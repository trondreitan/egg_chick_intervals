/*
 * $Id: neuralnet.C 1918 2011-03-23 14:25:50Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/neuralnet.C $
 */

#include <hydrasub/hydrabase/neuralnet.H>
#include <hydrasub/hydrabase/divfunc.H>

neuralnet::neuralnet()
{
  init();
}

void neuralnet::init(void)
{
  inputnode = outputnode = internalnode=NULL;
  numinput  = numoutput  = numinternal=0;
}

neuralnet::~neuralnet()
{
  cleanup();
}

void neuralnet::cleanup(void)
{
  register int i;
  
  if(inputnode)
    {
      for(i=0;i<numinput;i++)
	if(inputnode[i])
	  delete inputnode[i];
      delete [] inputnode;
      inputnode=NULL;
      numinput=0;
    }

  if(outputnode)
    {
      for(i=0;i<numoutput;i++)
	if(outputnode[i])
	  delete outputnode[i];
      delete [] outputnode;
      outputnode=NULL;
      numoutput=0;
    }

  if(internalnode)
    {
      for(i=0;i<numinternal;i++)
	if(internalnode[i])
	  delete internalnode[i];
      delete [] internalnode;
      internalnode=NULL;
      numinternal=0;
    }
}

neuralnet::neuralnet(node **input_nodes,    int num_in, 
		     node **output_nodes,   int num_out, 
		     node **internal_nodes, int num_int)
{
  register int i;

  inputnode=new node*[num_in];
  for(i=0;i<num_in; i++)
    inputnode[i]=input_nodes[i];
  numinput=num_in;

  outputnode=new node*[num_out];
  for(i=0;i<num_out; i++)
    outputnode[i]=output_nodes[i];
  numoutput=num_out;

  internalnode=new node*[num_int];
  for(i=0;i<num_int; i++)
    internalnode[i]=internal_nodes[i];
  numinternal=num_int;
}

// copies a neural net
neuralnet::neuralnet(neuralnet *orig)
{
  init();
  copynet(orig);
}

// copies a neural net
void neuralnet::copynet(neuralnet *orig)
{
  register int i,j;

  cleanup();

  numinput=orig->numinput;
  numoutput=orig->numoutput;
  numinternal=orig->numinternal;

  inputnode=new node*[numinput];
  for(i=0;i<numinput;i++)
    inputnode[i] = new node(orig->inputnode[i]);
  outputnode=new node*[numoutput];
  for(i=0;i<numoutput;i++)
    outputnode[i] = new node(orig->outputnode[i]);
  internalnode=new node*[numinternal];
  for(i=0;i<numinternal;i++)
    internalnode[i] = new node(orig->internalnode[i]);
  
  for(i=0;i<numinput;i++)
    {
      node *origin=orig->inputnode[i];
      node *copyin=inputnode[i];

      for(threadlist *thlist=origin->get_out_threads(); thlist; 
	  thlist=thlist->get_next_threadlistelement())
	{
	  thread th(thlist->get_thread(), NULL, NULL);

	  node *out=thlist->get_thread()->get_dest(), *copyout=NULL;

	  for(j=0;j<numinternal && !copyout;j++)
	    if(orig->internalnode[j] == out)
	      copyout = internalnode[j];

	  for(j=0;j<numoutput && !copyout;j++)
	    if((orig->outputnode[j]) == out)
	      copyout = outputnode[j];

	  if(copyout)
	    copyin->thread_out_of_node(&th, copyout);
	}
    }

  for(i=0;i<numinternal;i++)
    {
      node *origin=orig->internalnode[i];
      node *copyin=internalnode[i];

      for(threadlist *thlist=origin->get_out_threads(); thlist; 
	  thlist=thlist->get_next_threadlistelement())
	{
	  thread th(thlist->get_thread(), NULL, NULL);

	  node *out=thlist->get_thread()->get_dest(), *copyout=NULL;

	  for(j=0;j<numinternal && !copyout;j++)
	    if(orig->internalnode[j]==out)
	      copyout = internalnode[j];

	  for(j=0;j<numoutput && !copyout;j++)
	    if(orig->outputnode[j]==out)
	      copyout = outputnode[j];

	  if(copyout)
	    copyin->thread_out_of_node(&th, copyout);
	}
    }
}


void neuralnet::set_success(double new_success)
{
  for(int i=0;i<numoutput;i++)
    outputnode[i]->set_output_fire(new_success*outputnode[i]->get_fire());
}


// returns the status of the output node
void neuralnet::increment(double *input, double *output)
{
  register int i;

  for( i=0; i<numinput; i++ )
    inputnode[i]->set_fire(input[i]);

  for(i=0; i<numinput; i++)
    inputnode[i]->middle_increment();

  for(i=0; i<numinternal;i++)
    internalnode[i]->start_increment();
  
  for(i=0; i<numinternal;i++)
    internalnode[i]->middle_increment();

  for(i=0; i<numoutput; i++)
    outputnode[i]->start_increment();

  for(i=0; i<numoutput; i++)
    outputnode[i]->middle_increment();

  for(i=0; i<numinput; i++)
    inputnode[i]->end_increment();

  for(i=0; i<numinternal;i++)
    internalnode[i]->end_increment();

  for(i=0; i<numoutput; i++)
    {
      outputnode[i]->end_increment();
      output[i]=outputnode[i]->get_fire();
    }
}

// returns -1 if no descision was made
int neuralnet::reach_descision(double *input,int num_increment)
{
  double *output=new double[numoutput];
  register int i,j;

  for(i=0;i<num_increment; i++)
    {
      increment(input, output);
      if(drand48()<0.5)
	{
	  for(j=0;j<numoutput;j++)
	    if(output[j]>=0.9)
	      {
		delete [] output;
		return j;
	      }
	}
      else
	{
	  for(j=numoutput-1;j>=0;j--)
	    if(output[j]>=0.9)
	      {
		delete [] output;
		return j;
	      }
	}
    }

  delete [] output;
  return -1;
}


int neuralnet::get_num_input(void)
{
  return numinput;
}

int neuralnet::get_num_output(void)
{
  return numoutput;
}

int neuralnet::get_num_internal(void)
{
  return numinternal;
}

node **neuralnet::get_all_nodes(int *numnodes)
{
  *numnodes = numinput + numoutput + numinternal;
  
  node **allnodes=new node*[*numnodes];
  register int i=0,j;
  
  for(j=0;j<numinput;j++)
    allnodes[i++]=inputnode[j];

  for(j=0;j<numinternal;j++)
    allnodes[i++]=internalnode[j];

  for(j=0;j<numoutput;j++)
    allnodes[i++]=outputnode[j];
  
  return allnodes;
}

unsigned int neuralnet::get_number_of_nodes(void)
{
  return numinput+numoutput+numinternal;
}
 
unsigned int neuralnet::get_number_of_threads(void)
{
  unsigned int ret=0;
  register int j;

  for(j=0;j<numinternal;j++)
    ret += internalnode[j]->get_in_threads()->number_of_elements();

  for(j=0;j<numoutput;j++)
    ret += outputnode[j]->get_in_threads()->number_of_elements();

  return ret;
}

void neuralnet::print(std::ostream &out)
{
  int j; 

  for(j=0;j<numinput;j++)
    {
      out << "Input-node " << j+1 << " :" << std::endl;
      inputnode[j]->print(out);
      out << std::endl;
    }

  for(j=0;j<numinternal;j++)
    {
      out << "Internal-node " << j+1 << " :" << std::endl;
      internalnode[j]->print(out);
      out << std::endl;
    }

  for(j=0;j<numoutput;j++)
    {
      out << "Output-node " << j+1 << " :" << std::endl;
      outputnode[j]->print(out);
      out << std::endl;
    }
}
