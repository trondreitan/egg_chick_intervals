/*
 * $Id: bayesian_homogeneity.C 2576 2015-10-22 07:09:28Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/bayesian_homogeneity.C $
 */

#include <hydrasub/hydrabase/types.H>
#include <cmath>
#include <hydrasub/hydrabase/bayesian_homogeneity.H>
#include <hydrasub/hydrabase/linalg.H>
#include <hydrasub/hydrabase/mcmc.H>
#include <hydrasub/hydrabase/kalman.H>

void bayesian_homogeneity::init(void)
{
  post=yearvalues=logyearvalues=years=NULL;
  twostep_post=NULL;

  // default: 0.5, 0.1, 0.04, 0.26, 0.1
  prior_homogeneity=0.5;
  prior_linear=0.1;
  prior_quadratic=0.04;
  prior_twostep=0.1;
  
  start=end=numyears=0;
  regresult=NULL;
  twostep_regresult=NULL;
  calculated=false;
}

void bayesian_homogeneity::cleanup(void)
{
  if(yearvalues)
    delete yearvalues;
  if(logyearvalues)
    delete logyearvalues;
  if(years)
    delete [] years;
  if(post)
    delete [] post;
  doubledelete(twostep_post, numyears-2);

  if(regresult)
    {
      for(int i=0;i<numyears;i++)
	if(regresult[i])
	  delete regresult[i];
      delete [] regresult;
    }

  if(twostep_regresult)
    {
      for(int i=0;i<numyears-2;i++)
	if(twostep_regresult[i])
	  {
	    for(int j=0;j<numyears-2;j++)
	      if(twostep_regresult[i][j])
		delete twostep_regresult[i][j];
	    delete [] twostep_regresult[i];
	  }
      delete [] twostep_regresult;
    }

  init();
}

bayesian_homogeneity::bayesian_homogeneity()
{
  init();
}

bayesian_homogeneity::~bayesian_homogeneity()
{
  cleanup();
}

// Set the input data;
void bayesian_homogeneity::set_data(double *years_, double *values, 
				   int num_years)
{
  cleanup();

  int i,j,len=numyears=num_years;
  
  yearvalues=new double[len];
  logyearvalues=new double[len];
  years=new double[len];
  post=new double[len+2];
  twostep_post=new double*[len-2];

  //std::cout << endl;
  //std::cout << len << endl;
  for(i=0;i<len;i++)
    {
      //std::cout << years_[i] << " " << values[i] << endl;
      yearvalues[i]=values[i];
      logyearvalues[i]=log(values[i]);
      years[i]=years_[i];
      post[i]=0.0;
      
      if(i<len-2)
	{
	  twostep_post[i]=new double[len-2];
	  for(j=0;j<len-2;j++)
	    twostep_post[i][j]=0.0;
	}
    }
  post[i]=0.0;
  post[i+1]=0.0;
  
  start=(int) years[0];
  end=(int) years[len-1];
}
  
int bayesian_homogeneity::get_start_year(void)
{
  return start;
}

int bayesian_homogeneity::get_end_year(void)
{
  return end;
}

int bayesian_homogeneity::get_num_years(void)
{
  return numyears;
}


double *bayesian_homogeneity::getyears(void)
{
  return years;
}

double *bayesian_homogeneity::get_year_values(void)
{
  return yearvalues;
}

double *bayesian_homogeneity::get_log_year_values(void)
{
  return logyearvalues;
}

double bayesian_homogeneity::get_mean_year(void)
{
  return meanyear;
}

bool bayesian_homogeneity::has_been_calculated(void)
{
  return calculated;
}

// Calculates the aposterior probabilites of each 
// model (homgen and inhomogen).
void bayesian_homogeneity::calculate_aposteriori(double priorhomogeneity,
						 double priorlinear, 
						 double priorquadratic,
						 double priortwostep)
{
  int i,j,k, len=numyears;
  double a=4.0, b=1.0;
  double *prior=new double[len+2];
  double **twostep_prior=new double*[len-2];
  double scale=0.0, loglik;
  double **Xlin=new double*[2], **Xquad=new double*[3];
  double *mlin=new double[2], *mquad=new double[3];
  double **vlin=new double*[2], **vquad=new double*[3];
  double **X=new double*[2], *Xhh=new double[len];
  double **twostep_X=new double*[3];
  double mh=2.0, *vh=new double[1];
  double **v=new double*[2], *m=new double[2];
  double **twostep_v=new double*[3], *twostep_m=new double[3];
  double *likelihood=new double[len+2]; 
  double **twostep_likelihood=new double*[len-2];
  
  for(i=0;i<len-2;i++)
    {
      twostep_likelihood[i]=new double[len-2];
      twostep_prior[i]=new double[len-2];
      for(j=0;j<len-2;j++)
	{
	  twostep_likelihood[i][j]=0.0;
	  twostep_prior[i][j]=0.0;
	}
    }

  meanyear=find_statistics(years, numyears, MEAN);

  Xlin[0]=new double[len];
  Xlin[1]=new double[len];
  mlin[0]=2.0;
  mlin[1]=0.0;
  vlin[0]=new double[2];
  vlin[1]=new double[2];
  vlin[0][0]=6.0*6.0*(a-2)/b;
  vlin[1][1]=0.01*0.01*(a-2)/b;
  vlin[0][1]=vlin[1][0]=0;

  Xquad[0]=new double[len];
  Xquad[1]=new double[len];
  Xquad[2]=new double[len];
  mquad[0]=2.0;
  mquad[1]=0.0;
  mquad[2]=0.0;
  vquad[0]=new double[3];
  vquad[1]=new double[3];
  vquad[2]=new double[3];
  vquad[0][0]=6.0*6.0*(a-2)/b;
  vquad[1][1]=0.01*0.01*(a-2)/b;
  vquad[2][2]=0.0005*0.0005*(a-2)/b;
  vquad[0][1]=vquad[1][0]=0;
  vquad[0][2]=vquad[2][0]=0;
  vquad[2][1]=vquad[1][2]=0;
  
  X[0]=new double[len];
  X[1]=new double[len];
  v[0]=new double[2];
  v[1]=new double[2];
  
  vh[0]=6.0*6.0*(a-2)/b;
  v[0][0]=v[1][1]=vh[0];
  v[0][1]=v[1][0]=0.0;
  m[0]=m[1]=2.0;
  
  twostep_X[0]=new double[len];
  twostep_X[1]=new double[len];
  twostep_X[2]=new double[len];
  twostep_v[0]=new double[3];
  twostep_v[1]=new double[3];
  twostep_v[2]=new double[3];
  
  twostep_v[0][0]=twostep_v[1][1]=twostep_v[2][2]=vh[0];
  twostep_v[0][1]=twostep_v[1][0]=twostep_v[0][2]=twostep_v[2][0]=
    twostep_v[1][2]=twostep_v[2][1]=0.0;
  twostep_m[0]=twostep_m[1]=twostep_m[2]=2.0;
  
  double totpriorstep=0.0;
  prior[0]=priorhomogeneity;
  for(i=0;i<len;i++)
    {
      Xhh[i]=1.0;
      if(i>0)
	{
	  prior[i]=double(i)*double(len-i);
	  totpriorstep+=prior[i];
	}
      Xlin[0][i]=1.0;
      Xlin[1][i]=years[i]-meanyear;
      Xquad[0][i]=1.0;
      Xquad[1][i]=years[i]-meanyear;
      Xquad[2][i]=(years[i]-meanyear)*(years[i]-meanyear);
    }

  for(i=1;i<len;i++)
    prior[i]*=(1.0-priorhomogeneity-priorlinear-priorquadratic-priortwostep)/
      totpriorstep;

  double tot_twostep_prior=0.0;
  for(i=0;i<len-2;i++)
    for(j=0;j<len-i-2;j++)
      {
	twostep_prior[i][j]=double(i+1)*
	  double(j+1)*double(len-i-j);

	tot_twostep_prior += twostep_prior[i][j];
      }
    
  for(i=0;i<len-2;i++)
    for(j=0;j<len-i-2;j++)
      twostep_prior[i][j] *= priortwostep/tot_twostep_prior;

  prior[len]=priorlinear;
  prior[len+1]=priorquadratic;
  
  regresult=new bayesian_regression*[len+2];
  regresult[0]=
    get_bayesian_regression(&Xhh, 1, logyearvalues, len, 
			    &mh, &vh, a, b);
  loglik=regresult[0]->probability_density_of_data(true);
  
  for(i=1;i<len;i++)
    {
      for(j=0;j<len;j++)
	{
	  if(j<i)
	    {
	      X[0][j]=1.0;
	      X[1][j]=0.0;
	    }
	  else
	    {
	      X[0][j]=0.0;
	      X[1][j]=1.0;
	    }
	}
      
      regresult[i]=get_bayesian_regression(X, 2, logyearvalues, len,
					   m, v, a, b);
    }
  
  twostep_regresult=new bayesian_regression**[len-2];
  for(i=1;i<len-1;i++)
    {
      twostep_regresult[i-1]=new bayesian_regression*[len-2];
      
      for(k=0;k<len-2;k++)
	twostep_regresult[i-1][k]=NULL;

      for(k=i+1;k<len;k++)
	{
	  for(j=0;j<len;j++)
	    {
	      if(j<i)
		{
		  twostep_X[0][j]=1.0;
		  twostep_X[1][j]=0.0;
		  twostep_X[2][j]=0.0;
		}
	      else if(j<k)
		{
		  twostep_X[0][j]=0.0;
		  twostep_X[1][j]=1.0;
		  twostep_X[2][j]=0.0;
		}
	      else
		{
		  twostep_X[0][j]=0.0;
		  twostep_X[1][j]=0.0;
		  twostep_X[2][j]=1.0;
		}
	    }

	  twostep_regresult[i-1][k-i-1]=
	    get_bayesian_regression(twostep_X, 3, 
				    logyearvalues, len,
				    twostep_m, twostep_v, a, b);
	}
    }

  regresult[len]=get_bayesian_regression(Xlin, 2, logyearvalues, len,
					 mlin, vlin, a, b);
  
  regresult[len+1]=get_bayesian_regression(Xquad, 3, logyearvalues, len,
					   mquad, vquad, a, b);

  for(i=0;i<len+2;i++)
    likelihood[i]=regresult[i]->probability_density_of_data(false, 
							    loglik);
  for(i=0;i<len-2;i++)
    for(j=0;j<len-i-2;j++)
      twostep_likelihood[i][j]=
	twostep_regresult[i][j]->probability_density_of_data(false, 
							     loglik);

  for(i=0;i<len+2;i++)
    scale+=prior[i]*likelihood[i];
  for(i=0;i<len-2;i++)
    for(j=0;j<len-i-2;j++)
      scale+=twostep_prior[i][j]*twostep_likelihood[i][j];

  for(i=0;i<len+2;i++)
    post[i]=prior[i]*likelihood[i]/scale;
  for(i=0;i<len-2;i++)
    for(j=0;j<len-i-2;j++)
      twostep_post[i][j]=twostep_prior[i][j]*twostep_likelihood[i][j]/
	scale;


  total_onestep=0.0;
  for(i=1;i<numyears;i++)
    total_onestep+=post[i];

  double maxprob=0.0, maxprob2=0.0;
  for(i=1;i<numyears;i++)
    if(post[i]>maxprob)
      {
	maxprob=post[i];
	maxindex=i;
      }

  maxindex1=1;
  maxindex2=2;
  total_twostep=0.0;
  for(i=0;i<numyears-2;i++)
    for(j=0;j<numyears-i-2;j++)
      {
	total_twostep+=twostep_post[i][j];
	if(twostep_post[i][j]>maxprob2)
	  {
	    maxprob2=twostep_post[i][j];
	    maxindex1=i+1;
	    maxindex2=i+j+2;
	  }
      }

  delete [] prior;
  doubledelete(twostep_prior,len-2);
  doubledelete(Xlin,2);
  doubledelete(Xquad,3);
  delete [] mlin;
  delete [] mquad;
  doubledelete(vlin,2);
  doubledelete(vquad,3);
  doubledelete(X,2);
  delete [] Xhh;
  doubledelete(twostep_X,3);
  delete [] vh;
  doubledelete(v,2);
  delete [] m;
  doubledelete(twostep_v,3);
  delete [] twostep_m;
  delete [] likelihood;
  doubledelete(twostep_likelihood,len-2);

  calculated=true;
}

// These methods should not be called before running 'check_homogeneity);

// returns the aposteriori probabilities for model number 
// 0 (homogen model), 1-numyears (step models),
// numyears (linear model) and numyears+1 (quadratic model)
// two-step probabilities needs to be fetched by their own
double *bayesian_homogeneity::fetch_aposteriori_model_probabilities(void)
{
  return post;
}

double bayesian_homogeneity::homogeneity_probability(void)
{
  return post[0];
}

double bayesian_homogeneity::homogeneity_mean(void)
{
  return exp(regresult[0]->get_mean_coefficient(0));
}

double bayesian_homogeneity::homogeneity_upper(double credibility)
{
  return exp(regresult[0]->upper_coefficient_credibility(0,credibility));
}

double bayesian_homogeneity::homogeneity_lower(double credibility)
{
  return exp(regresult[0]->lower_coefficient_credibility(0,credibility));
}

double bayesian_homogeneity::homogeneity_sdev(void)
{
  return sqrt(regresult[0]->get_mean_square_standard_deviation());
}

double bayesian_homogeneity::full_step_model_probability(void)
{
  return total_onestep;
}

double bayesian_homogeneity::maxprob_step_probability(void)
{
  return post[maxindex];
}

int bayesian_homogeneity::year_maxprob_before_step(void)
{
  return (int) years[maxindex-1];
}

int bayesian_homogeneity::year_maxprob_after_step(void)
{
  return (int) years[maxindex];
}

double bayesian_homogeneity::maxprob_step_mean_before(void)
{
  return exp(regresult[maxindex]->get_mean_coefficient(0));
}

double bayesian_homogeneity::maxprob_step_upper_before(double credibility)
{
  return exp(regresult[maxindex]->
    upper_coefficient_credibility(0,credibility));
}

double bayesian_homogeneity::maxprob_step_lower_before(double credibility)
{
  return exp(regresult[maxindex]->
    lower_coefficient_credibility(0,credibility));
}

double bayesian_homogeneity::maxprob_step_mean_after(void)
{
  return exp(regresult[maxindex]->get_mean_coefficient(1));
}

double bayesian_homogeneity::maxprob_step_upper_after(double credibility)
{
  return exp(regresult[maxindex]->
    upper_coefficient_credibility(1,credibility));
}

double bayesian_homogeneity::maxprob_step_lower_after(double credibility)
{
  return exp(regresult[maxindex]->
    lower_coefficient_credibility(1,credibility));
}

double bayesian_homogeneity::maxprob_step_sdev(void)
{
  return sqrt(regresult[maxindex]->
	      get_mean_square_standard_deviation());
}

double bayesian_homogeneity::linear_probability(void)
{
  return post[numyears];
}

double bayesian_homogeneity::linear_mean_intercept(void)
{
  return regresult[numyears]->get_mean_coefficient(0);
}

double bayesian_homogeneity::linear_mean_slope(void)
{
  return regresult[numyears]->get_mean_coefficient(1);
}

double bayesian_homogeneity::linear_sdev(void)
{
  return sqrt(regresult[numyears]->
	      get_mean_square_standard_deviation());
}

double bayesian_homogeneity::quadratic_probability(void)
{
  return post[numyears+1];
}
 
double bayesian_homogeneity::quadratic_mean_intercept(void)
{
  return regresult[numyears+1]->get_mean_coefficient(0);
}

double bayesian_homogeneity::quadratic_mean_slope(void)
{
  return regresult[numyears+1]->get_mean_coefficient(1);
}

double bayesian_homogeneity::quadratic_mean_curvature(void)
{
  return regresult[numyears+1]->get_mean_coefficient(2);
}

double bayesian_homogeneity::quadratic_sdev(void)
{
  return sqrt(regresult[numyears+1]->
	      get_mean_square_standard_deviation());
}

double bayesian_homogeneity::full_twostep_probability(void)
{
  return total_twostep;
}

double bayesian_homogeneity::maxprob_twostep_probability(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_post[i][j];
}

int bayesian_homogeneity::year_maxprob_twostep_before_step1(void)
{
  return (int) years[maxindex1-1];
}

int bayesian_homogeneity::year_maxprob_twostep_after_step1(void)
{
  return (int) years[maxindex1];
}

int bayesian_homogeneity::year_maxprob_twostep_before_step2(void)
{
  return (int) years[maxindex2-1];
}

int bayesian_homogeneity::year_maxprob_twostep_after_step2(void)
{
  return (int) years[maxindex2];
}

double bayesian_homogeneity::maxprob_twostep_mean_before1(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->get_mean_coefficient(0));
}

double bayesian_homogeneity::maxprob_twostep_upper_before1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->
	     upper_coefficient_credibility(0,credibility));
}

double bayesian_homogeneity::maxprob_twostep_lower_before1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->
	     lower_coefficient_credibility(0,credibility));
}

double bayesian_homogeneity::maxprob_twostep_mean_after1(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->get_mean_coefficient(1));
}

double bayesian_homogeneity::maxprob_twostep_upper_after1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->
	     upper_coefficient_credibility(1,credibility));
}

double bayesian_homogeneity::maxprob_twostep_lower_after1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->
	     lower_coefficient_credibility(1,credibility));
}

double bayesian_homogeneity::maxprob_twostep_mean_after2(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->get_mean_coefficient(2));
}

double bayesian_homogeneity::maxprob_twostep_upper_after2(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->
	     upper_coefficient_credibility(2,credibility));
}

double bayesian_homogeneity::maxprob_twostep_lower_after2(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return exp(twostep_regresult[i][j]->
	     lower_coefficient_credibility(2,credibility));
}

double bayesian_homogeneity::maxprob_twostep_sdev(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return sqrt(twostep_regresult[i][j]->
     get_mean_square_standard_deviation());
}


// Returns the index of the one step model with the maximal probability;
int bayesian_homogeneity::get_maxprob_onestep_index(void)
{
  return maxindex;
}

// Ditto for the two step model;
int bayesian_homogeneity::get_maxprob_twostep_index_1(void)
{
  return maxindex1;
}

int bayesian_homogeneity::get_maxprob_twostep_index_2(void)
{
  return maxindex2;
}

BAYESIAN_TIMESERIE_MODEL bayesian_homogeneity::get_most_probable_model(void)
{
  if(post[0]>=total_onestep && post[0]>=total_twostep &&
     post[0]>=post[numyears] && post[0]>=post[numyears+1])
    return BAYESIAN_HOMOGENEITY;
  else if(post[numyears]>=post[0] && post[numyears]>=total_onestep && 
	  post[numyears]>=total_twostep && post[numyears]>=post[numyears+1])
    return BAYESIAN_LINEAR;
  else if(post[numyears+1]>=post[0] && post[numyears+1]>=total_onestep && 
	  post[numyears+1]>=total_twostep && post[numyears+1]>=post[numyears])
    return BAYESIAN_QUADRATIC;
  else if(total_onestep>=post[0] && total_onestep>=total_twostep &&
	  total_onestep>=post[numyears] && total_onestep>=post[numyears+1])
    return BAYESIAN_ONESTEP;
  else
    return BAYESIAN_TWOSTEP;
}


// Returns the regression results. Same indexing as for 'check_homogeneity'
bayesian_regression **bayesian_homogeneity::get_regressions(void)
{
  return regresult;
}

// Returns the two-step probabilities, a 
// (numyears-2)x(numyears-2) matrix. 
double **bayesian_homogeneity::get_two_step_probabilities(void)
{
  return twostep_post;
}

// Ditto for the regressions;
bayesian_regression ***bayesian_homogeneity::get_twostep_regressions(void)
{
  return twostep_regresult;
}








// Bayesian methods for analysing values of normally timeseries
// (assumed independent) and find if it's homogeneous or has 
// a linear, quadratic one-step or two-step trend.




void bayesian_homogeneity_general::init(void)
{
  post=y=logy=x=separate_x=NULL;
  twostep_post=NULL;
  startx=endx=MISSING_VALUE;
  len=separate_len=0;
  regresult=NULL;
  twostep_regresult=NULL;
  calculated=false;
  
  prior_homogeneity=0.5;
  prior_linear=0.5/4.0;
  prior_quadratic=0.5/4.0;
  prior_twostep=0.5/4.0;
  
  sigma_a=1.0;
  sigma_b=0.05;
  sd_a=0.05;
  sd_b=1.0;
  mu_a=0.0;
  
  logarithmic=false;
}

void bayesian_homogeneity_general::cleanup(bool doinit)
{
  if(y)
    delete [] y;
  if(logy)
    delete [] logy;
  if(x)
    delete [] x;
  if(separate_x)
    delete [] separate_x;
  if(post)
    delete [] post;
  doubledelete(twostep_post, separate_len-2);
  
  if(regresult && separate_len>1)
    {
      for(int i=0;i<separate_len;i++)
	if(regresult[i])
	  delete regresult[i];
      delete [] regresult;
    }
  
  if(twostep_regresult && separate_len>2)
    {
      for(int i=0;i<separate_len-2;i++)
	if(twostep_regresult[i])
	  {
	    for(int j=0;j<separate_len-2;j++)
	      if(twostep_regresult[i][j])
		delete twostep_regresult[i][j];
	    delete [] twostep_regresult[i];
	  }
      delete [] twostep_regresult;
    }

  if(doinit)
    init();
  else
    {
      post=y=logy=x=separate_x=NULL;
      twostep_post=NULL;
      regresult=NULL;
      twostep_regresult=NULL;
      calculated=false;
    }
}

bayesian_homogeneity_general::bayesian_homogeneity_general()
{
  init();
}

bayesian_homogeneity_general::~bayesian_homogeneity_general()
{
  cleanup();
}

// Set the input data;
void bayesian_homogeneity_general::set_data(double *x_, double *y_, 
					    int num_data)
{
  cleanup(false);
  
  int i,j;
  len=num_data;

  double_2d *data=new double_2d[len];
  for(i=0;i<len;i++)
    {
      data[i].x=x_[i];
      data[i].y=y_[i];
    }
  qsort(data,size_t(len),sizeof(double_2d), compare_double_2d_x);
  
  x=new double[len];
  y=new double[len];
  if(logarithmic)
    logy=new double[len];
  separate_x=new double[len];
  separate_len=0;
  
  for(i=0;i<len;i++)
    {
      x[i]=data[i].x;
      y[i]=data[i].y;
      if(logarithmic)
	logy[i]=log(y[i]);
      if(i==0 || x[i]>x[i-1])
	{
	  separate_x[separate_len]=x[i];
	  separate_len++;
	}
    }
  meanx=find_statistics(x,len,MEAN);
  
  post=new double[separate_len+2];
  if(separate_len>2)
    twostep_post=new double*[separate_len-2];

  for(i=0;i<separate_len;i++)
    {
      post[i]=0.0;
      
      if(i<(separate_len-2))
	{
	  twostep_post[i]=new double[separate_len-2];
	  for(j=0;j<separate_len-2;j++)
	    twostep_post[i][j]=0.0;
	}
    }
  post[i]=0.0;
  post[i+1]=0.0;

  startx=x[0];
  endx=x[len-1];
  
  sd_b=2.0*sd_a/(endx-startx);
  
  delete [] data;
}


// Set logarithmic transformation (default off)
void bayesian_homogeneity_general::set_logarithmic(bool is_logarithmic)
{
  logarithmic=is_logarithmic;
  if(logarithmic && y && len>0)
    {
      if(logy)
	delete [] logy;
      logy=new double[len];
      for(int i=0;i<len;i++)
	logy[i]=log(y[i]);
    }
}

bool bayesian_homogeneity_general::is_logarithmic(void)
{
  return logarithmic;
}
  
  
// Optional input:
void bayesian_homogeneity_general::set_priors(double sigma_alpha, 
					      double sigma_beta,
					      double mu_const, 
					      double sd_const, 
					      double sd_slope)
{
  sigma_a=sigma_alpha;
  sigma_b=sigma_beta;
  mu_a=mu_const;
  sd_a=sd_const;
  sd_b=sd_slope;
}

void bayesian_homogeneity_general::
set_prior_probabilities(double prior_homogeneity_,
			double prior_linear_,
			double prior_quadratic_,
			double prior_onestep_,
			double prior_twostep_)
  // previous default: 0.5, 0.1, 0.04, 0.26, 0.1
  // default: 0.5, 0.125, 0.125, 0.125, 0.125
{
  double ptot=(prior_homogeneity_+prior_linear_+
	       prior_quadratic_+prior_onestep_+prior_twostep_);
  prior_homogeneity=prior_homogeneity_/ptot;
  prior_linear=prior_linear_/ptot;
  prior_quadratic=prior_quadratic_/ptot;
  prior_twostep=prior_twostep_/ptot;
}

double bayesian_homogeneity_general::get_start_x(void)
{
  return startx;
}

double bayesian_homogeneity_general::get_end_x(void)
{
  return endx;
}

int bayesian_homogeneity_general::get_num_data(void)
{
  return len;
}


double *bayesian_homogeneity_general::get_x(void)
{
  return x;
}

double *bayesian_homogeneity_general::get_y(void)
{
  return y;
}

double bayesian_homogeneity_general::get_mean_x(void)
{
  return meanx;
}

bool bayesian_homogeneity_general::has_been_calculated(void)
{
  return calculated;
}

// Calculates the aposterior probabilites of each 
// model (homgen and inhomogen).
void bayesian_homogeneity_general::calculate_aposteriori(void)
{
  int i,j,k;
  double a=sigma_a, b=sigma_b;
  double *prior=new double[separate_len+2];
  double **twostep_prior=NULL;
  double **twostep_likelihood=NULL;
  if(separate_len>2)
    {
      twostep_prior=new double*[separate_len-2];
      twostep_likelihood=new double*[separate_len-2];
    }
  double scale=0.0, loglik;
  double **Xlin=new double*[2], **Xquad=new double*[3];
  double *mlin=new double[2], *mquad=new double[3];
  double **vlin=new double*[2], **vquad=new double*[3];
  double **X=new double*[2], *Xh=new double[len];
  double **twostep_X=new double*[3];
  double mh=mu_a, *vh=new double[1];
  double **v=new double*[2], *m=new double[2];
  double **twostep_v=new double*[3], *twostep_m=new double[3];
  double *likelihood=new double[separate_len+2]; 

  for(i=0;i<separate_len-2;i++)
    {
      twostep_likelihood[i]=new double[separate_len-2];
      twostep_prior[i]=new double[separate_len-2];
      for(j=0;j<separate_len-2;j++)
	{
	  twostep_likelihood[i][j]=0.0;
	  twostep_prior[i][j]=0.0;
	}
    }

  meanx=find_statistics(x, len, MEAN);

  Xlin[0]=new double[len];
  Xlin[1]=new double[len];
  mlin[0]=mu_a;
  mlin[1]=0.0;
  vlin[0]=new double[2];
  vlin[1]=new double[2];
  vlin[0][0]=sd_a*sd_a/(b/a);
  vlin[1][1]=sd_b*sd_b/(b/a);
  vlin[0][1]=vlin[1][0]=0;

  Xquad[0]=new double[len];
  Xquad[1]=new double[len];
  Xquad[2]=new double[len];
  mquad[0]=mu_a;
  mquad[1]=0.0;
  mquad[2]=0.0;
  vquad[0]=new double[3];
  vquad[1]=new double[3];
  vquad[2]=new double[3];
  vquad[0][0]=sd_a*sd_a/(b/a);
  vquad[1][1]=sd_b*sd_b/(b/a);
  vquad[2][2]=sd_b*sd_b*sd_b*sd_b/(b/a);
  vquad[0][1]=vquad[1][0]=0;
  vquad[0][2]=vquad[2][0]=0;
  vquad[2][1]=vquad[1][2]=0;

  X[0]=new double[len];
  X[1]=new double[len];
  v[0]=new double[2];
  v[1]=new double[2];
  
  vh[0]=sd_a*sd_a/(b/a);
  v[0][0]=v[1][1]=vh[0];
  v[0][1]=v[1][0]=0.0;
  m[0]=m[1]=mu_a;
  
  twostep_X[0]=new double[len];
  twostep_X[1]=new double[len];
  twostep_X[2]=new double[len];
  twostep_v[0]=new double[3];
  twostep_v[1]=new double[3];
  twostep_v[2]=new double[3];

  twostep_v[0][0]=twostep_v[1][1]=twostep_v[2][2]=vh[0];
  twostep_v[0][1]=twostep_v[1][0]=twostep_v[0][2]=twostep_v[2][0]=
    twostep_v[1][2]=twostep_v[2][1]=0.0;
  twostep_m[0]=twostep_m[1]=twostep_m[2]=mu_a;
  
  double totpriorstep=0.0;
  prior[0]=prior_homogeneity;
  for(i=0;i<len;i++)
    Xh[i]=1.0;
  
  for(i=1;i<separate_len;i++)
    {
      prior[i]=double(i)*double(separate_len-i);
      totpriorstep+=prior[i];
    }
  
  for(i=0;i<len;i++)
    {
      Xlin[0][i]=1.0;
      Xlin[1][i]=x[i]-meanx;
      Xquad[0][i]=1.0;
      Xquad[1][i]=x[i]-meanx;
      Xquad[2][i]=(x[i]-meanx)*(x[i]-meanx);
    }
  
  for(i=1;i<separate_len;i++)
    prior[i]*=(1.0-prior_homogeneity-prior_linear-prior_quadratic-
	       prior_twostep)/
      totpriorstep;
  
  double tot_twostep_prior=0.0;
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      {
	twostep_prior[i][j]=double(i+1)*
	  double(j+1)*double(separate_len-i-j);
	
	tot_twostep_prior += twostep_prior[i][j];
      }
    
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      twostep_prior[i][j] *= prior_twostep/tot_twostep_prior;
  
  prior[separate_len]=prior_linear;
  prior[separate_len+1]=prior_quadratic;
  
  regresult=new bayesian_regression*[separate_len+2];
  regresult[0]=
    get_bayesian_regression(&Xh, 1, !logarithmic ? y : logy, len, 
			    &mh, &vh, a, b);
  loglik=regresult[0]->probability_density_of_data(true);
  
  for(i=1;i<separate_len;i++)
    {
      for(j=0;j<len;j++)
	{
	  if(x[j]<separate_x[i])
	    {
	      X[0][j]=1.0;
	      X[1][j]=0.0;
	    }
	  else
	    {
	      X[0][j]=0.0;
	      X[1][j]=1.0;
	    }
	}
      
      regresult[i]=get_bayesian_regression(X, 2, !logarithmic ? y : logy, 
					   len, m, v, a, b);
    }
  
  twostep_regresult=NULL;
  if(separate_len>2)
    {
      twostep_regresult=new bayesian_regression**[separate_len-2];
      for(i=1;i<separate_len-1;i++)
	{
	  twostep_regresult[i-1]=new bayesian_regression*[separate_len-2];
	  
	  for(k=0;k<separate_len-2;k++)
	    twostep_regresult[i-1][k]=NULL;
	  
	  for(k=i+1;k<separate_len;k++)
	    {
	      for(j=0;j<len;j++)
		{
		  if(x[j]<separate_x[i])
		    {
		      twostep_X[0][j]=1.0;
		      twostep_X[1][j]=0.0;
		      twostep_X[2][j]=0.0;
		    }
		  else if(x[j]<separate_x[k])
		    {
		      twostep_X[0][j]=0.0;
		      twostep_X[1][j]=1.0;
		      twostep_X[2][j]=0.0;
		    }
		  else
		    {
		      twostep_X[0][j]=0.0;
		      twostep_X[1][j]=0.0;
		      twostep_X[2][j]=1.0;
		    }
		}
	      
	      twostep_regresult[i-1][k-i-1]=
		get_bayesian_regression(twostep_X, 3, !logarithmic ? y : logy, 
					len, twostep_m, twostep_v, a, b);
	    }
	}
    }
  
  regresult[separate_len]=get_bayesian_regression(Xlin, 2, !logarithmic ? 
						  y : logy, len,
						  mlin, vlin, a, b);
  
  regresult[separate_len+1]=get_bayesian_regression(Xquad, 3, !logarithmic ?
						    y : logy, len,
						    mquad, vquad, a, b);
  
  for(i=0;i<separate_len+2;i++)
    likelihood[i]=regresult[i]->probability_density_of_data(false, 
							    loglik);
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      twostep_likelihood[i][j]=
	twostep_regresult[i][j]->probability_density_of_data(false, 
							     loglik);

  for(i=0;i<separate_len+2;i++)
    scale+=prior[i]*likelihood[i];
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      scale+=twostep_prior[i][j]*twostep_likelihood[i][j];

  for(i=0;i<separate_len+2;i++)
    post[i]=prior[i]*likelihood[i]/scale;
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      twostep_post[i][j]=twostep_prior[i][j]*twostep_likelihood[i][j]/
	scale;
  
  total_onestep=0.0;
  for(i=1;i<separate_len;i++)
    total_onestep+=post[i];
  
  double maxprob=0.0, maxprob2=0.0;
  for(i=1;i<separate_len;i++)
    if(post[i]>maxprob)
      {
	maxprob=post[i];
	maxindex=i;
      }

  maxindex1=1;
  maxindex2=2;
  total_twostep=0.0;
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      {
	total_twostep+=twostep_post[i][j];
	if(twostep_post[i][j]>maxprob2)
	  {
	    maxprob2=twostep_post[i][j];
	    maxindex1=i+1;
	    maxindex2=i+j+2;
	  }
      }
  
  delete [] prior;
  doubledelete(twostep_prior,separate_len-2);
  doubledelete(Xlin,2);
  doubledelete(Xquad,3);
  delete [] mlin;
  delete [] mquad;
  doubledelete(vlin,2);
  doubledelete(vquad,3);
  doubledelete(X,2);
  delete [] Xh;
  doubledelete(twostep_X,3);
  delete [] vh;
  doubledelete(v,2);
  delete [] m;
  doubledelete(twostep_v,3);
  delete [] twostep_m;
  delete [] likelihood;
  doubledelete(twostep_likelihood,separate_len-2);

  calculated=true;
}

// These methods should not be called before running 'check_homogeneity);

// returns the aposteriori probabilities for model number 
// 0 (homogen model), 1-separate_len (step models),
// separate_len (linear model) and separate_len+1 (quadratic model)
// two-step probabilities needs to be fetched by their own
double *bayesian_homogeneity_general::fetch_aposteriori_model_probabilities(void)
{
  return post;
}

double bayesian_homogeneity_general::homogeneity_probability(void)
{
  return post[0];
}

double bayesian_homogeneity_general::homogeneity_mean(void)
{
  return regresult[0]->get_mean_coefficient(0);
}

double bayesian_homogeneity_general::homogeneity_upper(double credibility)
{
  return regresult[0]->upper_coefficient_credibility(0,credibility);
}

double bayesian_homogeneity_general::homogeneity_lower(double credibility)
{
  return regresult[0]->lower_coefficient_credibility(0,credibility);
}

double bayesian_homogeneity_general::homogeneity_sdev(void)
{
  return sqrt(regresult[0]->get_mean_square_standard_deviation());
}

double bayesian_homogeneity_general::full_step_model_probability(void)
{
  return total_onestep;
}

double bayesian_homogeneity_general::maxprob_step_probability(void)
{
  return post[maxindex];
}

double bayesian_homogeneity_general::x_maxprob_before_step(void)
{
  return x[maxindex-1];
}

double bayesian_homogeneity_general::x_maxprob_after_step(void)
{
  return x[maxindex];
}

double bayesian_homogeneity_general::maxprob_step_mean_before(void)
{
  return regresult[maxindex]->get_mean_coefficient(0);
}

double bayesian_homogeneity_general::
maxprob_step_upper_before(double credibility)
{
  return regresult[maxindex]->
    upper_coefficient_credibility(0,credibility);
}

double bayesian_homogeneity_general::
maxprob_step_lower_before(double credibility)
{
  return regresult[maxindex]->
    lower_coefficient_credibility(0,credibility);
}

double bayesian_homogeneity_general::maxprob_step_mean_after(void)
{
  return regresult[maxindex]->get_mean_coefficient(1);
}

double bayesian_homogeneity_general::
maxprob_step_upper_after(double credibility)
{
  return regresult[maxindex]->
    upper_coefficient_credibility(1,credibility);
}

double bayesian_homogeneity_general::
maxprob_step_lower_after(double credibility)
{
  return regresult[maxindex]->
    lower_coefficient_credibility(1,credibility);
}

double bayesian_homogeneity_general::maxprob_step_sdev(void)
{
  return sqrt(regresult[maxindex]->
	      get_mean_square_standard_deviation());
}

double bayesian_homogeneity_general::linear_probability(void)
{
  return post[separate_len];
}

double bayesian_homogeneity_general::linear_mean_intercept(void)
{
  return regresult[separate_len]->get_mean_coefficient(0);
}

double bayesian_homogeneity_general::linear_mean_slope(void)
{
  return regresult[separate_len]->get_mean_coefficient(1);
}

double bayesian_homogeneity_general::linear_sdev(void)
{
  return sqrt(regresult[separate_len]->
	      get_mean_square_standard_deviation());
}

double bayesian_homogeneity_general::quadratic_probability(void)
{
  return post[separate_len+1];
}
 
double bayesian_homogeneity_general::quadratic_mean_intercept(void)
{
  return regresult[separate_len+1]->get_mean_coefficient(0);
}

double bayesian_homogeneity_general::quadratic_mean_slope(void)
{
  return regresult[separate_len+1]->get_mean_coefficient(1);
}

double bayesian_homogeneity_general::quadratic_mean_curvature(void)
{
  return regresult[separate_len+1]->get_mean_coefficient(2);
}

double bayesian_homogeneity_general::quadratic_sdev(void)
{
  return sqrt(regresult[separate_len+1]->
	      get_mean_square_standard_deviation());
}

double bayesian_homogeneity_general::full_twostep_probability(void)
{
  return total_twostep;
}

double bayesian_homogeneity_general::maxprob_twostep_probability(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_post[i][j];
}

double bayesian_homogeneity_general::x_maxprob_twostep_before_step1(void)
{
  return x[maxindex1-1];
}

double bayesian_homogeneity_general::x_maxprob_twostep_after_step1(void)
{
  return x[maxindex1];
}

double bayesian_homogeneity_general::x_maxprob_twostep_before_step2(void)
{
  return x[maxindex2-1];
}

double bayesian_homogeneity_general::x_maxprob_twostep_after_step2(void)
{
  return x[maxindex2];
}

double bayesian_homogeneity_general::maxprob_twostep_mean_before1(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->get_mean_coefficient(0);
}

double bayesian_homogeneity_general::
maxprob_twostep_upper_before1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->
	     upper_coefficient_credibility(0,credibility);
}

double bayesian_homogeneity_general::
maxprob_twostep_lower_before1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->
	     lower_coefficient_credibility(0,credibility);
}

double bayesian_homogeneity_general::maxprob_twostep_mean_after1(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->get_mean_coefficient(1);
}

double bayesian_homogeneity_general::
maxprob_twostep_upper_after1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->
	     upper_coefficient_credibility(1,credibility);
}

double bayesian_homogeneity_general::
maxprob_twostep_lower_after1(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->
	     lower_coefficient_credibility(1,credibility);
}

double bayesian_homogeneity_general::maxprob_twostep_mean_after2(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->get_mean_coefficient(2);
}

double bayesian_homogeneity_general::
maxprob_twostep_upper_after2(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->
	     upper_coefficient_credibility(2,credibility);
}

double bayesian_homogeneity_general::
maxprob_twostep_lower_after2(double credibility)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return twostep_regresult[i][j]->
	     lower_coefficient_credibility(2,credibility);
}

double bayesian_homogeneity_general::maxprob_twostep_sdev(void)
{
  int i=maxindex1-1;
  int j=maxindex2-maxindex1-1;
  return sqrt(twostep_regresult[i][j]->
     get_mean_square_standard_deviation());
}


// Returns the index of the one step model with the maximal probability;
int bayesian_homogeneity_general::get_maxprob_onestep_index(void)
{
  return maxindex;
}

// Ditto for the two step model;
int bayesian_homogeneity_general::get_maxprob_twostep_index_1(void)
{
  return maxindex1;
}

int bayesian_homogeneity_general::get_maxprob_twostep_index_2(void)
{
  return maxindex2;
}

BAYESIAN_TIMESERIE_MODEL bayesian_homogeneity_general::
get_most_probable_model(void)
{
  if(post[0]>=total_onestep && post[0]>=total_twostep &&
     post[0]>=post[separate_len] && post[0]>=post[separate_len+1])
    return BAYESIAN_HOMOGENEITY;
  else if(post[separate_len]>=post[0] && 
	  post[separate_len]>=total_onestep && 
	  post[separate_len]>=total_twostep && 
	  post[separate_len]>=post[separate_len+1])
    return BAYESIAN_LINEAR;
  else if(post[separate_len+1]>=post[0] && 
	  post[separate_len+1]>=total_onestep && 
	  post[separate_len+1]>=total_twostep && 
	  post[separate_len+1]>=post[separate_len])
    return BAYESIAN_QUADRATIC;
  else if(total_onestep>=post[0] && 
	  total_onestep>=total_twostep &&
	  total_onestep>=post[separate_len] && 
	  total_onestep>=post[separate_len+1])
    return BAYESIAN_ONESTEP;
  else
    return BAYESIAN_TWOSTEP;
}


// Returns the regression results. Same indexing as for 'check_homogeneity'
bayesian_regression **bayesian_homogeneity_general::get_regressions(void)
{
  return regresult;
}

int bayesian_homogeneity_general::get_separate_x_len(void)
{
  return separate_len;
}

// Returns the two-step probabilities, a 
// (separate_len-2)x(separate_len-2) matrix. 
double **bayesian_homogeneity_general::get_two_step_probabilities(void)
{
  return twostep_post;
}

// Ditto for the regressions;
bayesian_regression ***bayesian_homogeneity_general::
get_twostep_regressions(void)
{
  return twostep_regresult;
}




void bayesian_homogeneity_general::show_priors_general(void)
 // for debug purposes
{
  printf("Logaritmisk=%s\n", logarithmic ? "Ja" : "Nei");
  printf("\n"); 
  printf("A' priori modellsannsynligheter:\n");
  printf("Homogen    : %7.3f\n", prior_homogeneity);
  printf("Line�r     : %7.3f\n", prior_linear);
  printf("Kvadratisk : %7.3f\n", prior_quadratic);
  printf("Ettsteg    : %7.3f\n", 1.0-prior_homogeneity-prior_linear-
	 prior_quadratic-prior_twostep);
  printf("Tosteg     : %7.3f\n", prior_twostep);
  printf("\n");
  printf("Lin�re parametre:\n");
  printf("a~N(%7.3f, %7.3f)\n", mu_a, sd_a);
  printf("b~N(      0, %7.3f)\n", sd_b);
  printf("sigma^2~IG(%7.3f,%7.3f)\n", sigma_a, sigma_b);
  printf("\n");
}






bayesian_homogeneity_with_ou::bayesian_homogeneity_with_ou()
{
  init();
  prior_homogeneity=0.5;
  prior_linear=0.5/5.0;
  prior_quadratic=0.5/5.0;
  prior_twostep=0.5/5.0;
  prior_ou=0.5/5.0;
  mu_mu=0;
  mu_sd=sd_a;
  logsd_mu=log(sd_a);
  logsd_sd=10.0;
  logdt_mu=1.0;
  logdt_sd=log(1000.0);
  logobs_mu=log(sd_a);
  logobs_sd=10.0;
  
  ou_mcmc_samples=NULL;
  ou_mu=ou_lsd=ou_ldt=ou_logobs=NULL;
  mean_ou_mu=mean_ou_lsd=mean_ou_ldt=mean_ou_logobs=MISSING_VALUE;
}

bayesian_homogeneity_with_ou::~bayesian_homogeneity_with_ou()
{
  cleanup();

  if(ou_mcmc_samples)
    doubledelete(ou_mcmc_samples, num_mcmc);
  if(ou_mu)
    delete [] ou_mu;
  ou_mu=NULL;
  if(ou_lsd)
    delete [] ou_lsd;
  ou_lsd=NULL;
  if(ou_ldt)
    delete [] ou_ldt;
  ou_ldt=NULL;
  if(ou_logobs)
    delete [] ou_logobs;
  ou_logobs=NULL;
  num_mcmc=0;
}

void bayesian_homogeneity_with_ou::
set_ou_priors(double mu_lower, 
	      double mu_upper, 
	      double stationary_sd_lower,
	      double stationary_sd_upper,
	      double corrtime_lower, double corrtime_upper,
	      double obs_sd_lower, double obs_sd_upper,
	      bool hard_corrtime_prior_border
	      // Use uniform distribution on log(corrtime) if set, 
	      // if not use log-normal distribution with 95% 
	      // within lower - upper
	      )
{
  mu_mu=(mu_lower+mu_upper)/2.0;
  mu_sd=(mu_upper-mu_lower)/2.0/1.96;
  logsd_mu=(log(stationary_sd_lower)+log(stationary_sd_upper))/2.0;
  logsd_sd=(log(stationary_sd_upper)-log(stationary_sd_lower))/2.0/1.96;
  logobs_mu=(log(obs_sd_lower)+log(obs_sd_upper))/2.0;
  logobs_sd=(log(obs_sd_upper)-log(obs_sd_lower))/2.0/1.96;
  if(!hard_corrtime_prior_border)
    {
      logdt_mu=(log(corrtime_lower)+log(corrtime_upper))/2.0;
      logdt_sd=(log(corrtime_upper)-log(corrtime_lower))/2.0/1.96;
      logdt_lower=logdt_upper=MISSING_VALUE;
    }
  else
    {
      logdt_mu=logdt_sd=MISSING_VALUE;
      logdt_lower=log(corrtime_lower);
      logdt_upper=log(corrtime_upper);
    }
}

void bayesian_homogeneity_with_ou::
set_prior_probabilities_with_ou(double prior_homogeneity_,
				double prior_linear_,
				double prior_quadratic_,
				double prior_onestep_,
				double prior_twostep_,
				double prior_ou_)
{
  double ptot=prior_homogeneity_+prior_linear_+
    prior_quadratic_+prior_onestep_+prior_twostep_+prior_ou_;
  prior_homogeneity=prior_homogeneity_/ptot;
  prior_linear=prior_linear_/ptot;
  prior_quadratic=prior_quadratic_/ptot;
  prior_twostep=prior_twostep_/ptot;
  prior_ou=prior_ou_/ptot;
}



void ou_init(int /* numparams */, 
	     double *params, 
	     int /* num_hyperparameters */,
	     double *hyperparameters)
{
  params[0]=hyperparameters[0]+hyperparameters[1]*gauss();
  params[1]=hyperparameters[2]+gauss();
  params[2]=hyperparameters[4]+hyperparameters[5]*gauss();
  params[3]=hyperparameters[8]+gauss();
}

double initvar=MISSING_VALUE;
double ou_logprior(int /* nnumparams */, 
		   double *params,
		   int /* num_hyperparameters */,
		   double *hyper_parameters)
{
  double mu_mu=hyper_parameters[0];
  double mu_sd=hyper_parameters[1];
  double lsd_mu=hyper_parameters[2];
  double lsd_sd=hyper_parameters[3];
  double ldt_mu=hyper_parameters[4];
  double ldt_sd=hyper_parameters[5];
  double ldt1=hyper_parameters[6];
  double ldt2=hyper_parameters[7];
  double logobs_mu=hyper_parameters[8];
  double logobs_sd=hyper_parameters[9];
  
  initvar=exp(2.0*lsd_mu)+mu_sd*mu_sd;

  double mu=params[0];
  double lsd=params[1];
  double ldt=params[2];
  double logobs=params[3];

  double lp_mu=
    -0.5*log(2.0*M_PI)-log(mu_sd)-0.5*(mu-mu_mu)*(mu-mu_mu)/mu_sd/mu_sd;
  double lp_lsd=
    -0.5*log(2.0*M_PI)-log(lsd_sd)-0.5*(lsd-lsd_mu)*(lsd-lsd_mu)/lsd_sd/lsd_sd;
  double lp_ldt;
  if(ldt_mu!=MISSING_VALUE && ldt_sd!=MISSING_VALUE)
    lp_ldt= -0.5*log(2.0*M_PI)-log(ldt_sd)-0.5*(ldt-ldt_mu)*(ldt-ldt_mu)/
      ldt_sd/ldt_sd;
  else
    {
      if(ldt<ldt1 || ldt>ldt2)
	return(-1e+200);
      lp_ldt=-log(ldt2-ldt1);
    }
  double lp_logobs=
    -0.5*log(2.0*M_PI)-log(logobs_sd)-
    0.5*(logobs-logobs_mu)*(logobs-logobs_mu)/logobs_sd/logobs_sd;
  
  double lp=lp_mu+lp_lsd+lp_ldt+lp_logobs;
  
  return lp;
}


// System equaltion: y(t_k)=x(t_k)+e_k, where e_k=observational noise
// Observational equation:
//    x(t_k)=exp(-(t_k-t_(k-1))/dt)*x(t_(k-1))+sigma*noise


double **Hk_OU(int , double , double *, double **)
{
  double **H=make_matrix(1,1);
  H[0][0]=1.0;
  return H;
}

double OU_corrtime=MISSING_VALUE;
double **Fk_OU(int, double, double timediff, double *, double **)
{
  double autocorr=exp(-timediff/OU_corrtime);
  double **F=make_matrix(1,1);
  F[0][0]=autocorr;
  return F;
}

double OU_sigma=MISSING_VALUE;
double **Qk_OU(int, double, double timediff, double *, double **)
{
  double autocorr=exp(-timediff/OU_corrtime);
  
  double **Q=make_matrix(1,1);
  Q[0][0]=(1.0-autocorr*autocorr)*OU_sigma*OU_sigma;
  return Q;
}

double OU_obs=MISSING_VALUE;
double **Rk_OU(int, double, double *, double **)
{
  double **R=make_matrix(1,1);
  R[0][0]=OU_obs*OU_obs;
  return R;
}

double OU_mu=MISSING_VALUE;
double *uk_OU(int, double, double timediff, double *, double **)
{
  double autocorr=exp(-timediff/OU_corrtime);
  double *u=new double[1];
  u[0]=(1.0-autocorr)*OU_mu;
  return u;
}


double ou_loglik(double  **data, 
		 int /* numrows */, 
		 int numcolumns,
		 int /* numparams */, 
		 double *params)
{
  double *t=data[0];
  double *y=data[1];
  int i,len=numcolumns;
  
  OU_mu=params[0];
  OU_sigma=exp(params[1]);
  OU_corrtime=exp(params[2]);
  OU_obs=exp(params[3]);
  
  /*
  double init_mu=OU_mu;
  double **init_var=make_matrix(1,1);
  init_var[0][0]=initvar;
  
  double **meas=make_matrix(len, 1);
  for(i=0;i<len;i++)
    meas[i][0]=y[i];
  
  kalman_filter_result *res1=kalman_filter(len, 1, 1, t,
					   meas, &init_mu, init_var,
					   Hk_OU, Fk_OU, Qk_OU, Rk_OU, uk_OU);
  doubledelete(init_var,1);
  doubledelete(meas,len);

  double ret=res1->loglik;
  delete res1;
  */
  
  double ret=-0.5*log(2.0*M_PI)-0.5*log(initvar)-
    0.5*(y[0]-OU_mu)*(y[0]-OU_mu)/initvar;
  for(i=1;i<len;i++)
    {
      if(t[i]<=t[i-1])
	{
	  std::cerr << "i=" << i << " t[i]=" << t[i] <<
	    " <= t[i-1]=" << t[i-1] << std::endl;
	  exit(0);
	}
      
      double a=exp(-(t[i]-t[i-1])/OU_corrtime);
      double proc_var=(1.0-a*a)*OU_sigma*OU_sigma;
      double totvar=proc_var+OU_obs*OU_obs;
      double y_prev=a*y[i-1]+(1.0-a)*OU_mu;
      
      ret += -0.5*log(2.0*M_PI)-0.5*log(totvar) -
	0.5*(y[i]-y_prev)*(y[i]-y_prev)/totvar;
    }

  return ret;
}

// Calculates the aposterior probabilites of each 
// model (homogen and inhomogen). 
void bayesian_homogeneity_with_ou::
calculate_aposteriori_with_ou(bool dodebug)
{
  int i,j,k;
  double a=sigma_a, b=sigma_b;
  double *prior=new double[separate_len+2];
  double **twostep_prior=NULL;
  double **twostep_likelihood=NULL;
  if(separate_len>2)
    {
      twostep_prior=new double*[separate_len-2];
      twostep_likelihood=new double*[separate_len-2];
    }
  double scale=0.0, loglik;
  double **Xlin=new double*[2], **Xquad=new double*[3];
  double *mlin=new double[2], *mquad=new double[3];
  double **vlin=new double*[2], **vquad=new double*[3];
  double **X=new double*[2], *Xh=new double[len];
  double **twostep_X=new double*[3];
  double mh=mu_a, *vh=new double[1];
  double **v=new double*[2], *m=new double[2];
  double **twostep_v=new double*[3], *twostep_m=new double[3];
  double *likelihood=new double[separate_len+2]; 
  bool ou_possible=true;

  /*
  for(i=1;i<len && ou_possible;i++)
    if(x[i]<=x[i-1])
      {
	ou_possible=false;
	std::cerr << "Autocorrelative model not possible, since covariate " << i <<
	  "=" << x[i-1] << " <= covariate " << i+1 << "=" << x[i] << 
	  "!" << std::endl;
	prior_ou=0.0;
      }
  */
  
  for(i=0;i<separate_len-2;i++)
    {
      twostep_likelihood[i]=new double[separate_len-2];
      twostep_prior[i]=new double[separate_len-2];
      for(j=0;j<separate_len-2;j++)
	{
	  twostep_likelihood[i][j]=0.0;
	  twostep_prior[i][j]=0.0;
	}
    }

  meanx=find_statistics(x, len, MEAN);

  Xlin[0]=new double[len];
  Xlin[1]=new double[len];
  mlin[0]=mu_a;
  mlin[1]=0.0;
  vlin[0]=new double[2];
  vlin[1]=new double[2];
  vlin[0][0]=sd_a*sd_a/(b/a);
  vlin[1][1]=sd_b*sd_b/(b/a);
  vlin[0][1]=vlin[1][0]=0;

  Xquad[0]=new double[len];
  Xquad[1]=new double[len];
  Xquad[2]=new double[len];
  mquad[0]=mu_a;
  mquad[1]=0.0;
  mquad[2]=0.0;
  vquad[0]=new double[3];
  vquad[1]=new double[3];
  vquad[2]=new double[3];
  vquad[0][0]=sd_a*sd_a/(b/a);
  vquad[1][1]=sd_b*sd_b/(b/a);
  vquad[2][2]=sd_b*sd_b*sd_b*sd_b/(b/a);
  vquad[0][1]=vquad[1][0]=0;
  vquad[0][2]=vquad[2][0]=0;
  vquad[2][1]=vquad[1][2]=0;

  X[0]=new double[len];
  X[1]=new double[len];
  v[0]=new double[2];
  v[1]=new double[2];

  vh[0]=sd_a*sd_a/(b/a);
  v[0][0]=v[1][1]=vh[0];
  v[0][1]=v[1][0]=0.0;
  m[0]=m[1]=mu_a;

  twostep_X[0]=new double[len];
  twostep_X[1]=new double[len];
  twostep_X[2]=new double[len];
  twostep_v[0]=new double[3];
  twostep_v[1]=new double[3];
  twostep_v[2]=new double[3];

  twostep_v[0][0]=twostep_v[1][1]=twostep_v[2][2]=vh[0];
  twostep_v[0][1]=twostep_v[1][0]=twostep_v[0][2]=twostep_v[2][0]=
    twostep_v[1][2]=twostep_v[2][1]=0.0;
  twostep_m[0]=twostep_m[1]=twostep_m[2]=mu_a;

  double totpriorstep=0.0;
  prior[0]=prior_homogeneity;
  for(i=0;i<len;i++)
    Xh[i]=1.0;

  for(i=1;i<separate_len;i++)
    {
      prior[i]=double(i)*double(separate_len-i);
      totpriorstep+=prior[i];
    }
  
  for(i=0;i<len;i++)
    {
      Xlin[0][i]=1.0;
      Xlin[1][i]=x[i]-meanx;
      Xquad[0][i]=1.0;
      Xquad[1][i]=x[i]-meanx;
      Xquad[2][i]=(x[i]-meanx)*(x[i]-meanx);
    }

  for(i=1;i<separate_len;i++)
    prior[i]*=(1.0-prior_homogeneity-prior_linear-prior_quadratic-
	       prior_twostep-prior_ou)/
      totpriorstep;

  double tot_twostep_prior=0.0;
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      {
	twostep_prior[i][j]=double(i+1)*
	  double(j+1)*double(separate_len-i-j);
	
	tot_twostep_prior += twostep_prior[i][j];
      }
    
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      twostep_prior[i][j] *= prior_twostep/tot_twostep_prior;
  
  prior[separate_len]=prior_linear;
  prior[separate_len+1]=prior_quadratic;
  
  regresult=new bayesian_regression*[separate_len+2];
  regresult[0]=
    get_bayesian_regression(&Xh, 1, !logarithmic ? y : logy, len, 
			    &mh, &vh, a, b);
  loglik=regresult[0]->probability_density_of_data(true);
  //std::cout << "Homogeneous loglik=" << loglik << std::endl;

  for(i=1;i<separate_len;i++)
    {
      for(j=0;j<len;j++)
	{
	  if(x[j]<separate_x[i])
	    {
	      X[0][j]=1.0;
	      X[1][j]=0.0;
	    }
	  else
	    {
	      X[0][j]=0.0;
	      X[1][j]=1.0;
	    }
	}
      
      regresult[i]=get_bayesian_regression(X, 2, !logarithmic ? y : logy, 
					   len, m, v, a, b);
    }
  
  twostep_regresult=NULL;
  if(separate_len>2)
    {
      twostep_regresult=new bayesian_regression**[separate_len-2];
      for(i=1;i<separate_len-1;i++)
	{
	  twostep_regresult[i-1]=new bayesian_regression*[separate_len-2];
	  
	  for(k=0;k<separate_len-2;k++)
	    twostep_regresult[i-1][k]=NULL;
	  
	  for(k=i+1;k<separate_len;k++)
	    {
	      for(j=0;j<len;j++)
		{
		  if(x[j]<separate_x[i])
		    {
		      twostep_X[0][j]=1.0;
		      twostep_X[1][j]=0.0;
		      twostep_X[2][j]=0.0;
		    }
		  else if(x[j]<separate_x[k])
		    {
		      twostep_X[0][j]=0.0;
		      twostep_X[1][j]=1.0;
		      twostep_X[2][j]=0.0;
		    }
		  else
		    {
		      twostep_X[0][j]=0.0;
		      twostep_X[1][j]=0.0;
		      twostep_X[2][j]=1.0;
		    }
		}
	      
	      twostep_regresult[i-1][k-i-1]=
		get_bayesian_regression(twostep_X, 3, !logarithmic ? y : logy, 
					len,twostep_m, twostep_v, a, b);
	    }
	}
    }
  
  // perform linear regression analysis:
  regresult[separate_len]=get_bayesian_regression(Xlin, 2, !logarithmic ?
						  y : logy, len,
						  mlin, vlin, a, b);
  
  // perform quadratic regression analysis:
  regresult[separate_len+1]=get_bayesian_regression(Xquad, 3, !logarithmic ?
						    y : logy, len,
						    mquad, vquad, a, b);
  
  if(ou_possible)
    {
      // Sort instances
      double_2d *sorted=new double_2d[len];
      for(i=0;i<len;i++)
	{
	  sorted[i].x=x[i];
	  if(!logarithmic)
	    sorted[i].y=y[i];
	  else
	    sorted[i].y=logy[i];
	}
      qsort(sorted, size_t(len), sizeof(double_2d), compare_double_2d_x);

      // perform OU analysis:
      double **data=make_matrix(2,len);
      for(i=0;i<len;i++)
	{
	  data[0][i]=sorted[i].x;
	  if(i>0 && data[0][i]-data[0][i-1]<0.0000001)
	    data[0][i]=data[0][i-1]+0.0000001;
	  
	  data[1][i]=sorted[i].y;
	}
      double hyper[]={mu_mu, mu_sd, logsd_mu, logsd_sd, logdt_mu, logdt_sd,
		      logdt_lower,logdt_upper,logobs_mu,logobs_sd};
      char *parnames[]={"mu", "lsd", "ldt","logobs"};
      double T[]={1.0,1.5,2.0,2.5,3.0};
      if(ou_mcmc_samples && num_mcmc>0)
	doubledelete(ou_mcmc_samples, num_mcmc);
      num_mcmc=1000;
      ou_mcmc_samples=mcmc(num_mcmc, 10000, 10, 5, data, 2, len, 4, parnames,
			   T, 0.1, 10, hyper, 
			   ou_init, ou_logprior, ou_loglik, true);
      
      double loglik_ou=log_model_likelihood_multinormal(100000,  
							ou_mcmc_samples,
							4, num_mcmc, data, 
							2, len,
							10, hyper, 
							ou_logprior, 
							ou_loglik);
      //std::cout << "OU loglik=" << loglik_ou << std::endl;
      ou_model_lik=exp(loglik_ou - loglik);
      doubledelete(data,2);
      delete [] sorted;
    } 
  
  // Calculate posterior probabilities:
  for(i=0;i<separate_len+2;i++)
    likelihood[i]=regresult[i]->probability_density_of_data(false, 
							    loglik);
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      twostep_likelihood[i][j]=
	twostep_regresult[i][j]->probability_density_of_data(false, 
							     loglik);

  for(i=0;i<separate_len+2;i++)
    scale+=prior[i]*likelihood[i];
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      scale+=twostep_prior[i][j]*twostep_likelihood[i][j];
  if(ou_possible)
    scale+=prior_ou*ou_model_lik;
  
  for(i=0;i<separate_len+2;i++)
    post[i]=prior[i]*likelihood[i]/scale;
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      twostep_post[i][j]=twostep_prior[i][j]*twostep_likelihood[i][j]/
	scale;
  if(ou_possible)
    post_ou=prior_ou*ou_model_lik/scale;
  else
    post_ou=0.0;

  total_onestep=0.0;
  for(i=1;i<separate_len;i++)
    total_onestep+=post[i];
  
  double maxprob=0.0, maxprob2=0.0;
  for(i=1;i<separate_len;i++)
    if(post[i]>maxprob)
      {
	maxprob=post[i];
	maxindex=i;
      }

  maxindex1=1;
  maxindex2=2;
  total_twostep=0.0;
  for(i=0;i<separate_len-2;i++)
    for(j=0;j<separate_len-i-2;j++)
      {
	total_twostep+=twostep_post[i][j];
	if(twostep_post[i][j]>maxprob2)
	  {
	    maxprob2=twostep_post[i][j];
	    maxindex1=i+1;
	    maxindex2=i+j+2;
	  }
      }
  
  if(dodebug)
    show_priors();
  
  
  if(ou_mu)
    delete [] ou_mu;
  ou_mu=NULL;
  if(ou_lsd)
    delete [] ou_lsd;
  ou_lsd=NULL;
  if(ou_ldt)
    delete [] ou_ldt;
  ou_ldt=NULL;
  if(ou_possible)
    {
      ou_mu=new double[num_mcmc];
      ou_lsd=new double[num_mcmc];
      ou_ldt=new double[num_mcmc];
      ou_logobs=new double[num_mcmc];
      for(i=0;i<num_mcmc;i++)
	{
	  ou_mu[i]=ou_mcmc_samples[i][0];
	  ou_lsd[i]=ou_mcmc_samples[i][1];
	  ou_ldt[i]=ou_mcmc_samples[i][2];
	  ou_logobs[i]=ou_mcmc_samples[i][3];
	}
    
      mean_ou_mu=find_statistics(ou_mu, num_mcmc, MEAN);
      mean_ou_lsd=find_statistics(ou_lsd, num_mcmc, MEAN);
      mean_ou_ldt=find_statistics(ou_ldt, num_mcmc, MEAN);
      mean_ou_logobs=find_statistics(ou_logobs, num_mcmc, MEAN);
      //std::cout << mean_ou_ldt << " " << logdt_mu << " " << logdt_sd << 
      //(mean_ou_ldt-logdt_mu)/logdt_sd << " " << logdt_lower << 
      //" " << logdt_upper << std::endl;
    }
  else
    mean_ou_mu=mean_ou_lsd=mean_ou_ldt=mean_ou_logobs=MISSING_VALUE;
  
  // cleanup
  delete [] prior;
  doubledelete(twostep_prior,separate_len-2);
  doubledelete(Xlin,2);
  doubledelete(Xquad,3);
  delete [] mlin;
  delete [] mquad;
  doubledelete(vlin,2);
  doubledelete(vquad,3);
  doubledelete(X,2);
  delete [] Xh;
  doubledelete(twostep_X,3);
  delete [] vh;
  doubledelete(v,2);
  delete [] m;
  doubledelete(twostep_v,3);
  delete [] twostep_m;
  delete [] likelihood;
  doubledelete(twostep_likelihood,separate_len-2);

  calculated=true;
}


// methods for retrieving info about the quadratic model;
double bayesian_homogeneity_with_ou::ou_probability(void)
{
  return post_ou;
}

double bayesian_homogeneity_with_ou::ou_mean_stationary_standarddev(void)
{
  return exp(mean_ou_lsd);
}

double bayesian_homogeneity_with_ou::ou_mean_obs_sd(void)
{
  return exp(mean_ou_logobs);
}

double bayesian_homogeneity_with_ou::ou_mean_corrtime(void)
{
  return exp(mean_ou_ldt);
}

double bayesian_homogeneity_with_ou::ou_mean_mu(void)
{
  return mean_ou_mu;
}
  
BAYESIAN_TIMESERIE_MODEL bayesian_homogeneity_with_ou::
get_most_probable_model_with_ou(void)
{
  if(post[0]>=total_onestep && post[0]>=total_twostep &&
     post[0]>=post[separate_len] && post[0]>=post[separate_len+1] && 
     post[0]>post_ou)
    return BAYESIAN_HOMOGENEITY;
  else if(post[separate_len]>=post[0] && post[separate_len]>=total_onestep && 
	  post[separate_len]>=total_twostep && 
	  post[separate_len]>=post[separate_len+1] && 
	  post[separate_len]>post_ou)
    return BAYESIAN_LINEAR;
  else if(post[separate_len+1]>=post[0] && 
	  post[separate_len+1]>=total_onestep && 
	  post[separate_len+1]>=total_twostep && 
	  post[separate_len+1]>=post[separate_len] && 
	  post[separate_len+1]>post_ou)
    return BAYESIAN_QUADRATIC;
  else if(total_onestep>=post[0] && total_onestep>=total_twostep &&
	  total_onestep>=post[separate_len] && 
	  total_onestep>=post[separate_len+1] && 
	  total_onestep>post_ou)
    return BAYESIAN_ONESTEP;
  else if(post_ou>=post[0] && post_ou>total_onestep && 
	  post_ou>=total_twostep && post_ou>=post[separate_len] && 
	  post_ou>=post[separate_len+1])
    return BAYESIAN_OU;
  else
    return BAYESIAN_TWOSTEP;
}


BAYESIAN_TIMESERIE_MODEL bayesian_homogeneity_with_ou::
get_most_probable_model_with_ou_without_homogeneity(void)
{
  if(post[separate_len]>=total_onestep && 
     post[separate_len]>=total_twostep && 
     post[separate_len]>=post[separate_len+1] && 
     post[separate_len]>post_ou)
    return BAYESIAN_LINEAR;
  else if(post[separate_len+1]>=total_onestep && 
	  post[separate_len+1]>=total_twostep && 
	  post[separate_len+1]>=post[separate_len] && 
	  post[separate_len+1]>post_ou)
    return BAYESIAN_QUADRATIC;
  else if(total_onestep>=total_twostep &&
	  total_onestep>=post[separate_len] && 
	  total_onestep>=post[separate_len+1] && 
	  total_onestep>post_ou)
    return BAYESIAN_ONESTEP;
  else if(post_ou>total_onestep && 
	  post_ou>=total_twostep && post_ou>=post[separate_len] && 
	  post_ou>=post[separate_len+1])
    return BAYESIAN_OU;
  else
    return BAYESIAN_TWOSTEP;
}

double bayesian_homogeneity_with_ou::ou_predict(double pred_covariate,
						double previous_covariate, 
						double previous_response)
{
  double mu=mean_ou_mu;
  double dt=exp(mean_ou_ldt);
  double t=pred_covariate;    
  double t0=previous_covariate;
  double curr_a=exp(-(t-t0)/dt);
  double y0=previous_response;
  
  double y_pred=curr_a*y0+(1.0-curr_a)*mu; 

  if(!logarithmic)
    return y_pred;
  else
    return exp(y_pred);
}

// predict on the basis of the data, returns 4 arrays, 
// combined predictor set (0), mean (1), lower (2) and upper (3)
// for the given predictor set plus the data:
double **bayesian_homogeneity_with_ou::ou_predict(double *predictor_set, 
						  int num_predictors,
						  int *length_out)
{
  int i,j,numtot=len;
  double_2d *data=new double_2d[len+num_predictors];
  for(i=0;i<len;i++)
    {
      data[i].x=x[i];
      if(logarithmic)
	data[i].y=logy[i];
      else
	data[i].y=y[i];
    }
  
  OU_mu=mean_ou_mu;
  OU_sigma=exp(mean_ou_lsd);
  OU_corrtime=exp(mean_ou_ldt);
  OU_obs=exp(mean_ou_logobs);

  for(i=0;i<num_predictors;i++)
    {
      bool found=false;
      for(j=0;j<len;j++)
	if(ABSVAL((x[j]-predictor_set[i]))<0.000001)
	  found=true;
      
      if(!found)
	{
	  data[numtot].x=predictor_set[i];
	  data[numtot].y=MISSING_VALUE;
	  numtot++;
	}
    }

  qsort(data, size_t(numtot), sizeof(double_2d), compare_double_2d_x);
  double *t_new=new double[numtot];
  double *y_new=new double[numtot];
  for(i=0;i<numtot;i++)
    {
      t_new[i]=data[i].x;
      y_new[i]=data[i].y;
    }
  delete [] data;
  
  double init_mu=OU_mu;
  double **init_var=make_matrix(1,1);
  init_var[0][0]=initvar;

  double **meas=make_matrix(numtot,1);
  for(i=0;i<numtot;i++)
    meas[i][0]=y_new[i];

  kalman_filter_result *res1=kalman_filter(numtot, 1, 1, t_new,
					   meas, &init_mu, init_var,
					   Hk_OU, Fk_OU, Qk_OU, Rk_OU, uk_OU);
  doubledelete(init_var,1);
  doubledelete(meas,numtot);
  
  kalman_smoother_result *res2=kalman_smoother(res1, Fk_OU, uk_OU);

  double **ret=make_matrix(4, numtot);
  for(i=0;i<numtot;i++)
    {
      ret[0][i]=t_new[i];
      ret[1][i]=res2->x_k_allmeas[i][0];
      ret[2][i]=res2->x_k_allmeas[i][0]-1.96*sqrt(res2->P_k_allmeas[i][0][0]);
      ret[3][i]=res2->x_k_allmeas[i][0]+1.96*sqrt(res2->P_k_allmeas[i][0][0]);

      if(logarithmic)
	for(j=1;j<=3;j++)
	  ret[j][i]=exp(ret[j][i]);
    }
  
  delete res1;
  delete res2;
  delete [] t_new;
  delete [] y_new;

  if(length_out)
    *length_out=numtot;
		
  return ret;
}


void bayesian_homogeneity_with_ou::show_priors(void)
 // for debug purposes
{
  printf("Logaritmisk=%s\n", logarithmic ? "Ja" : "Nei");
  printf("\n"); 
  printf("A' priori modellsannsynligheter:\n");
  printf("Homogen    : %7.3f\n", prior_homogeneity);
  printf("Line�r     : %7.3f\n", prior_linear);
  printf("Kvadratisk : %7.3f\n", prior_quadratic);
  printf("Ettsteg    : %7.3f\n", 1.0-prior_homogeneity-prior_linear-
	 prior_quadratic-prior_twostep-prior_ou);
  printf("Tosteg     : %7.3f\n", prior_twostep);
  printf("OU         : %7.3f\n", prior_ou);
  printf("\n");
  printf("Lin�re parametre:\n");
  printf("a~N(%7.3f, %7.3f)\n", mu_a, sd_a);
  printf("b~N(      0, %7.3f)\n", sd_b);
  printf("sigma^2~IG(%7.3f,%7.3f)\n", sigma_a, sigma_b);
  printf("\n");
  printf("OU-parametre:\n");
  printf("mu~N(%7.3f, %7.3f)\n", mu_mu, mu_sd);
  printf("sd~logN(%7.3f, %7.3f)\n", logsd_mu, logsd_sd);
  printf("dt~logN(%7.3f, %7.3f)\n", logdt_mu, logdt_sd);
  printf("   95%% cred.int. (%7.3f, %7.3f)\n", logdt_lower, logdt_upper);
  printf("obs~logN(%7.3f, %7.3f)\n", logobs_mu, logobs_sd);
}

