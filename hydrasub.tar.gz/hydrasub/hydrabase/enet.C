/*
 * $Id: enet.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/enet.C $
 */

#include <hydrasub/hydrabase/enet.H>

evolvenet_creature::evolvenet_creature(evolvenet_creature *prev) :
  double_linked_list((double_linked_list *) prev, NULL)
{
  start=0;
  age=0.0;
  index=findex=mindex=0;
  father=mother=NULL;
  imported=0.0;
  total_instructions = 0;
}

evolvenet_creature::evolvenet_creature(evolvenet_creature *prev, 
				       evolvenet_creature *orig) :
  double_linked_list((double_linked_list *) prev, NULL)
{
  start    = orig->start;
  t0       = orig->t0;
  age      = orig->age;
  lastpayoff = orig->lastpayoff;
  maxpayoff  = orig->maxpayoff;
  meanpayoff = orig->meanpayoff;
  numcromo = orig->numcromo;
  point    = orig->point;
  point1   = orig->point1;
  point2   = orig->point2;
  line     = orig->line;
  line1    = orig->line1;
  line2    = orig->line2;
  flip     = orig->flip;
  negate   = orig->negate;
  linelen  = orig->linelen;
  globaln  = orig->globaln;
  repair   = orig->repair;
  firstrepair = orig->firstrepair;
  maxgen   = orig->maxgen;
  gender   = orig->gender;
  numnodes = orig->numnodes;
  numthreads  = orig->numthreads;
  complexity  = orig->complexity;
  numinternal = orig->numinternal;
  numchildren = orig->numchildren; 
 
  variablemutaterate = orig->variablemutaterate;
  variablemutatesize = orig->variablemutatesize;

  th_r = orig->th_r; 
  th_m = orig->th_m; 
  th_a = orig->th_a; 
  th_f0 = orig->th_f0; 
  th_g = orig->th_g; 
  th_d = orig->th_d;
  int_r = orig->int_r;
  int_m = orig->int_m;
  int_x0 = orig->int_x0;
  int_l = orig->int_l;
  int_gam = orig->int_gam;
  int_d = orig->int_d;
  int_g = orig->int_g;
  int_reload = orig->int_reload;
  int_fatigue_level = orig->int_fatigue_level;
  int_fatigue_decrease = orig->int_fatigue_decrease;
  out_r = orig->out_r;
  out_m = orig->out_m;
  out_x0 = orig->out_x0;
  out_l = orig->out_l;
  out_gam = orig->out_gam;
  out_d = orig->out_d;
  out_g = orig->out_g;
  out_reload = orig->out_reload;
  out_fatigue_level = orig->out_fatigue_level;
  out_fatigue_decrease = orig->out_fatigue_decrease;
  outL  = orig->outL;
  outX0 = orig->outX0;

  num_ACTIVATE = orig->num_ACTIVATE;
  num_DEACTIVATE = orig->num_DEACTIVATE;
  num_ACTIVATEL = orig->num_ACTIVATEL;
  num_DEACTIVATEL = orig->num_DEACTIVATEL;
  num_CHN = orig->num_CHN; 
  num_CHNPROS = orig->num_CHNPROS;
  num_CHNODE = orig->num_CHNODE; 
  num_CHSTTHREAD = orig->num_CHSTTHREAD; 
  num_CHALLTH = orig->num_CHALLTH; 
  num_CHTHREAD = orig->num_CHTHREAD; 
  num_STOP = orig->num_STOP; 
  num_REM = orig->num_REM; 
  num_REM1 = orig->num_REM1; 
  num_REM2 = orig->num_REM2;
  num_IF1 = orig->num_IF1; 
  num_IF2 = orig->num_IF2; 
  num_IF3 = orig->num_IF3; 
  num_IF4 = orig->num_IF4; 
  num_INC1 = orig->num_INC1; 
  num_INC2 = orig->num_INC2; 
  num_DEC1 = orig->num_DEC1; 
  num_DEC2 = orig->num_DEC2;
  num_HALF1 = orig->num_HALF1; 
  num_HALF2 = orig->num_HALF2; 
  num_DOUBLE1 = orig->num_DOUBLE1; 
  num_DOUBLE2 = orig->num_DOUBLE2; 
  num_NEG1 = orig->num_NEG1; 
  num_NEG2 = orig->num_NEG2;
  num_CHANGEVAR1 = orig->num_CHANGEVAR1;
  num_CHANGEVAR2 = orig->num_CHANGEVAR2;
  num_CHANGEVAR3 = orig->num_CHANGEVAR3;
  num_CHANGEVAR4 = orig->num_CHANGEVAR4;
  num_CHANGEVAR5 = orig->num_CHANGEVAR5;
  total_instructions = orig->total_instructions;

  index=orig->index;
  findex=orig->findex;
  mindex=orig->mindex;
  imported=orig->imported;

  father=mother=NULL;
}

evolvenet_creature::~evolvenet_creature()
{
  evolvenet_creature *next = (evolvenet_creature *) getnext();

  removefromlist();

  if(next)
    delete next;
}
