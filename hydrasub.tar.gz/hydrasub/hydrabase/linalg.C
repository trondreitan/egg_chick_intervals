/*
 * $Id: linalg.C 2611 2015-11-24 12:27:00Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/linalg.C $
 */

#include <hydrasub/hydrabase/linalg.H>


#ifdef GSL
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_complex_math.h>
#endif // GSL
#include <cmath>

using namespace std;



long int tensor::lengths_to_total_length(void)
{
  long int ret=1;

  for(long int i=0;i<dim;i++)
    ret*=len[i];

  return ret;
}

tensor::tensor() // makes a zero-tensor, i.e. scalar
{
  dim=0;
  totlen=1;
  len=NULL;
  status=TENSOR_OK;
  data=new double[1];
  data[0]=0.0;
}

tensor::tensor(const tensor &orig) // copy a tensor
{
  dim=totlen=0;
  len=NULL;
  data=NULL;
  *this=orig;
}

// general purpose constructor;
tensor::tensor(long int dimension, long int *lengths) 
{
  dim=dimension;
  len=new long int[dim];
  for(long int i=0;i<dim;i++)
    len[i]=lengths[i];

  initialize();
}

tensor::tensor(long int length) // makes a vector, fills it with zeros
{
  dim=1;
  len=new long int[1];
  len[0]=length;

  initialize();
}

tensor::tensor(long int rows, long int columns) 
  // makes a matrix, fills it with zeros 
{
  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;

  initialize();
}

tensor::tensor(long int len1, long int len2, long int len3) 
  // makes three-tensor
{
  dim=3;
  len=new long int[3];
  len[0]=len1;
  len[1]=len2;
  len[2]=len3;

  initialize();
}

tensor::tensor(char *input_file) 
  // reads from file
{
  dim=totlen=0;
  len=NULL;
  data=NULL;

  read_file(input_file);
}

void tensor::initialize(void)
{
  status=TENSOR_OK;

  if(dim==0)
    {
      len=NULL;
      totlen=1;
      data=new double[1];
      return;
    }

  totlen=lengths_to_total_length();
  data=new double[totlen];
  for(long int i=0;i<totlen;i++)
    data[i]=0.0;
}

tensor::~tensor()
{
  cleanup();
}

void tensor::cleanup(void)
{
  if(len)
    delete [] len;
  len=NULL;
  if(data)
    delete [] data;
  data=NULL;
  dim=totlen=0;
}

bool tensor::check_sizes(const tensor &t2)
{
  if(dim!=t2.dim)
    {
      status=TENSOR_SIZE_MISMATCH;
      return false;
    }
  
  if(data==NULL || t2.data==NULL)
    {
      status=TENSOR_ILL_DEFINED;
      return false;
    }

  for(long int i=0;i<dim;i++)
    if(len[i]!=t2.len[i])
      {
	status=TENSOR_SIZE_MISMATCH;
	return false;
      }

  return true;
}

TENSOR_ERROR_STATUS tensor::error(void)
{
  return status;
}

void tensor::set_status(TENSOR_ERROR_STATUS newstatus)
{
  status=newstatus;
}

tensor& tensor::operator= (const tensor &orig)
// sets one tensor to other
{
  long int i;

  cleanup();
  
  dim=orig.dim;
  totlen=orig.totlen;
  status=orig.status;

  len=new long int[dim];
  for(i=0;i<dim;i++)
    len[i]=orig.len[i];
  
  data=new double[totlen];
  for(i=0;i<totlen;i++)
    data[i]=orig.data[i];

  return *this;
}

tensor& tensor::operator= (const double &orig) // sets the contents of 
// a tensor to a constant (i.e. all elements=orig).
{
  for(long int i=0;i<totlen;i++)
    data[i]=orig;

  return *this;
}

tensor& tensor::operator= (const float &orig) // sets the contents of 
// a tensor to a constant (i.e. all elements=orig).
{
  for(long int i=0;i<totlen;i++)
    data[i]=(double) orig;

  return *this;
}

tensor& tensor::operator= (const int &orig) // sets the contents of 
// a tensor to a constant (i.e. all elements=orig).
{
  for(long int i=0;i<totlen;i++)
    data[i]=(double) orig;

  return *this;
}

tensor operator+ (const tensor &c1, const tensor &c2)
{
  tensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]+c2.data[i];

  return ret;
}

tensor operator+ (const tensor &c1, const double &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

tensor operator+ (const double &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

tensor operator+ (const tensor &c1, const float &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

tensor operator+ (const float &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}

tensor operator+ (const tensor &c1, const int &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

tensor operator+ (const int &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}

tensor operator- (const tensor &c1, const tensor &c2)
{
  tensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2.data[i];

  return ret;
}


tensor operator- (const tensor &c1, const double &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

tensor operator- (const double &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

tensor operator- (const tensor &c1, const float &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

tensor operator- (const float &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}

tensor operator- (const tensor &c1, const int &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

tensor operator- (const int &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}


tensor operator* (const tensor &c1, const double &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2;

  return ret;
}

tensor operator* (const double &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1*c2.data[i];

  return ret;
}

tensor operator* (const tensor &c1, const float &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*(double) c2;

  return ret;
}

tensor operator* (const float &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1*c2.data[i];

  return ret;
}

tensor operator* (const tensor &c1, const int &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*(double) c2;

  return ret;
}

tensor operator* (const int &c1, const tensor &c2)
{
  tensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1*c2.data[i];

  return ret;
}


tensor operator/ (const tensor &c1, const double &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2;

  return ret;
}

tensor operator/ (const tensor &c1, const float &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/(double) c2;

  return ret;
}

tensor operator/ (const tensor &c1, const int &c2)
{
  tensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/(double) c2;

  return ret;
}

void operator+= (tensor &c1,const tensor &c2)
{
  c1=c1+c2;
}

void operator+= (tensor &c1,const double &c2)
{
  c1=c1+c2;
}

void operator+= (tensor &c1,const float &c2)
{
  c1=c1+c2;
}

void operator+= (tensor &c1,const int &c2)
{
  c1=c1+c2;
}

void operator-= (tensor &c1,const tensor &c2)
{
  c1=c1-c2;
}

void operator-= (tensor &c1,const double &c2)
{
  c1=c1-c2;
}

void operator-= (tensor &c1,const float &c2)
{
  c1=c1-c2;
}

void operator-= (tensor &c1,const int &c2)
{
  c1=c1-c2;
}


void operator*= (tensor &c1,const double &c2)
{
  c1=c1*c2;
}

void operator*= (tensor &c1,const float &c2)
{
  c1=c1*c2;
}

void operator*= (tensor &c1,const int &c2)
{
  c1=c1*c2;
}

void operator/= (tensor &c1,const double &c2)
{
  c1=c1/c2;
}

void operator/= (tensor &c1,const float &c2)
{
  c1=c1/c2;
}

void operator/= (tensor &c1,const int &c2)
{
  c1=c1/c2;
}

// element by element multiplication
tensor operator| (const tensor &c1, const tensor &c2)
{
  tensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2.data[i];

  return ret;
}

tensor operator|= (tensor &c1, const tensor &c2)
{
  c1=c1|c2;

  return c1;
}

// element by element division
tensor operator% (const tensor &c1, const tensor &c2)
{
  tensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2.data[i];

  return ret;
}

tensor operator%= (tensor &c1, const tensor &c2)
{
  c1=c1%c2;

  return c1;
}

void tensor::transpotize(tensor &orig,
			 long int *indexes, long int depth, 
			 long int index1, long int index2)
{
  long int i;

  if(depth==dim)
    {
      long int *indexes2=new long int[dim];
      for(i=0;i<dim;i++)
	indexes2[i]=indexes[i];
      indexes2[index1]=indexes[index2];
      indexes2[index2]=indexes[index1];

      set_element(indexes2, orig(indexes));
    }
  else
    {
      for(i=0;i<orig.len[depth];i++)
	{
	  indexes[depth]=i;
	  transpotize(orig,indexes,depth+1,index1,index2); 
	}
    }
}

tensor tensor::transpose(long int index1, long int index2)
{
  long int i,  *indexes=new long int[dim];
  long int *newlen=new long int[dim];

  for(i=0;i<dim;i++)
    if(i!=index1 && i!=index2)
      newlen[i]=len[i];
  newlen[index1]=len[index2];
  newlen[index2]=len[index1];

  tensor ret(dim, newlen);

  ret.transpotize(*this, indexes, 0, index1, index2); 
  
  delete [] newlen;
  delete [] indexes;

  return ret;
}

// Returns an element. Remember that C 
// counts from 0!
double tensor::operator() (long int *position) 
{
  return get_element(position);
}

double tensor::operator() (void) // returns the first element 
{
  return as_double();
}

double tensor::get_element(long int *position) 
{
  long int abspos=0;
  
  for(long int i=0;i<dim;i++)
    {
      abspos*=len[i];
      abspos+=position[i];
    }

  if(abspos<totlen)
    return data[abspos];
  else
    return MISSING_VALUE;
}

void tensor::set_element(long int *position, double newvalue)
{
  long int abspos=0;

  for(long int i=0;i<dim;i++)
    {
      abspos*=len[i];
      abspos+=position[i];
    }

  if(abspos<totlen)
    data[abspos]=newvalue;
} 

void tensor::set_element(long int *position, float newvalue)
{
  set_element(position, (double) newvalue);
}

void tensor::set_element(long int *position, int newvalue)
{
  set_element(position, (double) newvalue);
}


long int tensor::get_dimension(void)
{
  return dim;
}

long int tensor::get_length(long int index_number)
{
  if(index_number<0 || index_number>=dim)
    return (long int) MISSING_VALUE;
  else
    return len[index_number];
}

double tensor::as_double(void) // returns the first element
{
  if(data)
    return data[0];
  else
    return MISSING_VALUE;
}

void tensor::set_levi_cevita(void)
{
  for(long int i=0;i<dim;i++)
    if(len[i]!=dim)
      status=TENSOR_LEVI_CEVIATE_UNSUITABLE; // continue anyhow...

  long int *indexes=new long int[dim], depth=0;

  levi_cevitize(indexes,depth);
  delete [] indexes;
}

void tensor::levi_cevitize(long int *indexes, long int depth)
{
  long int i,j;

  if(depth==dim)
    {
      for(i=1;i<dim;i++)
	for(j=0;j<i;j++)
	  if(indexes[i]==indexes[j])
	    {
	      set_element(indexes, 0);
	      return;
	    }
      
      int elem=1;
      for(i=1;i<dim;i++)
	for(j=0;j<i;j++)
	  if(indexes[i]<indexes[j])
	    elem*=-1;
      set_element(indexes,elem);
    }
  else
    {
      for(i=0;i<len[depth];i++)
	{
	  indexes[depth]=i;
	  levi_cevitize(indexes,depth+1); 
	}
    }
}

// lengths (rows and columns) should be equal
void tensor::set_identity(void)
{
  for(long int i=1;i<dim;i++)
    if(len[i]!=len[i-1])
      status=TENSOR_INDENTITY_UNSUITABLE; // continue anyhow...

  long int *indexes=new long int[dim], depth=0;

  identitize(indexes,depth);
  delete [] indexes;
} 

void tensor::identitize(long int *indexes, long int depth)
{
  long int i;

  if(depth==dim)
    {
      int elem=1;
      for(i=1;i<dim && elem; i++)
	if(indexes[i]!=indexes[i-1])
	  elem=0;

      set_element(indexes,elem);
    }
  else
    {
      for(i=0;i<len[depth];i++)
	{
	  indexes[depth]=i;
	  identitize(indexes,depth+1); 
	}
    }
}


std::ostream& operator<<(std::ostream &out, tensor &c)
{
  long int *indexes=new long int[c.dim], depth=0;

  c.output(out, indexes, depth);
  delete [] indexes;

  return out;
}


void tensor::output(std::ostream &out, long int *indexes, long int depth)
{
  long int i;

  if(depth==dim)
    {
      double val=get_element(indexes);
      
      for(i=0;i<dim;i++)
	out << indexes[i] << (i<dim-1 ? " , " : " : ");
      out << val << std::endl;
    }
  else
    {
      for(i=0;i<len[depth];i++)
	{
	  indexes[depth]=i;
	  output(out,indexes,depth+1); 
	}
    }
}


void tensor::read_file(char *file_name)
{
  std::ifstream in;

  in.open(file_name, std::ios::in);

  if(in.fail())
    {
      set_status(TENSOR_COULDNT_READ_FILE);
      std::cerr << (WHAT("Klarte ikke � lese fil!",
		    "Couldn't read file!")) << std::endl;
      return;
    }

  read_stream(in);
  in.close();
}

void tensor::read_stream(std::istream &in)
{
  in >> *this;
}

std::istream& operator>>(std::istream &in, tensor &t)
{
  t.get_header(in);
  
  if(t.error()!=TENSOR_OK)
    return in;
  
  for(long int i=0;i<t.totlen;i++)
    {
      if(in.fail())
	{
	  t.status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return in;
	}
      in >> t.data[i];
      if(in.fail())
	{
	  t.status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return in;
	}
    }
  
  return in;
}

void tensor::get_header(std::istream &in)
{
  char line[10000];
  long int i, d=-1;

  cleanup();

  status=TENSOR_FILE_HEADER_NOT_FOUND;  
  dim=0;
  
  in.getline(line,9999);
  while(!in.fail() && status==TENSOR_FILE_HEADER_NOT_FOUND)
    {
      bool dim_set=false;

      if(!strncasecmp(line, "# dim:", 6))
	{
	  if(sscanf(line+6, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# dim :", 7))
	{
	  if(sscanf(line+7, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# dimension:", 12))
	{
	  if(sscanf(line+12, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# dimension :", 13))
	{
	  if(sscanf(line+13, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# length ", 9))
	{
	  long int index,l;

	  if(d<0)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }

	  if(sscanf(line+9, "%ld : %ld", &index, &l)<2)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  
	  if(index>d)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	   
	  len[index]=l;
	}
      else if(!strncasecmp(line, "# len ", 6))
	{
	  long int index,l;

	  if(d<0)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }

	  if(sscanf(line+6, "%ld : %ld", &index, &l)<2)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  
	  if(index>d)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	   
	  len[index]=l;
	}
      else if(stripspaces(line)[0]!='\0' &&
	      stripspaces(line)[0]!='#')
	return;
      
      if(dim_set)
	{
	  dim=d;
	  if(dim>0)
	    {
	      len=new long int[dim];
	      for(i=0;i<dim;i++)
		len[i]=0;
	    }
	  else
	    {
	      initialize();
	      status=TENSOR_OK;
	      return;
	    }
	}

      if(dim>0)
	{
	  bool complete=true;

	  for(i=0;i<dim && complete;i++)
	    if(len[i]==0)
	      complete=false;
	      
	  if(complete)
	    {
	      initialize();
	      status=TENSOR_OK;
	      return;
	    }
	}

      in.getline(line,9999);
    }  
}



// only one element made
vector::vector() : tensor()
{
  dim=1;
  len=new long int[1];
  totlen=len[0]=1;
  data=new double[1];
}
 
vector::vector(long int length) : tensor(1, &length)
{
}

vector::vector(double *content, long int length) : tensor(1, &length)
{
  for(long int i=0;i<length;i++)
    data[i]=content[i];
}

vector::vector(const vector &orig) : tensor((tensor&) orig)
{
}

vector::vector(char *input_file) : tensor()
{
  dim=1;
  len=new long int[1];
  totlen=len[0]=1;
  data=new double[1];

  fetch_file(input_file);
}

vector::~vector()
{
  cleanup();
}

// dot product:
double operator& (const vector &v1, const vector &v2)
{
  tensor t;
  
  t=v1|v2;

  if(t.error())
    return MISSING_VALUE;

  double ret=0;
  for(long int i=0;i<t.get_length(0);i++)
    ret+=t(&i);

  return ret;
}

vector operator* (const vector &v1, const vector &v2)
{
  vector ret;
  double val=v1&v2;

  ret.set_element(0, val);

  return ret;
}

vector operator* (Matrix &m, vector &v)
{
  if(m.Columns()!=v.size())
    {
      vector err;
      err.set_status(TENSOR_SIZE_MISMATCH);

      return err;
    }
  
  vector ret(m.Rows());
  long int i,j;

  for(i=0;i<m.Rows();i++)
    for(j=0;j<m.Columns();j++)
      ret.set_element(i, ret(i)+m(i,j)*v(j));
  
  return ret;
}

vector operator* (vector &v, Matrix &m)
{
  if(m.Rows()!=v.size())
    {
      vector err;
      err.set_status(TENSOR_SIZE_MISMATCH);

      return err;
    }
  
  vector ret(m.Columns());
  long int i,j;

  for(i=0;i<m.Columns();i++)
    for(j=0;j<m.Rows();j++)
      ret.set_element(i, ret(i)+m(j,i)*v(j));
  
  return ret;
}

vector vector::cross(const vector &v2)
{  
  vector ret(*this);

  if(len[0]!=3 || v2.len[0]!=3)
    {
      ret.status=TENSOR_SIZE_MISMATCH;
      return ret;
    }
  
  ret.data[0]=data[1]*v2.data[2]-data[2]*v2.data[1];
  ret.data[1]=data[2]*v2.data[0]-data[0]*v2.data[2];
  ret.data[2]=data[0]*v2.data[1]-data[1]*v2.data[0];
  
  return ret;
}

// PS: Among the tensor classes, 'vector' is the only one 
// where a file header isn't neccessary
std::istream& operator>>(std::istream &in, vector &v)
{
  v.fetch_input(in);

  return in;
}

void vector::fetch_file(char *file_name)
{
  std::ifstream in;

  in.open(file_name, std::ios::in);

  if(in.fail())
    {
      set_status(TENSOR_COULDNT_READ_FILE);
      std::cerr << (WHAT("Klarte ikke � lese fil!",
		    "Couldn't read file!")) << std::endl;
      return;
    }

  fetch_input(in);
  in.close();
}

void vector::fetch_input(std::istream &in)
{
  valuelist *head=NULL, *tail=NULL, *ptr;
  
  while(!in.fail())
    {
      double value;

      in >> value;

      if(!in.fail())
	{
	  tail=new valuelist(tail,NULL,value);
	  if(!head)
	    head=tail;
	}
    }
  
  if(!head)
    {
      set_status(TENSOR_ILL_DEFINED);
      return;
    }

  long int i=0;
  long int length=head->number_of_elements();

  cleanup();
  dim=1;
  len=new long int[1];
  len[0]=length;

  initialize();

  for(ptr=head; ptr; ptr=ptr->suc())
    data[i++]=ptr->getvalue();

  delete head;
}

void vector::fetch_input(std::istream &in, long int length)
{
  
  cleanup();
  dim=1;
  len=new long int[1];
  len[0]=length;

  initialize();

  for(long int i=0;i<totlen;i++)
    {
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
      in >> data[i];
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
    }
}

double get_vector_element(const vector &v, long int position)
{
  if(position<0 || position>v.totlen)
    return MISSING_VALUE;
  else
    return v.data[position];
}

double vector::get_element(long int position) const
{
  if(position<0 || position>totlen)
    return MISSING_VALUE;
  else
    return data[position];
}

double vector::operator() (long int position) const
{
  return get_element(position);
}


double vector::operator() (void) const
{
  if(data)
    return data[0];
  else
    return MISSING_VALUE;
}

double *vector::get_as_double_array(long int *array_length)
{
  if(array_length)
    *array_length=totlen;

  double *ret=new double[totlen];
  for(int i=0;i<totlen;i++)
    ret[i]=data[i];

  return ret;
}



vector operator+ (const vector &c1, const vector &c2)
{
  vector ret(*c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]+c2.data[i];

  return ret;
}


Matrix Matrix::transpose(void)
{
  Matrix ret(len[1], len[0]);

  for(long int i=0;i<len[0];i++)
    for(long int j=0;j<len[1];j++)
      ret.set_element(j,i, get_element(i,j));
    
  return ret;
}

double vector::length(void)
{
  return sqrt((*this)&(*this));
}

long int length(const vector &v)
{
  return v.len[0];
}

double vector::length_squared(void)
{
  return (*this)&(*this);
}

void vector::set_element(long int position, double newvalue)
{
  if(position<0 || position>totlen)
    return;
  data[position]=newvalue;
}

long int vector::size(void) const
{
  return len[0];
}

long int vector::number_of_elements(void)
{
  return len[0];
}

void vector::set_size(int new_size)
{
  cleanup();

  dim=1;
  len=new long int[1];
  totlen=len[0]=new_size;
  data=new double[new_size];
  for(int i=0;i<totlen;i++)
    data[i]=0.0;
}

Matrix::Matrix() : tensor() // makes a 1x1 matrix
{
  cleanup();

  dim=2;
  len=new long int[2];
  totlen=len[0]=len[1]=1;
  data=new double[1];
  data[0]=0.0;
}

Matrix::Matrix(long int rows, long int columns) : tensor()
{
  cleanup();

  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;

  initialize();
}

Matrix::Matrix(double **content, long int rows, long int columns) :
  tensor()
{
  cleanup();

  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;

  initialize();

  for(long int i=0;i<rows;i++)
    for(long int j=0;j<columns;j++)
      set_element(i,j, content[i][j]);
}

Matrix::Matrix(const Matrix &orig) : tensor((tensor&) orig) // Makes a copy
{
}


Matrix::Matrix(vector &orig, bool as_column_matrix) :
  tensor()
{
  cleanup();

  dim=2;
  len=new long int[2];
  len[0]=as_column_matrix ? orig.size() : 1; 
  len[1]=as_column_matrix ? 1 : orig.size();

  initialize();

  for(long int i=0;i<totlen;i++)
    data[i]=orig(i);
}

Matrix::Matrix(char *input_file) : tensor()
{
  dim=2;
  len=new long int[2];
  len[0]=len[1]=1; 

  initialize();

  fetch_file(input_file);
}

Matrix::~Matrix()
{
  cleanup();
}

Matrix operator+ (const Matrix &c1, const Matrix &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]+c2.data[i];

  return ret;
}

Matrix operator+ (const Matrix &c1, const vector &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  if(Rows(c1)!=length(c2))
    {
      ret.status=TENSOR_SIZE_MISMATCH;
      return ret;
    }

  for(long int i=0;i<Rows(c1);i++)
    for(long int j=0;j<Columns(c1);j++)
      ret.set_element(i, j, get_matrix_element(c1,i,j)+
		      get_vector_element(c2,i));

  return ret;
}

Matrix operator+ (const vector &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  if(Rows(c2)!=length(c1))
    {
      ret.status=TENSOR_SIZE_MISMATCH;
      return ret;
    }

  for(long int i=0;i<Rows(c2);i++)
    for(long int j=0;j<Columns(c2);j++)
      ret.set_element(i, j, get_matrix_element(c2,i,j)+
		      get_vector_element(c1,i));

  return ret;
}

Matrix operator+ (const Matrix &c1, const double &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

Matrix operator+ (const double &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

Matrix operator+ (const Matrix &c1, const float &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

Matrix operator+ (const float &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}

Matrix operator+ (const Matrix &c1, const int &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

Matrix operator+ (const int &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}

Matrix operator- (const Matrix &c1, const Matrix &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2.data[i];

  return ret;
}

Matrix operator- (const Matrix &c1, const vector &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  if(Columns(c1)!=length(c2))
    {
      ret.status=TENSOR_SIZE_MISMATCH;
      return ret;
    }

  for(long int i=0;i<Rows(c1);i++)
    for(long int j=0;j<Columns(c1);j++)
      ret.set_element(i, j, get_matrix_element(c1,i,j)-
		      get_vector_element(c2,j));

  return ret;
}

Matrix operator- (const vector &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  if(Columns(c2)!=length(c1))
    {
      ret.status=TENSOR_SIZE_MISMATCH;
      return ret;
    }

  for(long int i=0;i<Rows(c2);i++)
    for(long int j=0;j<Columns(c2);j++)
      ret.set_element(i, j, -get_matrix_element(c2,i,j)+
		      get_vector_element(c1,j));

  return ret;
}

Matrix operator- (const Matrix &c1, const double &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

Matrix operator- (const double &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

Matrix operator- (const Matrix &c1, const float &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

Matrix operator- (const float &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}

Matrix operator- (const Matrix &c1, const int &c2)
{
  Matrix ret(Rows(c1), Columns(c1));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-(double) c2;

  return ret;
}

Matrix operator- (const int &c1, const Matrix &c2)
{
  Matrix ret(Rows(c2), Columns(c2));

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=(double) c1-c2.data[i];

  return ret;
}


Matrix operator* (const Matrix &m1, const Matrix &m2)
{
#ifndef GSL
  std::cerr << "'inverse_matrix' not implemented. You need GSL!" << std::endl;
  return Matrix();
#else

  Matrix mat1, mat2;

  mat1=m1;
  mat2=m2;

  Matrix err;
  err.set_status(TENSOR_SIZE_MISMATCH);
  if(Columns(mat1)!=Rows(mat2))
    return err;

  int r1=Rows(mat1), c1=Columns(mat1),
    r2=Rows(mat2), c2=Columns(mat2);

  long int k,l;
  double **ret=new double*[r1];

  // make the return matrix;
  for(k=0;k<r1;k++)
    ret[k]=new double[c2];

  // make GSL matrixes;
  gsl_matrix *matrix1=gsl_matrix_alloc(r1,c1);
  gsl_matrix *matrix2=gsl_matrix_alloc(r2,c2);
  
  // Set the first GSL matrix;
  for(k=0;k<r1;k++)
    for(l=0;l<c1;l++)
      gsl_matrix_set(matrix1, k, l, mat1.get_element(k,l));

  // Set the second GSL matrix;
  for(k=0;k<r2;k++)
    for(l=0;l<c2;l++)
      gsl_matrix_set(matrix2, k, l, mat2.get_element(k,l));
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_matrix *matrix3=gsl_matrix_alloc(r1,c2);
  for(k=0;k<r1;k++)
    for(l=0;l<c2;l++)
      gsl_matrix_set(matrix3, k, l, 0.0);

  if(gsl_blas_dgemm(CblasNoTrans,CblasNoTrans, 1.0,matrix1, matrix2, 0.0,
		    matrix3))
    return err;
  
  // fetch values from the third GSL matrix;
  for(k=0;k<r1;k++)
    for(l=0;l<c2;l++)
      ret[k][l]=gsl_matrix_get(matrix3, k, l);
  
  // cleanup;
  gsl_matrix_free(matrix1);
  gsl_matrix_free(matrix2);
  gsl_matrix_free(matrix3);

  Matrix r(ret, r1, c2);
  doubledelete(ret, r1);

  return r; // return the inverted matrix
#endif // GSL

/*
  Matrix mat1, mat2;

  mat1=m1;
  mat2=m2;

  Matrix ret1, ret2(Rows(mat1), Columns(mat2));
  long int i,j,k;

  ret1.set_status(TENSOR_SIZE_MISMATCH);
  if(Columns(mat1)!=Rows(mat2))
    return ret1;
  
  for(i=0;i<Rows(mat1);i++)
    for(j=0;j<Columns(mat2);j++)
      for(k=0;k<Columns(mat1);k++)
	ret2.set_element(i,j, ret2.get_element(i,j)+
			 get_element(mat1,i,k)*get_element(mat2,k,j));

			 return ret2;  */
}

Matrix operator/ (const Matrix &m1, const Matrix &m2)
{
  Matrix m3,m4;

  m3=inverse(m2);
  m4=m1*m3;

  return m4;
}

Matrix Matrix::inverse(void)
{
#ifndef GSL
  std::cerr << "'inverse_matrix' not implemented. You need GSL!" << std::endl;
  return Matrix();
#else
  Matrix err;
  err.set_status(TENSOR_SIZE_MISMATCH);
  if(len[0]!=len[1])
    return err;

  long int k,l;
  int sign=1;
  double **inverted=new double*[len[0]];

  // make the return matrix;
  for(k=0;k<len[0];k++)
    inverted[k]=new double[len[1]];

  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(len[0],len[1]);
  gsl_matrix *matrix2=gsl_matrix_alloc(len[0], len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<len[0];k++)
    for(l=0;l<len[1];l++)
      gsl_matrix_set(matrix, k, l,  get_element(k,l));
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_LU_decomp(matrix, perm, &sign);
  gsl_linalg_LU_invert(matrix, perm, matrix2);
  
  // fetch values from the second GSL matrix;
  for(k=0;k<len[0];k++)
    for(l=0;l<len[1];l++)
      inverted[k][l]=gsl_matrix_get(matrix2, k, l);
  
  // cleanup;
  gsl_matrix_free(matrix);
  gsl_matrix_free(matrix2);
  gsl_permutation_free(perm);

  Matrix ret(inverted, len[0], len[1]);
  doubledelete(inverted, len[0]);

  return ret; // return the inverted matrix
#endif // GSL
}

double Matrix::get_trace(void)
{
  return trace(*this);
}

double Matrix::det(void)
{
  return determinant();
}

double Matrix::determinant(void)
{
#ifndef GSL
  std::cerr << "'determinant_matrix' not implemented. You need GSL!" << std::endl;
  return MISSING_VALUE;
#else
  if(len[0]!=len[1])
    return MISSING_VALUE;
  
  long int k,l;
  int sign=1;
  double det=MISSING_VALUE;
  
  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(len[0], len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<len[0];k++)
    for(l=0;l<len[1];l++)
      gsl_matrix_set(matrix, k, l,  get_element(k,l));
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_LU_decomp(matrix, perm, &sign);
  
  det=gsl_linalg_LU_det(matrix, sign);
  
  // cleanup;
  gsl_matrix_free(matrix);
  gsl_permutation_free(perm);
  
  return det; // return the determinant
#endif // GSL
}

bool Matrix::is_symmetric(void)
{
  long int i,j;

  if(len[0]!=len[1])
    return false;

  for(i=1;i<len[0];i++)
    for(j=0;j<i;j++)
      if(get_element(i,j)!=get_element(j,i))
	return false;

  return true;
}

double *Matrix::eigenvalues(void)
{
#ifndef GSL
  return NULL;
#else
  if(!is_symmetric())
    return NULL;

  long int i,j,l=len[0];

  gsl_vector *eigenvaluevector=gsl_vector_alloc(l);
  gsl_matrix *inputmatrix=gsl_matrix_alloc(l,l);

  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      gsl_matrix_set(inputmatrix,i,j,get_element(i,j));
      
  gsl_eigen_symm_workspace *w=gsl_eigen_symm_alloc(l);

  gsl_eigen_symm(inputmatrix,eigenvaluevector, w);
  double *evals=new double[l];
  for(i=0;i<l;i++)
    evals[i]=gsl_vector_get(eigenvaluevector,i);

  gsl_matrix_free(inputmatrix);
  gsl_vector_free(eigenvaluevector);
  gsl_eigen_symm_free(w);

  qsort(evals, l, sizeof(double), compare_double);
  
  return evals;
#endif // GSL
}

Matrix Matrix::eigenvectors_as_matrix(double **eigen_values)
{
  *eigen_values=NULL;
#ifndef GSL
  Matrix ret;
  ret.set_status(TENSOR_ILL_DEFINED);
  return ret;
#else
  if(!is_symmetric())
    {
      Matrix ret;
      ret.set_status(TENSOR_SIZE_MISMATCH);
      return ret;
    }

  long int i,j,l=len[0];

  gsl_vector *eigenvaluevector=gsl_vector_alloc(l);
  gsl_matrix *inputmatrix=gsl_matrix_alloc(l,l);
  gsl_matrix *outputmatrix=gsl_matrix_alloc(l,l);

  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      gsl_matrix_set(inputmatrix,i,j,get_element(i,j));
      
  gsl_eigen_symmv_workspace *w=gsl_eigen_symmv_alloc(l);

  gsl_eigen_symmv(inputmatrix,eigenvaluevector, outputmatrix, w);
  gsl_eigen_symmv_sort(eigenvaluevector,outputmatrix,
		       GSL_EIGEN_SORT_VAL_DESC);

  double *evals=new double[l];
  for(i=0;i<l;i++)
    evals[i]=gsl_vector_get(eigenvaluevector,i);
  *eigen_values=evals;

  Matrix ret(l,l);
  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      ret.set_element(i,j,gsl_matrix_get(outputmatrix,i,j));
		      
  gsl_matrix_free(inputmatrix);
  gsl_matrix_free(outputmatrix);
  gsl_vector_free(eigenvaluevector);
  gsl_eigen_symmv_free(w);

  return ret;
#endif // GSL
}

vector *Matrix::eigenvectors(double **eigen_values)
{
  long int i,j,l=len[0];
  Matrix m;
  
  if(m.error())
    return NULL;

  m=eigenvectors_as_matrix(eigen_values);

  vector *ret=new vector[l];
  for(i=0;i<l;i++)
    {
      vector v(l);

      for(j=0;j<l;j++)
	v.set_element(j, m.get_element(j,i));
      ret[i]=v;
    }
  
  return ret;
}

vector Matrix::get_column_vector(long int column_number)
{
  vector v(Rows());
  
  for(long int i=0;i<Rows();i++)
    v.set_element(i, get_element(i, column_number));

  return v;
}

vector *Matrix::get_column_vectors(void)
{
  vector *v=new vector[Columns()];
  
  for(long int i=0;i<Columns();i++)
    v[i]=get_column_vector(i);

  return v;
}

vector Matrix::get_row_vector(long int row_number)
{
  vector v(Columns());
  
  for(long int i=0;i<Columns();i++)
    v.set_element(i, get_element(row_number,i));

  return v;

}

vector *Matrix::get_row_vectors(void)
{
  vector *v=new vector[Rows()];
  
  for(long int i=0;i<Rows();i++)
    v[i]=get_row_vector(i);

  return v;
}

vector Matrix::column_mean(void)
{
  vector v(Columns());
  
  for(long int i=0;i<Columns();i++)
    for(long int j=0;j<Rows();j++)
      v.set_element(i, v(i)+get_element(j, i));

  for(long int i=0;i<Columns();i++)
    v.set_element(i, v(i)/double(Rows()));

  return v;
}

vector Matrix::row_mean(void)
{
  vector v(Rows());
  
  for(long int i=0;i<Rows();i++)
    for(long int j=0;j<Columns();j++)
      v.set_element(i, v(i)+get_element(i, j));

  for(long int i=0;i<Rows();i++)
    v.set_element(i, v(i)/double(Columns()));

  return v;
}

Matrix Matrix::covariance(void)
{
  Matrix X=(*this),Y,ret;
  int n=Rows();
  vector v;
  
  v=X.column_mean();
  Y=X-v;

  ret=Y.transpose()*Y;
  ret/=double(n-1);
  
  return ret;
}

Matrix covariance(const Matrix &X)
{
  Matrix ret, Y,Z;
  int n=Rows(X);
  vector v;
  
  Y=X;
  v=Y.column_mean();
  Z=Y-v;

  ret=transpose(Z)*Z;
  ret/=double(n-1);
  
  return ret;
}

vector Matrix::as_vector(void) // lays the matrix out as a
  // large, rows x columns vector. 
{
  vector v(Rows()*Columns());

  long int i,j,k=0;
  for(i=0;i<Rows();i++)
    for(j=0;j<Columns();j++)
      v.set_element(k++, get_element(i,j));

  return v;
}

std::istream& operator>>(std::istream &in, Matrix &m)
{
  m.fetch_input(in);

  return in;
}

Matrix transpose(const Matrix &m)
{
  Matrix ret(m.len[1], m.len[0]);
  
  for(long int i=0;i<m.len[0];i++)
    for(long int j=0;j<m.len[1];j++)
      ret.set_element(j,i, get_element(m,i,j));
    
  return ret;
}

void Matrix::fetch_file(char *file_name)
{
  std::ifstream in;

  in.open(file_name, std::ios::in);
  if(in.fail())
    {
      set_status(TENSOR_COULDNT_READ_FILE);
      std::cerr << (WHAT("Klarte ikke � lese fil!",
		    "Couldn't read file!")) << std::endl;
      return;
    }

  fetch_input(in);
  in.close();
}

void Matrix::fetch_input(std::istream &in)
{
  char line[10000];
  long int rows=0, columns=0;

  cleanup();

  status=TENSOR_FILE_HEADER_NOT_FOUND;  
  dim=2;
  
  in.getline(line,9999);
  while(!in.fail() && status==TENSOR_FILE_HEADER_NOT_FOUND)
    {
      char *ptr=stripspaces(line);

      if(*ptr=='#')
	{
	  if(sscanf(ptr+1, "%ld %ld", &rows, &columns)==2)
	    status=TENSOR_OK;
	}

      if(status!=TENSOR_OK)
	in.getline(line,9999);
    }  
  
  if(status!=TENSOR_OK)
    return;
  
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;
  initialize();

  for(long int i=0;i<totlen;i++)
    {
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
      in >> data[i];
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
    }
}

void Matrix::fetch_input(std::istream &in, long int rows, long int columns)
{
  cleanup();
  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;
  initialize();

  for(long int i=0;i<totlen;i++)
    {
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
      in >> data[i];
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
    }

}
double **Matrix::export_to_double(void)
{
  int i,j;
  double **ret=new double*[len[0]];
  
  for(i=0;i<len[0];i++)
    {
      ret[i]=new double[len[1]];
      for(j=0;j<len[1];j++)
	ret[i][j]=get_element(i,j);
    }

  return ret;
}

double get_matrix_element(const Matrix &m, 
			  long int row_position, 
			  long int column_position)
{
  if(row_position<0 || row_position>m.len[0] ||
     column_position<0 || column_position>m.len[1])
    return MISSING_VALUE;

  long int abspos=row_position*m.len[1]+column_position;

  return m.data[abspos];
}

double Matrix::get_element(long int row_position, 
			   long int column_position)
{
  if(row_position<0 || row_position>len[0] ||
     column_position<0 || column_position>len[1])
    return MISSING_VALUE;

  long int abspos=row_position*len[1]+column_position;

  return data[abspos];
}

double Matrix::operator() (long int row_position, 
			   long int column_position)
{
  return get_element(row_position, column_position);
}

double Matrix::operator() (void)
{
  if(data)
    return data[0];
  else
    return MISSING_VALUE;
}

void Matrix::set_element(long int row_position, long int column_position,
		   double newvalue)
{
  if(row_position<0 || row_position>len[0] ||
     column_position<0 || column_position>len[1])
    return;

  long int abspos=row_position*len[1]+column_position;

  data[abspos]=newvalue;
} 

long int Matrix::Rows(void)
{
  return len[0];
}

long int Matrix::Columns(void)
{
  return len[1];
}


long int Rows(const Matrix &m)
{
  return m.len[0];
}

long int Columns(const Matrix &m)
{
  return m.len[1];
}

double get_element(const Matrix &m, long int i, long int j)
{
  long int abspos=i*m.len[1]+j;
  return m.data[abspos];
}

Matrix inverse(const Matrix &m)
{
  #ifndef GSL
  std::cerr << "'inverse_matrix' not implemented. You need GSL!" << std::endl;
  return Matrix();
#else
  Matrix err;
  err.set_status(TENSOR_SIZE_MISMATCH);
  if(m.len[0]!=m.len[1])
    return err;

  long int k,l;
  int sign=1;
  double **inverted=new double*[m.len[0]];

  // make the return matrix;
  for(k=0;k<m.len[0];k++)
    inverted[k]=new double[m.len[1]];

  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(m.len[0],m.len[1]);
  gsl_matrix *matrix2=gsl_matrix_alloc(m.len[0], m.len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(m.len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      gsl_matrix_set(matrix, k, l,  get_element(m,k,l));
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_LU_decomp(matrix, perm, &sign);
  gsl_linalg_LU_invert(matrix, perm, matrix2);
  
  // fetch values from the second GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      inverted[k][l]=gsl_matrix_get(matrix2, k, l);
  
  // cleanup;
  gsl_matrix_free(matrix);
  gsl_matrix_free(matrix2);
  gsl_permutation_free(perm);

  Matrix ret(inverted, m.len[0], m.len[1]);
  doubledelete(inverted, m.len[0]);

  return ret; // return the inverted matrix
#endif // GSL
}

Matrix LU_decompose(const Matrix &m)
{
#ifndef GSL
  std::cerr << "'LU_decompsoe' not implemented. You need GSL!" << std::endl;
  return Matrix();
#else
  Matrix err;
  err.set_status(TENSOR_SIZE_MISMATCH);
  if(m.len[0]!=m.len[1])
    return err;

  long int k,l;
  int sign=1;
  double **decomp=new double*[m.len[0]];

  // make the return matrix;
  for(k=0;k<m.len[0];k++)
    decomp[k]=new double[m.len[1]];

  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(m.len[0],m.len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(m.len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      gsl_matrix_set(matrix, k, l,  get_element(m,k,l));
  
  // LU decompose this matrix using GSL:
  gsl_linalg_LU_decomp(matrix, perm, &sign);
  
  // fetch values from the decomposed GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      decomp[k][l]=gsl_matrix_get(matrix, k, l);
  
  // cleanup;
  gsl_matrix_free(matrix);
  gsl_permutation_free(perm);

  Matrix ret(decomp, m.len[0], m.len[1]);
  doubledelete(decomp, m.len[0]);

  return ret; // return the decomposed matrix
#endif // GSL
}

void cholesky_handler(const char * /* reason */, 
		      const char * /* file */, 
		      int /* line */, 
		      int /* gsl_errno */)
{
  // NOP
}

Matrix *cholesky_decompose(const Matrix &m)
{
#ifndef GSL
  std::cerr << "'LU_decompsoe' not implemented. You need GSL!" << std::endl;
  return NULL;
#else
  Matrix *err=new Matrix();
  err->set_status(TENSOR_SIZE_MISMATCH);
  if(m.len[0]!=m.len[1])
    return err;
  delete err;

  long int k,l;
  double **decomp=new double*[m.len[0]];

  // make the return matrix;
  for(k=0;k<m.len[0];k++)
    decomp[k]=new double[m.len[1]];

  gsl_set_error_handler(&cholesky_handler);
  
  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(m.len[0],m.len[1]);
  int status2;

  // Set the first GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      gsl_matrix_set(matrix, k, l,  get_element(m,k,l));

  // LU decompose this matrix using GSL:
  status2=gsl_linalg_cholesky_decomp(matrix);
  if(status2!=GSL_SUCCESS)
    {
      gsl_matrix_free(matrix);
      doubledelete(decomp, m.len[0]);
      gsl_set_error_handler(NULL); 
      err=new Matrix();
      err->set_status(TENSOR_CHOLESKY_FAILED);
      if(m.len[0]!=m.len[1])
	return err;
    }

  // fetch values from the decomposed GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      decomp[k][l]=gsl_matrix_get(matrix, k, l);
  
  // cleanup;
  gsl_matrix_free(matrix);
  
  Matrix *ret=new Matrix(decomp, m.len[0], m.len[1]);
  doubledelete(decomp, m.len[0]);

  gsl_set_error_handler(NULL); 

  return ret; // return the decomposed matrix
#endif // GSL
}

double trace(const Matrix &m)
{
  long int i,l=m.len[0];
  double ret=0.0;

  for(i=0;i<l;i++)
    ret+=get_element(m,i,i);

  return ret;
}

double det(const Matrix &m)
{
  return determinant(m);
}

double determinant(const Matrix &m)
{
#ifndef GSL
  std::cerr << "'determinant_matrix' not implemented. You need GSL!" << std::endl;
  return MISSING_VALUE;
#else
  if(m.len[0]!=m.len[1])
    return MISSING_VALUE;

  long int k,l;
  int sign=1;
  double det=MISSING_VALUE;

  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(m.len[0], m.len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(m.len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      gsl_matrix_set(matrix, k, l,  get_element(m,k,l));
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_LU_decomp(matrix, perm, &sign);
  
  det=gsl_linalg_LU_det(matrix, sign);

  // cleanup;
  gsl_matrix_free(matrix);
  gsl_permutation_free(perm);

  return det; // return the determinant
#endif // GSL
}




long int ctensor::lengths_to_total_length(void)
{
  long int ret=1;

  for(long int i=0;i<dim;i++)
    ret*=len[i];

  return ret;
}

ctensor::ctensor() // makes a zero-ctensor, i.e. scalar
{
  dim=0;
  totlen=1;
  len=NULL;
  status=TENSOR_OK;
  data=new complex[1];
  data[0]=0.0;
}

ctensor::ctensor(const ctensor &orig) // copy a ctensor
{
  dim=totlen=0;
  len=NULL;
  data=NULL;
  *this=orig;
}

ctensor::ctensor(const tensor &orig) // copy a tensor
{
  dim=totlen=0;
  len=NULL;
  data=NULL;
  *this=orig;
}

// general purpose constructor;
ctensor::ctensor(long int dimension, long int *lengths) 
{
  dim=dimension;
  len=new long int[dim];
  for(long int i=0;i<dim;i++)
    len[i]=lengths[i];

  initialize();
}

ctensor::ctensor(long int length) // makes a vector, fills it with zeros
{
  dim=1;
  len=new long int[1];
  len[0]=length;

  initialize();
}

ctensor::ctensor(long int rows, long int columns) 
  // makes a matrix, fills it with zeros 
{
  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;

  initialize();
}

ctensor::ctensor(long int len1, long int len2, long int len3) 
  // makes three-ctensor
{
  dim=3;
  len=new long int[3];
  len[0]=len1;
  len[1]=len2;
  len[2]=len3;

  initialize();
}

ctensor::ctensor(char *input_file) 
  // reads from file
{
  dim=totlen=0;
  len=NULL;
  data=NULL;

  read_file(input_file);
}

void ctensor::initialize(void)
{
  status=TENSOR_OK;

  if(dim==0)
    {
      len=NULL;
      totlen=1;
      data=new complex[1];
      return;
    }

  totlen=lengths_to_total_length();
  data=new complex[totlen];
  for(long int i=0;i<totlen;i++)
    data[i]=0.0;
}

ctensor::~ctensor()
{
  cleanup();
}

void ctensor::cleanup(void)
{
  if(len)
    delete [] len;
  len=NULL;
  if(data)
    delete [] data;
  data=NULL;
  dim=totlen=0;
}

bool ctensor::check_sizes(const ctensor &t2)
{
  if(dim!=t2.dim)
    {
      status=TENSOR_SIZE_MISMATCH;
      return false;
    }
  
  if(data==NULL || t2.data==NULL)
    {
      status=TENSOR_ILL_DEFINED;
      return false;
    }

  for(long int i=0;i<dim;i++)
    if(len[i]!=t2.len[i])
      {
	status=TENSOR_SIZE_MISMATCH;
	return false;
      }

  return true;
}

bool ctensor::check_sizes(const tensor &t2)
{
  if(dim!=t2.dim)
    {
      status=TENSOR_SIZE_MISMATCH;
      return false;
    }
  
  if(data==NULL || t2.data==NULL)
    {
      status=TENSOR_ILL_DEFINED;
      return false;
    }

  for(long int i=0;i<dim;i++)
    if(len[i]!=t2.len[i])
      {
	status=TENSOR_SIZE_MISMATCH;
	return false;
      }

  return true;
}

TENSOR_ERROR_STATUS ctensor::error(void)
{
  return status;
}

void ctensor::set_status(TENSOR_ERROR_STATUS newstatus)
{
  status=newstatus;
}

ctensor& ctensor::operator= (const ctensor &orig)
// sets one ctensor to other
{
  long int i;

  cleanup();
  
  dim=orig.dim;
  totlen=orig.totlen;
  status=orig.status;

  len=new long int[dim];
  for(i=0;i<dim;i++)
    len[i]=orig.len[i];
  
  data=new complex[totlen];
  for(i=0;i<totlen;i++)
    data[i]=orig.data[i];

  return *this;
}

ctensor& ctensor::operator= (const tensor &orig)
// sets one ctensor to other
{
  long int i;

  cleanup();
  
  dim=orig.dim;
  totlen=orig.totlen;
  status=orig.status;

  len=new long int[dim];
  for(i=0;i<dim;i++)
    len[i]=orig.len[i];
  
  data=new complex[totlen];
  for(i=0;i<totlen;i++)
    data[i]=orig.data[i];

  return *this;
}

ctensor& ctensor::operator= (const complex &orig) // sets the contents of 
// a ctensor to a constant (i.e. all elements=orig).
{
  for(long int i=0;i<totlen;i++)
    data[i]=orig;

  return *this;
}

ctensor& ctensor::operator= (const double &orig) // sets the contents of 
// a ctensor to a constant (i.e. all elements=orig).
{
  for(long int i=0;i<totlen;i++)
    data[i]=orig;

  return *this;
}

ctensor& ctensor::operator= (const float &orig) // sets the contents of 
// a ctensor to a constant (i.e. all elements=orig).
{
  for(long int i=0;i<totlen;i++)
    data[i]=orig;

  return *this;
}

ctensor& ctensor::operator= (const int &orig) // sets the contents of 
// a ctensor to a constant (i.e. all elements=orig).
{
  for(long int i=0;i<totlen;i++)
    data[i]=orig;

  return *this;
}

ctensor operator+ (const ctensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]+c2.data[i];

  return ret;
}

ctensor operator+ (const tensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]+c2.data[i];

  return ret;
}

ctensor operator+ (const ctensor &c1, const tensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]+c2.data[i];

  return ret;
}

ctensor operator+ (const ctensor &c1, const complex &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

ctensor operator+ (const complex &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

ctensor operator+ (const ctensor &c1, const double &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

ctensor operator+ (const double &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

ctensor operator+ (const ctensor &c1, const float &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

ctensor operator+ (const float &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

ctensor operator+ (const ctensor &c1, const int &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

ctensor operator+ (const int &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

ctensor operator- (const ctensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2.data[i];

  return ret;
}

ctensor operator- (const tensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2.data[i];

  return ret;
}

ctensor operator- (const ctensor &c1, const tensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2.data[i];

  return ret;
}


ctensor operator- (const ctensor &c1, const complex &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

ctensor operator- (const complex &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}


ctensor operator- (const ctensor &c1, const double &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

ctensor operator- (const double &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

ctensor operator- (const ctensor &c1, const float &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]- c2;

  return ret;
}

ctensor operator- (const float &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

ctensor operator- (const ctensor &c1, const int &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]-c2;

  return ret;
}

ctensor operator- (const int &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1-c2.data[i];

  return ret;
}

ctensor operator* (const ctensor &c1, const complex &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2;

  return ret;
}

ctensor operator* (const complex &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1*c2.data[i];

  return ret;
}


ctensor operator* (const ctensor &c1, const double &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2;

  return ret;
}

ctensor operator* (const double &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1*c2.data[i];

  return ret;
}


ctensor operator* (const ctensor &c1, const float &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2;

  return ret;
}

ctensor operator* (const float &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1*c2.data[i];

  return ret;
}

ctensor operator* (const ctensor &c1, const int &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2;

  return ret;
}

ctensor operator* (const int &c1, const ctensor &c2)
{
  ctensor ret(c2.dim, c2.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1*c2.data[i];

  return ret;
}


ctensor operator/ (const ctensor &c1, const complex &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2;

  return ret;
}

ctensor operator/ (const ctensor &c1, const double &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2;

  return ret;
}

ctensor operator/ (const ctensor &c1, const float &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2;

  return ret;
}

ctensor operator/ (const ctensor &c1, const int &c2)
{
  ctensor ret(c1.dim, c1.len);

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2;

  return ret;
}

void operator+= (ctensor &c1,const ctensor &c2)
{
  c1=c1+c2;
}

void operator+= (ctensor &c1,const tensor &c2)
{
  c1=c1+c2;
}

void operator+= (ctensor &c1,const complex &c2)
{
  c1=c1+c2;
}

void operator+= (ctensor &c1,const double &c2)
{
  c1=c1+c2;
}

void operator+= (ctensor &c1,const float &c2)
{
  c1=c1+c2;
}

void operator+= (ctensor &c1,const int &c2)
{
  c1=c1+c2;
}

void operator-= (ctensor &c1,const ctensor &c2)
{
  c1=c1-c2;
}

void operator-= (ctensor &c1,const tensor &c2)
{
  c1=c1-c2;
}

void operator-= (ctensor &c1,const complex &c2)
{
  c1=c1-c2;
}

void operator-= (ctensor &c1,const double &c2)
{
  c1=c1-c2;
}

void operator-= (ctensor &c1,const float &c2)
{
  c1=c1-c2;
}

void operator-= (ctensor &c1,const int &c2)
{
  c1=c1-c2;
}

void operator*= (ctensor &c1,const complex &c2)
{
  c1=c1*c2;
}

void operator*= (ctensor &c1,const double &c2)
{
  c1=c1*c2;
}

void operator*= (ctensor &c1,const float &c2)
{
  c1=c1*c2;
}

void operator*= (ctensor &c1,const int &c2)
{
  c1=c1*c2;
}

void operator/= (ctensor &c1,const complex &c2)
{
  c1=c1/c2;
}

void operator/= (ctensor &c1,const double &c2)
{
  c1=c1/c2;
}

void operator/= (ctensor &c1,const float &c2)
{
  c1=c1/c2;
}

void operator/= (ctensor &c1,const int &c2)
{
  c1=c1/c2;
}

// element by element multiplication
ctensor operator| (const ctensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2.data[i];

  return ret;
}

// element by element multiplication
ctensor operator| (const tensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2.data[i];

  return ret;
}

// element by element multiplication
ctensor operator| (const ctensor &c1, const tensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]*c2.data[i];

  return ret;
}

ctensor operator|= (ctensor &c1, const ctensor &c2)
{
  c1=c1|c2;

  return c1;
}

ctensor operator|= (ctensor &c1, const tensor &c2)
{
  c1=c1|c2;

  return c1;
}

// element by element division
ctensor operator% (const ctensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2.data[i];

  return ret;
}

// element by element division
ctensor operator% (const tensor &c1, const ctensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2.data[i];

  return ret;
}

// element by element division
ctensor operator% (const ctensor &c1, const tensor &c2)
{
  ctensor ret(c1.dim, c1.len);

  if(!ret.check_sizes(c2))
    return ret;

  for(long int i=0;i<ret.totlen;i++)
    ret.data[i]=c1.data[i]/c2.data[i];

  return ret;
}

ctensor operator%= (ctensor &c1, const ctensor &c2)
{
  c1=c1%c2;

  return c1;
}

ctensor operator%= (ctensor &c1, const tensor &c2)
{
  c1=c1%c2;

  return c1;
}

void ctensor::transpotize(ctensor &orig,
			 long int *indexes, long int depth, 
			 long int index1, long int index2)
{
  long int i;

  if(depth==dim)
    {
      long int *indexes2=new long int[dim];
      for(i=0;i<dim;i++)
	indexes2[i]=indexes[i];
      indexes2[index1]=indexes[index2];
      indexes2[index2]=indexes[index1];

      set_element(indexes2, orig(indexes));
    }
  else
    {
      for(i=0;i<orig.len[depth];i++)
	{
	  indexes[depth]=i;
	  transpotize(orig,indexes,depth+1,index1,index2); 
	}
    }
}

ctensor ctensor::transpose(long int index1, long int index2)
{
  long int i,  *indexes=new long int[dim];
  long int *newlen=new long int[dim];

  for(i=0;i<dim;i++)
    if(i!=index1 && i!=index2)
      newlen[i]=len[i];
  newlen[index1]=len[index2];
  newlen[index2]=len[index1];

  ctensor ret(dim, newlen);

  ret.transpotize(*this, indexes, 0, index1, index2); 
  
  delete [] newlen;
  delete [] indexes;

  return ret;
}


// Returns an element. Remember that C 
// counts from 0!
complex ctensor::operator() (long int *position) 
{
  return get_element(position);
}

complex ctensor::operator() (void) // returns the first element 
{
  return as_complex();
}

complex ctensor::get_element(long int *position) 
{
  long int abspos=0;
  
  for(long int i=0;i<dim;i++)
    {
      abspos*=len[i];
      abspos+=position[i];
    }

  if(abspos<totlen)
    return data[abspos];
  else
    return complex(MISSING_VALUE, MISSING_VALUE);
}

void ctensor::set_element(long int *position, complex newvalue)
{
  long int abspos=0;

  for(long int i=0;i<dim;i++)
    {
      abspos*=len[i];
      abspos+=position[i];
    }

  if(abspos<totlen)
    data[abspos]=newvalue;
} 

void ctensor::set_element(long int *position, double newvalue)
{
  long int abspos=0;

  for(long int i=0;i<dim;i++)
    {
      abspos*=len[i];
      abspos+=position[i];
    }

  if(abspos<totlen)
    data[abspos]=newvalue;
} 

void ctensor::set_element(long int *position, float newvalue)
{
  set_element(position, (double) newvalue);
}

void ctensor::set_element(long int *position, int newvalue)
{
  set_element(position, (double) newvalue);
}


long int ctensor::get_dimension(void)
{
  return dim;
}

long int ctensor::get_length(long int index_number)
{
  if(index_number<0 || index_number>=dim)
    return (long int) MISSING_VALUE;
  else
    return len[index_number];
}

complex ctensor::as_complex(void) // returns the first element
{
  if(data)
    return data[0];
  else
    return MISSING_VALUE;
}

void ctensor::set_levi_cevita(void)
{
  for(long int i=0;i<dim;i++)
    if(len[i]!=dim)
      status=TENSOR_LEVI_CEVIATE_UNSUITABLE; // continue anyhow...

  long int *indexes=new long int[dim], depth=0;

  levi_cevitize(indexes,depth);
  delete [] indexes;
}

void ctensor::levi_cevitize(long int *indexes, long int depth)
{
  long int i,j;

  if(depth==dim)
    {
      for(i=1;i<dim;i++)
	for(j=0;j<i;j++)
	  if(indexes[i]==indexes[j])
	    {
	      set_element(indexes, 0);
	      return;
	    }
      
      int elem=1;
      for(i=1;i<dim;i++)
	for(j=0;j<i;j++)
	  if(indexes[i]<indexes[j])
	    elem*=-1;
      set_element(indexes,elem);
    }
  else
    {
      for(i=0;i<len[depth];i++)
	{
	  indexes[depth]=i;
	  levi_cevitize(indexes,depth+1); 
	}
    }
}

// lengths (rows and columns) should be equal
void ctensor::set_identity(void)
{
  for(long int i=1;i<dim;i++)
    if(len[i]!=len[i-1])
      status=TENSOR_INDENTITY_UNSUITABLE; // continue anyhow...

  long int *indexes=new long int[dim], depth=0;

  identitize(indexes,depth);
  delete [] indexes;
} 

void ctensor::identitize(long int *indexes, long int depth)
{
  long int i;

  if(depth==dim)
    {
      int elem=1;
      for(i=1;i<dim && elem; i++)
	if(indexes[i]!=indexes[i-1])
	  elem=0;

      set_element(indexes,elem);
    }
  else
    {
      for(i=0;i<len[depth];i++)
	{
	  indexes[depth]=i;
	  identitize(indexes,depth+1); 
	}
    }
}


std::ostream& operator<<(std::ostream &out, ctensor &c)
{
  long int *indexes=new long int[c.dim], depth=0;

  c.output(out, indexes, depth);
  delete [] indexes;

  return out;
}


void ctensor::output(std::ostream &out, long int *indexes, long int depth)
{
  long int i;

  if(depth==dim)
    {
      complex val=get_element(indexes);
      
      for(i=0;i<dim;i++)
	out << indexes[i] << (i<dim-1 ? " , " : " : ");
      out << val << std::endl;
    }
  else
    {
      for(i=0;i<len[depth];i++)
	{
	  indexes[depth]=i;
	  output(out,indexes,depth+1); 
	}
    }
}

void ctensor::read_file(char *file_name)
{
  std::ifstream in;

  in.open(file_name, std::ios::in);

  if(in.fail())
    {
      set_status(TENSOR_COULDNT_READ_FILE);
      std::cerr << (WHAT("Klarte ikke � lese fil!",
		    "Couldn't read file!")) << std::endl;
      return;
    }

  read_stream(in);
  in.close();
}

void ctensor::read_stream(std::istream &in)
{
  in >> *this;
}

std::istream& operator>>(std::istream &in, ctensor &t)
{
  t.get_header(in);
  
  if(t.error()!=TENSOR_OK)
    return in;
  
  for(long int i=0;i<t.totlen;i++)
    {
      if(in.fail())
	{
	  t.status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return in;
	}
      in >> t.data[i];
      if(in.fail())
	{
	  t.status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return in;
	}
    }
  
  return in;
}

void ctensor::get_header(std::istream &in)
{
  char line[10000];
  long int i, d=-1;

  cleanup();

  status=TENSOR_FILE_HEADER_NOT_FOUND;  
  dim=0;
  
  in.getline(line,9999);
  while(!in.fail() && status==TENSOR_FILE_HEADER_NOT_FOUND)
    {
      bool dim_set=false;

      if(!strncasecmp(line, "# dim:", 6))
	{
	  if(sscanf(line+6, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# dim :", 7))
	{
	  if(sscanf(line+7, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# dimension:", 12))
	{
	  if(sscanf(line+12, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# dimension :", 13))
	{
	  if(sscanf(line+13, "%ld", &d)<1)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  dim_set=true;
	}
      else if(!strncasecmp(line, "# length ", 9))
	{
	  long int index,l;

	  if(d<0)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }

	  if(sscanf(line+9, "%ld : %ld", &index, &l)<2)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  
	  if(index>d)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	   
	  len[index]=l;
	}
      else if(!strncasecmp(line, "# len ", 6))
	{
	  long int index,l;

	  if(d<0)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }

	  if(sscanf(line+6, "%ld : %ld", &index, &l)<2)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	  
	  if(index>d)
	    {
	      status=TENSOR_FILE_HEADER_UNREADABLE;
	      return;
	    }
	   
	  len[index]=l;
	}
      else if(stripspaces(line)[0]!='\0' &&
	      stripspaces(line)[0]!='#')
	return;
      
      if(dim_set)
	{
	  dim=d;
	  if(dim>0)
	    {
	      len=new long int[dim];
	      for(i=0;i<dim;i++)
		len[i]=0;
	    }
	  else
	    {
	      initialize();
	      status=TENSOR_OK;
	      return;
	    }
	}

      if(dim>0)
	{
	  bool complete=true;

	  for(i=0;i<dim && complete;i++)
	    if(len[i]==0)
	      complete=false;
	      
	  if(complete)
	    {
	      initialize();
	      status=TENSOR_OK;
	      return;
	    }
	}

      in.getline(line,9999);
    }  
}


// only one element made
cvector::cvector() : ctensor()
{
  dim=1;
  len=new long int[1];
  totlen=len[0]=1;
  data=new complex[1];
}
 
cvector::cvector(long int length) : ctensor(1, &length)
{
}

cvector::cvector(complex *content, long int length) : ctensor(1, &length)
{
  for(long int i=0;i<length;i++)
    data[i]=content[i];
}

cvector::cvector(const cvector &orig) : ctensor((ctensor&) orig)
{
}

cvector::cvector(char *input_file) : ctensor()
{
  dim=1;
  len=new long int[1];
  totlen=len[0]=1;
  data=new complex[1];

  fetch_file(input_file);
}

// dot product:
complex operator& (const cvector &v1, const cvector &v2)
{
  ctensor t;
  
  t=v1|v2;

  if(t.error())
    return complex(MISSING_VALUE, MISSING_VALUE);

  complex ret=0;
  for(long int i=0;i<t.get_length(0);i++)
    ret+=t(&i);

  return ret;
}

cvector operator* (const cvector &v1, const cvector &v2)
{
  cvector ret;
  complex val=v1&v2;

  ret.set_element(0, val);

  return ret;
}

cvector operator* (Matrix &m, cvector &v)
{
  if(m.Columns()!=v.size())
    {
      cvector err;
      err.set_status(TENSOR_SIZE_MISMATCH);

      return err;
    }
  
  cvector ret(m.Rows());
  long int i,j;

  for(i=0;i<m.Rows();i++)
    for(j=0;j<m.Columns();j++)
      ret.set_element(i, ret(i)+m(i,j)*v(j));
  
  return ret;
}

cvector operator* (cmatrix &m, cvector &v)
{
  if(m.Columns()!=v.size())
    {
      cvector err;
      err.set_status(TENSOR_SIZE_MISMATCH);

      return err;
    }
  
  cvector ret(m.Rows());
  long int i,j;

  for(i=0;i<m.Rows();i++)
    for(j=0;j<m.Columns();j++)
      ret.set_element(i, ret(i)+m(i,j)*v(j));
  
  return ret;
}

cvector operator* (cvector &v, cmatrix &m)
{
  if(m.Rows()!=v.size())
    {
      cvector err;
      err.set_status(TENSOR_SIZE_MISMATCH);

      return err;
    }
  
  cvector ret(m.Columns());
  long int i,j;

  for(i=0;i<m.Columns();i++)
    for(j=0;j<m.Rows();j++)
      ret.set_element(i, ret(i)+m(j,i)*v(j));
  
  return ret;
}

cvector operator* (cvector &v, Matrix &m)
{
  if(m.Rows()!=v.size())
    {
      cvector err;
      err.set_status(TENSOR_SIZE_MISMATCH);

      return err;
    }
  
  cvector ret(m.Columns());
  long int i,j;

  for(i=0;i<m.Columns();i++)
    for(j=0;j<m.Rows();j++)
      ret.set_element(i, ret(i)+m(j,i)*v(j));
  
  return ret;
}

cvector cvector::cross(const cvector &v2)
{  
  cvector ret(*this);

  if(len[0]!=3 || v2.len[0]!=3)
    {
      ret.status=TENSOR_SIZE_MISMATCH;
      return ret;
    }
  
  ret.data[0]=data[1]*v2.data[2]-data[2]*v2.data[1];
  ret.data[1]=data[2]*v2.data[0]-data[0]*v2.data[2];
  ret.data[2]=data[0]*v2.data[1]-data[1]*v2.data[0];
  
  return ret;
}

// PS: Among the tensor classes, 'cvector' is the only one 
// where a file header isn't neccessary
std::istream& operator>>(std::istream &in, cvector &v)
{
  v.fetch_input(in);

  return in;
}

void cvector::fetch_file(char *file_name)
{
  std::ifstream in;

  in.open(file_name, std::ios::in);

  if(in.fail())
    {
      set_status(TENSOR_COULDNT_READ_FILE);
      std::cerr << (WHAT("Klarte ikke � lese fil!",
		    "Couldn't read file!")) << std::endl;
      return;
    }

  fetch_input(in);
  in.close();
}

void cvector::fetch_input(std::istream &in)
{
  complexlist *head=NULL, *tail=NULL, *ptr;
  
  while(!in.fail())
    {
      complex value;

      in >> value;

      if(!in.fail())
	{
	  tail=new complexlist(tail,NULL,value);
	  if(!head)
	    head=tail;
	}
    }
  
  if(!head)
    {
      set_status(TENSOR_ILL_DEFINED);
      return;
    }

  long int i=0;
  long int length=head->number_of_elements();

  cleanup();
  dim=1;
  len=new long int[1];
  len[0]=length;

  initialize();

  for(ptr=head; ptr; ptr=ptr->suc())
    data[i++]=ptr->getvalue();

  delete head;
}

void cvector::fetch_input(std::istream &in, long int length)
{
  
  cleanup();
  dim=1;
  len=new long int[1];
  len[0]=length;

  initialize();

  for(long int i=0;i<totlen;i++)
    {
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
      in >> data[i];
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
    }
}

complex cvector::get_element(long int position) const
{
  if(position<0 || position>totlen)
    return complex(MISSING_VALUE,MISSING_VALUE);
  else
    return data[position];
}

complex cvector::operator() (long int position) const
{
  return get_element(position);
}

complex cvector::operator() (void) const
{
  if(data)
    return data[0];
  else
    return complex(MISSING_VALUE,MISSING_VALUE);
}

cmatrix cmatrix::transpose(void)
{
  cmatrix ret(len[1], len[0]);

  for(long int i=0;i<len[0];i++)
    for(long int j=0;j<len[1];j++)
      ret.set_element(j,i, get_element(i,j));
    
  return ret;
}

cvector conjugate(cvector &orig)
{
  cvector ret(orig);

  for(long int i=0;i<ret.len[0];i++)
    ret.data[i]=ret.data[i].conjugate();

  return ret;
}

double cvector::length(void)
{
  return sqrt(((*this)&conjugate(*this)).abs());
}

double cvector::length_squared(void)
{
  return ((*this)&conjugate(*this)).abs2();
}

void cvector::set_element(long int position, complex newvalue)
{
  if(position<0 || position>totlen)
    return;
  data[position]=newvalue;
}

long int cvector::size(void) const
{
  return len[0];
}

complex get_element(const cvector &v, long int position)
{
  if(position<0 || position>v.totlen)
    return MISSING_VALUE;
  else
    return v.data[position];
}

long int cvector::number_of_elements(void)
{
  return len[0];
}


cmatrix::cmatrix() : ctensor() // makes a 1x1 matrix
{
  cleanup();

  dim=2;
  len=new long int[2];
  totlen=len[0]=len[1]=1;
  data=new complex[1];
  data[0]=0.0;
}

cmatrix::cmatrix(long int rows, long int columns) : ctensor()
{
  cleanup();

  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;

  initialize();
}

cmatrix::cmatrix(complex **content, long int rows, long int columns) :
  ctensor()
{
  cleanup();

  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;

  initialize();

  for(long int i=0;i<rows;i++)
    for(long int j=0;j<columns;j++)
      set_element(i,j, content[i][j]);
}

cmatrix::cmatrix(const cmatrix &orig) : ctensor((ctensor&) orig) // Makes a copy
{
}

cmatrix::cmatrix(const Matrix &orig) : ctensor((tensor&) orig) // Makes a copy
{
}


cmatrix::cmatrix(const cvector &orig, bool as_column_matrix) :
  ctensor()
{
  cleanup();

  dim=2;
  len=new long int[2];
  len[0]=as_column_matrix ? orig.size() : 1; 
  len[1]=as_column_matrix ? 1 : orig.size();

  initialize();

  for(long int i=0;i<totlen;i++)
    data[i]=orig(i);
}

cmatrix::cmatrix(const vector &orig, bool as_column_matrix) :
  ctensor()
{
  cleanup();

  dim=2;
  len=new long int[2];
  len[0]=as_column_matrix ? orig.size() : 1; 
  len[1]=as_column_matrix ? 1 : orig.size();

  initialize();

  for(long int i=0;i<totlen;i++)
    data[i]=orig(i);
}

cmatrix::cmatrix(char *input_file) : ctensor()
{
  dim=2;
  len=new long int[2];
  len[0]=len[1]=1; 

  initialize();

  fetch_file(input_file);
}

cmatrix operator* (const cmatrix &m1, const cmatrix &m2)
{
  cmatrix ret1, ret2(Rows(m1), Columns(m2));
  long int i,j,k;

  ret1.set_status(TENSOR_SIZE_MISMATCH);
  if(Columns(m1)!=Rows(m2))
    return ret1;
  
  for(i=0;i<Rows(m1);i++)
    for(j=0;j<Columns(m2);j++)
      for(k=0;k<Columns(m1);k++)
	ret2.set_element(i,j, ret2.get_element(i,j)+
			 get_element(m1,i,k)*get_element(m2,k,j));

  return ret2;
}

cmatrix operator* (const Matrix &m1, const cmatrix &m2)
{
  cmatrix ret1, ret2(Rows(m1), Columns(m2));
  long int i,j,k;

  ret1.set_status(TENSOR_SIZE_MISMATCH);
  if(Columns(m1)!=Rows(m2))
    return ret1;
  
  for(i=0;i<Rows(m1);i++)
    for(j=0;j<Columns(m2);j++)
      for(k=0;k<Columns(m1);k++)
	ret2.set_element(i,j, ret2.get_element(i,j)+
			 get_element(m1,i,k)*get_element(m2,k,j));

  return ret2;
}

cmatrix operator* (const cmatrix &m1, const Matrix &m2)
{
  cmatrix ret1, ret2(Rows(m1), Columns(m2));
  long int i,j,k;

  ret1.set_status(TENSOR_SIZE_MISMATCH);
  if(Columns(m1)!=Rows(m2))
    return ret1;
  
  for(i=0;i<Rows(m1);i++)
    for(j=0;j<Columns(m2);j++)
      for(k=0;k<Columns(m1);k++)
	ret2.set_element(i,j, ret2.get_element(i,j)+
			 get_element(m1,i,k)*get_element(m2,k,j));

  return ret2;
}


cmatrix operator/ (const cmatrix &m1, const cmatrix &m2)
{
  cmatrix m3,m4;

  m3=inverse(m2);
  m4=m1*m3;

  return m4;
}

cmatrix cmatrix::inverse(void)
{
#ifndef GSL
  std::cerr << "'inverse_matrix' not implemented. You need GSL!" << std::endl;
  return cmatrix();
#else
  cmatrix err;
  err.set_status(TENSOR_SIZE_MISMATCH);
  if(len[0]!=len[1])
    return err;

  long int k,l;
  int sign=1;
  complex **inverted=new complex*[len[0]];

  // make the return matrix;
  for(k=0;k<len[0];k++)
    inverted[k]=new complex[len[1]];

  // make GSL matrixes;
  gsl_matrix_complex *matrix=gsl_matrix_complex_alloc(len[0],len[1]);
  gsl_matrix_complex *matrix2=gsl_matrix_complex_alloc(len[0], len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<len[0];k++)
    for(l=0;l<len[1];l++)
      gsl_matrix_complex_set(matrix, k, l,  get_element(k,l).com);
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_complex_LU_decomp(matrix, perm, &sign);
  gsl_linalg_complex_LU_invert(matrix, perm, matrix2);
  
  // fetch values from the second GSL matrix;
  for(k=0;k<len[0];k++)
    for(l=0;l<len[1];l++)
      {
	gsl_complex com=gsl_matrix_complex_get(matrix2, k, l);
	inverted[k][l].com=com;
      }
  
  // cleanup;
  gsl_matrix_complex_free(matrix);
  gsl_matrix_complex_free(matrix2);
  gsl_permutation_free(perm);

  cmatrix ret(inverted, len[0], len[1]);
  doubledelete(inverted, len[0]);

  return ret; // return the inverted matrix
#endif // GSL
}

complex cmatrix::get_trace(void)
{
  return trace(*this);
}

complex cmatrix::det(void)
{
  return determinant();
}

complex cmatrix::determinant(void)
{
#ifndef GSL
  std::cerr << "'determinant_matrix' not implemented. You need GSL!" << std::endl;
  return MISSING_VALUE;
#else
  if(len[0]!=len[1])
    return MISSING_VALUE;
  
  long int k,l;
  int sign=1;
  complex det(MISSING_VALUE,MISSING_VALUE);
  
  // make GSL matrixes;
  gsl_matrix_complex *matrix=gsl_matrix_complex_alloc(len[0], len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<len[0];k++)
    for(l=0;l<len[1];l++)
      gsl_matrix_complex_set(matrix, k, l,  get_element(k,l).com);
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_complex_LU_decomp(matrix, perm, &sign);
  
  det.com=gsl_linalg_complex_LU_det(matrix, sign);
  
  // cleanup;
  gsl_matrix_complex_free(matrix);
  gsl_permutation_free(perm);
  
  return det; // return the determinant
#endif // GSL
}

bool cmatrix::is_hermitic(void)
{
  long int i,j;

  if(len[0]!=len[1])
    return false;

  for(i=1;i<len[0];i++)
    for(j=0;j<i;j++)
      if(get_element(i,j)!=get_element(j,i).conjugate())
	return false;

  return true;
}

double *cmatrix::eigenvalues(void)
{
#ifndef GSL
  return NULL;
#else
  if(!is_hermitic())
    return NULL;

  long int i,j,l=len[0];

  gsl_vector *eigenvaluecvector=gsl_vector_alloc(l);
  gsl_matrix_complex *inputmatrix=gsl_matrix_complex_alloc(l,l);

  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      gsl_matrix_complex_set(inputmatrix,i,j,get_element(i,j).com);
      
  gsl_eigen_herm_workspace *w=gsl_eigen_herm_alloc(l);

  gsl_eigen_herm(inputmatrix,eigenvaluecvector, w);
  double *evals=new double[l];
  for(i=0;i<l;i++)
    evals[i]=gsl_vector_get(eigenvaluecvector,i);

  qsort(evals, l, sizeof(double), compare_double);
  
  gsl_matrix_complex_free(inputmatrix);
  gsl_vector_free(eigenvaluecvector);
  gsl_eigen_herm_free(w);
  
  return evals;
#endif // GSL
}

cmatrix cmatrix::eigenvectors_as_matrix(double **eigen_values, bool do_sort)
{
  *eigen_values=NULL;
#ifndef GSL
  cmatrix ret;
  ret.set_status(TENSOR_ILL_DEFINED);
  return ret;
#else
  if(!is_hermitic())
    {
      cmatrix ret;
      ret.set_status(TENSOR_SIZE_MISMATCH);
      return ret;
    }

  long int i,j,l=len[0];

  gsl_vector *eigenvaluecvector=gsl_vector_alloc(l);
  gsl_matrix_complex *inputmatrix=gsl_matrix_complex_alloc(l,l);
  gsl_matrix_complex *outputmatrix=gsl_matrix_complex_alloc(l,l);

  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      gsl_matrix_complex_set(inputmatrix,i,j,get_element(i,j).com);
      
  gsl_eigen_hermv_workspace *w=gsl_eigen_hermv_alloc(l);

  gsl_eigen_hermv(inputmatrix,eigenvaluecvector, outputmatrix, w);
  if(do_sort)
    gsl_eigen_hermv_sort(eigenvaluecvector,outputmatrix,
			 GSL_EIGEN_SORT_VAL_DESC);

  double *evals=new double[l];
  for(i=0;i<l;i++)
    evals[i]=gsl_vector_get(eigenvaluecvector,i);
  *eigen_values=evals;

  cmatrix ret(l,l);
  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      {
	complex c;
	c.com=gsl_matrix_complex_get(outputmatrix,i,j);
	ret.set_element(i,j,c);
      }
		      
  gsl_matrix_complex_free(inputmatrix);
  gsl_matrix_complex_free(outputmatrix);
  gsl_vector_free(eigenvaluecvector);
  gsl_eigen_hermv_free(w);

  return ret;
#endif // GSL
}

#ifndef  _WIN32

cmatrix cmatrix::eigenvectors_as_matrix(complex **eigen_values)
{
  long int i,j,l=len[0];
  
  gsl_vector_complex *eigenvaluecvector=gsl_vector_complex_alloc(l);
  gsl_matrix *inputmatrix=gsl_matrix_alloc(l,l);
  gsl_matrix_complex *outputmatrix=gsl_matrix_complex_alloc(l,l);

  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      gsl_matrix_set(inputmatrix,i,j,get_element(i,j).Real_value());
      
  gsl_eigen_nonsymmv_workspace *w=gsl_eigen_nonsymmv_alloc(l);

  gsl_eigen_nonsymmv(inputmatrix,eigenvaluecvector, outputmatrix, w);
  
  *eigen_values=new complex[l]; 
  gsl_complex *evals=new gsl_complex[l];
  for(i=0;i<l;i++)
    {
      evals[i]=gsl_vector_complex_get(eigenvaluecvector,i);
      (*eigen_values)[i].com=evals[i];
    }
  delete [] evals;

  cmatrix ret(l,l);
  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      {
	complex c;
	c.com=gsl_matrix_complex_get(outputmatrix,i,j);
	ret.set_element(i,j,c);
      }
		      
  gsl_matrix_free(inputmatrix);
  gsl_matrix_complex_free(outputmatrix);
  gsl_vector_complex_free(eigenvaluecvector);
  gsl_eigen_nonsymmv_free(w);

  return ret;
}    

#endif // ! _WIN32

cvector *cmatrix::eigenvectors(double **eigen_values)
{
  long int i,j,l=len[0];
  cmatrix m;
  
  if(m.error())
    return NULL;

  m=eigenvectors_as_matrix(eigen_values);

  cvector *ret=new cvector[l];
  for(i=0;i<l;i++)
    {
      cvector v(l);

      for(j=0;j<l;j++)
	v.set_element(j, m.get_element(j,i));
      ret[i]=v;
    }
  
  return ret;
}

cvector cmatrix::get_column_vector(long int column_number)
{
  cvector v(Rows());
  
  for(long int i=0;i<Rows();i++)
    v.set_element(i, get_element(i, column_number));

  return v;
}

cvector *cmatrix::get_column_vectors(void)
{
  cvector *v=new cvector[Columns()];
  
  for(long int i=0;i<Columns();i++)
    v[i]=get_column_vector(i);

  return v;
}

cvector cmatrix::get_row_vector(long int row_number)
{
  cvector v(Columns());
  
  for(long int i=0;i<Columns();i++)
    v.set_element(i, get_element(row_number,i));

  return v;

}

cvector *cmatrix::get_row_vectors(void)
{
  cvector *v=new cvector[Rows()];
  
  for(long int i=0;i<Rows();i++)
    v[i]=get_row_vector(i);

  return v;
}

cvector cmatrix::as_cvector(void) // lays the matrix out as a
  // large, rows x columns cvector. 
{
  cvector v(Rows()*Columns());

  long int i,j,k=0;
  for(i=0;i<Rows();i++)
    for(j=0;j<Columns();j++)
      v.set_element(k++, get_element(i,j));

  return v;
}

std::istream& operator>>(std::istream &in, cmatrix &m)
{
  m.fetch_input(in);

  return in;
}

void cmatrix::fetch_file(char *file_name)
{
  std::ifstream in;

  in.open(file_name, std::ios::in);
  if(in.fail())
    {
      set_status(TENSOR_COULDNT_READ_FILE);
      std::cerr << (WHAT("Klarte ikke � lese fil!",
		    "Couldn't read file!")) << std::endl;
      return;
    }

  fetch_input(in);
  in.close();
}

void cmatrix::fetch_input(std::istream &in)
{
  char line[10000];
  long int rows=0, columns=0;

  cleanup();

  status=TENSOR_FILE_HEADER_NOT_FOUND;  
  dim=2;
  
  in.getline(line,9999);
  while(!in.fail() && status==TENSOR_FILE_HEADER_NOT_FOUND)
    {
      char *ptr=stripspaces(line);

      if(*ptr=='#')
	{
	  if(sscanf(ptr+1, "%ld %ld", &rows, &columns)==2)
	    status=TENSOR_OK;
	}

      if(status!=TENSOR_OK)
	in.getline(line,9999);
    }  
  
  if(status!=TENSOR_OK)
    return;
  
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;
  initialize();

  for(long int i=0;i<totlen;i++)
    {
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
      in >> data[i];
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
    }
}

void cmatrix::fetch_input(std::istream &in, long int rows, long int columns)
{
  cleanup();
  dim=2;
  len=new long int[2];
  len[0]=rows;
  len[1]=columns;
  initialize();

  for(long int i=0;i<totlen;i++)
    {
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
      in >> data[i];
      if(in.fail())
	{
	  status=TENSOR_INSUFFICIENT_FILE_CONTENT;
	  return;
	}
    }
}

complex cmatrix::get_element(long int row_position, 
			     long int column_position) const
{
  if(row_position<0 || row_position>len[0] ||
     column_position<0 || column_position>len[1])
    return MISSING_VALUE;

  long int abspos=row_position*len[1]+column_position;

  return data[abspos];
}

complex cmatrix::operator() (long int row_position, 
			     long int column_position) const
{
  return get_element(row_position, column_position);
}

complex cmatrix::operator() (void) const
{
  if(data)
    return data[0];
  else
    return MISSING_VALUE;
}

void cmatrix::set_element(long int row_position, long int column_position,
			  complex newvalue)
{
  if(row_position<0 || row_position>len[0] ||
     column_position<0 || column_position>len[1])
    return;

  long int abspos=row_position*len[1]+column_position;

  data[abspos]=newvalue;
} 

long int cmatrix::Rows(void)
{
  return len[0];
}

long int cmatrix::Columns(void)
{
  return len[1];
}


long int Rows(const cmatrix &m)
{
  return m.len[0];
}

long int Columns(const cmatrix &m)
{
  return m.len[1];
}

complex get_element(const cmatrix &m, long int i, long int j)
{
  long int abspos=i*m.len[1]+j;
  return m.data[abspos];
}

cmatrix inverse(const cmatrix &m)
{
  #ifndef GSL
  std::cerr << "'inverse_matrix' not implemented. You need GSL!" << std::endl;
  return cmatrix();
#else
  cmatrix err;
  err.set_status(TENSOR_SIZE_MISMATCH);
  if(m.len[0]!=m.len[1])
    return err;

  long int k,l;
  int sign=1;
  complex **inverted=new complex*[m.len[0]];

  // make the return matrix;
  for(k=0;k<m.len[0];k++)
    inverted[k]=new complex[m.len[1]];

  // make GSL matrixes;
  gsl_matrix_complex *matrix=gsl_matrix_complex_alloc(m.len[0],m.len[1]);
  gsl_matrix_complex *matrix2=gsl_matrix_complex_alloc(m.len[0], 
						       m.len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(m.len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      {
	complex c=get_element(m,k,l);
	gsl_complex com=gsl_complex_rect(c.Re(), c.Im());
	gsl_matrix_complex_set(matrix, k, l,  com);
      }
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_complex_LU_decomp(matrix, perm, &sign);
  gsl_linalg_complex_LU_invert(matrix, perm, matrix2);
  
  // fetch values from the second GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      {
	gsl_complex com=gsl_matrix_complex_get(matrix2, k, l);
	inverted[k][l].set(GSL_REAL(com), GSL_IMAG(com));
      }
  
  // cleanup;
  gsl_matrix_complex_free(matrix);
  gsl_matrix_complex_free(matrix2);
  gsl_permutation_free(perm);

  cmatrix ret(inverted, m.len[0], m.len[1]);
  doubledelete(inverted, m.len[0]);

  return ret; // return the inverted matrix
#endif // GSL
}

cmatrix LU_decompose(const cmatrix &m)
{
#ifndef GSL
  std::cerr << "'LU_decompsoe' not implemented. You need GSL!" << std::endl;
  return cmatrix();
#else
  cmatrix err;
  err.set_status(TENSOR_SIZE_MISMATCH);
  if(m.len[0]!=m.len[1])
    return err;

  long int k,l;
  int sign=1;
  complex **decomp=new complex*[m.len[0]];

  // make the return matrix;
  for(k=0;k<m.len[0];k++)
    decomp[k]=new complex[m.len[1]];

  // make GSL matrixes;
  gsl_matrix_complex *matrix=gsl_matrix_complex_alloc(m.len[0],m.len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(m.len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      {
	complex c=get_element(m,k,l);
	gsl_complex com=gsl_complex_rect(c.Re(), c.Im());
	gsl_matrix_complex_set(matrix, k, l,  com);
      }
  
  // LU decompose this matrix using GSL:
  gsl_linalg_complex_LU_decomp(matrix, perm, &sign);
  
  // fetch values from the decomposed GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      {
	gsl_complex com=gsl_matrix_complex_get(matrix, k, l);
	decomp[k][l].set(GSL_REAL(com), GSL_IMAG(com));
      }
  
  // cleanup;
  gsl_matrix_complex_free(matrix);
  gsl_permutation_free(perm);

  cmatrix ret(decomp, m.len[0], m.len[1]);
  doubledelete(decomp, m.len[0]);

  return ret; // return the decomposed matrix
#endif // GSL
}


cmatrix transpose(const cmatrix &m)
{
  cmatrix ret(m.len[1], m.len[0]);
  
  for(long int i=0;i<m.len[0];i++)
    for(long int j=0;j<m.len[1];j++)
      ret.set_element(j,i, get_element(m,i,j));
    
  return ret;
}

complex trace(const cmatrix &m)
{
  long int i,l=m.len[0];
  complex ret=0.0;

  for(i=0;i<l;i++)
    ret+=get_element(m,i,i);

  return ret;
}

complex det(const cmatrix &m)
{
  return determinant(m);
}

complex determinant(const cmatrix &m)
{
#ifndef GSL
  std::cerr << "'determinant_matrix' not implemented. You need GSL!" << std::endl;
  return complex(MISSING_VALUE, MISSING_VALUE);
#else
  if(m.len[0]!=m.len[1])
    return complex(MISSING_VALUE, MISSING_VALUE);

  long int k,l;
  int sign=1;
  complex det(MISSING_VALUE, MISSING_VALUE);

  // make GSL matrixes;
  gsl_matrix_complex *matrix=gsl_matrix_complex_alloc(m.len[0], m.len[1]);
  gsl_permutation *perm=gsl_permutation_calloc(m.len[0]);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<m.len[0];k++)
    for(l=0;l<m.len[1];l++)
      {
	complex c=get_element(m,k,l);
	gsl_complex com=gsl_complex_rect(c.Re(), c.Im());
	gsl_matrix_complex_set(matrix, k, l,  com);
      }
  
  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_complex_LU_decomp(matrix, perm, &sign);
  
  gsl_complex com=gsl_linalg_complex_LU_det(matrix, sign);
  det.set(GSL_REAL(com), GSL_IMAG(com));

  // cleanup;
  gsl_matrix_complex_free(matrix);
  gsl_permutation_free(perm);

  return det; // return the determinant
#endif // GSL
}



// Routines associated with random vectors;
vector **vectorial_sample_from_multinormal(int number_of_samples, vector &expectation, 
					   Matrix &sigma)
{
  int i,j,len=expectation.size();
  
  // Check the matrix size;
  if(sigma.Rows()!=len || sigma.Columns()!=len)
    {
      std::cerr << "Mismatch between size of expectation vector and "
	"sigma matrix!" << std::endl;
      return NULL;
    }
  
  Matrix *c; // will contain the cholesky decomposition of sigma

  c=cholesky_decompose(sigma); // the colesky decomposition of sigma
  if(c->error()==TENSOR_CHOLESKY_FAILED)
    {
      delete c;
      return NULL;
    }
  for(i=0;i<len;i++) // null out the upper triangle
    for(j=i+1;j<len;j++)
      c->set_element(i,j,0);
  
  double *u=new double[len]; // buffer storage for indep. gaussian samples
  vector **ret=new vector*[number_of_samples]; // return vector array

  // fetch the samples;
  for(i=0;i<number_of_samples;i++)
    {
      ret[i]=new vector(2);

      // make a vector U~N(0,ident(len))
      for(j=0;j<len;j++)
	u[j]=gauss();
      vector X(len),U(u,len);
      
      for(j=0;j<len;j++)
	for(int j2=0;j2<len;j2++)
	  X.set_element(j, X(j)+(*c)(j,j2)*U(j2) );
      // makes a vector with the correct correlation structure
      
      for(j=0;j<len;j++)
	ret[i][0].set_element(j, X(j)+expectation(j)); 
      // put it into the return array
    }

  delete [] u;
  delete c;

  return ret;
}

double **sample_from_multinormal(int number_of_samples, double *expectation, 
				 double **sigma, int dimension, gsl_rng *rptr,
				 bool dont_keep_cholesky)
{
  if(dimension==1)
    {
      double **ret=new double*[number_of_samples];
      double s=sqrt(sigma[0][0]);

      for(int i=0;i<number_of_samples;i++)
	{
	  ret[i]=new double[1];
	  ret[i][0]=expectation[0]+s*gsl_ran_ugaussian(rptr);
	}
      
      return ret;
    }
  
  int i,j,k,len=dimension, rptr_given=1;

  if(!rptr)
    {
      rptr=gsl_rng_alloc(gsl_rng_rand48);
      gsl_rng_set(rptr, rand()); 
      rptr_given=0;
    }
  
  if(dont_keep_cholesky)
    {
      double **c=cholesky(sigma, dimension);
      if(!c)
	return NULL;
      
      double *u=new double[len], *x=new double[len];
      double **ret=new double*[number_of_samples];
      // fetch the samples;
      for(i=0;i<number_of_samples;i++)
	{
	  ret[i]=new double[len];
	  
	  // make a vector U~N(0,ident(len))
	  for(j=0;j<len;j++)
	    u[j]=gsl_ran_gaussian(rptr, 1.0);
      
	  for(j=0;j<len;j++)
	    {
	      x[j]=0.0;
	      for(k=0;k<len;k++)
		x[j]+=c[k][j]*u[k];
	      // makes a vector with the correct correlation structure
	    }
	  
	  for(j=0;j<len;j++)
	    ret[i][j]=x[j]+expectation[j];
	  // put it into the return array
	}

      if(!rptr_given)
	{
	  gsl_rng_free(rptr);
	  rptr=NULL;
	}
      
      delete [] x;
      delete [] u;
      doubledelete(c,dimension);

      return ret;
    }

  static int visited=0;
  static double **sig=NULL;
  static int dim=0;
  static double **c=NULL;
  
  if(visited || sigma!=sig ||  dim!=dimension)
    {
      if(c)
	doubledelete(c, dim);
      c=cholesky(sigma, dimension); 
      if(!c)
	return NULL;
      
      sig=sigma;
      dim=dimension;
    }

  double *u=new double[len], *x=new double[len];
  double **ret=new double*[number_of_samples];
  // fetch the samples;
  for(i=0;i<number_of_samples;i++)
    {
      ret[i]=new double[len];

      // make a vector U~N(0,ident(len))
      for(j=0;j<len;j++)
	u[j]=gsl_ran_gaussian(rptr, 1.0);
      
      for(j=0;j<len;j++)
	{
	  x[j]=0.0;
	  for(k=0;k<len;k++)
	    x[j]+=c[k][j]*u[k];
	  // makes a vector with the correct correlation structure
	}

      for(j=0;j<len;j++)
	ret[i][j]=x[j]+expectation[j];
      // put it into the return array
    }

  if(!rptr_given)
    {
      gsl_rng_free(rptr);
      rptr=NULL;
    }

  delete [] x;
  delete [] u;
  visited=1;

  return ret;
}


vector find_mean_vector(int number_of_samples, vector *samples)
{
  int i,j,len=samples[0].size();
  vector ret;
  
  // Make the vector of sum(samples);
  ret=samples[0];
  for(i=1;i<number_of_samples;i++)
    for(j=0;j<len;j++)
      ret.set_element(j, ret(j)+samples[i](j));

  // Divide by the number of samples;
  for(j=0;j<len;j++)
    ret.set_element(j, ret(j)/double(number_of_samples));
  
  return ret;
}

double *find_mean_of_vectors(int number_of_samples, double **samples, int dimension)
{
  int i,j,len=dimension;
  double *ret=new double[len];

  for(j=0;j<len;j++)
    ret[j]=0.0;

  // Make the vector of sum(samples);
  for(i=0;i<number_of_samples;i++)
    for(j=0;j<len;j++)
      ret[j]+=samples[i][j];
  
  // Divide by the number of samples;
  for(j=0;j<len;j++)
    ret[j]/=double(number_of_samples);
  
  return ret;
}

Matrix find_estimated_sigma_matrix(vector *samples, 
				   int number_of_samples)
{
  Matrix ret;
  vector mu;
  mu=find_mean_vector(number_of_samples, samples);
  
  ret=find_estimated_sigma_matrix(number_of_samples, samples, mu);

  return ret;
}

double **find_estimated_variance(int number_of_samples,
				 double **samples /* a sample of vectors */,
				 int dimension)
{
  double *mean=find_mean_of_vectors(number_of_samples, samples, dimension);
  double **ret=find_estimated_variance(number_of_samples, samples, mean, dimension);

  delete [] mean;

  return ret;
}

Matrix find_estimated_sigma_matrix(int number_of_samples,
				   vector *samples,
				   vector &expectation)
{
  int i,j,k,len=samples[0].size();
  Matrix sigma(len,len);

  // fill out the upper triangle of sigma with transpose(x-mu)*(x-mu);
  for(i=0;i<number_of_samples;i++)
    for(j=0;j<len;j++)
      for(k=j;k<len;k++)
	sigma.set_element(j,k,sigma(j,k)+(samples[i](j)-expectation(j))*
			  (samples[i](k)-expectation(k)));
  
  // Divide by the number of samples
  for(j=0;j<len;j++)
    for(k=j;k<len;k++)
      sigma.set_element(j,k,sigma(j,k)/double(number_of_samples));

  // fill out the lower triangle of sigma to make it symmetric
  for(j=0;j<len;j++)
    for(k=0;k<j;k++)
      sigma.set_element(j,k,sigma(k,j));

  return sigma;
}

double **find_estimated_variance(int number_of_samples,
				 double **samples /* a sample of vectors */,
				 double *mean, int dimension)
{
  int i,j,k,len=dimension;
  double **sigma=new double*[len];

  for(j=0;j<len;j++)
    {
      sigma[j]=new double[len];
      for(k=0;k<len;k++)
	sigma[j][k]=0.0;
    }

  // fill out the upper triangle of sigma with transpose(x-mu)*(x-mu);
  for(i=0;i<number_of_samples;i++)
    for(j=0;j<len;j++)
      for(k=j;k<len;k++)
	sigma[j][k]+=(samples[i][j]-mean[j])*
	  (samples[i][k]-mean[k]);

  // Divide by the number of samples
  for(j=0;j<len;j++)
    for(k=j;k<len;k++)
      sigma[j][k]/=double(number_of_samples);

  // fill out the lower triangle of sigma to make it symmetric
  for(j=0;j<len;j++)
    for(k=0;k<j;k++)
      sigma[j][k]=sigma[k][j];

  return sigma;
}

double multinormal_pdf(vector &x, vector &expectation, Matrix &sigma)
{
  double n=(double) x.size();
  double ret=pow(2.0*M_PI, -n/2.0);
  vector x2(x);
  Matrix inv_sigma;

  inv_sigma=sigma.inverse();
  for(int i=0;i<n;i++)
    x2.set_element(i, x(i)-expectation(i));

  ret/=sqrt(sigma.det());
  ret*=exp(-0.5*((x2*inv_sigma*x2)(0)));
  
  return ret;
}

double multinormal_pdf(double *x, double *expectation, 
		       double **sigma, int dimension,
		       bool logarithmic, bool direct_logarithm)
{
  double n=double(dimension);
  double ret=logarithmic ? -n/2.0*log(2.0*M_PI) : pow(2.0*M_PI, -n/2.0);
  double **inv_sigma=inverse_matrix(sigma, dimension);
  if(!inv_sigma)
    return MISSING_VALUE;
  
  int j,k,len=dimension;
  double SS=0.0, det=determinant_matrix(sigma, dimension, 
					logarithmic, direct_logarithm);
  if(det==MISSING_VALUE)
    {
      doubledelete(inv_sigma, dimension);
      return MISSING_VALUE;
    }
  
  for(j=0;j<len;j++)
    for(k=0;k<len;k++)
      SS += (x[j]-expectation[j])*inv_sigma[j][k]*(x[k]-expectation[k]);

  if(!logarithmic)
    ret*=exp(-0.5*SS);
  else
    ret-=0.5*SS;
  
  if(!logarithmic)
    ret/=sqrt(det);
  else
    ret-=0.5*det;

  doubledelete(inv_sigma, dimension);

  return ret;
}

double multinormal_pdf(double *x, double *expectation, 
		       int dimension, double **inv_sigma, double det_sigma,
		       bool logarithmic)
{
  double n=double(dimension);
  double ret=logarithmic ? -n/2.0*log(2.0*M_PI) : pow(2.0*M_PI, -n/2.0);
  int j,k,len=dimension;
  double SS=0.0;

  for(j=0;j<len;j++)
    for(k=0;k<len;k++)
      SS += (x[j]-expectation[j])*inv_sigma[j][k]*(x[k]-expectation[k]);

  if(!logarithmic)
    ret*=exp(-0.5*SS);
  else
    ret-=0.5*SS;
  
  if(!logarithmic)
    ret/=sqrt(det_sigma);
  else
    ret-=0.5*det_sigma; // it is assumed that the determinant is now 
			// given in logarithmic form

  return ret;
}

double multi_t_pdf(double *x, double *expectation, 
		   double **sigma, double nu, int dimension,
		   bool logarithmic, bool direct_logarithm)
{
  double n=double(dimension);
  double ret=lgamma(0.5*(nu+n))-lgamma(0.5*nu)-0.5*n*log(M_PI*nu);
  if(!logarithmic)
    ret=exp(ret);

  double **inv_sigma=inverse_matrix(sigma, dimension);
  int j,k,len=dimension;
  double SS=0.0, det=determinant_matrix(sigma, dimension, 
					logarithmic, direct_logarithm);

  for(j=0;j<len;j++)
    for(k=0;k<len;k++)
      SS += (x[j]-expectation[j])*inv_sigma[j][k]*(x[k]-expectation[k]);

  if(!logarithmic)
    ret*=pow(1.0+SS/nu,-0.5*(nu+n));
  else
    ret-=0.5*(nu+n)*log(1.0+SS/nu);
  
  if(!logarithmic)
    ret/=sqrt(det);
  else
    ret-=0.5*det;

  doubledelete(inv_sigma, dimension);

  return ret;
}

double multi_t_pdf(double *x, double *expectation, double nu, 
		   int dimension, double **inv_sigma, double det_sigma,
		   bool logarithmic)
{
  double n=double(dimension);
  double ret=lgamma(0.5*(nu+n))-lgamma(0.5*nu)-0.5*n*log(M_PI*nu);
  if(!logarithmic)
    ret=exp(ret);
  int j,k,len=dimension;
  double SS=0.0;

  for(j=0;j<len;j++)
    for(k=0;k<len;k++)
      SS += (x[j]-expectation[j])*inv_sigma[j][k]*(x[k]-expectation[k]);


  if(!logarithmic)
    ret*=pow(1.0+SS/nu,-0.5*(nu+n));
  else
    ret-=0.5*(nu+n)*log(1.0+SS/nu);
  
  if(!logarithmic)
    ret/=sqrt(det_sigma);
  else
    ret-=0.5*det_sigma; // it is assumed that the determinant is now 
			// given in logarithmic form

  return ret;
}

double **cholesky(double **matrix_, int dimension)
{
#ifndef GSL
  std::cerr << "'LU_decompsoe' not implemented. You need GSL!" << std::endl;
  return NULL;
#else
  long int k,l;
  double **decomp=new double*[dimension];

  // make the return matrix;
  for(k=0;k<dimension;k++)
    decomp[k]=new double[dimension];

  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(dimension,dimension);
  
  // Set the first GSL matrix;
  for(k=0;k<dimension;k++)
    for(l=0;l<dimension;l++)
      gsl_matrix_set(matrix, k, l, matrix_[k][l]);
  
  // LU decompose this matrix using GSL:

  gsl_set_error_handler(&cholesky_handler);
  int status=gsl_linalg_cholesky_decomp(matrix);
  gsl_set_error_handler(NULL); 
  
  if(status!=GSL_SUCCESS)
    {
      gsl_matrix_free(matrix);
      doubledelete(decomp, dimension);
      return NULL;
    }
  
  // fetch values from the decomposed GSL matrix;
  for(k=0;k<dimension;k++)
    for(l=0;l<dimension;l++)
      if(l>=k)
	decomp[k][l]=gsl_matrix_get(matrix, k, l);
      else
	decomp[k][l]=0.0;
  
  // cleanup;
  gsl_matrix_free(matrix);
  
  return decomp; // return the decomposed matrix
#endif // GSL
}


double *eigenvalues(double **matrix_, int dimension)
{
#ifndef GSL
  return NULL;
#else

  long int i,j,l=dimension;

  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      if(!almost_equal(matrix_[i][j],matrix_[j][i]))
	return NULL;

  gsl_vector *eigenvaluevector=gsl_vector_alloc(l);
  gsl_matrix *inputmatrix=gsl_matrix_alloc(l,l);

  for(i=0;i<l;i++)
    for(j=0;j<l;j++)
      gsl_matrix_set(inputmatrix,i,j,matrix_[i][j]);
      
  gsl_eigen_symm_workspace *w=gsl_eigen_symm_alloc(l);

  gsl_eigen_symm(inputmatrix,eigenvaluevector, w);
  double *evals=new double[l];
  for(i=0;i<l;i++)
    evals[i]=gsl_vector_get(eigenvaluevector,i);

  gsl_matrix_free(inputmatrix);
  gsl_vector_free(eigenvaluevector);
  gsl_eigen_symm_free(w);

  qsort(evals, l, sizeof(double), compare_double);
  
  return evals;
#endif // GSL
}



void inverse_handler(const char * /* reason */, 
		     const char * /* file */, 
		     int /* line */, 
		     int /* gsl_errno */)
{
  // NOP
}


// invert a given matrix;
double **inverse_matrix(double **matrix_, int dimension)
{
#ifndef GSL
  std::cerr << "'inverse_matrix' not implemented. You need GSL!" << std::endl;
  return NULL;
#else
  int k,l, sign=1;
  double **inverted=new double*[dimension];

  // make the return matrix;
  for(k=0;k<dimension;k++)
    inverted[k]=new double[dimension];

  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(dimension,dimension);
  gsl_matrix *matrix2=gsl_matrix_alloc(dimension,dimension);
  gsl_permutation *perm=gsl_permutation_calloc(dimension);
  
  gsl_set_error_handler(&inverse_handler);
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<dimension;k++)
    for(l=0;l<dimension;l++)
      gsl_matrix_set(matrix, k, l,  matrix_[k][l]);
  

  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  int status=gsl_linalg_LU_decomp(matrix, perm, &sign);
  if(status!=GSL_SUCCESS)
    {
      gsl_matrix_free(matrix);
      gsl_matrix_free(matrix2);
      gsl_permutation_free(perm);
      gsl_set_error_handler(NULL); 
      return NULL;
    }
  
  status=gsl_linalg_LU_invert(matrix, perm, matrix2);
  if(status!=GSL_SUCCESS)
    {
      gsl_matrix_free(matrix);
      gsl_matrix_free(matrix2);
      gsl_permutation_free(perm);
      gsl_set_error_handler(NULL); 
      return NULL;
    }
  
  // fetch values from the second GSL matrix;
  for(k=0;k<dimension;k++)
    for(l=0;l<dimension;l++)
      inverted[k][l]=gsl_matrix_get(matrix2, k, l);
  
  // cleanup;
  gsl_matrix_free(matrix);
  gsl_matrix_free(matrix2);
  gsl_permutation_free(perm);
  gsl_set_error_handler(NULL); 

  return inverted; // return the inverted matrix
#endif // GSL
}

complex **inverse_complex_matrix(complex **matrix_, int dimension)
{
#ifndef GSL
  std::cerr << "'inverse_matrix' not implemented. You need GSL!" << std::endl;
  return NULL;
#else
  long int k,l;
  int sign=1;
  complex **inverted=new complex*[dimension];

  // make the return matrix;
  for(k=0;k<dimension;k++)
    inverted[k]=new complex[dimension];
  
  // make GSL matrixes;
  gsl_matrix_complex *matrix=
    gsl_matrix_complex_alloc(dimension,dimension);
  gsl_matrix_complex *matrix2=
    gsl_matrix_complex_alloc(dimension,dimension);
  gsl_permutation *perm=gsl_permutation_calloc(dimension);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<dimension;k++)
    for(l=0;l<dimension;l++)
      gsl_matrix_complex_set(matrix, k, l,  matrix_[k][l].com);
  

  // invert this matrix using GSL, put the result in the second
  // GSL matrix;
  gsl_linalg_complex_LU_decomp(matrix, perm, &sign);
  gsl_linalg_complex_LU_invert(matrix, perm, matrix2);
  
  // fetch values from the second GSL matrix;
  for(k=0;k<dimension;k++)
    for(l=0;l<dimension;l++)
      {
	gsl_complex com=gsl_matrix_complex_get(matrix2, k, l);
	inverted[k][l].com=com;
      }
  
  // cleanup;
  gsl_matrix_complex_free(matrix);
  gsl_matrix_complex_free(matrix2);
  gsl_permutation_free(perm);

  return inverted; // return the inverted matrix
#endif // GSL
}


void determinant_handler(const char * /* reason */, 
			 const char * /* file */, 
			 int /* line */, 
			 int /* gsl_errno */)
{
  // NOP
}


// find the determinant of a given matrix;
double determinant_matrix(double **matrix_, int dimension, 
			  int logarithmic, int direct_logarithm)
{
#ifndef GSL
  std::cerr << "'determinant_matrix' not implemented. You need GSL!" << std::endl;
  return MISSING_VALUE;
#else
  int k,l, sign=1;
  double det=MISSING_VALUE;

  gsl_set_error_handler(&determinant_handler);

  // make GSL matrixes;
  gsl_matrix *matrix=gsl_matrix_alloc(dimension,dimension);
  gsl_permutation *perm=gsl_permutation_calloc(dimension);
  
  // initialize GSL permutations;
  gsl_permutation_init(perm);
  
  // Set the first GSL matrix;
  for(k=0;k<dimension;k++)
    for(l=0;l<dimension;l++)
      gsl_matrix_set(matrix, k, l,  matrix_[k][l]);
  
  // invert this matrix using GSL, put the 
  // result in the second GSL matrix;
  int status=gsl_linalg_LU_decomp(matrix, perm, &sign);
  if(status!=GSL_SUCCESS)
    {
      gsl_matrix_free(matrix);
      gsl_permutation_free(perm);
      gsl_set_error_handler(NULL); 
      return MISSING_VALUE;
    }

  if(logarithmic)
    {
      if(direct_logarithm)
	det=gsl_linalg_LU_lndet(matrix);
      else
	det=log(gsl_linalg_LU_det(matrix, sign));
    }
  else
    det=gsl_linalg_LU_det(matrix, sign);

  // cleanup;
  gsl_matrix_free(matrix);
  gsl_permutation_free(perm);
  gsl_set_error_handler(NULL); 

  return det; // return the determinant
#endif // GSL
}


double **make_matrix(int rows, int columns)
{
  int i,j;
  double **ret=new double*[rows];
  
  for(i=0;i<rows;i++)
    {
      ret[i]=new double[columns];
      for(j=0;j<columns;j++)
	ret[i][j]=0.0;
    }
  
  return ret;
}

complex **make_complex_matrix(int rows, int columns)
{
  int i,j;
  complex **ret=new complex*[rows];
  
  for(i=0;i<rows;i++)
    {
      ret[i]=new complex[columns];
      for(j=0;j<columns;j++)
	ret[i][j]=0.0;
    }

  return ret;
}

double **multiply_matrices(double **mat1, double **mat2, 
			   int rows1, int col1_rows2, int col2)
{
  int i,j,k;
  double **ret=make_matrix(rows1, col2);
  
  for(i=0;i<rows1;i++)
    for(j=0;j<col2;j++)
      for(k=0;k<col1_rows2;k++)
	ret[i][j]=mat1[i][k]*mat2[k][j];

  return ret;
}

double **multiply_matrices_seconds_is_transposed(double **mat1, double **mat2, 
						 int rows1, int col1_col2, int rows2)
{
  int i,j,k;
  double **ret=make_matrix(rows1, rows2);
  
  for(i=0;i<rows1;i++)
    for(j=0;j<rows2;j++)
      for(k=0;k<col1_col2;k++)
	ret[i][j]=mat1[i][k]*mat2[j][k];

  return ret;
}

double **multiply_matrices_first_is_transposed(double **mat1, double **mat2, 
					       int col1, int rows1_rows2, int col2)
{
  int i,j,k;
  double **ret=make_matrix(col1, col2);
  
  for(i=0;i<col1;i++)
    for(j=0;j<col2;j++)
      for(k=0;k<rows1_rows2;k++)
	ret[i][j]=mat1[k][i]*mat2[k][j];

  return ret;
}




// check if a matrix has non-zero diagonal elements
bool is_diagonal(double **A, int size)
{
  bool ret=true;
  
  for(int i=0;i<size && ret;i++)
    if(ABSVAL((A[i][i]))<1e-10)
      ret=false;
  
  return ret;
}

// check if a matrix has non-zero diagonal elements
bool is_diagonal(complex **A, int size)
{
  bool ret=true;
  
  for(int i=0;i<size && ret;i++)
    if(A[i][i].abs2()<1e-20)
      ret=false;
  
  return ret;
}


#ifndef NVE // NVE has not sufficiently upgraded GSL

// Returns right eigenvectors matrices. Not necessaary to have
// symmetric input matrices, but returns NULL if the results
// are complex:
double **get_eigenvector_matrix(double **A, int size, double **lambda, 
				int talkative)
{
  // Find the eigenvectors and eigenvalues:
  Matrix Amat(A,size,size);
  cmatrix Acmat(Amat);
  complex *lambda_complex;
  cmatrix Vinv_cmat=Acmat.eigenvectors_as_matrix(&lambda_complex);
  
  int i,j;

  // check if there are complex eigenvalues:
  for(i=0;i<size;i++)
    if(ABSVAL((lambda_complex[i].Im()))>0.001)
      {
	if(talkative)
	  cout << i << "th eigenvalue has imaginary component, lambda" << 
	    i << "=(" << lambda_complex[i].Re() << "," << 
	    lambda_complex[i].Im() << ")" << std::endl;
	return NULL;
      }

  // fill out the eigenvalue vector:
  *lambda=new double[size];
  for(i=0;i<size;i++)
    (*lambda)[i]=lambda_complex[i].Re();

  // check if there are complex eigenvector values:
  for(i=0;i<size;i++)
    for(j=0;j<size;j++)
      if(ABSVAL((Vinv_cmat.get_element(i,j).Im()))>0.001)
	{
	  if(talkative)
	    cout << i << "," << j << 
	      "th eigenvector component has imaginary component, "
	      "Vinv_" << i << "," << j << "=(" <<
	      Vinv_cmat.get_element(i,j).Re() << "," <<
	      Vinv_cmat.get_element(i,j).Im() << ")" << std::endl;
	  return NULL;
	}

  // Make the eigenvector matrix:
  double **Vinv=new double*[size]; 
  for(i=0;i<size;i++)
    {
      Vinv[i]=new double[size];

      for(j=0;j<size;j++)
	Vinv[i][j]=Vinv_cmat.get_element(i,j).Re();
    }
  double **V=inverse_matrix(Vinv,size);
  
  delete [] lambda_complex;
  doubledelete(Vinv,size);
  
  return V;
}



// Returns right eigenvectors matrices. Not necessaary to have
// symmetric input matrices:
complex **get_complex_eigenvector_matrix(double **A, int size, 
					 complex **lambda, 
					 int talkative, 
					 int sparseness_iterations)
{
  // Find the eigenvectors and eigenvalues:
  Matrix Amat(A,size,size);
  cmatrix Acmat(Amat);
  complex *lambda_complex;
  cmatrix Vinv_cmat=Acmat.eigenvectors_as_matrix(&lambda_complex);
  bool order_failed=false;
  
  int i,j,k;
  
  // Make the eigenvector matrix:
  complex **Vinv=make_complex_matrix(size,size); 
  for(i=0;i<size;i++)
    for(j=0;j<size;j++)
      Vinv[i][j]=Vinv_cmat.get_element(i,j);
  
  if(sparseness_iterations>0)
    {
      complex *vbuff=new complex[size], lambda_buff;
      
      double maxval=0.0;
      for(i=0;i<size;i++)
	for(j=0;j<size;j++)
	  maxval=MAXIM(maxval, Vinv[i][j].abs2());
      
      for(i=0;i<size;i++)
	for(j=0;j<size;j++)
	  if(Vinv[i][j].abs2()<maxval*1e-17)
	    Vinv[i][j]=0.0;

      k=0;
      while(k<sparseness_iterations && !is_diagonal(Vinv,size))
	{
	  int index1=(int) floor(drand48()*double(size)), index2;
	  
	  if(Vinv[index1][index1].abs2()<maxval*1e-20)
	    {
	      do
		index2=(int) floor(drand48()*double(size));
	      while(index2==index1);
	      
	      if(Vinv[index2][index1].abs2()>=1e-20*maxval) // &&
		 //(Vinv[index2][index2].abs2()<1e-20*maxval || 
		//Vinv[index1][index2].abs2()>=1e-20*maxval))
		{
		  lambda_buff=lambda_complex[index2];
		  lambda_complex[index2]=lambda_complex[index1];
		  lambda_complex[index1]=lambda_buff;
		  
		  for(i=0;i<size;i++)
		    vbuff[i]=Vinv[i][index2];
		  for(i=0;i<size;i++)
		    Vinv[i][index2]=Vinv[i][index1];
		  for(i=0;i<size;i++)
		    Vinv[i][index1]=vbuff[i];
		}
	    }
	  
	  k++;
	}
      
      if(!is_diagonal(Vinv,size))
	order_failed=true;

      delete [] vbuff;
    }


  if(order_failed)
    {
      cout << "Eigenvector-decomposition: order failed!" << std::endl;
      //exit(0);
    }
      
  

  complex **V=inverse_complex_matrix(Vinv,size);
  
  if(talkative)
    {
      int i2,j2;

      cout << "lambda=c(";
      for(i2=0;i2<size;i2++)
	{
	  cout << lambda_complex[i2];
	  if(i2!=(size-1))
	    cout << ",";
	}
      cout << ")" << std::endl;

      cout << "Vinv=t(matrix(c(";
      for(i2=0;i2<size;i2++)
	{
	  for(j2=0;j2<size;j2++)
	    {
	      cout << Vinv[i2][j2];
	      if(i2!=(size-1) || j2!=(size-1))
		cout << ",";
	    }
	}
      cout << "), nrow=" << size << "))" << std::endl;

      cout << "V=t(matrix(c(";
      for(i2=0;i2<size;i2++)
	{
	  for(j2=0;j2<size;j2++)
	    {
	      cout << V[i2][j2];
	      if(i2!=(size-1) || j2!=(size-1))
		cout << ",";
	    }
	}
      cout << "), nrow=" << size << "))" << std::endl;
    }

  *lambda=lambda_complex;
  doubledelete(Vinv,size);
  
  return V;
}

#endif // NVE has not sufficiently upgraded GSL


/*
// Returns right eigenvectors matrices. Not necessaary to have
// symmetric input matrices:
complex **get_complex_eigenvector_matrix(double **A, int size, 
					 complex **lambda, 
					 int talkative, 
					 int sparseness_iterations)
{
  // Find the eigenvectors and eigenvalues:
  Matrix Amat(A,size,size);
  cmatrix Acmat(Amat);
  complex *lambda_complex;
  cmatrix Vinv_cmat=Acmat.eigenvectors_as_matrix(&lambda_complex);
  
  int i,j,k;

  // Make the eigenvector matrix:
  complex **Vinv=make_complex_matrix(size,size); 
  for(i=0;i<size;i++)
    for(j=0;j<size;j++)
      Vinv[i][j]=Vinv_cmat.get_element(i,j);
  
  
  bool order_failed=false;
  // Sparseness considerations
  int *order=new int[size];
  for(i=0;i<size && !order_failed;i++)
    {
      double *contrib_index=new double[size];

      for(j=0;j<size;j++)
	{
	  double len_other=0.0;
	  for(k=0;k<size;k++)
	    if(k!=i)
	      len_other+=Vinv[k][j].abs2();
	  contrib_index[j]=sqrt(Vinv[i][j].abs2()/len_other);
	}
      
      int largest_index=-1;
      double largest=0.0;
      for(j=0;j<size;j++)
	if(contrib_index[j]>largest)
	  {
	    int found=0;
	    for(k=0;k<i && !found;k++)
	      if(order[k]==j)
		found=1;
	    if(!found)
	      {
		largest=contrib_index[j];
		largest_index=j;
	      }
	  }

      if(largest_index<0)
	{
	  //cout << "Failed to find nonzero elements in row " <<i << "!" << std::endl;
	  order_failed=true;
	}
      order[i]=largest_index;

      delete [] contrib_index;
    }

  if(order_failed)
    {
      order_failed=false;
      for(i=(size-1);i>=0 && !order_failed;i--)
	{
	  double *contrib_index=new double[size];
	  
	  for(j=0;j<size;j++)
	    {
	      double len_other=0.0;
	      for(k=0;k<size;k++)
		if(k!=i)
		  len_other+=Vinv[k][j].abs2();
	      contrib_index[j]=sqrt(Vinv[i][j].abs2()/len_other);
	    }
	  
	  int largest_index=-1;
	  double largest=0.0;
	  for(j=0;j<size;j++)
	    if(contrib_index[j]>largest)
	      {
		int found=0;
		for(k=(size-1);k>i && !found;k--)
		  if(order[k]==j)
		    found=1;
		if(!found)
		  {
		    largest=contrib_index[j];
		    largest_index=j;
		  }
	      }
	  
	  if(largest_index<0)
	    {
	      cout << "Failed to find nonzero elements in row " <<i << "!" << std::endl;
	      order_failed=true;
	    }
	  order[i]=largest_index;
	  
	  delete [] contrib_index;
	}
    }


  for(i=0;i<size && !order_failed;i++)
    for(j=0;j<size && !order_failed;j++)
      if(i!=j && order[i]==order[j])
	order_failed=true;

  if(order_failed)
    {
      cout << "Eigenvector-decomposition: order failed!" << std::endl;
      //exit(0);
    }
  else
    {
      complex **Vinv_buff=make_complex_matrix(size,size);
      complex *lambda_buff=new complex[size];
      for(i=0;i<size;i++)
	lambda_buff[i]=lambda_complex[order[i]];
      for(i=0;i<size;i++)
	for(j=0;j<size;j++)
	  Vinv_buff[i][j]=Vinv[i][order[j]];
      
      for(i=0;i<size;i++)
	lambda_complex[i]=lambda_buff[i];
      for(i=0;i<size;i++)
	for(j=0;j<size;j++)
	  Vinv[i][j]=Vinv_buff[i][j];
      delete [] lambda_buff;
      doubledelete(Vinv_buff,size);
    }
      
  

  complex **V=inverse_complex_matrix(Vinv,size);
  
  if(talkative)
    {
      int i2,j2;

      cout << "lambda=c(";
      for(i2=0;i2<size;i2++)
	{
	  cout << lambda_complex[i2];
	  if(i2!=(size-1))
	    cout << ",";
	}
      cout << ")" << std::endl;

      cout << "Vinv=t(matrix(c(";
      for(i2=0;i2<size;i2++)
	{
	  for(j2=0;j2<size;j2++)
	    {
	      cout << Vinv[i2][j2];
	      if(i2!=(size-1) || j2!=(size-1))
		cout << ",";
	    }
	}
      cout << "), nrow=" << size << "))" << std::endl;

      cout << "V=t(matrix(c(";
      for(i2=0;i2<size;i2++)
	{
	  for(j2=0;j2<size;j2++)
	    {
	      cout << V[i2][j2];
	      if(i2!=(size-1) || j2!=(size-1))
		cout << ",";
	    }
	}
      cout << "), nrow=" << size << "))" << std::endl;
    }

  *lambda=lambda_complex;
  doubledelete(Vinv,size);
  
  return V;
}
*/

void print_matrix(double **A, int rows, int columns, char *name)
{
  std::cout << name << ":" << std::endl;
  if(columns<=8)
    {
      for(int i=0;i<rows;i++)
	{
	  std::cout << i << ":";
	  for(int j=0;j<columns;j++)
	    std::cout << A[i][j] << " ";
	  std::cout << std::endl;
	}
    }
  else
    {
      for(int i=0;i<rows;i++)
	{
	  for(int j=0;j<columns;j++)
	    std::cout << name << "[" << i << "," << j << "]=" <<
	      A[i][j] << std::endl;
	}
    }
}

void print_complex_matrix(complex **A, int rows, int columns, char *name)
{
  std::cout << name << ":" << std::endl;
  if(columns<=8)
    {
      for(int i=0;i<rows;i++)
	{
	  std::cout << i << ":";
	  for(int j=0;j<columns;j++)
	    std::cout << A[i][j] << " ";
	  std::cout << std::endl;
	}
    }
  else
    {
      for(int i=0;i<rows;i++)
	{
	  for(int j=0;j<columns;j++)
	    std::cout << name << "[" << i << "," << j << "]=" <<
	      A[i][j] << std::endl;
	}
    }
}

void print_vector(double *v, int length, char *name)
{
  if(length<=8)
    {
      std::cout << name << "=";
      for(int i=0;i<length;i++)
	std::cout << v[i] << " ";
      std::cout << std::endl;
    }
  else
    {
      for(int i=0;i<length;i++)
	std::cout << name << "[" << i << "]=" << v[i] << std::endl;
    }
}

void print_complex_vector(complex *v, int length, char *name)
{
  if(length<=8)
    {
      std::cout << name << "=";
      for(int i=0;i<length;i++)
	std::cout << v[i] << " ";
      std::cout << std::endl;
    }
  else
    {
      for(int i=0;i<length;i++)
	std::cout << name << "[" << i << "]=" << v[i] << std::endl;
    }
}
