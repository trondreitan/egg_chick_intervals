/*
 * $Id: stagedischarge.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/stagedischarge.C $
 */

#include <hydrasub/hydrabase/stagedischarge.H>
#include <fstream>
#include <cmath>
#include <hydrasub/hydrabase/divfunc.H>
#include <hydrasub/hydrabase/regression.H>

// ********************************************
//
//             STAGEDISCHARGE
//
// A module for reading and representing 
// stage/discharge measurements.
//
//      Made by Trond Reitan
//         10/5-2005
//
// ********************************************
 


int compare_sd_h(const void *i, const void *j) 
{
  StageDischarge *sd1=(StageDischarge *) i;
  StageDischarge *sd2=(StageDischarge *) j;

  double v =  sd1->h - sd2->h;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compare_sd_h */


int compare_sd_q(const void *i, const void *j) 
{
  StageDischarge *sd1=(StageDischarge *) i;
  StageDischarge *sd2=(StageDischarge *) j;

  double v =  sd1->q - sd2->q;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compare_sd_q */


int compare_sd_dt(const void *i, const void *j) 
{
  StageDischarge *sd1=(StageDischarge *) i;
  StageDischarge *sd2=(StageDischarge *) j;

  int v =  sd1->dt.difference_minutes(sd2->dt);
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compare_sd_dt */

void sort_sd_array_by_stage(StageDischarge *sd, int len)
{
  qsort(sd, size_t(len), sizeof(StageDischarge), compare_sd_h);
}

void sort_sd_array_by_discharge(StageDischarge *sd, int len)
{
  qsort(sd, size_t(len), sizeof(StageDischarge), compare_sd_q);
}

void sort_sd_array_by_time(StageDischarge *sd, int len)
{
  qsort(sd, size_t(len), sizeof(StageDischarge), compare_sd_dt);
}


sd_list::sd_list(sd_list *prev, double q_, double h_, DateTime d_) :
  double_linked_list((double_linked_list *) prev, NULL)
{
  q=q_;
  h=h_;
  dt=d_;
}

sd_list *sd_list::suc(void)
{
  return (sd_list *) getnext();
}

double *sd_list::get_q(int &num)
{
  num=number_of_elements();
  double *q=new double[num];
  int i=0;

  for(sd_list *ptr=this; ptr; ptr=ptr->suc())
    q[i++]=ptr->q;

  return q;
}

double *sd_list::get_h(int &num)
{
  num=number_of_elements();
  double *h=new double[num];
  int i=0;

  for(sd_list *ptr=this; ptr; ptr=ptr->suc())
    h[i++]=ptr->h;

  return h;
}

DateTime *sd_list::get_dt(int &num)
{
  num=number_of_elements();
  DateTime *dt=new DateTime[num];
  int i=0;

  for(sd_list *ptr=this; ptr; ptr=ptr->suc())
    dt[i++]=ptr->dt;

  return dt;
}


// Returns a StageDischarge array of the contents of a file
// along with array length, zeropoint (if found, if not MISSING_VALUE)
// and possible error messages;
StageDischarge *get_sd_file(const char *filename, int *length,
			    char *errmsg, double *zeropoint)
{
    std::ifstream in;
  int i,len;
  char line[1000];
  sd_list *head=NULL, *tail=NULL;
     
  *length=0;
  if(errmsg)
    strcpy(errmsg,"");
                                                                
  in.open(filename, std::ios::in);
  if(in.fail())
    {
      if(errmsg)
	sprintf(errmsg, "Couldn't read file %s!", filename);
      return NULL;
    }

  if(zeropoint)
    *zeropoint=MISSING_VALUE;
  int numzero=0;

  in.getline(line,999);
  while(!in.fail())
    {
      int y,m,d,h,min;
      double s,q;
                                           
      if(line[0]!='\"' && line[0]!='#')
        {
          
          if(sscanf(line, "%d/%d/%d %d:%d %lf %lf", 
		    &d, &m, &y, &h,&min,&s, &q)==7 ||
	     sscanf(line, "%d.%d.%d %d:%d %lf %lf", 
		    &d, &m, &y, &h,&min,&s, &q)==7)
	    {
	      DateTime dt(y,m,d,h,min);

	      if(q>=MIN_Q || !zeropoint)
		tail=new sd_list(tail, q,s,dt);
	      else
		{
		  numzero++;
		  if(zeropoint)
		    *zeropoint=s;
		}
	    }
	  else if(sscanf(line, "%d/%d/%d %lf %lf", &d, &m, &y, &s, &q)==5 ||
		  sscanf(line, "%d.%d.%d %lf %lf", &d, &m, &y, &s, &q)==5)
	    {
	      DateTime dt(y,m,d,12,00);

	      if(q>MIN_Q || !zeropoint)
		tail=new sd_list(tail, q,s,dt);
	      else
		{
		  numzero++;
		  if(zeropoint)
		    *zeropoint=s;
		}
	    }
          else if(sscanf(line, "%lf %lf", &s, &q)==2)
	    {
	      if(q>MIN_Q || !zeropoint)
		tail=new sd_list(tail, q, s, NoDateTime);
	      else
		{
		  numzero++;
		  if(zeropoint)
		    *zeropoint=s;
		}
	    }

	  if(numzero>1)
	    {
	      if(errmsg)
		sprintf(errmsg, "More than one zero-point found!");
	      return NULL;
	    }
              
          if(!head)
            head=tail;
        }
                                                           
      in.getline(line,999);
    }
  in.close();
                                                           
  if(!head)
    {
	std::cout << "No readable contents in the file " << filename << std::endl;
      return NULL;
    }
                                                           
  len=head->number_of_elements();
  *length=len;
  StageDischarge *sd=new StageDischarge[len];
  i=0;
  for(sd_list *ptr=head; ptr; ptr=(sd_list *) ptr->getnext())
    {
      sd[i].q=ptr->q;
      sd[i].h=ptr->h;
      sd[i].dt=ptr->dt;
      i++;
    }
 
  delete head;
  return sd;
}

void sd_to_file(StageDischarge *sd, int length, const char *filename, const char *header)
{
  FILE *f=fopen(filename, "w");
  if(!f)
    {
      printf("Could not open file \"%s\"\n", filename);
      return;
    }

  if(header)
    fprintf(f,"# %s\n", header);
  for(int i=0;i<length;i++)
    fprintf(f,"%02d/%02d/%04d %02d:%02d %f %f\n", sd[i].dt.getDay(),
	   sd[i].dt.getMonth(),sd[i].dt.getYear(),sd[i].dt.getHour(),
	   sd[i].dt.getMinute(),sd[i].h, sd[i].q);
  fclose(f);
}


// Returns the minimal stage value in the StageDischarge array;
double minh(StageDischarge *sd, int len)
{
  double min=sd[0].h;
   
  for(int i=1;i<len;i++)
    min=MINIM(min, sd[i].h);
 
  return min;
}

 
void frequentistic_curve_fit::init(void)
{
  q=NULL;
  h=NULL;
  num_meas=0;
  a=b=c=sigma2=MISSING_VALUE;
}

void frequentistic_curve_fit::cleanup(void)
{
  if(q)
    delete [] q;
  if(h)
    delete [] h;
  init();
}

  
frequentistic_curve_fit::frequentistic_curve_fit()
{
  init();
}

frequentistic_curve_fit::~frequentistic_curve_fit()
{
  cleanup();
}

bool frequentistic_curve_fit::fit_curve(double *stage, double *discharge, 
					   int number_of_measurements)
{
  cleanup();

  int i;
  double minh=find_statistics(stage, number_of_measurements, MIN);
  
  num_meas=number_of_measurements;
  q=new double[num_meas];
  h=new double[num_meas];
  for(i=0;i<num_meas;i++)
    {
      q[i]=discharge[i];
      h[i]=stage[i];
    }
  
  double *x=new double[num_meas], *y=new double[num_meas];
  double best_ss=MISSING_VALUE, step=0.01, curr_c;

  for(i=0;i<num_meas;i++)
    y[i]=log(q[i]);

  for(curr_c=-minh+step;curr_c<-minh+100.0; curr_c+=step)
    {
      for(i=0;i<num_meas;i++)
	x[i]=log(h[i]+curr_c);
      
      regression_result *reg=get_regression(&x, 1, y, num_meas);
      
      double curr_ss=reg->get_sum_of_square_residuals();

      if(best_ss==MISSING_VALUE || curr_ss<best_ss)
	{
	  a=reg->get_coefficient(0);
	  b=reg->get_coefficient(1);
	  c=curr_c;
	  sigma2=reg->get_square_standard_deviation();
	  best_ss=curr_ss;
	}

      delete reg;
    }

  delete [] x;
  delete [] y;

  if(c>=-minh+100.0-step || c<=-minh+step)
    return false;
  else
    return true;
}

bool frequentistic_curve_fit::fit_curve(StageDischarge *sd, 
					   int number_of_measurements)
{
  int i, len=number_of_measurements;
  double *qq=new double[len], *hh=new double[len];

  for(i=0;i<len;i++)
    {
      qq[i]=sd[i].q;
      hh[i]=sd[i].h;
    }

  bool ret=fit_curve(hh,qq,len);

  delete [] qq;
  delete [] hh;

  return ret;
}

double frequentistic_curve_fit::get_fitted_a(void)
{
  return a;
}

double frequentistic_curve_fit::get_fitted_b(void)
{
  return b;
}

double frequentistic_curve_fit::get_fitted_c(void)
{
  return c;
}

double frequentistic_curve_fit::get_fitted_sigma2(void)
{
  return sigma2;
}

// predict:
double frequentistic_curve_fit::get_discharge(double stage)
{
  if(stage+c>0.0)
    return exp(a+b*log(stage+c));
  else
    return 0.0;
}

double frequentistic_curve_fit::get_stage(double discharge)
{
  if(discharge>0.0)
    return -c+pow(discharge*exp(-a), 1.0/b);
  else
    return -c;
}

// fetch measurements:
int frequentistic_curve_fit::get_number_of_measurements(void)
{
  return num_meas;
}

double *frequentistic_curve_fit::get_stage_measurements(void)
{
  return h;
}

double *frequentistic_curve_fit::get_discharge_measurements(void)
{
  return q;
}



ratingcurve_period::ratingcurve_period()
{
  defined=false;
  a=b=h0=hs=NULL;
  num_seg=0;
}

ratingcurve_period::ratingcurve_period(ratingcurve_period *orig)
{
  defined=true;
  startdt=orig->startdt;
  enddt=orig->enddt;
  minh=orig->minh;
  maxh=orig->maxh;
  num_seg=orig->num_seg;

  a=new double[num_seg];
  b=new double[num_seg];
  h0=new double[num_seg];
  if(num_seg>1)
    hs=new double[num_seg-1];
  else
    hs=NULL;

  for(int i=0;i<num_seg;i++)
    {
      a[i]=orig->a[i];
      b[i]=orig->b[i];
      h0[i]=orig->h0[i];
      if(i<(num_seg-1))
	hs[i]=orig->hs[i];
    }
}

ratingcurve_period::ratingcurve_period(DateTime start_time, DateTime end_time, 
		   double h_min, double h_max, int number_of_segments,
		   double *a_, double *b_, double *h0_, double *hs_)
{
  defined=true;
  startdt=start_time;
  enddt=end_time;
  minh=h_min;
  maxh=h_max;
  num_seg=number_of_segments;

  a=new double[num_seg];
  b=new double[num_seg];
  h0=new double[num_seg];
  if(num_seg>1)
    hs=new double[num_seg-1];
  else
    hs=NULL;

  for(int i=0;i<num_seg;i++)
    {
      a[i]=a_[i];
      b[i]=b_[i];
      h0[i]=h0_[i];
      if(i<(num_seg-1))
	hs[i]=hs_[i];
    }
}

ratingcurve_period::~ratingcurve_period()
{
  if(defined)
    {
      if(a)
	delete [] a;
      a=NULL;
      if(b)
	delete [] b;
      b=NULL;
      if(h0)
	delete [] h0;
      h0=NULL;
      if(hs)
	delete [] hs;
      hs=NULL;
    }
}

bool ratingcurve_period::is_defined(void)
{
  return defined;
}
  
double ratingcurve_period::get_a(int segment_number)
{
  if(segment_number>=0 && segment_number<num_seg)
    return a[segment_number];
  else
    return MISSING_VALUE;
}

double ratingcurve_period::get_b(int segment_number)
{
  if(segment_number>=0 && segment_number<num_seg)
    return b[segment_number];
  else
    return MISSING_VALUE;
}

double ratingcurve_period::get_h0(int segment_number)
{
  if(segment_number>=0 && segment_number<num_seg)
    return h0[segment_number];
  else
    return MISSING_VALUE;
}

double ratingcurve_period::get_hs(int lower_segment_number)
{
  if(lower_segment_number>=0 && lower_segment_number<(num_seg-1))
    return hs[lower_segment_number];
  else
    return MISSING_VALUE;
}

DateTime ratingcurve_period::get_start_time(void)
{
  return startdt;
}

DateTime ratingcurve_period::get_end_time(void)
{
  return enddt;
}

double ratingcurve_period::get_h_min(void)
{
  return minh;
}

double ratingcurve_period::get_h_max(void)
{
  return maxh;
}

int ratingcurve_period::get_number_of_segments(void)
{
  return num_seg;
}

int ratingcurve_period::get_num_seg(void)
{
  return num_seg;
}

double ratingcurve_period::get_stage(double discharge)
{
  int i;
  
  if(discharge<=0)
    return h0[0];

  for(i=0;i<num_seg;i++)
    {
      double hmax=(i<(num_seg-1)) ? hs[i] : maxh;
      double hmin=(i>0) ? hs[i-1] : h0[0];
      double qmax=get_discharge(hmax);
      double qmin=get_discharge(hmin);
      
      if(discharge>qmin && discharge<=qmax)
	return h0[i]+exp((discharge-a[i])/b[i]);
    }

  return MISSING_VALUE;
}

double ratingcurve_period::get_discharge(double stage)
{
  int i;
  
  if(stage<=h0[0])
    return 0.0;

  for(i=0;i<num_seg;i++)
    {
      double hmax=(i<(num_seg-1)) ? hs[i] : maxh;
      double hmin=(i>0) ? hs[i-1] : h0[0];

      if(stage>hmin && stage<=hmax && stage>=h0[i])
	return exp(a[i]+b[i]*log(stage-h0[i]));
    }

  return MISSING_VALUE;
}

