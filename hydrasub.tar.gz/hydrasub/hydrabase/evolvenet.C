/*
 * $Id: evolvenet.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/evolvenet.C $
 */

#include <sys/time.h>
#include <signal.h>
#include <hydrasub/hydrabase/evolvenet.H>
#include <hydrasub/hydrabase/divfunc.H>
#include <cmath>
#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

FILE *evolvenet::file=NULL;
int evolvenet::runindex=0;
int evolvenet::numnet=0;
bool evolvenet::exit_controlled = false;
int evolvenet::save_index=1;
evolvenet *evolvenet::follow=NULL;
int evolvenet::masterindex=1;
int evolvenet::num_in=0;
int evolvenet::num_out=0;

void evolvenet::debug(char *msg)
{
    std::cerr << msg << std::endl;
}


int evolvenet::comp_rep(const void *ptr1, const void *ptr2)
{
  evolvenet *rs1=*((evolvenet **) ptr1);
  evolvenet *rs2=*((evolvenet **) ptr2);

  if(rs1->payoff>rs2->payoff)
    return -1;
  else if(rs2->payoff>rs1->payoff)
    return 1;
  else
    return 0;
}

void evolvenet::init(void)
{
  register int i;

  payoff=-2.0;
  maxpayoff=-2.0;
  meanpayoff=0.0;
  previous_payoff=0.0;
  payofchoice = (int) (drand48()*2.0);
  numiter=iterindex=0;
  numchildren=0;
  generation_time=0.0;
  processing_time=0.0;

  savecreature = new evolvenet_creature(NULL);

  savecreature->father = father ? father->savecreature : NULL;
  savecreature->mother = mother ? mother->savecreature : NULL;
  savecreature->age=0;
  savecreature->start=startgen;
  savecreature->t0=t0;

  savecreature->index = masterindex;
  masterindex++;
  savecreature->findex = father ? father->savecreature->index : 0;
  savecreature->mindex = mother ? mother->savecreature->index : 0;

  savecreature->lastpayoff      = 0.0;
  savecreature->meanpayoff      = 0.0;
  savecreature->maxpayoff       = 0.0;
  savecreature->numcromo    = 0;
  savecreature->point       = 0.0;
  savecreature->point1      = 0.0;
  savecreature->point2      = 0.0;
  savecreature->line        = 0.0;
  savecreature->line1       = 0.0;
  savecreature->line2       = 0.0;
  savecreature->flip        = 0.0;
  savecreature->negate      = 0.0;
  savecreature->linelen     = 0.0;
  savecreature->globaln     = 0;
  savecreature->maxgen = 0;
  savecreature->gender      = 0;
  savecreature->numnodes    = 0.0;
  savecreature->numthreads  = 0.0;
  savecreature->complexity  = savecreature->numnodes+savecreature->numthreads;
  savecreature->numinternal = 0.0;
  savecreature->numchildren = 0.0;
  savecreature->alive=1;
  savecreature->repair=0;
  savecreature->firstrepair=0;
  savecreature->imported=0.0;

  if(savecreature->father && 
     (savecreature->father->start+savecreature->father->age)<startgen)
    debug("Father out of line!");

  if(savecreature->mother && savecreature->mother!=savecreature->father &&
     (savecreature->mother->start+savecreature->mother->age)<startgen)
    debug("Mother out of line!");


  if(rsptr)
    {
      nn=rsptr->get_neural_net();
      complexity=nn->get_number_of_nodes()+
	nn->get_number_of_threads();
      
      savecreature->variablemutaterate = rsptr->get_variable_mutation_rate();
      savecreature->variablemutatesize = rsptr->get_variable_mutation_size();

      savecreature->th_r = rsptr->get_standard_thread()->get_r();
      savecreature->th_m = rsptr->get_standard_thread()->get_m(); 
      savecreature->th_a = rsptr->get_standard_thread()->get_a(); 
      savecreature->th_f0 = rsptr->get_standard_thread()->get_f0(); 
      savecreature->th_g = rsptr->get_standard_thread()->get_g(); 
      savecreature->th_d = rsptr->get_standard_thread()->get_d();
      savecreature->int_r = rsptr->get_standard_internal()->get_r(); 
      savecreature->int_m = rsptr->get_standard_internal()->get_m(); 
      savecreature->int_x0 = rsptr->get_standard_internal()->get_x0(); 
      savecreature->int_l = rsptr->get_standard_internal()->get_l(); 
      savecreature->int_gam = rsptr->get_standard_internal()->get_gamma(); 
      savecreature->int_d = rsptr->get_standard_internal()->get_d(); 
      savecreature->int_g = rsptr->get_standard_internal()->get_g();
      savecreature->int_reload = rsptr->get_standard_internal()->get_reload(); 
      savecreature->int_fatigue_level = 
	rsptr->get_standard_internal()->get_fatigue_level(); 
      savecreature->int_fatigue_decrease = 
	rsptr->get_standard_internal()->get_fatigue_decrease();
      savecreature->out_r = rsptr->get_standard_out()->get_r(); 
      savecreature->out_m = rsptr->get_standard_out()->get_m(); 
      savecreature->out_x0 = rsptr->get_standard_out()->get_x0(); 
      savecreature->out_l = rsptr->get_standard_out()->get_l(); 
      savecreature->out_gam = rsptr->get_standard_out()->get_gamma(); 
      savecreature->out_d = rsptr->get_standard_out()->get_d(); 
      savecreature->out_g = rsptr->get_standard_out()->get_g();
      savecreature->out_reload = rsptr->get_standard_out()->get_reload(); 
      savecreature->out_fatigue_level = 
	rsptr->get_standard_out()->get_fatigue_level(); 
      savecreature->out_fatigue_decrease = 
	rsptr->get_standard_out()->get_fatigue_decrease();
      savecreature->outL = rsptr->get_outl();
      savecreature->outX0 = rsptr->get_outx0();
      savecreature->num_ACTIVATE = rsptr->get_num_instruction(ACTIVATE); 
      savecreature->num_DEACTIVATE = rsptr->get_num_instruction(DEACTIVATE); 
      savecreature->num_ACTIVATEL = rsptr->get_num_instruction(ACTIVATEL); 
      savecreature->num_DEACTIVATEL = rsptr->get_num_instruction(DEACTIVATEL);
      savecreature->num_CHN = rsptr->get_num_instruction(CHN); 
      savecreature->num_CHNPROS = rsptr->get_num_instruction(CHNPROS); 
      savecreature->num_CHNODE = rsptr->get_num_instruction(CHNODE); 
      savecreature->num_CHSTTHREAD = rsptr->get_num_instruction(CHSTTHREAD); 
      savecreature->num_CHALLTH = rsptr->get_num_instruction(CHALLTH); 
      savecreature->num_CHTHREAD = rsptr->get_num_instruction(CHTHREAD); 
      savecreature->num_STOP = rsptr->get_num_instruction(STOP); 
      savecreature->num_REM = rsptr->get_num_instruction(REM); 
      savecreature->num_REM1 = rsptr->get_num_instruction(REM1); 
      savecreature->num_REM2 = rsptr->get_num_instruction(REM2);
      savecreature->num_IF1 = rsptr->get_num_instruction(IF1); 
      savecreature->num_IF2 = rsptr->get_num_instruction(IF2); 
      savecreature->num_IF3 = rsptr->get_num_instruction(IF3); 
      savecreature->num_IF4 = rsptr->get_num_instruction(IF4); 
      savecreature->num_INC1 = rsptr->get_num_instruction(INC1); 
      savecreature->num_INC2 = rsptr->get_num_instruction(INC2); 
      savecreature->num_DEC1 = rsptr->get_num_instruction(DEC1); 
      savecreature->num_DEC2 = rsptr->get_num_instruction(DEC2);
      savecreature->num_HALF1 = rsptr->get_num_instruction(HALF1); 
      savecreature->num_HALF2 = rsptr->get_num_instruction(HALF2); 
      savecreature->num_DOUBLE1 = rsptr->get_num_instruction(DOUBLE1); 
      savecreature->num_DOUBLE2 = rsptr->get_num_instruction(DOUBLE2); 
      savecreature->num_NEG1 = rsptr->get_num_instruction(NEG1); 
      savecreature->num_NEG2 = rsptr->get_num_instruction(NEG2);
      savecreature->num_CHANGEVAR1 = rsptr->get_num_instruction(CHANGEVAR1);
      savecreature->num_CHANGEVAR2 = rsptr->get_num_instruction(CHANGEVAR2);
      savecreature->num_CHANGEVAR3 = rsptr->get_num_instruction(CHANGEVAR3);
      savecreature->num_CHANGEVAR4 = rsptr->get_num_instruction(CHANGEVAR4);
      savecreature->num_CHANGEVAR5 = rsptr->get_num_instruction(CHANGEVAR5);
      savecreature->total_instructions = rsptr->get_total_instructions();
    }
  else
    {
      nn=NULL;
      complexity=0;

      savecreature->th_r = 0;
      savecreature->th_m = 0; 
      savecreature->th_a = 0; 
      savecreature->th_f0 = 0; 
      savecreature->th_g = 0; 
      savecreature->th_d = 0;
      savecreature->int_r = 0; 
      savecreature->int_m = 0; 
      savecreature->int_x0 = 0; 
      savecreature->int_l = 0; 
      savecreature->int_gam = 0; 
      savecreature->int_d = 0; 
      savecreature->int_g = 0;
      savecreature->int_reload = 0; 
      savecreature->int_fatigue_level = 0; 
      savecreature->int_fatigue_decrease = 0;
      savecreature->out_g = 0;
      savecreature->out_r = 0; 
      savecreature->out_m = 0; 
      savecreature->out_x0 = 0; 
      savecreature->out_l = 0; 
      savecreature->out_gam = 0; 
      savecreature->out_d = 0; 
      savecreature->out_g = 0;
      savecreature->out_reload = 0; 
      savecreature->out_fatigue_level = 0; 
      savecreature->out_fatigue_decrease = 0;
      savecreature->outL = 0; 
      savecreature->outX0 = 0; 
      savecreature->num_ACTIVATE = 0; 
      savecreature->num_DEACTIVATE = 0; 
      savecreature->num_ACTIVATEL = 0; 
      savecreature->num_DEACTIVATEL = 0;
      savecreature->num_CHN = 0; 
      savecreature->num_CHNPROS = 0; 
      savecreature->num_CHNODE = 0; 
      savecreature->num_CHSTTHREAD = 0; 
      savecreature->num_CHALLTH = 0; 
      savecreature->num_CHTHREAD = 0; 
      savecreature->num_STOP = 0; 
      savecreature->num_REM = 0; 
      savecreature->num_REM1 = 0; 
      savecreature->num_REM2 = 0;
      savecreature->num_IF1 = 0; 
      savecreature->num_IF2 = 0; 
      savecreature->num_IF3 = 0; 
      savecreature->num_IF4 = 0; 
      savecreature->num_INC1 = 0; 
      savecreature->num_INC2 = 0; 
      savecreature->num_DEC1 = 0; 
      savecreature->num_DEC2 = 0;
      savecreature->num_HALF1 = 0; 
      savecreature->num_HALF2 = 0; 
      savecreature->num_DOUBLE1 = 0; 
      savecreature->num_DOUBLE2 = 0; 
      savecreature->num_NEG1 = 0; 
      savecreature->num_NEG2 = 0;
      savecreature->num_CHANGEVAR1 = 0;
      savecreature->num_CHANGEVAR2 = 0;
      savecreature->num_CHANGEVAR3 = 0;
      savecreature->num_CHANGEVAR4 = 0;
      savecreature->num_CHANGEVAR5 = 0;
      savecreature->total_instructions = 0;
    }

  input=new double[evolvenet::num_in];
  for(i=0;i<evolvenet::num_in;i++)
    input[i]=0;

  choices=new int[evolvenet::num_out];  
  for(i=0;i<evolvenet::num_out;i++)
    choices[i]=0;

  prevchoice=0;
  age=0;
  intage=0;
}

// make startup creature
evolvenet::evolvenet(unsigned int number_of_cromosomes, 
		       int numinnodes, int numoutnodes)
{
  struct timezone tz;
  DateTime now1,now2; 
  timeval tv1,tv2;

  now1.now();
  gettimeofday(&tv1, &tz);
  rsptr=new replicatorset(number_of_cromosomes, numinnodes, numoutnodes);
  now2.now();
  gettimeofday(&tv2, &tz);
  generation_time=double((now2-now1)*24*3600) + 
    double(tv2.tv_sec - tv1.tv_sec) +
    double(tv2.tv_usec<tv1.tv_usec ? -1 : 0) + 
    double(tv2.tv_usec<tv1.tv_usec ? 1000000+tv2.tv_usec-tv1.tv_usec : 
	   tv2.tv_usec-tv1.tv_usec)/1000000.0;

  father=mother=NULL;
  t0=0.0;
  startgen=0;
  init();
}

// import creature
evolvenet::evolvenet(char *filename, int starting_generation, double t0_)
{
  rsptr=NULL;
  father=mother=NULL;
  t0 = t0_;
  startgen = starting_generation;
  init();
  from_file(filename);
  savecreature->index=masterindex-1;
  savecreature->findex=savecreature->mindex=0;
  startgen = starting_generation;
  t0 = t0_;
  savecreature->imported=1.0;
  savecreature->alive=1;
}

// recover saved creature
evolvenet::evolvenet(FILE *file)
{
  register int i;

  rsptr=NULL;
  father=mother=NULL;
  startgen = 0;
  from_file(file);
  savecreature->imported=0.0;
  savecreature->alive=1;
  savecreature->age++;
  age++;
  intage++;

  input=new double[evolvenet::num_in];
  for(i=0;i<evolvenet::num_in;i++)
    input[i]=0;

  choices=new int[evolvenet::num_out];  
  for(i=0;i<evolvenet::num_out;i++)
    choices[i]=0;
}

// import creature
evolvenet::evolvenet(FILE *file, int starting_generation, double t0_)
{
  rsptr=NULL;
  father=mother=NULL;
  t0 = t0_;
  startgen = starting_generation;
  init();
  from_file(file);
  savecreature->index=masterindex-1;
  savecreature->findex=savecreature->mindex=0;
  startgen = starting_generation;
  savecreature->imported=1.0;
  savecreature->alive=1;
}

// make clone;
evolvenet::evolvenet(evolvenet *parent, unsigned int startgen_,
		     double t0_)
{
  struct timezone tz;
  DateTime now1,now2; 
  timeval tv1,tv2;

  now1.now();
  gettimeofday(&tv1, &tz);
  rsptr=new replicatorset(parent->rsptr, parent->rsptr);
  now2.now();
  gettimeofday(&tv2, &tz);
  generation_time=double((now2-now1)*24*3600) + 
    double(tv2.tv_sec - tv1.tv_sec) +
    double(tv2.tv_usec<tv1.tv_usec ? -1 : 0) + 
    double(tv2.tv_usec<tv1.tv_usec ? 1000000+tv2.tv_usec-tv1.tv_usec : 
	   tv2.tv_usec-tv1.tv_usec)/1000000.0;

  mother=NULL;
  father=parent;
  t0 = t0_;
  startgen=startgen_;
  init();
  parent->numchildren++;
  savecreature->imported=0.5*parent->savecreature->imported;
}

// make from replicatorset file
evolvenet::evolvenet(char *neuralreplicatorfile)
{
  struct timezone tz;
  DateTime now1,now2; 
  timeval tv1,tv2;

  now1.now();
  gettimeofday(&tv1, &tz);
  rsptr=new replicatorset(neuralreplicatorfile);
  now2.now();
  gettimeofday(&tv2, &tz);
  generation_time=double((now2-now1)*24*3600) + 
    double(tv2.tv_sec - tv1.tv_sec) +
    double(tv2.tv_usec<tv1.tv_usec ? -1 : 0) + 
    double(tv2.tv_usec<tv1.tv_usec ? 1000000+tv2.tv_usec-tv1.tv_usec : 
	   tv2.tv_usec-tv1.tv_usec)/1000000.0;

  father=mother=NULL;
  t0 = 0;
  startgen=0;
  init();
  savecreature->alive=1;
  savecreature->imported=1.0;
}

// make from two different parents
evolvenet::evolvenet(evolvenet *parent1, evolvenet *parent2, 
		     unsigned int startgen_, double t0_)
{
  struct timezone tz;
  DateTime now1,now2; 
  timeval tv1,tv2;

  now1.now();
  gettimeofday(&tv1, &tz);
  rsptr=new replicatorset(parent1->rsptr, parent2->rsptr);
  now2.now();
  gettimeofday(&tv2, &tz);
  generation_time=double((now2-now1)*24*3600) + 
    double(tv2.tv_sec - tv1.tv_sec) +
    double(tv2.tv_usec<tv1.tv_usec ? -1 : 0) + 
    double(tv2.tv_usec<tv1.tv_usec ? 1000000+tv2.tv_usec-tv1.tv_usec : 
	   tv2.tv_usec-tv1.tv_usec)/1000000.0;

  father=parent1;
  mother=parent2;
  t0 = t0_;
  startgen=startgen_;
  init();

  parent1->numchildren += 0.5;
  parent2->numchildren += 0.5;
  savecreature->imported=0.25*(parent1->savecreature->imported +
			       parent2->savecreature->imported);
}

// destructor
evolvenet::~evolvenet()
{
  if(intage>0)
    meanpayoff /= ((double) intage);

  if(startgen>0 && savecreature->father==NULL && savecreature->findex==0 &&
     savecreature->imported==0.0)
    debug("Destructor: missing father!");

  savecreature->lastpayoff      = payoff;
  savecreature->meanpayoff      = meanpayoff;
  savecreature->maxpayoff       = maxpayoff;
  savecreature->numcromo    = rsptr ? rsptr->get_number_of_cromosomes() : 0.0;
  savecreature->point       = rsptr ? rsptr->get_point_mutation_rate() : 0.0;
  savecreature->point1      = rsptr ? rsptr->get_point_mutation_rate1() : 0.0;
  savecreature->point2      = rsptr ? rsptr->get_point_mutation_rate2() : 0.0;
  savecreature->line        = rsptr ? rsptr->get_line_mutation_rate() : 0.0;
  savecreature->line1       = rsptr ? rsptr->get_line_mutation_rate1() : 0.0;
  savecreature->line2       = rsptr ? rsptr->get_line_mutation_rate2() : 0.0;
  savecreature->flip        = rsptr ? rsptr->get_flip_rate() : 0.0;
  savecreature->negate      = rsptr ? rsptr->get_negate_rate() : 0.0;
  savecreature->linelen     = rsptr ? rsptr->get_line_length() : 0.0;
  savecreature->globaln     = rsptr ? rsptr->get_global_n() : 0.0;
  savecreature->repair      = rsptr ? rsptr->get_repair_ratio() : 0.0;
  savecreature->firstrepair = rsptr ? rsptr->get_first_repair() : 0.0;
  savecreature->maxgen = rsptr ? rsptr->get_max_number_of_generations() : 0.0;
  savecreature->gender      = rsptr ? rsptr->get_gender() : UNKNOWN_GENDER;
  savecreature->numnodes    = nn ? nn->get_number_of_nodes() : 0.0;
  savecreature->numthreads  = nn ? nn->get_number_of_threads() : 0.0;
  savecreature->complexity  = savecreature->numnodes+savecreature->numthreads;
  savecreature->numinternal = nn ? nn->get_num_internal() : 0.0;
  savecreature->numchildren = numchildren;

  savecreature->age=age;
  savecreature->alive=0;

  if(savecreature->index>0) 
    {
      if(savecreature->findex<=0 && savecreature->start>0 && 
	 savecreature->imported==0.0)
	debug("Father not found!");
      if(savecreature->findex>masterindex)
	debug("Father index out of range!");
      if(savecreature->mindex>masterindex)
	debug("Mother index out of range!");
      
      savecreature->removefromlist();
	  
      if(file)
	fwrite(savecreature, sizeof(evolvenet_creature), 1, file);
      save_index++;
      delete savecreature;
    }
  
  if(rsptr)
    delete rsptr;
}

// import a evolvenet file
void evolvenet::from_file(char *filename) 
{
  FILE *f=fopen(filename, "r");
  
  from_file(f);

  fclose(f);
}

void evolvenet::from_file(FILE *file)
{
  fread(&payofchoice, sizeof(int), 1, file); 
  fread(&iterindex, sizeof(int), 1, file); 
  fread(&prevchoice, sizeof(int), 1, file);
  fread(&startgen, sizeof(unsigned int), 1, file);
  fread(&t0, sizeof(double), 1, file);
  fread(&age, sizeof(double), 1, file);
  fread(&intage, sizeof(int), 1, file);
  fread(&numchildren, sizeof(double), 1, file);
  fread(&payoff, sizeof(double), 1, file);
  fread(&maxpayoff, sizeof(double), 1, file);
  fread(&meanpayoff, sizeof(double), 1, file);
  meanpayoff *= double(intage);
  fread(&complexity, sizeof(int), 1, file);
  fread(&numiter, sizeof(int), 1, file);
  savecreature=new evolvenet_creature(NULL);
  fread(savecreature, sizeof(evolvenet_creature), 1, file);
  father=mother=NULL;
  savecreature->father=savecreature->mother=NULL;

  rsptr = new replicatorset(file);
  nn    = rsptr->get_neural_net();
}

// exports a evolvenet file
void evolvenet::to_file(char *filename)  
{
  FILE *f=fopen(filename, "wb");
  
  to_file(f);

  fclose(f);
}

void evolvenet::to_file(FILE *file) 
{
  fwrite(&payofchoice, sizeof(int), 1, file); 
  fwrite(&iterindex, sizeof(int), 1, file); 
  fwrite(&prevchoice, sizeof(int), 1, file);
  fwrite(&startgen, sizeof(unsigned int), 1, file);
  fwrite(&t0, sizeof(double), 1, file);
  fwrite(&age, sizeof(double), 1, file);
  fwrite(&intage, sizeof(int), 1, file);
  fwrite(&numchildren, sizeof(double), 1, file);
  fwrite(&payoff, sizeof(double), 1, file);
  fwrite(&maxpayoff, sizeof(double), 1, file);
  fwrite(&meanpayoff, sizeof(double), 1, file);
  fwrite(&complexity, sizeof(int), 1, file);
  fwrite(&numiter, sizeof(int), 1, file);
  fwrite(savecreature, sizeof(evolvenet_creature), 1, file);
  rsptr->to_file(file);
}

void evolvenet::exportnet(int number, char *logfile)
{
  char filename[100], bufferfile[100];

  sprintf(bufferfile, "buffer_net_%s_%d", logfile, number);
  to_file(bufferfile);

  sprintf(filename, "evolved3_%s_%d", logfile, number);
  rename(bufferfile, filename);
  //sprintf(cmd, "mv %s %s", bufferfile, filename);
  //system(cmd);
}

replicatorset *evolvenet::get_replicatorset(void)
{
  return rsptr;
}

int evolvenet::determine_iter(int base_number_of_iterations)
{
  numiter = base_number_of_iterations + 
    ((int) (((double) base_number_of_iterations) * drand48()));

  numiter = (numiter/2) * 2;
  return numiter;
}

double evolvenet::get_age(void)
{
  return age;
}

void evolvenet::update_secondary(double newpayoff)
{
  secondary_payoff = (double(secondary_iter)*secondary_payoff+newpayoff)/
    double(secondary_payoff+1);
  secondary_payoff++;
}

neuralnet *evolvenet::get_neural_net(void)
{
  return nn;
}

evolvenet *evolvenet::importnet(int /* starting_generation */, 
				double /* t0 */, char *logfile)
{
  evolvenet *ret=NULL;
  char cmd[1000];
  FILE *p;
  int numfiles=0, index;

  fflush(stdin);
  fflush(stdout);
  fflush(stderr);

  sprintf(cmd, "ls | grep \"evolved3_*.*\" | "
	  "grep -v evolved3_%s_ | grep -v importing | wc -l", logfile);
  p=popen(cmd, "r");
  if(!p)
    return NULL;

  fscanf(p, "%d", &numfiles);

  std::cout << "Number of possible imports: " << numfiles << std::endl;

  if(numfiles<1)
    return NULL;

  index = (int) (drand48() * ((double) numfiles));
  index = index % numfiles;
  
  sprintf(cmd, "ls | grep \"evolved3_*.*\" | grep -v evolved3_%s_ "
	  "| grep -v importing", 
	  logfile);
  p=popen(cmd, "r");
  if(!p)
    return NULL;

  /*
  ifstream is2(fileno(p));

  if(!is2.fail())
    {
      char filename[100], newfilename[150];
      int i=0;

      is2.getline(filename, 99);
      while(!is2.fail() && i!=index)
	{
	  is2.getline(filename, 99);
	  i++;
	}

      if(i==index)
	{
	  struct stat buf;

	  cout << "Importing the file \"" << filename << "\"" << endl;

	  sprintf(newfilename, "importing.%s.%ld", filename, random());
	  //sprintf(cmd, "mv %s %s", filename, newfilename);
	  if(stat(filename, &buf) != 0 || buf.st_size<1000)
	    {
	      cout << "Import interrupted on \"" << filename << "\"!" << endl;
	      return NULL;
	    }
	  //system(cmd);
	  if(rename(filename, newfilename))
	     {
	       cout << "Import interrupted while moving \"" << filename << 
		 "\" to \"" << newfilename << "\"!" << endl;
	      return NULL;
	    }

	  if(stat(newfilename, &buf) != 0 || buf.st_size<1000)
	    {
	      cout << "Import interrupted(2) on \"" << newfilename << 
		"\"!" << endl;
	      return NULL;
	    }
	  ret=new evolvenet(newfilename, starting_generation, t0);
	  unlink(newfilename);
	}
    }

  pclose(p);
  is2.close();
  */

  return ret;
}

evolvenet *evolvenet::replicate(evolvenet *parent1, evolvenet **population,
				  int generation, int numnet, double t0)
{
  GENDER gender = parent1->rsptr->get_gender();
  evolvenet *ret=NULL, *parent2=NULL;

  switch(gender)
    {
    case CLONE:
      ret = new evolvenet(parent1, generation, t0);
      break;
    case HEMAPHRODITE: 
      parent2 = parent1->find_mate(population, numnet, HEMAPHRODITE); 
      if(parent2==parent1)
	parent2 = parent1->find_mate(population, numnet, FEMALE); 
      if(parent2==parent1)
	parent2 = parent1->find_mate(population, numnet, MALE); 
      ret = new evolvenet(parent1, parent2, generation, t0);
      break;
    case MALE:
      parent2 = parent1->find_mate(population, numnet, FEMALE);
      if(parent1==parent2)
	parent2 = parent1->find_mate(population, numnet, HEMAPHRODITE);

      if(parent2==parent1) // NO suitable mate found
	{
	  parent2 = parent1->find_mate(population, numnet, CLONE);
	  if(parent2==parent1)
	    parent2 = parent1->find_mate(population, numnet, HEMAPHRODITE);
	  ret = new evolvenet(parent2, generation, t0);
	}
      else
	ret = new evolvenet(parent1, parent2, generation, t0);
      break;
    case FEMALE:
      parent2 = parent1->find_mate(population, numnet, MALE); 
      if(parent1==parent2)
	parent2 = parent1->find_mate(population, numnet, HEMAPHRODITE);

      if(parent2==parent1) // NO suitable mate found
	{
	  parent2 = parent1->find_mate(population, numnet, CLONE);
	  if(parent2==parent1)
	    parent2 = parent1->find_mate(population, numnet, HEMAPHRODITE);
	  ret = new evolvenet(parent2, generation, t0);
	}
      else
	ret = new evolvenet(parent2, parent1, generation, t0);
      break;
	default:
	    break;
    }

  return ret;
}

void evolvenet::set_end(double t1)
{
  age=t1-t0;
  if(age<0.0)
    debug("Bad age!");
  if(floor(t0)>=floor(t1) && t0>=1.0)
    debug("Too short life!");
}

evolvenet *evolvenet::find_mate(evolvenet **population, int numnet, 
				  GENDER wantedgender)
{
  double minchildren=1000000;
  evolvenet *ptr=this;

  for(int i=0;i<numnet/2;i++)
    if(population[i]!=this && 
       population[i]->rsptr->get_gender() == wantedgender &&
       (population[i]->numchildren - 10.0*population[i]->payoff - 
	6.0*((double) (numnet-i))/((double) numnet)) < 
       minchildren)
      {
	minchildren =(population[i]->numchildren - 10.0*population[i]->payoff -
		      6.0*((double) (numnet-i))/((double) numnet));
	ptr=population[i];
      }
  
  return ptr;
}

void evolvenet::signal_handler(int /* signal_nr */)
{
  exit_controlled = true;
}

void evolvenet::activate_signal(void)
{
  signal(SIGTERM, evolvenet::signal_handler);
  signal(SIGILL,  evolvenet::signal_handler);
  signal(SIGQUIT, evolvenet::signal_handler);
  signal(SIGINT,  evolvenet::signal_handler);
  signal(SIGHUP,  evolvenet::signal_handler);
}

void evolvenet::doexit(char *logfile, int generation, int maxgen, int numnet, 
			evolvenet **rs)
{
  char savefile[1000];
  sprintf(savefile, "%s.sav", logfile);
  FILE *runfile=fopen(savefile, "w");
  int i;
  char alivelog[1000];

  sprintf(alivelog, "%s.alive", logfile);

  if(!runfile)
    {
	std::cout << "Couldn't open savefile 'evolvenet.sav' for output!" << std::endl;
      exit(0);
    }

  fwrite(&generation, sizeof(int), 1, runfile);
  fwrite(&maxgen, sizeof(int), 1, runfile);
  fwrite(&numnet, sizeof(int), 1, runfile);
  fwrite(&save_index, sizeof(int), 1, runfile);
  fwrite(&masterindex, sizeof(int), 1, runfile);
  fwrite(logfile, sizeof(char), 200, runfile);
  for(i=0;i<numnet;i++)
    if(rs[i])
      rs[i]->to_file(runfile);

  fclose(runfile);

  fflush(file);
  fclose(file);
  file=fopen(alivelog, "w");

  for(i=0;i<numnet;i++)
    if(rs[i])
      {
	double t0 = ((double) generation) + ((double) i)/((double) numnet); 
	rs[i]->set_end(t0);
	delete rs[i];
	rs[i]=NULL;
      }

  delete [] rs;

  fflush(file);
  fclose(file);
  exit(0);
}

void evolvenet::dogetsaved(char *logfile, int *generation, int *maxgen, 
			    int *numnet, evolvenet ***rsptr)
{
  char savefile[1000];
  sprintf(savefile, "%s.sav", logfile);
  FILE *runfile=fopen(savefile, "r");
  evolvenet **rs;

  fread(generation, sizeof(int), 1, runfile);
  fread(maxgen, sizeof(int), 1, runfile);
  fread(numnet, sizeof(int), 1, runfile);
  fread(&save_index, sizeof(int), 1, runfile);
  fread(&masterindex, sizeof(int), 1, runfile);
  fread(logfile, sizeof(char), 200, runfile);

  rs = new evolvenet*[*numnet];

  for(int i=0;i<(*numnet);i++)
    rs[i] = new evolvenet(runfile);

  fclose(runfile);

  *rsptr=rs;
}


void evolvenet::run_simulation(char *logfile_, int numnet_, int numgener, 
				int baseiter, int numfiles, bool getsaved, 
				evolvenet_process *process_plan)
{
  int i, gen, startgeneration=1;
  char logfile[201];
  evolvenet **rs=NULL;

  strcpy(logfile, logfile_);
  process_plan->set_logfilename(logfile_);
  numnet=numnet_;
  num_in=process_plan->number_of_in_nodes();
  num_out=process_plan->number_of_out_nodes();

  activate_signal();
  randify();

  if(getsaved)
    {
      dogetsaved(logfile, &startgeneration, &numgener, &numnet, &rs); 
      
      file=fopen(logfile, "a");
      if(!file)
	{
	    std::cerr << "File '" << logfile << "' couldn't be opened!" << std::endl;
	  exit(0);
	}
    }
  else
    {
      file=fopen(logfile, "w");
      if(!file)
	{
	    std::cerr << "File '" << logfile << "' couldn't be opened!" << std::endl;
	  exit(0);
	}

      rs=new evolvenet*[numnet];
    }

  

  if(!getsaved)
    for(i=0;i<numnet;i++)
      {
	  std::cout << "Making net number " << i+1 << std::endl;
	rs[i]=new evolvenet(5, num_in, num_out); 
      }
  
  follow = rs[0];

  process_plan->set_all_replicators(rs, numnet);

  for(gen=startgeneration; gen<=numgener; gen++)
    {
      char filename[100], fname2[100];
      
      sprintf(filename, "neu3_%s_%d", logfile, gen);
      sprintf(fname2, "net3_%s_%d", logfile, gen);
      std::cout << "STARTING GENERATION " << gen << std::endl << std::endl;

      for(i=0;i<numnet;i++)
	{
	  rs[i]->secondary_iter=0;
	  rs[i]->secondary_payoff=0.0;
	}
      process_plan->generation_started(gen);

      for(i=0;i<numnet;i++)
	{
	  struct timezone tz;
	  DateTime now1,now2; 
	  timeval tv1,tv2;
	  
	  now1.now();
	  gettimeofday(&tv1, &tz);

	  double p=process_plan->get_payoff(rs[i], baseiter);now2.now();

	  gettimeofday(&tv2, &tz);
	  rs[i]->processing_time=double((now2-now1)*24*3600) + 
	    double(tv2.tv_sec - tv1.tv_sec) +
	    double(tv2.tv_usec<tv1.tv_usec ? -1 : 0) + 
	    double(tv2.tv_usec<tv1.tv_usec ? 1000000+tv2.tv_usec-tv1.tv_usec : 
		   tv2.tv_usec-tv1.tv_usec)/1000000.0;

	  std::cout << "Payoff for net " << i+1 << " : " << p << std::endl;

	  if(exit_controlled)
	    doexit(logfile, gen, numgener, numnet, rs);

	  if(rs[i]==follow && follow!=NULL)
	    {
	      char buffer[300];
	      sprintf(buffer, 
		      "Followed: age=%4.1f gender=%d num_children=%3.1f",
		      follow->get_age(),
		      (int) follow->rsptr->get_gender(), 
		      follow->numchildren);
	      std::cout << buffer << std::endl;		 
	    }
	}

      for(i=0;i<numnet;i++)
	rs[i]->payoff=(rs[i]->payoff*rs[i]->numiter+
		       rs[i]->secondary_payoff*rs[i]->secondary_iter)/
	  double(rs[i]->numiter+rs[i]->secondary_iter);

      double meantime=0.0;
      for(i=0;i<numnet;i++)
	meantime+=rs[i]->processing_time+rs[i]->generation_time;
      meantime/=double(numnet);
      
      for(i=0;i<numnet;i++)
	rs[i]->payoff += 0.1-0.1*(rs[i]->processing_time +
				  rs[i]->generation_time)/meantime;

      process_plan->generation_ended(gen);      

      std::cout << "Sorting ..." << std::endl;
      qsort(rs, size_t(numnet), sizeof(evolvenet *), evolvenet::comp_rep);
      for(i=0;i<numnet;i++)
	{
	  std::cout << "Net " << i+1 << " mean payoff: " <<  rs[i]->payoff << 
	    "  nodes: " << 
	    rs[i]->rsptr->get_neural_net()->get_number_of_nodes() <<
	    "  thread: " << 
	    rs[i]->rsptr->get_neural_net()->get_number_of_threads();
	  if(rs[i]==follow)
	    std::cout << " followed...";
	  switch(rs[i]->rsptr->get_gender())
	    {
	    case CLONE:
	      std::cout << " (C)";
	      break;
	    case HEMAPHRODITE:
	      std::cout << " (H)";
	      break;
	    case FEMALE:
	      std::cout << " (F)";
	      break;
	    case MALE:
	      std::cout << " (M)";
	      break;
		default:
		    break;
	    }
	  std::cout << std::endl;
	}
	  

      int numclone=0, numhem=0, nummale=0, numfemale=0;
      for(i=0;i<numnet;i++)
	{
	  switch(rs[i]->rsptr->get_gender())
	    {
	    case CLONE:
	      numclone++;
	      break;
	    case HEMAPHRODITE: 
	      numhem++;
	      break;
	    case MALE:
	      nummale++;
	      break;
	    case FEMALE:
	      numfemale++;
	      break;
		default:
		    break;
	    }
	}

      std::cout << "Clones: " << numclone;
      std::cout << "  Hemophrodites: " << numhem;
      std::cout << "  Males: " << nummale;
      std::cout << "  Females: " << numfemale << std::endl;


      rs[0]->rsptr->to_file(filename);

      std::ofstream out;
      out.open(fname2, std::ios::out);
      rs[0]->rsptr->get_neural_net()->print(out);
      out.close();

      for(i=0;i<numnet/6;i++)
	{
	  int jj=numnet/2+i, kk=numnet/2+numnet/6+i;
	  int t0_ = (gen-1)*numnet + i,
	    t1_ = (gen-1)*numnet + i + numnet/6;
	  double t0 = ((double) t0_)/((double) numnet),
	    t1 = ((double) t1_)/((double) numnet);

	  if(follow==rs[jj] || follow==rs[kk])
	    follow=NULL;
	  
	  rs[jj]->set_end(t0+0.5);
	  rs[kk]->set_end(t1+0.5);

	  delete rs[jj];
	  delete rs[kk];

	  if(i<numfiles)
	    {
	      evolvenet *newnet=replicate(rs[i], rs, gen, numnet, t0);
	      newnet->exportnet(i+1, logfile);
	      delete newnet;
	    }
	      
	  std::cout << "Net number " << i << " reproducing..." << std::endl;
	  rs[jj]=replicate(rs[i], rs, gen, numnet, t0);
	  rs[kk]=replicate(rs[i], rs, gen, numnet, t1);

	  if(!follow)
	    follow=rs[jj];

	  if(exit_controlled)
	    doexit(logfile, gen, numgener, numnet, rs);
	}

      for(i=0;i<numnet/6;i++)
	{
	  int ii=i+numnet/6, jj=5*numnet/6+i;
	  unsigned int t0_ = (gen-1)*numnet + numnet/3;
	  double t0 = ((double) t0_)/((double) numnet);

	  std::cout << "Net number " << ii << " reproducing..." << std::endl;

	  if(follow==rs[jj])
	    follow=NULL;

	  rs[jj]->set_end(t0+0.5);
	  delete rs[jj];
	  rs[jj]=replicate(rs[ii], rs, gen, numnet, t0);

	  if(!follow)
	    follow=rs[jj];

	  if(exit_controlled)
	    doexit(logfile, gen, numgener, numnet, rs);
	}

      int numimported=0;
      evolvenet *import=rs[0];
      for(i=0;i<numfiles && import;i++)
	{
	  int t0_ = (gen-1)*numnet + i;
	  double t0 = ((double) t0_)/((double) numnet);

	  import=importnet(gen, t0, logfile);
	  if(import)
	    {
	      int jj=numnet/2-numimported-1;

	      if(follow==rs[jj])
		follow=NULL;

	      rs[jj]->set_end(t0+0.5);
	      delete rs[jj];

	      rs[jj]=import;
	      
	      if(!follow)
		follow=rs[jj];

	      numimported++;
	      std::cout << "Importing net number " << numimported << std::endl;
	    }

	  if(exit_controlled)
	    doexit(logfile, gen, numgener, numnet, rs);
	}

      for(i=0;i<numnet/6-numimported;i++)
	{
	  int ii=i+numnet/3;
	  unsigned int t0_ = (gen-1)*numnet + ii;
	  double t0 = ((double) t0_)/((double) numnet);

	  std::cout << "Net number " << ii << " reproducing..." << std::endl;

	  evolvenet *cp=replicate(rs[ii], rs, gen, numnet, t0);
	  
	  if(follow==rs[ii])
	    follow=NULL;
	  
	  rs[ii]->set_end(t0+0.5);
	  delete rs[ii];
	  rs[ii]=cp;
	  
	  if(!follow)
	    follow=rs[ii];

	  if(exit_controlled)
	    doexit(logfile, gen, numgener, numnet, rs);
	}

      if(follow==NULL)
	follow=rs[0];
    }

  doexit(logfile, gen, numgener, numnet, rs);
}

void evolvenet::set_previous_payoff(double new_previous_payoff)
{
  previous_payoff=new_previous_payoff;
}

double evolvenet::get_previous_payoff(void)
{
  return previous_payoff;
}

// ***************************************
// 
//     EVOLVENET_PROCESS 
//
// Superclass for problems to be solved.
//
// ***************************************

evolvenet_process::evolvenet_process(int number_of_in_nodes_, 
				     int number_of_out_nodes_)
{
  numin=number_of_in_nodes_;
  numout=number_of_out_nodes_;
}

void evolvenet_process::process_once(evolvenet *ptr)
{
  process_once(ptr->complexity, ptr, ptr->payoff, ptr->input,
	       ptr->numiter, ptr->payofchoice, ptr->choices,
	       ptr->iterindex, ptr->prevchoice);
}

double evolvenet_process::get_payoff(evolvenet *ptr, 
				     int base_number_of_iterations)
{
  int i;

  ptr->determine_iter(base_number_of_iterations);
  ptr->age++;
  ptr->intage++;
  ptr->savecreature->age++;
  ptr->iterindex=0;
  ptr->payoff=0.0;

  for(i=0;i<numin;i++)
    ptr->input[i]=0;
  for(i=0;i<numout;i++)
    ptr->choices[i]=0;

  get_payoff(ptr->complexity, ptr, ptr->payoff, ptr->input,
	     ptr->numiter, ptr->payofchoice, ptr->choices,
	     ptr->iterindex, ptr->prevchoice, base_number_of_iterations);
  
  ptr->payoff=MAXIM(ptr->payoff, 0.0);
  ptr->meanpayoff += ptr->payoff;
  ptr->maxpayoff = MAXIM(ptr->maxpayoff, ptr->payoff);

  return ptr->payoff;
}

int evolvenet_process::number_of_in_nodes(void)
{
  return numin;
}

int evolvenet_process::number_of_out_nodes(void)
{
  return numout;
}

void evolvenet_process::set_all_replicators(evolvenet **allrepliactors, 
					    int numreplicators)
{
  all_repliactors=allrepliactors;
  num_replicators=numreplicators;
}

void evolvenet_process::set_logfilename(char *new_logfilename)
{
  strcpy(logfilename, new_logfilename);
}

char *evolvenet_process::get_logfilename(void)
{
  return logfilename;
}

evolvenet *evolvenet_process::get_arbitrary_net(replicatorset *exception)
{
  int index=int(drand48()*num_replicators);
  
  while(all_repliactors[index]->get_replicatorset()==exception)
    index=int(drand48()*num_replicators);

  return all_repliactors[index];
}

void evolvenet_process::generation_started(int /* generation_number */)
{
}

void evolvenet_process::generation_ended(int /* generation_number */)
{
}
