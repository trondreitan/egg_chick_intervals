/*
 * $Id: regression.C 2765 2016-09-06 12:44:49Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/regression.C $
 */

#include <hydrasub/hydrabase/regression.H>

// ***************************************************
//
//              REGRESSION
//
// Contains method for doing regression analysis
// and storing the result of such an analysis.
//
// Made by Trond Reitan, 2002/2003
// Last modified by Trond Reitan, 3/6-2005
//
// ***************************************************


#ifdef GSL
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#endif // GSL

#include <cmath>
#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/linalg.H>
const char *regress_func_names[]=
{WHAT((char *) "Line�r", (char *) "Linear"),
 WHAT((char *) "Kvadrat", (char *) "Square"),
 WHAT((char *) "Kubisk", (char *) "Cube"),
 WHAT((char *) "Kvadratrot", (char *) "Square root"),
 WHAT((char *) "Log", (char *) "Log"),
 WHAT((char *) "Exp", (char *) "Exp"),
 WHAT((char *) "Sin", (char *) "Sin"),
 WHAT((char *) "Cos", (char *) "Cos"),
 WHAT((char *) "Indikator", (char *) "Indicator"),
 WHAT((char *) "Opph�yd i", (char *) "In the power of")};

const char *regress_func_names_short[]=
{WHAT((char *) "", (char *) ""),
 WHAT((char *) "�", (char *) "�"),
 WHAT((char *) "�", (char *) "�"),
 WHAT((char *) "sqr", (char *) "sqr"),
 WHAT((char *) "log", (char *) "log"),
 WHAT((char *) "exp", (char *) "exp"),
 WHAT((char *) "sin", (char *) "sin"),
 WHAT((char *) "cos", (char *) "cos"),
 WHAT((char *) "S", (char *) "S"),
 WHAT((char *) "^", (char *) "^")};

bool regress_func_before[]=
{true, false, false, true, true, true, true, true, true, 
 true};
bool regress_func_substract[]=
{true, true, true, true, true, true, false, false, 
 true, false};
int num_regression_basefunctions=REGRESS_FUNCTION_NUMBER;


// ******************************************************
// VARIANCE_TABLE
// Meant to store info about a variance table analysis
// ******************************************************

variance_table::variance_table()
{
  SS_res=df_reg=MS_reg=SS_res=df_res=MS_res=SS_tot=df_tot=F=p_F=MISSING_VALUE;
}

// Set all components of the structure;
void variance_table::Set(double SSreg, double dfreg, double MSreg, 
			 double SSres, double dfres, double MSres, 
			 double SStot, double dftot, double F_, double pF)
{
  SS_reg=SSreg;
  df_reg=dfreg;
  MS_reg=MSreg;
  SS_res=SSres;
  df_res=dfres;
  MS_res=MSres;
  SS_tot=SStot;
  df_tot=dftot;
  F=F_;
  p_F=pF;
}



// **********************************************
//
//        REGRESSION_RESULT
//
// Contains the result of a regression analysis
//
// *********************************************

// Constructor
// Stores all relevant info from an analysis already done;
regression_result::regression_result(double *coefficients, 
				     int number_of_coefficients,
				     double square_residual, 
				     double sigma_squared,
				     double *sdevs_squared,
				     double *t_observators, double *pvalues,
				     double *residuals, int numobs)
{
  int i;
  
  cooks=NULL;
  n=0;
  s_squared=NULL;
  coef=new double[number_of_coefficients];
  num_coef=number_of_coefficients;
  sqrresidual=square_residual;
  sigmasquared=sigma_squared;
  sdev_squared_coef=new double[number_of_coefficients];
  t_observator=new double[number_of_coefficients];
  pvalue=new double[number_of_coefficients];

  n=numobs;
  if(n>0)
    {
      resid=new double[n];
      for(i=0;i<n;i++)
	resid[i]=residuals[i];
    }
  else
    resid=NULL;
  
  for(i=0;i<num_coef;i++)
    {
      coef[i]=coefficients[i];
      sdev_squared_coef[i]=sdevs_squared[i];
      if(t_observators)
	t_observator[i]=t_observators[i];
      else
	t_observator[i]=MISSING_VALUE;
      if(pvalues)
	pvalue[i]=pvalues[i];
      else
	pvalue[i]=MISSING_VALUE;
    }
}

// initialize;
void regression_result::init(void)
{
  cooks=NULL;
  n=0;
  s_squared=NULL;
  coef=NULL;
  sdev_squared_coef=NULL;
  sqrresidual=0.0;
  t_observator=NULL;
  pvalue=NULL;
  num_coef=0;
  resid=NULL;
}

// Copies a regression result;
regression_result::regression_result(regression_result &orig)
{
  init();
  copy(orig);
}

// Copies a regression result;
void regression_result::copy(regression_result &orig)
{
  int i,j;

  cleanup();

  num_coef=orig.num_coef;
  sqrresidual=orig.sqrresidual;
  sigmasquared=orig.sigmasquared;
  n=orig.n;

  if(orig.coef)
    coef=new double[num_coef];
  if(orig.sdev_squared_coef)
    sdev_squared_coef=new double[num_coef];
  if(orig.t_observator)
    t_observator=new double[num_coef];
  if(orig.pvalue)
    pvalue=new double[num_coef];

  for(int i=0;i<num_coef;i++)
    {
      if(orig.coef)
	coef[i]=orig.coef[i];
      if(orig.sdev_squared_coef)
	sdev_squared_coef[i]=orig.sdev_squared_coef[i];
      if(orig.t_observator)
	t_observator[i]=orig.t_observator[i];
      if(orig.pvalue)
	pvalue[i]=orig.pvalue[i];
    }

  vartab=orig.vartab;
  if(orig.cooks)
    {
      cooks=new double[n];
      for(i=0;i<n;i++)
	cooks[i]=orig.cooks[i];
    }
  else
    cooks=NULL;

  if(orig.s_squared)
    {
      s_squared=new double*[num_coef];
      for(i=0;i<num_coef;i++)
	{
	  s_squared[i]=new double[num_coef];
	  for(j=0;j<num_coef;j++)
	    s_squared[i][j]=orig.s_squared[i][j];
	}
    }
  else
    s_squared=NULL;

  if(orig.resid)
    {
      if(resid)
	delete [] resid;
      resid=new double[n];
      for(i=0;i<n;i++)
	resid[i]=orig.resid[i];
    }
  else
    {
      if(resid)
	delete [] resid;
      resid=NULL;
    }
}

// destructor;
regression_result::~regression_result()
{
  cleanup();
}

// cleanup
void regression_result::cleanup(void)
{
  if(cooks)
    delete [] cooks;
  cooks=NULL;
  if(coef)
    delete [] coef;
  coef=NULL;
  if(sdev_squared_coef)
    delete [] sdev_squared_coef;
  sdev_squared_coef=NULL;
  if(t_observator)
    delete [] t_observator;
  t_observator=NULL;
  if(pvalue)
    delete [] pvalue;
  pvalue=NULL;
  if(s_squared)
    {
      for(int i=0;i<num_coef;i++)
	if(s_squared[i])
	  delete [] s_squared[i];
      delete [] s_squared;
    }
  s_squared=NULL;
  if(resid)
    delete [] resid;

  n=num_coef=0;
}

// Return a regression coefficient estimate specified by 'number'
double regression_result::get_coefficient(int number)
{
  return coef[number];
}

double regression_result::get_sum_of_square_residuals(void)
{
  return vartab.SS_res;
}

double *regression_result::get_residuals(void)
{
  return resid;
}

// Return the mean square residual;
double regression_result::get_mean_square_residual(void)
{
  return sqrresidual;
}

// Return the T observable (mean/sdev) for a given coefficient;
double regression_result::get_t_observator(int number)
{
  if(t_observator)
    return t_observator[number];
  else
    return MISSING_VALUE;
}

// Return the p-value derived from the T observable for a given
// coefficient;
double regression_result::get_pvalue(int number)
{
  if(pvalue)
    return pvalue[number];
  else
    return MISSING_VALUE;
}

// Returns the number of predictors used in this model;
int regression_result::get_number_of_predictors(void)
{
  return num_coef;
}

// Returns an estimate of the square standard deviation of the 
// model (sigma�);
double regression_result::get_square_standard_deviation(void)
{
  return sigmasquared;
}

// Returns cook's distance (a measure of an observations 
// effect on the regression) for a given observation (0<=number<n);
double regression_result::get_cooks_distance(int number)
{
  if(cooks)
    return cooks[number];
  else
    return MISSING_VALUE;
}

// Returns the variance table of this regression;
variance_table regression_result::get_variance_table(void)
{
  return vartab;
}

// Returns the estimated variance of the coefficient estimates for
// a given coefficient;
double regression_result::get_square_standard_deviation_coefficient(int number)
{
  return sdev_squared_coef[number];
}

// Returns the estimated covariance of the coefficient estimates for
// a given coefficient;
double regression_result::get_square_standard_deviation_coefficients(int num1,
								     int num2)
{
  if(s_squared && s_squared[num1])
    return s_squared[num1][num2];
  else
    return MISSING_VALUE;
}

double **regression_result::get_covariance_matrix(void)
{
  return s_squared;
}

double *regression_result::get_coefficient_vector(void)
{
  return coef;
}

// Performs a regssion analysis on the given predictors and response
// measurements. The predictor should have 'numpredictors' arrays
// each of size 'arraysize' while the response should have 'arraysize' 
// response measurements. 
regression_result *get_regression(double **predictor, int numpredictors,
				  double *response, int arraysize)
{
#ifndef GSL
  cerr << "Multi-predictor 'get_regression' not possible. GSL not found!" << 
    endl;
#else
  int i, j, k, l, n=arraysize, p=numpredictors+1, sign=1;
  double **X=new double*[n], **XtX=new double*[p], 
    **negXtX=new double*[p];
  double *H=new double[n];
  double *Xt_response=new double[p];
  double *coeff=new double[p];
  double *sdev_squared_coeff=new double[p];
  double *t_observator=new double[p];
  double *pvalue=new double[p];
  gsl_matrix *matrix=gsl_matrix_alloc(p,p);
  gsl_matrix *matrix2=gsl_matrix_alloc(p,p);
  gsl_permutation *perm=gsl_permutation_calloc(p);

  gsl_permutation_init(perm);

  // Want to solve Xt X coef = Xt response
  // => coef = (Xt X)^(-1) Xt response = negXtX Xt response

  // initialize;
  for(i=0;i<n;i++)
    {
      X[i]=new double[p];
      for(j=0;j<p;j++)
	X[i][j]=0.0;
      H[i]=0.0;
    }

  for(i=0;i<p;i++)
    {
      XtX[i]=new double[p];
      negXtX[i]=new double[p];
      for(j=0;j<p;j++)
	{
	  XtX[i][j]=0.0;
	  negXtX[i][j]=0.0;
	}
    }
  
  for(j=0;j<p;j++)
    {
      Xt_response[j]=0;
      coeff[j]=0.0;
    }


  // fill the X array (the reson for the structure is mathematical);
  for(i=0;i<n;i++)
    X[i][0]=1.0;
  for(j=1;j<p;j++)
    for(i=0;i<n;i++)
      X[i][j]=predictor[j-1][i];

  // calculate X-transpose (XT) times the response array
  for(i=0;i<n;i++)
    for(j=0;j<p;j++)
      Xt_response[j]+=X[i][j]*response[i];

  // find Xt * X;
  for(i=0;i<p;i++)
    for(j=0;j<p;j++)
      for(k=0;k<n;k++)
	XtX[i][j]+=X[k][i]*X[k][j];
  

  // use GSL to invert XtX;

  // put the values of XtX into a gsl matrix;
  for(i=0;i<p;i++)
    for(j=0;j<p;j++)
      gsl_matrix_set(matrix, i, j,  XtX[i][j]);

  // invert this matrix
  gsl_linalg_LU_decomp(matrix, perm, &sign);
  gsl_linalg_LU_invert(matrix, perm, matrix2);

  // fetch the values from the inverted matrix, 'matrix2' into negXtX;
  for(i=0;i<p;i++)
    for(j=0;j<p;j++)
      negXtX[i][j] = gsl_matrix_get(matrix2, i, j);

  // find the regression coefficients;
  for(i=0;i<p;i++)
    for(j=0;j<p;j++)
      coeff[i]+=negXtX[i][j]*Xt_response[j];
  
  double sqrresidual=0.0;
  double *resid=new double[arraysize];
  for(j=0;j<arraysize;j++)
    {
      double res=coeff[0];
      for(i=1;i<p;i++)
	res+=coeff[i]*predictor[i-1][j];
      res-=response[j];
      
      resid[j]=res;
      sqrresidual+=res*res;
    }

  double s2=sqrresidual/double(n-p);

  for(j=0;j<p;j++)
    {
      sdev_squared_coeff[j]=negXtX[j][j]*s2;
      t_observator[j]=coeff[j]/sqrt(sdev_squared_coeff[j]);
#ifdef GSL
      pvalue[j]=2.0*gsl_cdf_tdist_P(-ABSVAL(t_observator[j]), arraysize-p);
#else // NO GSL
      pvalue[j]=MISSING_VALUE;
#endif // GSL
#endif
    }

  for(i=0;i<n;i++)
    for(k=0;k<p;k++)
      for(l=0;l<p;l++)
	H[i] += X[i][k]*negXtX[k][l]*X[i][l];

  // put them into a structure;
  regression_result *ret=new regression_result(coeff, p, sqrresidual, s2,
					       sdev_squared_coeff, 
					       t_observator,pvalue,resid,n);
  
  ret->s_squared=new double*[p];
  for(i=0;i<p;i++)
    {
      ret->s_squared[i]=new double[p];
      for(j=0;j<p;j++)
	ret->s_squared[i][j]=negXtX[i][j]*s2;
    }

  ret->n=n;
  double *cooks = new double[n];
  for(i=0;i<n;i++)
    {
      double pred=coeff[0];
      for(j=0;j<numpredictors;j++)
	pred+=coeff[j+1]*predictor[j][i];
      double residual=response[i]-pred;

      cooks[i]=residual*residual/s2/ABSVAL(1.0-H[i])*H[i]/(1.0-H[i]);
    }

  ret->cooks=cooks;

  double meany=0.0;
  for(i=0;i<n;i++)
    meany+=response[i];
  meany/=double(n);

  double SSreg=0.0, SSres=0.0, SStot=0.0;
  for(i=0;i<p;i++)
    for(j=0;j<n;j++)
      SSreg+=coeff[i]*X[j][i]*response[j];

  for(i=0;i<n;i++)
    {
      double res=response[i];

      for(j=0;j<p;j++)
	res -= coeff[j]*X[i][j];

      SSres += res*res;
      //SSres += (response[i]*response[i];
      SStot += (response[i]*response[i]);
    }
  //SStot=SSres;
  
  //SSres -= SSreg;
  SSreg -= double(n)*meany*meany;
  SStot -= double(n)*meany*meany;

  double dfreg=double(p)-1, dfres=double(n-p), dftot=double(n)-1;
  double MSreg=SSreg/dfreg, MSres=SSres/dfres;
  double F=MSreg/MSres;
  double pF=MISSING_VALUE;

#ifdef GSL
  pF=1.0-gsl_cdf_fdist_P(F, p-1, n-p);
#endif // GSL


  variance_table vtab;
  vtab.Set(SSreg, dfreg, MSreg, SSres, dfres, MSres,
	   SStot, dftot, F, pF);
  ret->vartab=vtab;

  // cleanup;
  delete [] coeff;
  delete [] sdev_squared_coeff;
  delete [] t_observator;
  delete [] pvalue;
  gsl_matrix_free(matrix);
  gsl_matrix_free(matrix2);
  gsl_permutation_free(perm);
  for(i=0;i<n;i++)
    delete [] X[i];
  delete [] X;
  for(i=0;i<p;i++)
    delete [] XtX[i];
  delete [] XtX;
  for(i=0;i<p;i++)
    delete [] negXtX[i];
  delete [] negXtX;
  delete [] Xt_response;
  delete [] H;
  

  return ret; // return the result
}

// Predicts a new value based on incoming precitor values
// the array should have the number of elements complying
// to the rregression rule;
double regression_result::predict(double *predictor_values)
{
  double result=coef[0];
  for(int i=1;i<num_coef;i++)
    result+=coef[i]*predictor_values[i-1];
  return result;
}

// Performs a regssion analysis on the given predictors and response
// measurements and standard deviation of the different measurements. 
// This only works (for now) for the one-dimensional case.
// The predictor, respoonse and sdev should have size 'arraysize'.
regression_result *get_regression(double *predictor, double *response, 
				  double *sdev, int arraysize)
{
  double coeff[2],sdevs_squared[2],a,b,sdev_squared_a,sdev_squared_b;
  regression_result *ret;
  int j;
  double *pred=new double[arraysize], *resp=new double[arraysize];
  double pvalue[2], tobs[2];

  for(j=0;j<arraysize;j++)
    {
      pred[j]=predictor[j]/sdev[j];
      resp[j]=response[j]/sdev[j];
    }
  
  //regression_result *rr=get_regression(&predictor,1, value, num);
  a=0.0;
  b=0.0;

  double uv=0.0, uu=0.0, vv=0.0, zv=0.0, zu=0.0;
  for(j=0;j<arraysize;j++)
    {
      uv += pred[j]/sdev[j];
      uu += 1.0/sdev[j]/sdev[j];
      vv += pred[j]*pred[j];
      zv += resp[j]*pred[j];
      zu += resp[j]/sdev[j];
    }
  
  a=(zu*vv-zv*uv)/(uu*vv-uv*uv);
  b=(zv*uu-zu*uv)/(uu*vv-uv*uv);

  double sqrresidual=0.0;
  double *resid=new double[arraysize];
  for(j=0;j<arraysize;j++)
    {
      resid[j]= resp[j] - a/sdev[j]-b*pred[j];
      sqrresidual += resid[j]*resid[j];
    }
    
  double s2 = sqrresidual/double(arraysize-2);
  sdev_squared_a = s2*uu*vv/(double(arraysize)*uu*vv-uv*uv);
  sdev_squared_b = double(arraysize)*s2/(double(arraysize)*uu*vv-uv*uv);

  coeff[0]=a;
  coeff[1]=b;
  sdevs_squared[0]=sdev_squared_a;
  sdevs_squared[1]=sdev_squared_b;
  tobs[0]=coeff[0]/sqrt(sdevs_squared[0]);
  tobs[1]=coeff[1]/sqrt(sdevs_squared[1]);
#ifdef GSL
  pvalue[0]=gsl_cdf_tdist_P(tobs[0], arraysize-2);
  pvalue[1]=gsl_cdf_tdist_P(tobs[1], arraysize-2);
#else // no GSL
  pvalue[0]=MISSING_VALUE;
  pvalue[1]=MISSING_VALUE;
#endif // GSL 

  // put them into a structure;
  ret=new regression_result(coeff, 2, sqrresidual, s2, sdevs_squared,
			    tobs, pvalue);

  delete [] pred;
  delete [] resp;

  return ret; // return the result
}







// **********************************************
//
//     LOGISTIC_REGRESSION
//
// Should contain the necessary components of 
// a logistic regression analysis.
//
// **********************************************


// cleanup
void logistic_regression::cleanup(void)
{
  if(coef)
    delete [] coef;
  coef=NULL;
  n=num_coef=0;
}


// initialize;
void logistic_regression::init(void)
{
  n=0;
  coef=NULL;
  num_coef=0;
}

// Constructor
// Stores all relevant info from an analysis already done;
logistic_regression::logistic_regression(double *coefficients, 
					 int number_of_coefficients,
					 int num_measurement)
{
  n=num_measurement;
  coef=new double[number_of_coefficients];
  num_coef=number_of_coefficients;

  for(int i=0;i<num_coef;i++)
    coef[i]=coefficients[i];
}


// Copies a regression result;
logistic_regression::logistic_regression(logistic_regression &orig)
{
  init();
  copy(orig);
}

// Copies a regression result;
void logistic_regression::copy(logistic_regression &orig)
{
  cleanup();

  num_coef=orig.num_coef;

  if(orig.coef)
    {
      coef=new double[num_coef];
      for(int i=0;i<num_coef;i++)
	coef[i]=orig.coef[i];
    }
}

// destructor;
logistic_regression::~logistic_regression()
{
  cleanup();
}


// Returns the number of predictors used in this model;
int logistic_regression::get_number_of_predictors(void)
{
  return num_coef;
}

// Return a regression coefficient estimate specified by 'number'
double logistic_regression::get_coefficient(int number)
{
  return coef[number];
}


// Predicts an outcome probability based on incoming precitor values
// the array should have the number of elements complying
// to the regression rule;
double logistic_regression::predict(double *predictor_values)
{
  double result=0.0;

  for(int i=0;i<num_coef;i++)
    result+=coef[i]*predictor_values[i];
  
  return exp(result)/(1.0+exp(result));
}


// Performs a regssion analysis on the given predictors and response
// measurements. The predictor should have 'numpredictors' arrays
// each of size 'arraysize' while the response should have 'arraysize' 
// response measurements. PS: fixed constant part
logistic_regression *get_logistic_regression(double **predictor, 
					     int numpredictors,
					     long int *response, 
					     long int *numresponse,
					     int arraysize)
{
  int i,j,k;
  double *numresp2=new double[arraysize], *resp2=new double[arraysize];
  for(i=0;i<arraysize;i++)
    {
      numresp2[i]=numresponse[i];
      resp2[i]=response[i];
    }
  
  Matrix X(predictor, numpredictors, arraysize);
  vector y(resp2, arraysize);
  vector n(numresp2, arraysize);
  vector pi(arraysize), piinv(arraysize);
  vector b(numpredictors), JinvU(numpredictors);
  vector U(numpredictors);
  double diff=1.0;
  
  delete [] numresp2;
  delete [] resp2;
  
  while(diff>0.0001)
    {
      for(k=0;k<arraysize;k++)
	{
	  double nu=0;
	  for(i=0;i<numpredictors;i++)
	    nu += predictor[i][k]*b(i);
	  
	  pi.set_element(k, exp(nu)/(1.0+exp(nu)));
	  piinv.set_element(k, pi(k)*(1.0-pi(k)));
	}
      
      Matrix J(numpredictors,numpredictors);
      Matrix Jinv(numpredictors,numpredictors);
      for(i=0;i<numpredictors;i++)
	for(j=0;j<numpredictors;j++)
	  {
	    double res=0;
	    for(k=0;k<arraysize;k++)
	      res += piinv(k)*X(i,k)*X(j,k)*n(k);
	    
	    J.set_element(i,j,res);
	  }

      for(i=0;i<numpredictors;i++)
	{
	  double res=0;
	  for(k=0;k<arraysize;k++)
	    res += X(i,k)*(y(k)-n(k)*pi(k));
	  
	  U.set_element(i,res);
	}
      
      Jinv=inverse(J);
      JinvU=Jinv*U;
      
      b=b+JinvU;
      diff=JinvU.length();
    }
  
  double *coef=b.get_as_double_array();

  logistic_regression *result=new logistic_regression(coef, numpredictors,
						      arraysize);

  return result;
}




// **********************************************
//
//     POISSON_REGRESSION
//
// Should contain the necessary components of 
// a Poisson regression analysis.
//
// **********************************************



// cleanup
void poisson_regression::cleanup(void)
{
  if(coef)
    delete [] coef;
  coef=NULL;
  n=num_coef=0;
  loglik=MISSING_VALUE;
}


// initialize;
void poisson_regression::init(void)
{
  n=0;
  coef=NULL;
  num_coef=0;
  loglik=MISSING_VALUE;
}

// Constructor
// Stores all relevant info from an analysis already done;
poisson_regression::poisson_regression(double *coefficients, 
				       int number_of_coefficients,
				       int num_measurement, 
				       double log_likelihood)
{
  n=num_measurement;
  coef=new double[number_of_coefficients];
  num_coef=number_of_coefficients;

  for(int i=0;i<num_coef;i++)
    coef[i]=coefficients[i];
  loglik=log_likelihood;
}


// Copies a regression result;
poisson_regression::poisson_regression(poisson_regression &orig)
{
  init();
  copy(orig);
}

// Copies a regression result;
void poisson_regression::copy(poisson_regression &orig)
{
  cleanup();

  num_coef=orig.num_coef;

  if(orig.coef)
    {
      coef=new double[num_coef];
      for(int i=0;i<num_coef;i++)
	coef[i]=orig.coef[i];
    }
  loglik=orig.loglik;
}

// destructor;
poisson_regression::~poisson_regression()
{
  cleanup();
}


// Returns the number of predictors used in this model;
int poisson_regression::get_number_of_predictors(void)
{
  return num_coef;
}

// Return a regression coefficient estimate specified by 'number'
double poisson_regression::get_coefficient(int number)
{
  return coef[number];
}


// Return log-likelihood
double poisson_regression::get_loglik(void)
{
  return loglik;
}

// Predicts an outcome probability based on incoming precitor values
// the array should have the number of elements complying
// to the regression rule;
double poisson_regression::predict(double *predictor_values)
{
  double result=0.0;
  
  for(int i=0;i<num_coef;i++)
    result+=coef[i]*predictor_values[i];
  
  return exp(result);
}

// Performs a regssion analysis on the given predictors and response
// measurements. The predictor should have 'numpredictors' arrays
// each of size 'arraysize' while the response should have 'arraysize' 
// response measurements. PS: fixed constant part
poisson_regression *get_poisson_regression(double **predictor, 
					   int numpredictors,
					   long int *response, 
					   double *exposure,
					   int datasize)
{
  int i,j,k;
  double *resp2=new double[datasize];
  for(i=0;i<datasize;i++)
    resp2[i]=response[i];
  
  Matrix X(predictor, numpredictors, datasize);
  vector y(resp2, datasize);
  vector n(exposure, datasize);
  vector theta(datasize);
  vector b(numpredictors), JinvU(numpredictors);
  vector U(numpredictors);
  double diff=1.0;
  double loglik=0.0;

  delete [] resp2;
  
  while(diff>0.0001)
    {
      for(k=0;k<datasize;k++)
	{
	  double nu=0;
	  for(i=0;i<numpredictors;i++)
	    nu += predictor[i][k]*b(i);
	  
	  theta.set_element(k, exp(nu));
	}
      
      Matrix J(numpredictors,numpredictors);
      Matrix Jinv(numpredictors,numpredictors);
      for(i=0;i<numpredictors;i++)
	for(j=0;j<numpredictors;j++)
	  {
	    double res=0;
	    for(k=0;k<datasize;k++)
	      res += theta(k)*X(i,k)*X(j,k)*n(k);
	    
	    J.set_element(i,j,res);
	  }

      for(i=0;i<numpredictors;i++)
	{
	  double res=0;
	  for(k=0;k<datasize;k++)
	    res += X(i,k)*(y(k)-n(k)*theta(k));
	  
	  U.set_element(i,res);
	}
      
      Jinv=inverse(J);
      JinvU=Jinv*U;
      
      b=b+JinvU;
      diff=JinvU.length();
    }
  
  double *coef=b.get_as_double_array();

  for(k=0;k<datasize;k++)
    {
      double y=double(response[k]);
      double logpred=0.0,pred;
      for(i=0;i<numpredictors;i++)
	logpred+=coef[i]*predictor[i][k];
      pred=exp(logpred);

      loglik += y*logpred-pred-lgamma(y+1.0);
    }

  poisson_regression *result=new poisson_regression(coef, numpredictors,
						    datasize, loglik);

  return result;
}


double p_value_likelihood_ratio(double loglik_alternative_hypothesis,
				int degree_freedom_alternative_hypothesis,
				double loglik_null_hypothesis,
				int degree_freedom_null_hypothesis)
{
#ifdef GSL
  if(loglik_alternative_hypothesis==MISSING_VALUE || 
     loglik_null_hypothesis==MISSING_VALUE || 
     loglik_alternative_hypothesis<loglik_null_hypothesis ||
     degree_freedom_alternative_hypothesis==(int)MISSING_VALUE || 
     degree_freedom_null_hypothesis==(int)MISSING_VALUE || 
     degree_freedom_alternative_hypothesis<=degree_freedom_null_hypothesis)
    return MISSING_VALUE;

  double D=2.0*(loglik_alternative_hypothesis-loglik_null_hypothesis);
  double df=double(degree_freedom_alternative_hypothesis-
		   degree_freedom_null_hypothesis);
  double pvalue=gsl_cdf_chisq_Q(D,df);
  
  return pvalue;
#else // no GSL
  return MISSING_VALUE;
#endif // GSL
}


double p_value_likelihood_ratio(poisson_regression *alternative_hypothesis,
				poisson_regression *null_hypothesis)
{
  if(!alternative_hypothesis || !null_hypothesis)
    return MISSING_VALUE;
  
  double loglik_alt=alternative_hypothesis->get_loglik();
  double loglik_null=null_hypothesis->get_loglik();
  int df_alt=alternative_hypothesis->get_number_of_predictors();
  int df_null=null_hypothesis->get_number_of_predictors();
  
  return p_value_likelihood_ratio(loglik_alt,df_alt,loglik_null, df_null);
}




// **********************************************
//
//     BAYESIAN_REGRESSION
//
// Should contain the necessary components of 
// a Bayesian regression analysis.
//
// **********************************************

void bayesian_regression::cleanup(void)
{
  if(residuals)
    delete [] residuals;
  residuals=NULL;

  doubledelete(prior_V, num_coef);
  prior_V=NULL;

  if(prior_coefficient_removal_probability)
    delete [] prior_coefficient_removal_probability;
  prior_coefficient_removal_probability=NULL;

  if(prior_m)
    delete [] prior_m;
  prior_m=NULL;

  prior_a=prior_b=0.0;

  if(posteriori_coefficient_removal_probability)
    delete [] posteriori_coefficient_removal_probability;
  posteriori_coefficient_removal_probability=NULL;

  doubledelete(posteriori_V, num_coef);
  posteriori_V=NULL;

  if(posteriori_m)
    delete [] posteriori_m;
  posteriori_m=NULL;

  posteriori_a=posteriori_b=0.0;

  num_coef=n=0;
}

void bayesian_regression::init(void)
{
  residuals=NULL;

  prior_V=NULL;
  prior_m=NULL;

  prior_a=prior_b=0.0;
  prior_coefficient_removal_probability=NULL;

  posteriori_V=NULL;
  posteriori_m=NULL;

  posteriori_a=posteriori_b=0.0;
  posteriori_coefficient_removal_probability=NULL;

  num_coef=n=0;
}

bayesian_regression::bayesian_regression(bayesian_regression &orig)
{
  init();
  copy(orig);
}

bayesian_regression::
  bayesian_regression(double *prior_mean_coefficients,
		      double **prior_variance_coefficients,
		      double prior_a_, double prior_b_,
		      double *posteriori_mean_coefficients, 
		      double **posteriori_variance_coefficients,
		      double posteriori_a_, double posteriori_b_,
		      int number_of_coefficients,
		      int number_of_observations,
		      double *new_residuals,
		      double *prior_coefficient_removal_probability_,
		      double *posteriori_coefficient_removal_probability_)
{
  int i,j;

  init();

  num_coef=number_of_coefficients;
  n=number_of_observations;

  prior_a=prior_a_;
  prior_b=prior_b_;
  posteriori_a=posteriori_a_;
  posteriori_b=posteriori_b_;

  if(new_residuals)
    {
      residuals=new double[n];
      for(i=0;i<n;i++)
	residuals[i]=new_residuals[i];
    }

  if(num_coef>0)
    {
      prior_m=new double[num_coef];
      prior_V=new double*[num_coef];
      posteriori_m=new double[num_coef];
      posteriori_V=new double*[num_coef];
      
      for(i=0;i<num_coef;i++)
	{
	  prior_m[i]=prior_mean_coefficients[i];
	  prior_V[i]=new double[num_coef];
	  posteriori_m[i]=posteriori_mean_coefficients[i];
	  posteriori_V[i]=new double[num_coef];
	  for(j=0;j<num_coef;j++)
	    {
	      prior_V[i][j]=prior_variance_coefficients[i][j];
	      posteriori_V[i][j]=posteriori_variance_coefficients[i][j];
	    }
	}
      
      if(prior_coefficient_removal_probability_)
	{
	  prior_coefficient_removal_probability=new double[num_coef];
	  for(i=0;i<num_coef;i++)
	    prior_coefficient_removal_probability[i]=
	      prior_coefficient_removal_probability_[i];
	}
      else
	prior_coefficient_removal_probability=NULL;

      if(posteriori_coefficient_removal_probability_)
	{
	  posteriori_coefficient_removal_probability=new double[num_coef];
	  for(i=0;i<num_coef;i++)
	    posteriori_coefficient_removal_probability[i]=
	      posteriori_coefficient_removal_probability_[i];
	}
      else
	posteriori_coefficient_removal_probability=NULL;
    }
  
  prior_full_model=posteriori_full_model=1.0;
  prior_no_predictors=posteriori_no_predictors=
    prior_only_constant=posteriori_only_constant=0.0;
  posteriori_auto=prior_auto=0.0;
  posteriori_nonauto=prior_nonauto=0.0;
}

bayesian_regression::~bayesian_regression()
{
  cleanup();
}

int bayesian_regression::get_number_of_predictors(void)
{
  return num_coef;
}

double bayesian_regression::get_mean_coefficient(int number,
						 bool posterior)
{
  if(number>=0 && number<num_coef)
    {
      if(posterior)
	return posteriori_m[number];
      else
	return prior_m[number];
    }
  else
    return MISSING_VALUE;
}

double bayesian_regression::get_mean_square_standard_deviation(bool posterior)
{
  if(posterior)
    return posteriori_b/(posteriori_a-1.0);
  else
    return prior_b/(prior_a-1.0);
}

double bayesian_regression::get_sdev_square_standard_deviation(bool posterior)
{
  if(posterior)
    return sqrt(posteriori_b/(posteriori_a-1.0)/(posteriori_a-2.0));
  else
    return sqrt(prior_b/(prior_a-1.0)/(prior_a-2.0));
}

double bayesian_regression::
get_covariance_coefficient(int number1, int number2,
			   bool posterior,
			   bool estimate_standard_devation)
{
  double sigma2=get_mean_square_standard_deviation(posterior);
  if(!estimate_standard_devation)
    sigma2=1.0;

  if(number1>=0 && number1<num_coef && 
     number2>=0 && number2<num_coef)
    {
      if(posterior)
	return posteriori_V[number1][number2]*sigma2;
      else
	return prior_V[number1][number2]*sigma2;
    }
  else
    return MISSING_VALUE;
}

double bayesian_regression::
get_coefficient_removal_probability(int number, 
				    bool posterior)
{
  if(number>=0 && number<num_coef &&
     ((posterior && posteriori_coefficient_removal_probability) ||
      (!posterior && prior_coefficient_removal_probability)))
    {
      if(posterior)
	return posteriori_coefficient_removal_probability[number];
      else
	return prior_coefficient_removal_probability[number];
    }
  return MISSING_VALUE;
}

double bayesian_regression::get_sigma_a(bool posterior)
{
  if(posterior)
    return posteriori_a;
  else
    return prior_a;
}

double bayesian_regression::get_sigma_b(bool posterior)
{
  if(posterior)
    return posteriori_b;
  else
    return prior_b;
}

double **bayesian_regression::get_V(bool posterior)
{
  if(posterior)
    return posteriori_V;
  else
    return prior_V;
}

double *bayesian_regression::get_m(bool posterior)
{
  if(posterior)
    return posteriori_m;
  else
    return prior_m;
}

double bayesian_regression::get_V_elem(int index1, int index2, 
				       bool posterior)
{
  if(posterior)
    return posteriori_V[index1][index2];
  else
    return prior_V[index1][index2];
}

void bayesian_regression::copy(bayesian_regression &orig)
{
  cleanup();

  num_coef=orig.num_coef;
  n=orig.n;

  prior_a=orig.prior_a;
  prior_b=orig.prior_b;
  posteriori_a=orig.posteriori_a;
  posteriori_b=orig.posteriori_b;
  
  prior_m=new double[num_coef];
  posteriori_m=new double[num_coef];
  prior_V=new double*[num_coef];
  posteriori_V=new double*[num_coef];

  if(orig.prior_coefficient_removal_probability)
    prior_coefficient_removal_probability=new double[num_coef];
  if(orig.posteriori_coefficient_removal_probability)
    posteriori_coefficient_removal_probability=new double[num_coef];

  prior_auto=orig.prior_auto;
  prior_nonauto=orig.prior_nonauto;
  posteriori_auto=orig.posteriori_auto;
  posteriori_nonauto=orig.posteriori_nonauto;

  if(orig.residuals)
    {
      residuals=new double[n];
      for(int i=0;i<n;i++)
	residuals[i]=orig.residuals[i];
    }

  for(int i=0;i<num_coef;i++)
    {
      prior_m[i]=orig.prior_m[i];
      posteriori_m[i]=orig.posteriori_m[i];
      prior_V[i]=new double[num_coef];
      posteriori_V[i]=new double[num_coef];
      if(orig.prior_coefficient_removal_probability)
	prior_coefficient_removal_probability[i]=
	  orig.prior_coefficient_removal_probability[i];
      if(orig.posteriori_coefficient_removal_probability)
	posteriori_coefficient_removal_probability[i]=
	  orig.posteriori_coefficient_removal_probability[i];

      for(int j=0;j<num_coef;j++)
	{
	  prior_V[i][j]=orig.prior_V[i][j];
	  posteriori_V[i][j]=orig.posteriori_V[i][j];
	}
    }
}

void bayesian_regression::print(std::ostream &out)
{
  int i,j;
  double posterior=1.0, prior=1.0;
  char buffer[400];
  
  sprintf(buffer, "a=%f b=%f E(sigma)=%f sdev(sigma)=%f",
	  posteriori_a, posteriori_b,
	  get_mean_square_standard_deviation(),
	  get_sdev_square_standard_deviation());
  out << buffer << std::endl;
  for(i=0;i<num_coef;i++)
    {
      sprintf(buffer, "Coefficient %d: %f sdev=%f (%f - %f)", i,
	      get_mean_coefficient(i),
	      sqrt(get_covariance_coefficient(i,i)),
	      lower_coefficient_credibility(i,0.95),
	      upper_coefficient_credibility(i,0.95));
      out << buffer;
      if(posteriori_coefficient_removal_probability)
	{
	  sprintf(buffer," prob of coef=0:%7.3g%%", 
		  posteriori_coefficient_removal_probability[i]*100.0);
	  out << buffer;
	  posterior-=posteriori_coefficient_removal_probability[i];

	  if(prior_coefficient_removal_probability)
	    {
	      sprintf(buffer, " (prior:%7.3g%%)", 
		      prior_coefficient_removal_probability[i]*100.0);
	      out << buffer << std::endl;
	      prior-=prior_coefficient_removal_probability[i];
	    }
	}
      out << std::endl;
    }

  if(posteriori_coefficient_removal_probability || 
     prior_no_predictors>0.0 || prior_only_constant>0.0)
    {
      sprintf(buffer, "Full model probability: %7.3g%%", 
	      posteriori_full_model*100.0);
      out << buffer;
      sprintf(buffer, " (prior: %7.3g%%)", prior_full_model*100.0);
      out << buffer << std::endl;

      if(prior_no_predictors>0.0)
	{
	  sprintf(buffer, "No predictor probability: %7.3g%%", 
		  posteriori_no_predictors*100.0);
	  out << buffer;
	  sprintf(buffer, " (prior: %7.3g%%)", prior_no_predictors*100.0);
	  out << buffer << std::endl;
	}

      if(prior_only_constant>0.0)
	{
	  sprintf(buffer, "No predictor probability: %7.3g%%", 
		  posteriori_only_constant*100.0);
	  out << buffer;
	  sprintf(buffer, " (prior: %7.3g%%)", prior_only_constant*100.0);
	  out << buffer << std::endl;
	}
    }

  if(prior_auto>0.0)
    {
      sprintf(buffer, "Autoregression probability: %7.3g%% (prior: %7.3g %%)",
	      posteriori_auto*100.0, prior_auto*100.0);
      out << buffer << std::endl;
    }

  for(i=0;i<num_coef;i++)
    for(j=0;j<num_coef;j++)
      {
	sprintf(buffer, "V(%d)(%d)=%f", i, j, posteriori_V[i][j]);
	out << buffer << std::endl;
      }
}

double *bayesian_regression::get_residuals(void)
{
  return residuals;
}

// Predicts a new value based on incoming precitor values
// the array should have the number of elements complying
// to the regression rule; (Remember to set predictor[0]=1 if you've
// used a constant term!)
double bayesian_regression::predict(double *predictor_values,
					   bool posterior)
{
  double ret=0.0;
  for(int i=0;i<num_coef;i++)
    if(posterior)
      ret+=posteriori_m[i]*predictor_values[i];
    else
      ret+=prior_m[i]*predictor_values[i];

  return ret;
}

// help function. calculates trans(predictor_values)*V*predictor_values;
double bayesian_regression::estimate_variance(double *predictor_values,
						     bool posterior)
{
  double ret=0.0;

  for(int i=0;i<num_coef;i++)
    for(int j=0;j<num_coef;j++)
      if(posterior)
	ret+=predictor_values[i]*posteriori_V[i][j]*predictor_values[j];
      else
	ret+=predictor_values[i]*prior_V[i][j]*predictor_values[j];

  return ret;
}

// samples from predicted measurements;
double *bayesian_regression::
sample_prediction(double *predictor_values, int num,
		  bool posterior)
{
  double mean=predict(predictor_values, posterior);
  double *ret=new double[num];
  double v=1.0+estimate_variance(predictor_values, posterior);
  int i;    

  for(i=0;i<num;i++)
    if(posterior)
      ret[i]=sample_from_student_t(mean, posteriori_b*v, posteriori_a);
    else
      ret[i]=sample_from_student_t(mean, prior_b*v, prior_a);
    
  return ret;
}

//samples from estimates;
double *bayesian_regression::
sample_estimates(double *predictor_values, int num,
		 bool posterior,
		 bool indirect_sampling)
{
  double mean=predict(predictor_values, posterior);
  double *ret=new double[num];
  double v=estimate_variance(predictor_values, posterior);
  int i,j,k;    
  
  for(i=0;i<num;i++)
    {
      if(!indirect_sampling)
	{
	  if(posterior)
	    ret[i]=sample_from_student_t(mean, posteriori_b*v, posteriori_a);
	  else
	    ret[i]=sample_from_student_t(mean, prior_b*v, prior_a);
	}
      else
	{
	  static gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
	  double sigma2;

	  if(posterior)
	    sigma2=1.0/gsl_ran_gamma(rptr,posteriori_a,1.0/posteriori_b);
	  else
	    sigma2=1.0/gsl_ran_gamma(rptr,prior_a,1.0/prior_b);
	  
	  double **S=new double*[num_coef];
	  for(j=0;j<num_coef;j++)
	    {
	      S[j]=new double[num_coef];
	      for(k=0;k<num_coef;k++)
		if(posterior)
		  S[j][k]=posteriori_V[j][k]*sigma2;
		else
		  S[j][k]=prior_V[j][k]*sigma2;

	    }

	  double *u=new double[num_coef];
	  for(k=0;k<num_coef;k++)
	    u[k]=gauss();

	  Matrix m(S,num_coef,num_coef),*c;
	  vector U(u,num_coef),X;
	  
	  c=cholesky_decompose(m);
	  for(j=0;j<num_coef;j++)
	    for(k=j+1;k<num_coef;k++)
	      c->set_element(j,k,0.0);
	  X=(*c)*U;

	  delete c;

	  for(j=0;j<num_coef;j++)
	    {
	      double mu=posteriori_m[j];
	      if(!posterior)
		mu=prior_m[j];

	      X.set_element(j, X(j)+mu);
	    }
	  
	  //cout << exp(X(0)) << " "  << X(1) << std::endl;

	  ret[i]=0;
	  for(j=0;j<num_coef;j++)
	    ret[i]+=X(j)*predictor_values[j];
	}
    }
  
  return ret;
}

// Returns a sample from the prior or a posteriori distribution
// of the coefficients, with p+1 arrays, where the last
// array is that of sigma�.
double **bayesian_regression::sample_coefficients(int num, bool posterior)
{
  double **ret=new double*[num_coef+1];
  int i,j,k;    
  
  for(i=0;i<num_coef+1;i++)
    ret[i]=new double[num];
  
  for(i=0;i<num;i++)
    {
      static gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
      double sigma2;
      
      if(posterior)
	sigma2=1.0/gsl_ran_gamma(rptr,posteriori_a,1.0/posteriori_b);
      else
	sigma2=1.0/gsl_ran_gamma(rptr,prior_a,1.0/prior_b);
      
      double **S=new double*[num_coef];
      for(j=0;j<num_coef;j++)
	{
	  S[j]=new double[num_coef];
	  for(k=0;k<num_coef;k++)
	    if(posterior)
	      S[j][k]=posteriori_V[j][k]*sigma2;
	    else
	      S[j][k]=prior_V[j][k]*sigma2;  
	}
      
      double *u=new double[num_coef];
      for(k=0;k<num_coef;k++)
	u[k]=gauss();
      
      Matrix m(S,num_coef,num_coef),*c;
      vector U(u,num_coef),X;
      
      c=cholesky_decompose(m);
      for(j=0;j<num_coef;j++)
	for(k=j+1;k<num_coef;k++)
	  c->set_element(j,k,0.0);
      X=(*c)*U;

      delete c;

      for(j=0;j<num_coef;j++)
	{
	  double mu=posteriori_m[j];
	  if(!posterior)
	    mu=prior_m[j];
	  
	  X.set_element(j, X(j)+mu);
	}
      
      for(j=0;j<num_coef;j++)
	ret[j][i]=X(j);
      ret[num_coef][i]=sigma2;
    }

  return ret;
}

double bayesian_regression::
upper_prediction_credibility(double *predictor_values, 
			     double credibility,
			     bool posterior)
{
  double mean=predict(predictor_values, posterior);
  double v=1.0+estimate_variance(predictor_values, posterior);

  if(posterior)
    return inv_cdf_student_t(mean, posteriori_b*v, posteriori_a, 
			     (1.0+credibility)/2.0);
  else
    return inv_cdf_student_t(mean, prior_b*v, prior_a, 
			     (1.0+credibility)/2.0);

}

double bayesian_regression::
lower_prediction_credibility(double *predictor_values, 
			     double credibility,
			     bool posterior)
{
  double mean=predict(predictor_values, posterior);
  double v=1.0+estimate_variance(predictor_values, posterior);
  
  if(posterior)
    return inv_cdf_student_t(mean, posteriori_b*v, posteriori_a, 
			     (1.0-credibility)/2.0);
  else
    return inv_cdf_student_t(mean, prior_b*v, prior_a, 
			     (1.0-credibility)/2.0);
}


double bayesian_regression::
upper_estimate_credibility(double *predictor_values, 
			   double credibility,
			   bool posterior)
{
  double mean=predict(predictor_values, posterior);
  double v=estimate_variance(predictor_values, posterior);
  
  if(posterior)
    return inv_cdf_student_t(mean, posteriori_b*v, posteriori_a, 
			     (1.0+credibility)/2.0);
  else
    return inv_cdf_student_t(mean, prior_b*v, prior_a, 
			     (1.0+credibility)/2.0);

}

double bayesian_regression::
lower_estimate_credibility(double *predictor_values, 
			   double credibility,
			   bool posterior)
{
  double mean=predict(predictor_values, posterior);
  double v=estimate_variance(predictor_values, posterior);
  
  if(posterior)
    return inv_cdf_student_t(mean, posteriori_b*v, posteriori_a, 
			     (1.0-credibility)/2.0);
  else
    return inv_cdf_student_t(mean, prior_b*v, prior_a, 
			     (1.0-credibility)/2.0);
}

double bayesian_regression::
upper_coefficient_credibility(int number, double credibility,
			      bool posterior)
{
  if(number>=0 && number<num_coef)
    {
      if(posterior)
	return inv_cdf_student_t(posteriori_m[number], 
				 posteriori_b*posteriori_V[number][number],
				 posteriori_a, (1.0+credibility)/2.0);
      else
	return inv_cdf_student_t(prior_m[number], 
				 prior_b*prior_V[number][number],
				 prior_a, (1.0+credibility)/2.0);
    }
  else
    return MISSING_VALUE;
}

double bayesian_regression::
lower_coefficient_credibility(int number, double credibility,
			      bool posterior)
{
  if(number>=0 && number<num_coef)
    {
      if(posterior)
	return inv_cdf_student_t(posteriori_m[number], 
				 posteriori_b*posteriori_V[number][number],
				 posteriori_a, (1.0-credibility)/2.0);
      else
	return inv_cdf_student_t(prior_m[number], 
				 prior_b*prior_V[number][number],
				 prior_a, (1.0-credibility)/2.0);
    }
  else
    return MISSING_VALUE;
}

// Probabilities of submodels;
double bayesian_regression::probability_zero_coefficient(int number, 
							 bool posterior)
{
  if(number<0 || number>=num_coef)
    return MISSING_VALUE;

  if(!prior_coefficient_removal_probability || 
     !posteriori_coefficient_removal_probability)
    return 0.0;

  if(posterior)
    return posteriori_coefficient_removal_probability[number];
  else
    return prior_coefficient_removal_probability[number];
}

double bayesian_regression::probability_only_constant(bool posterior)
{
  if(posterior)
    return posteriori_only_constant;
  else
    return prior_only_constant;
}

double bayesian_regression::probability_all_zero(bool posterior)
{
  if(posterior)
    return posteriori_no_predictors;
  else
    return prior_no_predictors;
}

double bayesian_regression::probability_full_model(bool posterior)
{
  if(posterior)
    return posteriori_full_model;
  else
    return prior_full_model;
}

// auto correlation (probabilities independent og the previous);
double bayesian_regression::probability_autocorrelation(bool posterior)
{
  if(posterior)
    return posteriori_auto;
  else
    return prior_auto;
}

double bayesian_regression::probability_no_autocorrelation(bool posterior)
{
  if(posterior)
    return posteriori_nonauto;
  else
    return prior_nonauto;
}


// returns the posterior denisty of the data
// used for calculating the posteriori probability of the model
double bayesian_regression::
probability_density_of_data(bool logarithmic, double log_rescale)
{
  double prior_result, post_result, result;
  double k=double(num_coef);

  if(num_coef>0)
    {
      if(prior_a>0.0)
	prior_result=0.5*log(ABSVAL((determinant_matrix(prior_V, num_coef))))-
	  log(prior_b)*prior_a + lgamma(prior_a) + 0.5*k*log(2.0*M_PI);
      else // can only be used to compare two models with a=0
	prior_result=0.5*log(ABSVAL((determinant_matrix(prior_V, num_coef)))) 
	  + 0.5*k*log(2.0*M_PI);
	
      post_result=
	0.5*log(ABSVAL((determinant_matrix(posteriori_V, num_coef))))-
	log(posteriori_b)*posteriori_a + lgamma(posteriori_a)-
	double(n)/2.0*log(2.0*M_PI) + 0.5*k*log(2.0*M_PI);
      
      //cout << determinant_matrix(posteriori_V, num_coef) << " " << 
      //ABSVAL((determinant_matrix(posteriori_V, num_coef))) << " " << 
      //log(ABSVAL((determinant_matrix(posteriori_V, num_coef)))) << " " 
      //   << post_result << std::endl;
    }
  else
    {
      if(prior_a>0.0)
	prior_result = -log(prior_b)*prior_a + lgamma(prior_a);
      else
	prior_result=0.0;
      post_result  = -log(posteriori_b)*posteriori_a + lgamma(posteriori_a);
    }
  
  result=post_result-prior_result;
  if(log_rescale)
    result-=log_rescale;
  
  if(logarithmic)
    return result;
  else
    return exp(result);
}



// Bayesian regression
// PS: no fixed constant part
bayesian_regression 
*get_bayesian_regression(double **predictor, int numpredictors,
			 double *response, int arraysize,
			 double *expected_coef, 
			 // coefficient variance
			 double **V, 
			 // sigma�~IG(a,b)
			 double a, double b,

			 bool find_residuals,

			 // if this one's specified, all models
			 // derived by removing one predictor type
			 // will be examined
			 // PS: The probabilities should not sum
			 // to one. Leave som probability for the 
			 // full model!
			 double *probability_of_submodels,
			 double probability_no_predictors,
			 double probability_only_constant,
			 
			 // This probability is independent of the previous
			 // model probabilities;
			 double probability_of_autoregressivity)
{
  int i,j,k,l,num_coef=numpredictors, n=arraysize;
  if(num_coef==0)
    {
      double pa=a+double(n)/2.0;
      double pb=b;
      
      for(k=0;k<n;k++)
	pb+=0.5*response[k]*response[k];

      bayesian_regression *result=
	new bayesian_regression(NULL,NULL,a,b,NULL,NULL,pa,pb,0,n);

      return result;
    }
  
  double *m=expected_coef, *pm=new double[num_coef];
  double **pV, **inv_pV;
  double pa=a,pb=b;
  double **XtX=new double*[num_coef], 
    **inv_V=inverse_matrix(V, num_coef);
  double *Xt_response=new double[num_coef];

  for(i=0;i<num_coef;i++)
    XtX[i]=new double[num_coef];

  for(i=0;i<num_coef;i++)
    for(j=0;j<num_coef;j++)
      {
	XtX[i][j]=inv_V[i][j];

	for(k=0;k<n;k++)
	  XtX[i][j]+=predictor[i][k]*predictor[j][k];
      }
  pV=inverse_matrix(XtX, num_coef);
  
  for(i=0;i<num_coef;i++)
    {
      Xt_response[i]=0.0;

      for(j=0;j<num_coef;j++)
	Xt_response[i] += inv_V[i][j]*m[j];

      for(k=0;k<n;k++)
	Xt_response[i] += predictor[i][k]*response[k];
    }

  //inv_pV=inverse_matrix(pV, num_coef);
  inv_pV=XtX;

  for(i=0;i<num_coef;i++)
    {
      pm[i]=0.0;
      
      for(j=0;j<num_coef;j++)
	pm[i] += pV[i][j]*Xt_response[j];
    }
  
  pa=a+n/2.0;
  pb=b;

  for(i=0;i<num_coef;i++)
    for(j=0;j<num_coef;j++)
      pb += 0.5*(m[i]*inv_V[i][j]*m[j] - pm[i]*inv_pV[i][j]*pm[j]);

  for(k=0;k<n;k++)
    pb += 0.5*response[k]*response[k];

  double *residuals=NULL;
  if(find_residuals)
    {
      residuals=new double[n];
      for(k=0;k<n;k++)
	{
	  residuals[k]=response[k];
	  for(i=0;i<num_coef;i++)
	    residuals[k] -= m[i]*predictor[i][k];
	}
    }

  bayesian_regression *result=
    new bayesian_regression(m,V,a,b,pm,pV,pa,pb,num_coef,n,residuals);
  
  doubledelete(inv_V,num_coef);
  doubledelete(inv_pV,num_coef);
  doubledelete(pV,num_coef);
  delete [] Xt_response;
  delete [] pm;
  
  if(probability_of_autoregressivity)
    {
      double prior_auto=probability_of_autoregressivity;
      double **autopred=new double*[num_coef+1];
      double *autom=new double[num_coef+1];
      double **autoV=new double*[num_coef+1];

      autom[0]=1.0;
      for(i=0;i<num_coef;i++)
	autom[i+1]=expected_coef[i];
      
      for(i=0;i<num_coef+1;i++)
	{
	  autoV[i]=new double[num_coef+1];
	  for(j=0;j<num_coef+1;j++)
	    autoV[i][j]=0.0;
	}

      autoV[0][0]=1.0;
      for(i=0;i<num_coef;i++)
	for(j=0;j<num_coef;j++)
	  autoV[i+1][j+1]=V[i][j];

      autopred[0]=new double[n];
      autopred[0][0]=response[0];
      for(k=1;k<n;k++)
	autopred[0][k]=response[k-1];
      
      for(i=0;i<num_coef;i++)
	autopred[i+1]=predictor[i];

      bayesian_regression *autoresult=
	get_bayesian_regression(autopred, num_coef+1, response, n,
				autom,autoV,a,b);

      double log_rescale=autoresult->probability_density_of_data(true,0);
      double likelihood_nonauto=result->probability_density_of_data(false,
								    log_rescale);
      double likelihood_auto=autoresult->probability_density_of_data(false,
								     log_rescale);
      
      double scale=likelihood_nonauto*(1.0-prior_auto) + 
	likelihood_auto*prior_auto;
      
      result->prior_nonauto=1.0-prior_auto;
      result->prior_auto=prior_auto;
      result->posteriori_nonauto=likelihood_nonauto*(1.0-prior_auto)/scale;
      result->posteriori_auto=likelihood_auto*prior_auto/scale;

      delete autoresult;
      delete [] autopred[0];
      delete [] autopred;
      delete [] autom;
      doubledelete(autoV, num_coef+1);
    }
  
  result->prior_no_predictors=result->posteriori_no_predictors=
    result->prior_only_constant=result->posteriori_only_constant=0.0;
  result->prior_full_model=result->posteriori_full_model=1.0;

  if(num_coef>=1)
    {
      double *p_prior=NULL, *p_posterior=NULL, 
	prior_fullmodel=1.0, posterior_fullmodel=1.0,
	likelihood_full_model, likelihood_no_predictors=0.0,
	likelihood_only_constant=0.0, posterior_prob_only_constant=0.0,
	posterior_prob_no_predictors=0.0, *likelihood=NULL;
      double log_rescale=result->probability_density_of_data(true,0);
      likelihood_full_model=result->probability_density_of_data(false,
								log_rescale);
      
      if(probability_of_submodels)
	for(i=0;i<num_coef;i++)
	  prior_fullmodel-=probability_of_submodels[i];
      prior_fullmodel-=probability_no_predictors;
      prior_fullmodel-=probability_only_constant;
      
      if(probability_of_submodels)
	{
	  p_prior=new double[num_coef];
	  p_posterior=new double[num_coef];
	  
	  likelihood=new double[num_coef];
	  
	  for(i=0;i<num_coef;i++)
	    p_prior[i]=probability_of_submodels[i];
	  
	  for(i=0;i<num_coef;i++)
	    {
	      int index=0;
	      double **subpredictors=new double*[num_coef-1];
	      double *sub_m=new double[num_coef-1];
	      double **sub_V=new double*[num_coef-1];
	      
	      for(j=0;j<num_coef;j++)
		if(j!=i)
		  {
		    subpredictors[index]=new double[n];
		    for(k=0;k<n;k++)
		      subpredictors[index][k]=predictor[j][k];
		    sub_m[index]=expected_coef[j];
		    sub_V[index]=new double[num_coef-1];
		    int index2=0;
		    for(l=0;l<num_coef;l++)
		      if(l!=i)
			{
			  sub_V[index][index2]=V[j][l];
			  index2++;
			}
		    
		    index++;
		  }
	      
	      bayesian_regression *subresult=
		get_bayesian_regression(subpredictors, num_coef-1,
					response, n, sub_m, sub_V, a, b);
	      doubledelete(subpredictors, num_coef-1);
	      doubledelete(sub_V, num_coef-1);
	      delete [] sub_m;
	      
	      likelihood[i]=subresult->probability_density_of_data(false,
								   log_rescale);
	      delete subresult;
	    }
	}

      if(probability_no_predictors>0.0)
	{
	  bayesian_regression *nopred=
	    get_bayesian_regression(NULL,0,response, n, NULL, NULL, a, b);
	  likelihood_no_predictors=nopred->probability_density_of_data(false,
								       log_rescale);
	  delete nopred;
	}

      
      if(probability_only_constant>0.0)
	{
	  double om[1]={expected_coef[0]};
	  double **oV=new double*[1];
	  oV[0]=new double[1];
	  oV[0][0]=V[0][0];

	  bayesian_regression *onlyconstant=
	    get_bayesian_regression(predictor,1,response, n, om, oV, a, b);

	  likelihood_only_constant=onlyconstant->probability_density_of_data(false,
									     log_rescale);

	  doubledelete(oV,1);
	  delete onlyconstant;
	}

      // set scaling;
      double scaling=prior_fullmodel*likelihood_full_model;
      if(probability_of_submodels)
	for(j=0;j<num_coef;j++)
	  scaling += p_prior[j]*likelihood[j];
      if(probability_only_constant>0.0)
	scaling += probability_only_constant * likelihood_only_constant;
      if(probability_no_predictors>0.0)
	scaling += probability_no_predictors * likelihood_no_predictors;
      
      if(probability_of_submodels)
	for(i=0;i<num_coef;i++)
	  p_posterior[i]=p_prior[i]*likelihood[i]/scaling;
      if(probability_only_constant>0.0)
	posterior_prob_only_constant=probability_only_constant * 
	  likelihood_only_constant/scaling;
      if(probability_no_predictors>0.0)
	posterior_prob_no_predictors=probability_no_predictors * 
	  likelihood_no_predictors/scaling;

      posterior_fullmodel=prior_fullmodel*likelihood_full_model/scaling;
      
      result->prior_full_model=prior_fullmodel;
      result->posteriori_full_model=posterior_fullmodel;

      if(probability_only_constant>0.0)
	{
	  result->prior_only_constant=probability_only_constant;
	  result->posteriori_only_constant=posterior_prob_only_constant;
	}

      if(probability_no_predictors>0.0)
	{
	  result->prior_no_predictors=probability_no_predictors;
	  result->posteriori_no_predictors=posterior_prob_no_predictors;
	}

      if(probability_of_submodels)
	{
	  result->prior_coefficient_removal_probability=new double[num_coef];
	  result->posteriori_coefficient_removal_probability=new double[num_coef];
	  for(i=0;i<num_coef;i++)
	    {
	      result->prior_coefficient_removal_probability[i]=p_prior[i];
	      result->posteriori_coefficient_removal_probability[i]=p_posterior[i];
	    }
	}

      if(p_prior)
	delete [] p_prior;
      if(p_posterior)
	delete [] p_posterior;
      if(likelihood)
	delete [] likelihood;
    }
  
  return result;
}



double sample_from_student_t(double mean, double v, double c)
{
#ifdef GSL
  
  static int firstvisit=1;
  static gsl_rng *ptr=gsl_rng_alloc(gsl_rng_rand48);
  
  if(firstvisit)
    {
      time_t t;
      gsl_rng_set(ptr, (int) time(&t));
      firstvisit=0;
    }
  
  double r=gsl_ran_tdist(ptr,c); // sampled from t(0,c,c)
  
  r*=sqrt(v/c);
  r+=mean;
  
  return r;
  
#else // no GSL
  
  return MISSING_VALUE;
  
#endif //GSL
}


double inv_cdf_student_t(double mean, double v, double c, double probability)
{
#ifdef GSL
  
  double x=gsl_cdf_tdist_Pinv(probability, (int) floor(c+0.5));
  
  x*=sqrt(v/c);
  x+=mean;
  
  return x;  
#endif // GSL
}

double cdf_student_t(double mean, double v, double c, double value)
{
#ifdef GSL  
  
  double x=(value-mean)/sqrt(v/c);
  
  return gsl_cdf_tdist_P(x, (int) floor(c+0.5));
  
#endif // GSL
}

double pdf_student_t(double mean, double v, double c, double value)
{
  return exp(lgamma(0.5*(c+1.0))-lgamma(0.5*c)-0.5*log(v*M_PI)-0.5*(c+1.0)*
	     log(1.0+(value-mean)*(value-mean)/v));
}


double find_student_t_c, find_student_t_mean, find_student_t_wanted_lower,
  find_student_t_p;
double find_student_diff(double *vv)
{
  double v=*vv;

  double lower=inv_cdf_student_t(find_student_t_mean, v*v, 
				 find_student_t_c, find_student_t_p);

  return (lower-find_student_t_wanted_lower)*
    (lower-find_student_t_wanted_lower);
}


void find_student_t(double wanted_lower, double wanted_upper, 
		    double wanted_credibility_in_percent, double c, 
		    double *mean, double *v)
{
  int maxiter=100;
  double start=1.0;

  *mean=(wanted_lower+wanted_upper)/2.0;
  
  find_student_t_mean=*mean;
  find_student_t_c=c;
  find_student_t_wanted_lower=wanted_lower;
  find_student_t_p=(100.0-wanted_credibility_in_percent)/200.0;
  
  double *v2=gsl_optimization_cover(find_student_diff, 1, &start, 
				    0.0001, maxiter);
  //newtonraphson

  *v=v2[0]*v2[0];
}





static double find_invgamma_wanted_min, find_invgamma_wanted_max;
static double find_invgamma_wanted_credibility;
/*
double find_invgamma_sum(double *ab)
{
  double gsl_a=exp(ab[0]), gsl_b=exp(ab[1]);
  
  //double start=gsl_cdf_gamma_Pinv((1.0-find_invgamma_wanted_credibility)/2.0,
  //			  gsl_a, gsl_b);
  //double end=gsl_cdf_gamma_Pinv(1.0-(1.0-find_invgamma_wanted_credibility)/2.0,
  //			gsl_a, gsl_b);
  
  double ptail=(1.0-find_invgamma_wanted_credibility)/2.0;
  double this_p1=gsl_cdf_gamma_P(find_invgamma_wanted_min,gsl_a, gsl_b);
  double this_p2=1.0-gsl_cdf_gamma_P(find_invgamma_wanted_max,gsl_a, gsl_b);

  
  //double ret=(start-find_invgamma_wanted_min)*(start-find_invgamma_wanted_min)+
  //(end-find_invgamma_wanted_max)*(end-find_invgamma_wanted_max);
  
  
double ret=sqrt((ptail-this_p1)*(ptail-this_p1)+(ptail-this_p2)*(ptail-this_p2));
  
  //cout << gsl_a << " " << gsl_b << " " << ret << std::endl;

  return ret;
}
*/

double find_invgamma_sum(double *ab)
{
  double gsl_a=exp(ab[0]), gsl_b=exp(ab[1]);
  double q1=find_invgamma_wanted_min, q2=find_invgamma_wanted_max;
  
  double this_q1=gsl_cdf_gamma_Pinv(0.025,gsl_a, gsl_b);
  double this_q2=gsl_cdf_gamma_Pinv(0.975,gsl_a, gsl_b);
  
  double ret=sqrt(q2*q2/q1/q1*(this_q1-q1)*(this_q1-q1)+
		  (this_q2-q2)*(this_q2-q2));
  
  return ret;
}

void find_invgamma_distribution(double wanted_lower, double wanted_upper, 
				double wanted_credibility_in_percent, 
				double *a, double *b,
				double *actual_credibility_in_percent)
{ 
  find_invgamma_wanted_min=1.0/wanted_upper;
  find_invgamma_wanted_max=1.0/wanted_lower;
  find_invgamma_wanted_credibility=wanted_credibility_in_percent/100.0;
  
  double mean=exp(0.25*(log(find_invgamma_wanted_max)+
			log(find_invgamma_wanted_min)));
  
  double a0=2.0;
  double b0=mean*mean;
  
  double m=(wanted_upper+wanted_lower)/2.0;
  double s=(wanted_upper-wanted_lower)/2.0/1.96;
  double v=s*s;
  
  if(m*m/v>5.0)
  {
    a0=m*m/v;
    b0=mean*mean/(a0+1.0);
  }
  
  //cout << m << " " << v << " " << a0 << " " << b0 << std::endl;
  
  double ab[2]={log(a0), log(b0)};
  int maxiter=100;
  
  double *newab=simplex_optimization(find_invgamma_sum, 2, ab, 0.0000001, 
				     maxiter); 
   
  //double *newab=gsl_optimization_cover(find_invgamma_sum, 2, ab, 0.0000001, 
  //maxiter,true,
  // GSL_COVER_CONJUGATE_FR); 
   
  // double gsl_a=0.0000001+newab[0]*newab[0], 
  // gsl_b=0.0000001+newab[1]*newab[1];
  // double ptail=(1.0-find_invgamma_wanted_credibility)/2.0;
  // double this_p1=gsl_cdf_gamma_P(find_invgamma_wanted_min,gsl_a, gsl_b);
  // double this_p2=1.0-gsl_cdf_gamma_P(find_invgamma_wanted_max,gsl_a, gsl_b);
  // cout << this_p1 << " " << this_p2 << " " << ptail << " " << 
  // maxiter << std::endl;

  *a=exp(newab[0]);
  *b=exp(-newab[1]);
  
  //cout << "a:" << a0 << " vs " << *a << std::endl;
  //cout << "b:" << b0 << " vs " << *b << std::endl;
  
  if(actual_credibility_in_percent)
    {
      *actual_credibility_in_percent=100.0*
	(gsl_cdf_gamma_P(find_invgamma_wanted_max,*a,1.0/(*b))-
	 gsl_cdf_gamma_P(find_invgamma_wanted_min,*a,1.0/(*b)));
      //cout << find_invgamma_sum(newab) << " " << 
      //	*actual_credibility_in_percent << " " <<
      //100.0*gsl_cdf_gamma_P(find_invgamma_wanted_min,*a,1.0/(*b)) << " " <<
      //100.0*gsl_cdf_gamma_P(find_invgamma_wanted_max,*a,1.0/(*b)) << std::endl;
    }
}



static double find_gamma_wanted_min, find_gamma_wanted_max;
static double find_gamma_wanted_credibility;

double find_gamma_sum(double *ab)
{
  double gsl_a=exp(ab[0]), gsl_b=exp(ab[1]);
  double q1=find_gamma_wanted_min, q2=find_gamma_wanted_max;
  
  double this_q1=gsl_cdf_gamma_Pinv(0.025,gsl_a, gsl_b);
  double this_q2=gsl_cdf_gamma_Pinv(0.975,gsl_a, gsl_b);
  
  double ret=sqrt((this_q1-q1)*(this_q1-q1)+
		  (this_q2-q2)*(this_q2-q2));
  
  return ret;
}

void find_gamma_distribution(double wanted_lower, double wanted_upper, 
			     double wanted_credibility_in_percent, 
			     double *a, double *b,
			     double *actual_credibility_in_percent)
{ 
  find_gamma_wanted_min=wanted_lower;
  find_gamma_wanted_max=wanted_upper;
  find_gamma_wanted_credibility=wanted_credibility_in_percent/100.0;
  
  double mean=exp(0.25*(log(find_invgamma_wanted_max)+
			log(find_invgamma_wanted_min)));
  
  double a0=2.0;
  double b0=a0/mean;
  
  double m=(wanted_upper+wanted_lower)/2.0;
  double s=(wanted_upper-wanted_lower)/2.0/1.96;
  double v=s*s;
  
  if(m*m/v>5.0)
  {
    a0=m*m/v;
    b0=a0/m;
  }
  
  //cout << m << " " << v << " " << a0 << " " << b0 << std::endl;
  
  double ab[2]={log(a0), log(b0)};
  int maxiter=100;
  
  double *newab=simplex_optimization(find_gamma_sum, 2, ab, 0.0000001, 
				     maxiter); 
   
  //double *newab=gsl_optimization_cover(find_invgamma_sum, 2, ab, 0.0000001, 
  //maxiter,true,
  // GSL_COVER_CONJUGATE_FR); 
   
  // double gsl_a=0.0000001+newab[0]*newab[0], 
  // gsl_b=0.0000001+newab[1]*newab[1];
  // double ptail=(1.0-find_invgamma_wanted_credibility)/2.0;
  // double this_p1=gsl_cdf_gamma_P(find_invgamma_wanted_min,gsl_a, gsl_b);
  // double this_p2=1.0-gsl_cdf_gamma_P(find_invgamma_wanted_max,gsl_a, gsl_b);
  // cout << this_p1 << " " << this_p2 << " " << ptail << " " << 
  // maxiter << std::endl;

  *a=exp(newab[0]);
  *b=exp(newab[1]);
  
  //cout << "a:" << a0 << " vs " << *a << std::endl;
  //cout << "b:" << b0 << " vs " << *b << std::endl;
  
  if(actual_credibility_in_percent)
    {
      *actual_credibility_in_percent=100.0*
	(gsl_cdf_gamma_P(find_invgamma_wanted_max,*a,1.0/(*b))-
	 gsl_cdf_gamma_P(find_invgamma_wanted_min,*a,1.0/(*b)));
      //cout << find_invgamma_sum(newab) << " " << 
      //	*actual_credibility_in_percent << " " <<
      //100.0*gsl_cdf_gamma_P(find_invgamma_wanted_min,*a,1.0/(*b)) << " " <<
      //100.0*gsl_cdf_gamma_P(find_invgamma_wanted_max,*a,1.0/(*b)) << std::endl;
    }
}



double invgamma_pdf(double x, double a, double b)
{
  return exp(a*log(b)-lgamma(a)-(a+1)*log(x)-b/x);
}







static double find_beta_wanted_min, find_beta_wanted_max;
static double find_beta_wanted_credibility;
double find_beta_sum(double *ab)
{
  double gsl_a=0.0000001+ab[0]*ab[0], gsl_b=0.0000001+ab[1]*ab[1];
  
  double ptail=(1.0-find_beta_wanted_credibility)/2.0;
  double this_p1=gsl_cdf_beta_P(find_beta_wanted_min, gsl_a, gsl_b);
  double this_p2=1.0-gsl_cdf_beta_P(find_beta_wanted_max,gsl_a, gsl_b);

  double ret=(ptail-this_p1)*(ptail-this_p1)+(ptail-this_p2)*(ptail-this_p2);
  
  return ret;
}

void find_beta_distribution(double wanted_lower, double wanted_upper, 
				double wanted_credibility_in_percent, 
				double *a, double *b)
{ 
  find_beta_wanted_min=wanted_lower;
  find_beta_wanted_max=wanted_upper;
  find_beta_wanted_credibility=wanted_credibility_in_percent/100.0;

  double m=(wanted_lower+wanted_upper)/2;
  double s=(wanted_upper-wanted_lower)/2/1.96;
  double v=s*s;

  double a0=(m*m*(1.0-m)-m*v)/v;
  double b0=a0*(1.0/m-1.0);

  double ab[2]={sqrt(a0), sqrt(b0)};
  int maxiter=10000;
  
  double *newab=simplex_optimization(find_beta_sum, 2, ab, 0.0000001, 
				     maxiter);

  *a=0.0000001+newab[0]*newab[0];
  *b=0.0000001+newab[1]*newab[1];
}




// Methods for handling regression done based on
// A predefined set of function operations
// on the base predictors;


// Makes a description of a predictor or response and sends it along
// in 'return_string';
void make_func_description(int index, char const* const* alias, REGRESS_FUNC_TYPE functype,
			   double scale, char *return_string, const char *title)
{
    char titlestr[100];
    char* str=return_string;

  if(title)
    sprintf(titlestr, "%s: ", title);
  else
    strcpy(titlestr,"");
  
  if((almost_equal(scale,1.0) && !regress_func_substract[(int) functype]) ||
     (almost_equal(scale,0.0) && regress_func_substract[(int) functype]))
    {
      if(functype==REGRESS_POWER)
	sprintf(str, "%s%s ", titlestr,
		alias[index]);
      else if(regress_func_before[(int) functype])
	sprintf(str, "%s%s( %s )", titlestr, 
		regress_func_names_short[(int) functype], alias[index]);
      else
	sprintf(str, "%s (%s)%s", titlestr, 
		alias[index], regress_func_names_short[(int) functype]);
    }
  else
    {
      if(functype==REGRESS_POWER)
	sprintf(str, "%s%s^%-5.3f ", titlestr,
		alias[index], scale);
      else if(regress_func_before[(int) functype])
	{
	  if(!regress_func_substract[(int) functype])
	    sprintf(str, "%s%s( %5.3f*%s )", titlestr, 
		    regress_func_names_short[(int) functype],
		    scale, alias[index]);
	  else
	    sprintf(str, "%s%s( %s-%5.3f )", titlestr, 
		    regress_func_names_short[(int) functype],
		    alias[index],scale);
	}
      else
	{
	  if(!regress_func_substract[(int) functype])
	    sprintf(str, "%s (%5.3f*%s)%s", titlestr, 
		    scale, alias[index],
		    regress_func_names_short[(int) functype]);
	  else
	    sprintf(str, "%s (%s-%5.3f)%s", titlestr, 
		    alias[index], scale,
		    regress_func_names_short[(int) functype]);
	}
    }
}



double regress_funcvalue(double arg, REGRESS_FUNC_TYPE functype,
			 double scale)
{
  double newval = 0.0;

  switch(functype)
    {
    case REGRESS_LINEAR:
      newval=arg-scale;
      break;
    case REGRESS_SQUARE: 
      newval=(arg-scale)*(arg-scale);
      break;
    case REGRESS_CUBE:
      newval = (arg-scale)*(arg-scale)*(arg-scale);
      break;
    case REGRESS_SQUARE_ROOT:
      newval = sqrt(arg-scale);
      break;
    case REGRESS_LOG:
      newval = log(arg-scale);
      break;
    case REGRESS_EXP:
      newval = exp(newval-scale);
      break;
    case REGRESS_SIN:
      newval = sin(arg*scale);
      break;
    case REGRESS_COS:
      newval=cos(arg*scale);
      break;
    case REGRESS_POWER:
      newval = pow(arg, scale);
      break;
    case REGRESS_STEP:
      newval = (arg>=scale) ? 1.0 : 0.0;
      break;
    default:
      break;
    }

  return newval;
}

double inverse_regress_funcvalue(double arg, REGRESS_FUNC_TYPE functype,
				 double scale)
{
  double newval=arg;

  switch(functype)
    {
    case REGRESS_LINEAR:
      newval=arg+scale;
      break;
    case REGRESS_SQUARE: 
      newval = sqrt(ABSVAL(arg))+scale;
      break;
    case REGRESS_CUBE:
      newval = pow(ABSVAL(arg), 1.0/3.0)+scale;
      break;
    case REGRESS_SQUARE_ROOT:
      newval = arg*arg+scale;
      break;
    case REGRESS_LOG:
      newval = exp(newval)+scale;
      break;
    case REGRESS_EXP:
      newval = log(newval)+scale;
      break;
    case REGRESS_SIN:
      newval = asin(arg)/scale;
      break;
    case REGRESS_COS:
      newval = acos(arg)/scale;
      break;
    case REGRESS_POWER:
      newval = pow(arg, 1.0/scale);
      break;
    case REGRESS_STEP:
      newval = arg>0.5 ? scale : scale-0.000001;
      break;
    default:
      break;
    }

  return newval;
}



regression_rule::regression_rule(regression_result *result_, int numseries_,
				 int numpredictors_, int *predictor_index_,
				 int *interaction_index_, int response_index_,
				 REGRESS_FUNC_TYPE *predictor_func_, 
				 REGRESS_FUNC_TYPE *interaction_func_,
				 REGRESS_FUNC_TYPE response_func_,
				 double *predictor_scales_, 
				 double *interaction_scales_,
				 double response_scale_)
{
  result         = new regression_result(*result_);
  numseries      = numseries_;
  numpredictors  = numpredictors_;
  response_func  = response_func_;
  response_scale = response_scale_;
  response_index = response_index_;
  
  predictor_index    = new int[numpredictors];
  predictor_func     = new REGRESS_FUNC_TYPE[numpredictors];
  predictor_scales   = new double[numpredictors];
  interaction_index  = new int[numpredictors];
  interaction_func   = new REGRESS_FUNC_TYPE[numpredictors];
  interaction_scales = new double[numpredictors];

  for(int i=0;i<numpredictors;i++)
    {
      predictor_index[i]   = predictor_index_[i];
      predictor_scales[i]  = predictor_scales_[i];
      predictor_func[i]    = predictor_func_[i];
      interaction_index[i] = interaction_index_ ? interaction_index_[i] : -1;
      interaction_scales[i]= interaction_scales_ ? interaction_scales_[i] : 0;
      interaction_func[i]  = interaction_func_ ? interaction_func_[i] : 
	REGRESS_LINEAR;
    }
}

regression_rule::regression_rule(regression_rule &orig)
{
  init();
  copy(orig);
}

regression_rule::regression_rule()
{
  init();
}

regression_rule::~regression_rule()
{
  cleanup();
}

void regression_rule::init(void)
{
  predictor_index    = NULL;
  predictor_scales   = NULL;
  predictor_func     = NULL;
  interaction_index  = NULL;
  interaction_scales = NULL;
  interaction_func   = NULL;
  result = NULL;
  numpredictors = numseries = response_index = 0;
}

void regression_rule::cleanup(void)
{
  if(predictor_index)
    delete [] predictor_index;
  if(predictor_scales)
    delete [] predictor_scales;
  if(predictor_func)
    delete [] predictor_func;
  if(interaction_index)
    delete [] interaction_index;
  if(interaction_scales)
    delete [] interaction_scales;
  if(interaction_func)
    delete [] interaction_func;
  if(result)
    delete result;
  init();
}

void regression_rule::copy(regression_rule &orig)
{
  result         = new regression_result(*orig.result);
  numseries      = orig.numseries;
  numpredictors  = orig.numpredictors;
  response_func  = orig.response_func;
  response_scale = orig.response_scale;
  response_index = orig.response_index;

  predictor_index  = new int[numpredictors];
  predictor_func   = new REGRESS_FUNC_TYPE[numpredictors];
  predictor_scales = new double[numpredictors];
  
  interaction_index  = new int[numpredictors];
  interaction_func   = new REGRESS_FUNC_TYPE[numpredictors];
  interaction_scales = new double[numpredictors];
  
  for(int i=0;i<numpredictors;i++)
    {
      predictor_index[i]  = orig.predictor_index[i];
      predictor_scales[i] = orig.predictor_scales[i];
      predictor_func[i]   = orig.predictor_func[i];

      interaction_index[i]  = orig.interaction_index ?
	orig.interaction_index[i] : -1;
      interaction_scales[i] = orig.interaction_scales ?
	orig.interaction_scales[i] : 0;
      interaction_func[i]   = orig.interaction_func ?
	orig.interaction_func[i] : REGRESS_LINEAR;
    }
}

// returns a response value according to the input (of size 'numseries');
double regression_rule::find_response_value(double *predictor_set)
{
  double ret = find_response(predictor_set);

  ret = inverse_regress_funcvalue(ret, response_func, response_scale);

  return ret;
}

double regression_rule::find_response(double *predictor_set)
{
  int i;
  double ret=result->get_coefficient(0);
  
  for(i=0;i<numpredictors;i++)
    {
      double arg=predictor_set[predictor_index[i]];
      double transformed=regress_funcvalue(arg, predictor_func[i],
					   predictor_scales[i]);
      if(interaction_index && interaction_index[i]>=0)
	{
	  double interaction=predictor_set[interaction_index[i]];
	  double interactiontransf=regress_funcvalue(interaction,
						     interaction_func[i],
						     interaction_scales[i]);

	  ret += result->get_coefficient(i+1)*transformed*interactiontransf;
	}
      else
	ret += result->get_coefficient(i+1)*transformed; 
    }

  return ret;
}

regression_result *regression_rule::get_regression(void)
{
  return result;
}

int regression_rule::get_numseries(void)
{
  return numseries;
}

int regression_rule::get_numpredictors(void)
{
  return numpredictors;
}

int *regression_rule::get_predictor_index(void)
{
  return predictor_index;
}

int *regression_rule::get_interaction_index(void)
{
  return interaction_index;
}

int regression_rule::get_response_index(void)
{
  return response_index;
}

REGRESS_FUNC_TYPE *regression_rule::get_predictor_func(void) 
{
  return predictor_func;
}

REGRESS_FUNC_TYPE *regression_rule::get_interaction_func(void) 
{
  return interaction_func;
}

REGRESS_FUNC_TYPE regression_rule::get_response_func(void)
{
  return response_func;
}

double *regression_rule::get_predictor_scales(void)
{
  return predictor_scales;
}

double *regression_rule::get_interaction_scales(void)
{
  return interaction_scales;
}

double regression_rule::get_response_scale(void)
{
  return response_scale;
}

bool regression_rule::is_predictor(int index)
{
  if(index<0 || index>numseries)
    return false;

  for(int i=0;i<numpredictors;i++)
    {
      if(predictor_index[i]==index)
	return true;
      if(interaction_index && interaction_index[i]==index)
	return true;
    }

  return false;
}

// Predicts the response based on input values (numseries of them).
// Inputs not in use can be set to MISSING_VALUE
// If a used predictor has MISSING_VALUE, the result
// is MISSING_VALUE.
double regression_rule::predict(double *input_values)
{
  double prediction=result->get_coefficient(0);

  for(int j=0;j<numpredictors;j++)
    {
      double arg=input_values[predictor_index[j]];
      double arg2=1;
      
      if(interaction_index[j]>=0)
	arg2=input_values[interaction_index[j]];

      if(arg!=MISSING_VALUE && arg2!=MISSING_VALUE &&
	 prediction!=MISSING_VALUE)
	{
	  arg=regress_funcvalue(arg,predictor_func[j],
				predictor_scales[j]);
	  if(interaction_index[j]>=0)
	    arg *= regress_funcvalue(arg,interaction_func[j],
				     interaction_scales[j]);
	  
	  prediction+=result->get_coefficient(j+1)*arg;
	}
      else
	prediction=MISSING_VALUE;
    }
  
  if(prediction!=MISSING_VALUE)
    prediction=inverse_regress_funcvalue(prediction,response_func,
					 response_scale);
  return prediction;
}

void regression_rule::print(std::ostream& /* out */)
{
  
}




/*  ****************************************
// 
//  BAYES_OUTLIER_DETECTION
//
// Bayesian outlier detection. Based on 
// comparing the model:
// H0: x_i~N(0,sigma�) iid    with
// H1: x_i~(1-p)*N(0,sigma�)+p*N(0,sigma0�)
// with sigma�~ IG(alpha,beta), 
//      sigma0�~IG(alpha0,beta0)
//      p~beta(a,b)
// Returns the Bayes factor f(D|M2)/f(D|M1)
// Calculates only an approximation for 
// large residual sets, based on identifying
// the most extreme residuals.
// Additional input: maxnum set the of 
// maximum number of extreme residuals 
// examined.
//
// -Trond Reitan, 21/4-2008
//
// ***************************************** */

double bayes_outlier_detection(double *x, int len, 
			       double alpha, double beta,
			       double alpha0, double beta0,
			       double a, double b,
			       int maxnum)
{
  int i;
  double x2=0.0, n=double(len);
  for(i=0;i<len;i++)
    x2+=x[i]*x[i];
  double log_p1=-0.5*n*log(2.0*M_PI)+alpha*log(beta)+lgamma(alpha+n/2.0)-
    lgamma(alpha)-(alpha+n/2.0)*log(beta+0.5*x2);
  double *x_copy=new double[len];
  
  if(maxnum>len)
    maxnum=len;
  
  for(i=0;i<len;i++)
    x_copy[i]=x[i];

  qsort(x_copy,len,sizeof(double), compare_absdouble_descending);
  
  double p2=0.0;
  int xx,max=1<<maxnum;
  int *y=new int[len];

  for(xx=0;xx<max;xx++)
    {
      for(i=0;i<len;i++)
	y[i]=0;
      
      int z=1;
      for(i=0;i<maxnum;i++)
	{
	  if(xx & z)
	    y[i]=1;
	  z=z<<1;
	}
      
      int numy=0;
      for(i=0;i<len;i++)
	numy=numy+y[i];
      double x2_0=0.0, x2_1=0.0;
      for(i=0;i<len;i++)
	if(y[i])
	  x2_1 += x_copy[i]*x_copy[i];
	else
	  x2_0 += x_copy[i]*x_copy[i];

      double ny=double(numy);
      double logp=-0.5*n*log(2.0*M_PI)+alpha*log(beta)-lgamma(alpha);
      logp += alpha0*log(beta0)-lgamma(alpha0);
      logp += lgamma(a+b)-lgamma(a)-lgamma(b);
      logp += lgamma(alpha+(n-ny)/2.0) - (alpha+(n-ny)/2.0)*log(beta+0.5*x2_0);
      logp += lgamma(alpha0+ny/2.0) - (alpha0+ny/2.0)*log(beta0+0.5*x2_1);
      logp += lgamma(a+ny)+lgamma(b+n-ny)-lgamma(a+b+n);
      
      p2+=exp(logp-log_p1);
    }
  
  // Add diagonal terms
  for(xx=maxnum+1;xx<len;xx++)
    {
      for(i=0;i<=xx;i++)
	y[i]=1;
      for(i=xx+1;i<len;i++)
	y[i]=0;
      
      int numy=0;
      for(i=0;i<len;i++)
	numy=numy+y[i];
      double x2_0=0.0, x2_1=0.0;
      for(i=0;i<len;i++)
	if(y[i])
	  x2_1 += x_copy[i]*x_copy[i];
	else
	  x2_0 += x_copy[i]*x_copy[i];
      
      double ny=double(numy);
      double logp=-0.5*n*log(2.0*M_PI)+alpha*log(beta)-lgamma(alpha);
      logp += alpha0*log(beta0)-lgamma(alpha0);
      logp += lgamma(a+b)-lgamma(a)-lgamma(b);
      logp += lgamma(alpha+(n-ny)/2.0) - (alpha+(n-ny)/2.0)*log(beta+0.5*x2_0);
      logp += lgamma(alpha0+ny/2.0) - (alpha0+ny/2.0)*log(beta0+0.5*x2_1);
      logp += lgamma(a+ny)+lgamma(b+n-ny)-lgamma(a+b+n);
      
      p2+=exp(logp-log_p1);
    }

  delete [] x_copy;
  delete [] y;

  return p2;
}
