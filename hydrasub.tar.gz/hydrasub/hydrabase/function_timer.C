#include <hydrasub/hydrabase/function_timer.H>

Date function_timer::totalstart;
Date* function_timer::start = NULL;
timeval  function_timer::totaltimeval;
timeval* function_timer::timevals = NULL;
int function_timer::numtimers = 0;
int function_timer::started = 0;
int function_timer::totalstopped = 0;
int* function_timer::stopped = NULL;
double* function_timer::aggregated = NULL;
double function_timer::totaltime = 0.0;

void function_timer::start_total_timer(int number_of_timers)
{
    struct timezone tz;

    numtimers = number_of_timers;
    if (start)
    {
        delete [] start;
    }
    start = NULL;
    if (timevals)
    {
        delete [] timevals;
    }
    timevals = NULL;
    if (aggregated)
    {
        delete [] aggregated;
    }
    aggregated = NULL;
    if (stopped)
    {
        delete [] stopped;
    }
    stopped = NULL;

    if (numtimers < 1)
    {
        return;
    }

    start = new Date[numtimers];
    timevals = new timeval[numtimers];
    stopped = new int[numtimers];
    aggregated = new double[numtimers];

    totalstopped = 0;
    started = 1;

    for (int i = 0; i < numtimers; i++)
    {
        stopped[i] = 1;
        aggregated[i] = 0.0;
    }

    totaltime = 0.0;

    totalstart.now();
    gettimeofday(&totaltimeval, &tz);
}

void function_timer::stop_total_timer(void)
{
    totaltime += get_last_total_timer();
    totalstopped = 1;
}

void function_timer::restart_total_timer(void)
{
    struct timezone tz;

    totalstart.now();
    gettimeofday(&totaltimeval, &tz);
    totalstopped = 0;
}

double function_timer::get_last_total_timer(void)
{
    Date now2, now1 = totalstart;
    timeval tv2, tv1 = totaltimeval;
    struct timezone tz;
    double ret;

    now2.now();
    gettimeofday(&tv2, &tz);

    ret = double((now2 - now1) * 24 * 3600) + double(tv2.tv_sec - tv1.tv_sec) +
          double(tv2.tv_usec < tv1.tv_usec ? -1 : 0) +
          double(tv2.tv_usec < tv1.tv_usec ? 1000000 + tv2.tv_usec - tv1.tv_usec :
                 tv2.tv_usec - tv1.tv_usec) / 1000000.0;

    return ret;
}

double function_timer::get_total_timer(void)
{
    if (totalstopped)
    {
        return totaltime;
    }
    else
    {
        return totaltime + get_last_total_timer();
    }
}

void function_timer::start_timer(int number)
{
    struct timezone tz;

    if (!timevals)
    {
        return;
    }

    if (!started)
    {
        start_total_timer(number + 1);
    }

    stopped[number] = 0;
    start[number].now();
    gettimeofday(timevals + number, &tz);
}

double function_timer::get_last_timer(int number)
{
    if (!timevals)
    {
        return 0.0;
    }

    Date now2, now1 = start[number];
    timeval tv2, tv1 = timevals[number];
    struct timezone tz;
    double ret;

    now2.now();
    gettimeofday(&tv2, &tz);

    ret = double((now2 - now1) * 24 * 3600) + double(tv2.tv_sec - tv1.tv_sec) +
          double(tv2.tv_usec < tv1.tv_usec ? -1 : 0) +
          double(tv2.tv_usec < tv1.tv_usec ? 1000000 + tv2.tv_usec - tv1.tv_usec :
                 tv2.tv_usec - tv1.tv_usec) / 1000000.0;

    return ret;
}

void function_timer::stop_timer(int number)
{
    if (!timevals)
    {
        return;
    }

    aggregated[number] += get_last_timer(number);
    stopped[number] = 1;
}

double function_timer::get_timer(int number)
{
    if (stopped[number])
    {
        return aggregated[number];
    }
    else
    {
        return aggregated[number] + get_last_timer(number);
    }
}
