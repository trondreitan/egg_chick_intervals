/*
 * $Id: types.C 2576 2015-10-22 07:09:28Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/types.C $
 */

#include <hydrasub/hydrabase/types.H>
#include <cstdlib>

#if defined(_WIN32) || defined(_WIN64) 
double drand48(void)
{
	return (((double)(rand())) / ((double)RAND_MAX));
}

void srand48(long int seed)
{
	srand((unsigned int)seed);
}

#endif

extern const char* timeresstr[]=
{
  "Knekkpkt", 
  "1 min",
  "5 min", 
  "15 min",
  "20 min",
  "30 min",
  "1 time", 
  "3 timer", 
  "6 timer", 
  "12 timer", 
  "D�gn",
  "5 d�gn",
  "Uke",
  "10 d�gn",
  "M�ned",
  "Kvartal",
  "Halv�r",
  "�rs"
};


//extern char *timeresstr_eng[]=
extern const char* timeresstr_eng[]=
{
  "Unspec.", 
  "1 min",
  "5 min", 
  "15 min",    
  "20 min",
  "30 min",
  "1 hour", 
  "3 hours", 
  "6 timer", 
  "12 hours", 
  "Day",
  "5 days",
  "Week",
  "10 days",
  "Month",
  "Quartal",
  "Halfyear",
  "Year"
};

//extern char *timeresstr2[]=
extern const char* timeresstr2[]=
{
  "Knekkpunkt-verdier", 
  "1-minutts-verdier",
  "5-minutts-verdier", 
  "Kvarters-verdier", 
  "Tjue minutter-verdier",
  "Halvtimes-verdier",
  "Times-verdier", 
  "3-timers-verdier", 
  "6-timers-verdier", 
  "12-timers-verdier", 
  "D�gn-verdier",
  "5-d�gns-verdier",
  "Uke",
  "10-d�gns-verdier",
  "M�ned",
  "Kvartal",
  "Halv�r",
  "�rs"
};



//extern BASE_TIME timeresarray[]=
extern const BASE_TIME timeresarray[]=
{
  MIN0, MIN1, MIN5, MIN15, MIN20, MIN30, MIN60, MIN180, MIN360, MIN720,
  DAY1, DAY5, DAY7, DAY10, MONTH1, MONTH3, MONTH6, YEAR1
};

extern const int timeres_arraylen=18;
