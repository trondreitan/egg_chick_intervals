#include "bayes_multiseg_ratingcurve_priors.H"
#include <hydrasub/hydrabase/bayes_multiseg_ratingcurve.H>
#include <hydrasub/hydrabase/linalg.H>
#include <cmath>
#include <gsl/gsl_cdf.h>

void segmented_priors::initialize(void)
{
  min_num_seg=max_num_seg=0;
  dim=NULL;
  mu_hs=NULL;
  sd_hs=NULL;
  mu_hs_detailed_buffer=NULL;
  sd_hs_detailed_buffer=NULL;
  mu_h0=NULL;
  sd_h0=NULL;
  max_h0=NULL;
  lognormal_h0=NULL;
  mu_h0_detailed_buffer=NULL;
  sd_h0_detailed_buffer=NULL;
  max_h0_detailed_buffer=NULL;
  lognormal_h0_detailed_buffer=NULL;
  lin_m=NULL;
  lin_V=NULL;
  lin_m_detailed_buffer=NULL;
  lin_V_detailed_buffer=NULL;
  lin_a_sd=NULL;
  lin_b_sd=NULL;
  lin_corr=NULL;
  lin_a_sd_detailed_buffer=NULL;
  lin_b_sd_detailed_buffer=NULL;
  lin_corr_detailed_buffer=NULL;
  prob_model=NULL;
  sigma_a=sigma_b=0.0;
  overall_a_mean=overall_b_mean=overall_a_sd=
    overall_b_sd=overall_corr=MISSING_VALUE;
  mu_q=sd_q=mu_h01=mu_h02=sd_h01=sd_h02=MISSING_VALUE;
  detailed_hs=detailed_h0=detailed_lin=
    extremely_detailed_lin=false;
  max_h01=MISSING_VALUE;
  lognormal_h01=false;

  if(first_init)
    reset_standards();
  first_init=0;
  
  num_restr=num_lower_and_upper=0;
  restr_stage=restr_q_lower=restr_q_upper=NULL;
  restr_comment=NULL;
  
  num_extra=num_extra_lower_and_upper=0;
  extra_stage=extra_q_lower=extra_q_upper=NULL;
  extra_comment=NULL;
}

void segmented_priors::reset_standards(void)
{
  standard_mu_a=2.84;
  standard_sd_a=1.38;
  standard_mu_b=2.46;
  standard_sd_b=0.92;
  standard_cor=-0.42;
  
  standard_sigma_upper_cred=0.15;
  standard_sigma_lower_cred=0.02;
  standard_sigma_cred=0.95;
  find_invgamma_distribution(standard_sigma_lower_cred*
			     standard_sigma_lower_cred, 
			     standard_sigma_upper_cred*
			     standard_sigma_upper_cred,
			     standard_sigma_cred*100.0,
			     &standard_sigma_a, &standard_sigma_b);
  
  standard_mu_q=1.80;
  standard_sd_q=2.35;
  standard_h01_mu=0.0;
  standard_h01_sd=2500.0/1.96;
  standard_h02_mu=0.1925;
  standard_h02_sd=0.5448;
}



void segmented_priors::cleanup(void)
{
  if(max_num_seg>1)
    {
      doubledelete(mu_hs, max_num_seg-1);
      doubledelete(sd_hs, max_num_seg-1);
      doubledelete(mu_hs_detailed_buffer, max_num_seg-1);
      doubledelete(sd_hs_detailed_buffer, max_num_seg-1);
    }
  doubledelete(mu_h0, max_num_seg);
  doubledelete(sd_h0, max_num_seg);
  doubledelete(max_h0, max_num_seg);
  doubledelete(lognormal_h0, max_num_seg);
  doubledelete(mu_h0_detailed_buffer, max_num_seg);
  doubledelete(sd_h0_detailed_buffer, max_num_seg);
  doubledelete(max_h0_detailed_buffer, max_num_seg);
  doubledelete(lognormal_h0_detailed_buffer, max_num_seg);
  doubledelete(lin_m, max_num_seg);
  tripledelete(lin_V, max_num_seg, dim);
  doubledelete(lin_m_detailed_buffer, max_num_seg);
  tripledelete(lin_V_detailed_buffer, max_num_seg, dim);

  if(lin_a_sd)
    delete [] lin_a_sd;
  doubledelete(lin_b_sd, max_num_seg);
  if(lin_corr)
    delete [] lin_corr;
  
  if(lin_a_sd_detailed_buffer)
    delete [] lin_a_sd_detailed_buffer;
  doubledelete(lin_b_sd_detailed_buffer, max_num_seg);
  if(lin_corr_detailed_buffer)
    delete [] lin_corr_detailed_buffer;
  
  
  if(prob_model)
    delete [] prob_model;

  if(dim)
    delete [] dim;

  if(restr_stage)
    delete [] restr_stage;
  if(restr_q_lower)
    delete [] restr_q_lower;
  if(restr_q_upper)
    delete [] restr_q_upper;
  doubledelete(restr_comment, num_restr);
  
  if(extra_stage)
    delete [] extra_stage;
  if(extra_q_lower)
    delete [] extra_q_lower;
  if(extra_q_upper)
    delete [] extra_q_upper;
  doubledelete(extra_comment, num_extra);
  
  
  initialize();
}

void segmented_priors::set_default(int min_seg, int max_seg)
{
  cleanup();

  int i,j,k;

  min_num_seg=min_seg;
  max_num_seg=max_seg;

  dim=new int[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    dim[i]=i+2;
  prob_model=new double[max_num_seg];
  for(i=0;i<(min_num_seg-1);i++)
    prob_model[i]=0.0;
  for(i=(min_num_seg-1);i<max_num_seg;i++)
    prob_model[i]=1.0/double(max_num_seg-min_num_seg+1);

  overall_a_mean=standard_mu_a;
  overall_b_mean=standard_mu_b;
  overall_a_sd=standard_sd_a;
  overall_b_sd=standard_sd_b;
  overall_corr=standard_cor;
  detailed_lin=extremely_detailed_lin=false;

  lin_m=new double*[max_num_seg];
  lin_a_sd=new double[max_num_seg];
  lin_b_sd=new double*[max_num_seg];
  lin_corr=new double[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    {
      lin_m[i]=new double[i+2];
      // set mu_a for this model:
      lin_m[i][0]=standard_mu_a;
      // set the mu_b's for this model:

      lin_corr[i]=standard_cor;
      lin_a_sd[i]=standard_sd_a;
      lin_b_sd[i]=new double[i+1];
      for(j=0;j<(i+1);j++)
	lin_m[i][j+1]=standard_mu_b;
      for(j=0;j<(i+1);j++)
	lin_b_sd[i][j]=standard_sd_b;
    }

  lin_V=new double**[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    {
      lin_V[i]=new double*[dim[i]];
      for(j=0;j<dim[i];j++)
	lin_V[i][j]=new double[dim[i]];
      lin_V[i][0][0]=standard_sd_a*standard_sd_a;
      for(j=1;j<dim[i];j++)
	lin_V[i][0][j]=lin_V[i][j][0]=
	  standard_cor*standard_sd_a*standard_sd_b;
      for(j=1;j<dim[i];j++)
	for(k=1;k<dim[i];k++)
	  {
	    if(j==k)
	      lin_V[i][j][k]=standard_sd_b*standard_sd_b;
	    else
	      lin_V[i][j][k]=standard_cor*standard_cor*
		standard_sd_b*standard_sd_b;
	  }
    }
      
  detailed_hs=false;
  mu_q=standard_mu_q;
  sd_q=standard_sd_q;

  detailed_h0=false;
  mu_h01=standard_h01_mu;
  sd_h01=standard_h01_sd;
  mu_h02=standard_h02_mu;
  sd_h02=standard_h02_sd;
  lognormal_h01=false;
  max_h01=MISSING_VALUE;

  sigma_lower=standard_sigma_lower_cred;
  sigma_upper=standard_sigma_upper_cred;
  sigma_cred=standard_sigma_cred;
  sigma_a=standard_sigma_a;
  sigma_b=standard_sigma_b;
}

segmented_priors::segmented_priors()
{
  first_init=1;
  initialize();
  set_default(1, 3);
}

segmented_priors::
segmented_priors(int max_segments)
{
  first_init=1;
  initialize();
  set_default(1,max_segments);
}

segmented_priors::
segmented_priors(int min_segments, int max_segments)
{
  first_init=1;
  initialize();
  set_default(min_segments, max_segments);
}

segmented_priors::
segmented_priors(int min_segments, int max_segments,
		 double a_mu, double b_mu, 
		 double h01_mu, double h02_mu,
		 double a_sd, double b_sd, double cor,
		 double h01_sd, double h02_sd,
		 double lower_sigma, double upper_sigma,
		 double sigma_credibility,
		 double q_mu, double q_sd)
{
  first_init=1;
  initialize();
  set_default(min_segments, max_segments);
  set_linear_parameters_simple(a_mu, b_mu, a_sd, b_sd, cor);
  set_sigma_parameters(lower_sigma, upper_sigma, sigma_credibility);
  set_h0_simple(h01_mu, h01_sd, false, MISSING_VALUE, h02_mu, h02_sd);
  set_hs_simple(q_mu, q_sd);
}


// Detailed specification of priors:
// Note that the arrays will go from 0=segment 1 to p-1=segment max
// for any value of 'min_segments'
segmented_priors::
segmented_priors(int min_segments, int max_segments,
		 double *a_mu, double **b_mu, 
		 double *a_sd, double **b_sd, double cor,
		 double **h0_mu, double **hs_mu,
		 double **h0_sd, double **hs_sd,
		 double lower_sigma, double upper_sigma,
		 double sigma_credibility)
{
  first_init=0;
  initialize();
  set_default(min_segments, max_segments);
  set_linear_parameters_detailed(a_mu, b_mu, a_sd, b_sd, cor);
  set_sigma_parameters(lower_sigma, upper_sigma, sigma_credibility);
  set_h0_detailed(h0_mu, h0_sd, NULL, NULL);
  set_hs_detailed(hs_mu, hs_sd);
}

// Very detailed specification of priors:
// Note that the arrays will go from 0=segment 1 to p-1=segment max
// for any value of 'min_segments'
segmented_priors::segmented_priors(int min_segments, int max_segments,
				   bool detailed_hs_, bool detailed_h0_, 
				   bool detailed_lin_, 
				   bool extremely_detailed_lin_,
				   double overall_a_mean_, 
				   double overall_b_mean_, 
				   double overall_a_sd_, 
				   double overall_b_sd_, 
				   double overall_corr_,
				   double sigma_lower_, 
				   double sigma_upper_,
				   double sigma_cred_,
				   double mu_q_, double sd_q_,
				   double mu_h01_, double sd_h01_,
				   bool lognormal_h01_, double max_h01_,
				   double mu_h02_, double sd_h02_,
				   
				   double *model_prob,
				   double *a_mu, double **b_mu, 
				   double *a_sd, double **b_sd, double *cor,
				   
				   double ***V_,
				   
				   double **h0_mu, double **hs_mu,
				   double **h0_sd, double **hs_sd,
				   bool **h0_lognormal, double **h0_max)
{
  int i,j,k;

  first_init=1;
  initialize();

  min_num_seg=min_segments;
  max_num_seg=max_segments;
  
  detailed_h0=detailed_h0_;
  detailed_hs=detailed_hs_;
  detailed_lin=detailed_lin_;
  extremely_detailed_lin=extremely_detailed_lin_;

  overall_a_mean=overall_a_mean_;
  overall_b_mean=overall_b_mean_;
  overall_a_sd=overall_a_sd_;
  overall_b_sd=overall_b_sd_;
  overall_corr=overall_corr_;

  set_sigma_parameters(sigma_lower_,sigma_upper_,
		       sigma_cred_);
  
  mu_q=mu_q_;
  sd_q=sd_q_;
  mu_h01=mu_h01_;
  sd_h01=sd_h01_;
  mu_h02=mu_h02_;
  sd_h02=sd_h02_;
  lognormal_h01=lognormal_h01_;
  max_h01=max_h01_;

  dim=new int[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    dim[i]=i+2;

  prob_model=new double[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    prob_model[i]=model_prob[i];

  
  if(hs_mu)
    {
      mu_hs=new double*[max_num_seg];
      mu_hs_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  mu_hs[i]=new double[i+1];
	  mu_hs_detailed_buffer[i]=new double[i+1];
	  for(j=0;j<i;j++)
	    mu_hs[i][j]=mu_hs_detailed_buffer[i][j]=hs_mu[i][j];
	}
    }
  else
    mu_hs=NULL;

  if(hs_sd)
    {
      sd_hs=new double*[max_num_seg];
      sd_hs_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  sd_hs[i]=new double[i+1];
	  sd_hs_detailed_buffer[i]=new double[i+1];
	  for(j=0;j<i;j++)
	    sd_hs[i][j]=sd_hs_detailed_buffer[i][j]=hs_sd[i][j];
	}
    }
  else
    sd_hs=NULL;

  if(h0_mu)
    {
      mu_h0=new double*[max_num_seg];
      mu_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  mu_h0[i]=new double[i+1];
	  mu_h0_detailed_buffer[i]=new double[i+1];
	  for(j=0;j<=i;j++)
	    mu_h0[i][j]=mu_h0_detailed_buffer[i][j]=h0_mu[i][j];
	}
    }
  else
    mu_h0=NULL;

  if(h0_sd)
    {
      sd_h0=new double*[max_num_seg];
      sd_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  sd_h0[i]=new double[i+1];
	  sd_h0_detailed_buffer[i]=new double[i+1];
	  for(j=0;j<=i;j++)
	    sd_h0[i][j]=sd_h0_detailed_buffer[i][j]=h0_sd[i][j];
	}
    }
  else
    sd_h0=NULL;

  
  if(h0_max && h0_lognormal)
    {
      max_h0=new double*[max_num_seg];
      max_h0_detailed_buffer=new double*[max_num_seg];
      lognormal_h0=new bool*[max_num_seg];
      lognormal_h0_detailed_buffer=new bool*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  max_h0[i]=new double[i+1];
	  max_h0_detailed_buffer[i]=new double[i+1];
	  lognormal_h0[i]=new bool[i+1];
	  lognormal_h0_detailed_buffer[i]=new bool[i+1];
	  for(j=0;j<=i;j++)
	    {
	      max_h0[i][j]=max_h0_detailed_buffer[i][j]=h0_max[i][j];
	      lognormal_h0[i][j]=lognormal_h0_detailed_buffer[i][j]=
		h0_lognormal[i][j];
	    }
	}
    }
  else
    {
      max_h0=NULL;
      lognormal_h0=NULL;
    }
  
  lin_m=new double*[max_num_seg];
  lin_a_sd=new double[max_num_seg];
  lin_b_sd=new double*[max_num_seg];
  lin_corr=new double[max_num_seg];
  if(detailed_lin || extremely_detailed_lin)
    {
      lin_m_detailed_buffer=new double*[max_num_seg];
      lin_a_sd_detailed_buffer=new double[max_num_seg];
      lin_b_sd_detailed_buffer=new double*[max_num_seg];
      lin_corr_detailed_buffer=new double[max_num_seg];
    }
  for(i=0;i<max_num_seg;i++)
    {
      lin_m[i]=new double[i+2];
      if(detailed_lin || extremely_detailed_lin)
	lin_m_detailed_buffer[i]=new double[i+2];
      // set mu_a for this model:
      lin_m[i][0]=a_mu[i];
      if(detailed_lin || extremely_detailed_lin)
	lin_m_detailed_buffer[i][0]=a_mu[i];
      // set the mu_b's for this model:

      lin_corr[i]=cor[i];
      lin_a_sd[i]=a_sd[i];
      lin_b_sd[i]=new double[i+1];
      if(detailed_lin || extremely_detailed_lin)
	{
	  lin_corr_detailed_buffer[i]=cor[i];
	  lin_a_sd_detailed_buffer[i]=a_sd[i];
	  lin_b_sd_detailed_buffer[i]=new double[i+1];
	}
      for(j=0;j<(i+1);j++)
	{
	  lin_m[i][j+1]=b_mu[i][j];
	  if(detailed_lin || extremely_detailed_lin)
	    lin_m_detailed_buffer[i][j+1]=b_mu[i][j];
	}

      for(j=0;j<(i+1);j++)
	{
	  lin_b_sd[i][j]=b_sd[i][j];
	  if(detailed_lin || extremely_detailed_lin)
	    lin_b_sd_detailed_buffer[i][j]=b_sd[i][j];
	}
    }
  
  lin_V=new double**[max_num_seg];
  if(detailed_lin || extremely_detailed_lin)
    lin_V_detailed_buffer=new double**[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    {
      lin_V[i]=new double*[dim[i]];
      if(detailed_lin || extremely_detailed_lin)
	lin_V_detailed_buffer[i]=new double*[dim[i]];
      for(j=0;j<dim[i];j++)
	{
	  lin_V[i][j]=new double[dim[i]];
	  if(detailed_lin || extremely_detailed_lin)
	    lin_V_detailed_buffer[i][j]=new double[dim[i]];
	}
      for(j=0;j<dim[i];j++)
	for(k=0;k<dim[i];k++)
	  {
	    lin_V[i][j][k]=V_[i][j][k];
	    if(detailed_lin || extremely_detailed_lin)
	      lin_V_detailed_buffer[i][j][k]=V_[i][j][k];
	  }
    }
}

segmented_priors::segmented_priors(segmented_priors *orig)
{
  int i,j,k;
  
  initialize();
  
  first_init=orig->first_init;
  min_num_seg=orig->min_num_seg;
  max_num_seg=orig->max_num_seg;
  
  dim=new int[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    dim[i]=orig->dim[i];
  
  if(orig->mu_hs)
    {
      mu_hs=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  mu_hs[i]=new double[i+1];
	  for(j=0;j<i;j++)
	    mu_hs[i][j]=orig->mu_hs[i][j];
	}
    }
  else
    mu_hs=NULL;

  if(orig->mu_hs_detailed_buffer)
    {
      mu_hs_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(orig->mu_hs_detailed_buffer[i])
	    {
	      mu_hs_detailed_buffer[i]=new double[i+1];
	      for(j=0;j<i;j++)
		mu_hs_detailed_buffer[i][j]=orig->mu_hs_detailed_buffer[i][j];
	    }
	  else
	    mu_hs_detailed_buffer[i]=NULL;
	}
    }
  else
    mu_hs_detailed_buffer=NULL;

  if(orig->sd_hs)
    {
      sd_hs=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  sd_hs[i]=new double[i+1];
	  for(j=0;j<i;j++)
	    sd_hs[i][j]=orig->sd_hs[i][j];
	}
    }
  else
    sd_hs=NULL;
  
  if(orig->sd_hs_detailed_buffer)
    {
      sd_hs_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(orig->sd_hs_detailed_buffer[i])
	    {
	      sd_hs_detailed_buffer[i]=new double[i+1];
	      for(j=0;j<i;j++)
		sd_hs_detailed_buffer[i][j]=orig->sd_hs_detailed_buffer[i][j];
	    }
	  else
	    sd_hs_detailed_buffer[i]=NULL;
	}
    }
  else
    sd_hs_detailed_buffer=NULL;
  
  if(orig->mu_h0)
    {
      mu_h0=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  mu_h0[i]=new double[i+1];
	  for(j=0;j<=i;j++)
	    mu_h0[i][j]=orig->mu_h0[i][j];
	}
    }
  else
    mu_h0=NULL;

  if(orig->mu_h0_detailed_buffer)
    {
      mu_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(orig->mu_h0_detailed_buffer[i])
	    {
	      mu_h0_detailed_buffer[i]=new double[i+1];
	      for(j=0;j<=i;j++)
		mu_h0_detailed_buffer[i][j]=orig->mu_h0_detailed_buffer[i][j];
	    }
	  else
	    mu_h0_detailed_buffer[i]=NULL;
	}
    }
  else
    mu_h0_detailed_buffer=NULL;

  if(orig->sd_h0)
    {
      sd_h0=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  sd_h0[i]=new double[i+1];
	  for(j=0;j<=i;j++)
	    sd_h0[i][j]=orig->sd_h0[i][j];
	}
    }
  else
    sd_h0=NULL;
  
  if(orig->sd_h0_detailed_buffer)
    {
      sd_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(orig->sd_h0_detailed_buffer[i])
	    {
	      sd_h0_detailed_buffer[i]=new double[i+1];
	      for(j=0;j<=i;j++)
		sd_h0_detailed_buffer[i][j]=orig->sd_h0_detailed_buffer[i][j];
	    }
	  else
	    sd_h0_detailed_buffer[i]=NULL;
	}
    }
  else
    sd_h0_detailed_buffer=NULL;
  
  if(orig->max_h0)
    {
      max_h0=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  max_h0[i]=new double[i+1];
	  for(j=0;j<=i;j++)
	    max_h0[i][j]=orig->max_h0[i][j];
	}
    }
  else
    max_h0=NULL;

  if(orig->max_h0_detailed_buffer)
    {
      max_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(orig->max_h0_detailed_buffer[i])
	    {
	      max_h0_detailed_buffer[i]=new double[i+1];
	      for(j=0;j<=i;j++)
		max_h0_detailed_buffer[i][j]=orig->max_h0_detailed_buffer[i][j];
	    }
	  else
	    max_h0_detailed_buffer[i]=NULL;
	}
    }
  else
    max_h0_detailed_buffer=NULL;

  if(orig->lognormal_h0)
    {
      lognormal_h0=new bool*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  lognormal_h0[i]=new bool[i+1];
	  for(j=0;j<=i;j++)
	    lognormal_h0[i][j]=orig->lognormal_h0[i][j];
	}
    }
  else
    lognormal_h0=NULL;

  if(orig->lognormal_h0_detailed_buffer)
    {
      lognormal_h0_detailed_buffer=new bool*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(orig->lognormal_h0_detailed_buffer[i])
	    {
	      lognormal_h0_detailed_buffer[i]=new bool[i+1];
	      for(j=0;j<=i;j++)
		lognormal_h0_detailed_buffer[i][j]=
		  orig->lognormal_h0_detailed_buffer[i][j];
	    }
	  else
	    lognormal_h0_detailed_buffer[i]=NULL;
	}
    }
  else
    lognormal_h0_detailed_buffer=NULL;

  lin_m=new double*[max_num_seg];
  if(orig->lin_m_detailed_buffer)
    lin_m_detailed_buffer=new double*[max_num_seg];
  lin_a_sd=new double[max_num_seg];
  if(orig->lin_a_sd_detailed_buffer)
    lin_a_sd_detailed_buffer=new double[max_num_seg];
  lin_b_sd=new double*[max_num_seg];
  if(orig->lin_b_sd_detailed_buffer)
    lin_b_sd_detailed_buffer=new double*[max_num_seg];
  lin_corr=new double[max_num_seg];
  if(orig->lin_corr_detailed_buffer)
    lin_corr_detailed_buffer=new double[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    {
      lin_m[i]=new double[i+2];
      if(orig->lin_m_detailed_buffer)
	{
	  if(orig->lin_m_detailed_buffer[i])
	    lin_m_detailed_buffer[i]=new double[i+2];
	  else
	    lin_m_detailed_buffer[i]=NULL;
	}
      
      // set mu_a for this model:
      lin_m[i][0]=orig->lin_m[i][0];
      if(orig->lin_m_detailed_buffer && orig->lin_m_detailed_buffer[i])
	lin_m_detailed_buffer[i][0]=orig->lin_m_detailed_buffer[i][0];
      
      // set the mu_b's for this model:

      lin_corr[i]=orig->lin_corr[i];
      if(orig->lin_corr_detailed_buffer)
	lin_corr_detailed_buffer[i]=orig->lin_corr_detailed_buffer[i];
      lin_a_sd[i]=orig->lin_a_sd[i];
      if(orig->lin_a_sd_detailed_buffer)
	 lin_a_sd_detailed_buffer[i]=orig->lin_a_sd_detailed_buffer[i];
      lin_b_sd[i]=new double[i+1];
      if(orig->lin_b_sd_detailed_buffer)
	{
	  if(orig->lin_b_sd_detailed_buffer[i])
	    lin_b_sd_detailed_buffer[i]=new double[i+1];
	  else
	    lin_b_sd_detailed_buffer[i]=NULL;
	}
      
      for(j=0;j<(i+1);j++)
	{
	  lin_m[i][j+1]=orig->lin_m[i][j+1];
	  if(orig->lin_m_detailed_buffer && 
	     orig->lin_m_detailed_buffer[i])
	    {
	      lin_m_detailed_buffer[i][j+1]=
		orig->lin_m_detailed_buffer[i][j+1];
	    }
	}
      for(j=0;j<(i+1);j++)
	{
	  lin_b_sd[i][j]=orig->lin_b_sd[i][j];
	  if(orig->lin_b_sd_detailed_buffer && 
	     orig->lin_b_sd_detailed_buffer[i])
	    lin_b_sd_detailed_buffer[i][j]=orig->lin_b_sd_detailed_buffer[i][j];
	}
    }

  lin_V=new double**[max_num_seg];
  if(orig->lin_V_detailed_buffer)
    lin_V_detailed_buffer=new double**[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    {
      lin_V[i]=new double*[dim[i]];
      if(orig->lin_V_detailed_buffer)
	{
	  if(orig->lin_V_detailed_buffer[i])
	    lin_V_detailed_buffer[i]=new double*[dim[i]];
	  else
	    lin_V_detailed_buffer[i]=NULL;
	}

      for(j=0;j<dim[i];j++)
	{
	  lin_V[i][j]=new double[dim[i]];
	  if(orig->lin_V_detailed_buffer &&
	     orig->lin_V_detailed_buffer[i])
	    {
	      if(orig->lin_V_detailed_buffer[i][j])
		lin_V_detailed_buffer[i][j]=new double[dim[i]];
	      else
		lin_V_detailed_buffer[i][j]=NULL;
	    }
	}
      
      for(j=0;j<dim[i];j++)
	for(k=0;k<dim[i];k++)
	  {
	    lin_V[i][j][k]=orig->lin_V[i][j][k];
	    if(orig->lin_V_detailed_buffer && 
	       orig->lin_V_detailed_buffer[i] && 
	       orig->lin_V_detailed_buffer[i][j])
	      lin_V_detailed_buffer[i][j][k]=
		orig->lin_V_detailed_buffer[i][j][k];
	  }
    }

  overall_a_mean=orig->overall_a_mean;
  overall_b_mean=orig->overall_b_mean;
  overall_a_sd=orig->overall_a_sd;
  overall_b_sd=orig->overall_b_sd;
  overall_corr=orig->overall_corr;
  
  sigma_a=orig->sigma_a;
  sigma_b=orig->sigma_b;
  sigma_lower=orig->sigma_lower;
  sigma_upper=orig->sigma_upper;
  sigma_cred=orig->sigma_cred;
  mu_q=orig->mu_q;
  sd_q=orig->sd_q;
  mu_h01=orig->mu_h01;
  mu_h02=orig->mu_h02;
  sd_h01=orig->sd_h01;
  sd_h02=orig->sd_h02;
  max_h01=orig->max_h01;
  lognormal_h01=orig->lognormal_h01;
  
  prob_model=new double[max_num_seg];
  for(i=0;i<max_num_seg;i++)
    prob_model[i]=orig->prob_model[i];

  detailed_hs=orig->detailed_hs;
  detailed_h0=orig->detailed_h0;
  detailed_lin=orig->detailed_lin;
  extremely_detailed_lin=orig->extremely_detailed_lin;

  standard_mu_a=orig->standard_mu_a; 
  standard_mu_b=orig->standard_mu_b;
  standard_sd_a=orig->standard_sd_a; 
  standard_sd_b=orig->standard_sd_b; 
  standard_cor=orig->standard_cor;
  standard_sigma_a=orig->standard_sigma_a; 
  standard_sigma_b=orig->standard_sigma_b;
  standard_sigma_upper_cred=orig->standard_sigma_upper_cred; 
  standard_sigma_lower_cred=orig->standard_sigma_lower_cred;
  standard_sigma_cred=orig->standard_sigma_cred; 
  standard_mu_q=orig->standard_mu_q; 
  standard_sd_q=orig->standard_sd_q;
  standard_h01_mu=orig->standard_h01_mu; 
  standard_h01_sd=orig->standard_h01_sd;
  standard_h02_mu=orig->standard_h02_mu; 
  standard_h02_sd=orig->standard_h02_sd;


  if(orig->num_restr > 0)
    {
      num_restr=orig->num_restr;
      num_lower_and_upper=orig->num_lower_and_upper;
      
      if(orig->restr_stage)
	{
	  restr_stage=new double[num_restr];
	  for(i=0;i<num_restr;i++)
	    restr_stage[i]=orig->restr_stage[i];
	}
      if(orig->restr_q_lower)
	{
	  restr_q_lower=new double[num_restr];
	  for(i=0;i<num_restr;i++)
	    restr_q_lower[i]=orig->restr_q_lower[i];
	}
      if(orig->restr_q_upper)
	{
	  restr_q_upper=new double[num_restr];
	  for(i=0;i<num_restr;i++)
	    restr_q_upper[i]=orig->restr_q_upper[i];
	}
      if(orig->restr_comment)
	{
	  restr_comment=new char*[num_restr];
	  for(i=0;i<num_restr;i++)
	    if(orig->restr_comment[i])
	      {
		restr_comment[i]=new char[strlen(orig->restr_comment[i])+2];
		strcpy(restr_comment[i],orig->restr_comment[i]);
	      }
	    else
	      restr_comment[i]=NULL;
	}
    }
  else
    {
      num_restr=num_lower_and_upper=0;
      restr_stage=restr_q_lower=restr_q_upper=NULL;
      restr_comment=NULL;
    }
  
  if(orig->num_extra > 0)
    {
      num_extra=orig->num_extra;
      num_extra_lower_and_upper=orig->num_extra_lower_and_upper;
      
      if(orig->extra_stage)
	{
	  extra_stage=new double[num_extra];
	  for(i=0;i<num_extra;i++)
	    extra_stage[i]=orig->extra_stage[i];
	}
      if(orig->extra_q_lower)
	{
	  extra_q_lower=new double[num_extra];
	  for(i=0;i<num_extra;i++)
	    extra_q_lower[i]=orig->extra_q_lower[i];
	}
      if(orig->extra_q_upper)
	{
	  extra_q_upper=new double[num_extra];
	  for(i=0;i<num_extra;i++)
	    extra_q_upper[i]=orig->extra_q_upper[i];
	}
      if(orig->extra_comment)
	{
	  extra_comment=new char*[num_extra];
	  for(i=0;i<num_extra;i++)
	    if(orig->extra_comment[i])
	      {
		extra_comment[i]=new char[strlen(orig->extra_comment[i])+2];
		strcpy(extra_comment[i],orig->extra_comment[i]);
	      }
	    else
	      extra_comment[i]=NULL;
	}
    }
  else
    {
      num_extra=num_extra_lower_and_upper=0;
      extra_stage=extra_q_lower=extra_q_upper=NULL;
      extra_comment=NULL;
    }
}


// Prior restrictions are "measurement"-like
// information restricting the discharge at 
// a given set of stage values in the extrapolated area. 
// If both upper and lower bounds are given, this is 
// interpreted as a 95% credibility interval. If only upper 
// (lower=MISSING_VALUE) or vice versa, then this
// is viewed as a hard boundry. PS: Must be set before the prior
// is used in an analysis, in order to have effect!
void segmented_priors::set_extrapolation_restrictions(int num_prior_extrapol, 
						      double *extrapol_stage,
						      double *extrapol_lower, 
						      double *extrapol_upper,
						      char **extrapol_comment)
{
  // Store extrapolation prior (if any)
  if(num_prior_extrapol>0 && extrapol_stage &&
     (extrapol_lower || extrapol_upper))
    {
      int i;
      
      num_extra=num_prior_extrapol;
      num_extra_lower_and_upper=0;
      
      extra_stage=new double[num_extra];
      extra_q_lower=new double[num_extra];
      extra_q_upper=new double[num_extra];
      extra_comment=new char*[num_extra];

      for(i=0;i<num_extra;i++)
	{
	  if(extrapol_comment && extrapol_comment[i])
	    {
	      extra_comment[i]=new char[strlen(extrapol_comment[i])+10];
	      strcpy(extra_comment[i], extrapol_comment[i]);
	    }
	  else
	    {
	      extra_comment[i]=new char[10];
	      strcpy(extra_comment[i],"");
	    }
	  
	  extra_stage[i]=extrapol_stage[i];
	  
	  if(extrapol_lower && extrapol_lower[i]!=MISSING_VALUE && extrapol_lower[i]>0.0)
	    extra_q_lower[i]=log(extrapol_lower[i]);
	  else
	    extra_q_lower[i]=MISSING_VALUE;
	  
	  if(extrapol_upper && extrapol_upper[i]!=MISSING_VALUE && extrapol_upper[i]>0.0)
	    extra_q_upper[i]=log(extrapol_upper[i]);
	  else
	    extra_q_upper[i]=MISSING_VALUE;
	  
	  if(extra_q_lower[i]!=MISSING_VALUE && 
	     extra_q_upper[i]!=MISSING_VALUE)
	    num_extra_lower_and_upper++;
	}
    }
  else
    {
      num_extra=num_extra_lower_and_upper=0;
      extra_stage=extra_q_lower=extra_q_upper=NULL;
      extra_comment=NULL;
    }
}

// Note: Interplation restrictions should
// only be used in the interpolated stage area.
// If used outside, the interpolated area will be
// epxanded, which can have unforseen consequences.
void segmented_priors::
set_interpolation_restrictions(int num_prior_restrictions, 
			       double *restriction_stage,
			       double *discharge_lower, 
			       double *discharge_upper,
			       char **restriction_comment)
{
  // Store restrictions (if any)
  if(num_prior_restrictions>0 && restriction_stage &&
     (discharge_lower || discharge_upper))
    {
      int i;
      
      num_restr=num_prior_restrictions;
      num_lower_and_upper=0;
      
      restr_stage=new double[num_restr];
      restr_q_lower=new double[num_restr];
      restr_q_upper=new double[num_restr];
      restr_comment=new char*[num_restr];
      
      for(i=0;i<num_restr;i++)
	{
	  if(restriction_comment && restriction_comment[i])
	    {
	      restr_comment[i]=new char[strlen(restriction_comment[i])+10];
	      strcpy(restr_comment[i], restriction_comment[i]);
	    }
	  else
	    {
	      restr_comment[i]=new char[10];
	      strcpy(restr_comment[i],"");
	    }
	  
	  restr_stage[i]=restriction_stage[i];
	  
	  if(discharge_lower && discharge_lower[i]!=MISSING_VALUE)
	    restr_q_lower[i]=log(discharge_lower[i]);
	  else
	    restr_q_lower[i]=MISSING_VALUE;
	  
	  if(discharge_upper && discharge_upper[i]!=MISSING_VALUE)
	    restr_q_upper[i]=log(discharge_upper[i]);
	  else
	    restr_q_upper[i]=MISSING_VALUE;
	  
	  if(restr_q_lower[i]!=MISSING_VALUE && 
	     restr_q_upper[i]!=MISSING_VALUE)
	    num_lower_and_upper++;
	}
    }
  else
    {
      num_restr=num_lower_and_upper=0;
      restr_stage=restr_q_lower=restr_q_upper=NULL;
      restr_comment=NULL;
    }
  
}
  

segmented_priors::~segmented_priors()
{
  cleanup();
}

void segmented_priors::set_model_probabilities(double *probs)
{
  int i;
  double norm=0.0;

  for(i=0;i<max_num_seg;i++)
    {
      prob_model[i]=probs[i];
      norm+=probs[i];
    }

  if(!almost_equal(norm, 1.0))
    for(i=0;i<max_num_seg;i++)
      prob_model[i]/=norm;
}

void segmented_priors::
set_linear_parameters_simple(double a_mu, double b_mu, 
			     double a_sd, double b_sd, double cor,
			     bool is_detailed, 
			     bool is_extreme_detailed)
{
  if(max_num_seg<=0 || !lin_V || !lin_m || !dim)
    {
      std::cerr << "segmented_priors not initialized!" << std::endl;
      exit(0);
    }

  detailed_lin=is_detailed;
  extremely_detailed_lin=is_extreme_detailed;

  overall_a_mean=a_mu;
  overall_b_mean=b_mu;
  overall_a_sd=a_sd;
  overall_b_sd=b_sd;
  overall_corr=cor;
  
  if(!is_detailed && !is_extreme_detailed)
    {
      int i,j,k;
      for(i=0;i<max_num_seg;i++)
	{
	  lin_m[i][0]=a_mu;
	  for(j=1;j<dim[i];j++)
	    lin_m[i][j]=b_mu;
	  lin_V[i][0][0]=a_sd*a_sd;
	  for(j=1;j<dim[i];j++)
	    {
	      lin_V[i][0][j]=lin_V[i][j][0]=cor*a_sd*b_sd;
	      for(k=1;k<dim[i];k++)
		{
		  if(j==k)
		    lin_V[i][j][k]=b_sd*b_sd;
		  else
		    lin_V[i][j][k]=cor*cor*b_sd*b_sd;
		}
	    }
	}
    }
}

void segmented_priors::
set_linear_parameters_detailed(double *a_mu, double **b_mu, 
			       double *a_sd, double **b_sd, 
			       double cor)
{
  if(max_num_seg<=0 || !lin_V || !lin_m || !dim)
    {
      std::cerr << "segmented_priors not initialized!" << std::endl;
      exit(0);
    }

  detailed_lin=true;
  extremely_detailed_lin=false;

  int i,j,k;

  lin_a_sd=new double[max_num_seg];
  lin_b_sd=new double*[max_num_seg];
  lin_corr=new double[max_num_seg];
  lin_a_sd_detailed_buffer=new double[max_num_seg];
  lin_b_sd_detailed_buffer=new double*[max_num_seg];
  lin_corr_detailed_buffer=new double[max_num_seg];
  if(!lin_m_detailed_buffer)
    {
      lin_m_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	 lin_m_detailed_buffer[i]=new double[i+2];
    }
  if(!lin_V_detailed_buffer)
    {
      lin_V_detailed_buffer=new double**[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  lin_V_detailed_buffer[i]=new double*[dim[i]];
	  for(j=0;j<dim[i];j++)
	    lin_V_detailed_buffer[i][j]=new double[dim[i]];
	} 
    }

  for(i=0;i<max_num_seg;i++)
    {
      lin_m[i][0]=lin_m_detailed_buffer[i][0]=a_mu[i];
      lin_a_sd[i]=lin_a_sd_detailed_buffer[i]=a_sd[i];
      lin_corr[i]=lin_corr_detailed_buffer[i]=cor;
      lin_b_sd[i]=new double[i+1];
      lin_b_sd_detailed_buffer[i]=new double[i+1];
      for(j=0;j<=i;j++)
	lin_b_sd[i][j]=lin_b_sd_detailed_buffer[i][j]=b_sd[i][j];
      for(j=1;j<dim[i];j++)
	lin_m[i][j]=lin_m_detailed_buffer[i][j]=b_mu[i][j-1];
      lin_V[i][0][0]=lin_V_detailed_buffer[i][0][0]=a_sd[i]*a_sd[i];
      for(j=1;j<dim[i];j++)
	{
	  lin_V[i][0][j]=lin_V[i][j][0]=
	    lin_V_detailed_buffer[i][0][j]=lin_V_detailed_buffer[i][j][0]=
	    cor*a_sd[i]*b_sd[i][j-1];
	  for(k=1;k<dim[i];k++)
	    {
	      if(j==k)
		lin_V[i][j][k]=lin_V_detailed_buffer[i][j][k]=
		  b_sd[i][j-1]*b_sd[i][k-1];
	      else
		lin_V[i][j][k]=lin_V_detailed_buffer[i][j][k]=
		  cor*cor*b_sd[i][j-1]*b_sd[i][k-1];
	    }
	}
    }
}

void segmented_priors::
set_linear_parameters_detailed(double *a_mu, double **b_mu, 
			       double *a_sd, double **b_sd, 
			       double *cor)
{
  if(max_num_seg<=0 || !lin_V || !lin_m || !dim)
    {
      std::cerr << "segmented_priors not initialized!" << std::endl;
      exit(0);
    }

  detailed_lin=true;
  extremely_detailed_lin=false;

  int i,j,k;
  lin_a_sd=new double[max_num_seg];
  lin_b_sd=new double*[max_num_seg];
  lin_corr=new double[max_num_seg];
  lin_a_sd_detailed_buffer=new double[max_num_seg];
  lin_b_sd_detailed_buffer=new double*[max_num_seg];
  lin_corr_detailed_buffer=new double[max_num_seg];
  if(!lin_m_detailed_buffer)
    {
      lin_m_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	 lin_m_detailed_buffer[i]=new double[i+2];
    }
  if(!lin_V_detailed_buffer)
    {
      lin_V_detailed_buffer=new double**[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  lin_V_detailed_buffer[i]=new double*[dim[i]];
	  for(j=0;j<dim[i];j++)
	    lin_V_detailed_buffer[i][j]=new double[dim[i]];
	} 
    }

  for(i=0;i<max_num_seg;i++)
    {
      lin_m[i][0]=lin_m_detailed_buffer[i][0]=a_mu[i];
      lin_a_sd[i]=lin_a_sd_detailed_buffer[i]=a_sd[i];
      lin_corr[i]=lin_corr_detailed_buffer[i]=cor[i];
      lin_b_sd[i]=new double[i+1];
      lin_b_sd_detailed_buffer[i]=new double[i+1];
      for(j=0;j<=i;j++)
	lin_b_sd[i][j]=lin_b_sd_detailed_buffer[i][j]=b_sd[i][j];
      for(j=1;j<dim[i];j++)
	lin_m[i][j]=lin_m_detailed_buffer[i][j]=b_mu[i][j-1];
      lin_V[i][0][0]=lin_V_detailed_buffer[i][0][0]=a_sd[i]*a_sd[i];
      for(j=1;j<dim[i];j++)
	{
	  lin_V[i][0][j]=lin_V[i][j][0]=
	    lin_V_detailed_buffer[i][0][j]=lin_V_detailed_buffer[i][j][0]=
	    cor[i]*a_sd[i]*b_sd[i][j-1];
	  for(k=1;k<dim[i];k++)
	    {
	      if(j==k)
		lin_V[i][j][k]=lin_V_detailed_buffer[i][j][k]=
		  b_sd[i][j-1]*b_sd[i][k-1];
	      else
		lin_V[i][j][k]=lin_V_detailed_buffer[i][j][k]=
		  cor[i]*cor[i]*b_sd[i][j-1]*b_sd[i][k-1];
	    }
	}
    }
}

void segmented_priors::
set_linear_parameters_extremely_detailed(double *a_mu, double **b_mu, 
					 double *a_sd, double **b_sd, 
					 double ***cor)
{
  if(max_num_seg<=0 || !lin_V || !lin_m || !dim)
    {
      std::cerr << "segmented_priors not initialized!" << std::endl;
      exit(0);
    }

  detailed_lin=true;
  extremely_detailed_lin=true;

  int i,j,k;
  if(!lin_m_detailed_buffer)
    {
      lin_m_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	 lin_m_detailed_buffer[i]=new double[i+2];
    }
  if(!lin_V_detailed_buffer)
    {
      lin_V_detailed_buffer=new double**[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  lin_V_detailed_buffer[i]=new double*[dim[i]];
	  for(j=0;j<dim[i];j++)
	    lin_V_detailed_buffer[i][j]=new double[dim[i]];
	} 
    }
  
  for(i=0;i<max_num_seg;i++)
    {
      lin_m[i][0]=lin_m_detailed_buffer[i][0]=a_mu[i];
      for(j=1;j<dim[i];j++)
	lin_m[i][j]=lin_m_detailed_buffer[i][j]=b_mu[i][j-1];
      lin_V[i][0][0]=lin_V_detailed_buffer[i][0][0]=a_sd[i]*a_sd[i];
      for(j=1;j<dim[i];j++)
	{
	  lin_V[i][0][j]=lin_V[i][j][0]=
	    lin_V_detailed_buffer[i][0][j]=lin_V_detailed_buffer[i][j][0]=
	    cor[i][0][j]*a_sd[i]*b_sd[i][j-1];
	  for(k=1;k<dim[i];k++)
	    {
	      if(j==k)
		lin_V[i][j][k]=lin_V_detailed_buffer[i][j][k]=
		  b_sd[i][j-1]*b_sd[i][k-1];
	      else
		lin_V[i][j][k]=lin_V_detailed_buffer[i][j][k]=
		  cor[i][j][k]*cor[i][j][k]*b_sd[i][j-1]*b_sd[i][k-1];
	    }
	}
    }
}

void segmented_priors::copy_linear_parameters_to_buffer(void)
{
  int i,j,k;

  if(lin_b_sd_detailed_buffer)
    doubledelete(lin_b_sd_detailed_buffer, max_num_seg);
  lin_b_sd_detailed_buffer=NULL;

  if(lin_m_detailed_buffer)
    doubledelete(lin_m_detailed_buffer, max_num_seg);
  lin_m_detailed_buffer=NULL;
  
  if(lin_V_detailed_buffer)
    tripledelete(lin_V_detailed_buffer, max_num_seg, dim);
  lin_V_detailed_buffer=NULL;
  
  if(lin_a_sd_detailed_buffer)
    delete [] lin_a_sd_detailed_buffer;
  lin_a_sd_detailed_buffer=NULL;

  if(lin_corr_detailed_buffer)
    delete [] lin_corr_detailed_buffer;
  lin_corr_detailed_buffer=NULL;

  if(lin_m)
    {
      lin_m_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(lin_m[i])
	    {
	      lin_m_detailed_buffer[i]=new double[i+2];
	      for(j=0;j<dim[i];j++)
		lin_m_detailed_buffer[i][j]=lin_m[i][j];
	    }
	  else
	    lin_m_detailed_buffer[i]=NULL;
	}
    }
  
  if(lin_V)
    {
      lin_V_detailed_buffer=new double**[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(lin_V[i])
	    {
	      lin_V_detailed_buffer[i]=new double*[dim[i]];
	      for(j=0;j<dim[i];j++)
		{
		  if(lin_V[i][j])
		    {
		      lin_V_detailed_buffer[i][j]=new double[dim[i]];
		      for(k=0;k<dim[i];k++)
			lin_V_detailed_buffer[i][j][k]=lin_V[i][j][k];
		    }
		  else
		    lin_V_detailed_buffer[i][j]=NULL;
		}
	    } 
	  else
	    lin_V_detailed_buffer[i]=NULL;
	}
    }

  if(lin_a_sd)
    {
      lin_a_sd_detailed_buffer=new double[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	lin_a_sd_detailed_buffer[i]=lin_a_sd[i];
    }
  
  if(lin_b_sd)
    {
      lin_b_sd_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(lin_b_sd[i])
	    {
	      lin_b_sd_detailed_buffer[i]=new double[i+1];
	      for(j=0;j<(i+1);j++)
		lin_b_sd_detailed_buffer[i][j]=lin_b_sd[i][j];
	    }
	  else
	    lin_b_sd_detailed_buffer[i]=NULL;
	}
    }
  
  if(lin_corr)
    {
      lin_corr_detailed_buffer=new double[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	lin_corr_detailed_buffer[i]=lin_corr[i];
    }
}


void segmented_priors::copy_buffer_parameters_to_linear(void)
{
  int i,j,k;
  
  if(lin_m_detailed_buffer)
    for(i=0;i<max_num_seg;i++)
      for(j=0;j<dim[i];j++)
	lin_m[i][j]=lin_m_detailed_buffer[i][j];
  
  if(lin_V_detailed_buffer)
  for(i=0;i<max_num_seg;i++)
    for(j=0;j<dim[i];j++)
      for(k=0;k<dim[i];k++)
	lin_V[i][j][k]=lin_V_detailed_buffer[i][j][k];

  if(lin_a_sd_detailed_buffer)
    {
      if(!lin_a_sd)
	lin_a_sd=new double[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	lin_a_sd[i]=lin_a_sd_detailed_buffer[i];
    }
  
  if(lin_b_sd_detailed_buffer)
    {
      if(!lin_b_sd)
	lin_b_sd=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  if(lin_b_sd_detailed_buffer[i])
	    {
	      if(!lin_b_sd[i])
		lin_b_sd[i]=new double[i+1];
	      for(j=0;j<(i+1);j++)
		lin_b_sd[i][j]=lin_b_sd_detailed_buffer[i][j];
	    }
	  else
	    lin_b_sd[i]=NULL;
	}
    }
  
  if(lin_corr_detailed_buffer)
    {
      if(!lin_corr)
	lin_corr=new double[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	lin_corr[i]=lin_corr_detailed_buffer[i];
    }
}


void segmented_priors::
set_sigma_parameters(double lower_cred, double upper_cred, double credibility)
{
  sigma_lower=lower_cred;
  sigma_upper=upper_cred;
  sigma_cred=credibility;
  find_invgamma_distribution(lower_cred*lower_cred, upper_cred*upper_cred, 
			     credibility*100.0,&sigma_a, &sigma_b);
}

void segmented_priors::set_sigma_parameters(double sigma_a_, 
					    double sigma_b_)
{
  sigma_a=sigma_a_;
  sigma_b=sigma_b_;
  
  sigma_lower=sqrt(1.0/gsl_cdf_gamma_Pinv(0.975, sigma_a, 1.0/sigma_b));
  sigma_upper=sqrt(1.0/gsl_cdf_gamma_Pinv(0.025, sigma_a, 1.0/sigma_b));
  sigma_cred=0.95;
}

void segmented_priors::set_h0_simple(double h01_mu,double h01_sd, 
				     bool h01_lognormal, double h01_max,
				     double h02_mu,double h02_sd)
{
  doubledelete(mu_h0, max_num_seg);
  mu_h0=NULL;
  doubledelete(sd_h0, max_num_seg);
  sd_h0=NULL;
  doubledelete(max_h0, max_num_seg);
  max_h0=NULL;
  doubledelete(lognormal_h0, max_num_seg);
  lognormal_h0=NULL;

  detailed_h0=false;
  
  mu_h01=h01_mu;
  sd_h01=h01_sd;
  mu_h02=h02_mu;
  sd_h02=h02_sd;
  lognormal_h01=h01_lognormal;
  max_h01=h01_max;
}


void segmented_priors::set_h01_simple(double h01_mu,double h01_sd)
{
  doubledelete(mu_h0, max_num_seg);
  mu_h0=NULL;
  doubledelete(sd_h0, max_num_seg);
  sd_h0=NULL;
  doubledelete(max_h0, max_num_seg);
  max_h0=NULL;
  doubledelete(lognormal_h0, max_num_seg);
  lognormal_h0=NULL;

  detailed_h0=false;
  
  mu_h01=h01_mu;
  sd_h01=h01_sd;
  lognormal_h01=false;
  max_h01=MISSING_VALUE;
}


void segmented_priors::set_h0_detailed(double **h0_mu, double **h0_sd, 
				       bool **h0_lognormal,double **h0_max)
{
  int i,j;

  if(!mu_h0)
    {
      mu_h0=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	mu_h0[i]=new double[i+1];
    }

  if(!mu_h0_detailed_buffer)
    {
      mu_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	mu_h0_detailed_buffer[i]=new double[i+1];
    }

  if(!sd_h0)
    {
      sd_h0=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	sd_h0[i]=new double[i+1];
    }
  
  if(!sd_h0_detailed_buffer)
    {
      sd_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	sd_h0_detailed_buffer[i]=new double[i+1];
    }
  
  if(!lognormal_h0)
    {
      lognormal_h0=new bool*[max_num_seg];      
      for(i=0;i<max_num_seg;i++)
	lognormal_h0[i]=new bool[i+1];
    }

  if(!lognormal_h0_detailed_buffer)
    {
      lognormal_h0_detailed_buffer=new bool*[max_num_seg];      
      for(i=0;i<max_num_seg;i++)
	lognormal_h0_detailed_buffer[i]=new bool[i+1];
    }

  if(!max_h0)
    {
      max_h0=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	max_h0[i]=new double[i+1];
    }
  
  if(!max_h0_detailed_buffer)
    {
      max_h0_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	max_h0_detailed_buffer[i]=new double[i+1];
    }
  
  for(i=0;i<max_num_seg;i++)
    for(j=0;j<=i;j++)
      {
	mu_h0[i][j]=mu_h0_detailed_buffer[i][j]=h0_mu[i][j];
	sd_h0[i][j]=sd_h0_detailed_buffer[i][j]=h0_sd[i][j];
	
	if(h0_lognormal && h0_lognormal[i])
	  lognormal_h0[i][j]=lognormal_h0_detailed_buffer[i][j]=
	    h0_lognormal[i][j];
	else
	  lognormal_h0[i][j]=lognormal_h0_detailed_buffer[i][j]=false;
	  
	if(h0_lognormal && h0_lognormal[i] && h0_max && h0_max[i])
	  max_h0[i][j]=max_h0_detailed_buffer[i][j]=h0_max[i][j];
	else
	  max_h0[i][j]=max_h0_detailed_buffer[i][j]=MISSING_VALUE;
      }

  detailed_h0=true; 
}

void segmented_priors::set_h0_back_to_simple(void)
{
  doubledelete(mu_h0, max_num_seg);
  mu_h0=NULL;
  doubledelete(sd_h0, max_num_seg);
  sd_h0=NULL;
  doubledelete(max_h0, max_num_seg);
  max_h0=NULL;
  doubledelete(lognormal_h0, max_num_seg);
  lognormal_h0=NULL;
  
  detailed_h0=false;
}


void segmented_priors::copy_h0_parameters_to_buffer(void)
{
  int i,j;
  
  if(mu_h0)
    {
      if(!mu_h0_detailed_buffer)
	{
	  mu_h0_detailed_buffer=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    mu_h0_detailed_buffer[i]=new double[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  mu_h0_detailed_buffer[i][j]=mu_h0[i][j];
    }

  if(sd_h0)
    {
      if(!sd_h0_detailed_buffer)
	{
	  sd_h0_detailed_buffer=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    sd_h0_detailed_buffer[i]=new double[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  sd_h0_detailed_buffer[i][j]=sd_h0[i][j];
    }

  if(lognormal_h0)
    {
      if(!lognormal_h0_detailed_buffer)
	{
	  lognormal_h0_detailed_buffer=new bool*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    lognormal_h0_detailed_buffer[i]=new bool[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  lognormal_h0_detailed_buffer[i][j]=lognormal_h0[i][j];
    }

  if(max_h0)
    {
      if(!max_h0_detailed_buffer)
	{
	  max_h0_detailed_buffer=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    max_h0_detailed_buffer[i]=new double[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  max_h0_detailed_buffer[i][j]=max_h0[i][j];
    }
}

void segmented_priors::copy_buffer_parameters_to_h0(void)
{
  int i,j;
  
  if(mu_h0_detailed_buffer)
    {
      if(!mu_h0)
	{
	  mu_h0=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    mu_h0[i]=new double[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  mu_h0[i][j]=mu_h0_detailed_buffer[i][j];
    }

  if(sd_h0_detailed_buffer)
    {
      if(!sd_h0)
	{
	  sd_h0=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    sd_h0[i]=new double[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  sd_h0[i][j]=sd_h0_detailed_buffer[i][j];
    }

  if(mu_h0_detailed_buffer && sd_h0_detailed_buffer)
    detailed_h0=true;

  if(lognormal_h0_detailed_buffer)
    {
      if(!lognormal_h0)
	{
	  lognormal_h0=new bool*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    lognormal_h0[i]=new bool[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  lognormal_h0[i][j]=lognormal_h0_detailed_buffer[i][j];
    }

  if(max_h0_detailed_buffer)
    {
      if(!max_h0)
	{
	  max_h0=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    max_h0[i]=new double[i+1];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  max_h0[i][j]=max_h0_detailed_buffer[i][j];
    }
}



void segmented_priors::set_hs_simple(double q_mu, double q_sd)
{
  detailed_hs=false;
  mu_q=q_mu;
  sd_q=q_sd;
}

void segmented_priors::set_hs_detailed(double **hs_mu, 
				       double **hs_sd)
{
  int i;
  
  detailed_hs=true;
  doubledelete(mu_hs, max_num_seg);
  doubledelete(sd_hs, max_num_seg);
  
  mu_hs=new double*[max_num_seg];
  sd_hs=new double*[max_num_seg];
  if(!mu_hs_detailed_buffer)
    {
      mu_hs_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	mu_hs_detailed_buffer[i]=new double[i];
    }
  if(!sd_hs_detailed_buffer)
    {
      sd_hs_detailed_buffer=new double*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	sd_hs_detailed_buffer[i]=new double[i];
    }

  for(i=0;i<max_num_seg;i++)
    {
      mu_hs[i]=new double[i+1];
      sd_hs[i]=new double[i+1];
      for(int j=0;j<i;j++)
	{
	  mu_hs[i][j]=mu_hs_detailed_buffer[i][j]=hs_mu[i][j];
	  sd_hs[i][j]=sd_hs_detailed_buffer[i][j]=hs_sd[i][j];
	}
    }
}

void segmented_priors::set_hs_back_to_simple(void)
{
  detailed_hs=false;
}

void segmented_priors::copy_hs_parameters_to_buffer(void)
{
  int i,j;
  
  if(mu_hs)
    {
      if(!mu_hs_detailed_buffer)
	{
	  mu_hs_detailed_buffer=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    mu_hs_detailed_buffer[i]=new double[i];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<i;j++)
	  mu_hs_detailed_buffer[i][j]=mu_hs[i][j];
    }

  if(sd_hs)
    {
      if(!sd_hs_detailed_buffer)
	{
	  sd_hs_detailed_buffer=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    sd_hs_detailed_buffer[i]=new double[i];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<i;j++)
	  sd_hs_detailed_buffer[i][j]=sd_hs[i][j];
    }
}

void segmented_priors::copy_buffer_parameters_to_hs(void)
{
  int i,j;
  
  if(mu_hs_detailed_buffer)
    {
      if(!mu_hs)
	{
	  mu_hs=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    mu_hs[i]=new double[i];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<i;j++)
	  mu_hs[i][j]=mu_hs_detailed_buffer[i][j];
    }

  if(sd_hs_detailed_buffer)
    {
      if(!sd_hs)
	{
	  sd_hs=new double*[max_num_seg];
	  for(i=0;i<max_num_seg;i++)
	    sd_hs[i]=new double[i];
	}
      
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<i;j++)
	  sd_hs[i][j]=sd_hs_detailed_buffer[i][j];
    }

  if(mu_hs_detailed_buffer && sd_hs_detailed_buffer)
    detailed_hs=true;
}


double segmented_priors::
get_probability_of_model(int number_of_segments)
{
  if(number_of_segments>0 && number_of_segments<=max_num_seg)
    return prob_model[number_of_segments-1];
  else
    return 0.0;
}


bool segmented_priors::is_lin_detailed(void)
{
  return (detailed_lin==true || extremely_detailed_lin==true) ?
    true : false;
}

bool segmented_priors::is_lin_extremely_detailed(void)
{
  return extremely_detailed_lin;
}


double segmented_priors::get_overall_a_mu(void)
{
  return overall_a_mean;
}

double segmented_priors::get_overall_b_mu(void)
{
  return overall_b_mean;
}

double segmented_priors::get_overall_a_sd(void)
{
  return overall_a_sd;
}

double segmented_priors::get_overall_b_sd(void)
{
  return overall_b_sd;
}

double segmented_priors::get_overall_corr(void)
{
  return overall_corr;
}  

double segmented_priors::get_a_mu(int num_seg)
{
  return lin_m[num_seg-1][0];
}

double segmented_priors::get_b_mu(int num_seg, int seg)
{
  return lin_m[num_seg-1][seg];
}

double *segmented_priors::get_b_mu_vector(int num_seg)
{
  double *bmu=new double[num_seg];
  for(int i=0;i<num_seg;i++)
    bmu[i]=lin_m[num_seg-1][i+1];
  return bmu;
}

double segmented_priors::get_a_sd(int num_seg)
{
  return sqrt(lin_V[num_seg-1][0][0]);
}

double segmented_priors::get_b_sd(int num_seg, int seg)
{
  return sqrt(lin_V[num_seg-1][seg][seg]);
}

double *segmented_priors::get_b_sd_vector(int numseg)
{
  double *bsd=new double[numseg];
  for(int i=0;i<numseg;i++)
    bsd[i]=sqrt(lin_V[numseg-1][i+1][i+1]);
  return bsd;
}

double segmented_priors::get_cor(int numseg)
// will fetch from first correltation between a and b
{
  return lin_V[numseg-1][0][1]/
    sqrt(lin_V[numseg-1][0][0]*lin_V[numseg-1][1][1]);
}

double segmented_priors::get_cor(int numseg, 
					       int coefficient_index_1, 
					       int coefficient_index_2)
{
  return lin_V[numseg-1][coefficient_index_1][coefficient_index_2]/
    sqrt(lin_V[numseg-1][coefficient_index_1][coefficient_index_1]*
	 lin_V[numseg-1][coefficient_index_2][coefficient_index_2]);
}

bool segmented_priors::is_h0_detailed(void)
{
  return detailed_h0;
}

double segmented_priors::get_h01_mu(void)
{
  if(!detailed_h0)
    return mu_h01;
  else
    return MISSING_VALUE;
}

double segmented_priors::get_h01_sd(void)
{
  if(!detailed_h0)
    return sd_h01;
  else
    return MISSING_VALUE;
}

double segmented_priors::get_h02_mu(void)
{
  if(!detailed_h0)
    return mu_h02;
  else
    return MISSING_VALUE;
}

double segmented_priors::get_h02_sd(void)
{
  if(!detailed_h0)
    return sd_h02;
  else
    return MISSING_VALUE;
}

double segmented_priors::get_h01_max(void)
{
  if(!detailed_h0)
    return max_h01;
  else
    return MISSING_VALUE;
}

bool segmented_priors::get_lognormal_h01(void)
{
  if(!detailed_h0)
    return lognormal_h01;
  else
    return false;
}


double segmented_priors::get_h0_mu(int num_seg, int seg)
{
  if(detailed_h0 && mu_h0 && seg<=num_seg)
    return mu_h0[num_seg-1][seg-1];
  else
    return MISSING_VALUE;
}

double segmented_priors::get_h0_sd(int num_seg, int seg)
{
  if(detailed_h0 && mu_h0 && seg<=num_seg)
    return sd_h0[num_seg-1][seg-1];
  else
    return MISSING_VALUE;
}

bool segmented_priors::get_lognormal_h0(int num_seg, int seg)
{
  if(detailed_h0 && lognormal_h0 && seg<=num_seg)
    return lognormal_h0[num_seg-1][seg-1];
  else
    return false;
}


double segmented_priors::get_h0_max(int num_seg, int seg)
{
  if(detailed_h0 && max_h0 && seg<=num_seg)
    return max_h0[num_seg-1][seg-1];
  else
    return MISSING_VALUE;
}


bool segmented_priors::is_hs_detailed(void)
{
  return detailed_hs;
}

double segmented_priors::get_hs_mu(int num_seg, int seg)
{
  if(detailed_hs && mu_hs && num_seg>1 && seg<num_seg)
    return mu_hs[num_seg-1][seg-1];
  else
    return MISSING_VALUE;
}

double segmented_priors::get_hs_sd(int num_seg, int seg)
{
  if(detailed_hs && mu_hs && num_seg>1 && seg<num_seg)
    return sd_hs[num_seg-1][seg-1];
  else
    return MISSING_VALUE;
}


double segmented_priors::get_mu_q(void)
{
  return mu_q;
}

double segmented_priors::get_sd_q(void)
{
  return sd_q;
}

double segmented_priors::get_sigma_a(void)
{
  return sigma_a;
}

double segmented_priors::get_sigma_b(void)
{
  return sigma_b;
}

double segmented_priors::get_sigma_lower_cred(void)
{
  return sigma_lower;
}                  

double segmented_priors::get_sigma_upper_cred(void)
{
  return sigma_upper;
}

double segmented_priors::get_sigma_cred(void)
{
  return sigma_cred;
}

double segmented_priors::get_standard_mu_a(void)
{
  return standard_mu_a;
}

double segmented_priors::get_standard_mu_b(void)
{
  return standard_mu_b;
}

double segmented_priors::get_standard_sd_a(void)
{
  return standard_sd_a;
}

double segmented_priors::get_standard_sd_b(void)
{
  return standard_sd_b;
}

double segmented_priors::get_standard_cor(void)
{
  return standard_cor;
}

double segmented_priors::get_standard_sigma_a(void)
{
  return standard_sigma_a;
}

double segmented_priors::get_standard_sigma_b(void)
{
  return standard_sigma_b;
}

double segmented_priors::get_standard_sigma_lower_cred(void)
{
  return standard_sigma_lower_cred;
}

double segmented_priors::get_standard_sigma_upper_cred(void)
{
  return standard_sigma_upper_cred;
}

double segmented_priors::get_standard_sigma_credibility(void)
{
  return standard_sigma_cred;
}

double segmented_priors::get_standard_mu_q(void)
{
  return standard_mu_q;
}

double segmented_priors::get_standard_sd_q(void)
{
  return standard_sd_q;
}

double segmented_priors::get_standard_h01_mu(void)
{
  return standard_h01_mu;
}

double segmented_priors::get_standard_h01_sd(void)
{
  return standard_h01_sd;
}

double segmented_priors::get_standard_h02_mu(void)
{
  return standard_h02_mu;
}

double segmented_priors::get_standard_h02_sd(void)
{
  return standard_h02_sd;
}


int segmented_priors::get_max_seg(void)
{
  return max_num_seg;
}

int segmented_priors::get_min_seg(void)
{
  return min_num_seg;
}


int segmented_priors::num_internal_restrictions()
{
  return num_restr;
}

int segmented_priors::num_internal_lower_and_upper(void)
{
  return num_lower_and_upper;
}

double *segmented_priors::stage_internal_restrictions(void)
{
  return restr_stage;
}

double segmented_priors::stage_internal_restriction(int num)
{
  if(num>=0 && num<num_restr && restr_stage)
    return restr_stage[num];
  else 
    return MISSING_VALUE;
}

double *segmented_priors::logdischarge_lower_internal_restrictions(void)
{
  return restr_q_lower;
}

double segmented_priors::logdischarge_lower_internal_restriction(int num)
{
  if(num>=0 && num<num_restr && restr_q_lower)
    return restr_q_lower[num];
  else 
    return MISSING_VALUE;
}

double *segmented_priors::logdischarge_upper_internal_restrictions(void)
{
  return restr_q_upper;
}

double segmented_priors::logdischarge_upper_internal_restriction(int num)
{
  if(num>=0 && num<num_restr && restr_q_upper)
    return restr_q_upper[num];
  else 
    return MISSING_VALUE;
}

char **segmented_priors::restriction_comments(void)
{
  return restr_comment;
}

char *segmented_priors::restriction_comment(int num)
{
  if(num>=0 && num<num_restr && restr_comment)
    return restr_comment[num];
  else 
    return NULL;
}

int segmented_priors::num_extrapolation_restrictions()
{
  return num_extra;
}

int segmented_priors::num_extrapolation_lower_and_upper(void)
{
  return num_extra_lower_and_upper;
}

double *segmented_priors::stage_extrapolation_restrictions(void)
{
  return extra_stage;
}

double segmented_priors::stage_extrapolation_restriction(int num)
{
  if(num>=0 && num<num_extra && extra_stage)
    return extra_stage[num];
  else 
    return MISSING_VALUE;
}


double *segmented_priors::logdischarge_lower_extrapolation_restrictions(void)
{
  return extra_q_lower;
}

double segmented_priors::logdischarge_lower_extrapolation_restriction(int num)
{
  if(num>=0 && num<num_extra && extra_q_lower)
    return extra_q_lower[num];
  else 
    return MISSING_VALUE;
}

double *segmented_priors::logdischarge_upper_extrapolation_restrictions(void)
{
  return extra_q_upper;
}

double segmented_priors::logdischarge_upper_extrapolation_restriction(int num)
{
  if(num>=0 && num<num_extra && extra_q_upper)
    return extra_q_upper[num];
  else 
    return MISSING_VALUE;
}

char **segmented_priors::extrapolation_comments(void)
{
  return extra_comment;
}

char *segmented_priors::extrapolation_comment(int num)
{
  if(num>=0 && num<num_extra && extra_comment)
    return extra_comment[num];
  else 
    return NULL;
}

int segmented_priors::get_linear_dimensions(int num_seg)
{
  return num_seg+1;
}


double *segmented_priors::get_linear_mean(int num_seg)
{
  return lin_m[num_seg-1];
}

double **segmented_priors::get_linear_V(int num_seg)
{
  return lin_V[num_seg-1];
}


double segmented_priors::
loglikelihood_prior_linear_contrib(int numseg, double a1, double *b)
{
  int i,j,dim=numseg+1;
  double *beta=new double[dim];
  beta[0]=a1;
  for(j=0;j<numseg;j++)
    beta[j+1]=b[j];

  double contrib_pri_beta=-1e+200;
  if(numseg<=max_num_seg)
    contrib_pri_beta = multinormal_pdf(beta,lin_m[numseg-1],
				       lin_V[numseg-1],dim,true);
  else
    {
      // Model larger than the largest specified. Copy linear prior from largest model:
      double *newm=new double[dim], **newV=make_matrix(dim,dim);
      for(i=0;i<dim;i++)
	{
	  int ii=MINIM(i,max_num_seg);
	  newm[i]=lin_m[max_num_seg-1][ii];
	  for(j=0;j<dim;j++)
	    {
	      int jj=MINIM(j,max_num_seg);
	      int iii=MINIM(ii,jj),jjj=MAXIM(ii,jj);
	      newV[i][j]=lin_V[max_num_seg-1][iii][jjj];
	    }
	}
      
      contrib_pri_beta = multinormal_pdf(beta,newm,newV,dim,true);
      
      delete [] newm;
      doubledelete(newV,dim);
    }

  delete [] beta;
  
  return contrib_pri_beta;
}

double segmented_priors::
loglikelihood_prior_h0_contrib(int numseg, double *h0)
{
  double contrib_h0=0.0;

  if(!detailed_h0)
    {
      double contrib_h01=0.0;
      double contrib_h02=0.0; 
      
      for(int j=0;j<(numseg-1);j++)
	contrib_h02+=-0.5*log(2.0)-log(sd_h02)-
	  abs(h0[j+1]-h0[j]-mu_h02)*sqrt(2.0)/sd_h02;
	//contrib_h02+=-log(2.0*M_PI)-log(sd_h02)-0.5*(h0[j+1]-h0[j]-mu_h02)*
	//(h0[j+1]-h0[j]-mu_h02)/sd_h02/sd_h02;

      if(mu_h01!=MISSING_VALUE && sd_h01!=MISSING_VALUE)
	{
	  if(!lognormal_h01)
	    contrib_h01=-0.5*log(2.0*M_PI)-log(sd_h01) -
	      0.5*(h0[0]-mu_h01)*(h0[0]-mu_h01)/sd_h01/sd_h01;
	  else
	    contrib_h01=-0.5*log(2.0*M_PI)-log(sd_h01)-log(max_h01-h0[0])-
	      0.5*(log(max_h01-h0[0])-mu_h01)*(log(max_h01-h0[0])-mu_h01)/sd_h01/sd_h01;
	}
      contrib_h0=contrib_h01+contrib_h02;
    }
  else
    {
      for(int i=0;i<numseg;i++)
	{
	  int ii=MINIM(i,max_num_seg);
	  int ns=MINIM(numseg,max_num_seg);

	  if(!lognormal_h0 || !lognormal_h0[ns-1] || 
	     !lognormal_h0[ns-1][ii] || !max_h0 || !max_h0[ns-1] || 
	     max_h0[ns-1][ii]==MISSING_VALUE)
	    contrib_h0+=
	      -0.5*log(2*M_PI)-log(sd_h0[ns-1][ii])-
	      0.5*(h0[i]-mu_h0[ns-1][ii])*
	      (h0[i]-mu_h0[ns-1][ii])/
	      sd_h0[ns-1][ii]/sd_h0[ns-1][ii];
	  else
	    contrib_h0+=
	      -0.5*log(2*M_PI)-log(sd_h0[ns-1][ii])-
	      log(max_h0[ns-1][ii]-h0[i])-
	      0.5*(log(max_h0[ns-1][ii]-h0[i])-mu_h0[ns-1][ii])*
	      (log(max_h0[ns-1][ii]-h0[i])-mu_h0[ns-1][ii])/
	      sd_h0[ns-1][ii]/sd_h0[ns-1][ii];
	}
    }
  
  return contrib_h0;
}

double segmented_priors::
loglikelihood_prior_hs_contrib(int numseg, double *hs, 
			       double a1, double *b, double *h0)
{
  double contrib_hs=0.0;
  int j;
  
  if(numseg>1)
    {
      if(!detailed_hs)
	{
	  double *a=new double[numseg];
	  a[0]=a1;
	  for(j=1;j<numseg;j++)
	    a[j]=a[j-1]+b[j-1]*log(hs[j-1]-h0[j-1])-b[j]*log(hs[j-1]-h0[j]);
	  
	  for(j=0;j<(numseg-1);j++)
	    contrib_hs += -ABSVAL((hs[j]-h0[j]))+
	      log(ABSVAL(b[j]))-0.5*log(2.0*M_PI*sd_q*sd_q)-
              0.5*(a[j]+b[j]*log(hs[j]-h0[j])-mu_q)*
	      (a[j]+b[j]*log(hs[j]-h0[j])-mu_q) / (sd_q*sd_q);
	  
	  delete [] a;
	}
      else
	{
	  for(j=0;j<(numseg-1);j++)
	    {	      
	      int jj=MINIM(j,max_num_seg);
	      int ns=MINIM(numseg,max_num_seg);
	      
	      contrib_hs+=(-0.5*log(2.0*M_PI*sd_hs[ns-1][jj]*
				    sd_hs[ns-1][jj]) - 
			   0.5*(hs[j]-mu_hs[ns-1][jj])*
			   (hs[j]-mu_hs[ns-1][jj])/
			   (sd_hs[ns-1][jj]*sd_hs[ns-1][jj]));
	    }
	}
    }

  return contrib_hs;
}

double segmented_priors::
loglikelihood_prior_sigma_contrib(double s2)
{
  double contrib_s2 = - (sigma_a+1.0)*log(s2) - sigma_b/s2 + 
    sigma_a*log(sigma_b) - lgamma(sigma_a);
  
  return contrib_s2;
}

double segmented_priors::
loglikelihood_prior_contrib(int numseg, double a1, double *b, 
			    double *h0, double *hs, double s2)
{
  double contrib_beta=loglikelihood_prior_linear_contrib(numseg,a1,b);
  double contrib_h0=loglikelihood_prior_h0_contrib(numseg,h0);
  double contrib_hs=loglikelihood_prior_hs_contrib(numseg,hs,a1,b,h0);
  double contrib_s2=loglikelihood_prior_sigma_contrib(s2);
  
  double contrib_prior=contrib_beta+contrib_h0+contrib_hs+contrib_s2;
  
  return contrib_prior;
}

void segmented_priors::print(void)
{
  int i,j,k;
  
  printf("Minimum #segments: %d\n", min_num_seg);
  printf("Maximum #segments: %d\n", max_num_seg);
  for(i=0;i<max_num_seg;i++)
    printf("Prob. for %d segment(s): %f\n", i+1, prob_model[i]);
  printf("\n");
  if(!detailed_lin)
    {
      printf("Non-detailed info on linear parameters\n");
      printf("mu_a:%f sd_a=%f\n", lin_m[0][0], sqrt(lin_V[0][0][0]));
      for(i=1;i<max_num_seg;i++)
	{
	  if(!almost_equal(lin_m[i][0], lin_m[0][0]))
	    printf("Inconsistent mu_a: mu_a(1)=%f mu_a(%d)=%f\n",
		   lin_m[0][0], i+1, lin_m[i][0]);
	  if(!almost_equal(lin_V[0][0][0], lin_V[i][0][0]))
	    printf("Inconsistent sd_a: sd_a(1)=%f sd_a(%d)=%f\n",
		   sqrt(lin_V[0][0][0]), i+1, sqrt(lin_V[i][0][0]));
	}
      
      printf("mu_b:%f sd_b=%f\n", lin_m[0][1], sqrt(lin_V[0][1][1]));
      for(i=1;i<max_num_seg;i++)
	for(j=1;j<=(i+1);j++)
	  {
	    if(!almost_equal(lin_m[0][1], lin_m[i][j]))
	      printf("Inconsistent mu_b: mu_b(1,1)=%f mu_b(%d,%d)=%f\n",
		     lin_m[0][1], i+1, j, lin_m[i][j]);
	    if(!almost_equal(lin_V[0][1][1], lin_V[i][j][j]))
	      printf("Inconsistent sd_a: sd_b(1,1)=%f sd_b(%d,%d)=%f\n",
		     sqrt(lin_V[0][1][1]), i+1, j, sqrt(lin_V[i][j][j]));
	  }

      double corr=lin_V[0][0][1]/sqrt(lin_V[0][0][0]*lin_V[0][1][1]);
      printf("corr=%f\n", corr);
      for(i=0;i<max_num_seg;i++)
	for(j=1;j<=(i+1);j++)
	  {
	    double corr2=lin_V[i][0][j]/sqrt(lin_V[i][0][0]*lin_V[i][j][j]);
	    if(!almost_equal(corr,corr2))
	      {
		printf("Inconsistent corr: corr(1,0,1)=%f corr(%d,0,%d)=%f\n",
		       corr, i+1, j, corr2);
	      }
	    for(k=1;k<j;k++)
	      {
		double corr3=lin_V[i][j][k]/
		  sqrt(lin_V[i][j][j]*lin_V[i][k][k]);
		if(!almost_equal(corr*corr,corr3))
		  {
		    printf("Inconsistent corr�: corr(1,0,1)=%f "
			   "corr(%d,%d,%d)=%f\n",
			   corr, i+1, j, k, corr3);
		  }
	      }
	  }
    }
  else // detailed lin
    {
      printf("Detailed specification of linear parameters\n");
      for(i=0;i<max_num_seg;i++)
	{
	  printf("%d Segments:\n", i+1);
	  printf("m= \n");
	  for(j=0;j<dim[i];j++)
	    printf("%f ", lin_m[i][j]);
	  printf("\n");
	  for(j=0;j<dim[i];j++)
	    {
	      printf("V(row %d)= ", j+1);
	      for(k=0;k<dim[i];k++)
		printf("%f ", lin_V[i][j][k]);
	      printf("\n");
	    }
	}
    }
  printf("\n");

  if(!detailed_h0)
    {
      printf("Non-detailed h0:\n");
      printf("mu_h01=%f, sd_h01=%f\n", mu_h01, sd_h01);
      printf("mu_h02=%f, sd_h02=%f\n", mu_h02, sd_h02);
      if(lognormal_h01)
	printf("h01 is lognormally distributed with maximum=%f\n", 
	       max_h01);
    }
  else
    {
      printf("Detailed h0:\n");
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  {
	    printf("model %d, seg. %d: mu=%f sd=%f\n",
		   i+1, j+1, mu_h0[i][j], sd_h0[i][j]);
	    if(lognormal_h0 && lognormal_h0[i] && lognormal_h0[i][j] &&
	       max_h0 && max_h0[i] && max_h0[i][j]!=MISSING_VALUE)
	      printf("  h0 is lognormally distributed with maximum=%f\n", 
		     max_h0[i][j]);
	  }
    }
  printf("\n");

  if(!detailed_hs)
    {
      printf("Non-detailed hs:\n");
      printf("mu_q=%f, sd_q=%f\n", mu_q, sd_q);
    }
  else
    {
      printf("Detailed hs:\n");
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<i;j++)
	  printf("model %d, seg. %d: mu=%f sd=%f\n",
		 i+1, j+1, mu_hs[i][j], sd_hs[i][j]);
    }
  printf("\n");

  printf("Sigma�: alpha=%f beta=%f\n", sigma_a, sigma_b);  
}


bool segmented_priors::
curve_adheres_to_extrapolation_restrictions(segmented_curve *curve)
{
  int i;
  
  if(num_extra<=0)
    return true;

  for(i=0;i<num_extra;i++)
    {
      double Q=curve->get_discharge(extra_stage[i]), 
	Q1=extra_q_lower[i]==MISSING_VALUE ? MISSING_VALUE : exp(extra_q_lower[i]),
	Q2=extra_q_upper[i]==MISSING_VALUE ? MISSING_VALUE : exp(extra_q_upper[i]);
      if(!(Q1==MISSING_VALUE || Q>Q1) || !(Q2==MISSING_VALUE || Q<Q2))
	return false;
    }
  
  return true;
}

char *segmented_priors::describe_prior(void)
{
  int i,j,k;
  char *str=new char[30000];
  strcpy(str,"");

  sprintf(str+strlen(str),"Minimum #segments: %d\n", min_num_seg);
  sprintf(str+strlen(str),"Maximum #segments: %d\n", max_num_seg);
  for(i=0;i<max_num_seg;i++)
    sprintf(str+strlen(str),"Prob. for %d segment(s): %f\n", 
	    i+1, prob_model[i]);
  sprintf(str+strlen(str),"\n");
  if(extremely_detailed_lin)
    {
      sprintf(str+strlen(str),"Extremely detailed specification "
	      "of linear parameters\n");
      for(i=0;i<max_num_seg;i++)
	{
	  sprintf(str+strlen(str),"%d Segments:\n", i+1);
	  sprintf(str+strlen(str),"m= \n");
	  for(j=0;j<dim[i ];j++)
	    sprintf(str+strlen(str),"%f ", lin_m[i][j]);
	  sprintf(str+strlen(str),"\n");
	  for(j=0;j<dim[i];j++)
	    {
	      sprintf(str+strlen(str),"V(row %d)= ", j+1);
	      for(k=0;k<dim[i];k++)
		sprintf(str+strlen(str),"%f ", lin_V[i][j][k]);
	      sprintf(str+strlen(str),"\n");
	    }
	}
      sprintf(str+strlen(str),"\n");
    }
  else if(detailed_lin)
    {
      sprintf(str+strlen(str),"Detailed specification of linear parameters\n");
      for(i=0;i<max_num_seg;i++)
	{
	  sprintf(str+strlen(str),"%d Segments:\n", i+1);
	  sprintf(str+strlen(str),"mu_a=%f, sd_a=%f\n", 
		  lin_m[i][0], lin_a_sd[i]);
	  for(j=0;j<=i;j++)
	    sprintf(str+strlen(str),"mu_b=%f, sd_b=%f\n", 
		  lin_m[i][1+j], lin_b_sd[i][j]);
	  sprintf(str+strlen(str),"corr=%f\n", lin_corr[i]);
	}
      sprintf(str+strlen(str),"\n");
    }
  else
    {
      sprintf(str+strlen(str),"Non-detailed linear parameters:\n");
      sprintf(str+strlen(str),"mu_a=%f, sd_a=%f\n", overall_a_mean, overall_a_sd);
      sprintf(str+strlen(str),"mu_b=%f, sd_b=%f\n", overall_b_mean, overall_b_sd);
      sprintf(str+strlen(str),"corr=%f\n", overall_corr);
    }

  if(!detailed_h0)
    {
      sprintf(str+strlen(str),"Non-detailed h0:\n");
      sprintf(str+strlen(str),"mu_h01=%f, sd_h01=%f\n", mu_h01, sd_h01);
      sprintf(str+strlen(str),"mu_h02=%f, sd_h02=%f\n", mu_h02, sd_h02);
      if(lognormal_h01)
	sprintf(str+strlen(str),"h01 is lognormally distributed with maximum=%f\n", 
		max_h01);
    }
  else
    {
      sprintf(str+strlen(str),"Detailed h0:\n");
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<=i;j++)
	  {
	    sprintf(str+strlen(str),"model %d, seg. %d: mu=%f sd=%f\n",
		    i+1, j+1, mu_h0[i][j], sd_h0[i][j]);
	    if(lognormal_h0 && lognormal_h0[i] && lognormal_h0[i][j] &&
	       max_h0 && max_h0[i] && max_h0[i][j]!=MISSING_VALUE)
	      sprintf(str+strlen(str),"  h0 is lognormally distributed with maximum=%f\n", 
		      max_h0[i][j]);
	  }
    }
  sprintf(str+strlen(str),"\n");

  if(!detailed_hs)
    {
      sprintf(str+strlen(str),"Non-detailed hs:\n");
      sprintf(str+strlen(str),"mu_q=%f, sd_q=%f\n", mu_q, sd_q);
    }
  else
    {
      sprintf(str+strlen(str),"Detailed hs:\n");
      for(i=0;i<max_num_seg;i++)
	for(j=0;j<i;j++)
	  sprintf(str+strlen(str),"model %d, seg. %d: mu=%f sd=%f\n",
		 i+1, j+1, mu_hs[i][j], sd_hs[i][j]);
    }
  sprintf(str+strlen(str),"\n");

  sprintf(str+strlen(str),"Sigma�: alpha=%f beta=%f\n", sigma_a, sigma_b);  

  return str;
}

