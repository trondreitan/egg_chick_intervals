/*
 * $Id: bayes_generate_ratingcurve.C 2572 2015-10-19 14:41:56Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/bayes_generate_ratingcurve.C $
 */

#include <hydrasub/hydrabase/bayes_generate_ratingcurve.H>
#include <cmath>
#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/linalg.H>

// ********************************************
//
//           BAYES_MCMC_RATINGCURVE
//
// A module for generating a discharge rating
// curve using Bayesian statistics and
// Markov Chain Monte Carlo (MCMC) 
// simulations. The Bayesian model has a
// non-informative prior for the non-linear
// model (default) and a semi-conjugate
// prior (prior knowledge of regression 
// coefficients and noise is independent) for 
// the linear parameters. 
//
// The specific MCMC method used, works as
// follows: 
// First the non-linear parameter is drawn
// for discrete choices and the rest of the
// paramete3rs is drawn using Gibbs method.
// The maximal probability is  found and the 
// corresponding non-linear parameters is 
// chosen as the start of the Markov Chain.
// A prliminary run using Random Walk
// Metrpolois is then run, while the step
// length is adjusted so that the accepance
// probability is approximately 0.25. Then
// further RW Metrpolois drawings are done,
// and the mean and standard deviation of 
// the non-linear parameter is found from
// that batch. An independence sampler
// for the non-linear parameter is then
// constructed with a Normal distribtution
// with the found mean and standard deviation
// as the proposal distribution. 
//
//           Trond Reitan, 3/10-2006
//
// ********************************************



void bayes_mcmc_ratingcurve::init(void)
{
  num_meas=0;
  q=NULL;
  h=NULL;
  
  a_m=2.5;
  a_s=0.6950;
  b_m=2.5976;
  b_s=0.9059;
  ab_corr=-0.2;

  sampled_a=NULL;
  sampled_b=NULL;
  sampled_c=NULL;
  sampled_s2=NULL;
  sampled_logprob=NULL;
  num_samples=0;
  
  qsample=NULL;
  stage_of_qsample=MISSING_VALUE;
  hsample=NULL;
  discharge_of_hsample=MISSING_VALUE;

  var=NULL;
  inv_var=NULL;

  a_mean=MISSING_VALUE;
  b_mean=MISSING_VALUE;
  c_mean=MISSING_VALUE;
  s2_mean=MISSING_VALUE;
  a_median=MISSING_VALUE;
  b_median=MISSING_VALUE;
  c_median=MISSING_VALUE;
  s2_median=MISSING_VALUE;

  sd_c=0.2;
}

void bayes_mcmc_ratingcurve::cleanup(void)
{
  if(sampled_a)
    delete [] sampled_a;
  if(sampled_b)
    delete [] sampled_b;
  if(sampled_c) 
    delete [] sampled_c;
  if(sampled_s2)
    delete [] sampled_s2;
  if(sampled_logprob)
    delete [] sampled_logprob;
  if(qsample)
    delete [] qsample;
  if(hsample)
    delete [] hsample;
  if(q)
    delete [] q;
  if(h)
    delete [] h;
  if(var)
    doubledelete(var,2);
  if(inv_var)
  doubledelete(inv_var,2); 

  init();
}


double bayes_mcmc_ratingcurve::logprob_no_s(double a, double b, double c, 
					    double **inv_var)
{
  // contrubtion from (beta-m)V^(-1)(beta-m);
  double contrib_pri_beta = - 0.5*
    ((a-a_m)*(a-a_m)*inv_var[0][0]+(a-a_m)*(b-b_m)*
     (inv_var[0][1]+inv_var[1][0])+(b-b_m)*(b-b_m)*inv_var[1][1]);
  
  double SS=0.0;
  for(int i=0;i<num_meas;i++)
    SS+=(log(q[i])-a-b*log(h[i]+c))*(log(q[i])-a-b*log(h[i]+c));
  
  double loglik=-(sigma_a+1.0+double(num_meas)/2.0)*log(sigma_b+0.5*SS);
  /* I'm not sure if '+1.0' should be there. */

  double logc=0.0;
  if(c_prior==BAYES_RATINGCURVE_C_SCALE)
    {
      double hmin=find_statistics(h,num_meas, MIN);
      logc-=log(hmin+c);
    }
  else if(c_prior==BAYES_RATINGCURVE_C_NORMAL &&
	  c_m!=MISSING_VALUE && c_s!=MISSING_VALUE)
    logc-=(c-c_m)*(c-c_m)/2.0/c_s/c_s+0.5*log(2.0*M_PI)+log(c_s);
  
  return contrib_pri_beta+loglik+logc;
}

double bayes_mcmc_ratingcurve::logprob(double a, double b, double c, double s, 
				       double **inv_var)
{
  if(s<0.0)
    return -1e+216;

  // contrubtion from (beta-m)V^(-1)(beta-m);
  double contrib_pri_beta = - 0.5*
    ((a-a_m)*(a-a_m)*inv_var[0][0]+(a-a_m)*(b-b_m)*
     (inv_var[0][1]+inv_var[1][0])+(b-b_m)*(b-b_m)*inv_var[1][1]);
  
  // contribution from (sigma�)^-(a+2+n/2)*exp(-b/sigma�)
   double contrib_s2 = - (sigma_a+1.0+0.5*num_meas)*log(s) - sigma_b/s;
   
   double SS=0.0;
  // contribution from the exponensial data part of the likelihood function;
  for(int i=0;i<num_meas;i++)
    if(h[i]+c<0.0)
      return -1e+216;
    else
      SS+=(log(q[i])-a-b*log(h[i]+c))*(log(q[i])-a-b*log(h[i]+c));
  
  double ret=contrib_pri_beta+contrib_s2 - SS/2.0/s;

  if(c_prior==BAYES_RATINGCURVE_C_SCALE)
    {
      double hmin=find_statistics(h,num_meas, MIN);
      ret-=log(hmin+c);
    }
  else if(c_prior==BAYES_RATINGCURVE_C_NORMAL &&
	  c_m!=MISSING_VALUE && c_s!=MISSING_VALUE)
    ret-=(c-c_m)*(c-c_m)/2.0/c_s/c_s;
  
  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;

  return ret;
}


double bayes_mcmc_ratingcurve::get_proposal_logdensity(double prop_a, double prop_b, 
						       double prop_c, double prop_s2,
						       double m_c, double sd_c, 
						       double *m, double **V, 
						       double prev_s2)
{
  double ret=0.0;
  double **XtX=new double*[2], **V_star, **inv_V_star=new double*[2], 
    **inv_V;
  double *Y=new double[num_meas];
  int i,j;
  
  for(i=0;i<num_meas;i++)
    Y[i]=log(q[i]);
  
  inv_V=inverse_matrix(V,2);
  
  XtX[0]=new double[2];
  XtX[1]=new double[2];
  inv_V_star[0]=new double[2];
  inv_V_star[1]=new double[2];
  XtX[0][0]=XtX[1][0]=XtX[0][1]=XtX[1][1]=0.0;
  
  for(i=0;i<num_meas;i++)
    {
      XtX[0][0]++;
      XtX[0][1]+=log(h[i]+prop_c);
      XtX[1][0]+=log(h[i]+prop_c);
      XtX[1][1]+=log(h[i]+prop_c)*log(h[i]+prop_c);
    }
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      inv_V_star[i][j]=inv_V[i][j]+XtX[i][j]/prev_s2;

  V_star=inverse_matrix(inv_V_star,2);
  
  
  double m_star_raw[2], m_star[2];
  
  
  for(i=0;i<2;i++)
    m_star_raw[i]=m_star[i]=0.0;
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      m_star_raw[i]+=inv_V[i][j]*m[j];
  for(i=0;i<num_meas;i++)
    {
      m_star_raw[0]+=Y[i]/prev_s2;
      m_star_raw[1]+=Y[i]*log(h[i]+prop_c)/prev_s2;
    }
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      m_star[i]+=V_star[i][j]*m_star_raw[j];
  
  
  double x[2]={prop_a, prop_b};

  ret=multinormal_pdf(x,m_star,V_star,2,true);
  
  ret += -0.5*log(2.0*M_PI) - log(sd_c) - 0.5*(prop_c-m_c)*(prop_c-m_c)/sd_c/sd_c;


  double sigma_a_star=sigma_a + 0.5*double(num_meas);
  double sigma_b_star=sigma_b;

  for(i=0;i<num_meas;i++)
    sigma_b_star+=0.5*(Y[i]-prop_a-prop_b*log(h[i]+prop_c))*
      (Y[i]-prop_a-prop_b*log(h[i]+prop_c));
  
  ret+=sigma_a_star*log(sigma_b_star)-lgamma(sigma_a_star)-
    (sigma_a_star+1.0)*log(prop_s2)-sigma_b_star/prop_s2;

  delete [] Y;
  doubledelete(inv_V,2);
  doubledelete(XtX,2);
  doubledelete(V_star,2);
  doubledelete(inv_V_star,2);

  return ret;
}

// Samples first the linear regression  coefficients given
// the non_linear part and sigma^2. Also samples s^2
// given the samples linear coefficients.
void bayes_mcmc_ratingcurve::gibbs_sample(double *m, double **V,
					  double c, gsl_rng *rptr, 
					  double prev_s2, double *a, 
					  double *b, double *s2)
{
  double **XtX=new double*[2], **V_star, **inv_V_star=new double*[2], 
    **inv_V;
  double *Y=new double[num_meas];
  int i,j;

  for(i=0;i<num_meas;i++)
    Y[i]=log(q[i]);

  inv_V=inverse_matrix(V,2);
  
  XtX[0]=new double[2];
  XtX[1]=new double[2];
  inv_V_star[0]=new double[2];
  inv_V_star[1]=new double[2];
  XtX[0][0]=XtX[1][0]=XtX[0][1]=XtX[1][1]=0.0;

  for(i=0;i<num_meas;i++)
    {
      XtX[0][0]++;
      XtX[0][1]+=log(h[i]+c);
      XtX[1][0]+=log(h[i]+c);
      XtX[1][1]+=log(h[i]+c)*log(h[i]+c);
    }
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      inv_V_star[i][j]=inv_V[i][j]+XtX[i][j]/prev_s2;

  V_star=inverse_matrix(inv_V_star,2);
  
  double m_star_raw[2], m_star[2];
  
  for(i=0;i<2;i++)
    m_star_raw[i]=m_star[i]=0.0;
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      m_star_raw[i]+=inv_V[i][j]*m[j];
  for(i=0;i<num_meas;i++)
    {
      m_star_raw[0]+=Y[i]/prev_s2;
      m_star_raw[1]+=Y[i]*log(h[i]+c)/prev_s2;
    }
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      m_star[i]+=V_star[i][j]*m_star_raw[j];

  double **sample=sample_from_multinormal(1,m_star,V_star,2,rptr);
  double a_=sample[0][0];
  double b_=sample[0][1];
  
  doubledelete(sample,1);
  doubledelete(inv_V,2);
  doubledelete(XtX,2);
  doubledelete(V_star,2);
  doubledelete(inv_V_star,2);
  
  if(a)
    *a=a_;
  if(b)
    *b=b_;
  
  double sigma_a_star=sigma_a + 0.5*double(num_meas);
  double sigma_b_star=sigma_b;
  double prev_a=a_;
  double prev_b=b_;

  for(i=0;i<num_meas;i++)
    sigma_b_star+=0.5*(Y[i]-prev_a-prev_b*log(h[i]+c))*
      (Y[i]-prev_a-prev_b*log(h[i]+c));
  
  if(s2)
    *s2=1.0/gsl_ran_gamma(rptr, sigma_a_star, 1.0/sigma_b_star);
  
  delete [] Y;
  
  return;
}

 

bayes_mcmc_ratingcurve::bayes_mcmc_ratingcurve()
{
  init();
}

bayes_mcmc_ratingcurve::~bayes_mcmc_ratingcurve()
{
  cleanup();
}

void bayes_mcmc_ratingcurve::draw_parameters(double *stage, double *discharge, 
					     int number_of_measurements, 
					     // measurements
		     
					     // Optional input::
		     
					     int num_sim, 
					     // number of drawings
					     
					     // prior knowledge:
					     double est_exp, 
					     double sdev_exp, 
					     double est_logconst, 
					     double sdev_logconst,
					     double prior_a_b_correlation,
					     double sigma_a_, 
					     double sigma_b_, 
					     BAYES_RATINGCURVE_C_PRIOR cprior,
					     double c_mean_, double c_sdev_,

					     int brute_number, 
					     // number of discrete simulation
					     // at the start 
		     
					     int indep, 
					     /* spacing between drawings */
					     
					     int burnin, 
					     /* burn-in length */
					     
					     int random_met, 
					     /* RW length */
					     
					     int random_met_burnin 
					     /* RW burn-in length */
					     )
{
  int i;

  cleanup();

  num_samples=num_sim;

  // Store the measurements:
  num_meas=number_of_measurements;
  if(num_meas>0)
    {
      q=new double[num_meas];
      h=new double[num_meas];
      for(i=0;i<num_meas;i++)
	{
	  q[i]=discharge[i];
	  h[i]=stage[i];
	}
    }

  // Store the priors:
  a_m=est_logconst;
  a_s=sdev_logconst;
  b_m=est_exp;
  b_s=sdev_exp;
  c_m=c_mean_;
  c_s=c_sdev_;
  c_prior=cprior;
  ab_corr=prior_a_b_correlation;
  sigma_a=sigma_a_;
  sigma_b=sigma_b_;
  
  
  double *a=new double[random_met+num_sim*indep+burnin];
  double *b=new double[random_met+num_sim*indep+burnin];
  double *c=new double[random_met+num_sim*indep+burnin];
  double *s=new double[random_met+num_sim*indep+burnin];
  double *psi=new double[random_met+num_sim*indep+burnin];

  double *m=new double[2];
  double minh=num_meas>0 ? find_statistics(h,num_meas,MIN) : MISSING_VALUE;
  double prev_logprob;
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  double prev_s2=sigma_a>0.0 ? 1.0/gsl_ran_gamma(rptr,sigma_a,1.0/sigma_b):
    1.0e+5*drand48();
  
  // prior mean vector and variance matrix for the parameters (a,b)
  var=new double*[2];
  var[0]=new double[2];
  var[1]=new double[2];
  m[0]=est_logconst;
  m[1]=est_exp;
  var[0][0]=sdev_logconst*sdev_logconst;
  var[1][1]=sdev_exp*sdev_exp;
  var[0][1]=var[1][0]=ab_corr*sqrt(var[0][0]*var[1][1]);
  inv_var=inverse_matrix(var,2);

  // Brute force approach to get a good start as for
  // the proposal distribution
  double new_a, new_b, new_c, new_s2;
  double old_a, old_b, old_c, old_s2;
  double best_a, best_b, best_c, best_s2;
  double new_logprop, best_logprop;

  // fetch a first sample:
  if(num_meas<=0)
    old_c=c_m+c_s*gauss();
  else
    {
      old_c=-minh+-minh+2.0+2.0*gauss();
      while(minh+old_c<0.0)
	old_c=-minh+2.0+2.0*gauss(); // gsl_ran_gaussian(rptr, 2.0);
    }
  gibbs_sample(m, var, old_c, rptr, prev_s2, &old_a, &old_b, &old_s2);
  best_s2=old_s2;
  best_a=old_a;
  best_b=old_b;
  best_c=old_c;
  best_logprop=MISSING_VALUE;
  // go through th routine a couple of times, accepting everything,
  // but check which is best:
  for(i=0;i<brute_number;i++)
    {
      if(num_meas<=0)
	new_c=c_m+c_s*gauss();
      else
	{
	  new_c=-minh+2.0+2.0*gauss(); // gsl_ran_gaussian(rptr, 2.0);
	  while(minh+new_c<0.0)
	    new_c=-minh+2.0+2.0*gauss(); // gsl_ran_gaussian(rptr, 2.0);
	}
      
      gibbs_sample(m, var, new_c, rptr, old_s2, &new_a, &new_b, &new_s2);
      
      new_logprop=get_proposal_logdensity(new_a, new_b, new_c, new_s2,
					  old_c, 0.05, m, var, best_s2);
      
      if(best_logprop==MISSING_VALUE || new_logprop>best_logprop)
	{
	  best_logprop=new_logprop;
	  best_a=new_a;
	  best_b=new_b;
	  best_c=new_c;
	  best_s2=new_s2;
	}
      
      old_a=new_a;
      old_b=new_b;
      old_c=new_c;
      old_s2=new_s2;
    }
  

  // Start with the best sample so far;
  a[0]=best_a;
  b[0]=best_b;
  c[0]=best_c;
  s[0]=best_s2;
  prev_logprob=logprob(a[0],b[0],c[0],s[0], inv_var);
  psi[0]=prev_logprob;
  
  acc_rate=0.0;
  double sdev_indep, mean_indep;
  
  // MCMC-sampling:
  for(i=1;i<random_met+num_sim*indep+burnin;i++)
    {
      double new_c;
      
      // update sd_c during burn-in (adaptive random walk):
      if(i%30==0 && i<random_met_burnin)
	{
	  acc_rate/=double(30);
	  sd_c*=exp((acc_rate-0.33)*2.0);
	  acc_rate=0.0;
	}

      // Fetch statistics used later on in indepencence sampler?
      if(i==random_met)
	{
	  mean_indep=find_statistics(c+random_met_burnin, 
				     random_met-random_met_burnin, MEAN);
	  sdev_indep=find_statistics(c+random_met_burnin,  
				     random_met-random_met_burnin, 
				     STANDARD_DEVIATION);
	}

      // Sample new coefficients; 
      if(i<random_met)
	new_c=c[i-1]+gsl_ran_gaussian(rptr, sd_c);
      else
	new_c=mean_indep+gsl_ran_gaussian(rptr, sdev_indep);
      
      if(new_c+minh>0.0)
	{
	  double prev_logprop, new_logprob;
	  
	  // fetch gibbs sample and proposal density for next choice:
	  gibbs_sample(m, var, new_c, rptr, s[i-1], &new_a, &new_b, &new_s2);

	  new_logprob=logprob(new_a, new_b, new_c, new_s2, inv_var);

	  
	  new_logprop=get_proposal_logdensity(new_a, new_b, new_c, new_s2,
                          (i<random_met ? c[i-1] : mean_indep),
                          (i<random_met ? sd_c : sdev_indep),
					      m, var, s[i-1]);
	  prev_logprop=get_proposal_logdensity(a[i-1], b[i-1], c[i-1], s[i-1],
                               (i<random_met ? new_c : mean_indep),
                               (i<random_met ? sd_c : sdev_indep),
					       m, var, new_s2);
	  
	  // accept or reject the proposed parameter set?
	  if(log(drand48())< new_logprob-prev_logprob - 
	     new_logprop+prev_logprop)
	    {
	      // accept, store the proposed parameters
	      a[i]=new_a;
	      b[i]=new_b;
	      c[i]=new_c;
	      s[i]=new_s2;
	      
	      prev_logprob=new_logprob;
	      
	      if(i>random_met || i<random_met_burnin)
		acc_rate++;
	    }
	  else
	    {
	      // reject, copy the old parameter values:
	      a[i]=a[i-1];
	      b[i]=b[i-1];
	      c[i]=c[i-1];
	      s[i]=s[i-1];
	    }
	}
      else
	{
	  // reject, copy the old parameter values:
	  a[i]=a[i-1];
	  b[i]=b[i-1];
	  c[i]=c[i-1];
	  s[i]=s[i-1];
	}

      psi[i]=prev_logprob;
    }

  // update the acceptance rate
  acc_rate/=double(num_sim*indep);
  //cout << "Acceptance rate:" << acc_rate << endl;
  
  // Store each indep'th sample after burn-in:
  sampled_a=new double[num_sim];
  sampled_b=new double[num_sim];
  sampled_c=new double[num_sim];
  sampled_s2=new double[num_sim];
  sampled_logprob=new double[num_sim];
  
  for(i=0;i<num_sim;i++)
    {
      sampled_a[i]=a[random_met+i*indep+burnin];
      sampled_b[i]=b[random_met+i*indep+burnin];
      sampled_c[i]=c[random_met+i*indep+burnin];
      sampled_s2[i]=s[random_met+i*indep+burnin];
      sampled_logprob[i]=psi[random_met+i*indep+burnin];
    }
  
  // Store some statistics about each parameter:
  a_mean=find_statistics(sampled_a,num_sim,MEAN);
  a_median=find_statistics(sampled_a,num_sim,MEDIAN);
  b_mean=find_statistics(sampled_b,num_sim,MEAN);
  b_median=find_statistics(sampled_b,num_sim,MEDIAN);
  c_mean=find_statistics(sampled_c,num_sim,MEAN);
  c_median=find_statistics(sampled_c,num_sim,MEDIAN);
  s2_mean=find_statistics(sampled_s2,num_sim,MEAN);
  s2_median=find_statistics(sampled_s2,num_sim,MEDIAN);
  
  // cleanup:
  delete [] a;
  delete [] b;
  delete [] c;
  delete [] s;
  delete [] psi;
  delete [] m;

}

int bayes_mcmc_ratingcurve::get_number_of_drawings(void)
{
  return num_samples;
}

// Get drawings of the linear parameter a=log(constant)
// in Q(h)=constant*(h+c)^b
double *bayes_mcmc_ratingcurve::get_sampled_a(void)
{
  return sampled_a;
}

// Get drawings of the linar parameter b;
double *bayes_mcmc_ratingcurve::get_sampled_b(void)
{
  return sampled_b;
}

// Get drawings of the non-linear parameter c;
double *bayes_mcmc_ratingcurve::get_sampled_c(void)
{
  return sampled_c;
}

// Get drawings of the noise term s�:
double *bayes_mcmc_ratingcurve::get_sampled_sigma_squared(void)
{
  return sampled_s2;
}

  // Get the log(probability) (up to a scale factor)
  // of the drawings:
double *bayes_mcmc_ratingcurve::get_sampled_logprob(void)
{
  return sampled_logprob;
}


  
// Fetch measurement data used;
int bayes_mcmc_ratingcurve::get_number_of_measurements(void)
{
  return num_meas;
}

double *bayes_mcmc_ratingcurve::get_stage_measurements(void)
{
  return h;
}

double *bayes_mcmc_ratingcurve::get_discharge_measurements(void)
{
  return q;
}


// Fetches a sorted array of discharge drawings from
// the parameter drawings for a given stage value;
double *bayes_mcmc_ratingcurve::get_discharge_sample(double stage)
{
  if(qsample)
    delete [] qsample;

  qsample=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    if(stage+sampled_c[i]>0.0)
      qsample[i]=exp(sampled_a[i])*pow(stage+sampled_c[i],sampled_b[i]);
    else
      qsample[i]=0.0;

  qsort(qsample, size_t(num_samples), sizeof(double), compare_double);
  stage_of_qsample=stage;

  return qsample;
}

double *bayes_mcmc_ratingcurve::get_stage_sample(double discharge)
{
  if(hsample)
    delete [] hsample;

  hsample=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    if(discharge>0.0)
      hsample[i]=-sampled_c[i]+pow(discharge*exp(-sampled_a[i]), 
				   1.0/sampled_b[i]);
    else
      hsample[i]=-sampled_c[i];

  qsort(hsample, size_t(num_samples), sizeof(double), compare_double);
  discharge_of_hsample=discharge;

  return hsample;
}

// Fetch the mean (estimated expectation) discharge for a given stage
// or vice versa:
double bayes_mcmc_ratingcurve::get_mean_discharge(double stage)
{
  if(qsample==NULL || stage!=stage_of_qsample)
    get_discharge_sample(stage);
  
  double mean_q=find_statistics(qsample, num_samples, MEAN);

  return mean_q;
}

double bayes_mcmc_ratingcurve::get_mean_stage(double discharge)
{
  if(hsample==NULL || discharge!=discharge_of_hsample)
    get_stage_sample(discharge);
  
  double mean_h=find_statistics(hsample, num_samples, MEAN);

  return mean_h;
}


// Fetch a percentile (estimated quantile) for a given stage;
// (0<percentile<1)
double bayes_mcmc_ratingcurve::get_discharge_percentile(double stage, 
							double percentile)
{
  if(qsample==NULL || stage!=stage_of_qsample)
    get_discharge_sample(stage);
  
  double q_p=find_percentile(qsample, num_samples, percentile);

  return q_p;
}

double bayes_mcmc_ratingcurve::get_stage_percentile(double discharge, 
						    double percentile)
{
  if(hsample==NULL || discharge!=discharge_of_hsample)
    get_stage_sample(discharge);
  
  double h_p=find_percentile(hsample, num_samples, percentile);

  return h_p;
}


// Fetch mean estimates for the different parameters;
double bayes_mcmc_ratingcurve::get_mean_a(void)
{
  return a_mean;
}

double bayes_mcmc_ratingcurve::get_mean_b(void)
{
  return b_mean;
}

double bayes_mcmc_ratingcurve::get_mean_c(void)
{
  return c_mean;
}

double bayes_mcmc_ratingcurve::get_mean_s2(void)
{
  return s2_mean;
}

double bayes_mcmc_ratingcurve::get_var_a(void)
{
  return find_statistics(sampled_a,num_samples,VARIATION);
}

double bayes_mcmc_ratingcurve::get_var_b(void)
{
  return find_statistics(sampled_b,num_samples,VARIATION);
}

double bayes_mcmc_ratingcurve::get_var_c(void)
{
  return find_statistics(sampled_c,num_samples,VARIATION);
}

double bayes_mcmc_ratingcurve::get_var_s2(void)
{
  return find_statistics(sampled_s2,num_samples,VARIATION);
}

// Fetch median estimates for the different parameters;
double bayes_mcmc_ratingcurve::get_median_a(void)
{
  return a_median;
}

double bayes_mcmc_ratingcurve::get_median_b(void)
{
  return b_median;
}

double bayes_mcmc_ratingcurve::get_median_c(void)
{
  return c_median;
}

double bayes_mcmc_ratingcurve::get_median_s2(void)
{
  return s2_median;
}

double bayes_mcmc_ratingcurve::get_a_percentile(double percentile)
{
  double *a=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    a[i]=sampled_a[i];
  
  double a_p=find_percentile(a,num_samples, percentile);
  delete [] a;

  return a_p;
}

double bayes_mcmc_ratingcurve::get_b_percentile(double percentile)
{
  double *b=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    b[i]=sampled_b[i];
  
  double b_p=find_percentile(b,num_samples, percentile);
  delete [] b;

  return b_p;
}

double bayes_mcmc_ratingcurve::get_c_percentile(double percentile)
{
  double *c=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    c[i]=sampled_c[i];
  
  double c_p=find_percentile(c,num_samples, percentile);
  delete [] c;

  return c_p;
}

double bayes_mcmc_ratingcurve::get_s2_percentile(double percentile)
{
  double *s2=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    s2[i]=sampled_s2[i];
  
  double s2_p=find_percentile(s2,num_samples, percentile);
  delete [] s2;

  return s2_p;
}


// Returns the discharge for the mean coefficients;
double bayes_mcmc_ratingcurve::get_mean_coefficient_discharge(double stage)
{
  if(stage+c_mean>0.0)
    return exp(a_mean)*pow(stage+c_mean, b_mean);
  else
    return 0.0;
}

double bayes_mcmc_ratingcurve::get_mean_coefficient_stage(double discharge)
{
  if(discharge>0.0)
    return -c_mean+pow(discharge*exp(-a_mean), 1.0/b_mean);
  else
    return -c_mean;
}


// Returns the discharge for the median coefficients;
double bayes_mcmc_ratingcurve::get_median_coefficient_discharge(double stage)
{
  if(stage+c_median>0.0)
    return exp(a_median)*pow(stage+c_median, b_median);
  else
    return 0.0;
}

double bayes_mcmc_ratingcurve::get_median_coefficient_stage(double discharge)
{
  if(discharge>0.0)
    return -c_median+pow(discharge*exp(-a_median), 1.0/b_median);
  else
    return -c_median;
}


double bayes_mcmc_ratingcurve::get_sd(void) // get the adapted RW step length
{
  return sd_c;
}

double bayes_mcmc_ratingcurve::get_acceptance_rate(void)
{
  return acc_rate;
}

// Fetch prior info:

// Coefficient priors 
double bayes_mcmc_ratingcurve::get_prior_a_mean(void)
{
  return a_m;
}

double bayes_mcmc_ratingcurve::get_prior_a_sdev(void)
{
  return a_s;
}

double bayes_mcmc_ratingcurve::get_prior_b_mean(void)
{
  return b_m;
}

double bayes_mcmc_ratingcurve::get_prior_b_sdev(void)
{
  return b_s;
}

double bayes_mcmc_ratingcurve::get_prior_a_b_correlation(void)
{
  return ab_corr;
}


// sigma� priors (sigma� ~ IG(sigma_a, sigma_b)):
double bayes_mcmc_ratingcurve::get_sigma_a(void)
{
  return sigma_a;
}

double bayes_mcmc_ratingcurve::get_sigma_b(void)
{
  return sigma_b;
}

// get the prior variance matrix used internally
double **bayes_mcmc_ratingcurve::get_var(void)
{
  return var;
}

// get the prior inverse variance matrix used internally 
double **bayes_mcmc_ratingcurve::get_inv_var(void)
{
  return inv_var;
}


// ********************************************
//
//             BAYES_MULTISEGMENT_RATINGCURVE
//
// ********************************************



void bayes_multisegment_ratingcurve::init(void)
{
  q=h=NULL;
  num_meas=0;

  max_num_seg=0;
  a_m=NULL;
  a_s=NULL;
  ab_corr=NULL;
  b_m=NULL;
  b_s=NULL;
  h0_m=NULL;
  h0_s=NULL;
  hs_m=NULL;
  hs_s=NULL;
  sigma_a=sigma_b=0;
  mu_q=sd_q=mu_h02=sd_h02=MISSING_VALUE;
  
  sampled_a=NULL;
  sampled_s2=NULL;
  sampled_logprob=NULL;
  sampled_b=NULL;
  sampled_h0=NULL;
  sampled_hs=NULL;
  sampled_num_seg=NULL;
  num_samples=0;

  qsample=NULL;
  hsample=NULL;
  stage_of_qsample=discharge_of_hsample=MISSING_VALUE;

  a_mean=MISSING_VALUE;
  a_median=MISSING_VALUE;
  s2_mean=MISSING_VALUE;
  s2_median=MISSING_VALUE;
  b_mean=NULL;
  b_median=NULL;
  h0_mean=NULL;
  h0_median=NULL;
  hs_mean=NULL;
  hs_median=NULL;
  
  var=NULL;
  m=NULL;

  model_prior=NULL;
  model_post=NULL;

  rw_h0=NULL;
  rw_hs=NULL;
}

void bayes_multisegment_ratingcurve::cleanup(void)
{
  int i;

  if(a_m)
    delete [] a_m;
  if(a_s)
    delete [] a_s;
  if(ab_corr)
    delete [] ab_corr;
  doubledelete(b_m,max_num_seg);
  doubledelete(b_s,max_num_seg);
  doubledelete(h0_m,max_num_seg);
  doubledelete(h0_s,max_num_seg);
  doubledelete(hs_m,max_num_seg);
  doubledelete(hs_s,max_num_seg);
  
  if(sampled_a)
    delete [] sampled_a;
  if(sampled_s2)
    delete [] sampled_s2;
  if(sampled_logprob)
    delete [] sampled_logprob;
  doubledelete(sampled_b, num_samples);
  doubledelete(sampled_h0, num_samples);
  doubledelete(sampled_hs, num_samples);
  if(sampled_num_seg)
    delete [] sampled_num_seg;

  if(qsample)
    delete [] qsample;
  if(hsample)
    delete [] hsample;
  
  if(b_mean)
    delete [] b_mean;
  if(h0_mean)
    delete [] h0_mean;
  if(hs_mean)
    delete [] hs_mean;
  if(b_median)
    delete [] b_median;
  if(h0_median)
    delete [] h0_median;
  if(hs_median)
    delete [] hs_median;

  if(var)
    for(i=0;i<max_num_seg;i++)
      doubledelete(var, i+2);
  doubledelete(m, max_num_seg);

  doubledelete(rw_h0, max_num_seg);
  doubledelete(rw_hs, max_num_seg);

  if(model_prior)
    delete [] model_prior;
  if(model_post)
    delete [] model_post;

  init();
}

double bayes_multisegment_ratingcurve::Bj(double h_curr, double *h0, 
					  double *hs, int seg, int numseg)
{
  if(seg<0 || seg>=numseg)
    return MISSING_VALUE;

  double ret;

  if(seg>=1 && h_curr<hs[seg-1])
    ret=0.0;
  else if(h_curr<h0[seg])
    return MISSING_VALUE;
  else
    {
      if(seg==0 && (numseg==1 || h_curr<hs[seg]))
	ret=log(h_curr-h0[seg]);
      else if(seg==(numseg-1) || h_curr<hs[seg])
	ret=log(h_curr-h0[seg])-log(hs[seg-1]-h0[seg]);
      else // h_curr>=hs[seg]
	{
	  if(seg==0)
	    ret=log(hs[seg]-h0[seg]);
	  else
	    ret=log(hs[seg]-h0[seg])-log(hs[seg-1]-h0[seg]);
	}
    }

  return ret;
}


double bayes_multisegment_ratingcurve::find_SS(double a1, double *b, 
					       double *h0,double *hs, 
					       int numseg)
{
  double SS=0.0, res;
  int i,j;

  for(i=0;i<len;i++)
    {
      for(j=0;j<numseg;j++)	
	if(b[j]==MISSING_VALUE)
	  return 1e+216;
      
      res=q[i]-a1;
      for(j=0;j<numseg;j++)
	{
	  double bj=Bj(h[i],h0,hs,j,numseg);
	  if(bj==MISSING_VALUE)
	    return MISSING_VALUE;

	  if(!(bj>-1e+100 && bj<1e+100))
	    {
		std::cout << " noe er galt!" << std::endl;
	      bj=Bj(h[i],h0,hs,j,numseg);
	      return MISSING_VALUE;
	    }

	  res-=b[j]*bj;
	}
      
      SS+=res*res;
    }
  
  return SS;
}

double bayes_multisegment_ratingcurve::logprob(double a1, double *b, 
					       double *hs, double *h0, 
					       double s2, int numseg,double T)
{
  int i, j;
  double n=(double) len;
  
  if(numseg>max_num_seg)
    return -1e+216;

  if(hmin<h0[0])
    return -1e+216;
  
  for(i=0;i<(numseg-1);i++)
    if(h0[i+1]>hs[i] || h0[i]>hs[i] || hs[i]<hmin || hs[i]>hmax)
      return -1e+216;

  for(i=0;i<(numseg-2);i++)
    if(hs[i]>=hs[i+1])
      return -1e+216;

  if(s2<0.0)
    return -1e+216;

  // contrubtion from (beta-m)V^(-1)(beta-m);
  int dim=numseg+1;
  double *beta=new double[dim];
  beta[0]=a1;
  for(j=0;j<numseg;j++)
    beta[j+1]=b[j];

  double *a=new double[numseg];
  a[0]=a1;
  for(j=1;j<numseg;j++)
    a[j]=a[j-1]+b[j-1]*log(hs[j-1]-h0[j-1])-b[j]*log(hs[j-1]-h0[j]);

  double contrib_pri_beta = multinormal_pdf(beta,m[numseg-1],var[numseg-1],
					    numseg+1,true);
  double contrib_h01=0.0;
  double contrib_hs=0.0;

  for(j=0;j<(numseg-1);j++)
    contrib_hs+=log(ABSVAL(b[j]))-0.5*log(2.0*M_PI)-log(sd_q)-
      0.5*(a[j]+b[j]*log(hs[j]-h0[j])-mu_q)*(a[j]+b[j]*log(hs[j]-h0[j])-mu_q)/
      sd_q/sd_q;

  double contrib_h02=0.0; 
  if(!h0_m)
    for(j=0;j<(numseg-1);j++)
      contrib_h02+=(-log(sqrt(2.0)*sd_h02))-ABSVAL((h0[j+1]-h0[j]-mu_h02))*
	sqrt(2.0)/sd_h02;
  else
    for(j=1;j<numseg;j++)
      contrib_h02+=(-0.5*log(2.0*M_PI)-log(h0_s[numseg-1][j])-
		    0.5*(h0[j]-h0_m[numseg-1][j])*(h0[j]-h0_m[numseg-1][j])/
		    h0_s[numseg-1][j]/h0_s[numseg-1][j]);
		    
  if(h0_m)
    contrib_h01=-0.5*log(2.0*M_PI)-log(h0_s[numseg-1][0])-
      0.5*(h0[0]-h0_m[numseg-1][0])*(h0[0]-h0_m[numseg-1][0])/
      h0_s[numseg-1][0]/h0_s[numseg-1][0];
  else if(mu_h01!=MISSING_VALUE && sd_h01!=MISSING_VALUE)
    contrib_h01=-0.5*log(2.0*M_PI)-log(sd_h01)-
      0.5*(h0[0]-mu_h01)*(h0[0]-mu_h01)/sd_h01/sd_h01;

  if(hs_m && hs_s)
    for(j=0;j<(numseg-1);j++)
      contrib_hs-=0.5*log(2.0*M_PI)+log(hs_s[numseg-1][j])+
	0.5*(hs[j]-hs_m[numseg-1][j])*(hs[j]-hs_m[numseg-1][j])/
	hs_s[numseg-1][j]/hs_s[numseg-1][j];
  else
    contrib_hs = - lgamma(double(numseg+1-1))-double(numseg-1)*log(hmax-hmin);

  // contribution from (sigma�)^-(a+2+n/2)*exp(-b/sigma�)
  double contrib_s2 = - (sigma_a+1.0)*log(s2) - sigma_b/s2;
  
  double SS=find_SS(a1,b,h0,hs,numseg);

  if(SS==MISSING_VALUE)
    {
      delete [] beta;
      delete [] a;
      return -1e+216;
    }

  // contribution from the exponensial data part of the likelihood function;
  double contrib_lik=-0.5*n*log(s2)-SS/2.0/s2;

  double ret = contrib_pri_beta +contrib_s2 +
    contrib_h01+contrib_h02 +contrib_hs +contrib_lik;

  delete [] beta;
  delete [] a;

  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;

  return ret/T;
}


double bayes_multisegment_ratingcurve::gibbs_sigma2(double a1, double *b, 
						    double *hs, double *h0, 
						    double T, gsl_rng *rptr,
						    int num_seg)
{
  double n=(double) len;
  double sigma_a_star=sigma_a+n/2.0;
  double sigma_b_star=sigma_b;

  sigma_b_star+=find_SS(a1,b,h0,hs,num_seg)/2.0;
  
  if(T!=1.0)
    {
      sigma_a_star=(sigma_a_star+1.0-T)/T;
      sigma_b_star/=T;
    }

  double s2=1.0/gsl_ran_gamma(rptr, sigma_a_star, 1.0/sigma_b_star);

  return s2;
}


void bayes_multisegment_ratingcurve::
get_linear_proposal_hyperparameters(double *hs, double *h0,
				    double s2, double T, int numseg,
				    double **m_star_, double ***V_star_)
{
  int dim=numseg+1;
  double **XtX=new double*[dim], **V_star, 
    **inv_V_star=new double*[dim], **inv_V;
  int i,j,k;
  double **X=new double*[len];
  
  inv_V=inverse_matrix(var[numseg-1],dim);
  
  for(j=0;j<dim;j++)
    {
      XtX[j]=new double[dim];
      for(k=0;k<dim;k++)
	XtX[j][k]=0.0;
    }
  for(j=0;j<dim;j++)
    inv_V_star[j]=new double[dim];

  for(i=0;i<len;i++)
    {
      X[i]=new double[dim];
      X[i][0]=1.0;
      for(j=0;j<numseg;j++)
	X[i][j+1]=Bj(h[i],h0,hs,j,numseg);
	  
      for(j=0;j<dim;j++)
	for(k=j;k<dim;k++)
	  XtX[j][k] += X[i][j]*X[i][k];
    }
  for(j=0;j<dim;j++)
    for(k=0;k<j;k++)
      XtX[j][k]=XtX[k][j];
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      inv_V_star[j][k]=inv_V[j][k]+XtX[j][k]/s2;
  
  V_star=inverse_matrix(inv_V_star,dim);
  
  double *m_star_raw=new double[dim], *m_star=new double[dim];
  
  for(j=0;j<dim;j++)
    m_star_raw[j]=m_star[j]=0.0;
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      m_star_raw[j]+=inv_V[j][k]*m[numseg-1][k];
  for(i=0;i<len;i++)
    for(j=0;j<dim;j++)
      m_star_raw[j]+=q[i]*X[i][j]/s2;
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      m_star[j]+=V_star[j][k]*m_star_raw[k];

  doubledelete(X,len);
  doubledelete(XtX,dim);
  doubledelete(inv_V_star,dim);
  doubledelete(inv_V,dim);
  delete [] m_star_raw;

  if(T!=1.0)
    for(j=0;j<dim;j++)
      for(k=0;k<dim;k++)
	V_star[j][k]*=T;

  *m_star_=m_star;
  *V_star_=V_star;
}


double bayes_multisegment_ratingcurve::gibbs_linear(double *hs, double *h0, 
						    double s2, double T, 
						    int numseg,
						    double *new_a1, 
						    double **new_b, 
						    gsl_rng *rptr)
{
  double *m_star, **V_star, ret;
  int j,dim=numseg+1;

  get_linear_proposal_hyperparameters(hs, h0, s2, T, numseg,&m_star, &V_star);

  double **samples=sample_from_multinormal(1,m_star,V_star,dim,rptr);
  
  double *b=new double[numseg];

  *new_a1=samples[0][0];
  for(j=0;j<numseg;j++)
    b[j]=samples[0][j+1];
  *new_b=b;

  ret=multinormal_pdf(samples[0],m_star,V_star,dim,true);
  
  delete [] m_star;
  doubledelete(V_star,dim);
  doubledelete(samples,1);
  
  return ret;
}


double bayes_multisegment_ratingcurve::
get_proposal_logdensity(double s2, double *hs,
			double prop_a1, double *prop_b,
			double *prop_h0, double T, int numseg)
{
  int j, dim=numseg+1;
  double *m_star, **V_star;
  double ret, *beta=new double[dim];
  
  beta[0]=prop_a1;
  for(j=0;j<numseg;j++)
    beta[j+1]=prop_b[j];
  
  get_linear_proposal_hyperparameters(hs, prop_h0, s2, T, numseg,
				      &m_star, &V_star);
  
  ret=multinormal_pdf(beta,m_star,V_star,dim,true);

  delete [] m_star;
  doubledelete(V_star,dim);
  delete [] beta;

  return ret;
}

int bayes_multisegment_ratingcurve::
draw_from_model(int num_seg, int num_temp, double *T, gsl_rng *rptr, 
		double *prev_a1, double **prev_b, double **prev_h0,
		double **prev_hs, double *prev_s2, double *prev_logprob,
		int h0_update /* =-1 means all h0's are updated */,
		int hs_update /* =-1 means all h0's are updated. If not
				 accpetance for this is reported */)
{
  int t,l,l2, acc=0;
  double new_logprob;

  for(t=0;t<num_temp;t++)
    {
      double steptype=sqrt(T[t]);
      double r=drand48();
      if(r<0.1)
	steptype/=10.0;
      else if(r<0.2)
	steptype/=300.0;
      else if(r<0.3)
	steptype/=10000.0;
      else if(r<0.4)
	steptype*=10.0;
      else if(r<0.5)
	steptype*=100.0;
      
      // Update s^2
      prev_s2[t]=gibbs_sigma2(prev_a1[t], prev_b[t], 
			      prev_hs[t], prev_h0[t], 
			      T[t], rptr, num_seg);
      
      // Update hs:
      for(l=0;l<(num_seg-1);l++)
	if(hs_update<0 || hs_update==l)
	  {
	    double *new_hs=new double[num_seg-1];
	    for(l2=0;l2<(num_seg-1);l2++)
	      new_hs[l2]=prev_hs[t][l2];
	    new_hs[l]=prev_hs[t][l]+gsl_ran_gaussian(rptr,steptype*
						     rw_hs[num_seg-1][l]);
	    
	    new_logprob=logprob(prev_a1[t], prev_b[t], new_hs, prev_h0[t], 
				prev_s2[t], num_seg, T[t]);
	    
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_hs[t][l]=new_hs[l];
		prev_logprob[t]=new_logprob;

		if(hs_update>=0)
		  acc=1;
	      }
	    
	    delete [] new_hs;
	  }

      // Update h01, h02, a1, b1, b2:
      double new_a1, *new_h0=new double[num_seg];
      for(l=0;l<num_seg;l++)
	new_h0[l]=prev_h0[t][l]+
	  gsl_ran_gaussian(rptr, steptype*rw_h0[num_seg-1][l]);
      
      int is_h0_ok=1;
      if(new_h0[0]>=hmin)
	is_h0_ok=0;
      for(l=0;l<(num_seg-1);l++)
	if(new_h0[l]>=prev_hs[t][l] || new_h0[l+1]>=prev_hs[t][l])
	  is_h0_ok=0;
      
      if(is_h0_ok)
	{
	  if(h0_update>=0 && h0_update<num_seg)
	    for(l=0;l<num_seg;l++)
	      if(l!=h0_update)
		new_h0[l]=prev_h0[t][l];
	  
	  double *new_b;
	  double new_proposal=
	    gibbs_linear(prev_hs[t], new_h0,
			 prev_s2[t], T[t], num_seg, &new_a1, 
			 &new_b, rptr);
	  
	  new_logprob=logprob(new_a1, new_b, prev_hs[t], 
			      new_h0, prev_s2[t],num_seg, T[t]);
	  double prev_proposal=
	    get_proposal_logdensity(prev_s2[t], prev_hs[t], prev_a1[t], 
				    prev_b[t], prev_h0[t],T[t], num_seg);
	  
	  if(log(drand48())<((new_logprob-prev_logprob[t])-
			     (new_proposal-prev_proposal)))
	    {
	      for(l=0;l<num_seg;l++)
		prev_h0[t][l]=new_h0[l];
	      prev_a1[t]=new_a1;
	      for(l=0;l<num_seg;l++)
		prev_b[t][l]=new_b[l];
	      prev_logprob[t]=new_logprob;
	
	      if(t==0 && hs_update<0)
		acc=1;
	    }

	  delete [] new_b;
	}

      delete [] new_h0;
    }

  return acc;
}

void bayes_multisegment_ratingcurve::
make_lin_prior(double est_logconst, double est_exp, 
	       double sdev_logconst, double sdev_exp,double corr)
{
  m=new double*[max_num_seg];
  var=new double**[max_num_seg];
  a_m=new double[max_num_seg];
  a_s=new double[max_num_seg];
  ab_corr=new double[max_num_seg];
  b_m=new double*[max_num_seg];
  b_s=new double*[max_num_seg];

  for(int i=0;i<(max_num_seg-1);i++)
    {
      int curr_numseg=i+1;
      int l,l2;

      // Make the prior expectancy vector:
      m[i]=new double[curr_numseg+1];
      m[i][0]=est_logconst;
      for(l=0;l<curr_numseg;l++)
	m[i][l+1]=est_exp;
  
      // Make the prior covariance matrix:
      var[i]=new double*[curr_numseg+1];
      for(l=0;l<curr_numseg+1;l++)
	var[i][l]=new double[curr_numseg+1];
      var[i][0][0]=sdev_logconst*sdev_logconst;
      for(l=0;l<curr_numseg;l++)
	{
	  var[i][0][l+1]=var[i][l+1][0]=corr*sdev_logconst*sdev_exp;
	  var[i][l+1][l+1]=sdev_exp*sdev_exp;
	}
      for(l=0;l<curr_numseg;l++)
	for(l2=l+1;l2<curr_numseg;l2++)
	  var[i][l+1][l2+1]=var[i][l2+1][l+1]=corr*corr*sdev_exp*sdev_exp;

      a_m[i]=est_logconst;
      a_s[i]=sdev_logconst;
      ab_corr[i]=corr;
      b_m[i]=new double[curr_numseg];
      b_s[i]=new double[curr_numseg];
      for(l=0;l<curr_numseg;l++)
	{
	  b_m[i][l]=est_exp;
	  b_s[i][l]=sdev_exp;
	}
    }
}

void bayes_multisegment_ratingcurve::
make_lin_prior(double *a1_mean, double *a1_sdev, double **b_mean,
	       double **b_sdev, double *ab_corr_)
{
  m=new double*[max_num_seg];
  var=new double**[max_num_seg];
  a_m=new double[max_num_seg];
  a_s=new double[max_num_seg];
  ab_corr=new double[max_num_seg];
  b_m=new double*[max_num_seg];
  b_s=new double*[max_num_seg];

  for(int i=0;i<(max_num_seg-1);i++)
    {
      int curr_numseg=i+1;
      int l,l2;

      a_m[i]=a1_mean[i];
      a_s[i]=a1_sdev[i];
      ab_corr[i]=ab_corr_[i];
      b_m[i]=new double[curr_numseg];
      b_s[i]=new double[curr_numseg];
      for(l=0;l<curr_numseg;l++)
	{
	  b_m[i][l]=b_mean[i][l];
	  b_s[i][l]=b_sdev[i][l];
	}

      // Make the prior expectancy vector:
      m[i]=new double[curr_numseg+1];
      m[i][0]=a1_mean[i];
      for(l=0;l<curr_numseg;l++)
	m[i][l+1]=b_mean[i][l];
  
      // Make the prior covariance matrix:
      var[i]=new double*[curr_numseg+1];
      for(l=0;l<curr_numseg+1;l++)
	var[i][l]=new double[curr_numseg+1];
      var[i][0][0]=a1_sdev[i]*a1_sdev[i];
      for(l=0;l<curr_numseg;l++)
	{
	  var[i][0][l+1]=var[i][l+1][0]=ab_corr[i]*
	    a1_sdev[i]*b_sdev[i][l];
	  var[i][l+1][l+1]=b_sdev[i][l]*b_sdev[i][l];
	}
      for(l=0;l<curr_numseg;l++)
	for(l2=l+1;l2<curr_numseg;l2++)
	  var[i][l+1][l2+1]=var[i][l2+1][l+1]=ab_corr[i]*ab_corr[i]*
	    b_sdev[i][l]*b_sdev[i][l2];
    }
}

void bayes_multisegment_ratingcurve::
switch_temp(double new_logprob1, double new_logprob2, 
	    double *prev_a1, double **prev_b, double **prev_h0, 
	    double **prev_hs, double *prev_s2, double *prev_logprob,
	    int num_seg, int t)
{
  int l;
  double *b_buff=new double[num_seg], 
    *h0_buff=new double[num_seg], 
    *hs_buff=new double[num_seg];
  double a1_buff=prev_a1[t],
    s2_buff=prev_s2[t]; // lambda_buff=prev_lambda[t],
  
  for(l=0;l<num_seg;l++)
    {
      b_buff[l]=prev_b[t][l];
      h0_buff[l]=prev_h0[t][l];
      if(l<(num_seg-1))
	hs_buff[l]=prev_hs[t][l];
    }
  
  prev_a1[t]=prev_a1[t+1];
  for(l=0;l<num_seg;l++)
    {
      prev_b[t][l]=prev_b[t+1][l];
      prev_h0[t][l]=prev_h0[t+1][l];
      if(l<(num_seg-1))
	prev_hs[t][l]=prev_hs[t+1][l];
    }
  prev_s2[t]=prev_s2[t+1];
  //prev_lambda[t]=prev_lambda[t+1];
  prev_logprob[t]=new_logprob1;
  
  prev_a1[t+1]=a1_buff;
  for(l=0;l<num_seg;l++)
    {
      prev_b[t+1][l]=b_buff[l];
      prev_h0[t+1][l]=h0_buff[l];
      if(l<(num_seg-1))
	prev_hs[t+1][l]=hs_buff[l];
    }
  prev_s2[t+1]=s2_buff;
  //prev_lambda[t+1]=lambda_buff;
  prev_logprob[t+1]=new_logprob2;

  delete [] b_buff;
  delete [] h0_buff;
  delete [] hs_buff;
}

bayes_multisegment_ratingcurve::bayes_multisegment_ratingcurve()
{
  init();
}

bayes_multisegment_ratingcurve::~bayes_multisegment_ratingcurve()
{
  cleanup();
}


void bayes_multisegment_ratingcurve::
draw_parameters(double *stage, double *discharge, 
		int number_of_measurements, 
		// measurements
		
		int num_sim, 
		// number of drawings
		
		// Optional input::
		
		// prior knowledge:
		double est_exp, 
		double sdev_exp, 
		double est_logconst, 
		double sdev_logconst,
		double corr,
		
		double sigma_alpha, 
		double sigma_beta, 
		
		// prior mean and st.dev. log(discharge):
		double mu_logdischarge, double sd_logdischarge,
		
		// mean and st.dev. of the lowest h0:
		double mu_h01_, double sd_h01_,
		
		// mean and st.dev. for concecutive
		// h0's compared to the previous one:
		double mu_h02_, double sd_h02_,
		
		int max_seg,
		
		double *p_models,
		// default is equal probability to each model
		
		// Detailed parameter priors:
		double *a1_prior_mean, double *a1_prior_sdev,
		double **b_prior_mean, double **b_prior_sdev, 
		double *ab_prior_corr,
		double **h0_prior_mean, double **h0_prior_sdev,
		double **hs_prior_mean, double **hs_prior_sdev,
		
		int burnin, 
		/* burn-in length */
		
		int indep, 
		/* spacing between drawings */
		
		int num_temp,
		int min_seg
		)
{
  int i, l, l2;
  
  cleanup();

  // Store the measurements:
  num_meas=number_of_measurements;
  len=number_of_measurements;
  q=new double[num_meas];
  h=new double[num_meas];
  for(i=0;i<num_meas;i++)
    {
      q[i]=log(discharge[i]);
      h[i]=stage[i];
    }

  hmin=find_statistics(h,num_meas,MIN);
  hmax=find_statistics(h,num_meas,MAX);
  
  max_num_seg=max_seg;
  min_num_seg=min_seg;
  num_mod=(max_seg-min_seg+1);
  
  double *T=new double[num_temp];
  
  model_prior=new double[max_num_seg];
  double **T_model=new double*[max_num_seg];
  for(l=(min_num_seg-1);l<max_num_seg;l++)
    {
      if(!p_models)
	model_prior[l]=1.0/double(num_mod);
      else
	model_prior[l]=p_models[l];

      T_model[l]=new double[max_num_seg];
      for(l2=0;l2<max_seg;l2++)
	T_model[l][l2]=0.0;
      if(num_mod>=2)
	{
	  if(l==(min_num_seg-1))
	    T_model[l][l+1]=1.0;
	  else if(l==(max_num_seg-1))
	    T_model[l][l-1]=1.0;
	  else
	    T_model[l][l-1]=T_model[l][l+1]=0.5;
	}
    }

  // Initialize GSL random generator:
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand());

  if(!a1_prior_mean || !a1_prior_sdev || !b_prior_mean || 
     !b_prior_sdev || !ab_prior_corr)
    make_lin_prior(est_logconst, est_exp, sdev_logconst, sdev_exp, corr);
  else
    make_lin_prior(a1_prior_mean, a1_prior_sdev, b_prior_mean, 
		   b_prior_sdev, ab_prior_corr);
  
  sigma_a=sigma_alpha;
  sigma_b=sigma_beta;
  
  mu_q=mu_logdischarge;
  sd_q=sd_logdischarge;

  mu_h01=mu_h01_;
  sd_h01=sd_h01_;
  
  mu_h02=mu_h02_;
  sd_h02=sd_h02_;

  if(h0_prior_mean)
    {
      h0_m=new double*[max_num_seg];
      for(l=0;l<max_num_seg;l++)
	{
	  h0_m[l]=new double[l+1];
	  for(l2=0;l2<l+1;l2++)
	    h0_m[l][l2]=h0_prior_mean[l][l2];
	}
    }

  if(h0_prior_sdev)
    {
      h0_s=new double*[max_num_seg];
      for(l=0;l<max_num_seg;l++)
	{
	  h0_s[l]=new double[l+1];
	  for(l2=0;l2<l+1;l2++)
	    h0_s[l][l2]=h0_prior_sdev[l][l2];
	}
    }

  if(hs_prior_mean && max_num_seg>1)
    {
      hs_m=new double*[max_num_seg-1];
      for(l=0;l<max_num_seg-1;l++)
	{
	  hs_m[l]=new double[l+1];
	  for(l2=0;l2<l;l2++)
	    hs_m[l][l2]=hs_prior_mean[l][l2];
	}
    }

  if(hs_prior_sdev && max_num_seg>1)
    {
      hs_s=new double*[max_num_seg-1];
      for(l=0;l<max_num_seg-1;l++)
	{
	  hs_s[l]=new double[l+1];
	  for(l2=0;l2<l;l2++)
	    hs_s[l][l2]=hs_prior_sdev[l][l2];
	}
    }
  
  // Make the return arrays:
  double *a1=new double[num_sim];
  double **b_=new double*[num_sim];
  double **hs_=new double*[num_sim];
  double **h0_=new double*[num_sim];
  double *s2=new double[num_sim];
  double *psi=new double[num_sim];
  int *num_seg=new int[num_sim];
  for(l=0;l<num_sim;l++)
    {
      b_[l]=new double[max_seg];
      hs_[l]=new double[max_seg];
      h0_[l]=new double[max_seg];
    }

  // Make the vectors holding previous simulation values:
  int prev_nseg=max_seg>min_seg ? min_seg+1 : min_seg;
  double **prev_a1=new double*[max_seg], ***prev_b=new double**[max_seg],
    ***prev_h0=new double**[max_seg], ***prev_hs=new double**[max_seg],
    **prev_s2=new double*[max_seg], **prev_logprob=new double*[max_seg];

  for(l=0;l<max_seg;l++)
    {
      prev_a1[l]=new double[num_temp];
      prev_b[l]=new double*[num_temp]; 
      prev_h0[l]=new double*[num_temp];
      prev_hs[l]=new double*[num_temp]; 
      prev_s2[l]=new double[num_temp];
      prev_logprob[l]=new double[num_temp];

      for(i=0;i<num_temp;i++)
	{
	  prev_b[l][i]=new double[max_seg];
	  prev_h0[l][i]=new double[max_seg];
	  prev_hs[l][i]=new double[max_seg];
	}
    }

  int t;
  int *numswaps=NULL;

  if(num_temp>1)
    numswaps=new int[num_temp-1];
  
  // First sample for all models;
  for(l=(min_seg-1);l<max_seg;l++)
    {
      for(t=0;t<num_temp;t++)
	{
	  if(t==0)
	    T[t]=1.0;
	  else
	    T[t]=2.0*T[t-1];
	  if(num_temp>1 && t<num_temp-1)
	    numswaps[t]=0; 
	  
	  prev_a1[l][t]=m[l][0]+gsl_ran_gaussian(rptr, sdev_logconst);
	  
	  for(l2=0;l2<=l;l2++)
	    {
	      prev_b[l][t][l2]=m[l][l2+1]+gsl_ran_gaussian(rptr, sdev_exp);
	      prev_h0[l][t][l2]=hmin-drand48();
	      if(l2<l)
		prev_hs[l][t][l2]=hmin+drand48()*(hmax-hmin);
	    }
	  if(l>1)
	    qsort(prev_hs[l][t],l, sizeof(double), compare_double); 
	  
	  prev_s2[l][t]=sigma_a>0.0 ? 
	    1.0/gsl_ran_gamma(rptr,sigma_a,1.0/sigma_b) : 1.0e+5*drand48();
	  
	  prev_logprob[l][t]=logprob(prev_a1[l][t], prev_b[l][t], 
				     prev_hs[l][t], prev_h0[l][t], 
				     prev_s2[l][t],l+1, T[t]);
	}
    }
  
  // burnin non-adaptive samples for each model;
  rw_hs=new double*[max_seg];
  rw_h0=new double*[max_seg];
  for(l=(min_seg-1);l<max_seg;l++)
    {
      rw_hs[l]=new double[max_seg];
      rw_h0[l]=new double[max_seg];
      for(l2=0;l2<=l;l2++)
	{
	  rw_h0[l][l2]=0.1;
	  if(l2<l)
	    rw_hs[l][l2]=0.1;
	}

      for(i=0;i<burnin;i++)
	draw_from_model(l+1, (l==0 ? 1 : num_temp), T, rptr, 
			prev_a1[l], prev_b[l], prev_h0[l], prev_hs[l], 
			prev_s2[l], prev_logprob[l],-1, -1);
    }

  // adaptive samples for each model:
  for(l=(min_seg-1);l<max_seg;l++)
    {
      for(i=0;i<burnin;i+=100)
	{
	  for(l2=0;l2<=l;l2++) // adapt rw_h0
	    {
	      int acc=0;
	      for(int j=0;j<100;j++)
		acc+=draw_from_model(l+1, (l==0 ? 1 : num_temp), 
				     T, rptr, prev_a1[l], prev_b[l], 
				     prev_h0[l], prev_hs[l], 
				     prev_s2[l], prev_logprob[l],l2, -1);
	      double accrate=double(acc)/double(100);
	      
	      rw_h0[l][l2]*=exp((accrate-0.33)*2.0);
	    }
	  
	  for(l2=0;l2<l;l2++) // adapt rw_hs
	    {
	      int acc=0;
	      for(int j=0;j<100;j++)
		acc+=draw_from_model(l+1, (l==0 ? 1 : num_temp), 
			 	     T, rptr, prev_a1[l], prev_b[l], 
				     prev_h0[l], prev_hs[l],
				     prev_s2[l], prev_logprob[l],-1, l2);
	      double accrate=double(acc)/double(100);
	      
	      rw_hs[l][l2]*=exp((accrate-0.33)*2.0);
	    }
	}
    }     


  // Global variables inside the simulation:
  int prev_method=0;
  double *numseg=new double[burnin+num_sim*indep+1];
  
  for(i=1;i<=num_sim*indep+burnin;i++)
    {
      if(prev_nseg>=2 && drand48()<0.1 && num_temp>1) 
	// try tempering algorithm?
	{
	  int t=(int) floor(drand48()*double(num_temp-1));

	  double new_logprob1=
	    logprob(prev_a1[prev_nseg-1][t+1], 
		    prev_b[prev_nseg-1][t+1], 
		    prev_hs[prev_nseg-1][t+1], prev_h0[prev_nseg-1][t+1], 
		    prev_s2[prev_nseg-1][t+1],prev_nseg, T[t]);
	  
	  double new_logprob2=
	    logprob(prev_a1[prev_nseg-1][t], prev_b[prev_nseg-1][t], 
		    prev_hs[prev_nseg-1][t], prev_h0[prev_nseg-1][t], 
		    prev_s2[prev_nseg-1][t], prev_nseg, T[t+1]);

	  // swap parameters between distribution t and distribution t+1
	  if(log(drand48())< new_logprob1+new_logprob2-
	     prev_logprob[prev_nseg-1][t]-prev_logprob[prev_nseg-1][t+1])
	    {
	      switch_temp(new_logprob1, new_logprob2,
			  prev_a1[prev_nseg-1], prev_b[prev_nseg-1],
			  prev_h0[prev_nseg-1], prev_hs[prev_nseg-1],
			  prev_s2[prev_nseg-1], prev_logprob[prev_nseg-1],
			  prev_nseg, t);
	      numswaps[t]++;
	    }
	      
	  prev_method=1;
	}
      else // no tempering proposal
	{
	  // reversible jump:
	  if(num_mod>=2 && i>burnin/2 && drand48()<0.2) // propose model jump?
	    {
	      // Draw a new model:
	      double r=drand48(), T_cumul=0.0;
	      int next_nseg=-1;
	      
	      for(l=(min_seg-1);l<max_seg && next_nseg<0;l++)
		{
		  T_cumul+=T_model[prev_nseg-1][l];
		  if(r<=T_cumul)
		    next_nseg=l+1;
		}
	      
	      // Draw from that model:
	      draw_from_model(next_nseg, (next_nseg==1 ? 1 : num_temp),T, rptr,
			      prev_a1[next_nseg-1], prev_b[next_nseg-1], 
			      prev_h0[next_nseg-1], prev_hs[next_nseg-1],
			      prev_s2[next_nseg-1], prev_logprob[next_nseg-1],
			      -1, -1);
	      
	      // Accept/reject model proposal:
	      if(log(drand48())<
		 (prev_logprob[next_nseg-1][0]-prev_logprob[prev_nseg-1][0])+
		 (log(model_prior[next_nseg-1])-log(model_prior[prev_nseg-1]))-
		 (log(T_model[prev_nseg-1][next_nseg-1])-
		  log(T_model[next_nseg-1][prev_nseg-1])))
		prev_nseg=next_nseg;
	    }
	  else // internal model run
	    {
	      draw_from_model(prev_nseg, prev_nseg==1 ? 1 : num_temp,T, rptr,  
			      prev_a1[prev_nseg-1], prev_b[prev_nseg-1], 
			      prev_h0[prev_nseg-1], prev_hs[prev_nseg-1], 
			      prev_s2[prev_nseg-1], prev_logprob[prev_nseg-1],
			      -1, -1);
	      
	      prev_method=4;
	    }
	}
      
      if(i%1000==0)
	{
	    std::cout << i << " " << prev_a1[prev_nseg-1][0] << " " << 
	    prev_b[prev_nseg-1][0][0] << " " << 
	    prev_b[prev_nseg-1][0][1] << " " << 
	    prev_hs[prev_nseg-1][0][0] << 
	    " "  << prev_h0[prev_nseg-1][0][0] << " " << 
	    prev_h0[prev_nseg-1][0][1] << " " << 
	    prev_s2[prev_nseg-1][0] << " " << 
	    prev_logprob[prev_nseg-1][0] << " " << 
		prev_nseg << std::endl;
	}
      numseg[i]=prev_nseg;
      
      if(i>burnin && (i-burnin)%indep==0)
	{
	  a1[(i-burnin)/indep-1]=prev_a1[prev_nseg-1][0];
	  for(l=0;l<max_seg;l++)
	    {
	      b_[(i-burnin)/indep-1][l]=prev_b[prev_nseg-1][0][l];
	      h0_[(i-burnin)/indep-1][l]=prev_h0[prev_nseg-1][0][l];
	      if(l<(max_seg-1))
		hs_[(i-burnin)/indep-1][l]=prev_hs[prev_nseg-1][0][l];
	    }
	  s2[(i-burnin)/indep-1]=prev_s2[prev_nseg-1][0];
	  psi[(i-burnin)/indep-1]=prev_logprob[prev_nseg-1][0];
	  num_seg[(i-burnin)/indep-1]=prev_nseg;
	}
    }
  
  int num_1=0, num_2=0;
  for(i=burnin;i<burnin+indep*num_sim;i++)
    if(numseg[i]==1)
      num_1++;
    else
      num_2++;
  
  for(t=0;t<num_temp-1;t++)
      std::cout << "Number of swaps from " << t+1 << " to " << 
	  t+2 << " : " << numswaps[t] << std::endl;

  sampled_a=a1;
  sampled_b=b_;
  sampled_hs=hs_;
  sampled_h0=h0_;
  sampled_s2=s2;
  sampled_logprob=psi;
  sampled_num_seg=num_seg;
  num_samples=num_sim;

  int *num_mod=new int[max_num_seg];
  for(i=0;i<num_samples;i++)
    num_mod[num_seg[i]-1]++;
  model_post=new double[max_num_seg];
  for(l=0;l<max_num_seg;l++)    
    model_post[l]=double(num_mod[l])/double(num_samples);

  int max_index=-1;
  max_post=0.0;
  for(l=0;l<max_num_seg;l++)   
    if(model_post[l]>max_post)
      {
	max_post=model_post[l];
	max_index=l;
      }
  best_model=max_index;
  best_model_numseg=best_model+1;

  int num;
  double *a=get_sampled_a(best_model, &num);
  a_mean=find_statistics(a, num, MEAN);
  a_median=find_statistics(a, num, MEDIAN);
  delete [] a;

  b_mean=new double[best_model_numseg];
  b_median=new double[best_model_numseg];
  for(l=0;l<best_model_numseg;l++)
    {
      double *b=get_sampled_b(best_model, l, &num);
      b_mean[l]=find_statistics(b, num, MEAN);
      b_median[l]=find_statistics(b, num, MEDIAN);
      delete [] b;
    }
  
  h0_mean=new double[best_model_numseg];
  h0_median=new double[best_model_numseg];
  for(l=0;l<best_model_numseg;l++)
    {
      double *h0=get_sampled_h0(best_model, l, &num);
      h0_mean[l]=find_statistics(h0, num, MEAN);
      h0_median[l]=find_statistics(h0, num, MEDIAN);
      delete [] h0;
    }
  
  if(best_model_numseg>1)
    {
      hs_mean=new double[best_model_numseg-1];
      hs_median=new double[best_model_numseg-1];
      for(l=0;l<(best_model_numseg-1);l++)
	{
	  double *hs=get_sampled_hs(best_model, l, &num);
	  hs_mean[l]=find_statistics(hs, num, MEAN);
	  hs_median[l]=find_statistics(hs, num, MEDIAN);
	  delete [] hs;
	}
    }

  double *s2buff=get_sampled_sigma_squared(best_model, &num);
  s2_mean=find_statistics(s2buff, num, MEAN);
  s2_median=find_statistics(s2buff, num, MEDIAN);

  doubledelete(prev_a1,max_seg);
  for(i=0;i<max_seg;i++)
    {
      doubledelete(prev_b[i],num_temp);
      doubledelete(prev_h0[i],num_temp);
      doubledelete(prev_hs[i],num_temp);
    }
  delete [] prev_b;
  delete [] prev_h0;
  delete [] prev_hs;
  doubledelete(prev_s2,max_seg);
  doubledelete(prev_logprob,max_seg);

  delete [] s2buff;
  delete [] T;
  delete [] num_mod;
  delete [] numseg;
  if(numswaps)
    delete [] numswaps;
}

double bayes_multisegment_ratingcurve::get_Q(double h, double a1, 
					     double *b, double *hs, 
					     double *h0, int num_seg)
{
  double Q=0.0;

  if(h>h0[0])
    {
      double a=a1;
      int seg=0;

      for(seg=0;seg<(num_seg-1);seg++)
	{
	  if(h<=hs[seg])
	    break;
	  else
	    a+=b[seg]*log(hs[seg]-h0[seg])-b[seg+1]*log(hs[seg]-h0[seg+1]);
	}
      
      Q=exp(a+b[seg]*log(h-h0[seg]));
    }

  return Q;
}

double bayes_multisegment_ratingcurve::get_h(double Q, double a1, 
					     double *b, double *hs, 
					     double *h0, int num_seg)
{
  double h=h0[0];
  double q=log(Q);

  if(Q>0.0)
    {
      double a=a1;
      int seg=0;

      for(seg=0;seg<(num_seg-1);seg++)
	{
	  if(Q<=get_Q(hs[seg],a1,b,hs,h0,num_seg))
	    break;
	  else
	    a+=b[seg]*log(hs[seg]-h0[seg])-b[seg+1]*log(hs[seg]-h0[seg+1]);
	}
      
      h=h0[seg]+exp((q-a)/b[seg]);
    }

  return h;
}

int bayes_multisegment_ratingcurve::get_number_of_drawings(void)
{
  return num_samples;
}

double bayes_multisegment_ratingcurve::get_model_probability(int model)
{
  if(model>=0 && model<max_num_seg)
    return model_post[model];
  else
    return 0.0;
}

double *bayes_multisegment_ratingcurve::get_model_probabilities(void)
{
  return model_post;
}

int bayes_multisegment_ratingcurve::get_most_probable_model(void)
{
  return best_model;
}

int bayes_multisegment_ratingcurve::get_most_probable_number_of_segments(void)
{
  return best_model_numseg;
}

double *bayes_multisegment_ratingcurve::get_sampled_a(int model, 
						      int *num)
{
  double *ret=NULL;
  int n=0,i;

  if(model<0)
    {
      n=num_samples;
      ret=new double[n];
      for(i=0;i<n;i++)
	ret[i]=sampled_a[i];
    }
  else
    {
      int index=0;
      for(i=0;i<num_samples;i++)
	if((sampled_num_seg[i]-1)==model)
	  index++;
      n=index;

      if(n>0)
	{
	  ret=new double[n];
	  index=0;

	  for(i=0;i<num_samples;i++)
	    if((sampled_num_seg[i]-1)==model)
	      ret[index++]=sampled_a[i];
	}
    }

  if(num)
    *num=n;
  
  return ret;
}


double *bayes_multisegment_ratingcurve::get_sampled_b(int segment_no,
						      int model, 
						      int *num)
{
  if(num)
    *num=0;

  if(segment_no<0 || segment_no>model)
    return NULL;
  
  double *ret=NULL;
  int n=0,i;
  int index=0;
  for(i=0;i<num_samples;i++)
    if((sampled_num_seg[i]-1)==model)
      index++;
  n=index;

  if(n>0)
    {
      ret=new double[n];
      index=0;
      
      for(i=0;i<num_samples;i++)
	if((sampled_num_seg[i]-1)==model)
	  ret[index++]=sampled_b[i][segment_no];
    }

  if(num)
    *num=n;
  
  return ret;
}

double *bayes_multisegment_ratingcurve::get_sampled_h0(int segment_no,
						      int model,int *num)
{
  if(num)
    *num=0;

  if(segment_no<0 || segment_no>model)
    return NULL;
  
  double *ret=NULL;
  int n=0,i;
  int index=0;
  for(i=0;i<num_samples;i++)
    if((sampled_num_seg[i]-1)==model)
      index++;
  n=index;

  if(n>0)
    {
      ret=new double[n];
      index=0;
      
      for(i=0;i<num_samples;i++)
	if((sampled_num_seg[i]-1)==model)
	  ret[index++]=sampled_h0[i][segment_no];
    }

  if(num)
    *num=n;
  
  return ret;
}

double *bayes_multisegment_ratingcurve::get_sampled_hs(int segment_no,
						      int model,int *num)
{
  if(num)
    *num=0;

  if(segment_no<0 || segment_no>=model)
    return NULL;
  
  double *ret=NULL;
  int n=0,i;
  int index=0;
  for(i=0;i<num_samples;i++)
    if((sampled_num_seg[i]-1)==model)
      index++;
  n=index;

  if(n>0)
    {
      ret=new double[n];
      index=0;
      
      for(i=0;i<num_samples;i++)
	if((sampled_num_seg[i]-1)==model)
	  ret[index++]=sampled_hs[i][segment_no];
    }

  if(num)
    *num=n;
  
  return ret;
}

double *bayes_multisegment_ratingcurve::
get_sampled_sigma_squared(int  model, int *num)
{
  double *ret=NULL;
  int n=0,i;

  if(model<0)
    {
      n=num_samples;
      ret=new double[n];
      for(i=0;i<n;i++)
	ret[i]=sampled_s2[i];
    }
  else
    {
      int index=0;
      for(i=0;i<num_samples;i++)
	if((sampled_num_seg[i]-1)==model)
	  index++;
      n=index;

      if(n>0)
	{
	  ret=new double[n];
	  index=0;

	  for(i=0;i<num_samples;i++)
	    if((sampled_num_seg[i]-1)==model)
	      ret[index++]=sampled_s2[i];
	}
    }

  if(num)
    *num=n;
  
  return ret;
}

double *bayes_multisegment_ratingcurve::
get_sampled_sigma(int  model, int *num)
{
  double *ret=NULL;
  int n=0,i;

  if(model<0)
    {
      n=num_samples;
      ret=new double[n];
      for(i=0;i<n;i++)
	ret[i]=sqrt(sampled_s2[i]);
    }
  else
    {
      int index=0;
      for(i=0;i<num_samples;i++)
	if((sampled_num_seg[i]-1)==model)
	  index++;
      n=index;

      if(n>0)
	{
	  ret=new double[n];
	  index=0;

	  for(i=0;i<num_samples;i++)
	    if((sampled_num_seg[i]-1)==model)
	      ret[index++]=sqrt(sampled_s2[i]);
	}
    }

  if(num)
    *num=n;
  
  return ret;
}

double *bayes_multisegment_ratingcurve::
get_sampled_logprob(int  model, int *num)
{
  double *ret=NULL;
  int n=0,i;

  if(model<0)
    {
      n=num_samples;
      ret=new double[n];
      for(i=0;i<n;i++)
	ret[i]=sampled_logprob[i];
    }
  else
    {
      int index=0;
      for(i=0;i<num_samples;i++)
	if((sampled_num_seg[i]-1)==model)
	  index++;
      n=index;

      if(n>0)
	{
	  ret=new double[n];
	  index=0;

	  for(i=0;i<num_samples;i++)
	    if((sampled_num_seg[i]-1)==model)
	      ret[index++]=sampled_logprob[i];
	}
    }

  if(num)
    *num=n;
  
  return ret;
}


int bayes_multisegment_ratingcurve::get_number_of_measurements(void)
{
  return num_meas;
}

double *bayes_multisegment_ratingcurve::get_stage_measurements(void)
{
  return h;
}

double *bayes_multisegment_ratingcurve::get_logdischarge_measurements(void)
{
  return q;
}


double bayes_multisegment_ratingcurve::get_h_min(void)
{
  return hmin;
}

double bayes_multisegment_ratingcurve::get_h_max(void)
{
  return hmax;
}

// Fetches a sorted array of discharge drawings from
// the parameter drawings for a given stage value;
double *bayes_multisegment_ratingcurve::get_discharge_sample(double stage)
{
  if(qsample)
    delete [] qsample;

  qsample=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    qsample[i]=get_Q(stage, sampled_a[i], sampled_b[i],
		     sampled_hs[i], sampled_h0[i], sampled_num_seg[i]);

  qsort(qsample, size_t(num_samples), sizeof(double), compare_double);
  stage_of_qsample=stage;

  return qsample;
}

double *bayes_multisegment_ratingcurve::get_stage_sample(double discharge)
{
  if(hsample)
    delete [] hsample;

  hsample=new double[num_samples];
  for(int i=0;i<num_samples;i++)
    hsample[i]=get_h(discharge, sampled_a[i], sampled_b[i],
		     sampled_hs[i], sampled_h0[i], sampled_num_seg[i]);

  qsort(hsample, size_t(num_samples), sizeof(double), compare_double);
  discharge_of_hsample=discharge;

  return hsample;
}

// Fetch the mean (estimated expectation) discharge for a given stage
// or vice versa:
double bayes_multisegment_ratingcurve::get_mean_discharge(double stage)
{
  if(qsample==NULL || stage!=stage_of_qsample)
    get_discharge_sample(stage);
  
  double mean_q=find_statistics(qsample, num_samples, MEAN);

  return mean_q;
}

double bayes_multisegment_ratingcurve::get_mean_stage(double discharge)
{
  if(hsample==NULL || discharge!=discharge_of_hsample)
    get_stage_sample(discharge);
  
  double mean_h=find_statistics(hsample, num_samples, MEAN);

  return mean_h;
}


// Fetch a percentile (estimated quantile) for a given stage;
// (0<percentile<1)
double bayes_multisegment_ratingcurve::get_discharge_percentile(double stage, 
							double percentile)
{
  if(qsample==NULL || stage!=stage_of_qsample)
    get_discharge_sample(stage);
  
  double q_p=find_percentile(qsample, num_samples, percentile);

  return q_p;
}

double bayes_multisegment_ratingcurve::get_stage_percentile(double discharge, 
						    double percentile)
{
  if(hsample==NULL || discharge!=discharge_of_hsample)
    get_stage_sample(discharge);
  
  double h_p=find_percentile(hsample, num_samples, percentile);

  return h_p;
}

double bayes_multisegment_ratingcurve::get_mean_a(void)
{
  int num;
  double *a=get_sampled_a(best_model, &num);
  
  double ret=find_statistics(a, num, MEAN);

  delete [] a;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_mean_b(int segment_no)
{
  int num;
  double *b=get_sampled_b(segment_no,best_model, &num);
  
  double ret=find_statistics(b, num, MEAN);

  delete [] b;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_mean_h0(int segment_no)
{
  int num;
  double *h0=get_sampled_h0(segment_no,best_model, &num);
  
  double ret=find_statistics(h0, num, MEAN);

  delete [] h0;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_mean_hs(int segment_no)
{
  int num;
  double *hs=get_sampled_hs(segment_no,best_model, &num);
  
  double ret=find_statistics(hs, num, MEAN);

  delete [] hs;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_mean_s2(void)
{
  int num;
  double *s2=get_sampled_sigma_squared(best_model, &num);
  
  double ret=find_statistics(s2, num, MEAN);

  delete [] s2;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_var_a(void)
{
  int num;
  double *a=get_sampled_a(best_model, &num);
  
  double ret=find_statistics(a, num, VARIATION);

  delete [] a;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_var_b(int segment_no)
{
  int num;
  double *b=get_sampled_b(segment_no,best_model, &num);
  
  double ret=find_statistics(b, num, VARIATION);

  delete [] b;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_var_h0(int segment_no)
{
  int num;
  double *h0=get_sampled_h0(segment_no,best_model, &num);
  
  double ret=find_statistics(h0, num, VARIATION);

  delete [] h0;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_var_hs(int segment_no)
{
  int num;
  double *hs=get_sampled_hs(segment_no,best_model, &num);
  
  double ret=find_statistics(hs, num, VARIATION);

  delete [] hs;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_var_s2(void)
{
  int num;
  double *s2=get_sampled_sigma_squared(best_model, &num);
  
  double ret=find_statistics(s2, num, VARIATION);

  delete [] s2;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_median_a(void)
{
  int num;
  double *a=get_sampled_a(best_model, &num);
  
  double ret=find_statistics(a, num, MEDIAN);

  delete [] a;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_median_b(int segment_no)
{
  int num;
  double *b=get_sampled_b(segment_no,best_model, &num);
  
  double ret=find_statistics(b, num, MEDIAN);

  delete [] b;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_median_h0(int segment_no)
{
  int num;
  double *h0=get_sampled_h0(segment_no,best_model, &num);
  
  double ret=find_statistics(h0, num, MEDIAN);

  delete [] h0;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_median_hs(int segment_no)
{
  int num;
  double *hs=get_sampled_hs(segment_no,best_model, &num);
  
  double ret=find_statistics(hs, num, MEDIAN);

  delete [] hs;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_median_s2(void)
{
  int num;
  double *s2=get_sampled_sigma_squared(best_model, &num);
  
  double ret=find_statistics(s2, num, MEDIAN);

  delete [] s2;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_a_percentile(double percentile)
{
  int num;
  double *a=get_sampled_a(best_model, &num);
  
  double ret=find_percentile(a, num, percentile);

  delete [] a;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_b_percentile(double percentile, 
							int segment_no)
{
  int num;
  double *b=get_sampled_b(segment_no,best_model, &num);
  
  double ret=find_percentile(b, num, percentile);

  delete [] b;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_h0_percentile(double percentile, 
							 int segment_no)
{
  int num;
  double *h0=get_sampled_h0(segment_no,best_model, &num);
  
  double ret=find_percentile(h0, num, percentile);

  delete [] h0;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_hs_percentile(double percentile, 
							 int segment_no)
{
  int num;
  double *hs=get_sampled_hs(segment_no,best_model, &num);
  
  double ret=find_percentile(hs, num, percentile);

  delete [] hs;
  
  return ret;
}

double bayes_multisegment_ratingcurve::get_s2_percentile(double percentile)
{
  int num;
  double *s2=get_sampled_sigma_squared(best_model, &num);
  
  double ret=find_percentile(s2, num, percentile);

  delete [] s2;
  
  return ret;
}

double bayes_multisegment_ratingcurve::
get_mean_coefficient_discharge(double stage)
{
  return get_Q(stage, a_mean, b_mean, hs_mean, h0_mean, best_model_numseg);
}

double bayes_multisegment_ratingcurve::
get_mean_coefficient_stage(double discharge)
{
  return get_h(discharge, a_mean, b_mean, hs_mean, h0_mean, best_model_numseg);
}

double bayes_multisegment_ratingcurve::
get_median_coefficient_discharge(double stage)
{
  return get_Q(stage, a_median, b_median, hs_median, h0_median, 
	       best_model_numseg);
}

double bayes_multisegment_ratingcurve::
get_median_coefficient_stage(double discharge)
{
  return get_h(discharge, a_median, b_median, hs_median, h0_median, 
	       best_model_numseg);
}


double bayes_multisegment_ratingcurve::get_rw_h0(int model, int segment_no)
// get the adapted RW step length
{
  return rw_h0[model][segment_no];
}

double bayes_multisegment_ratingcurve::get_rw_hs(int model, int segment_no)
// get the adapted RW step length
{
  return rw_hs[model][segment_no];
}

double bayes_multisegment_ratingcurve::
get_prior_a_mean(int model)
{
  return a_m[model];
}

double bayes_multisegment_ratingcurve::
get_prior_a_sdev(int model)
{
  return a_s[model];
}

double bayes_multisegment_ratingcurve::
get_prior_b_mean(int model, int segment_no)
{
  return b_m[model][segment_no];
}

double bayes_multisegment_ratingcurve::
get_prior_b_sdev(int model, int segment_no)
{
  return b_s[model][segment_no];
}

double bayes_multisegment_ratingcurve::
get_prior_h0_mean(int model, int segment_no)
{
  if(h0_m)
    return h0_m[model][segment_no];
  else if(segment_no==0)
    return mu_h01;
  else
    return MISSING_VALUE;
}

double bayes_multisegment_ratingcurve::
get_prior_h0_sdev(int model, int segment_no)
{
  if(h0_s)
    return h0_s[model][segment_no];
  else if(segment_no==0)
    return sd_h01;
  else
    return MISSING_VALUE;
}

double bayes_multisegment_ratingcurve::
get_prior_hs_mean(int model, int segment_no)
{
  if(hs_m && segment_no>=0 && segment_no<model)
    return hs_m[model][segment_no];
  else
    return MISSING_VALUE;
}

double bayes_multisegment_ratingcurve::
get_prior_hs_sdev(int model, int segment_no)
{
  if(hs_s && segment_no>=0 && segment_no<model)
    return hs_s[model][segment_no];
  else
    return MISSING_VALUE;
}

double bayes_multisegment_ratingcurve::
get_prior_a_b_correlation(int model)
{
  return ab_corr[model];
}

double bayes_multisegment_ratingcurve::
get_sigma_a(void)
{
  return sigma_a;
}

double bayes_multisegment_ratingcurve::
get_sigma_b(void)
{
  return sigma_b;
}

// get the prior variance matrix used internally
double **bayes_multisegment_ratingcurve::
get_var(int model) 
{
  return var[model];
}

// get the prior inverse variance matrix used internally
double **bayes_multisegment_ratingcurve::
get_inv_var(int model)
{
  return inverse_matrix(var[model], model+2);
} 




// ********************************************
//
//             BAYES_GENERATE_RATINGCURVE
//
// A module for generating a rating curve
// segment using bayesian regression.
//
//                Trond Reitan
//                   5/3-2004
//
// ********************************************

#include <cmath>
#include <hydrasub/hydrabase/linalg.H>
#include <gsl/gsl_sf_bessel.h>

void bayes_generate_segment::init(void)
{
  prior_x0=acc_post_x0=post_x0=x0=discharge=stage=NULL;
  reg_x0=NULL;
  num_x0=num_meas=maxprob_index=0;
}

void bayes_generate_segment::cleanup(void)
{
  if(acc_post_x0)
    delete [] acc_post_x0;
  if(prior_x0)
    delete [] prior_x0;
  if(post_x0)
    delete [] post_x0;
  if(x0)
    delete [] x0;
  if(stage)
    delete [] stage;
  if(discharge)
    delete [] discharge;
  if(reg_x0)
    {
      for(int i=0;i<num_x0;i++)
	if(reg_x0[i])
	  delete reg_x0[i];
      delete [] reg_x0;
    }

  init();
}

bayes_generate_segment::bayes_generate_segment()
{
  init();
}

bayes_generate_segment::~bayes_generate_segment()
{
  cleanup();
}

void bayes_generate_segment::create(double *stage_, double *discharge_, 
				    int nummeas, bool semi_informative_c)
{
  int numx0=1000, i;
  double *probx0=new double[numx0];
  double *x0buffer=new double[numx0];
  double scale=0.0;
  double minstage=find_statistics(stage_, nummeas, MIN);

  for(i=0;i<numx0;i++)
    {
      if(semi_informative_c)
	probx0[i]=1.0/double(numx0-i);
      else
	probx0[i]=1.0;
      x0buffer[i]=minstage-20.0+20.0*double(i)/double(numx0);
      
      scale+=probx0[i];
    }
  
  for(i=0;i<numx0;i++)
    probx0[i]/=scale;
  
  create(stage_, discharge_, nummeas, probx0, x0buffer, numx0,
	 2.5, /*0.75*/ 1.0, 2.6, 1.3, 4.0, 0.03);
  
  delete [] x0buffer;
  delete [] probx0;
}


void bayes_generate_segment::create(double *stage_, double *discharge_, 
				    int nummeas, // measurements
				    double *prob_x0, double *x0_, 
				    int numx0, // prior x0
				    double est_exp_, 
				    double sdev_exp_, // prior exponent
				    double est_logconst_, 
				    double sdev_logconst_, // prior log const.
				    // prior of sigma�~neggamma(a,b)
				    double sigma_a_, double sigma_b_) 
{
  int i,j;

  cleanup();

  // storing the measurements;
  num_meas=nummeas;
  stage=new double[num_meas];
  discharge=new double[num_meas];
  double *q=new double[num_meas];
  for(i=0;i<num_meas;i++)
    {
      stage[i]=stage_[i];
      discharge[i]=discharge_[i];
      q[i]=log(discharge_[i]);
    }

  // storing priors;
  sigma_a=sigma_a_;
  sigma_b=sigma_b_;
  est_logconst=est_logconst_;
  sdev_logconst=sdev_logconst_;
  est_exp=est_exp_;
  sdev_exp=sdev_exp_;
  
  hm=find_statistics(stage_, nummeas, MIN);
  
  // warmup to the regression;
  double *mean=new double[2];
  double **var=new double*[2];
  var[0]=new double[2];
  var[1]=new double[2];
  mean[0]=est_logconst;
  mean[1]=est_exp;
  var[0][0]=sdev_logconst*sdev_logconst*(2.0*sigma_a-2.0); ///sigma_b;
  var[1][1]=sdev_exp*sdev_exp*(2.0*sigma_a-2.0); ///sigma_b;
  var[0][1]=var[1][0]=-0.2*sqrt(var[0][0]*var[1][1]);
  double **X=new double*[2];
  X[0]=new double[num_meas];
  X[1]=new double[num_meas];
  for(i=0;i<num_meas;i++)
    X[0][i]=1.0;
  
  num_x0=numx0;
  prior_x0=new double[num_x0];
  post_x0=new double[num_x0];
  x0=new double[num_x0];
  reg_x0=new bayesian_regression*[num_x0];
  
  double max_log_likelihood=MISSING_VALUE;
  double maxprob=0.0;
  
  maxprob_x0=MISSING_VALUE;
  maxprob_index=0;
  
  for(i=0;i<num_x0;i++)
    {
      prior_x0[i]=prob_x0[i];
      x0[i]=x0_[i];
      post_x0[i]=0.0;
      
      if(prior_x0[i]>0.0)
	{
	  for(j=0;j<num_meas;j++)
	    X[1][j]=stage[j]>x0[i] ? log(stage[j]-x0[i]) : 0.0;
	  
	  reg_x0[i]=get_bayesian_regression(X, 2, q, num_meas, 
					    mean, var, sigma_a, sigma_b);  
	  
	  double loglik=reg_x0[i]->probability_density_of_data(true);
	  
	  if(max_log_likelihood==MISSING_VALUE ||
	     max_log_likelihood<loglik)
	    max_log_likelihood=loglik;
	}
      else
	reg_x0[i]=NULL;
    }

  double scale=0.0;
  for(i=0;i<num_x0;i++)
    {
      if(reg_x0[i])
	post_x0[i]=prior_x0[i]*
	  reg_x0[i]->probability_density_of_data(false,max_log_likelihood);
      else
	post_x0[i]=0.0;

      scale += post_x0[i];
    }
  
  acc_post_x0=new double[num_x0];
  for(i=0;i<num_x0;i++)
    {
      post_x0[i]/=scale;
  
      if(post_x0[i]>maxprob)
	{
	  maxprob=post_x0[i];
	  maxprob_x0=x0[i];
	  maxprob_index=i;
	}

      if(i==0)
	acc_post_x0[i]=post_x0[i];
      else
	acc_post_x0[i]=acc_post_x0[i-1]+post_x0[i];
    }

  //maxprob_x0=x0[maxprob_index];
  maxprob_exp=reg_x0[maxprob_index]->get_mean_coefficient(1);
  maxprob_logconst=reg_x0[maxprob_index]->get_mean_coefficient(0);

  //cout << maxprob_index << " " << x0[maxprob_index] << " exp=" << 
  //reg_x0[maxprob_index]->get_mean_coefficient(1) << endl;

  maxprob_sdev_exp=sqrt(reg_x0[maxprob_index]->
			get_covariance_coefficient(1,1));
  maxprob_sdev_logconst=sqrt(reg_x0[maxprob_index]->
			     get_covariance_coefficient(0,0));

  mean_x0=0.0;
  sdev_x0=0.0;
  for(i=0;i<num_x0;i++)
    mean_x0+=x0[i]*post_x0[i];
  for(i=0;i<num_x0;i++)
    sdev_x0+=(x0[i]-mean_x0)*(x0[i]-mean_x0)*post_x0[i];
  sdev_x0=sdev_x0>0.0 ? sqrt(sdev_x0) : 0.0;
}

double bayes_generate_segment::prior_sigma_a(void)
{
  return sigma_a;
}

double bayes_generate_segment::prior_sigma_b(void)
{
  return sigma_b;
}

double bayes_generate_segment::prior_exp(void)
{
  return est_exp;
}

double bayes_generate_segment::prior_logconst(void)
{
  return est_logconst;
}

double bayes_generate_segment::prior_sdev_exp(void)
{
  return sdev_exp;
}

double bayes_generate_segment::prior_sdev_logconst(void)
{
  return sdev_logconst;
}

double *bayes_generate_segment::get_cumulative_x0_probability(void)
{
  return acc_post_x0;
}

double *bayes_generate_segment::get_x0_probability(bool posteriori)
{
  if(posteriori)
    return post_x0;
  else
    return prior_x0;
}

bayesian_regression **bayes_generate_segment::get_x0_specific_regression(void)
{
  return reg_x0;
}

double *bayes_generate_segment::get_stage(void)
{
  return stage;
}

double *bayes_generate_segment::get_discharge(void)
{
  return discharge;
}

double *bayes_generate_segment::get_x0(void)
{
  return x0;
}


int bayes_generate_segment::get_number_of_x0(void)
{
  return num_x0;
}

int bayes_generate_segment::get_number_of_measurements(void)
{
  return num_meas;
}

double bayes_generate_segment::get_hmin(void)
{
  return hm;
}

double bayes_generate_segment::get_maxprob_x0(void)
{
  return maxprob_x0;
}

double bayes_generate_segment::get_x0_sdev(void)
{
  return sdev_x0;
}

double bayes_generate_segment::get_maxprob_exp(void)
{
  return maxprob_exp;
}

double bayes_generate_segment::get_maxprob_exp_sdev(void)
{
  return maxprob_sdev_exp;
}

double bayes_generate_segment::get_maxprob_logconst(void)
{
  return maxprob_logconst;
}

double bayes_generate_segment::get_maxprob_logconst_sdev(void)
{
  return maxprob_sdev_logconst;
}

double bayes_generate_segment::get_estimated_discharge(double stagevalue)
{
  int i;
  double dis=0.0;
  double predictor[2];
  
  predictor[0]=1.0;
  
  for(i=0;i<num_x0;i++)
    {
      if(stagevalue>x0[i] && post_x0[i]>0.0 && reg_x0[i])
	{
	  double x=log(stagevalue-x0[i]);
	  double a=reg_x0[i]->get_mean_coefficient(0);
	  double b=reg_x0[i]->get_mean_coefficient(1);
	  //double d=2.0*reg_x0[i]->get_sigma_a();
	  //double nu=d/2.0;
	  //double **V=reg_x0[i]->get_V();
	  //double ki_V_ki=sqrt(V[0][0]+x*(V[1][0]+V[0][1])+x*x*V[1][1]);
	  double qm=exp(a+b*x);
	  double mod1=1.0, mod2=1.0;

	  /*
	  if(ki_V_ki>1e-10)
	    {
	      mod1=gsl_sf_bessel_Knu(nu, ki_V_ki);
	      mod2=pow(ki_V_ki, -nu)*pow(2.0, nu-1.0)*
		exp(lgamma(nu));
		} */
	  
	  dis+=post_x0[i]*qm*mod1/mod2;
	  
	  //predictor[1]=log(stagevalue-x0[i]);
	  //dis+=post_x0[i]*exp(reg_x0[i]->predict(predictor));
	  //dis+=post_x0[i]*exp(a)*pow(stagevalue-x0[i], b);
	}
    }
  
  return dis;
}

// Sample from a normal approximation of (a,log(b),log(hm-h0),log(sigma�))
// and make estimates from that for a given mean and covariance;
double **bayes_generate_segment::sample_coefficients(int sample_size, 
						     double *mean, 
						     double **cov)
{
  int i;
  // make a matrix and vector out of this;
  Matrix sigma(cov,4,4);
  vector mu(mean,4);
  
  // Sample from a multinormal distribution having the
  // found mean and covariance;
  vector **normal_samples=vectorial_sample_from_multinormal(sample_size, mu, sigma);
  double **coef=new double*[4];
  for(i=0;i<4;i++)
    coef[i]=new double[sample_size];
  
  // Put this into a coefficient array of arrays while transforming back;
  for(i=0;i<sample_size;i++)
    {
      coef[0][i]=normal_samples[i][0](0);
      coef[1][i]=exp(normal_samples[i][0](1));
      coef[2][i]=hm-exp(normal_samples[i][0](2));
      coef[3][i]=exp(normal_samples[i][0](3));
    }

  for(i=0;i<sample_size;i++)
    delete normal_samples[i];
  delete [] normal_samples;
  
  return coef;
}


// Returns a sample from the distribution of a(=log(C)),b,x0 and sigma�
// and returns it as an array of array with array 0=samples from a,
// 1=b, 2=c and 3=sigma�. 
double **bayes_generate_segment::sample_coefficients(int sample_size,
						     bool 
						     normal_approximation)
{
  if(normal_approximation)
    {
      double *m, **v;

      m=find_moments(&v);
      double **coef=sample_coefficients(sample_size, m,v);

      doubledelete(v,4);
      delete [] m;
      
      return coef;
    }

  double **coef=new double*[4];
  int i,k;

  for(i=0;i<4;i++)
    coef[i]=new double[sample_size];

  for(i=0;i<sample_size;i++)
    {
      double rand=drand48();
      double **sampled_coefficient=NULL;
      
      for(k=0;k<num_x0;k++)
	if(rand<acc_post_x0[k])
	  break;
      coef[2][i]=x0[k];

      if(k<num_x0 && reg_x0[k])
	{
	  sampled_coefficient=reg_x0[k]->sample_coefficients(1, true);
	  coef[0][i]=sampled_coefficient[0][0];
	  coef[1][i]=sampled_coefficient[1][0];
	  coef[3][i]=sampled_coefficient[2][0];
	}
    }
  
  return coef;
}

// Make estimates from an external coefficient sample;
double *bayes_generate_segment::sample_estimates(double stagevalue, 
						 int sample_size,
						 double **coefficient_sample)
{
  double x=stagevalue;
  double *qsamples=new double[sample_size];
  double **coef=coefficient_sample;

  for(int i=0;i<sample_size;i++)
    if(x>coef[2][i])
      qsamples[i]=exp(coef[0][i]+coef[1][i]*log(x-coef[2][i]));
    else
      qsamples[i]=0.0;
    
  return qsamples;
}

// Sample estimates directly;
double *bayes_generate_segment::sample_estimates(double stagevalue, 
						 int sample_size,
						 bool indirect_sampling)
{
  double x=stagevalue;
  double *estimates=new double[sample_size];
  int i,k;
  double predictor[2];

  predictor[0]=1.0;

  for(i=0;i<sample_size;i++)
    {
      double rand=drand48();
      double *sampled_estimate=NULL;
      
      for(k=0;k<num_x0;k++)
	if(rand<acc_post_x0[k])
	  break;
      
      if(k<num_x0 && x>x0[k] && reg_x0[k])
	{
	  predictor[1]=log(x-x0[k]);
	  sampled_estimate=reg_x0[k]->sample_estimates(predictor, 1,
						       true,
						       indirect_sampling);
	}
      
      if(sampled_estimate)
	{
	  estimates[i]=exp(sampled_estimate[0]);
	  delete [] sampled_estimate;
	}
      else
	estimates[i]=0.0;
    }

  qsort(estimates, size_t(sample_size), sizeof(double), compare_double);

  return estimates;
}

double bayes_generate_segment::get_lower_discharge(double stagevalue, 
						   double credibility,
						   int sample_size,
						   bool indirect_sampling)
{
  double *estimates=sample_estimates(stagevalue, sample_size,
				     indirect_sampling);
  int lower_index=(int) (double(sample_size)*(1.0-credibility)/2.0);
  double lower=estimates[lower_index];
  delete [] estimates;

  return lower;
}

double bayes_generate_segment::get_upper_discharge(double stagevalue, 
						   double credibility,
						   int sample_size,
						   bool indirect_sampling)
{
  double *estimates=sample_estimates(stagevalue, sample_size,
				     indirect_sampling);
  int upper_index=(int) (double(sample_size)-1.0-
			 double(sample_size)*(1.0-credibility)/2.0);
  double upper=estimates[upper_index];
  delete [] estimates;

  return upper;
}


double bayes_generate_segment::get_credibility(double stagevalue, 
					       double dischargevalue,
					       int sample_size)
{
  double cred, *estimates=sample_estimates(stagevalue, sample_size);
  int i;

  for(i=0;i<sample_size;i++)
    if(dischargevalue<estimates[i])
      break;
  
  if(i<sample_size/2)
    cred=double(i+1)/double(sample_size/2);
  else
    cred=double(sample_size+1-i)/double(1+sample_size/2);

  delete [] estimates;

  return cred;
}

double bayes_generate_segment::get_zeropoint_credibility(double stagevalue)
{
  double cred;
  int i;

  for(i=0;i<num_x0-1;i++)
    if(x0[i]<stagevalue && x0[i+1]>stagevalue)
      break;
  
  cred=acc_post_x0[i];
  if(cred>0.5)
    cred=1.0-cred;

  cred*=2.0;
  
  return cred;
}

double bayes_generate_segment::get_lower_x0(double credibility)
{
  for(int i=0;i<num_x0-1;i++)
    if(acc_post_x0[i]<0.5*(1.0-credibility) && 
       acc_post_x0[i+1]>=0.5*(1.0-credibility))
      return x0[i];
  
  return MISSING_VALUE;
}

double bayes_generate_segment::get_upper_x0(double credibility)
{
  for(int i=0;i<num_x0-1;i++)
    if((1.0-acc_post_x0[i])>0.5*(1.0-credibility) && 
       (1.0-acc_post_x0[i+1])<=0.5*(1.0-credibility))
      return x0[i];
  
  return MISSING_VALUE;
}

double bayes_generate_segment::get_maxprob_discharge(double stagevalue)
{
  double predictor[2];

  predictor[0]=1.0;
  predictor[1]=stagevalue>x0[maxprob_index] ?
    log(stagevalue-x0[maxprob_index]) : 0.0;

  if(stagevalue>x0[maxprob_index])
    return exp(reg_x0[maxprob_index]->predict(predictor));
  else
    return 0.0;
}

double bayes_generate_segment::get_maxprob_lower_discharge(double stagevalue,
							   double credibility)
{
  double predictor[2];

  predictor[0]=1.0;
  predictor[1]=stagevalue>x0[maxprob_index] ? 
    log(stagevalue-x0[maxprob_index]) : 0.0;

  if(stagevalue>x0[maxprob_index])
    return exp(reg_x0[maxprob_index]->lower_estimate_credibility(predictor,
								 credibility));
  else
    return 0.0;
}

double bayes_generate_segment::get_maxprob_upper_discharge(double stagevalue,
							   double credibility)
{
  double predictor[2];

  predictor[0]=1.0;
  predictor[1]=stagevalue>x0[maxprob_index] ? 
    log(stagevalue-x0[maxprob_index]) : 0.0;

  if(stagevalue>x0[maxprob_index])
    return exp(reg_x0[maxprob_index]->upper_estimate_credibility(predictor,
								 credibility));
  else
    return 0.0;
}

// Returns mean and covariance matrix for a,log(b) or b,log(hm-h0) or h0 
// and log(sigma�);
double *bayes_generate_segment::find_moments(double ***cov_pointer,
					     bool log_b, bool log_hm_h0)
{
  // Prepare estimated distribution;
  int i,j,numsamples=100000;
  double **coef=sample_coefficients(numsamples);
  double **coef2=new double*[4];
  int numsamples2=0;
  
  for(i=0;i<4;i++)
    coef2[i]=new double[numsamples];

  // Transform the coefficient sample arrays;
  j=0;
  for(i=0;i<numsamples;i++)
    if((coef[1][i]>0.0 || !log_b) && coef[3][i]>0.0 && 
       ((hm-coef[2][i])>0.0 || !log_hm_h0))
      {
	coef2[0][j]=coef[0][i];
	if(log_b)
	  coef2[1][j]=log(coef[1][i]);
	else
	  coef2[1][j]=coef[1][i];
	if(log_hm_h0)
	  coef2[2][j]=log(hm-coef[2][i]);
	else
	  coef2[2][j]=coef[2][i];
	coef2[3][j]=log(coef[3][i]);
	j++;
      }
  numsamples2=j;
  
  // Put the samples into an array of vectors
  double *vbuffer=new double[4];
  vector *samples=new vector[numsamples2];
  for(i=0;i<numsamples2;i++)
    {
      for(j=0;j<4;j++)
	vbuffer[j]=coef2[j][i];
      vector X(vbuffer,4);

      samples[i]=X;
    }
  
  Matrix covariance;
  vector mean;
  
  // Find mean and covariance matrix of the samples;
  mean=find_mean_vector(numsamples2, samples);
  covariance=find_estimated_sigma_matrix(numsamples2, samples, mean);

  delete [] vbuffer;
  delete [] samples;
  doubledelete(coef,4);
  doubledelete(coef2,4);

  double *meanarray=mean.get_as_double_array();
  double **cov=covariance.export_to_double();
  
  *cov_pointer=cov;

  return meanarray;
}
  


double *bayes_generate_segment::
compare_with_competing_models(bayesian_regression **competing_regs,
			      double *competing_priors, int num_competing)
{
  double maxloglik=MISSING_VALUE;
  int i=0;
  double sum_external=0.0;
  
  for(i=0;i<num_competing;i++)
    sum_external=competing_priors[i];
  
  for(i=0;i<num_x0;i++)
    if(post_x0[i] && reg_x0[i])
      {
	double loglik=reg_x0[i]->probability_density_of_data(true);
	
	  if(maxloglik==MISSING_VALUE || 
	     loglik>maxloglik)
	    maxloglik=loglik;
      }
  
  for(i=0;i<num_competing;i++)
    if(competing_priors[i] && competing_regs[i])
      {
	double loglik=competing_regs[i]->probability_density_of_data(true);
	
	if(maxloglik==MISSING_VALUE || 
	   loglik>maxloglik)
	  maxloglik=loglik;
      }
    
  double *internal_likelihoods=new double[num_x0];
  double *external_likelihoods=new double[num_competing];
  double *post_internal=new double[num_x0];
  double *post_external=new double[num_competing];
  double scale=0.0;
  
  for(i=0;i<num_x0;i++)
    if(post_x0[i] && reg_x0[i])
      internal_likelihoods[i]=
	reg_x0[i]->probability_density_of_data(false,maxloglik);
    else
      internal_likelihoods[i]=0.0;

  for(i=0;i<num_competing;i++)
    if(competing_priors[i] && competing_regs[i])
      external_likelihoods[i]=
	competing_regs[i]->probability_density_of_data(false,maxloglik);
    else
      external_likelihoods[i]=0.0;

  for(i=0;i<num_x0;i++)
    {
      post_internal[i]=(1.0-sum_external)*prior_x0[i]*internal_likelihoods[i];
      scale+=post_internal[i];
    }

  for(i=0;i<num_competing;i++)
    {
      post_external[i]=competing_priors[i]*external_likelihoods[i];
      scale+=post_external[i];
    }

  for(i=0;i<num_x0;i++)
    post_internal[i]/=scale; // ... just for show
  for(i=0;i<num_competing;i++) // this one's important
    post_external[i]/=scale;  // (Bayes formula)

  delete [] internal_likelihoods;
  delete [] external_likelihoods;
  delete [] post_internal;

  return post_external;
}
