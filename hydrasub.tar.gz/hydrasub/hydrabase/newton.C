/*
 * $Id: newton.C 2576 2015-10-22 07:09:28Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/newton.C $
 */



// ************************************************* //
//                                                   //
//               NEWTON                              //
//                                                   //
// Newton's method for finding the argument where    //
// A function value is zero, as well as extreme      //
// value points (where the derivated is zero).       //
// Uses the GSL library for matrix inversion         //
// for multi-parameter functions.                    //
//                                                   //
//              Trond Reitan                         //
//               1/10-2002                           //
//                                                   //
// ************************************************* //



#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/linalg.H>
#include <hydrasub/hydrabase/divfunc.H>
#include <cmath>

#ifdef GSL
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_vector.h>
#endif // GSL



// Newtons method for a function with non-specified derivated.
// Calculates the derivated numerically
// Parameters; func  - the function
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             func_value - The value the function should have
//             steplength - The speed of the operation. In standard
//                          newton's method this value should be 1.0
//                          0.5 chosen for stability
double newtons_method(double (*func)(double), double start, double enddiff, 
		      int &maxiter, double func_value, double steplength, 
		      double minvalue,double maxvalue)
{
  double x=start, stepsize=steplength;
  int i=0;

  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && ABSVAL(((*func)(x) - func_value))>enddiff)
    {
      // Calculate the numeric derivative;
      double df = (((*func)(x+enddiff/20.0))-((*func)(x-enddiff/20.0)))/
	(enddiff/10.0);

      double step=(((*func)(x))-func_value)/df;
      
      if(minvalue!=MISSING_VALUE || maxvalue!=MISSING_VALUE)
	while((minvalue!=MISSING_VALUE && x-stepsize*step<=minvalue) ||
	      (maxvalue!=MISSING_VALUE && x-stepsize*step>=maxvalue))
	  stepsize/=2.0;
      // calculate the next argument from that;
      x = x - stepsize*step;
      stepsize=steplength;
      
      i++; // update the index
    }
  
  maxiter=i; // set the number of iterations used

  return x; // return the argument
}

double *multi_newtons_method(double*(*func)(double *), int dimension,
			     double *start, double enddiff, 
			     int &maxiter, double *func_value, double steplength,
			     double maxstep)
{
  double *x=new double[dimension];
  int i=0,j,k,l;

  for(j=0;j<dimension;j++)
    x[j]=start[j];
  
  double SS=0.0;
  double *currval=(*func)(x);
  for(j=0;j<dimension;j++)
    SS+=ABSVAL((currval[j]-func_value[j]));
  delete [] currval;

  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && SS>enddiff)
    {
      // Calculate the numeric derivative;
      double **df = new double*[dimension];
      for(j=0;j<dimension;j++)
	df[j]=new double[dimension];
      
      for(j=0;j<dimension;j++)
	for(k=0;k<dimension;k++)
	  {
	    double *x1=new double[dimension], *x2=new double[dimension];
	    
	    for(l=0;l<dimension;l++)
	      x1[l]=x2[l]=x[l];
	    x1[j]+=enddiff/20.0;
	    x2[j]-=enddiff/20.0;
	    
	    double *currval1=(*func)(x1);
	    double *currval2=(*func)(x2);
	    df[k][j]=(currval1[k]-currval2[k])/
	      (enddiff/10.0);
	    
	    delete [] x1;
	    delete [] x2;
	    delete [] currval1;
	    delete [] currval2;
	  }
      
      double **inv_df=inverse_matrix(df,dimension);  
      
      currval=(*func)(x);
      // calculate the next argument from that;
      double maxincrement=0.0;
      for(j=0;j<dimension;j++)
	for(k=0;k<dimension;k++)
	  {
	    double absincrement=abs(steplength*inv_df[j][k]*(currval[k]-func_value[k]));
	    if(maxincrement<absincrement)
	      maxincrement=absincrement;
	  }

      for(j=0;j<dimension;j++)
	for(k=0;k<dimension;k++)
	  {
	    double increment=steplength*inv_df[j][k]*(currval[k]-func_value[k]);
	    
	    if(maxincrement>maxstep)
	      x[j] -= increment/maxincrement * maxstep;
	    else
	      x[j] -= increment;
	  }
      delete [] currval;
      
      //printf("%f %f %f %f\n", exp(x[0]), exp(x[1]), exp(x[2]), exp(x[3]));  

      currval=(*func)(x);
      SS=0.0;
      for(j=0;j<dimension;j++)
	SS+=ABSVAL((currval[j]-func_value[j]));
      delete [] currval;

      i++; // update the index

      doubledelete(df,dimension);
      doubledelete(inv_df,dimension);
    }

  maxiter=i; // set the number of iterations used

  return x; // return the argument
}



// Newtons method for a function with specified derivated.
// Parameters; func  - the function
//             derivated - the derivated function
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             func_value - The value the function should have
//             steplength - The speed of the operation. In standard
//                          newton's method this value should be 1.0
//                          0.5 chosen for stability
double newtons_method(double (*func)(double), double (*derivated)(double), 
		      double start, double enddiff, 
		      int &maxiter, double func_value, double steplength)
{
  double x=start;
  int i=0;

  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && ABSVAL(((*func)(x) - func_value))>enddiff)
    {
      // Fetch the derivative;
      double df = (*derivated)(x);

      // calculate the next argument from that;
      x = x - steplength*(((*func)(x))-func_value)/df;

      i++; // update the index
    }

  maxiter=i; // set the number of iterations used

  return x; // return the argument
}



// Newton Raphsons method for finding extremes of a function
// Parameters; func  - the function
//             derivated - the derivated function
//             doublederivated - the derivation of the derivated
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             do_min  - Indicates wether a minumum (true) or
//                       a maximum (false) is sought
double newtonraphson(double (*func)(double), double (*derivated)(double), 
		     double (*doublederivated)(double), 
		     double start, double enddiff, 
		     int &maxiter, bool do_min)
{
  double x=start;
  int i=0;

  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && ABSVAL(((*derivated)(x)))>enddiff)
    {
      double steplength=1.0; // start by standard (Newton-Raphosn) steplength
      double x1=x; // fetch the argument
      double fval=(*func)(x); // fetch the function value
      int j=0;
      // Fetch the double derivative;
      double ddf = (*doublederivated)(x);
      // Fetch the derivative; 
      double df= (*derivated)(x);

      // loop while the new function value is less desirable than the 
      // previous one;
      do 
	{
	  x1 = x - steplength*df/ddf; // try a new Newton-Raphosn-argument
	  steplength/=-2.0; // look to both sides in smaller and smaller areas
	  j++; 
	} while(((do_min && (*func)(x1)>fval) || 
		 (!do_min && (*func)(x1)<fval)) &&
		j<maxiter);
      x=x1; // set the argument to the one recently calculated

      i++; // update the index
    }
  
  maxiter=i; // set the number of iterations
  
  return x;  // return the argument
}



// Newton Raphsons method for finding extremes of a function
// Double derivated is calculated numerically
// Parameters; func  - the function
//             derivated - the derivated function
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             do_min  - Indicates wether a minumum (true) or
//                       a maximum (false) is sought
double newtonraphson(double (*func)(double), double (*derivated)(double), 
		     double start, double enddiff, 
		     int &maxiter, bool do_min)
{
  double x=start;
  int i=0;

  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && ABSVAL(((*derivated)(x)))>enddiff)
    {
      double steplength=1.0;// start by standard (Newton-Raphosn) steplength
      double x1=x; // fetch the argument
      double fval=(*func)(x); // fetch the function value
      int j=0;
      // Calculate the double derivative numerically;
      double ddf = ((*derivated)(x+enddiff/20.0)-
		    (*derivated)(x-enddiff/20.0)) / (enddiff/10.0);
      // Fetch the derivative;
      double df= (*derivated)(x);

      // loop while the new function value is less desirable than the 
      // previous one;
      do
	{
	  x1 = x - steplength*df/ddf;// try a new Newton-Raphosn-argument
	  steplength/=-2.0; // look to both sides in smaller and smaller areas
	  j++;
	} while(((do_min && (*func)(x1)>fval) || 
		 (!do_min && (*func)(x1)<fval)) 
		&& j<maxiter);
      x=x1; // set the argument to the one recently calculated

      i++; // update the index
    }
  
  maxiter=i; // set the number of iterations
  
  return x;  // return the argument
}



// Newton Raphsons method for finding extremes of a function
// Derivated and double derivated is calculated numerically
// Parameters; func  - the function
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             do_min  - Indicates wether a minumum (true) or
//                       a maximum (false) is sought
double newtonraphson(double (*func)(double), double start, double enddiff, 
		     int &maxiter, bool do_min, double *doubleder)
{
  double x=start;
  int i=0;
  // Calculate the derivative numerically;
  double d1=(*func)(x+enddiff/20.0), d2=(*func)(x-enddiff/20.0);
  double df=(d1-d2) / (enddiff/10.0);  
  double ddf = 0.0;
  
  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && ABSVAL(df)>enddiff)
    {
      double steplength=1.0; // start with standard step length
      double x1=x; // fetch the argument
      double fval=(*func)(x); // fetch the function value
      int j=0;
      // Calculate the derivate numerically;
      df= ((*func)(x+enddiff/20.0)-
	   (*func)(x-enddiff/20.0)) / (enddiff/10.0);
      // Calculate two more derivative in the vicinity;
      double df1= ((*func)(x+enddiff/10.0)-(*func)(x)) / (enddiff/10.0);
      double df2= ((*func)(x)- (*func)(x-enddiff/10.0)) / (enddiff/10.0);
      // Calculate the double derivative numerically from that;
      double ddf=(df1-df2)/(enddiff/10.0);
      
      // loop while the new function value is less desirable than the 
      // previous one;
      do
	{
	  x1 = x - steplength*df/ddf;// try a new Newton-Raphosn-argument
	  steplength/=-2.0; // look to both sides in smaller and smaller areas
	  j++;
	} while(((do_min && (*func)(x1)>fval) || 
		 (!do_min && (*func)(x1)<fval)) 
		&& j<maxiter);
      x=x1; // set the argument to the one recently calculated

      i++; // update the index
    }
  
  if(doubleder)
    *doubleder=ddf;
  
  maxiter=i; // set the number of iterations
  
  return x;  // return the argument
}



// Newton Raphsons method for finding extremes of a multivariate function
// Parameters; func  - the function
//             derivated - the derivated function array
//             doublederivated - the derivation of the derivated matrix
//             dimension - the number of variables and thus the dimension of
//                         the argument
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             do_min  - Indicates wether a minumum (true) or
//                       a maximum (false) is sought
double *multinewtonraphson(double (*func)(double *), 
			   double *(*derivated)(double *), 
			   double **(*doublederivated)(double *), 
			   int dimension,
			   double *start, double enddiff,  
			   int &maxiter, bool do_min)
{
  double *x=new double[dimension]; // argument vector
  double *x1=new double[dimension]; // argument vector buffer
  int i=0,j,k,l;

  for(k=0;k<dimension;k++)
    x[k]=start[k];
    
  // find the derivated vector;
  double *df=(*derivated)(x);
  double max_derivated=MISSING_VALUE;

  // Find the max derivated;
  for(j=0;j<dimension;j++)
    if(max_derivated==MISSING_VALUE || ABSVAL(df[j])>max_derivated)
      max_derivated=ABSVAL(df[j]);
  delete [] df;

  
  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && max_derivated>enddiff)
    {
      double **inverted; 
      double steplength=1.0; // start with standard step length
      double fval=(*func)(x), fval2; // fetch the function value
      df=(*derivated)(x); // fetch the derivated vector
      // Fetch the double derivated matrix;
      double **ddf=(*doublederivated)(x); 

      // Find the inverse of the double derivated;
      if(!almost_equal(determinant_matrix(ddf,dimension),0.0))
	inverted=inverse_matrix(ddf,dimension);
      else
	break;

      // loop while the new function value is less desirable than the 
      // previous one;
      j=0;
      do
	{
	  for(k=0;k<dimension;k++)
	    {
	      x1[k]=x[k]; // set the buffer equal to the argument vector
	      
	      // update the argument using Newtons method;
	      for(l=0;l<dimension;l++)
		x1[k]-=steplength*inverted[k][l]*df[l];
	    }

	  steplength/=-2.0; // next time, we'll look in the other direction 
	  // with less force...
	  j++;

	  fval2=(*func)(x1); // fetch the new function value
	} while(((do_min && fval2>fval) || 
		 (!do_min && fval2<fval) ||
		 !(fval2>=-1e+100 && fval2<=1e+100)) &&
		j<maxiter);

      // update the argument;
      for(k=0;k<dimension;k++)
	x[k]=x1[k];

      // cleanup;
      for(k=0;k<dimension;k++)
	delete [] ddf[k];
      delete [] ddf;

      for(k=0;k<dimension;k++)
	delete [] inverted[k];
      delete [] inverted;

      // fetch the max derivated;
      max_derivated=MISSING_VALUE;
      for(j=0;j<dimension;j++)
	if(max_derivated==MISSING_VALUE || ABSVAL(df[j])>max_derivated)
	  max_derivated=ABSVAL(df[j]);

      delete [] df;

      i++;
    }
  
  // cleanup;
  delete [] x1;

  maxiter=i; // set the number of ieterations done
  
  return x; // return the argument vector
}


// Static global variables used inside the multivariate
// Newton-Raphson methods;
static int newton_dimension;

void set_newton_dimension(int dim)
{
  newton_dimension=dim;
}

double *(*newton_derivated)(double *);

void set_newton_derivated_func(double *(*func)(double *))
{
  newton_derivated=func;
}

// double derivated of the last function used by multinewtonraphson
double **newton_numeric_doubleder(double *x)
{
  double *df=(*newton_derivated)(x); // fetch the derivated vector
  double **ddf=new double*[newton_dimension]; // make the return matrix
  double delta=1e-7; // precision
  int i,j;
  double *x2=new double[newton_dimension]; // argument vector buffer
  
  // traverse the dimensions;
  for(i=0;i<newton_dimension;i++)
    {
      ddf[i]=new double[newton_dimension];

      // update the argument vector going a little step off for a single
      // index, i;
      for(j=0;j<newton_dimension;j++)
	if(j!=i)
	  x2[j]=x[j];
	else
	  x2[j]=x[j]+delta;

      // fetch the new derivated;
      double *df2=(*newton_derivated)(x2);
      
      // Make the double derivated from the difference in derivated;
      for(j=0;j<newton_dimension;j++)
	ddf[i][j]=(df2[j]-df[j])/delta;
      delete [] df2;
    }
  
  // cleanup;
  delete [] x2;
  delete [] df;

  return ddf; // return the double derivated matrix
}


// Newton Raphsons method for finding extremes of a multivariate function
// The double derivated matrix is calculated numerically
// Parameters; func  - the function
//             derivated - the derivated function array
//             dimension - the number of variables and thus the dimension of
//                         the argument
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             do_min  - Indicates wether a minumum (true)
double *multinewtonraphson(double (*func)(double *), 
			   double *(*derivated)(double *), 
			   int dimension,
			   double *start, double enddiff, 
			   int &maxiter, bool do_min)
{
  // Set the global variables for calculating double derivated
  // to the given derivated;
  newton_derivated=derivated;
  newton_dimension=dimension;

  // Use the numeric double derivated to calculate the Newton Raphson argument;
  return multinewtonraphson(func, derivated, newton_numeric_doubleder, 
			    dimension, start, enddiff, maxiter, do_min);
}
 
// Static global variable used inside the multivariate
// Newton-Raphson methods;
double (*newton_func)(double *);

void set_newton_func(double (*func)(double *))
{
  newton_func=func;
}

// derivated of the last function used by multinewtonraphson
double *newton_numeric_derivated(double *x)
{
  int i,j;
  double fval=(*newton_func)(x); // fetch the function value
  double *df=new double[newton_dimension]; // derivated vector
  double *x2=new double[newton_dimension]; // argument vector buffer
  double delta=1e-7; // precision

  // traverse the dimensions
  for(i=0;i<newton_dimension;i++)
    {
      // Set the argument vecotr, going a little to the left for one index, i;

      for(j=0;j<newton_dimension;j++)
	if(i!=j)
	  x2[j]=x[j];
	else
	  x2[j]=x[j]+delta;

      // Calculate the derivated as the scaled difference between the
      // function value before and after the step;
      df[i]=((*newton_func)(x2)-fval)/delta;
    }

  // cleanup;
  delete [] x2;

  return df; // return the derivated vector
}


// Newton Raphsons method for finding extremes of a multivariate function
// The derivated vector and the double derivated matrix is 
// calculated numerically
// Parameters; func  - the function
//             dimension - the number of variables and thus the dimension of
//                         the argument
//             start - initializes the argument
//             enddiff - The iterations are stopped when 
//                       the diffierence from one iteration and the next
//                       is less than this value
//             maxiter - The maximal number of iterations. Returns the number 
//                       of iterations actually used
//             do_min  - Indicates wether a minumum (true)
double *multinewtonraphson(double (*func)(double *), 
			   int dimension,
			   double *start, double enddiff, 
			   int &maxiter, bool do_min)
{
  // Set the global function used for calculating numeric derivated to
  // the one given;
  newton_func=func;
  newton_dimension=dimension;

  // Use this derivated to calculate the Newton Raphson argument;
  return multinewtonraphson(func, newton_numeric_derivated, dimension,
			    start, enddiff, maxiter, do_min);
}


// Static global variable used inside the multivariate
// Newton-Raphson methods;
double (*quasi_func)(double *);
static int quasi_dimension;

// derivated of the last function used by multinewtonraphson
double *quasi_numeric_derivated(double *x)
{
  int i,j;
  double fval=(*quasi_func)(x); // fetch the function value
  double *df=new double[quasi_dimension]; // derivated vector
  double *x2=new double[quasi_dimension]; // argument vector buffer
  double delta=1e-7; // precision

  // traverse the dimensions
  for(i=0;i<quasi_dimension;i++)
    {
      // Set the argument vecotr, going a little to the left for one index, i;

      for(j=0;j<quasi_dimension;j++)
	if(i!=j)
	  x2[j]=x[j];
	else
	  x2[j]=x[j]+delta;

      // Calculate the derivated as the scaled difference between the
      // function value before and after the step;
      df[i]=((*quasi_func)(x2)-fval)/delta;
    }

  // cleanup;
  delete [] x2;

  return df; // return the derivated vector
}

double *quasi_newton(double (*func)(double *), 
		     double *(*derivated)(double *), 
		     int dimension,
		     double *start, double enddiff, 
		     int &maxiter, bool do_min,
		     bool hillclimb)
{
  double *x=new double[dimension]; // argument vector
  double *x1=new double[dimension]; // argument vector buffer
  int i=0,j,k,l, m;

  for(k=0;k<dimension;k++)
    x[k]=start[k];

  // find the derivated vector;
  double f0=(*func)(x), f1=f0+1000.0*enddiff;
  double *df=(*derivated)(x);
  double **H=new double*[dimension];
  double **Hnew=new double*[dimension];
  double *s=new double[dimension];
  double *p=new double[dimension];
  double *q=new double[dimension];
  double qHq,ptq,*Hq=new double[dimension],**pqt=new double*[dimension];

  // Set H=unity matrix
  for(k=0;k<dimension;k++)
    {
      H[k]=new double[dimension];
      pqt[k]=new double[dimension];
      Hnew[k]=new double[dimension];
      for(l=0;l<dimension;l++)
	if(k==l)
	  H[k][l]=1.0;
	else
	  H[k][l]=0.0;
    }

  double lambda[13]={1e-12, 1e-6, 0.001,
		     0.003,0.01,0.03,0.1,0.3,1.0,3.0,10.0,30.0,100.0};


  // Loop for as long as the number of iterations is less than the maximum,
  // and the function value is outside the interval we're interested in;
  while(i<maxiter && ABSVAL((f0-f1))>enddiff)
    { 
      df=(*derivated)(x); // fetch the derivated vector
      f0=(*func)(x);

      //cout << "#############" << endl;
      //cout << "iteration " << i << endl;
      //cout << df[0] << " " << f0 << endl;

      // s=H*df;
      if(!hillclimb)
	{
	  for(k=0;k<dimension;k++)
	    {
	      s[k]=0.0;
	      for(l=0;l<dimension;l++)
		s[k]+=H[k][l]*df[l];
	    }
	  if(!do_min)
	    for(k=0;k<dimension;k++)
	      s[k]=-s[k];
	}
      else // hillclimbing
	{
	  for(k=0;k<dimension;k++)
	    s[k]=df[k];
	  double norm=0;
	  for(k=0;k<dimension;k++)
	    norm+=s[k]*s[k];
	  norm=sqrt(norm);
	  for(k=0;k<dimension;k++)
	    s[k]/=norm;
	}

      //cout << H[0][0] << endl;
      //cout << s[0] << endl;

      // Minimize/maximize func(x-lambda*s)
      int mindex=0;
      for(k=0;k<dimension;k++)
	x1[k]=x[k]-lambda[0]*s[k];
      double ex=(*func)(x1); 
      double sign=1.0;
      for(j=1;j<13;j++)
	{
	  for(k=0;k<dimension;k++)
	    x1[k]=x[k]-lambda[j]*s[k];
	  double f2=(*func)(x1);
	  if(f2!=MISSING_VALUE &&
	     (ex==MISSING_VALUE  || (do_min && f2<ex) || (!do_min && f2>ex)))
	    {
	      sign=1.0;
	      mindex=j;
	      ex=f2;
	    }
	}
      for(j=0;j<13;j++)
	{
	  for(k=0;k<dimension;k++)
	    x1[k]=x[k]+lambda[j]*s[k];
	  double f2=(*func)(x1);
	  if(f2!=MISSING_VALUE && 
	     (ex==MISSING_VALUE  || (do_min && f2<ex) || (!do_min && f2>ex)))
	    {
	      sign=-1.0;
	      mindex=j;
	      ex=f2;
	    }
	}
      
      for(k=0;k<dimension;k++)
	x1[k]=x[k]-sign*lambda[mindex]*s[k];
      double *df2=(*derivated)(x1); 

      //cout << lambda[mindex] << " " << x1[0] << endl;

      qHq=0.0; 
      ptq=0.0;
      for(k=0;k<dimension;k++)
	{
	  p[k]=x1[k]-x[k];
	  q[k]=df2[k]-df[k];
	}

      for(k=0;k<dimension;k++)
	{
	  Hq[k]=0.0;
	  for(l=0;l<dimension;l++)
	    {
	      Hq[k]+=H[k][l]*q[l];
	      pqt[k][l]=p[k]*q[l];
	    }
	  qHq+=q[k]*Hq[k];
	  ptq+=p[k]*q[k];
	}

      for(k=0;k<dimension;k++)
	for(l=0;l<dimension;l++)
	  Hnew[k][l]=H[k][l];

      double fac1=(1.0+qHq/ptq)/ptq;
      for(k=0;k<dimension;k++)
	for(l=0;l<dimension;l++)
	  Hnew[k][l]+=fac1*p[k]*p[l];
      
      for(k=0;k<dimension;k++)
	for(l=0;l<dimension;l++)
	  for(m=0;m<dimension;m++)
	    Hnew[k][l]-=(H[k][m]*pqt[m][l]+H[l][m]*pqt[m][k])/ptq;

      for(k=0;k<dimension;k++)
	{
	  x[k]=x1[k];
	  for(l=0;l<dimension;l++)
	    H[k][l]=Hnew[k][l];
	}
      
      f1=(*func)(x1);

      delete [] df2;
      delete [] df;
      i++;
    }
  
  // cleanup;
  delete [] x1;
  doubledelete(H,dimension);
  doubledelete(Hnew,dimension);
  delete [] s;
  delete [] p;
  delete [] q;
  delete [] Hq;
  doubledelete(pqt,dimension);

  maxiter=i; // set the number of ieterations done
  
  return x; // return the argument vector  
}

double *quasi_newton(double (*func)(double *), 
		     int dimension,
		     double *start, double enddiff, 
		     int &maxiter, bool do_min,
		     bool hillclimb)
{
  // Set the global function used for calculating numeric derivated to
  // the one given;
  quasi_func=func;
  quasi_dimension=dimension;

  // Use this derivated to calculate the Newton Raphson argument;
  return quasi_newton(func, quasi_numeric_derivated, dimension,
		      start, enddiff, maxiter, do_min, hillclimb);
}


double (*simplex_func)(double *);
int simplex_dimension;
bool simplex_do_min;
double simplex_minfunc(const gsl_vector *x, void* /* params */)
{
  double *xx=new double[simplex_dimension];
  for(int i=0;i<simplex_dimension;i++)
    xx[i]=gsl_vector_get(x, i);

  double ret=simplex_func(xx);
  if(!simplex_do_min)
    ret=-ret;
  
  delete [] xx;

  return ret;
}

double *simplex_optimization(double (*func)(double *),
			     int dimension, double *start, double enddiff,
			     int &maxiter, bool do_min)
{
  int iter = 0;
  int status,i;
  
  const gsl_multimin_fminimizer_type *T;
  gsl_multimin_fminimizer *s;
  
  gsl_vector *x, *step;
  gsl_multimin_function gsl_simplex_func;

  simplex_func=func;
  simplex_dimension=dimension;
  simplex_do_min=do_min;
  
  gsl_simplex_func.f = &simplex_minfunc;
  gsl_simplex_func.n = dimension;
  gsl_simplex_func.params = NULL;
       
  /* Starting point */
  x = gsl_vector_alloc (dimension);
  for(i=0;i<dimension;i++)
    gsl_vector_set (x, i, start[i]);

  step = gsl_vector_alloc (dimension);
  for(i=0;i<dimension;i++)
    gsl_vector_set (step, i, 1e-4);
  
  T = gsl_multimin_fminimizer_nmsimplex; // optimization method
  s = gsl_multimin_fminimizer_alloc (T, dimension);
  
  gsl_multimin_fminimizer_set (s, &gsl_simplex_func, x, step);
  
  do
    {
      iter++;
      status = gsl_multimin_fminimizer_iterate (s);
      
      if (status)
	break;
      
      double size = gsl_multimin_fminimizer_size (s);
      status = gsl_multimin_test_size (size, enddiff);
    }
  while (status==GSL_CONTINUE && iter < maxiter);
  
  maxiter=iter;

  double *ret=new double[dimension];
  for(i=0;i<dimension;i++)
    ret[i]=gsl_vector_get (s->x, i);

  gsl_multimin_fminimizer_free (s);
  gsl_vector_free (x);

  return ret;
}



double (*gsl_cover_func)(double *);
double *(*gsl_cover_der)(double *);
int gsl_cover_dimension;
bool gsl_cover_do_min;
double gsl_cover_f(const gsl_vector *x, void* /* params */)
{
  double *xx=new double[gsl_cover_dimension];
  for(int i=0;i<gsl_cover_dimension;i++)
    xx[i]=gsl_vector_get(x, i);

  double ret=gsl_cover_func(xx);
  if(!gsl_cover_do_min)
    ret=-ret;
  
  delete [] xx;

  return ret;
}
     
/* The gradient of f, df = (df/dx, df/dy). */
void gsl_cover_df (const gsl_vector *x, void* /* params */,
		   gsl_vector *df)
{
  int i;
  double *xx=new double[gsl_cover_dimension];
  for(i=0;i<gsl_cover_dimension;i++)
    xx[i]=gsl_vector_get(x, i);

  double *ret=gsl_cover_der(xx);
  if(!gsl_cover_do_min)
    for(i=0;i<gsl_cover_dimension;i++)
      ret[i]=-ret[i];
  
  for(i=0;i<gsl_cover_dimension;i++)
    gsl_vector_set(df, i, ret[i]);

  delete [] xx;
  delete [] ret;
}
     
/* Compute both f and df together. */
void gsl_cover_fdf (const gsl_vector *x, void *params,
		    double *f, gsl_vector *df)
{
  *f = gsl_cover_f(x, params);
  gsl_cover_df(x, params, df);
}


double *gsl_optimization_cover(double (*func)(double *),
			       double *(*derivated)(double *), 
			       int dimension, double *start, double enddiff,
			       int &maxiter, bool do_min,
			       GSL_COVER_METHOD method)
{
  int iter = 0;
  int status,i;
  
  gsl_cover_func=func;
  gsl_cover_der=derivated;
  gsl_cover_dimension=dimension;
  gsl_cover_do_min=do_min;
  
  const gsl_multimin_fdfminimizer_type *T;
  gsl_multimin_fdfminimizer *s;
  gsl_vector *x;
  gsl_multimin_function_fdf gsl_cover_infunc;
  
  gsl_cover_infunc.f = &gsl_cover_f;
  gsl_cover_infunc.df = &gsl_cover_df;
  gsl_cover_infunc.fdf = &gsl_cover_fdf;
  gsl_cover_infunc.n = dimension;
  gsl_cover_infunc.params = NULL;
  
  x = gsl_vector_alloc (dimension);
  for(i=0;i<dimension;i++)
    gsl_vector_set (x, i, start[i]);

  switch(method)
    {
    case GSL_COVER_CONJUGATE_FR:
      T = gsl_multimin_fdfminimizer_conjugate_fr;
      break;
    case GSL_COVER_CONJUGATE_PR:
      T = gsl_multimin_fdfminimizer_conjugate_pr;
      break;
    case GSL_COVER_BFGS:
      T = gsl_multimin_fdfminimizer_vector_bfgs;
      break;
    case GSL_COVER_STEEPEST_DESC:
    default:
      T = gsl_multimin_fdfminimizer_steepest_descent;
      break;
    }

  s = gsl_multimin_fdfminimizer_alloc (T, dimension);
  
  gsl_multimin_fdfminimizer_set (s, &gsl_cover_infunc, x, 1e-4, enddiff);
  
  do
    {
      iter++;
      status = gsl_multimin_fdfminimizer_iterate (s);
      
      if (status)
	break;
      
      status = gsl_multimin_test_gradient (s->gradient, 1e-3);
    }
  while (status == GSL_CONTINUE && iter < maxiter);

  maxiter=iter;

  double *ret=new double[dimension];
  for(i=0;i<dimension;i++)
    ret[i]=gsl_vector_get (s->x, i);

  gsl_multimin_fdfminimizer_free (s);
  gsl_vector_free (x);

  return ret;
}


// derivated of the last function used by multinewtonraphson
double *gsl_cover_numeric_derivated(double *x)
{
  int i,j;
  double fval=(*gsl_cover_func)(x); // fetch the function value
  double *df=new double[gsl_cover_dimension]; // derivated vector
  double *x2=new double[gsl_cover_dimension]; // argument vector buffer
  double delta=1e-5; // precision
  
  // traverse the dimensions
  for(i=0;i<gsl_cover_dimension;i++)
    {
      // Set the argument vecotr, going a little to the left for one index, i;

      for(j=0;j<gsl_cover_dimension;j++)
	if(i!=j)
	  x2[j]=x[j];
	else
	  x2[j]=x[j]+delta;

      // Calculate the derivated as the scaled difference between the
      // function value before and after the step;
      df[i]=((*gsl_cover_func)(x2)-fval)/delta;
    }

  // cleanup;
  delete [] x2;

  return df; // return the derivated vector
}


double *gsl_optimization_cover(double (*func)(double *), 
			       int dimension,
			       double *start, double enddiff, 
			       int &maxiter, bool do_min,
			       GSL_COVER_METHOD method)
{
  // Set the global function used for calculating numeric derivated to
  // the one given;
  gsl_cover_func=func;
  gsl_cover_dimension=dimension;

  // Use this derivated to calculate the Newton Raphson argument;
  return gsl_optimization_cover(func, gsl_cover_numeric_derivated, dimension,
				start, enddiff, maxiter, do_min, method);
}

