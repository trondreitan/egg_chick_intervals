#include <hydrasub/hydrabase/mcmc.H>
#include <cmath>

using namespace std;

double log_prob(double **data, int numrows, int numcolumns,
		int numparams, double *params,
		int num_hyperparameters, double *hyper_parameters,
		
		double (*log_prior)(int /*numparams*/, 
				    double* /* params */,
				    int /* num_hyperparameters */,
				    double* /* hyper_parameters */),
		 
		double (*log_lik)(double** /*data*/, 
				  int /* numrows */, 
				  int /* numcolumns */,
				  int /*numparams*/, 
				  double* /* params */), 

		double T )
{
  double lp=log_prior(numparams,params,num_hyperparameters,hyper_parameters);

  if(!(lp>-1e+200 && lp<1e+200))
    return(-1e+200);

  double ll=log_lik(data,numrows,numcolumns,numparams,params);

  if(!(ll>-1e+200 && ll<1e+200))
    return(-1e+200);
  
  double pp=ll+lp;

  return pp/T;
}

void sample_once(double **data, int numrows, int numcolumns,
		 int numparams, int numtemp, double **params, 
		 int *acc, double *rw, double *logprob,
		 double *T, int *swaps, double tempering_prob,
		 int num_hyperparameters, double *hyper_parameters,
		 
		 double (*log_prior)(int /*numparams*/, 
				     double* /* params */,
				     int /* num_hyperparameters */,
				     double* /* hyper_parameters */),
		 
		 double (*log_lik)(double** /*data*/, 
				   int /* numrows */, 
				   int /* numcolumns */,
				   int /*numparams*/, 
				   double* /* params */),
		 bool update_prev_log_prob,
		 bool silent)
{
  int i;
  
  if(numtemp>1 && drand48()<tempering_prob) // tempering swap?
    {
      // choose a random chain below the maximum:
      int index=(int) floor(double(numtemp-1)*drand48());
      // Find the logprob when a switch takes place:
      double p1=log_prob(data,numrows,numcolumns,numparams,params[index],
			 num_hyperparameters, hyper_parameters,
			 log_prior, log_lik, T[index+1]);
      
      double p2=log_prob(data,numrows,numcolumns,numparams,params[index+1],
			 num_hyperparameters, hyper_parameters,
			 log_prior, log_lik, T[index]);
      
      if(update_prev_log_prob)
	{
	  logprob[index]=log_prob(data,numrows,numcolumns,numparams,
				  params[index],num_hyperparameters, 
				  hyper_parameters,
				  log_prior, log_lik, T[index]);
	  logprob[index+1]=log_prob(data,numrows,numcolumns,numparams,
				  params[index+1],num_hyperparameters, 
				  hyper_parameters,
				  log_prior, log_lik, T[index+1]);
	}

      // Acceptance-rejection term:
      if(log(drand48())<p1+p2-logprob[index]-logprob[index+1])
	{
	  // Swap chains:
	  logprob[index+1]=p1;
	  logprob[index]=p2;
	  
	  // Switch the contents of the chains:
	  double *buffer=new double[numparams];
	  for(i=0;i<numparams;i++)
	    buffer[i]=params[index][i];
	  for(i=0;i<numparams;i++)
	    params[index][i]=params[index+1][i];
	  for(i=0;i<numparams;i++)
	    params[index+1][i]=buffer[i];
	  
	  swaps[index]++; // update the number of swaps
	  
	  if(!silent)
	    cout << " Swap chain " << index << " <-> chain " << index+1 << endl; 
	  
	  // cleanup
	  delete [] buffer;
	}
    }
  else // normal RW Metropolis sampling:
    for(int t=0;t<numtemp;t++) // traverse the tempering chains
      {
	double *newparams=new double[numparams];
	for(i=0;i<numparams;i++)
	  newparams[i]=params[t][i];
	
	double new_logprob;
	double sT=sqrt(T[t]); // tempering contribution to the 
	// random walk standard deviation
	
	for(i=0;i<numparams;i++)
	  {
	    newparams[i]+=rw[i]*sT*gauss();

	    // Update the logprob (log(prior*likelihood)):
	    new_logprob=log_prob(data,numrows,numcolumns,numparams,newparams,
				 num_hyperparameters, hyper_parameters,
				 log_prior, log_lik, T[t]);
	    
	    if(update_prev_log_prob)
	      logprob[t]=log_prob(data,numrows,numcolumns,numparams,params[t],
				  num_hyperparameters, hyper_parameters,
				  log_prior, log_lik, T[t]);

	    // Acceptance/rejection term:
	    if(log(drand48())<new_logprob-logprob[t])
	      {
		// copy the new value over to the 'sample' structure:
		params[t][i]=newparams[i];
		// update the logprob:
		logprob[t]=new_logprob;
		// if this is the lowest chain (the chain of the
		// model we are interested in), then set the
		// acceptances indicator for this parameter:
		if(t==0)
		  acc[i]=1;
	      }
	    else // rejection
	      {
		// if this is the lowest chain (the chain of the
		// model we are interested in), then nullify the
		// acceptances indicator for this parameter:
		if(t==0)
		  acc[i]=0;
		// put the old sample value into the 
		// new sample structure
		newparams[i]=params[t][i];
	      }
	  }

	delete [] newparams;
      }
}


double **mcmc(int numsamples, int burnin, int indep, int numtemp,

	      double **data, int numrows, int numcolumns,

	      int numparams, char **param_names, 

	      double *T, double tempering_prob, 

	      int num_hyperparameters, double *hyper_parameters,

	      void (*init)(int /* numparams */,
			   double* /* input parameter array*/, 
			   int /* num_hyperparameters */,
			   double* /* hyperparameters */), // init mechanism
	      // may possibly use the prior via hyper-parameters

	      double (*log_prior)(int /*numparams*/, 
				 double* /* params */,
				 int /* num_hyperparameters */,
				 double* /* hyper_parameters */),
	      
	      double (*log_lik)(double** /*data*/, 
				int /* numrows */, 
				int /* numcolumns */,
				int /*numparams*/, 
				double* /* params */),

	      bool silent,
	      bool update_prev_log_prob,
	      bool show_graphs,
	      double *rw_sd_start,
	      double **sd_proposal,
	      int **num_swaps)
{
  if(T[0]!=1.0)
    {
      cerr << "Usage in routine 'mcmc': first tempering temperature "
	"*must* be equal to 1!" << endl;
      return NULL;
    }
  
  // Return matrix:
  double **ret=make_matrix(numsamples,numparams);
  
  // indexes:
  int i,j,k,t;
  
  // Current set of samples (one for each tempering chain) and
  // acceptance indicators and random walk standard deviations:
  double **params=make_matrix(numtemp,numparams);
  double *rw=new double[numparams];
  int *totalacc=new int[numparams];
  int *acc=new int[numparams];
  
  for(k=0;k<numparams;k++)
    {
      if(rw_sd_start)
	rw[k]=rw_sd_start[k];
      else
	rw[k]=0.1;
      totalacc[k]=0;
    }
  
  // logprob, i.e. log(prior*likelihood):
  double *logprob=new double[numtemp];
  
  // Number of swaps between one chain and the next:
  int *swaps=new int[numtemp];
  for(t=0;t<numtemp;t++)
    swaps[t]=0;
  
  // **************************************************************
  // initialization of the samples:
  for(t=0;t<numtemp;t++) // traverse the chains
    {
      do
	{
	  init(numparams, params[t], num_hyperparameters, hyper_parameters);
	  
	  logprob[t]=log_prob(data, numrows, numcolumns,
			      numparams, params[t],
			      num_hyperparameters, hyper_parameters,
			      log_prior, log_lik, T[t]); 
	} while(!(logprob[t]>-1e+200 && logprob[t]<1e+200));
    }
  if(!silent)
    cout << "done getting initial values" << endl;
  
  
  // **************************************************************
  // burn-in phase:
  if(burnin>0)
    {
      for(j=0;j<2;j++) // two sub-phases, with and without 
	// adaptation, done twice
	{
	  // sample without adaptation:
	  for(i=1;i<=burnin/4;i++)
	    {
	      sample_once(data,numrows,numcolumns,
			  numparams, numtemp, params,
			  acc, rw, logprob, T, swaps, tempering_prob,
			  num_hyperparameters, hyper_parameters,
			  log_prior, log_lik, update_prev_log_prob, silent);
	      if(!silent)
		{
		  cout << "burnin, j=" << j*2+1 << " of 4 i=" << i << 
		    " of " << burnin/4 << " logprob=" << logprob[0] << " ";
		  show_parameter_value(params[0], numparams, param_names,10);
		}
	    }
	  
	  // update the acceptances:
	  for(k=0;k<numparams;k++)
	    totalacc[k]=0;
	  
	  // sample with adaptation:
	  for(i=1;i<=burnin/4;i++)
	    {
	      sample_once(data,numrows,numcolumns,
			  numparams, numtemp, params,
			  acc, rw, logprob, T, swaps, tempering_prob,
			  num_hyperparameters, hyper_parameters,
			  log_prior, log_lik, update_prev_log_prob, silent);
	      if(!silent)
		{
		  cout << "burnin, j=" << j*2+2 << " of 4 i=" << i << 
		    " of " << burnin/4 << " logprob=" << logprob[0] << " ";
		  show_parameter_value(params[0], numparams, param_names,10);
		}

	      // update the total amount of acceptances for each parameter:
	      for(k=0;k<numparams;k++)
		totalacc[k]+=acc[k];
	      
	      // Adapt according to the acceptance rate each 100th sample:
	      if(i%100==0)
		{
		  // traverse the parameters:
		  for(k=0;k<numparams;k++)
		    {
		      // adapt the standard deviation
		      // so that it goes towards 0.3333:
		      rw[k] *= exp((totalacc[k]/100.0-0.3333)*2.0);
		      
		      // initialize the total amount of accpetances again:
		      totalacc[k]=0;
		      
		      if(!silent && k<10)
			cout << "rw[" << k << "]=" << rw[k] << " ";
		    }
		  if(!silent)
		    cout << endl;
		}
	      else if(i==(burnin/4))
		{
		  double num_trailing=double(i%100);
		  // traverse the parameters:
		  for(k=0;k<numparams;k++)
		    {
		      // adapt the standard deviation
		      // so that it goes towards 0.3333:
		      rw[k] *= exp((totalacc[k]/num_trailing-0.3333)*2.0);
		      
		      // initialize the total amount of accpetances again:
		      totalacc[k]=0;
		      
		      if(!silent && k<10)
			cout << "rw[" << k << "]=" << rw[k] << " ";
		    }
		  if(!silent)
		    cout << endl;
		}
	    }
	}
    }
  
  
  // **************************************************************
  // MCMC sampling:
  for(i=0;i<numsamples;i++) // traverse the wanted number of samples
    {
      // For each wanted sample, do MCMC iterations 'indep' number
      // of times:
      for(j=0;j<indep;j++)
	{
	  sample_once(data,numrows,numcolumns,
		      numparams, numtemp, params,
		      acc, rw, logprob, T, swaps, tempering_prob,
		      num_hyperparameters, hyper_parameters,
		      log_prior, log_lik, update_prev_log_prob, silent);
	  if(!silent)
	    {
	      cout << "sample i=" << i+1 << " of " << numsamples << 
		" j=" << j+1 << " of " << indep << " logprob=" << 
		logprob[0] << " ";
	      show_parameter_value(params[0], numparams, param_names, 10);
	    }
	} 

      // copy the result to the return array:
      for(k=0;k<numparams;k++)
	ret[i][k]=params[0][k];
   
      /*
      // Show debug info, if wanted:
      if(i%10==0 && !silent)
	{
	  printf("i=%d: ", i);
	  for(k=0;k<numparams;k++)
	    if(param_names && param_names[k])
	      printf("%s=%f ", param_names[k], ret[i][k]);
	    else
	      printf("par%03d=%f ", k, ret[i][k]);
	  printf("logprob=%g\n", logprob[0]);
	}
      */
    }

  // Show tempering swapping info, if wanted:
  if(!silent)
    {
      // Tempering output:
      if(numtemp>1)
	{
	  printf("Swaps:\n");
	  for(t=0;t<(numtemp-1);t++)
	    printf("%d<->%d: %d\n", t, t+1, swaps[t]);
	}
    }

  delete [] logprob;
  delete [] acc;
  delete [] totalacc;
  if(sd_proposal)
    *sd_proposal=rw;
  else
    delete [] rw;
  if(num_swaps)
    *num_swaps=swaps;
  else
    delete [] swaps;
  doubledelete(params,numtemp);

  if(show_graphs)
    {
      for(k=0;k<numparams;k++)
	{
	  double *theta=new double[numsamples];
	  for(i=0;i<numsamples;i++)
	    theta[i]=ret[i][k];
	  
	  show_mcmc_parameter(theta, numsamples, param_names[k],false);
	  delete [] theta;
	}

      for(j=0;j<(numparams-1);j++)
	for(k=j+1;k<numparams;k++)
	  {
	    double *theta1=new double[numsamples];
	    double *theta2=new double[numsamples];
	    for(i=0;i<numsamples;i++)
	      {
		theta1[i]=ret[i][j];
		theta2[i]=ret[i][k];
	      }
	    
	    show_mcmc_scatter(theta1, theta2, numsamples, 
			      param_names[j],param_names[k]);
	    delete [] theta1;
	    delete [] theta2;
	  }
    }
  
  return ret;
}


// Importance sampling method for calculating model likelihood
// using a multinormal approximation of the posterior samples
// as the proposal distribution.
double log_model_likelihood_multinormal(int num_importance_samples,
			    
			    double **mcmc_params, 
			    int numparams, int numsamples,
			    
			    double **data, int numrows, int numcolumns,
			    
			    int num_hyperparameters, double *hyper_parameters,
			    
			    double (*log_prior)(int /*numparams*/, 
						double* /* params */,
						int /* num_hyperparameters */,
						double* /* hyper_parameters */),
			    
			    double (*log_lik)(double** /*data*/, 
					      int /* numrows */, 
					      int /* numcolumns */,
					      int /*numparams*/, 
					      double* /* params */),
			    
					bool silent,
					bool dont_keep_cholesky,
					double scale)
{
  int i, j, num_imp=num_importance_samples;
  
  // **************************************************************
  // Importance sampling for finding the marginal data probability
  // Get mean and correlation for the coefficients 
  // in the different models:
      
  // Fetch the moments:
  double *mu_coefs=find_mean_of_vectors(numsamples, mcmc_params, numparams);
  double **sigma_coefs=find_estimated_variance(numsamples, mcmc_params,
					       mu_coefs, numparams);
  for(i=0;i<numparams;i++)
    for(j=0;j<numparams;j++)
      sigma_coefs[i][j]*=scale*scale;
  
  // Initialize GSL random generator:
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  
  double *lp_lw=new double[num_imp];
  
  // Importance sampling in order to calculate
  // the model probabilities:
  for(i=0;i<num_imp;i++)
    {
      // sample from a multinormal proposal distribution having 
      // the same moments as the posterior MCMC samples:
      double **csample=sample_from_multinormal(1, mu_coefs, 
					       sigma_coefs, 
					       numparams, rptr,
					       dont_keep_cholesky);
      if(!csample)
	{
	  delete [] lp_lw;
	  delete [] mu_coefs;
	  doubledelete(sigma_coefs,numparams);
	  gsl_rng_free(rptr);
	  return MISSING_VALUE;
	}


      // make a proposal parameter structure:
      double *par=*csample;
      
      // calculate the proposal distribution density:
      double lw=multinormal_pdf(par, mu_coefs,
				sigma_coefs, numparams, 
				true);
      if(lw==MISSING_VALUE)
	{
	  delete [] lp_lw;
	  delete [] mu_coefs;
	  doubledelete(sigma_coefs,numparams);
	  gsl_rng_free(rptr);
	  return MISSING_VALUE;
	}

      // fetch the logprob for the proposal:
      double lp=log_prob(data,numrows,numcolumns,numparams,par,
			 num_hyperparameters, hyper_parameters,
			 log_prior, log_lik);

      if(lp>-1e+200 && lp<1e+200 && lw>-1e+200 && lw<1e+200)
	lp_lw[i]=lp-lw;
      else
	lp_lw[i]=-1e+200;

      // cleanup:
      doubledelete(csample,1);
    }

  double lp_lw_max=find_statistics(lp_lw,num_imp,MAX);
  
  // probaiblity sum, contribution and prior sum
  double probsum=0.0;
  for(i=0;i<num_imp;i++)
    probsum+=exp(lp_lw[i]-lp_lw_max);

  // Monte Carlo estimate for the marginal data density
  probsum/=((double) num_imp);

  double lprobsum=log(probsum)+lp_lw_max;
  // Show the model marginal data density:
  if(!silent)
    {
      printf("probsum_0=%g\n", probsum);
      printf("lprobsum=%g\n", lprobsum);
    }
  
  delete [] lp_lw;
  delete [] mu_coefs;
  doubledelete(sigma_coefs,numparams);
  gsl_rng_free(rptr); 

  return lprobsum;
}


// Importance sampling method for calculating model likelihood
// using a multinormal approximation of the posterior samples
// as the proposal distribution.
double log_model_likelihood_indepnormal(int num_importance_samples,
			    
			    double **mcmc_params, 
			    int numparams, int numsamples,
			    
			    double **data, int numrows, int numcolumns,
			    
			    int num_hyperparameters, double *hyper_parameters,
			    
			    double (*log_prior)(int /*numparams*/, 
						double* /* params */,
						int /* num_hyperparameters */,
						double* /* hyper_parameters */),
			    
			    double (*log_lik)(double** /*data*/, 
					      int /* numrows */, 
					      int /* numcolumns */,
					      int /*numparams*/, 
					      double* /* params */),
			    
					bool silent,
					double scale)
{
  int i, j, num_imp=num_importance_samples;
  
  // **************************************************************
  // Importance sampling for finding the marginal data probability
  // Get mean and correlation for the coefficients 
  // in the different models:
      
  // Fetch the moments:
  double *mu_coefs=find_mean_of_vectors(numsamples, mcmc_params, numparams);
  double *sigma_coefs=new double[numparams];
  for(j=0;j<numparams;j++)
    {
      double *parsamples=new double[numsamples];
      for(i=0;i<numsamples;i++)
	parsamples[i]=mcmc_params[i][j];

      sigma_coefs[j]=find_statistics(parsamples,numsamples,STANDARD_DEVIATION);
      delete [] parsamples;
    }

  for(j=0;j<numparams;j++)
    sigma_coefs[j]*=scale;

  // Initialize GSL random generator:
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  
  double *lp_lw=new double[num_imp];
  
  // Importance sampling in order to calculate
  // the model probabilities:
  for(i=0;i<num_imp;i++)
    {
      // make a proposal parameter structure:
      double *par=new double[numparams];
      for(j=0;j<numparams;j++)
	par[j]=mu_coefs[j]+sigma_coefs[j]*gsl_ran_ugaussian(rptr);

      // calculate the proposal distribution density:
      double lw=0.0;
      for(j=0;j<numparams;j++)
	lw += -0.5*log(2.0*M_PI) - log(sigma_coefs[j])-
	  0.5*(par[j]-mu_coefs[j])*(par[j]-mu_coefs[j])/
	  sigma_coefs[j]/sigma_coefs[j];
      
      // fetch the logprob for the proposal:
      double lp=log_prob(data,numrows,numcolumns,numparams,par,
			 num_hyperparameters, hyper_parameters,
			 log_prior, log_lik);

      if(lp>-1e+200 && lp<1e+200 && lw>-1e+200 && lw<1e+200)
	lp_lw[i]=lp-lw;
      else
	lp_lw[i]=-1e+200;

      // cleanup:
      delete [] par;
    }

  double lp_lw_max=find_statistics(lp_lw,num_imp,MAX);
  
  // probaiblity sum, contribution and prior sum
  double probsum=0.0;
  for(i=0;i<num_imp;i++)
    probsum+=exp(lp_lw[i]-lp_lw_max);
  
  // Monte Carlo estimate for the marginal data density
  probsum/=((double) num_imp);
  
  double lprobsum=log(probsum)+lp_lw_max;
  // Show the model marginal data density:
  if(!silent)
    {
      printf("lp_lw_max=%g\n", lp_lw_max);
      printf("probsum=%g\n", probsum);
      printf("probsum_0=%g\n", probsum);
      printf("lprobsum=%g\n", lprobsum);
    }
  
  delete [] lp_lw;
  delete [] mu_coefs;
  delete [] sigma_coefs;
  gsl_rng_free(rptr); 
  
  return lprobsum;
}

// Importance sampling method for calculating model likelihood
// using a multinormal approximation of the posterior samples
// as the proposal distribution.
double log_model_likelihood_multistudent(int num_importance_samples,
			    
			    double **mcmc_params, 
			    int numparams, int numsamples,
			    
			    double **data, int numrows, int numcolumns,
			    
			    int num_hyperparameters, double *hyper_parameters,
			    
			    double (*log_prior)(int /*numparams*/, 
						double* /* params */,
						int /* num_hyperparameters */,
						double* /* hyper_parameters */),
			    
			    double (*log_lik)(double** /*data*/, 
					      int /* numrows */, 
					      int /* numcolumns */,
					      int /*numparams*/, 
					      double* /* params */),

					 double t_free,
					 bool silent,
					 bool dont_keep_cholesky,
					 double scale)
{
  int i, j,num_imp=num_importance_samples;
  
  // **************************************************************
  // Importance sampling for finding the marginal data probability
  // Get mean and correlation for the coefficients 
  // in the different models:
      
  // Fetch the moments:
  double *mu_coefs=find_mean_of_vectors(numsamples, mcmc_params, numparams);
  double **sigma_coefs=find_estimated_variance(numsamples, mcmc_params,
					       mu_coefs, numparams);
  for(i=0;i<numparams;i++)
    for(j=0;j<numparams;j++)
      sigma_coefs[i][j]*=scale*scale;

  double *zeros=new double[numparams];
  for(j=0;j<numparams;j++)
    zeros[j]=0.0;

  // Initialize GSL random generator:
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  
  double *lp_lw=new double[num_imp];
  
  // Importance sampling in order to calculate
  // the model probabilities:
  for(i=0;i<num_imp;i++)
    {
      // sample from a multinormal proposal distribution having 
      // the same moments as the posterior MCMC samples:
      double **csample=sample_from_multinormal(1, zeros,
					       sigma_coefs, 
					       numparams, rptr,
					       dont_keep_cholesky);
      if(!csample)
	{
	  delete [] lp_lw;
	  delete [] mu_coefs;
	  delete [] zeros;
	  doubledelete(sigma_coefs,numparams);
	  gsl_rng_free(rptr);
	  return MISSING_VALUE;
	}

      double V=gsl_ran_chisq(rptr, t_free);
      double mfactor=sqrt(t_free/V);

      // make a proposal parameter structure:
      double *par=*csample;
      for(j=0;j<numparams;j++)
	par[j]=mu_coefs[j]+par[j]*mfactor;

      // calculate the proposal distribution density:
      double lw=multi_t_pdf(par, mu_coefs,
			    sigma_coefs, t_free,
			    numparams, true);
      
      // fetch the logprob for the proposal:
      double lp=log_prob(data,numrows,numcolumns,numparams,par,
			 num_hyperparameters, hyper_parameters,
			 log_prior, log_lik);

      if(lp>-1e+200 && lp<1e+200 && lw>-1e+200 && lw<1e+200)
	lp_lw[i]=lp-lw;
      else
	lp_lw[i]=-1e+200;
      
      // cleanup:
      doubledelete(csample,1);
    }

  double lp_lw_max=find_statistics(lp_lw,num_imp,MAX);
  
  // probaiblity sum, contribution and prior sum
  double probsum=0.0;
  for(i=0;i<num_imp;i++)
    probsum+=exp(lp_lw[i]-lp_lw_max);

  // Monte Carlo estimate for the marginal data density
  probsum/=((double) num_imp);

  double lprobsum=log(probsum)+lp_lw_max;
  // Show the model marginal data density:
  if(!silent)
    {
      printf("probsum_0=%g\n", probsum);
      printf("lprobsum=%g\n", lprobsum);
    }
  
  delete [] lp_lw;
  delete [] mu_coefs;
  delete [] zeros;
  doubledelete(sigma_coefs,numparams);
  gsl_rng_free(rptr); 

  return lprobsum;
}






// show_parameters: Uses the external programs
// 'vvgraph' and 'histogramme' from the hydrasub
// package to show the sampling for a given
// parameter. If these are not present, this
// methods should be set on silent (only spacing
// between independent samples are shown).
// par: parameter samples
// N: number of samples
// parname: name of parameter
// silent: if set, turns on silent modus
void show_mcmc_parameter(double *par, int N, char *parname, 
			 bool silent, 
			 char *filestart)
{
  char cmd[1000], filename[1000]; // command string + file name string
  FILE *p; // file pointer
  int i, len=N; 
  // calculate one-step autocorrelation:
  double rho=get_auto_correlation(par, len);
  // number of independent samples, using 
  // AR(1) model and Gelman's formula for independent samples:
  // double n_indep=len/2.0/(0.5+rho/(1.0-rho));
  // spacing=N/n_indep
  double spacing=2.0*(0.5+rho/(1.0-rho));

  cout << parname << " mean=" << find_statistics(par,N,MEAN);
  cout << " median=" << find_statistics(par,N,MEDIAN);
  cout << " 95% post.cred.int=(" << 
    find_statistics(par,N,PERCENTILE_2_5) << " , " <<
    find_statistics(par,N,PERCENTILE_97_5) << ")" << endl;

  // if silent, this is all that is to be done:
  if(silent)
    return;
  
  // Show spacing:
  cout << parname << " - spacing between independent samples:" << 
    spacing << endl;

  // show sampling history using 'vvgraph':
  if(!filestart || !*filestart)
    {
      sprintf(cmd, "vvgraph -x \"%s\" 2> /dev/null > /dev/null", parname);
      p=popen(cmd,"w");
    }
  else
    {
      sprintf(filename, "%s_%s_ts.txt", filestart, parname);
      p=fopen(filename,"w");
    }
  fprintf(p,"# Column 1: %s\n",  parname);
  fprintf(p,"###################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%d %f\n", i+1, par[i]);
  if(!filestart || !*filestart)
    pclose(p);
  else
    fclose(p);

  // show histogram using 'histogramme':
  if(!filestart || !*filestart)
    {
      sprintf(cmd, "histogramme -x \"%s\" -t \"%s\" 2> /dev/null > /dev/null", 
	      parname,  parname); 
      p=popen(cmd, "w");
    }
  else
    {
      sprintf(filename, "%s_%s_hist.txt", filestart, parname);
      p=fopen(filename,"w");
    }
  for(i=0;i<len;i++)
    fprintf(p,"%f\n", par[i]);
  if(!filestart || !*filestart)
    pclose(p);
  else
    fclose(p);
}


// show_scatter: Shows scatterplots of the samples for
// two parameter.
// par1: parameter samples for parameter 1
// par2: parameter samples for parameter 2
// N: number of samples
// parname1: parameter name 1
// parname2: parameter name 2
void show_mcmc_scatter(double *par1, double *par2, int N, 
		       char *parname1, char *parname2, char *filestart)
{
  FILE *p; // file pointer
  char cmd[1000], filename[1000]; // command string + file name string
  int i, len=N;
  
  // show scatterplot using the 'vvgraph' program:

  if(!filestart || !*filestart)
    {
      sprintf(cmd, "vvgraph -x \"%s\" -y \"%s\"", parname1, parname2);
      p=popen(cmd,"w");
    }
  else
    {
      sprintf(filename, "%s_%s_%s_scatter.txt", filestart, parname1,parname2);
      p=fopen(filename,"w");
    }
  fprintf(p, "# Column 1: %s vs %s\n", parname1, parname2);
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%f %f\n", par1[i], par2[i]);
  if(!filestart || !*filestart)
    pclose(p);
  else
    fclose(p);
}


// show_parameter_value : prints current parameter array to screen:
void show_parameter_value(double *param, int numparam, char **parnames,
			  int max_params)
{
  int showmax=numparam;
  if(max_params!=(int)MISSING_VALUE && max_params>0 &&
     numparam>max_params)
    showmax=max_params;
  for(int i=0;i<showmax;i++)
    if(parnames)
      cout << parnames[i] << "=" << param[i] << " ";
    else
      cout << "par" << i+1 << "=" << param[i] << " ";
  cout << endl;
}


