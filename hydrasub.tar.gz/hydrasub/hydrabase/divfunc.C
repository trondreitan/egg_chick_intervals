/*
 * $Id: divfunc.C 2935 2017-06-19 12:51:55Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/divfunc.C $
 */

#include <hydrasub/hydrabase/divfunc.H>
#include <cmath>
#include <fstream>

#ifdef NVE
#include <envirsub/system.H>
#else
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <grp.h>
#include <pwd.h> 
#endif // NVE

METHOD methodlist[NUMBER_OF_METHODS]=
  {
    UNKNOWN_METHOD,
    INSTANTANEOUS,
    MAX,
    MIN,
    MEAN,
    CHANGE,
    SUM,
    TIME_INDEPENDENT_INSTANTANEOUS,
    MORNING,
    NOON ,
    AFTERNOON,
    MIXED_METHODS ,
    SEVERAL_YEAR_MEAN,
    SEVERAL_YEAR_MAX,
    SEVERAL_YEAR_MIN,
    SEVERAL_YEAR_SUM,
    VARIATION,
    STANDARD_DEVIATION,
    AVERAGE_DEVIATION,
    SKEW,
    CURTOSIS,
    SEVERAL_YEAR_STANDARD_DEVIATION,
    STANDARD_ERROR,
    MEAN_PLUS_SDEV ,
    MEAN_MINUS_SDEV,
    SEVERAL_YEAR_MEAN_PLUS_SDEV,
    SEVERAL_YEAR_MEAN_MINUS_SDEV,
    MEAN_PLUS_SERR,
    MEAN_MINUS_SERR,
    MEAN_PLUS_2SERR,
    MEAN_MINUS_2SERR,
    SEVERAL_YEAR_PERCENTILE_2_5,
    SEVERAL_YEAR_PERCENTILE_5,
    SEVERAL_YEAR_PERCENTILE_10,
    SEVERAL_YEAR_PERCENTILE_20,
    SEVERAL_YEAR_PERCENTILE_25,
    SEVERAL_YEAR_PERCENTILE_30,
    SEVERAL_YEAR_PERCENTILE_40,
    SEVERAL_YEAR_MEDIAN ,
    SEVERAL_YEAR_PERCENTILE_60,
    SEVERAL_YEAR_PERCENTILE_70,
    SEVERAL_YEAR_PERCENTILE_75,
    SEVERAL_YEAR_PERCENTILE_80,
    SEVERAL_YEAR_PERCENTILE_90,
    SEVERAL_YEAR_PERCENTILE_95,
    SEVERAL_YEAR_PERCENTILE_97_5,
    PERCENTILE_2_5,
    PERCENTILE_5,
    PERCENTILE_10,
    PERCENTILE_20,
    PERCENTILE_25,
    PERCENTILE_30,
    PERCENTILE_40,
    MEDIAN,
    PERCENTILE_60,
    PERCENTILE_70,
    PERCENTILE_75,
    PERCENTILE_80,
    PERCENTILE_90,
    PERCENTILE_95,
    PERCENTILE_97_5,
    DERIVATIVE,
    DIFFERENCE_MET,
    ACCUMULATION_DIFFERENCE,
    CONFORM_TRAN_DAY,
    CONFORM_TRAN_WEEK,
    CONFORM_TRAN_YEAR,
    MOST_FREQUENT        
  };

char *methodstrlist[NUMBER_OF_METHODS]=
  {
    WHAT((char *) "Ukjent metode", (char *) "Unknown method"),
    WHAT((char *) "Momentan", (char *) "Instantaneous"),
    WHAT((char *) "Maksimum", (char *) "Maximum"),
    WHAT((char *) "Minimum", (char *) "Minimum"),
    WHAT((char *) "Gjennomsnitt", (char *) "Mean"),
    WHAT((char *) "Forandrning", (char *) "Change"),
    WHAT((char *) "Sum", (char *) "Sum"),
    WHAT((char *) "Tidsuavhengig momentan", (char *) "Time independent instantaneous"),
    WHAT((char *) "Morgen", (char *) "Morning"),
    WHAT((char *) "Middag", (char *) "Noon"),
    WHAT((char *) "Kveld", (char *) "Afternoon"),
    WHAT((char *) "Miks av metoder", (char *) "Mixed methods"),
    WHAT((char *) "Fler�rs-gjennomsnitt", (char *) "Severl year mean"),
    WHAT((char *) "Fler�rs-maksimum", (char *) "Severl year maximum"),
    WHAT((char *) "Fler�rs-minimum", (char *) "Severl year minimum"),
    WHAT((char *) "Fler�rs-sum", (char *) "Severl year sum"),
    WHAT((char *) "Variasjon", (char *) "Variation"),
    WHAT((char *) "Standardavvik", (char *) "Standard deviation"),
    WHAT((char *) "Gjennomsnittelig avvik", (char *) "Average deviation"),
    WHAT((char *) "Skjeveht", (char *) "Skew"),
    WHAT((char *) "Kurtose", (char *) "Curtosis"),
    WHAT((char *) "Fler�rs-standardavvik", 
	 (char *) "Severl year standard deviation"),
    WHAT((char *) "Standardfeil", (char *) "Standard error"),
    WHAT((char *) "Gjennomsnitt + standardavvik", (char *) "Mean + std.dev."),
    WHAT((char *) "Gjennomsnitt - standardavvik", (char *) "Mean - std.dev."),
    WHAT((char *) "Fler�rsgjennomsnitt + standardavvik", 
	 (char *) "Several year mean + std.dev."),
    WHAT((char *) "Fler�rsgjennomsnitt - standardavvik", 
	 (char *) "Several year mean - std.dev."),
    WHAT((char *) "Gjennomsnitt + standardfeil", (char *) "Mean + std.error"),
    WHAT((char *) "Gjennomsnitt - standardfeil", (char *) "Mean - std.error"),
    WHAT((char *) "Gjennomsnitt + 2 standardfeil", 
	 (char *) "Mean + 2 std.error"),
    WHAT((char *) "Gjennomsnitt - 2 standardfeil", 
	 (char *) "Mean - 2 std.error"),
    WHAT((char *) "Fler�rs 2.5%-persentil",
	 (char *) "Several year 2.5% percentile"),
    WHAT((char *) "Fler�rs 5%-persentil",  
	 (char *) "Several year 5% percentile"),
    WHAT((char *) "Fler�rs 10%-persentil", 
	 (char *) "Several year 10% percentile"),
    WHAT((char *) "Fler�rs 20%-persentil", 
	 (char *) "Several year 20% percentile"),
    WHAT((char *) "Fler�rs 25%-persentil", 
	 (char *) "Several year 25% percentile"),
    WHAT((char *) "Fler�rs 30%-persentil", 
	 (char *) "Several year 30% percentile"),
    WHAT((char *) "Fler�rs 40%-persentil", 
	 (char *) "Several year 40% percentile"),
    WHAT((char *) "Fler�rs-median", (char *) "Several year median"),
    WHAT((char *) "Fler�rs 60%-persentil", 
	 (char *) "Several year 60% percentile"),
    WHAT((char *) "Fler�rs 70%-persentil", 
	 (char *) "Several year 70% percentile"),
    WHAT((char *) "Fler�rs 75%-persentil", 
	 (char *) "Several year 75% percentile"),
    WHAT((char *) "Fler�rs 80%-persentil", 
	 (char *) "Several year 80% percentile"),
    WHAT((char *) "Fler�rs 90%-persentil", 
	 (char *) "Several year 90% percentile"),
    WHAT((char *) "Fler�rs 95%-persentil", 
	 (char *) "Several year 95% percentile"),
    WHAT((char *) "Fler�rs 97.5%-persentil", 
	 (char *) "Several year 97.5% percentile"),
    WHAT((char *) "2.5%-persentil",(char *) "2.5% percentile"),
    WHAT((char *) "5%-persentil",  (char *) "5% percentile"),
    WHAT((char *) "10%-persentil", (char *) "10% percentile"),
    WHAT((char *) "20%-persentil", (char *) "20% percentile"),
    WHAT((char *) "25%-persentil", (char *) "25% percentile"),
    WHAT((char *) "30%-persentil", (char *) "30% percentile"),
    WHAT((char *) "40%-persentil", (char *) "40% percentile"),
    WHAT((char *) "Median", (char *) "Median"),
    WHAT((char *) "60%-persentil", (char *) "60% percentile"),
    WHAT((char *) "70%-persentil", (char *) "70% percentile"),
    WHAT((char *) "75%-persentil", (char *) "75% percentile"),
    WHAT((char *) "80%-persentil", (char *) "80% percentile"),
    WHAT((char *) "90%-persentil", (char *) "90% percentile"),
    WHAT((char *) "95%-persentil", (char *) "95% percentile"),
    WHAT((char *) "97.5%-persentil", (char *) "97.5% percentile"),
    WHAT((char *) "Derivert", (char *) "Derivated"),
    WHAT((char *) "Differans", (char *) "Difference"),
    WHAT((char *) "Akkumulerings-differans", 
	 (char *) "Accumulation difference"),
    WHAT((char *) "Konformt transformert p� d�gnbasis", 
	 (char *) "Conform transformation on day-level"),
    WHAT((char *) "Konformt transformert p� ukesbasis", 
	 (char *) "Conform transformation on week-level"),
    WHAT((char *) "Konformt transformert p� �rsbasis", 
	 (char *) "Conform transformation on year-level"),
    WHAT((char *) "Mest forekommende", (char *) "Most frequent")
  };


// *  Description:       To perform a linear interpolation 
// *-----------------------------------------------------------------------*
// *  Programmer: Lars A. Roald, HD
// *  Revised by: Maitrayi Sabaratnam                      Date: 30.6.1993
// *  Changes:    Fortran  to C
// *-----------------------------------------------------------------------*
// *  In-parameters:                                                       *
// *  Ngame       Type     Descri1ption                                      *
// *  X0         real     Lowest X-value in the interval defining the      *
// *                      slope of the linear relation                     *
// *  Y0         real     Lowest Y-value                                   *
// *  X1         real     Highest X-value                                  *
// *  Y1         real     Highest Y-value                                  *
// *  X          real     X-value to be interpolated
// *************************************************************************
float linear(float x0, float y0, float x1, float y1, float x) 
{
  if (x1 - x0 == 0.0 || y0==MISSING_VALUE || y1==MISSING_VALUE) 
    return MISSING_VALUE;
  else 
    return (((y1-y0) / (x1-x0)) * (x-x0) + y0);
}

double linear_double(double x0, double y0, double x1, double y1, double x) 
{
  if (x1 - x0 == 0.0 || y0==MISSING_VALUE || y1==MISSING_VALUE) 
    return MISSING_VALUE;
  else 
    return (((y1-y0) / (x1-x0)) * (x-x0) + y0);
}


// *  Description:       To perform a linear interpolation 
// *-----------------------------------------------------------------------*
// *  Programmer: Lars A. Roald, HD
// *  Revised by: Maitrayi Sabaratnam                      Date: 30.6.1993
// *  Changes:    Fortran  to C
// *-----------------------------------------------------------------------*
// *  In-parameters:                                                       *
// *  Name       Type     Description                                      *
// *  X0         real     Lowest X-value in the interval defining the      *
// *                      slope of the linear relation                     *
// *  Y0         real     Lowest Y-value                                   *
// *  X1         real     Highest X-value                                  *
// *  Y1         real     Highest Y-value                                  *
// *  X          real     X-value to be interpolated
// *************************************************************************
float linear(DateTime x0, float y0, DateTime x1, float y1, DateTime x) 
{
  if ((x1 - x0) == 0 || y0 == MISSING_VALUE || y1 == MISSING_VALUE) 
    return MISSING_VALUE;
  else 
    return (((y1-y0) / float(x1-x0)) * float(x-x0) + y0);
}


// *  Description:       Computes the trapezoid area                       *
// *-----------------------------------------------------------------------*
// *  Programmer: B�rd J. Gr�nbech
// *  Revised by:                                           Date: 26.9.1994
// *-----------------------------------------------------------------------*
// *  In-parameters:                                                       *
// *  Name       Type     Description                                      *
// *  a          float    Value of first point                             *
// *  b          float    Value of second point                            *
// *  da         DateTime first day                                        *
// *  db         DateTime second day                                       *
// *  Out-parameters:                                                      *
// *  dist       unsigned int   adds the new distance                     *
// *  val        float           adds new area                             *
// *-----------------------------------------------------------------------*
// Formula:     (a + b) * ((db - da)/60) / 2
// *************************************************************************
void trapez_area(DateTime da, double  a, DateTime db, double  b, 
		 unsigned int &dist, double  &val) 
{
  unsigned int segmentdist = (db - da) / 60L;
  //    cout << da << "\t" << a << "\t" << val << endl;
  dist += segmentdist;
  if(val==MISSING_VALUE)
    val = (a + b) * ((double) segmentdist) * 0.5;
  else
    val += (a + b) * ((double) segmentdist) * 0.5;
  // cout << db << "\t" << b << "\t" << val << endl << segmentdist << endl;
}

void trapez_area(DateTime da, float a, DateTime db, float b, 
		 unsigned int &dist, float &val) 
{
  unsigned int d = (db - da) / 60L;
  //    cout << da << "\t" << a << "\t" << val << endl;
  dist += d;
  if(val==MISSING_VALUE)
    val = (a + b) * ((float) d) * 0.5;
  else
    val += (a + b) * ((float) d) * 0.5;
  //    cout << db << "\t" << b << "\t" << val << endl << endl;
}


// *  Description:       Prints out text in a convienient way
// *-----------------------------------------------------------------------*
// *  Programmer: B�rd J. Gr�nbech
// *  Revised by:                                           Date: 1.12.1994
// *-----------------------------------------------------------------------*
// *  In-parameters:                                                       *
// *  Name       Type     Description                                      *
// *  o           ostream& output stream                                   *
// *  txt         char *   text to be printed                              *
// *  linelength  int      how many chars on each line                     *
// *  linetoprint int      how many lines to print                         *
// *-----------------------------------------------------------------------*
// *************************************************************************
void PrintText(std::ostream &out, char *txt, int linelength, int linetoprint) 
{
  char *str=Make_Text(txt, linelength, linetoprint);
  
  out << str;
}

// *  Description:       Makes a string in a convenient way
// *-----------------------------------------------------------------------*
// *  Programmer: B�rd J. Gr�nbech
// *  Revised by:                                           Date: 1.12.1994
// *  Revised by: Trond Reitan                              Date: 15.6.2000
// *-----------------------------------------------------------------------*
// *  Returns: a string that's been cut into lines with the specified      *
// *  line length.                                                         *
// *                                                                       *
// *  In-parameters:                                                       *
// *  Name       Type     Description                                      *
// *  txt         char *   text to be printed                              *
// *  linelength  int      how many chars on each line                     *
// *  linetoprint int      how many lines to print                         *
// *-----------------------------------------------------------------------*
// *************************************************************************
char *Make_Text(const char *txt, unsigned int linelength, int linetoprint) 
{
  if(!txt)
    return NULL;
  if(linelength < 1)
    return NULL;
  if(linetoprint < 1)
    return NULL;

  int len = strlen(txt);
  const char *p = txt;
  char *outstr=new char[strlen(txt)+2*strlen(txt)/linelength+20];
  int n = 0;
  register int i;

  outstr[0]='\0';

  while(n < len && linetoprint--) 
    {
      char *tmp = new char[linelength + 5];
      int newlen=MINIM(linelength,strlen(p));
      strncpy(tmp, p, newlen);
      tmp[newlen]='\0';

      for(i = 0; tmp[i]; i++)
	if(tmp[i] == '\n')
	  tmp[i] = ' ';

      n += linelength;
      p += linelength;
      
      if(n  < len) 
	{
	  i = linelength;
	  while(i && tmp[i] != ' ') 
	    {
	      tmp[i--] = '\0';
	      n--;
	      p--;
	    }
	}
	
      sprintf(outstr+strlen(outstr), "%s\n", tmp);
      delete [] tmp;
    }

  return outstr;
}


// *  Description:  Breaks lines larger than "max_linelength", 
// *                keeps the other line breaks
// *-----------------------------------------------------------------------*
// *  Programmer: Trond Reitan
// *  Revised by:                                           Date: 19.6.2017
// *-----------------------------------------------------------------------*
// *  In-parameters:                                                       *
// *  Name            Type         Description                             *
// *  txt             char*        Input text                              *
// *  max_linelength  unisgned int maximum line length                     *
// *                                                                       *
// *  Out-parameters:                                                      *
// *                  char*        Output string with line breaks for long *
// *                               lines                                   *
// *-----------------------------------------------------------------------*
// *************************************************************************
char *break_text(char *txt, unsigned int max_linelength)
{
  int len=strlen(txt);
  char *out=new char[len+10]; // output string
  char *ptr1=txt, // input string position
    *ptr2=out; // output string position
  unsigned int i=0, // counts the number of characters from last line break
    j=0; // counts backwards from new line break.
  
  while(*ptr1) // traverse the input string
    {
      if(i<max_linelength) // max line length not reached yet?
	{
	  // Copy the character from input to output:
	  *ptr2=*ptr1;

	  // If line feed, initialize the number of characters 
	  // from last line break
	  if(*ptr1=='\n')
	    i=0;
	  else // ordinary character?
	    i++; // update the number of characters from last line break
	}
      else // max line length reached!
	{
	  // Count down to last space, '-' or failing that
	  // start of string or start of line:
	  j=0;
	  while(ptr1>txt+j && *(ptr1-j)!=' ' && 
		*(ptr1-j)!='-' && *(ptr1-j)!='\n')
	    j++;
	  
	  if(ptr1<=txt+j || *(ptr1-j)=='\n') // Couldn't find suitable line
					   // break?
	    {
	      // Just put it here:
	      *ptr2='\n';
	    }
	  else // suitable palce for line break (' ' or '.') found
	    {
	      // go back to that position:
	      ptr1-=j;
	      ptr2-=j;
	      if(*ptr1=='-')
		{
		  // Copy the character from input to output:
		  *ptr2=*ptr1;
		  ptr2++;
		}
	      
	      // insert line break:
	      *ptr2='\n';
	    }
	  
	  // initialize the number of characters from last line break
	  i=0;
	}
      
      // update the string positions:
      ptr1++;
      ptr2++;
    }
  *ptr2='\0';
  
  return(out);
}

// *  Description:  Gets time resolution description
// *-----------------------------------------------------------------------*
// *  Programmer: Per Marstein
// *  Revised by:                                           Date: 30.1.1995
// *-----------------------------------------------------------------------*
// *  In-parameters:                                                       *
// *  Name       Type     Description                                      *
// *  res        Float    time resolution                                  *
// *                                                                       *
// *  Out-parameters:                                                      *
// *             char*    time resolution description                      *
// *-----------------------------------------------------------------------*
// *************************************************************************

const char* tresdesc(float res, bool short_desc)
{
  static char tmp[40];
  char min_tmp[10];
  int min;
  
  sprintf(min_tmp,"%.0f",res);
  min = atoi(min_tmp);

  if(!short_desc)
    {
      switch(min) 
	{
	case MIN0:
	  return WHAT(timeresstr2[0], timeresstr_eng[0]);
	case MIN1:
	  return WHAT(timeresstr2[1], timeresstr_eng[1]);
	case MIN5:
	  return WHAT(timeresstr2[2], timeresstr_eng[2]);
	case MIN10:
	  return WHAT("10-minutts-verdier\0", "10 min\0");
	case MIN15:
	  return WHAT(timeresstr2[3], timeresstr_eng[3]);
	case MIN20:
	  return WHAT(timeresstr2[4], timeresstr_eng[4]);
	case MIN30:
	  return WHAT(timeresstr2[5], timeresstr_eng[5]);
	case MIN60:
	  return WHAT(timeresstr2[6], timeresstr_eng[6]);
	case MIN180:
	  return WHAT(timeresstr2[7], timeresstr_eng[7]);
	case MIN360:
	  return WHAT(timeresstr2[8], timeresstr_eng[8]);
	case MIN720:
	  return WHAT(timeresstr2[9], timeresstr_eng[9]);
	case DAY1:
	  return WHAT(timeresstr2[10], timeresstr_eng[10]);
	case DAY5:
	  return WHAT(timeresstr2[11], timeresstr_eng[11]);
	case DAY7:
	  return WHAT(timeresstr2[12], timeresstr_eng[12]);
	case DAY10:
	  return WHAT(timeresstr2[13], timeresstr_eng[13]);
	case 44640:
	case MONTH1:
	  return WHAT(timeresstr2[14], timeresstr_eng[14]);
	case 131040:
	case MONTH3:
	  return WHAT(timeresstr2[15], timeresstr_eng[15]);
	case 263520:
	case 262080:
	case MONTH6:
	  return WHAT(timeresstr2[16], timeresstr_eng[16]);
	case 525600:
	case YEAR1:
	case 527040:
	  return WHAT(timeresstr2[17], timeresstr_eng[17]);
	}
    }
  else
    {
      switch(min) 
	{
	case MIN0:
	  return WHAT(timeresstr[0], timeresstr_eng[0]);
	case MIN1:
	  return WHAT(timeresstr[1], timeresstr_eng[1]);
	case MIN5:
	  return WHAT(timeresstr[2], timeresstr_eng[2]);
	case MIN10:
	  return WHAT("10-min.\0", "10 min.\0");
	case MIN15:
	  return WHAT(timeresstr[3], timeresstr_eng[3]);
	case MIN20:
	  return WHAT(timeresstr[4], timeresstr_eng[4]);
	case MIN30:
	  return WHAT(timeresstr[5], timeresstr_eng[5]);
	case MIN60:
	  return WHAT(timeresstr[6], timeresstr_eng[6]);
	case MIN180:
	  return WHAT(timeresstr[7], timeresstr_eng[7]);
	case MIN360:
	  return WHAT(timeresstr[8], timeresstr_eng[8]);
	case MIN720:
	  return WHAT(timeresstr[9], timeresstr_eng[9]);
	case DAY1:
	  return WHAT(timeresstr[10], timeresstr_eng[10]);
	case DAY5:
	  return WHAT(timeresstr[11], timeresstr_eng[11]);
	case DAY7:
	  return WHAT(timeresstr[12], timeresstr_eng[12]);
	case DAY10:
	  return WHAT(timeresstr[13], timeresstr_eng[13]);
	case 44640:
	case MONTH1:
	  return WHAT(timeresstr[14], timeresstr_eng[14]);
	case 131040:
	case MONTH3:
	  return WHAT(timeresstr[15], timeresstr_eng[15]);
	case 263520:
	case 262080:
	case MONTH6:
	  return WHAT(timeresstr[16], timeresstr_eng[16]);
	case 525600:
	case YEAR1:
	case 527040:
	  return WHAT(timeresstr[17], timeresstr_eng[17]);
	}
    }
  
  sprintf(tmp, WHAT("Tidsoppl�sning: %d min.", 
		    "Time resolution: %d min."), min);
  return tmp;
}





/************ reverse a string **********************/

void reverse(char s[]) 
{
  int c,i,j;
  for (i = 0, j = strlen(s) -1; i <j; i++, j--) 
    {
      c = s[i];
      s[i] = s[j];
      s[j] =c;
    }
}

// returns 1 if val lies between val1 and val2
int between(float val1,float val,float val2)
{
  if(val>=val1 && val<=val2)
    return 1;
  if(val>=val2 && val<=val1)
    return 1;
  return 0;
}






char largecase(char c)
{
  char r=c;
  if(c>='a' && c<='z')
    r=c-'a'+'A';
  if(c=='�')
    r='�';
  if(c=='�')
    r='�';
  if(c=='�')
    r='�';
  return r;
}

char smallcase(char c)
{
  char r=c;
  if(c>='A' && c<='Z')
    r=c-'A'+'a';
  if(c=='�')
    r='�';
  if(c=='�')
    r='�';
  if(c=='�')
    r='�';
  return r;
}


// full name of user, using 'finger';
char *full_name(void)
{
  char pwname[100];
  char command[100];
  std::ifstream inp;
  char strbuff[100];
  char *name;
  
#ifdef NVE
  strcpy(pwname,hydraenvir::system::get_user_name().c_str());
#else
  strcpy(pwname,getpwuid(getuid())->pw_name);
#endif //NVE
  sprintf(command,"finger %s > /tmp/fullname",pwname);
  system(command);
  
  inp.open("/tmp/fullname",std::ios::in);
  inp.getline(strbuff,100);
  name=strstr(strbuff,"In real life: ");
  if(name)
    {
      name+=14;
      return name;
    }
  else 
    return "";
}



// name is on the format: LASTNAME, FIRSTNAME
// wewant it as; Firstname Lastname
char *unscramblename(char *name)
{
  char *ptr, *ret = new char[1000];
  int i=0;

  ptr=strstr(name,",");
  if(ptr)
    {
      while((*ptr==',' || *ptr==' ') && *ptr!='\0')
	ptr++;
      ret[i++]=largecase(*ptr);
      ptr++;
      while(*ptr!='\0')
	{
	  ret[i++]=smallcase(*ptr);
	  ptr++;
	}
      ret[i++]=' ';

      ptr=name;
      ret[i++]=largecase(*ptr);
      ptr++;
      while(*ptr!=' ' && *ptr!=',' && *ptr!='\0')
	{
	  ret[i++]=smallcase(*ptr);
	  ptr++; 
	}
      ret[i]='\0';
    }
  else
    strcpy(ret,name);

  return ret;
}


/************* convert an integer to a string **********/
void itoa( int n, char s[]) 
{
  int i, sign;
    
  if ((sign =n) <0)
    n= -n;
    
  i =0;
  do 
    {
      s[i++] = n%10 + '0';
    } while (( n /= 10) > 0);
    
  if (sign < 0) s[i++] = '-';
  s[i] = '\0';
  reverse(s);
}


// Removes blanks from the start and end of a string, and returns the result
char *stripspaces(char *in_string)
{ 
  int  teller;
  while (*in_string == ' ' ) in_string++;     // Remove leading blanks
  teller = strlen(in_string);  // Length of the string without leading blanks
  if (teller >=1)
    {
      while (in_string[--teller] == ' ') in_string[teller] = '\0'; 
      // Remove the blanks at the end of the string
    }
   
  return in_string;
}

// Made to get orig_value modulo modulo_value for arbitrary real numbers:
double double_modulo(double orig_value, double modulo_value)
{
  double value=orig_value;
  double substract_number=floor(value/modulo_value);
  
  value -= substract_number*modulo_value;

  while(value<0.0)
    value+=modulo_value;
  while(value>modulo_value)
    value-=modulo_value;
  
  return value;
}

// Count the number of spaces between contents
// For instant "ajksdh   skjdfh     sasasd" would return "2".
int count_spaces(char *line)
{
  int count=0;
  int has_been_content=0, has_been_spaces=0;

  for(unsigned int i=0;i<strlen(line);i++)
    {
      if(line[i]!=' ' && line[i]!='\t')
	{
	  has_been_content=1;
	  if(has_been_spaces)
	    count++;
	  has_been_spaces=0;
	}
      else if(has_been_content)
	has_been_spaces=1;
    }

  return count;
}



void space(char *str,int l)
{
  for(int i=0;i<l;i++)
    str[i]=' ';
  str[l]='\0';
}

void shorten(char *str, unsigned int len)
{
  if(strlen(str)<=len || len<3)
    return;

  str[len]='\0';
  str[len-1]=str[len-2]=str[len-3]='.';
}

char *uppercase_to_lowercase(char *origstr)
{
  int i,len=strlen(origstr);
  char *ret=new char[len+1];
  
  strcpy(ret, origstr);
  for(i=0;i<len;i++)
    {
      if(ret[i]>='A' && ret[i]<='Z')
	{
	  ret[i]+='a';
	  ret[i]-='A';
	}
      else if(ret[i]=='�')
	ret[i]='�';
      else if(ret[i]=='�')
	ret[i]='�';
      else if(ret[i]=='�')
	ret[i]='�';
    }
  
  return ret;
}

char *lowercase_to_uppercase(char *origstr)
{
  int i,len=strlen(origstr);
  char *ret=new char[len+1];
  
  strcpy(ret, origstr);
  for(i=0;i<len;i++)
    {
      if(ret[i]>='a' && ret[i]<='z')
	{
	  ret[i]+='A';
	  ret[i]-='a';
	}
      else if(ret[i]=='�')
	ret[i]='�';
      else if(ret[i]=='�')
	ret[i]='�';
      else if(ret[i]=='�')
	ret[i]='�';
    }
  
  return ret;
}



void norwegiansigns(char *outstr,char *instr)
{
  char *ptr=instr,*ptr2=outstr;

  while(ptr[0] && ptr[1])
    {
      if(ptr[0]=='a' && ptr[1]=='e')
	{
	  *ptr2='�';
	  ptr++;
	}
      else if(ptr[0]=='o' && ptr[1]=='e')
	{
	  *ptr2='�';
	  ptr++;
	}
      else if(ptr[0]=='a' && ptr[1]=='a')
	{
	  *ptr2='�';
	  ptr++;
	}
      else
	*ptr2=*ptr;

      ptr2++;
      ptr++;
    }

  if(*ptr)
    {
      *ptr2=*ptr;
      ptr2++;
    }

  *ptr2=(char) 0;
}


char *break_up_long_string(char *str, int /*line_len*/)
{
  int slen=strlen(str);
  char *newstr=new char[slen+10+slen/10];
  char *currptr=str,*nextptr=str+100;
  char *currnewptr=newstr;
  bool end_met=false;

  while(!end_met)
    {
      if(nextptr>str+slen)
	{
	  while(*currptr!='\0')
	    {
	      *currnewptr=*currptr;
	      currnewptr++;
	      currptr++;
	    }
	  *currnewptr=*currptr;
	  end_met=true;
	}
      else
	{
	  while(*nextptr!=' ')
	    nextptr--;
	  
	  while(currptr!=nextptr)
	    {
	      *currnewptr=*currptr;
	      currnewptr++;
	      currptr++;
	    }
	  *currnewptr='\n';
	  currnewptr++;
	  currptr=nextptr;
	  nextptr+=100;
	}
    }

  return newstr;
}


// A method for makeing a string into a datetime. Returns 
// wether the transition was feasable (1) or not (0).
int getdatefromstring(char *string,DateTime *datetime)
{
  DateTime dt(string);
  *datetime=dt;

  if(!strcasecmp(string,"nodate"))
    {
      *datetime=NoDateTime;
      return 1;
    }

  if(dt.legal())
    return 1;
  else
    return 0;
}


// fetches the next integer and returns a pointer to 
// the end of the fetched text
char *getnextint(char *instr,int *nextint, int missing)
{
  char *ptr=instr;
  
  *nextint=missing;

  while(!isdigit(*ptr) && *ptr!='-')
    {
      if(!(*ptr))
	return NULL;
      
      ptr++;
    }
  
  if(!sscanf(ptr,"%d",nextint))
    return NULL;
  
  while(*ptr && isdigit(*ptr))
    ptr++;
  
  return ptr;
}


// fetches the next float and returns a pointer to 
// the end of the fetched text
char *getnextfloat(char *instr,float *nextfloat, float missing)
{
  char *ptr=instr;
  
  *nextfloat=missing;

  while(!isdigit(*ptr) && *ptr!='+' && *ptr!='-' &&
	strncmp(ptr,"---",3) && strncasecmp(ptr, "missing", 7) &&
	strncasecmp(ptr, "na", 2))
    {
      if(!(*ptr))
	return NULL;
      
      ptr++;
    }

  if(!strncmp(ptr,"---",3) || !strncasecmp(ptr, "missing", 7) || 
     !strncasecmp(ptr, "na", 2))
    *nextfloat=MISSING_VALUE;
  else if(!sscanf(ptr,"%f",nextfloat))
    return NULL;
  
  while(*ptr && *ptr!=' ' && *ptr!='\t' && *ptr!=',')
    ptr++;
  
  return ptr;
}

// fetches the next double and returns a pointer to 
// the end of the fetched text
char *getnextdouble(char *instr, double *nextdouble,double missing)
{
  char *ptr=instr;
  
  *nextdouble=missing;

  while(!isdigit(*ptr) && *ptr!='+' && *ptr!='-' &&
	strncmp(ptr,"---",3) && strncasecmp(ptr, "missing", 7) &&
	strncasecmp(ptr, "na", 2))
    {
      if(!(*ptr))
	return NULL;
      
      ptr++;
    }

  
  if(!strncmp(ptr,"---",3) || !strncasecmp(ptr, "missing", 7) || 
     !strncasecmp(ptr, "na", 2))
    *nextdouble=MISSING_VALUE;
  else if(!sscanf(ptr,"%lf",nextdouble))
    return NULL;
  
  while(*ptr && *ptr!=' ' && *ptr!='\t' && *ptr!=',' && *ptr!=';' && *ptr!=':')
    ptr++;
  
  return ptr;
}

// fetches the next string and returns a pointer to 
// the end of the fetched text
char *getnextstr(char *instr,char *nextstr)
{
  int hasdelimiter=0;
  char *ptr=instr;
  
  strcpy(nextstr,"");

  while(*ptr==' ' || *ptr==',' || *ptr=='\t')
    {
      if(!(*ptr))
	return NULL;
      
      if(*ptr=='\"')
	{
	  hasdelimiter=1;
	  ptr++;
	  break;
	}
      
      ptr++;
    }

  
  char *nextptr=nextstr;

  while(*ptr && (hasdelimiter || (*ptr!=' ' && *ptr!=',' && *ptr!='\t')))
    {
      if(hasdelimiter && *ptr=='\"')
	{
	  ptr++;
	  break;
	}
      
      *nextptr=*ptr;
      ptr++;
      nextptr++;
    }
  *nextptr='\0';

  return ptr;
}

// fetches the next delimited ("this is a delimited string")
// string and returns a pointer to the end of the fetched text
char *getnextdelimitedstr(char *instr,char *nextstr)
{
  char *ptr=instr;
  
  strcpy(nextstr,"");

  while(*ptr!='\"')
    {
      if(!(*ptr))
	return NULL;
      
      ptr++;
    }
  ptr++;

  int i=0;
  while(*ptr!='\"' && *ptr!='\0')
    {
      nextstr[i++]=*ptr;
      ptr++;
    }

  if(!nextstr[0])
    return NULL;
  nextstr[i]='\0';

  if(*ptr=='\"')
    ptr++;

  return ptr;
}

// removes all but the first significant number in 
// a floating point value
float shorten_float(float in_value)
{
  float sign=(in_value>0.0) ? 1.0 : -1.0;
  //  int scale=(int) ffloor(flog10(sign*in_value));
  int scale=(int) floor(log10(sign*in_value)); //erikt
  double scaled_value=((double) (sign*in_value)) / pow((double) 10 , 
						       (double) scale);
  int nearest=(int) rint(scaled_value);
  float out_value=sign * ((float) nearest) * ((float) pow((double) 10 ,
							  (double) scale));
  return out_value;
}


// return wether one value is veru near another...
// In this case by less than 0.01%.
int very_near(float v1,float v2, int decimals)
{
  float power=(float)pow(10.0, decimals);
  float dev = (v1==0.0) ? 1e-20 : v1/power;

  if(dev<0)
    dev=-dev;

  if(v2>=(v1-dev) && v2<=(v1+dev))
    return 1;
  else
    return 0;
}


const char *get_timeres_name(BASE_TIME btime, int type)
{
  for(int i=0;i<timeres_arraylen;i++)
    if(btime==timeresarray[i])
      {
	if(type==1)
	  return WHAT(timeresstr[i], timeresstr_eng[i]);
	else
	  return timeresstr2[i];
      }

  return "";
}


BASE_TIME get_base_time(const char *btimename)
{
  int i;

  for(i=0;i<timeres_arraylen;i++)
    if(!strcasecmp(btimename,timeresstr[i]))
      return timeresarray[i];

  for(i=0;i<timeres_arraylen;i++)
    if(!strcasecmp(btimename,timeresstr2[i]))
      return timeresarray[i];

  for(i=0;i<timeres_arraylen;i++)
    if(!strcasecmp(btimename,timeresstr_eng[i]))
      return timeresarray[i];

  return UNKNOWN_TIMERES;
}

// Replaces one string pattern with another in the input string 'instring'
// and puts the result into the output string 'outstring' (should
// be allocated in advance). Returns 1 if the old pattern was found.
int replace_string(char *outstring, char *instring, 
		   char *oldpattern, char *newpattern)
{
  char *ptr=outstring;
  int i,len=strlen(instring),plen=strlen(oldpattern),nlen=strlen(newpattern);
  int found=0;

  for(i=0;i<len;i++)
    {
      if(len-i >= plen && !strncmp(instring+i, oldpattern, plen))
	{
	  strcpy(ptr, newpattern);
	  ptr+=nlen;
	  i+=plen-1;
	  found=1;
	}
      else
	{
	  *ptr=instring[i];
	  ptr++;
	}
    }
  *ptr='\0';

  return found;
}



// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for qsort() in the 'percentile' method
// ######################################################################
int compare_int(const void *i, const void *j) 
{
  int v =  *(int *)i - *(int *)j;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

int compare_int_descending(const void *i, const void *j) 
{
  int v =  *(int *)i - *(int *)j;
  if(v < 0)
    return 1;
  else if(v == 0)
    return 0;
  else
    return -1;
} /* compar */

// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for qsort() in the 'percentile' method
// ######################################################################
int compare_double(const void *i, const void *j) 
{
  double v =  *(double *)i - *(double *)j;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

int compare_double_descending(const void *i, const void *j) 
{
  double v =  *(double *)i - *(double *)j;
  if(v < 0)
    return 1;
  else if(v == 0)
    return 0;
  else
    return -1;
} /* compar */

int compare_absdouble(const void *i, const void *j) 
{
  double v =  abs(*(double *)i) - abs(*(double *)j);
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

int compare_absdouble_descending(const void *i, const void *j) 
{
  double v =  abs(*(double *)i) - abs(*(double *)j);
  if(v < 0)
    return 1;
  else if(v == 0)
    return 0;
  else
    return -1;
} /* compar */



// Used for sorting string names;
int compare_string(const void *i, const void *j) 
{
  char *v1 =  *(char **)i;
  char *v2 =  *(char **)j;
  int v=strcmp(v1,v2);
  
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compare_string */


// Used for sorting category names;
int compare_string_caseinsensitive(const void *i, const void *j)
{
  char *v1 =  *(char **)i;
  char *v2 =  *(char **)j;
  int v=strcasecmp(v1,v2);
  
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compare_string */


char **unique_strings(char **strings, int len, 
		      int *unique_len)
{
  char **cnames=new char*[len];
  char **unames=new char*[len];
  int i;

  for(i=0;i<len;i++)
    {
      cnames[i]=new char[strlen(strings[i])+5];
      unames[i]=new char[1000];
      strcpy(cnames[i],strings[i]);
    }
  
  qsort(cnames, size_t(len), sizeof(char *), compare_string);
  
  int ulen=0;
  for(i=0;i<len;i++)
    {
      if(i==0 || strcmp(cnames[i], cnames[i-1]))
	{
	  strcpy(unames[ulen], cnames[i]);
	  ulen++;
	}
    }

  char **ret=new char*[ulen];
  for(i=0;i<ulen;i++)
    {
      ret[i]=new char[strlen(unames[i])+5];
      strcpy(ret[i], unames[i]);
    }

  doubledelete(cnames,len);
  doubledelete(unames,len);

  *unique_len=ulen;
  return ret;
}

char **unique_strings_caseinsensitive(char **strings, int len, 
		      int *unique_len)
{
  char **cnames=new char*[len];
  char **unames=new char*[len];
  int i;

  for(i=0;i<len;i++)
    {
      cnames[i]=new char[strlen(strings[i])+5];
      unames[i]=new char[1000];
      strcpy(cnames[i],strings[i]);
    }
  
  qsort(cnames, size_t(len), sizeof(char *), compare_string_caseinsensitive);
  
  int ulen=0;
  for(i=0;i<len;i++)
    {
      if(i==0 || strcasecmp(cnames[i], cnames[i-1]))
	{
	  strcpy(unames[ulen], cnames[i]);
	  ulen++;
	}
    }

  char **ret=new char*[ulen];
  for(i=0;i<ulen;i++)
    {
      ret[i]=new char[strlen(unames[i])+5];
      strcpy(ret[i], unames[i]);
    }

  doubledelete(cnames,len);
  doubledelete(unames,len);

  *unique_len=ulen;
  return ret;
}




#include <sys/stat.h>
DateTime *getfiletime(char *fullfilename)
{
  struct stat st;

  if(stat(fullfilename, &st))
    return NULL;

  

  /* Irix and Linux uses different timestructs when retreving time specs from
     a file. 

  On Linux:
  time_t        st_mtime;    // time of last modification 

  On Irix:
  timespec_t     st_mtim;     // Time of last data modification 
  
  (See 'man 2 stat' on both platforms.)
  */

  DateTime *dt = NULL;

  #ifdef IRIX // erikt
  timespec_t t=st.st_mtim; 
  time_t sec = t.tv_sec;
  tm *local=localtime(&sec); 

 

  if(local->tm_year<50)
    dt = new DateTime(local->tm_year+2000, local->tm_mon+1, 
		      local->tm_mday, local->tm_hour, 
		      local->tm_min, local->tm_sec);
  else
    dt = new DateTime(local->tm_year+1900, local->tm_mon+1, 
		      local->tm_mday, local->tm_hour, 
		      local->tm_min, local->tm_sec);

  //cout << local->tm_year << endl;

  // DateTime *dt=new DateTime(1970,1,1);
  
  // (*dt)+=(long) sec;
  #endif
  

  #ifdef LINUX // erikt
  time_t t=st.st_mtime; 
  tm *local=localtime(&t); 

  if(local->tm_year<50)
    dt = new DateTime(local->tm_year+2000, local->tm_mon+1, 
		      local->tm_mday, local->tm_hour, 
		      local->tm_min, local->tm_sec);
  else
    dt = new DateTime(local->tm_year+1900, local->tm_mon+1, 
		      local->tm_mday, local->tm_hour, 
		      local->tm_min, local->tm_sec);
 
  #endif

  return dt;
}

DateTime *getfiletime(char *directory, char *filename)
{
  char fullname[1000];

  if(directory[strlen(directory)-1]=='/')
    sprintf(fullname,"%s%s",directory,filename);
  else
    sprintf(fullname,"%s/%s",directory,filename);

  return getfiletime(fullname);
}


void do_log(char *logfilename)
{
  DateTime now;

  std::ofstream out;
  out.open(logfilename,std::ios::app);
  if(out.fail())
    return;
  now.now();

#ifdef NVE
  out << hydraenvir::system::get_user_name().c_str() << " : " << now << std::endl;
#else
  out << getpwuid(getuid())->pw_name << " : " << now << std::endl;
#endif // NVE
}



int almost_equal(float v1, float v2)
{
  if(fabs(v1-v2)<1e-20)
    return 1;

  if(fabs(v1)>0.999999*fabs(v2) && fabs(v1)<1.0000001*fabs(v2) &&
     ((v1<0.0 && v2< 0.0) || (v1>0.0 && v2>0.0)))
    return 1;

  return 0;
}

int almost_equal(double v1, double v2)
{
  if(fabs(v1-v2)<1e-20)
    return 1;

  if(fabs(v1)>0.999999*fabs(v2) && fabs(v1)<1.0000001*fabs(v2) &&
     ((v1<0.0 && v2< 0.0) || (v1>0.0 && v2>0.0)))
    return 1;

  return 0;
}

#ifdef ENGLISH_LANGUAGE
Language language=English;
#else
Language language=Norwegian;
#endif

int randify(bool reseed)
{
  static bool visited=false;
  DateTime now,then(1970,1,1); 
  now.now();
 
#ifdef NVE
  long int seed=(now-then)+hydraenvir::system::get_pid();  
#else
  long int seed=(now-then)+getpid();
#endif // NVE

  if(!visited || reseed)
    {
      srand48(seed);
      srandom(seed);
    }

  visited=true;

  return seed;
}

// Find minima using the golden section algorithm
// See chapter 14 of Cheney & Kincaid's Numerical Mathematics and Computing
double find_extreme(double (*func)(double), double start, double end,
		    int &maxiter, bool minimum)
{
  double sign=minimum ? 1.0 : -1.0;
  double a=start, b=end;
  double r=0.5*(sqrt(5.0)-1); // golden section
  double x=a+r*(b-a), y=a+r*r*(b-a);
  double u=sign*func(x), v=sign*func(y), df=u-v;
  int i=0;

  while(i<maxiter) 
    {
      if(df>0.0)
	{
	  b=x;
	  x=y;
	  u=v;
	  y=a+r*r*(b-a);
	  v=sign*(*func)(y);
	}
      else
	{
	  a=y;
	  y=x;
	  v=u;
	  x=a+r*(b-a);
	  u=sign*(*func)(x);
	}

      df=u-v;
      i++;
    } 

  maxiter=i;

  return (a+b)/2.0;
}

void set_number_as_string(char *str, double number, int decimals, 
			  int engeneeringform_limit,
			  bool cutzeroes)
{
  double absv = ABSVAL(number);
  int order = (absv==0.0) ? 0 : (int) floor(log10(absv));
  char buffer[200], *ptr;
  bool dotencountered=false;
  double corr = number * pow(10.0, -decimals-2);

  number+=corr;
  absv = ABSVAL(number);
  order = (absv==0.0) ? 0 : (int) floor(log10(absv));

  corr = 5.0 * pow(10.0, order-decimals-1);
  number+=corr;

  number *= pow(10.0, -order+decimals);
  number = floor(number);
  number /= pow(10.0, -order+decimals);

  absv = ABSVAL(number);
  order = (absv==0.0) ? 0 : (int) floor(log10(absv));

  if(number<1e-16 && number>(-1e-16))
    strcpy(buffer, "%1.0f");
  //else if((order>decimals && order>3) || (order<=-decimals && order<-3))
  else if((order>decimals && order>engeneeringform_limit) || 
	  (order<=-decimals && order<-engeneeringform_limit))
    sprintf(buffer, "%%1.%de",  decimals);
  else if(order<0)
    sprintf(buffer, "%%1.%df",  decimals-order-1);
  else if(order<decimals)
    sprintf(buffer, "%%%d.%df", order+1, decimals-order);
  else 
    sprintf(buffer, "%%%d.0f",  order+1);

  sprintf(str, buffer, number);

  if(cutzeroes)
    {
      ptr = str + (strlen(str)-1);
      if(strstr(str, "."))
	while(!dotencountered && ptr>str && (*ptr=='0' || *ptr=='.'))
	  {
	    if(*ptr=='.')
	      dotencountered=true;
	    ptr--;
	  }
      
      *(ptr+1)='\0';
    }
}

double gauss(void)
{
  return sqrt(-2.0*log(drand48()))*sin(2.0*M_PI*drand48());
}

void shorten_name(char *newstr, char *oldstr, unsigned int newmaxlen,
		  int padd_string)
{
  strncpy(newstr, oldstr, MINIM(newmaxlen, strlen(oldstr)));
  if(strlen(oldstr)<=newmaxlen)
    {
      if(!padd_string)
	newstr[strlen(oldstr)]='\0';
      else
	{
	  for(int i=strlen(oldstr);i<(int) newmaxlen;i++)
	    newstr[i]=' ';
	  newstr[newmaxlen-1]='\0';
	}
    }
  else if(newmaxlen>=10)
    strcpy(newstr+newmaxlen-3, "...");
  else
    strcpy(newstr+newmaxlen-1, ".");
}




// FIND_MEAN
// Finds the mean value of a timeserie
// Parameters: data - the timeserie
//             len  - the length of the serie
//             procent_needed - the procent of the data needed tp
//                              extract the mean value
double find_mean(double *data, int len, double procent_needed)
{
  double meanval=0.0;
  int num=0;
  int requiredlen=(int) (((double) len)*procent_needed/100.0);

  // loop through the data...
  for(register int i=0;i<len;i++)
    if(data[i]!=MISSING_VALUE)
      {
	meanval+=data[i]; // increment the mean value
	num++; // increment the number of values used
      }

  if(num<requiredlen) // if th enumber of values found was less than needed...
    return MISSING_VALUE;

  return meanval/num;
}

// FIND_MEAN
// Finds the mean value of a timeserie
// Parameters: data - the timeserie
//             len  - the length of the serie
//             procent_needed - the procent of the data needed tp
//                              extract the mean value
float find_mean(float *data, int len, float procent_needed)
{
  double *newdata=new double[len];
  float ret;

  for(register int i=0; i<len;i++)
    newdata[i]=data[i];

  ret=find_mean(newdata, len, procent_needed);

  delete [] newdata;

  return (float) ret;
}


// FIND_STDEV
// Find the standard deviation of a time serie
// Parameters: data - the timeserie
//             len  - the length of the serie
//             procent_needed - the procent of the data needed tp
//                              extract the mean value
//             mean - the mean value of the time serie 
//                    (can be set to MISSING_VALUE)
float find_stdev(float *data, int len, 
		 float procent_needed, float mean)
{
  double *newdata=new double[len];
  float ret;

  for(register int i=0; i<len;i++)
    newdata[i]=data[i];

  ret=find_stdev(newdata, len, procent_needed, (double) mean);

  delete [] newdata;

  return (float) ret;
}

// FIND_STDEV




// FIND_STDEV
// Find the standard deviation of a time serie
// Parameters: data - the serie
//             len  - the length of the serie
//             procent_needed - the procent of the data needed tp
//                              extract the mean value
//             mean - the mean value of the time serie 
//                    (can be set to MISSING_VALUE)
double find_stdev(double *data, int len, 
		  double procent_needed, double mean)
{
  double var=0.0;
  int num=0;
  int requiredlen=(int) (((double) len)*procent_needed/100.0);

  if(mean==MISSING_VALUE)
    mean=find_mean(data, len, procent_needed);

  if(mean==MISSING_VALUE)
    return MISSING_VALUE;

  // loop through the data...
  for(register int i=0;i<len;i++)
    if(data[i]!=MISSING_VALUE)
      {
	// increment the variance
	var += (data[i]-mean)*(data[i]-mean); 
	
	num++; // increment the number of values used
      }

  if(num<requiredlen) // if the number of values found was less than needed...
    return MISSING_VALUE;

  if(var==MISSING_VALUE)
    return var;

  return sqrt(var/double(num-1));
}


bool enough(double *data, int len, double procent_needed)
{
  int miss_found=0;

  for(register int i=0;i<len;i++)
    if(data[i]==MISSING_VALUE)
      miss_found++;
  
  if(double(len-miss_found)*100.0 < procent_needed)
    return false;
  else
    return true;
}


float find_statistics(float *data, int len, METHOD met, 
		      float procent_needed)
{
  double *newdata=new double[len];
  float ret;

  for(register int i=0; i<len;i++)
    newdata[i]=data[i];

  ret=find_statistics(newdata, len, met, procent_needed);

  delete [] newdata;

  return (float) ret;
}

double find_statistics(double *data, int len, METHOD met, 
		       double procent_needed)
{
  if(!enough(data, len, procent_needed))
    return MISSING_VALUE;

  if(met==MEAN || met==SEVERAL_YEAR_MEAN)
    return find_mean(data, len, procent_needed); // in order to speed things up
  else if(met==STANDARD_DEVIATION || met==SEVERAL_YEAR_STANDARD_DEVIATION)
    return find_stdev(data, len, procent_needed);
  else if(met==STANDARD_ERROR)
    return find_stdev(data, len, procent_needed)/sqrt(double(len));
  else if(met==MEAN_PLUS_SDEV || met==SEVERAL_YEAR_MEAN_PLUS_SDEV || 
	  met==MEAN_PLUS_SERR || met==MEAN_PLUS_2SERR)
    {
      double mean=find_mean(data, len, procent_needed);
      double sdev=find_stdev(data, len, procent_needed, mean);

      if(met==MEAN_PLUS_SERR)
	sdev/=sqrt(double(len));
      else if(met==MEAN_PLUS_2SERR)
	sdev*=2.0/sqrt(double(len));

      return mean+sdev;
    }
  else if(met==MEAN_MINUS_SDEV || met==SEVERAL_YEAR_MEAN_MINUS_SDEV || 
	  met==MEAN_MINUS_SERR || met==MEAN_MINUS_2SERR)
    {
      double mean=find_mean(data, len, procent_needed);
      double sdev=find_stdev(data, len, procent_needed, mean);

      if(met==MEAN_MINUS_SERR)
	sdev/=sqrt(double(len));
      else if(met==MEAN_MINUS_2SERR)
	sdev*=2.0/sqrt(double(len));

      return mean-sdev;
    }

  double val=MISSING_VALUE;
  register int i;
      
  if((met>=SEVERAL_YEAR_PERCENTILE_2_5 && met<=SEVERAL_YEAR_PERCENTILE_97_5) ||
     (met>=PERCENTILE_2_5 && met<=PERCENTILE_97_5))
    {
      double *databuffer=new double[len];
      double perc=0.0;

      switch(met)
	{
	case SEVERAL_YEAR_PERCENTILE_2_5:
	case PERCENTILE_2_5:
	  perc=2.5;
	  break;
	case SEVERAL_YEAR_PERCENTILE_5:
	case PERCENTILE_5:
	  perc=5.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_10:
	case PERCENTILE_10:
	  perc=10.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_20:
	case PERCENTILE_20:
	  perc=20.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_25:
	case PERCENTILE_25:
	  perc=25.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_30:
	case PERCENTILE_30:
	  perc=30.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_40:
	case PERCENTILE_40:
	  perc=40.0;
	  break;
	case SEVERAL_YEAR_MEDIAN:
	case MEDIAN:
	  perc=50.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_60:
	case PERCENTILE_60:
	  perc=60.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_70:
	case PERCENTILE_70:
	  perc=70.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_75:
	case PERCENTILE_75:
	  perc=75.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_80:
	case PERCENTILE_80:
	  perc=80.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_90:
	case PERCENTILE_90:
	  perc=90.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_95:
	case PERCENTILE_95:
	  perc=95.0;
	  break;
	case SEVERAL_YEAR_PERCENTILE_97_5:
	case PERCENTILE_97_5:
	  perc=97.5;
	  break;
	default:
	  break;
	}
      
      int newlen=0;
      for(i=0;i<len;i++)
	if(data[i]!=MISSING_VALUE)
	  {
	    databuffer[newlen]=data[i];
	    newlen++;
	  }

      if(newlen==0)
	{
	  delete [] databuffer;
	  return MISSING_VALUE;
	}

      int p = int((newlen-1) * perc/100.0), q = int((newlen-1) * perc/100.0 + 
						    0.99999);

      qsort(databuffer, newlen, sizeof(double), compare_double);

      if(p == q)		// Match a perfect index
	val = databuffer[p];
      else 
	/*
	 * Lies between to data points. Percentil is calculated
	 * with linear interpolation.
	 */
	val = linear(p, databuffer[p], q, databuffer[q], 
		     double(newlen-1) * perc/100.0);
      
      delete [] databuffer;
    }
  else if(met==MAX || met==SEVERAL_YEAR_MAX)
    {
      val=data[0];
      for(i=1;i<len;i++)
	if(val==MISSING_VALUE || (data[i]>val && data[i]!=MISSING_VALUE))
	  val=data[i];
    }
  else if(met==MIN || met==SEVERAL_YEAR_MIN)
    {
      val=data[0];
      for(i=1;i<len;i++)
	if(val==MISSING_VALUE || (data[i]<val && data[i]!=MISSING_VALUE))
	  val=data[i];
    }
  else if(met==SUM || met==SEVERAL_YEAR_SUM)
    {
      val=0.0;
      for(i=0;i<len;i++)
	if(data[i]!=MISSING_VALUE)
	  val += data[i];
    }
  else if(met==VARIATION)
    {
      double mean=find_mean(data, len, procent_needed);
      int found=0;

      val=0.0;
      for(i=0;i<len;i++)
	if(data[i]!=MISSING_VALUE)
	  {
	    val += (data[i]-mean)*(data[i]-mean);
	    found++;
	  }

      val /= double(found-1);
    }
  else if(met==AVERAGE_DEVIATION)
    {
      int found=0;

      val = 0.0;
      for(i=1;i<len;i++)
	if(data[i]!=MISSING_VALUE && data[i-1]!=MISSING_VALUE)
	  {
	    // cumbersome method, but in case of missing data, we'll need it
	    val += (data[i]-data[i-1]);
	    found++;
	  }
      if(data[0]!=MISSING_VALUE && data[len-1]!=MISSING_VALUE)
	{
	  val += (data[0]-data[len-1]);
	  found++;
	}

      val /= double(found);
    }
  else if(met==SKEW)
    {
      double mean=find_mean(data, len, procent_needed);
      double sdev=find_stdev(data, len, procent_needed, mean);
      int found=0;

      val=0.0;
      for(i=0;i<len;i++)
	if(data[i]!=MISSING_VALUE)
	  {
	    val += (data[i]-mean)*(data[i]-mean)*(data[i]-mean);
	    found++;
	  }

      val *= double(found)/double(found-1)/double(found-2);
      val /= (sdev*sdev*sdev);
    }
  else if(met==CURTOSIS)
    {
      double mean=find_mean(data, len, procent_needed);
      double sdev=find_stdev(data, len, procent_needed, mean);
      int found=0;

      val=0.0;
      for(i=0;i<len;i++)
	if(data[i]!=MISSING_VALUE)
	  {
	    val += (data[i]-mean)*(data[i]-mean)*(data[i]-mean)*(data[i]-mean);
	    found++;
	  }

      val *= double(found)*double(found+1)/double(found-1)/double(found-1)/
	double(found-1);
      val /= (sdev*sdev*sdev*sdev);
    }
  else if(met==MOST_FREQUENT)
    {
      int i, j, numcath=0, maxnum=0;
      struct double_cathegory
      {
	double val;
	int num;
      };
      double_cathegory *cath=new double_cathegory[len];
      
      for(i=0;i<len;i++)
	cath[i].num=0;

      for(i=0;i<len;i++)
	{
	  int found=0;

	  for(j=0;j<numcath && !found;j++)
	    if(almost_equal(cath[j].val, data[i]))
	      {
		found=1;
		cath[j].num++;
	      }

	  if(!found)
	    {
	      cath[numcath].val=data[i];
	      cath[numcath].num++;
	      
	      numcath++;
	    }
	}
      
      for(j=0;j<numcath;j++)
	if(maxnum < cath[j].num)
	  {
	    val = cath[j].val;
	    maxnum = cath[j].num;
	  }

      delete [] cath;
    }

  return val;
}


double find_percentile(double *data, int len, 
		       double percentile /* 0.0 - 1.0 */,
		       bool pre_sorted)
{
  if(!pre_sorted)
    qsort(data, size_t(len), sizeof(double), compare_double);
  
  int index=(int) floor(percentile*double(len+1))-1;
  
  if(index<0)
    index=0;
  if(index>len-2)
    index=len-2;
  
  double extra=percentile*double(len+1)-1.0-double(index);
  double perc=MISSING_VALUE;

  if(index>=0 && index<=len-2)
    perc=(1.0-extra)*data[index]+extra*data[index+1];

  return perc;
}


// REMOVE_TRAILING_MISSING_VALUES
// Makes a new float array without the 
// missing values at the end of the incoming array
double *remove_trailing_missing_values(double *values,int len,int *outlen)
{
  register int i;
  double *outvalues;

  *outlen=0;
  // find the index of the last non-missing value
  for(i=len-1;i>=0;i--)
    if(values[i]!=MISSING_VALUE)
      break;

  if(i<0)
    return NULL;
  
  *outlen=i+1; // set the returned length
  outvalues=new double[*outlen];
  // set the outgoing values
  for(i=0;i<*outlen;i++)
    outvalues[i]=values[i];

  return outvalues;
}

// REMOVE_MISSING_VALUES_FROM_ENDPTS
// Makes a new float array without the 
// missing values at the start and end of the incoming array
double *remove_missing_values_from_endpts(double *values,int len,
					  int *outlen, int *startpos)
{
  register int i,i0=0,i1;
  double *outvalues;

  for(i=0;i<len;i++)
    if(values[i]!=MISSING_VALUE)
      break;
    else
      {
	i0++;
	*startpos=*startpos+1;
      }

  *outlen=0;
  // find the index of the last non-missing value
  for(i=len-1;i>=0;i--)
    if(values[i]!=MISSING_VALUE)
      break;
  i1=i;

  if(i1<0)
    return NULL;
  
  *outlen=i1+1-i0; // set the returned length
  outvalues=new double[*outlen];
  // set the outgoing values
  for(i=i0;i<=i1;i++)
    outvalues[i-i0]=values[i];

  return outvalues;
}


char *Get_method_name(METHOD met)
{
  for(int i=0;i<NUMBER_OF_METHODS;i++)
    if(met==methodlist[i])
      return methodstrlist[i];

  return NULL;
}


// Return whether the method chosen is a 'several year' method:
bool is_several_year_statistics(METHOD met)
{
  if((met>=SEVERAL_YEAR_MEAN && met<=SEVERAL_YEAR_SUM) ||
     met==SEVERAL_YEAR_STANDARD_DEVIATION ||
     met==SEVERAL_YEAR_MEAN_PLUS_SDEV ||
     met==SEVERAL_YEAR_MEAN_MINUS_SDEV ||
     (met>=SEVERAL_YEAR_PERCENTILE_2_5 && 
      met<=SEVERAL_YEAR_PERCENTILE_97_5))
    return true;
  else
    return false;
}


// Returns the one-step auto-correlation of a sample 'x'
double get_auto_correlation(double *x, int len)
{
  double cov=0;
  double var=find_statistics(x,len,VARIATION);
  double mu=find_statistics(x,len,MEAN);

  for(int i=1;i<len;i++)
    cov+=(x[i-1]-mu)*(x[i]-mu);
  cov/=double(len-1);
  
  return cov/var;
}

// returns -1 if the file wasn't found,
//         0 if the string wasn't found
//         1 if the string was found
int grep(char *filename, char *str, bool case_sensitive)
{
  std::ifstream in;
  char line[1000];

  in.open(filename, std::ios::in);
  if(in.fail())
    return -1;

  in.getline(line,999);
  while(!in.fail())
    {
      for(char *ptr=line;ptr<=line+strlen(line)-strlen(str);ptr++)
	if((case_sensitive && !strncmp(ptr, str, strlen(str))) ||
	   (!case_sensitive && !strncasecmp(ptr,str,strlen(str))))
	  {
	    in.close();
	    return 1;
	  }

      in.getline(line,999);
    }
    
  in.close();
  return 0;
}




// This routine should remove negative values in a value serie
// while keeping the sum (volume) constant. The array itself
// will be changed, so make sure it's a copy you send along
// if you want to keep the original values. Returns an error status,
// see the NEGATIVE_HANDLING_EXCEPTIONS enumerator.
int remove_negative(double *values, int len)
{
  double *forward=new double[len], *backward=new double[len];
  double *forward_diff=new double[len], *backward_diff=new double[len];
  int i;
  double lastpos1=0.0, lastpos2=0.0;
  int status=0;

  for(i=0;i<len;i++)
    if(i==0 || forward[i-1]==MISSING_VALUE || values[i]==MISSING_VALUE)
      forward[i]=values[i];
    else
      forward[i]=forward[i-1]+values[i];
  
  for(i=0;i<len;i++)
    {
      if(i==0 || (forward[i-1]==MISSING_VALUE && forward[i]!=MISSING_VALUE))
	{
	  if(forward[i]<0.0)
	    {
	      forward[i]=0.0;
	      if(i==0)
		status = status | NEGATIVE_UTMOST_LEFT_FAILED;
	      else
		status = status | NEGATIVE_INTERNAL_LEFT_FAILED;
	    }
	  lastpos1=forward[i];
	}
      else if(forward[i-1]!=MISSING_VALUE && forward[i]!=MISSING_VALUE)
	{
	  if(forward[i]<lastpos1)
	    {
	      forward[i]=lastpos1;
	      if(i==(len-1))
		status = status | NEGATIVE_UTMOST_RIGHT_FAILED;
	      else if(forward[i+1]==MISSING_VALUE)
		status = status |  NEGATIVE_INTERNAL_RIGHT_FAILED;
	    }
	  else
	    lastpos1=forward[i];
	}
    }

  for(i=0;i<len;i++)
    if(i==0 || (forward[i-1]==MISSING_VALUE && forward[i]!=MISSING_VALUE))
      forward_diff[i]=forward[i];
    else if(forward[i-1]!=MISSING_VALUE && forward[i]!=MISSING_VALUE)
      forward_diff[i]=forward[i]-forward[i-1];
    else
      forward_diff[i]=MISSING_VALUE;


  for(i=len-1;i>=0;i--)
    if(i==len-1 || backward[i+1]==MISSING_VALUE || values[i]==MISSING_VALUE)
      backward[i]=values[i];
    else
      backward[i]=backward[i+1]+values[i];
  
  for(i=len-1;i>=0;i--)
    {
      if(i==len-1 || (backward[i+1]==MISSING_VALUE && 
		      backward[i]!=MISSING_VALUE))
	{
	  if(backward[i]<0.0)
	    {
	      backward[i]=0.0;
	      if(i==len-1)
		status = status | NEGATIVE_UTMOST_RIGHT_FAILED;
	      else
		status = status | NEGATIVE_INTERNAL_RIGHT_FAILED;
	    }
	  lastpos2=backward[i];
	}
      else if(backward[i+1]!=MISSING_VALUE && backward[i]!=MISSING_VALUE)
	{
	  if(backward[i]<lastpos2)
	    {
	      backward[i]=lastpos2;
	      if(i==0)
		status = status | NEGATIVE_UTMOST_LEFT_FAILED;
	      else if(backward[i-1]==MISSING_VALUE)
		status = status |  NEGATIVE_INTERNAL_LEFT_FAILED;
	    }
	  else
	    lastpos2=backward[i];
	}
    }

  for(i=len-1;i>=0;i--)
    if(i==len-1 || (backward[i+1]==MISSING_VALUE && 
		    backward[i]!=MISSING_VALUE))
      backward_diff[i]=backward[i];
    else if(backward[i+1]!=MISSING_VALUE && backward[i]!=MISSING_VALUE)
      backward_diff[i]=backward[i]-backward[i+1];
    else
      backward_diff[i]=MISSING_VALUE;

  for(i=0;i<len;i++)
    if(backward_diff[i]!=MISSING_VALUE && forward_diff[i]!=MISSING_VALUE)
      values[i]=(forward_diff[i]+backward_diff[i])/2.0;
    else
      values[i]=MISSING_VALUE;

  delete [] forward;
  delete [] forward_diff;
  delete [] backward;
  delete [] backward_diff;

  return status;
}



hsv rgb_to_hsv(rgb orig)
{
  // RGB are each on [0, 1]. S and V are returned on [0, 1] and H is 
  // returned on [0, 6]. Exception: H is returned UNDEFINED if S==0. 
  double R = double(orig.red)/255.0, G = double(orig.green)/255.0, 
    B = double(orig.blue)/255.0, v, x, f, i; 
  hsv ret;

  x = MINIM(MINIM(R, G), B); 
  v = MAXIM(MAXIM(R, G), B); 

  if(v == x) 
    ret.Set(0, 0, v);
  else
    {
      f = (R == x) ? G - B : ((G == x) ? B - R : R - G); 
      i = (R == x) ? 3 : ((G == x) ? 5 : 1); 

      ret.Set((i - f /(v - x))/6.0, (v - x)/v, v);
    }

  return ret;
}

rgb hsv_to_rgb(hsv orig)
{
  // H is given on [0, 6] or UNDEFINED. S and V are given on [0, 1]. 
  // RGB are each returned on [0, 1]. 
  double h = orig.hue, s = orig.saturation, v = orig.value, m, n, f;
  int i;
  rgb ret; 

  if(s==0) 
    {
      ret.Set((unsigned char) (255.0*v),(unsigned char) (255.0*v),
	      (unsigned char) (255.0*v));
      return ret;
    }

  i = int(floor(h*6.0)); 
  f = 6.0*h - i;
  if(!(i & 1)) // if i is even
    f = 1 - f; 
 
  m = v * (1 - s); 
  n = v * (1 - s * f);
 
  switch (i) 
    { 
    case 6: 
    case 0: 
      ret.Set((unsigned char) (255.0*v), (unsigned char) (255.0*n), 
	      (unsigned char) (255.0*m));
      break;
    case 1: 
      ret.Set((unsigned char) (255.0*n), (unsigned char) (255.0*v),  
	      (unsigned char) (255.0*m)); 
      break;
    case 2: 
      ret.Set((unsigned char) (255.0*m), (unsigned char) (255.0*v),  
	      (unsigned char) (255.0*n)); 
      break;
    case 3: 
      ret.Set((unsigned char) (255.0*m), (unsigned char) (255.0*n),  
	      (unsigned char) (255.0*v)); 
      break;
    case 4: 
      ret.Set((unsigned char) (255.0*n), (unsigned char) (255.0*m),  
	      (unsigned char) (255.0*v)); 
      break;
    case 5: 
      ret.Set((unsigned char) (255.0*v), (unsigned char) (255.0*m),  
	      (unsigned char) (255.0*n)); 
      break;
    }

  return ret;
}


image::image()
{
  width=height=0;
  values=NULL;
}

image::image(int width_, int height_)
{
  rgb black(0,0,0);

  width=width_;
  height=height_;
  
  values=new rgb*[height];
  for(int y=0;y<height;y++)
    {
      values[y]=new rgb[width];
      for(int x=0;x<width;x++)
	values[y][x]=black;
    }
}

image::image(int width_, int height_, rgb color)
{
  width=width_;
  height=height_;
  
  values=new rgb*[height];
  for(int y=0;y<height;y++)
    {
      values[y]=new rgb[width];
      for(int x=0;x<width;x++)
	values[y][x]=color;
    }
}

image::~image()
{
  if(width && height && values)
    doubledelete(values, height);
  values=NULL;
  width=height=0;
}

dbl_image::dbl_image()
{
  width=height=0;
  values=NULL;
}

dbl_image::dbl_image(int width_, int height_)
{
  dbl_rgb black(0.0,0.0,0.0);

  width=width_;
  height=height_;
  
  values=new dbl_rgb*[height];
  for(int y=0;y<height;y++)
    {
      values[y]=new dbl_rgb[width];
      for(int x=0;x<width;x++)
	values[y][x]=black;
    }
}

dbl_image::dbl_image(int width_, int height_, dbl_rgb color)
{
  width=width_;
  height=height_;
  
  values=new dbl_rgb*[height];
  for(int y=0;y<height;y++)
    {
      values[y]=new dbl_rgb[width];
      for(int x=0;x<width;x++)
	values[y][x]=color;
    }
}


dbl_image::dbl_image(int width_, int height_, rgb color)
{
  width=width_;
  height=height_;
  
  values=new dbl_rgb*[height];
  for(int y=0;y<height;y++)
    {
      values[y]=new dbl_rgb[width];
      for(int x=0;x<width;x++)
	{
	  values[y][x].red=(double)color.red;
	  values[y][x].green=(double)color.green;
	  values[y][x].blue=(double)color.blue;
	}
    }
}

dbl_image::~dbl_image()
{
  if(width && height && values)
    doubledelete(values, height);
  values=NULL;
  width=height=0;
}


// Read from ppm:
image *read_image(char *filename)
{
char cmd[1000];

  FILE *t=fopen(filename, "r");
  if(!t)
    {
      printf("Couldn't open file %s!\n", filename);
      return NULL;
    }
  fclose(t);

  sprintf(cmd, "convert %s temp.ppm", filename);
  system(cmd);

  FILE *f=fopen("temp.ppm","r");
  image *ret=new image();
  
  int i,status, max;
  fscanf(f,"P%d", &status);
  fscanf(f, "%d %d", &(ret->width), &(ret->height));
  fscanf(f, "%d", &max);

  ret->values=new rgb*[ret->height];
  for(i=0;i<ret->height;i++)
    {
      ret->values[i]=new rgb[ret->width];
      
      fread(ret->values[i], size_t(ret->width), sizeof(rgb), f);
    }

  fclose(f);
#ifdef NVE
  hydraenvir::system::unlink("temp.ppm");
#else
  unlink("temp.ppm");
#endif

  printf("%s: %d %d\n", filename, ret->width, ret->height);

  return ret;
}

// Write to ppm:
void write_image(image *img, char *filename)
{
  FILE *f=fopen("temp.ppm", "w");
  fprintf(f, "P6\n");
  fprintf(f, "%d %d\n255\n", img->width, img->height);
  
  for(int y=0;y<img->height;y++)
    fwrite(img->values[y], size_t(img->width), sizeof(rgb), f);
  fclose(f);
  
  char cmd[1000];
  sprintf(cmd, "convert temp.ppm %s", filename);
  system(cmd);
  
#ifdef NVE
  hydraenvir::system::unlink("temp.ppm");
#else
  unlink("temp.ppm");
#endif // NVE
}

// Add a rgb value to a double representation of an rgb value
dbl_rgb add_rgb(dbl_rgb col1, rgb col2)
{
  dbl_rgb ret;

  ret.red=col1.red+double(col2.red);
  ret.blue=col1.blue+double(col2.blue);
  ret.green=col1.green+double(col2.green);
  
  return ret;
}
 
// Add on another ordinary image to a double respresented
// image:
void addimage(dbl_image *result, image *newimg)
{
  int x,y;

  for(y=0;y<result->height;y++)
    for(x=0;x<result->width;x++)
      result->values[y][x] = 
	add_rgb(result->values[y][x], newimg->values[y][x]);
}

// Pweform a power-law transformation of a double
// represented image:
void transform_dblimage(dbl_image *orgimage, double invpower)
{
  for(int y=0;y<orgimage->height;y++)
    for(int x=0;x<orgimage->width;x++)
      {
	orgimage->values[y][x].red=
	  pow(orgimage->values[y][x].red,1.0/invpower);
	orgimage->values[y][x].blue=
	  pow(orgimage->values[y][x].blue,1.0/invpower);
	orgimage->values[y][x].green=
	  pow(orgimage->values[y][x].green,1.0/invpower);
      }
}

// Transform a double-represented image back to an ordinary image:
// sep indicates separate normalization of each color.
image *dblimage2image(dbl_image *orgimage, int sep)
{
  double red95,green95,blue95,total95;
  int x,y,len=orgimage->width*orgimage->height;
  double *red=new double[len];
  double *green=new double[len];
  double *blue=new double[len];
  double *total=new double[3*len];
  image *ret=new image();

  // initialize the return image;
  ret->width=orgimage->width;
  ret->height=orgimage->height;
  ret->values=new rgb*[orgimage->height];
  for(y=0;y<orgimage->height;y++)
    ret->values[y]=new rgb[orgimage->width];

  for(y=0;y<orgimage->height;y++)
    for(x=0;x<orgimage->width;x++)
      {
	red[y*orgimage->height+x]=orgimage->values[y][x].red;
	blue[y*orgimage->height+x]=orgimage->values[y][x].blue;
	green[y*orgimage->height+x]=orgimage->values[y][x].green;
	total[3*(y*orgimage->height+x)]=orgimage->values[y][x].red;
	total[3*(y*orgimage->height+x)+1]=orgimage->values[y][x].blue;
	total[3*(y*orgimage->height+x)+2]=orgimage->values[y][x].green;
      }

  qsort(red, size_t(len), sizeof(double), compare_double);
  qsort(green, size_t(len), sizeof(double), compare_double);
  qsort(blue, size_t(len), sizeof(double), compare_double);
  qsort(total, size_t(3*len), sizeof(double), compare_double);
  
  red95=red[95*len/100];
  blue95=blue[95*len/100];
  green95=green[95*len/100];
  total95=total[95*3*len/100];
  
  for(y=0;y<orgimage->height;y++)
    for(x=0;x<orgimage->width;x++)
      if(sep)
	{
	  if(orgimage->values[y][x].red<=red95)
	    ret->values[y][x].red=(unsigned char) 
	      (orgimage->values[y][x].red/red95*255.0);
	  else
	    ret->values[y][x].red=(unsigned char) 255; 
	  if(orgimage->values[y][x].green<=green95)
	    ret->values[y][x].green=(unsigned char) 
	      (orgimage->values[y][x].green/green95*255.0);
	  else
	    ret->values[y][x].green=(unsigned char) 255;
	  if(orgimage->values[y][x].blue<=blue95)
	    ret->values[y][x].blue=(unsigned char) 
	      (orgimage->values[y][x].blue/blue95*255.0);
	  else
	    ret->values[y][x].blue=(unsigned char) 255;
	}
      else
	{
	  if(orgimage->values[y][x].red<=total95)
	    ret->values[y][x].red=(unsigned char) 
	      (orgimage->values[y][x].red/total95*255.0);
	  else
	    ret->values[y][x].red=(unsigned char) 255; 
	  if(orgimage->values[y][x].green<=total95)
	    ret->values[y][x].green=(unsigned char) 
	      (orgimage->values[y][x].green/total95*255.0);
	  else
	    ret->values[y][x].green=(unsigned char) 255;
	  if(orgimage->values[y][x].blue<=total95)
	    ret->values[y][x].blue=(unsigned char) 
	      (orgimage->values[y][x].blue/total95*255.0);
	  else
	    ret->values[y][x].blue=(unsigned char) 255;
	}

  delete [] red;
  delete [] blue;
  delete [] green;
  delete [] total;

  return ret;
}

// Transform a double-represented image back to an ordinary image:
dbl_image *image2dblimage(image *orgimage)
{
  dbl_image *result=new dbl_image();

  result->width=orgimage->width;
  result->height=orgimage->height;
  result->values=new dbl_rgb*[orgimage->height];
  for(int y=0;y<orgimage->height;y++)
    {
      result->values[y]=new dbl_rgb[orgimage->width];
      for(int x=0;x<orgimage->width;x++)
	{
	  result->values[y][x].red=(double) orgimage->values[y][x].red;
	  result->values[y][x].green=(double) orgimage->values[y][x].green;
	  result->values[y][x].blue=(double) orgimage->values[y][x].blue;
	}
    }
  
  return result;
}

rgb get_image_point(image *img, int x, int y)
{
  rgb black(0,0,0);

  if(img->values==NULL || x<0 || x>=img->width || y<0 || y>=img->height)
    return black;

  return img->values[y][x];
}

rgb get_image_point(dbl_image *img, int x, int y)
{
  rgb black(0,0,0);

  if(img->values==NULL || x<0 || x>=img->width || y<0 || y>=img->height)
    return black;

  rgb ret;

  ret.red=(unsigned char) img->values[y][x].red;
  ret.green=(unsigned char) img->values[y][x].green;
  ret.blue=(unsigned char) img->values[y][x].blue;

  return ret;
}

dbl_rgb get_dblimage_point(dbl_image *img, int x, int y)
{
  dbl_rgb black(0,0,0);

  if(img->values==NULL || x<0 || x>=img->width || y<0 || y>=img->height)
    return black;

  return img->values[y][x];
}

void set_image_point(image *img, int x, int y, rgb newcol)
{
  if(img->values==NULL || x<0 || x>=img->width || y<0 || y>=img->height)
    return;

  img->values[y][x]=newcol;
}

void set_image_point(dbl_image *img, int x, int y, dbl_rgb newcol)
{
  if(img->values==NULL || x<0 || x>=img->width || y<0 || y>=img->height)
    return;

  img->values[y][x]=newcol;
}


void set_image_point(dbl_image *img, int x, int y, rgb newcol)
{
  if(img->values==NULL || x<0 || x>=img->width || y<0 || y>=img->height)
    return;

  img->values[y][x].red=(double) newcol.red;
  img->values[y][x].green=(double) newcol.green;
  img->values[y][x].blue=(double) newcol.blue;
}

void solid_circle(image *img, int x0, int y0, int radius, rgb newcol)
{
  for(int x=x0-radius;x<=x0+radius;x++)
    for(int y=y0-radius;y<=y0+radius;y++)
      if((y-y0)*(y-y0)+(x-x0)*(x-x0)<=radius*radius)
	set_image_point(img, x,y, newcol);
}

void solid_circle(dbl_image *img, int x0, int y0, int radius, dbl_rgb newcol)
{
  for(int x=x0-radius;x<=x0+radius;x++)
    for(int y=y0-radius;y<=y0+radius;y++)
      if((y-y0)*(y-y0)+(x-x0)*(x-x0)<=radius*radius)
	set_image_point(img, x,y, newcol);
}

void solid_circle(dbl_image *img, int x0, int y0, int radius, rgb newcol)
{
  for(int x=x0-radius;x<=x0+radius;x++)
    for(int y=y0-radius;y<=y0+radius;y++)
      if((y-y0)*(y-y0)+(x-x0)*(x-x0)<=radius*radius)
	set_image_point(img, x,y, newcol);
}

/*
void image_line(image *img, int x1, int y1, int x2, int y2, int width, rgb newcol)
{
  if(width>1)
    {
      double theta=M_PI/2.0-atan(double(y2-y1)/double(x2-x1));
      int x3,y3,x4,y4, w=width;
      
      if(cos(theta)>0)
	{
	  x3=(int) (-0.5*double(w)*cos(theta)); 
	  y3=(int) (+0.5*double(w)*sin(theta)); 
	  x4=(int) (0.5*double(w)*cos(theta)); 
	  y4=(int) (-0.5*double(w)*sin(theta)); 
	}
      else
	{
	  x3=(int)(0.5*double(w)*cos(theta)); 
	  y3=(int)(-0.5*double(w)*sin(theta)); 
	  x4=(int)(-0.5*double(w)*cos(theta)); 
	  y4=(int)(+0.5*double(w)*sin(theta)); 
	}
      
	*	
      int xx[4], yy[4];
      xx[0]=x1+x3;
      xx[1]=x2+x3;
      xx[2]=x2-x3;
      xx[3]=x1-x3;
      yy[0]=y1+y3;
      yy[1]=y2+y3;
      yy[2]=y2-y3;
      yy[3]=y1-y3;

      image_filled_polygon(img, xx, yy, 4, newcol);
      *
      
      int x,y;
      if(x3!=x4)
	for(x=x3;x<=x4;x++)
	  {
	    y=(int) (double(y3) + double(y4-y3)/double(x4-x3)*double(x-x3));
	    image_line(img, x1+x, y1+y, x2+x, y2+y, 1, newcol);
	    image_line(img, x1+x+1, y1+y, x2+x, y2+y, 1, newcol);
	    image_line(img, x1+x+1, y1+y, x2+x+1, y2+y, 1, newcol);
	    image_line(img, x1+x, y1+y, x2+x+1, y2+y, 1, newcol);
	    image_line(img, x1+x, y1+y, x2+x, y2+y+1, 1, newcol);
	    image_line(img, x1+x, y1+y+1, x2+x, y2+y, 1, newcol);
	    image_line(img, x1+x, y1+y+1, x2+x, y2+y+1, 1, newcol);
	  }
      
      int step=y4>y3 ? 1 : -1;
      if(y3!=y4)
	for(y=y3;y<=y4;y+=step)
	  {
	    x=(int) (double(x3) + double(x4-x3)/double(y4-y3)*double(y-y3));
	    image_line(img, x1+x, y1+y+1, x2+x, y2+y, 1, newcol);
	    image_line(img, x1+x, y1+y, x2+x, y2+y+1, 1, newcol);
	    image_line(img, x1+x, y1+y+1, x2+x, y2+y, 1, newcol);
	    image_line(img, x1+x, y1+y+1, x2+x, y2+y+1, 1, newcol);
	    image_line(img, x1+x+1, y1+y, x2+x, y2+y, 1, newcol);
	    image_line(img, x1+x+1, y1+y, x2+x+1, y2+y, 1, newcol);
	  }
      
    }
  else
    {
      if(ABSVAL((x2-x1))>ABSVAL((y2-y1)))
	{
	  if(x1>x2) // switch places:
	    {
	      int x1b=x1,y1b=y1;
	      x1=x2;
	      y1=y2;
	      x2=x1b;
	      y2=y1b;
	    }
	  
	  for(int x=x1;x<=x2;x++)
	    {
	      int y=(int) (double(y1) + double(y2-y1)/double(x2-x1)*double(x-x1));
	      set_image_point(img, x, y, newcol);
	    }
	}
      else
	{
	  if(y1>y2) // switch places:
	    {
	      int x1b=x1,y1b=y1;
	      x1=x2;
	      y1=y2;
	      x2=x1b;
	      y2=y1b;
	    }
	  
	  for(int y=y1;y<=y2;y++)
	    {
	      int x=(int) (double(x1) + double(x2-x1)/double(y2-y1)*double(y-y1));
	      set_image_point(img, x, y, newcol);
	    }
	}
    }
}
*/

void image_line(image *img, int x1, int y1, int x2, int y2, int width, rgb newcol)
{
  if(ABSVAL((x2-x1))>ABSVAL((y2-y1)))
    {
      if(x1>x2) // switch places:
	{
	  int x1b=x1,y1b=y1;
	  x1=x2;
	  y1=y2;
	  x2=x1b;
	  y2=y1b;
	}
      
      for(int x=x1;x<=x2;x++)
	{
	  int y=(int) (double(y1) + double(y2-y1)/double(x2-x1)*double(x-x1));
	  if(width<=1)
	    set_image_point(img, x, y, newcol);
	  else
	    solid_circle(img,x,y,width/2,newcol);
	}
    }
  else
    {
      if(y1>y2) // switch places:
	{
	  int x1b=x1,y1b=y1;
	  x1=x2;
	  y1=y2;
	  x2=x1b;
	  y2=y1b;
	}
      
      for(int y=y1;y<=y2;y++)
	{
	  int x=(int) (double(x1) + double(x2-x1)/double(y2-y1)*double(y-y1));
	  if(width<=1)
	    set_image_point(img, x, y, newcol);
	  else
	    solid_circle(img,x,y,width/2,newcol);
	}
    }
}


void image_line(dbl_image *img, int x1, int y1, int x2, int y2, 
		int width, dbl_rgb newcol)
{
  if(ABSVAL((x2-x1))>ABSVAL((y2-y1)))
    {
      if(x1>x2) // switch places:
	{
	  int x1b=x1,y1b=y1;
	  x1=x2;
	  y1=y2;
	  x2=x1b;
	  y2=y1b;
	}
      
      for(int x=x1;x<=x2;x++)
	{
	  int y=(int) (double(y1) + double(y2-y1)/double(x2-x1)*double(x-x1));
	  if(width<=1)
	    set_image_point(img, x, y, newcol);
	  else
	    solid_circle(img,x,y,width/2,newcol);
	}
    }
  else
    {
      if(y1>y2) // switch places:
	{
	  int x1b=x1,y1b=y1;
	  x1=x2;
	  y1=y2;
	  x2=x1b;
	  y2=y1b;
	}
      
      for(int y=y1;y<=y2;y++)
	{
	  int x=(int) (double(x1) + double(x2-x1)/double(y2-y1)*double(y-y1));
	  if(width<=1)
	    set_image_point(img, x, y, newcol);
	  else
	    solid_circle(img,x,y,width/2,newcol);
	}
    }
}


void image_line(dbl_image *img, int x1, int y1, int x2, int y2, 
		int width, rgb newcol)
{
  if(ABSVAL((x2-x1))>ABSVAL((y2-y1)))
    {
      if(x1>x2) // switch places:
	{
	  int x1b=x1,y1b=y1;
	  x1=x2;
	  y1=y2;
	  x2=x1b;
	  y2=y1b;
	}
      
      for(int x=x1;x<=x2;x++)
	{
	  int y=(int) (double(y1) + double(y2-y1)/double(x2-x1)*double(x-x1));
	  if(width<=1)
	    set_image_point(img, x, y, newcol);
	  else
	    solid_circle(img,x,y,width/2,newcol);
	}
    }
  else
    {
      if(y1>y2) // switch places:
	{
	  int x1b=x1,y1b=y1;
	  x1=x2;
	  y1=y2;
	  x2=x1b;
	  y2=y1b;
	}
      
      for(int y=y1;y<=y2;y++)
	{
	  int x=(int) (double(x1) + double(x2-x1)/double(y2-y1)*double(y-y1));
	  if(width<=1)
	    set_image_point(img, x, y, newcol);
	  else
	    solid_circle(img,x,y,width/2,newcol);
	}
    }
}

void image_filled_rectangle(image *img, int x1, int y1, int x2, int y2, 
			    rgb newcol)
{
  for(int x=MINIM(x1,x2);x<MAXIM(x1,x2);x++)
    for(int y=MINIM(y1,y2);y<MAXIM(y1,y2);y++)
      set_image_point(img,x,y,newcol);
}

void image_filled_rectangle(dbl_image *img, int x1, int y1, int x2, int y2, 
			    dbl_rgb newcol)
{
  for(int x=MINIM(x1,x2);x<MAXIM(x1,x2);x++)
    for(int y=MINIM(y1,y2);y<MAXIM(y1,y2);y++)
      set_image_point(img,x,y,newcol);
}

void image_filled_rectangle(dbl_image *img, int x1, int y1, int x2, int y2, 
			    rgb newcol)
{
  for(int x=MINIM(x1,x2);x<MAXIM(x1,x2);x++)
    for(int y=MINIM(y1,y2);y<MAXIM(y1,y2);y++)
      set_image_point(img,x,y,newcol);
}

void image_filled_polygon(image *img, int *x, int *y, int num, rgb newcol)
// Filled polygon. Polygon must be convex and the points must be defined
// clockwise
{
  int xmin=x[0], ymin=y[0], xmax=x[0], ymax=y[0];
  int xx,yy,i,j;

  for(i=1;i<num;i++)
    {
      xmin=MINIM(xmin, x[i]);
      ymin=MINIM(ymin, y[i]);
      xmax=MAXIM(xmax, x[i]);
      ymax=MAXIM(ymax, y[i]);
    }

  for(xx=xmin;xx<=xmax;xx++)
    for(yy=ymin;yy<=ymax;yy++)
      {
	int dodraw=1;

	for(i=0;i<num && dodraw;i++)
	  {
	    j=(i+1)%num;
	    if((x[j]-x[i])*(xx-x[i])+(y[j]-y[i])*(yy-y[i])<0)
	      dodraw=0;
	  }

	if(dodraw)
	  set_image_point(img, xx, yy, newcol);
      }
}

void image_filled_polygon(dbl_image *img, int *x, int *y, int num, rgb newcol)
// Filled polygon. Polygon must be convex and the points must be defined
// clockwise
{
  int xmin=x[0], ymin=y[0], xmax=x[0], ymax=y[0];
  int xx,yy,i,j;

  for(i=1;i<num;i++)
    {
      xmin=MINIM(xmin, x[i]);
      ymin=MINIM(ymin, y[i]);
      xmax=MAXIM(xmax, x[i]);
      ymax=MAXIM(ymax, y[i]);
    }

  for(xx=xmin;xx<=xmax;xx++)
    for(yy=ymin;yy<=ymax;yy++)
      {
	int dodraw=1;

	for(i=0;i<num && dodraw;i++)
	  {
	    j=(i+1)%num;
	    if((x[j]-x[i])*(xx-x[i])+(y[j]-y[i])*(yy-y[i])<0)
	      dodraw=0;
	  }

	if(dodraw)
	  set_image_point(img, xx, yy, newcol);
      }
}


void image_filled_polygon(dbl_image *img, int *x, int *y, int num, dbl_rgb newcol)
// Filled polygon. Polygon must be convex and the points must be defined
// clockwise
{
  int xmin=x[0], ymin=y[0], xmax=x[0], ymax=y[0];
  int xx,yy,i,j;

  for(i=1;i<num;i++)
    {
      xmin=MINIM(xmin, x[i]);
      ymin=MINIM(ymin, y[i]);
      xmax=MAXIM(xmax, x[i]);
      ymax=MAXIM(ymax, y[i]);
    }

  for(xx=xmin;xx<=xmax;xx++)
    for(yy=ymin;yy<=ymax;yy++)
      {
	int dodraw=1;

	for(i=0;i<num && dodraw;i++)
	  {
	    j=(i+1)%num;
	    if((x[j]-x[i])*(xx-x[i])+(y[j]-y[i])*(yy-y[i])<0)
	      dodraw=0;
	  }

	if(dodraw)
	  set_image_point(img, xx, yy, newcol);
      }
}
