/*
 * $Id: distribution.C 2724 2016-05-31 10:52:15Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/distribution.C $
 */

#include <hydrasub/hydrabase/types.H>
#include <hydrasub/hydrabase/distribution.H>
#include <cmath>
#include <hydrasub/hydrabase/linalg.H>
#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/mcmc.H>

#include <gsl/gsl_cdf.h>

#ifdef NVE
#include <envirsub/path.H>
#endif // NVE

// ************************************************************* //
//                                                               //
//                        DISTRIBUTION                           //
//                                                               //
// This is a module for handling distributions based on time     //
// series. Is has a central superclass, called 'distribution'.   //
// Is has virtual methods for plugging a dataset into it and  //
// for retrieving a probability for a given value. It alos has   //
// methods for retrieving the resulting distribution. The class  //
// has several subclasses, each one representing a particlar     //
// distribution type, like the Gauss distribution, log-normal    //
// distribution or the beta distribution. When using a           //
// distribution, a dataset is given, and the parameters are   //
// set. The parameters can later be retrieved.                   //
//                                                               //
//                       Trond Reitan                            //
//                         28/2-2000                             //
//                                                               //   
// ************************************************************* //

static char *est_method_name[]={"moment","l-moment",
				"max lik","Bayesiansk","Ukjent metode"};

void historic_threshold::Set(int startyear, int endyear, double threshold)
{
  start_year=startyear;
  end_year=endyear;
  threshold_value=threshold;
}


void historic_extreme_data::Set(int year_, double lower, double upper, 
				double estimate,
				bool systematic_as_historic, 
				double post_lower,double post_upper)
{
  year=year_;
  lower_limit=lower;
  upper_limit=upper;
  estimated_value=estimate;
  systematic_camuflaged_as_historic=systematic_as_historic;
  posterior_lower=post_lower;
  posterior_upper=post_upper;
}

// Support for historical data (only extreme value analysis)
// of positively definite data (like flood frequency analysis).
int num_logprob_thresholds=0, num_logprob_hist=0;
historic_threshold *logprob_threshold=NULL;
historic_extreme_data *logprob_hist=NULL;
// PS: Use of global parameters requires that there is no threaded
// parallel runs on logprior/log-likelihood with different 
// historical info.


// Initialize extra parameters for historical estimates:
void init_extra(double *par, int numpar)
{
  int i,j=0;

  if(!logprob_hist || !logprob_threshold)
    return;

  for(i=0;i<num_logprob_hist;i++)
    if(logprob_hist[i].lower_limit!=MISSING_VALUE || 
       logprob_hist[i].upper_limit!=MISSING_VALUE)
      {
	if(j>=numpar)
	  {
	    std::cout << "Error! Number of extra hierarchical parameters "
	      "found for historical extremes, exceeds the number of "
	      "parameters available (" << numpar << ") in initiation!" << 
	      std::endl;
	    return;
	  }
	
	if(logprob_hist[i].lower_limit!=MISSING_VALUE && 
	   logprob_hist[i].upper_limit!=MISSING_VALUE)
	  {
	    int k=0;
	    // find threshold it belongs to:
	    for(k=0;k<num_logprob_thresholds;k++)
	      if(logprob_hist[i].year>=logprob_threshold[k].start_year &&
		 logprob_hist[i].year<=logprob_threshold[k].end_year)
		break;
	    if(k>=num_logprob_thresholds)
	      {
		if(!logprob_hist[i].systematic_camuflaged_as_historic)
		  printf("Error: historical data for year %d outside "
			 "threshold definitions! Treating it as "
			 "systematic data\n", logprob_hist[i].year);
		par[j]=logprob_hist[i].lower_limit+
		  (logprob_hist[i].upper_limit-logprob_hist[i].lower_limit)*
		  drand48();
	      }
	    else
	      {
		if(logprob_hist[i].lower_limit>
		   logprob_threshold[k].threshold_value)
		  par[j]=logprob_hist[i].lower_limit+
		    (logprob_hist[i].upper_limit-logprob_hist[i].lower_limit)*
		    drand48();
		else // just an upper limit, really
		  par[j]=logprob_threshold[k].threshold_value+
		    (logprob_hist[i].upper_limit-
		     logprob_threshold[k].threshold_value)*drand48();
	      }
	  }
	else if(logprob_hist[i].upper_limit!=MISSING_VALUE)
	  {
	    int k=0;
	    // find threshold it belongs to:
	    for(k=0;k<num_logprob_thresholds;k++)
	      if(logprob_hist[i].year>=logprob_threshold[k].start_year &&
		 logprob_hist[i].year<=logprob_threshold[k].end_year)
		break;
	    if(k>=num_logprob_thresholds)
	      {
		if(!logprob_hist[i].systematic_camuflaged_as_historic)
		  printf("Error: historical data for year %d outside "
			 "threshold definitions!\n", logprob_hist[i].year);
		par[j]=drand48()*logprob_hist[i].upper_limit;
	      }
	    else
	      par[j]=logprob_threshold[k].threshold_value+
		(logprob_hist[i].upper_limit-
		 logprob_threshold[k].threshold_value)*drand48();
	  }
	else // logprob_hist[i].lower_limit!=MISSING_VALUE
	  {
	    par[j]=logprob_hist[i].lower_limit*(1.0+exp(gauss()));
	  }
	j++;
      }
}




// Prior for extra historical parameters (handled equally 
// for all distributions):

double logprior_extra(double *par, int numpar)
{
  int i,j=0;
  double ret=0.0;
  
  if(!logprob_hist || !logprob_threshold)
    return -1e+200;

  for(i=0;i<num_logprob_hist;i++)
    {
      double estimated=logprob_hist[i].estimated_value;
      if(logprob_hist[i].lower_limit!=MISSING_VALUE || 
	 logprob_hist[i].upper_limit!=MISSING_VALUE)
	// intervals found?
	{
	  if(j>=numpar)
	    {
	      std::cout << "Error! Number of extra hierarchical parameters "
		"found for historical extremes, exceeds the number of "
		"parameters available (" << numpar << ") in prior!" << 
		std::endl;
	      return -1e+200;
	    }
	
	  estimated=par[j];
	  j++;
	  
	  // find threshold it belongs to:
	  int k;
	  double threshold=0.0;
	  for(k=0;k<num_logprob_thresholds;k++)
	    if(logprob_hist[i].year>=logprob_threshold[k].start_year &&
	       logprob_hist[i].year<=logprob_threshold[k].end_year)
	      threshold=logprob_threshold[k].threshold_value;
	  
	  double x=estimated - threshold;		  
	  double l=logprob_hist[i].lower_limit - threshold;
	  double u=logprob_hist[i].upper_limit - threshold;
	  
	  if(logprob_hist[i].lower_limit!=MISSING_VALUE && 
	     logprob_hist[i].upper_limit!=MISSING_VALUE)
	    {
	      // Both lower and upper limit. Adapt a log-normal
	      // distribution starting at the threshold and having
	      // 95% probability mass within the limits.
	      
	      if(l<=0.0)
		// if so, we basically only have an upper limit:
		{
		  //Make an exponential distribution starting
		  // at the threshold, with 95% probability
		  // mass below limit:
		  
		  // exceedance prob = exp(-u/lambda)=0.05
		  double lambda=-u/log(0.05);
		  
		  if(x>0.0)
		    ret += -x/lambda;
		  else
		    return -1e+200;
		}
	      else // both upper and lower boundry
		{
		  // Use log-normal distribution:
		  
		  double ln_m=(log(l)+log(u))/2.0;
		  double ln_s=(log(u)-log(l))/2.0/1.96;
		  
		  if(x>0.0)
		    ret += -0.5*sqrt(2.0*M_PI) - log(ln_s) -
		      0.5*(log(x)-ln_m)*(log(x)-ln_m)/ln_s/ln_s - 
		      log(x);
		  else
		    return -1e+200;
		}
	    }
	  else if(logprob_hist[i].upper_limit!=MISSING_VALUE)
	    // only upper limit
	    {
	      //Make an exponential distribution starting
	      // at the threshold, with 95% probability
	      // mass below limit:
	      
	      // exceedance prob = exp(-u/lambda)=0.05
	      double lambda=-u/log(0.05);
	      
	      if(x>0.0)
		ret += -x/lambda;
	      else
		return -1e+200;
	    }
	  else // logprob_lower_hist[i]!=MISSING_VALUE
	    // only lower limit
	    {
	      //Make an exponential distribution starting
	      // at the threshold, with 95% probability
	      // mass above limit:
	      
	      // exceedance prob = exp(-u/lambda)=0.95
	      double lambda=-l/log(0.95);
	      
	      if(x>0.0)
		    ret += -x/lambda;
	      else
		return -1e+200;
	    }
	} // intervals found?
    } // traversal of historical floods

  // PS : Tackle estimates (in data or as parameters) and 
  // limits in likelihood

  return ret;
} 


double loglik_general(double *x, int len, 
		      int numparams, double *par,
		      double (*log_f)(double xx, int numpar, double *params),
		      double (*log_F)(double xx, int numpar, double *params),
		      int distrib_num_par)
{
  int i;
  double ret=0.0;
  for(i=0;i<len;i++)
    if(x[i]!=MISSING_VALUE)
      {
	double curr_loglik=log_f(x[i],numparams,par);
	if(!(curr_loglik > -1e+199))
	  return -1e+200;
	ret+=curr_loglik;
      }

  if(num_logprob_thresholds>0) // historical thresholds given?
    {
      int *num_below_threshold=new int[num_logprob_thresholds];
      int k, j=0;
      
      for(k=0;k<num_logprob_thresholds;k++)
	num_below_threshold[k]=logprob_threshold[k].end_year-
	  logprob_threshold[k].start_year+1;
      
      // traverse historical data: 
      for(i=0;i<num_logprob_hist;i++)
	{
	  // remember contrib due to thresholds themselves
	  // count number of years within each interval which doesn't
	  // have historical data attached to them.
	  
	  double estimated=logprob_hist[i].estimated_value;
	  if(logprob_hist[i].lower_limit!=MISSING_VALUE || 
	     logprob_hist[i].upper_limit!=MISSING_VALUE)
	    {
	      if(distrib_num_par+j >= numparams)
		{
		  std::cout << "Too many parameters read in loglik_logprob! "
		    "Reading parameter " << 3+j << ", numparams=" << 
		    numparams << " !" << std::endl;
		}
	      
	      estimated=par[distrib_num_par+j];
	      j++;
	    }
	  
	  double xx=estimated;
	      
	  double curr_loglik= log_f(xx,numparams,par);
	  if(!(curr_loglik > -1e+199))
	    return -1e+200;
	  
	  ret += curr_loglik;
	  
	  // find threshold it belongs to and decrease number of 
	  // years below threshold:
	  for(k=0;k<num_logprob_thresholds;k++)
	    if(logprob_hist[i].year>=logprob_threshold[k].start_year &&
	       logprob_hist[i].year<=logprob_threshold[k].end_year)
	      num_below_threshold[k]--;
	  
	} // traversal of historical floods
      
      // treshold likelihood:
      for(k=0;k<num_logprob_thresholds;k++)
	{
	  double xx=logprob_threshold[k].threshold_value;
	  double threshold_G=log_F(xx,numparams,par);
	  if(!(threshold_G > -1e+199))
	    return -1e+200;
	  
	  if(num_below_threshold[k]>0)
	    ret += threshold_G*double(num_below_threshold[k]);
	}
    } // historical thresholds given
  
  return ret;
}




char **dist_copy_strings(char **names, int num_param)
{
  char **ret=new char*[num_param];
  
  for(int i=0;i<num_param;i++)
    {
      ret[i]=new char[100];
      strcpy(ret[i], names[i]);
    }
  
  return ret;
}

void cleanup_hist_and_names(char **names,int numpar,
			    double **pars,int num_mcmc)
{
  doubledelete(names,numpar);
  if(logprob_threshold)
    delete [] logprob_threshold;
  logprob_threshold=NULL;
  if(logprob_hist)
    delete [] logprob_hist;
  logprob_hist=NULL;
  
  num_logprob_thresholds=0;
  num_logprob_hist=0;
  
  doubledelete(pars,num_mcmc);
}

// Global (for all distributions) prior info, based on quantiles,
// q1=first (lowest) quantile, q2=quantile2-quantile1,q3=quantile3-quantile2
// p1,p2,p3 are the corresponding quantile probabilities
bool distribution_strictly_positive_data=false;
bool has_ratio_based_higher_order_quantile_prior=false;
double q1_mu=0.0, q1_sd=1000.0, 
  logq1_mu=0.0, logq1_sd=10.0, 
  logq2_mu=0.0, logq2_sd=10.0, 
  logq3_mu=0.0, logq3_sd=10.0;
double dist_p1=0.025, dist_p2=0.5, dist_p3=0.975;



#define ZETA_REPEAT 10
double riemann_zeta(double n, double precision)
{
  if(n<=1.0)
    return MISSING_VALUE;

  register int i=0, m=0;
  register double result=0.0, partresult=0.0;
  
  while((result==0.0 || partresult/result>precision) && i<10000000)
    {
      partresult = 0.0;
      
      for(m=i;m<i+ZETA_REPEAT;m++)
	partresult += pow((double) (m+1), (double) -n);

      result += partresult;
      partresult /= ZETA_REPEAT;
      partresult *= 10.0;
      i += ZETA_REPEAT;
    }

  return result;
}

double derivated_riemann_zeta(double n, double precision)
{
  return (riemann_zeta(n+precision, precision) - 
	  riemann_zeta(n-precision, precision)) / (2.0*precision);
}

double sigma_zeta(double n, double precision)
{
  if(n<=2.0)
    return MISSING_VALUE;

  double result;

  result = riemann_zeta(n-1.0, precision)/(n-1.0) - 
    riemann_zeta(n, precision)*riemann_zeta(n, precision) / n / 
    riemann_zeta(n+1, precision);
  result /= n*riemann_zeta(n+1.0, precision);

  return result;
}

double tau_zeta(double n, double precision)
{
  if(n<=3.0)
    return MISSING_VALUE;

  double result;

  result = riemann_zeta(n-2.0, precision)/((n-1.0)*(n-2.0)) - 
    3.0*riemann_zeta(n-1.0, precision)*riemann_zeta(n, precision) /
    (n*(n-1.0)*riemann_zeta(n+1.0, precision)) +
    2.0*riemann_zeta(n, precision)*riemann_zeta(n, precision)*
    riemann_zeta(n, precision)/(n*n*riemann_zeta(n+1.0, precision)*
				riemann_zeta(n+1.0, precision));

  result /= n*riemann_zeta(n+1.0, precision);

  return result;
}

double planckskew(double n, double precision)
{
  if(n<=3.0)
    return MISSING_VALUE;

  double tau = tau_zeta(n, precision);
  double sigma = sigma_zeta(n, precision);

  return tau/ pow(sigma, 1.5); 
}

double derivated_planckskew(double n, double precision)
{
  if(n<=3.0)
    return MISSING_VALUE;

  return (planckskew(n+precision, precision) - 
	  planckskew(n-precision, precision)) / (2.0*precision);
}

double derivated_gamma(double arg)
{
  double delta=1e-8;
  double g1=exp(lgamma(arg-0.5*delta));
  double g2=exp(lgamma(arg+0.5*delta));
  
  return (g2-g1)/delta;
}

double doublederivated_gamma(double arg)
{
  double delta=1e-8;
  double g1=derivated_gamma(arg-0.5*delta);
  double g2=derivated_gamma(arg+0.5*delta);
  
  return (g2-g1)/delta;
}

void tdist_handler (const char * /* reason */, 
		    const char * /* file */, 
		    int /* line */, 
		    int /* gsl_errno */)
{
  // NOP
}

int derivated_gamma_likelihood_n=1;
double derivated_gamma_mean=1;
double derivated_gamma_logmean=1;
double derivated_gamma_likelihood(double arg)
{
  double ret=0.0;
  
  ret+=log(derivated_gamma_mean);
  ret-=log(arg);
  ret-=derivated_gamma(arg)/exp(lgamma(arg));
  ret+=derivated_gamma_logmean;
  
  ret*=double(derivated_gamma_likelihood_n);
  
  return ret;
}




// Comparison routine for sorting historic thresholds
// by threeshold_value using 'qsort':
int compare_historic_threshold_values(const void *i, const void *j)
{
  double v =  ((historic_threshold *)i)->threshold_value - 
    ((historic_threshold *)j)->threshold_value;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
}

// Comparison routine for sorting historic thresholds
// by start_year using 'qsort':
int compare_historic_threshold_start_years(const void *i, const void *j)
{
  int v =  ((historic_threshold *)i)->start_year - 
    ((historic_threshold *)j)->start_year;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
}



// Comparison routine for sorting historic extreme data
// by year using 'qsort':
int compare_historic_extreme_data_years(const void *i, const void *j)
{
  int v =  ((historic_extreme_data *)i)->year - 
    ((historic_extreme_data *)j)->year;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
}


// Comparison routine for sorting historic extreme data
// by year using 'qsort':
int compare_historic_extreme_data_estimate(const void *i, const void *j)
{
  double v =  ((historic_extreme_data *)i)->estimated_value - 
    ((historic_extreme_data *)j)->estimated_value;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
}





// BETA distribution support
int beta_likelihood_n;
double *beta_likelihood_X;
double beta_min, beta_max;

double beta_likelihood(double *arg)
{
  double ret=0.0;
  int n=beta_likelihood_n, nminus=0;
  double *x=beta_likelihood_X;
  double alfa=arg[0];
  double beta=arg[1];

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	ret += (alfa-1)*log((x[i]-beta_min)/log(beta_max-beta_min));
	ret += (beta-1)*log(1.0-(x[i]-beta_min)/(beta_max-beta_min));
      }
    else 
      nminus++;

  ret += double(n-nminus)*
    (lgamma(alfa+beta)-lgamma(alfa)-lgamma(beta)-log(beta_max-beta_min));
  
  return ret;
}

/* MCMC stuff */
void init_beta(int numpar, double *par, int, double * /*hyperpar*/ )
{
  par[0]=gauss();
  par[1]=gauss();

  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_beta(double p, double p_ref, double logalpha, double logbeta)
{
  double ret;
  double alfa=exp(logalpha), beta=exp(logbeta);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=gsl_cdf_beta_Pinv(p,alfa,beta)-gsl_cdf_beta_Pinv(p_ref,alfa,beta);
  else
    ret=gsl_cdf_beta_Pinv(p,alfa,beta);
  return ret;
}

double qratio_beta(double p, double p_ref, double logalpha, double logbeta)
{
  double ret;
  double alfa=exp(logalpha), beta=exp(logbeta);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=gsl_cdf_beta_Pinv(p,alfa,beta)/gsl_cdf_beta_Pinv(p_ref,alfa,beta);
  else
    ret=gsl_cdf_beta_Pinv(p,alfa,beta);
  return ret;
}

double logprior_beta(int numparams, 
		     double *par,
		     int /* num_hyperparameters */,
		     double * /*hyperpar*/ )
{
  // hyper parameters fetched from global parameter list 
  // in the start of the file
  double p1=dist_p1, p2=dist_p2;
  
  double logalfa=par[0];
  double logbeta=par[1];
  
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_beta(p1,MISSING_VALUE,logalfa,logbeta) : 
    qratio_beta(p1,MISSING_VALUE,logalfa,logbeta);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_beta(p2,p1,logalfa,logbeta) : 
    qratio_beta(p2,p1,logalfa,logbeta);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_beta(p1,MISSING_VALUE,
					  logalfa-dx,logbeta))/dx;
      theta_der[0][1]=(q1_curr-qdiff_beta(p1,MISSING_VALUE,
					  logalfa,logbeta-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_beta(p2,p1,logalfa-dx,logbeta))/dx;
      theta_der[1][1]=(q2_curr-qdiff_beta(p2,p1,logalfa,logbeta-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_beta(p1,MISSING_VALUE,
					  logalfa-dx,logbeta))/dx;
      theta_der[0][1]=(q1_curr-qratio_beta(p1,MISSING_VALUE,
					  logalfa,logbeta-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_beta(p2,p1,logalfa-dx,logbeta))/dx;
      theta_der[1][1]=(q2_curr-qratio_beta(p2,p1,logalfa,logbeta-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_beta(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  double xx=(x-beta_min)/(beta_max-beta_min);

  if(xx<=0.0 || xx>=1.0)
    return -1e+200;

  double ret=(alfa-1.0)*log(xx) + (beta-1.0)*log(1.0-xx) +
    lgamma(alfa+beta) - lgamma(alfa) - 
    lgamma(beta) - log(beta_max-beta_min);

  return ret;
}

double log_F_beta(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  double xx=(x-beta_min)/(beta_max-beta_min);
  
  if(xx<=0.0)
    return -1e+200;
  if(xx>=1.0)
    return 0.0;

  double ret=log(gsl_cdf_beta_P(xx,alfa,beta));

  return ret;
}

double loglik_beta(double **data, 
		   int numrows, 
		   int /* numcolumns */,
		   int numparams, 
		   double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_beta, log_F_beta, 2);

  return ret;
}



// GAUSS support functions:
/* MCMC stuff */
void init_gauss(int numpar, double *par, int, double * /*hyperpar*/ )
{
  if(!distribution_strictly_positive_data)
    par[0]=gauss();
  else
    par[0]=exp(gauss());
  par[1]=gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);

}

double qdiff_gauss(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=sigma*gsl_cdf_ugaussian_Pinv(p)-sigma*gsl_cdf_ugaussian_Pinv(p_ref);
  else
    ret=mu+sigma*gsl_cdf_ugaussian_Pinv(p);
  return ret;
}

double qratio_gauss(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=(sigma*gsl_cdf_ugaussian_Pinv(p))/(sigma*gsl_cdf_ugaussian_Pinv(p_ref));
  else
    ret=mu+sigma*gsl_cdf_ugaussian_Pinv(p);
  return ret;
}



double logprior_gauss(int numparams, 
		      double *par,
		      int /* num_hyperparameters */,
		      double * /*hyperpar*/ )
{
  double mu=par[0];
  double logsigma=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gauss(p1,MISSING_VALUE,mu,logsigma) : 
    qratio_gauss(p1,MISSING_VALUE,mu,logsigma);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gauss(p2,p1,mu,logsigma) : 
    qratio_gauss(p2,p1,mu,logsigma);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_gauss(p1,MISSING_VALUE,mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qdiff_gauss(p1,MISSING_VALUE,mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_gauss(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qdiff_gauss(p2,p1,mu,logsigma-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_gauss(p1,MISSING_VALUE,
					    mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qratio_gauss(p1,MISSING_VALUE,
					    mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_gauss(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qratio_gauss(p2,p1,mu,logsigma-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_gauss(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);

  double ret= -0.5*log(2.0*M_PI)-logsigma-
    0.5*(x-mu)*(x-mu)/sigma/sigma;

  return ret;
}


double log_F_gauss(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);

  double ret=log(gsl_cdf_ugaussian_P((x-mu)/sigma));
  
  return ret;
}

double loglik_gauss(double **data, 
		     int numrows, 
		     int /* numcolumns */,
		     int numparams, 
		     double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_gauss, log_F_gauss, 2);

  return ret;
}




// LOGNORMAL support functions:
/* MCMC stuff */
void init_lognormal(int numpar, double *par, int, double * /*hyperpar*/)
{
  par[0]=gauss();
  par[1]=gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_lognorm(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma*gsl_cdf_ugaussian_Pinv(p))-
      exp(mu+sigma*gsl_cdf_ugaussian_Pinv(p_ref));
  else
    ret=exp(mu+sigma*gsl_cdf_ugaussian_Pinv(p));
  return ret;
}

double qratio_lognorm(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma*gsl_cdf_ugaussian_Pinv(p)) /
      exp(mu+sigma*gsl_cdf_ugaussian_Pinv(p_ref));
  else
    ret=exp(mu+sigma*gsl_cdf_ugaussian_Pinv(p));
  return ret;
}

double logprior_lognormal(int numparams, 
			  double *par,
			  int /* num_hyperparameters */,
			  double * /*hyperpar*/)
{
  double mu=par[0];
  double logsigma=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_lognorm(p1,MISSING_VALUE,mu,logsigma) : 
    qratio_lognorm(p1,MISSING_VALUE,mu,logsigma);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_lognorm(p2,p1,mu,logsigma) : 
    qratio_lognorm(p2,p1,mu,logsigma);

  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_lognorm(p1,MISSING_VALUE,
					     mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qdiff_lognorm(p1,MISSING_VALUE,
					     mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_lognorm(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qdiff_lognorm(p2,p1,mu,logsigma-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_lognorm(p1,MISSING_VALUE,
					     mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qratio_lognorm(p1,MISSING_VALUE,
					     mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_lognorm(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qratio_lognorm(p2,p1,mu,logsigma-dx))/dx;
    }

  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_lognormal(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);

  if(x<=0.0)
    return -1e+200;

  double ret= -0.5*log(2.0*M_PI)-logsigma-log(x)-
    0.5*(log(x)-mu)*(log(x)-mu)/sigma/sigma;

  return ret;
}


double log_F_lognormal(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);
  
  if(x<0.0)
    return -1e+200;
  
  double ret=log(gsl_cdf_ugaussian_P((log(x)-mu)/sigma));
  
  return ret;
}

double loglik_lognormal(double **data, 
			int numrows, 
			int /* numcolumns */,
			int numparams, 
			double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_lognormal, log_F_lognormal, 2);

  return ret;
}





// Student t support functions:
/* MCMC stuff */
int tdist_likelihood_n;
double *tdist_likelihood_X;
double tdist_likelihood(double *arg)
{
  int n=tdist_likelihood_n;
  double mu=arg[0];
  double logsigma=arg[1], sigma=exp(logsigma), logitnu=arg[2],  nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  double ret=0.0;
  double *x=tdist_likelihood_X;
  
  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      ret+= lgamma((nu+1.0)/2.0) - 0.5*log(nu*M_PI) - lgamma(nu/2.0) - logsigma - 
	(nu+1.0)/2.0*log(1.0+(x[i]-mu)*(x[i]-mu)/sigma/sigma/nu);
  
  return ret;
} 


void init_tdist(int numpar, double *par, int, double * /*hyperpar*/ )
{
  if(!distribution_strictly_positive_data)
    par[0]=gauss();
  else
    par[0]=exp(gauss());
  par[1]=gauss();
  par[2]=-15.0+gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);
}

double qdiff_tdist(double p, double p_ref, double mu, 
		   double logsigma, double logitnu)
{
  double ret;
  double sigma=exp(logsigma);
  double nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=sigma*(gsl_cdf_tdist_Pinv(p,nu)-gsl_cdf_tdist_Pinv(p_ref,nu));
  else
    ret=mu+sigma*gsl_cdf_tdist_Pinv(p,nu);
  return ret;
}

double qratio_tdist(double p, double p_ref, double mu, 
		    double logsigma, double logitnu)
{
  double ret;
  double sigma=exp(logsigma);
  double nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=(mu+sigma*gsl_cdf_tdist_Pinv(p,nu))/
      (mu+sigma*gsl_cdf_tdist_Pinv(p_ref,nu));
  else
    ret=mu+sigma*gsl_cdf_tdist_Pinv(p,nu);
  return ret;
}

double logprior_tdist(int numparams, 
		      double *par,
		      int /* num_hyperparameters */,
		      double * /*hyperpar*/ )
{
  double mu=par[0];
  double logsigma=par[1];
  double logitnu=par[2];
  
  double p1=dist_p1, p2=dist_p2, p3=dist_p3;
  double **theta_der=make_matrix(3,3);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_tdist(p1,MISSING_VALUE,mu,logsigma,logitnu) : 
    qratio_tdist(p1,MISSING_VALUE,mu,logsigma,logitnu);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_tdist(p2,p1,mu,logsigma,logitnu) : 
    qratio_tdist(p2,p1,mu,logsigma,logitnu);
  double q3_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_tdist(p3,p2,mu,logsigma,logitnu) : 
    qratio_tdist(p3,p2,mu,logsigma,logitnu);

  if(q2_curr<=0.0)
    return -1e+200;
  if(q3_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_tdist(p1,MISSING_VALUE,
					   mu-dx,logsigma,logitnu))/dx;
      theta_der[0][1]=(q1_curr-qdiff_tdist(p1,MISSING_VALUE,
					   mu,logsigma-dx,logitnu))/dx;
      theta_der[0][2]=(q1_curr-qdiff_tdist(p1,MISSING_VALUE,
					   mu,logsigma,logitnu-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_tdist(p2,p1,mu-dx,logsigma,logitnu))/dx;
      theta_der[1][1]=(q2_curr-qdiff_tdist(p2,p1,mu,logsigma-dx,logitnu))/dx;
      theta_der[1][2]=(q2_curr-qdiff_tdist(p2,p1,mu,logsigma,logitnu-dx))/dx;
      theta_der[2][0]=(q3_curr-qdiff_tdist(p3,p2,mu-dx,logsigma,logitnu))/dx;
      theta_der[2][1]=(q3_curr-qdiff_tdist(p3,p2,mu,logsigma-dx,logitnu))/dx;
      theta_der[2][2]=(q3_curr-qdiff_tdist(p3,p2,mu,logsigma,logitnu-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_tdist(p1,MISSING_VALUE,
					   mu-dx,logsigma,logitnu))/dx;
      theta_der[0][1]=(q1_curr-qratio_tdist(p1,MISSING_VALUE,
					   mu,logsigma-dx,logitnu))/dx;
      theta_der[0][2]=(q1_curr-qratio_tdist(p1,MISSING_VALUE,
					   mu,logsigma,logitnu-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_tdist(p2,p1,mu-dx,logsigma,logitnu))/dx;
      theta_der[1][1]=(q2_curr-qratio_tdist(p2,p1,mu,logsigma-dx,logitnu))/dx;
      theta_der[1][2]=(q2_curr-qratio_tdist(p2,p1,mu,logsigma,logitnu-dx))/dx;
      theta_der[2][0]=(q3_curr-qratio_tdist(p3,p2,mu-dx,logsigma,logitnu))/dx;
      theta_der[2][1]=(q3_curr-qratio_tdist(p3,p2,mu,logsigma-dx,logitnu))/dx;
      theta_der[2][2]=(q3_curr-qratio_tdist(p3,p2,mu,logsigma,logitnu-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 3, 1);
  doubledelete(theta_der,3);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq3_sd)-log(q3_curr)-
    0.5*(log(q3_curr)-logq3_mu)*(log(q3_curr)-logq3_mu)/logq3_sd/logq3_sd;
  
  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}


double log_f_tdist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma), logitnu=par[2], 
    nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  double ret=lgamma((nu+1.0)/2.0) - 0.5*log(nu*M_PI) - 
    lgamma(nu/2.0) - log(sigma) - 
    (nu+1.0)/2.0*log(1.0+(x-mu)*(x-mu)/sigma/sigma/nu);

    return ret;
}

double log_F_tdist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma), logitnu=par[2], 
    nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  double ret=log(gsl_cdf_tdist_P((x-mu)/sigma,nu));

  return ret;
}

double loglik_tdist(double **data, 
		    int numrows, 
		    int /* numcolumns */,
		    int numparams, 
		    double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_tdist, log_F_tdist, 3);
  
  return ret;
}


// Log-Student t support functions:
int logtdist_likelihood_n;
double *logtdist_likelihood_X;
double logtdist_likelihood(double *arg)
{
  int n=logtdist_likelihood_n;
  double mu=arg[0];
  double logsigma=arg[1], sigma=exp(logsigma), logitnu=arg[2],  nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  double ret=0.0;
  double *x=logtdist_likelihood_X;
  
  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	if(x[i]<=0.0)
	  return -1e+200;
	ret+= -log(x[i]) + lgamma((nu+1.0)/2.0) - 0.5*log(nu*M_PI) - lgamma(nu/2.0) - logsigma - 
	  (nu+1.0)/2.0*log(1.0+(log(x[i])-mu)*(log(x[i])-mu)/sigma/sigma/nu);
      }
  
  return ret;
} 

/* MCMC stuff */

void init_logtdist(int numpar, double *par, int, double * /*hyperpar*/ )
{
  if(!distribution_strictly_positive_data)
    par[0]=gauss();
  else
    par[0]=exp(gauss());
  par[1]=gauss();
  par[2]=-15.0+gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);
}

double qdiff_logtdist(double p, double p_ref, double mu, 
		      double logsigma, double logitnu)
{
  double ret;
  double sigma=exp(logsigma);
  double nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma*gsl_cdf_tdist_Pinv(p,nu))-
      exp(mu+sigma*gsl_cdf_tdist_Pinv(p_ref,nu));
  else
    ret=exp(mu+sigma*gsl_cdf_tdist_Pinv(p,nu));
  return ret;
}

double qratio_logtdist(double p, double p_ref, double mu, 
		      double logsigma, double logitnu)
{
  double ret;
  double sigma=exp(logsigma);
  double nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma*gsl_cdf_tdist_Pinv(p,nu)) /
      exp(mu+sigma*gsl_cdf_tdist_Pinv(p_ref,nu));
  else
    ret=exp(mu+sigma*gsl_cdf_tdist_Pinv(p,nu));
  return ret;
}

double logprior_logtdist(int numparams, 
			 double *par,
			 int /* num_hyperparameters */,
			 double * /*hyperpar*/ )
{
  double mu=par[0];
  double logsigma=par[1];
  double logitnu=par[2];
  
  double p1=dist_p1, p2=dist_p2, p3=dist_p3;
  double **theta_der=make_matrix(3,3);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logtdist(p1,MISSING_VALUE,mu,logsigma,logitnu) : 
    qratio_logtdist(p1,MISSING_VALUE,mu,logsigma,logitnu);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logtdist(p2,p1,mu,logsigma,logitnu) : 
    qratio_logtdist(p2,p1,mu,logsigma,logitnu);
  double q3_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logtdist(p3,p2,mu,logsigma,logitnu) : 
    qratio_logtdist(p3,p2,mu,logsigma,logitnu);

  if(q2_curr<=0.0)
    return -1e+200;
  if(q3_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_logtdist(p1,MISSING_VALUE,
					      mu-dx,logsigma,logitnu))/dx;
      theta_der[0][1]=(q1_curr-qdiff_logtdist(p1,MISSING_VALUE,
					      mu,logsigma-dx,logitnu))/dx;
      theta_der[0][2]=(q1_curr-qdiff_logtdist(p1,MISSING_VALUE,
					      mu,logsigma,logitnu-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_logtdist(p2,p1,
					      mu-dx,logsigma,logitnu))/dx;
      theta_der[1][1]=(q2_curr-qdiff_logtdist(p2,p1,
					      mu,logsigma-dx,logitnu))/dx;
      theta_der[1][2]=(q2_curr-qdiff_logtdist(p2,p1,
					      mu,logsigma,logitnu-dx))/dx;
      theta_der[2][0]=(q3_curr-qdiff_logtdist(p3,p2,
					      mu-dx,logsigma,logitnu))/dx;
      theta_der[2][1]=(q3_curr-qdiff_logtdist(p3,p2,
					      mu,logsigma-dx,logitnu))/dx;
      theta_der[2][2]=(q3_curr-qdiff_logtdist(p3,p2,
					      mu,logsigma,logitnu-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_logtdist(p1,MISSING_VALUE,
					      mu-dx,logsigma,logitnu))/dx;
      theta_der[0][1]=(q1_curr-qratio_logtdist(p1,MISSING_VALUE,
					      mu,logsigma-dx,logitnu))/dx;
      theta_der[0][2]=(q1_curr-qratio_logtdist(p1,MISSING_VALUE,
					      mu,logsigma,logitnu-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_logtdist(p2,p1,
					      mu-dx,logsigma,logitnu))/dx;
      theta_der[1][1]=(q2_curr-qratio_logtdist(p2,p1,
					      mu,logsigma-dx,logitnu))/dx;
      theta_der[1][2]=(q2_curr-qratio_logtdist(p2,p1,
					      mu,logsigma,logitnu-dx))/dx;
      theta_der[2][0]=(q3_curr-qratio_logtdist(p3,p2,
					      mu-dx,logsigma,logitnu))/dx;
      theta_der[2][1]=(q3_curr-qratio_logtdist(p3,p2,
					      mu,logsigma-dx,logitnu))/dx;
      theta_der[2][2]=(q3_curr-qratio_logtdist(p3,p2,
					      mu,logsigma,logitnu-dx))/dx;
    }

  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 3, 1);
  doubledelete(theta_der,3);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq3_sd)-log(q3_curr)-
    0.5*(log(q3_curr)-logq3_mu)*(log(q3_curr)-logq3_mu)/logq3_sd/logq3_sd;
  
  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}


double log_f_logt(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma), logitnu=par[2], 
    nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  if(x<=0.0)
    return -1e+200;

  double ret=lgamma((nu+1.0)/2.0) - 0.5*log(nu*M_PI) - 
    lgamma(nu/2.0) - log(sigma) - 
    (nu+1.0)/2.0*log(1.0+(log(x)-mu)*(log(x)-mu)/sigma/sigma/nu)-
    log(x);
  
  return ret;
}

double log_F_logt(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma), logitnu=par[2], 
    nu=0.03+1e+9*exp(logitnu)/(1.0+exp(logitnu));
  
  if(x<=0.0)
    return -1e+200;
  
  double ret=log(gsl_cdf_tdist_P((log(x)-mu)/sigma,nu));
  
  return ret;
}

double loglik_logtdist(double **data, 
		       int numrows, 
		       int /* numcolumns */,
		       int numparams, 
		       double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_logt, log_F_logt, 3);

  return ret;
}



// LOGISTIC support functions:
/* MCMC stuff */
int logistic_likelihood_n;
double *logistic_likelihood_X;
double logistic_likelihood(double *arg)
{
  int n=logistic_likelihood_n;
  double mu=arg[0];
  double logsigma=arg[1], sigma=exp(logsigma);
  double ret=0.0;
  double *x=logistic_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      ret+= -logsigma - (x[i]-mu)/sigma - 2.0*log(1.0+exp(-(x[i]-mu)/sigma));

  return ret;
} 

void init_logistic(int numpar, double *par, int, double * /*hyperpar*/ )
{
  if(!distribution_strictly_positive_data)
    par[0]=gauss();
  else
    par[0]=exp(gauss());
  par[1]=gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_logistic(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=sigma*(log(p/(1.0-p))-log(p_ref/(1.0-p_ref)));
  else
    ret=mu+sigma*log(p/(1.0-p));
  
  return ret;
}

double qratio_logistic(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=(mu+sigma*log(p/(1.0-p)))/(mu+sigma*log(p_ref/(1.0-p_ref)));
  else
    ret=mu+sigma*log(p/(1.0-p));
  
  return ret;
}

double logprior_logistic(int numparams, 
			 double *par,
			 int /* num_hyperparameters */,
			 double * /*hyperpar*/ )
{
  double mu=par[0];
  double logsigma=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logistic(p1,MISSING_VALUE,mu,logsigma) : 
    qratio_logistic(p1,MISSING_VALUE,mu,logsigma);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logistic(p2,p1,mu,logsigma) : 
    qratio_logistic(p2,p1,mu,logsigma);

  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_logistic(p1,MISSING_VALUE,
					      mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qdiff_logistic(p1,MISSING_VALUE,
					      mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_logistic(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qdiff_logistic(p2,p1,mu,logsigma-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_logistic(p1,MISSING_VALUE,
					      mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qratio_logistic(p1,MISSING_VALUE,
					      mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_logistic(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qratio_logistic(p2,p1,mu,logsigma-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_logist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);

  double ret=-logsigma - (x-mu)/sigma - 2.0*log(1.0+exp(-(x-mu)/sigma));

  return ret;
}

double log_F_logist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);
  
  double ret=-log(1.0+exp(-(x-mu)/sigma));
  
  return ret;
}

double loglik_logistic(double **data, 
		       int numrows, 
		       int /* numcolumns */,
		       int numparams, 
		       double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_logist, log_F_logist, 2);
  
  return ret;
}




// LOG-LOGISTIC support functions:
/* MCMC stuff */
int loglogistic_likelihood_n;
double *loglogistic_likelihood_X;
double loglogistic_likelihood(double *arg)
{
  int n=loglogistic_likelihood_n;
  double mu=arg[0];
  double logsigma=arg[1], sigma=exp(logsigma);
  double ret=0.0;
  double *x=loglogistic_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	if(x[i]<=0.0)
	  return -1e+200;
	ret+= -logsigma - log(x[i]) - (log(x[i])-mu)/sigma - 2.0*log(1.0+exp(-(log(x[i])-mu)/sigma));
      }
  
  return ret;
} 

void init_loglogistic(int numpar, double *par, int, double * /*hyperpar*/ )
{
  par[0]=gauss();
  par[1]=gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_loglogistic(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma*log(p/(1.0-p)))-exp(mu+sigma*log(p_ref/(1.0-p_ref)));
  else
    ret=exp(mu+sigma*log(p/(1.0-p)));
  
  return ret;
}

double qratio_loglogistic(double p, double p_ref, double mu, double logsigma)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma*log(p/(1.0-p)))/exp(mu+sigma*log(p_ref/(1.0-p_ref)));
  else
    ret=exp(mu+sigma*log(p/(1.0-p)));
  
  return ret;
}

double logprior_loglogistic(int numparams, 
			    double *par,
			    int /* num_hyperparameters */,
			    double * /*hyperpar*/ )
{
  double mu=par[0];
  double logsigma=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_loglogistic(p1,MISSING_VALUE,mu,logsigma) : 
    qratio_loglogistic(p1,MISSING_VALUE,mu,logsigma);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_loglogistic(p2,p1,mu,logsigma) : 
    qratio_loglogistic(p2,p1,mu,logsigma);

  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_loglogistic(p1,MISSING_VALUE,
						 mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qdiff_loglogistic(p1,MISSING_VALUE,
						 mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_loglogistic(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qdiff_loglogistic(p2,p1,mu,logsigma-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_loglogistic(p1,MISSING_VALUE,
						 mu-dx,logsigma))/dx;
      theta_der[0][1]=(q1_curr-qratio_loglogistic(p1,MISSING_VALUE,
						 mu,logsigma-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_loglogistic(p2,p1,mu-dx,logsigma))/dx;
      theta_der[1][1]=(q2_curr-qratio_loglogistic(p2,p1,mu,logsigma-dx))/dx;
    }

  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_loglogist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);

  if(x<=0.0)
    return -1e+200;

  double ret=-logsigma - log(x)- (log(x)-mu)/sigma - 
    2.0*log(1.0+exp(-(log(x)-mu)/sigma));

  return ret;
}

double log_F_loglogist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);
  
  if(x<=0.0)
    return -1e+200;
  
  double ret=-log(1.0+exp(-(log(x)-mu)/sigma));
  
  return ret;
}

double loglik_loglogistic(double **data, 
			  int numrows, 
			  int /* numcolumns */,
			  int numparams, 
			  double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_loglogist, log_F_loglogist, 2);
  
  return ret;
}




// GENERALIZED LOGISTIC support functions:
/* MCMC stuff */
int glogistic_likelihood_n;
double *glogistic_likelihood_X;
double glogistic_likelihood(double *arg)
{
  int n=glogistic_likelihood_n;
  double mu=arg[0];
  double logsigma=arg[1], sigma=exp(logsigma), k=arg[2];
  double ret=0.0;
  double *x=glogistic_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	if(k==0.0)
	  ret+=-logsigma - (x[i]-mu)/sigma - 2.0*log(1.0+exp(-(x[i]-mu)/sigma));
	else if((k>0.0 && x[i]<=mu+sigma/k) || (k<0.0 && x[i]>=mu+sigma/k))
	  ret+= -logsigma + (1.0/k-1.0)*log(1.0-k*(x[i]-mu)/sigma)-
	    2.0*log(1.0+pow(1.0-k*(x[i]-mu)/sigma,1.0/k));
	else
	  return -1e+200;
      }

  return ret;
} 

void init_glogistic(int numpar, double *par, int, double * /*hyperpar*/ )
{
  if(!distribution_strictly_positive_data)
    par[0]=gauss();
  else
    par[0]=exp(gauss());
  par[1]=gauss();
  par[2]=gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);
}

double qdiff_glogistic(double p, double p_ref, double mu, 
		       double logsigma, double k)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    {
      if(k==0.0)
	ret=sigma*(log(p/(1.0-p))-log(p_ref/(1.0-p_ref)));
      else
	ret=sigma/k*(-pow((1.0-p)/p,k)+pow((1.0-p_ref)/p_ref,k));
    }
  else
    {
      if(k==0.0)
	ret=mu+sigma*log(p/(1.0-p));
      else
	ret=mu+sigma/k*(1.0-pow((1.0-p)/p,k));
    }
  
  return ret;
}

double qratio_glogistic(double p, double p_ref, double mu, 
		       double logsigma, double k)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    {
      if(k==0.0)
	ret=(mu+sigma*log(p/(1.0-p)))/(mu+sigma*log(p/(1.0-p_ref)));
      else
	ret=(mu+sigma/k*(1.0-pow((1.0-p)/p,k)))/
	  (mu+sigma/k*(1.0-pow((1.0-p)/p_ref,k)));
    }
  else
    {
      if(k==0.0)
	ret=mu+sigma*log(p/(1.0-p));
      else
	ret=mu+sigma/k*(1.0-pow((1.0-p)/p,k));
    }
  
  return ret;
}

double logprior_glogistic(int numparams, 
			 double *par,
			 int /* num_hyperparameters */,
			 double * /*hyperpar*/ )
{
  double mu=par[0];
  double logsigma=par[1];
  double k=par[2];
  
  double p1=dist_p1, p2=dist_p2, p3=dist_p3;
  double **theta_der=make_matrix(3,3);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_glogistic(p1,MISSING_VALUE,mu,logsigma,k) : 
    qratio_glogistic(p1,MISSING_VALUE,mu,logsigma,k);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_glogistic(p2,p1,mu,logsigma,k) : 
    qratio_glogistic(p2,p1,mu,logsigma,k);
  double q3_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_glogistic(p3,p2,mu,logsigma,k) : 
    qratio_glogistic(p3,p2,mu,logsigma,k);

  if(q2_curr<=0.0)
    return -1e+200;
  if(q3_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_glogistic(p1,MISSING_VALUE,
					       mu-dx,logsigma,k))/dx;
      theta_der[0][1]=(q1_curr-qdiff_glogistic(p1,MISSING_VALUE,
					       mu,logsigma-dx,k))/dx;
      theta_der[0][2]=(q1_curr-qdiff_glogistic(p1,MISSING_VALUE,
					       mu,logsigma,k-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_glogistic(p2,p1,mu-dx,logsigma,k))/dx;
      theta_der[1][1]=(q2_curr-qdiff_glogistic(p2,p1,mu,logsigma-dx,k))/dx;
      theta_der[1][2]=(q2_curr-qdiff_glogistic(p2,p1,mu,logsigma,k-dx))/dx;
      theta_der[2][0]=(q3_curr-qdiff_glogistic(p3,p2,mu-dx,logsigma,k))/dx;
      theta_der[2][1]=(q3_curr-qdiff_glogistic(p3,p2,mu,logsigma-dx,k))/dx;
      theta_der[2][2]=(q3_curr-qdiff_glogistic(p3,p2,mu,logsigma,k-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_glogistic(p1,MISSING_VALUE,
					       mu-dx,logsigma,k))/dx;
      theta_der[0][1]=(q1_curr-qratio_glogistic(p1,MISSING_VALUE,
					       mu,logsigma-dx,k))/dx;
      theta_der[0][2]=(q1_curr-qratio_glogistic(p1,MISSING_VALUE,
					       mu,logsigma,k-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_glogistic(p2,p1,mu-dx,logsigma,k))/dx;
      theta_der[1][1]=(q2_curr-qratio_glogistic(p2,p1,mu,logsigma-dx,k))/dx;
      theta_der[1][2]=(q2_curr-qratio_glogistic(p2,p1,mu,logsigma,k-dx))/dx;
      theta_der[2][0]=(q3_curr-qratio_glogistic(p3,p2,mu-dx,logsigma,k))/dx;
      theta_der[2][1]=(q3_curr-qratio_glogistic(p3,p2,mu,logsigma-dx,k))/dx;
      theta_der[2][2]=(q3_curr-qratio_glogistic(p3,p2,mu,logsigma,k-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 3, 1);
  doubledelete(theta_der,3);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_glogist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma), k=par[2];

  double ret;
  if(k==0.0)
    ret=-logsigma - (x-mu)/sigma - 2.0*log(1.0+exp(-(x-mu)/sigma));
  else if((k>0.0 && x<=mu+sigma/k) || (k<0.0 && x>=mu+sigma/k))
    ret= -logsigma + (1.0/k-1.0)*log(1.0-k*(x-mu)/sigma)-
      2.0*log(1.0+pow(1.0-k*(x-mu)/sigma,1.0/k));
  else
    return -1e+200;

  return ret;
}

double log_F_glogist(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma), k=par[2];
  
  double ret;
  
  if(k==0.0)
    ret=-log(1.0+exp(-(x-mu)/sigma));
  else if((k>0.0 && x<=mu+sigma/k) || (k<0.0 && x>=mu+sigma/k))
    ret=-log(1.0+pow(1.0-k*(x-mu)/sigma,1.0/k));
  else if(k>0.0)
    ret=0.0;
  else
    ret=-1e+200;
  
  return ret;
}

double loglik_glogistic(double **data, 
			int numrows, 
			int /* numcolumns */,
			int numparams, 
			double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_glogist, log_F_glogist, 3);
  
  return ret;
}




// GAMMA support functions:
/* MCMC stuff */
void init_gamma(int numpar, double *par, int, double * /*hyperpar*/)
{
  par[0]=gauss();
  par[1]=gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}


double qdiff_gamma(double p, double p_ref, double logalpha, double logbeta)
{
  double ret;
  double alpha=exp(logalpha);
  double beta=exp(logbeta);

  if(p_ref>0.0 && p_ref<1.0)
    ret=gsl_cdf_gamma_Pinv(p,alpha,beta)-
      gsl_cdf_gamma_Pinv(p_ref,alpha,beta);
  else
    ret=gsl_cdf_gamma_Pinv(p,alpha,beta);
  return ret;
}


double qratio_gamma(double p, double p_ref, double logalpha, double logbeta)
{
  double ret;
  double alpha=exp(logalpha);
  double beta=exp(logbeta);

  if(p_ref>0.0 && p_ref<1.0)
    ret=gsl_cdf_gamma_Pinv(p,alpha,beta)/
      gsl_cdf_gamma_Pinv(p_ref,alpha,beta);
  else
    ret=gsl_cdf_gamma_Pinv(p,alpha,beta);
  return ret;
}


double logprior_gamma(int numparams, 
		      double *par,
		      int /* num_hyperparameters */,
		      double * /*hyperpar*/ )
{
  double logalfa=par[0];
  double logbeta=par[1];

  if(exp(logalfa)>300.0 || exp(logalfa)<0.2)
    return -1e+200;
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gamma(p1,MISSING_VALUE,logalfa,logbeta) : 
    qratio_gamma(p1,MISSING_VALUE,logalfa,logbeta);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gamma(p2,p1,logalfa,logbeta) : 
    qratio_gamma(p2,p1,logalfa,logbeta);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_gamma(p1,MISSING_VALUE,
					   logalfa-dx,logbeta))/dx;
      theta_der[0][1]=(q1_curr-qdiff_gamma(p1,MISSING_VALUE,
					   logalfa,logbeta-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_gamma(p2,p1,logalfa-dx,logbeta))/dx;
      theta_der[1][1]=(q2_curr-qdiff_gamma(p2,p1,logalfa,logbeta-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_gamma(p1,MISSING_VALUE,
					   logalfa-dx,logbeta))/dx;
      theta_der[0][1]=(q1_curr-qratio_gamma(p1,MISSING_VALUE,
					   logalfa,logbeta-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_gamma(p2,p1,logalfa-dx,logbeta))/dx;
      theta_der[1][1]=(q2_curr-qratio_gamma(p2,p1,logalfa,logbeta-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}


double log_f_gamma(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  
  double ret;
  if(x<=0.0)
    ret = -1e+200;
  else
    ret = -alfa*log(beta)-lgamma(alfa) + (alfa-1.0)*log(x)-x/beta;

  return ret;
}

double log_F_gamma(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  
  if(x<0.0)
    return -1e+200;

  double ret=log(gsl_cdf_gamma_P(x,alfa,beta));

  return ret;
}

double loglik_gamma(double **data, 
		    int numrows, 
		    int /* numcolumns */,
		    int numparams, 
		    double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_gamma, log_F_gamma, 2);
  
  return ret;
}

// PEARSON3 support functions:
/* ML stuff: */
int pearson3_likelihood_n;
double *pearson3_likelihood_X;
double pearson3_likelihood(double *arg)
{
  int n=pearson3_likelihood_n;
  double alfa=exp(arg[0]),beta=exp(arg[1]), mu=arg[2];
  double ret=0.0;
  double *x=pearson3_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	if(x[i]<=mu)
	  return -1e+200;
	else
	  ret+= -alfa*log(beta)-lgamma(alfa) + (alfa-1.0)*log(x[i]-mu)-(x[i]-mu)/beta;
      }
  
  return ret;
} 

/* MCMC stuff */
void init_pearson3(int numpar, double *par, int, double * /*hyperpar*/)
{
  par[0]=gauss();
  par[1]=gauss();
  par[2]=gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);
}


double qdiff_pearson3(double p, double p_ref, double logalpha, 
		      double logbeta, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  double beta=exp(logbeta);

  if(p_ref>0.0 && p_ref<1.0)
    ret=gsl_cdf_gamma_Pinv(p,alpha,beta)-
      gsl_cdf_gamma_Pinv(p_ref,alpha,beta);
  else
    ret=mu+gsl_cdf_gamma_Pinv(p,alpha,beta);
  return ret;
}

double qratio_pearson3(double p, double p_ref, double logalpha, 
		       double logbeta, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  double beta=exp(logbeta);

  if(p_ref>0.0 && p_ref<1.0)
    ret=(mu+gsl_cdf_gamma_Pinv(p,alpha,beta)) /
      (mu+gsl_cdf_gamma_Pinv(p_ref,alpha,beta));
  else
    ret=mu+gsl_cdf_gamma_Pinv(p,alpha,beta);
  return ret;
}


double logprior_pearson3(int numparams, 
		      double *par,
		      int /* num_hyperparameters */,
		      double * /*hyperpar*/ )
{
  double logalfa=par[0];
  double logbeta=par[1];
  double mu=par[2];

  if(exp(logalfa)>300.0 || exp(logalfa)<0.2)
    return -1e+200;
  
  double p1=dist_p1, p2=dist_p2, p3=dist_p3;
  double **theta_der=make_matrix(3,3);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_pearson3(p1,MISSING_VALUE,logalfa,logbeta,mu) : 
    qratio_pearson3(p1,MISSING_VALUE,logalfa,logbeta,mu);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_pearson3(p2,p1,logalfa,logbeta,mu) : 
    qratio_pearson3(p2,p1,logalfa,logbeta,mu);
  double q3_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_pearson3(p3,p2,logalfa,logbeta,mu) : 
    qratio_pearson3(p3,p2,logalfa,logbeta,mu);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(q3_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_pearson3(p1,MISSING_VALUE,
					      logalfa-dx,logbeta,mu))/dx;
      theta_der[0][1]=(q1_curr-qdiff_pearson3(p1,MISSING_VALUE,
					      logalfa,logbeta-dx,mu))/dx;
      theta_der[0][2]=(q1_curr-qdiff_pearson3(p1,MISSING_VALUE,
					      logalfa,logbeta,mu-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_pearson3(p2,p1,logalfa-dx,logbeta,mu))/dx;
      theta_der[1][1]=(q2_curr-qdiff_pearson3(p2,p1,logalfa,logbeta-dx,mu))/dx;
      theta_der[1][2]=(q2_curr-qdiff_pearson3(p2,p1,logalfa,logbeta,mu-dx))/dx;
      theta_der[2][0]=(q3_curr-qdiff_pearson3(p3,p2,logalfa-dx,logbeta,mu))/dx;
      theta_der[2][1]=(q3_curr-qdiff_pearson3(p3,p2,logalfa,logbeta-dx,mu))/dx;
      theta_der[2][2]=(q3_curr-qdiff_pearson3(p3,p2,logalfa,logbeta,mu-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_pearson3(p1,MISSING_VALUE,
					      logalfa-dx,logbeta,mu))/dx;
      theta_der[0][1]=(q1_curr-qratio_pearson3(p1,MISSING_VALUE,
					      logalfa,logbeta-dx,mu))/dx;
      theta_der[0][2]=(q1_curr-qratio_pearson3(p1,MISSING_VALUE,
					      logalfa,logbeta,mu-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_pearson3(p2,p1,logalfa-dx,logbeta,mu))/dx;
      theta_der[1][1]=(q2_curr-qratio_pearson3(p2,p1,logalfa,logbeta-dx,mu))/dx;
      theta_der[1][2]=(q2_curr-qratio_pearson3(p2,p1,logalfa,logbeta,mu-dx))/dx;
      theta_der[2][0]=(q3_curr-qratio_pearson3(p3,p2,logalfa-dx,logbeta,mu))/dx;
      theta_der[2][1]=(q3_curr-qratio_pearson3(p3,p2,logalfa,logbeta-dx,mu))/dx;
      theta_der[2][2]=(q3_curr-qratio_pearson3(p3,p2,logalfa,logbeta,mu-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 3, 1);
  doubledelete(theta_der,3);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq3_sd)-log(q3_curr)-
    0.5*(log(q3_curr)-logq3_mu)*(log(q3_curr)-logq3_mu)/logq3_sd/logq3_sd;
  
  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_pearson3(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  double mu=par[2];

  double ret;
  if(x<=mu)
    ret = -1e+200;
  else
    ret = -alfa*log(beta)-lgamma(alfa) + (alfa-1.0)*log(x-mu)-(x-mu)/beta;

  return ret;
}

double log_F_pearson3(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  double mu=par[2];

  if(x<=mu)
    return -1e+200;
  
  double ret=log(gsl_cdf_gamma_P(x-mu,alfa,beta));
  
  return ret;
}

double loglik_pearson3(double **data, 
		       int numrows, 
		       int /* numcolumns */,
		       int numparams, 
		       double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_pearson3, log_F_pearson3, 3);
  
  return ret;
}



// LOGPEARSON3 support functions:
/* ML stuff: */
int logpearson3_likelihood_n;
double *logpearson3_likelihood_X;
double logpearson3_likelihood(double *arg)
{
  int n=logpearson3_likelihood_n;
  double alfa=exp(arg[0]),beta=exp(arg[1]), mu=arg[2];
  double ret=0.0;
  double *x=logpearson3_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	if(x[i]<=0.0 || log(x[i])<mu)
	   return -1e+200;
	else
	  ret+= -alfa*log(beta)-lgamma(alfa) + (alfa-1.0)*log(log(x[i])-mu)-(log(x[i])-mu)/beta-log(x[i]);
      }
	
  return ret;
} 

/* MCMC stuff */
void init_logpearson3(int numpar, double *par, int, double * /*hyperpar*/)
{
  par[0]=gauss();
  par[1]=gauss();
  par[2]=gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);
}


double qdiff_logpearson3(double p, double p_ref, double logalpha, double logbeta, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  double beta=exp(logbeta);

  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+gsl_cdf_gamma_Pinv(p,alpha,beta))-
      exp(mu+gsl_cdf_gamma_Pinv(p_ref,alpha,beta));
  else
    ret=exp(mu+gsl_cdf_gamma_Pinv(p,alpha,beta));
  return ret;
}

double qratio_logpearson3(double p, double p_ref, double logalpha, 
			 double logbeta, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  double beta=exp(logbeta);

  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+gsl_cdf_gamma_Pinv(p,alpha,beta)) / 
      exp(mu+gsl_cdf_gamma_Pinv(p_ref,alpha,beta));
  else
    ret=exp(mu+gsl_cdf_gamma_Pinv(p,alpha,beta));
  return ret;
}


double logprior_logpearson3(int numparams, 
			    double *par,
			    int /* num_hyperparameters */,
			    double * /*hyperpar*/ )
{
  double logalfa=par[0];
  double logbeta=par[1];
  double mu=par[2];

  if(exp(logalfa)>300.0 || exp(logalfa)<0.2)
    return -1e+200;
  
  double p1=dist_p1, p2=dist_p2, p3=dist_p3;
  double **theta_der=make_matrix(3,3);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logpearson3(p1,MISSING_VALUE,logalfa,logbeta,mu) : 
    qratio_logpearson3(p1,MISSING_VALUE,logalfa,logbeta,mu);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logpearson3(p2,p1,logalfa,logbeta,mu) : 
    qratio_logpearson3(p2,p1,logalfa,logbeta,mu);
  double q3_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_logpearson3(p3,p2,logalfa,logbeta,mu) : 
    qratio_logpearson3(p3,p2,logalfa,logbeta,mu);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(q3_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_logpearson3(p1,MISSING_VALUE,
						 logalfa-dx,logbeta,mu))/dx;
      theta_der[0][1]=(q1_curr-qdiff_logpearson3(p1,MISSING_VALUE,
						 logalfa,logbeta-dx,mu))/dx;
      theta_der[0][2]=(q1_curr-qdiff_logpearson3(p1,MISSING_VALUE,
						 logalfa,logbeta,mu-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_logpearson3(p2,p1,logalfa-dx,
						 logbeta,mu))/dx;
      theta_der[1][1]=(q2_curr-qdiff_logpearson3(p2,p1,logalfa,
						 logbeta-dx,mu))/dx;
      theta_der[1][2]=(q2_curr-qdiff_logpearson3(p2,p1,logalfa,
						 logbeta,mu-dx))/dx;
      theta_der[2][0]=(q3_curr-qdiff_logpearson3(p3,p2,logalfa-dx,
						 logbeta,mu))/dx;
      theta_der[2][1]=(q3_curr-qdiff_logpearson3(p3,p2,logalfa,
						 logbeta-dx,mu))/dx;
      theta_der[2][2]=(q3_curr-qdiff_logpearson3(p3,p2,logalfa,
						 logbeta,mu-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_logpearson3(p1,MISSING_VALUE,
						 logalfa-dx,logbeta,mu))/dx;
      theta_der[0][1]=(q1_curr-qratio_logpearson3(p1,MISSING_VALUE,
						 logalfa,logbeta-dx,mu))/dx;
      theta_der[0][2]=(q1_curr-qratio_logpearson3(p1,MISSING_VALUE,
						 logalfa,logbeta,mu-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_logpearson3(p2,p1,logalfa-dx,
						 logbeta,mu))/dx;
      theta_der[1][1]=(q2_curr-qratio_logpearson3(p2,p1,logalfa,
						 logbeta-dx,mu))/dx;
      theta_der[1][2]=(q2_curr-qratio_logpearson3(p2,p1,logalfa,
						 logbeta,mu-dx))/dx;
      theta_der[2][0]=(q3_curr-qratio_logpearson3(p3,p2,logalfa-dx,
						 logbeta,mu))/dx;
      theta_der[2][1]=(q3_curr-qratio_logpearson3(p3,p2,logalfa,
						 logbeta-dx,mu))/dx;
      theta_der[2][2]=(q3_curr-qratio_logpearson3(p3,p2,logalfa,
						 logbeta,mu-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 3, 1);
  doubledelete(theta_der,3);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq3_sd)-log(q3_curr)-
    0.5*(log(q3_curr)-logq3_mu)*(log(q3_curr)-logq3_mu)/logq3_sd/logq3_sd;
  
  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}


double log_f_logpearson3(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  double mu=par[2];
  
  double ret;
  if(x<=0.0 || log(x)<=mu)
    ret = -1e+200;
  else
    ret = -alfa*log(beta)-lgamma(alfa) + 
      (alfa-1.0)*log(log(x)-mu)-(log(x)-mu)/beta-log(x);

  return ret;
}

double log_F_logpearson3(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double logbeta=par[1], beta=exp(logbeta);
  double mu=par[2];
  
  if(x<=0.0 || log(x)<=mu)
    return -1e+200;

  double ret=log(gsl_cdf_gamma_P(log(x)-mu,alfa,beta));
  
  return ret;
}

double loglik_logpearson3(double **data, 
			  int numrows, 
			  int /* numcolumns */,
			  int numparams, 
			  double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_logpearson3, log_F_logpearson3, 3);
  
  return ret;
}


// GUMBEL suuport functions:
/* ML stuff: */
int gumbel_likelihood_n;
double *gumbel_likelihood_X;
double gumbel_likelihood(double *arg)
{
  int n=gumbel_likelihood_n;
  double alfa=arg[0]*arg[0];
  double u=arg[1];
  double ret=0.0;
  double *x=gumbel_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      ret+=log( exp( -(x[i]-u)/alfa-exp(-(x[i]-u)/alfa) )/alfa );

  return ret;
} 

/* MCMC stuff */
void init_gumbel(int numpar, double *par, int, double * /*hyperpar*/)
{
  par[0]=gauss();
  par[1]=gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_gumbel(double p, double p_ref, double logalpha, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=-alpha*log(-log(p))+alpha*log(-log(p_ref));
  else
    ret=mu-alpha*log(-log(p));
  return ret;
}

double qratio_gumbel(double p, double p_ref, double logalpha, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=(mu-alpha*log(-log(p)))/(mu-alpha*log(-log(p_ref)));
  else
    ret=mu-alpha*log(-log(p));
  return ret;
}

double logprior_gumbel(int numparams, 
		       double *par,
		       int /* num_hyperparameters */,
		       double * /*hyperpar*/)
{
  double logalfa=par[0];
  double u=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gumbel(p1,MISSING_VALUE,logalfa,u) : 
    qratio_gumbel(p1,MISSING_VALUE,logalfa,u);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gumbel(p2,p1,logalfa,u) : 
    qratio_gumbel(p2,p1,logalfa,u);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_gumbel(p1,MISSING_VALUE,logalfa-dx,u))/dx;
      theta_der[0][1]=(q1_curr-qdiff_gumbel(p1,MISSING_VALUE,logalfa,u-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_gumbel(p2,p1,logalfa-dx,u))/dx;
      theta_der[1][1]=(q2_curr-qdiff_gumbel(p2,p1,logalfa,u-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_gumbel(p1,MISSING_VALUE,logalfa-dx,u))/dx;
      theta_der[0][1]=(q1_curr-qratio_gumbel(p1,MISSING_VALUE,logalfa,u-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_gumbel(p2,p1,logalfa-dx,u))/dx;
      theta_der[1][1]=(q2_curr-qratio_gumbel(p2,p1,logalfa,u-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_gumbel(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double u=par[1];

  double ret = -(x-u)/alfa - exp(-(x-u)/alfa) - logalfa;

  return ret;
}

double log_F_gumbel(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double u=par[1];

  double ret=-exp(-(x-u)/alfa);

  return ret;
}

double loglik_gumbel(double **data, 
		     int numrows, 
		     int /* numcolumns */,
		     int numparams, 
		     double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_gumbel, log_F_gumbel, 2);
  
  return ret;
}

// LOG-GUMBEL suuport functions:
/* ML stuff: */
int loggumbel_likelihood_n;
double *loggumbel_likelihood_X;
double loggumbel_likelihood(double *arg)
{
  int n=loggumbel_likelihood_n;
  double alfa=arg[0]*arg[0];
  double u=arg[1];
  double ret=0.0;
  double *x=loggumbel_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      ret+=log( exp( -(log(x[i])-u)/alfa-exp(-(log(x[i])-u)/alfa) )/alfa/x[i] );

  return ret;
} 

/* MCMC stuff */
void init_loggumbel(int numpar, double *par, int, double * /*hyperpar*/)
{
  par[0]=gauss();
  par[1]=gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_loggumbel(double p, double p_ref, double logalpha, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu-alpha*log(-log(p)))-exp(mu-alpha*log(-log(p_ref)));
  else
    ret=exp(mu-alpha*log(-log(p)));
  return ret;
}

double qratio_loggumbel(double p, double p_ref, double logalpha, double mu)
{
  double ret;
  double alpha=exp(logalpha);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu-alpha*log(-log(p)))/exp(mu-alpha*log(-log(p_ref)));
  else
    ret=exp(mu-alpha*log(-log(p)));
  return ret;
}

double logprior_loggumbel(int numparams, 
			  double *par,
			  int /* num_hyperparameters */,
			  double * /*hyperpar*/)
{
  double logalfa=par[0];
  double u=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_loggumbel(p1,MISSING_VALUE,logalfa,u) : 
    qratio_loggumbel(p1,MISSING_VALUE,logalfa,u);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_loggumbel(p2,p1,logalfa,u) : 
    qratio_loggumbel(p2,p1,logalfa,u);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_loggumbel(p1,MISSING_VALUE,
					       logalfa-dx,u))/dx;
      theta_der[0][1]=(q1_curr-qdiff_loggumbel(p1,MISSING_VALUE,
					       logalfa,u-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_loggumbel(p2,p1,logalfa-dx,u))/dx;
      theta_der[1][1]=(q2_curr-qdiff_loggumbel(p2,p1,logalfa,u-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_loggumbel(p1,MISSING_VALUE,
					       logalfa-dx,u))/dx;
      theta_der[0][1]=(q1_curr-qratio_loggumbel(p1,MISSING_VALUE,
					       logalfa,u-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_loggumbel(p2,p1,logalfa-dx,u))/dx;
      theta_der[1][1]=(q2_curr-qratio_loggumbel(p2,p1,logalfa,u-dx))/dx;
    }

  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(q1_curr<=0.0 || q2_curr<=0.0)
    return -1e+200;
  
  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_loggumbel(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double u=par[1];

  if(x<=0.0)
    return -1e+200;
  
  double ret=-(log(x)-u)/alfa - exp(-(log(x)-u)/alfa) - log(alfa) - log(x);
  
  return ret;
}

double log_F_loggumbel(double x, int /*numparams*/, double *par)
{
  double logalfa=par[0], alfa=exp(logalfa);
  double u=par[1];
  
  if(x<=0.0)
    return -1e+200;

  double ret=-exp(-(log(x)-u)/alfa);

  return ret;
}

double loglik_loggumbel(double **data, 
			int numrows, 
			int /* numcolumns */,
			int numparams, 
			double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_loggumbel, log_F_loggumbel, 2);
  
  return ret;
}



// GEV support functions, ML:
int gev_likelihood_n;
double *gev_likelihood_X;
double gev_likelihood(double *arg)
{
  int n=gev_likelihood_n;
  double sigma=arg[0];
  double mu=arg[1];
  double ksi=arg[2];
  double ret=0.0;
  double *x=gev_likelihood_X;

  if(sigma<=0.0)
    return -1000000.0;
  
  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	double f;
	
	if(ksi==0.0)
	  {
	    f=1.0/sigma * exp(-(x[i]-mu)/sigma) * exp(-exp(-(x[i]-mu)/sigma));
	  }
	else
	  {
	    if((ksi>0.0 && x[i]<mu-sigma/ksi) ||
	       (ksi<0.0 && x[i]>mu-sigma/ksi))
	      f=0.0;
	    else
	      f=1.0/sigma * pow(1.0+ksi*(x[i]-mu)/sigma, -1.0/ksi-1.0) * 
		exp(-pow(1.0+ksi*(x[i]-mu)/sigma, -1.0/ksi));
	  } 

	if(f>0.0)
	  ret+=log(f);
	else
	  ret-=1000000.0;
      }

  return ret;
} 

/* MCMC stuff */




// possibility to set initial values:
double gev_mu_init=MISSING_VALUE, gev_sigma_init=MISSING_VALUE, 
  gev_ksi_init=MISSING_VALUE;
int first_gev_init=1;

// Function for setting initial parameter values:
void init_gev(int numpar, double *par, int, double * /*hyperpar */)
{
  if(gev_mu_init!=MISSING_VALUE && first_gev_init)
    par[0]=gev_mu_init;
  else
    par[0]=gauss();
  
  if(gev_sigma_init!=MISSING_VALUE && first_gev_init)
    par[1]=log(gev_sigma_init);
  else
    par[1]=gauss();
  
  if(gev_ksi_init!=MISSING_VALUE && first_gev_init)
    par[2]=gev_ksi_init;
  else
    par[2]=gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);

  first_gev_init=0;
}

double qdiff_gev(double p, double p_ref, double mu, 
		 double logsigma, double ksi)
{
  double sigma=exp(logsigma);
  double ret;

  if(p_ref>0.0 && p_ref<1.0)
    ret=sigma/ksi*(pow(-log(p),-ksi)-pow(-log(p_ref),-ksi));
  else
    ret=mu+sigma/ksi*(pow(-log(p),-ksi)-1.0);
  return ret;
}

double qratio_gev(double p, double p_ref, double mu, 
		  double logsigma, double ksi)
{
  double sigma=exp(logsigma);
  double ret;

  if(p_ref>0.0 && p_ref<1.0)
    ret=(mu+sigma/ksi*(pow(-log(p),-ksi)-1.0))/
      (mu+sigma/ksi*(pow(-log(p_ref),-ksi)-1.0));
  else
    ret=mu+sigma/ksi*(pow(-log(p),-ksi)-1.0);
  return ret;
}

double logprior_gev(int numparams, 
		    double *par,
		    int /* num_hyperparameters */,
		    double * /*hyperpar*/)
{
  // hyper parameters fetched from global parameter list 
  // in the start of the file
  double p1=dist_p1, p2=dist_p2, p3=dist_p3;
  
  double mu=par[0];
  double ls=par[1]; // log(sigma)
  double ksi=par[2];
  
  double **theta_der=make_matrix(3,3);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gev(p1,MISSING_VALUE,mu,ls,ksi) : 
    qratio_gev(p1,MISSING_VALUE,mu,ls,ksi);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gev(p2,p1,mu,ls,ksi) : 
    qratio_gev(p2,p1,mu,ls,ksi);
  double q3_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_gev(p3,p2,mu,ls,ksi) : 
    qratio_gev(p3,p2,mu,ls,ksi);
  
  if(q2_curr<=0.0)
    return -1e+200;
  if(q3_curr<=0.0)
    return -1e+200;

  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_gev(p1,MISSING_VALUE,mu-dx,ls,ksi))/dx;
      theta_der[0][1]=(q1_curr-qdiff_gev(p1,MISSING_VALUE, mu,ls-dx,ksi))/dx;
      theta_der[0][2]=(q1_curr-qdiff_gev(p1,MISSING_VALUE,mu,ls,ksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_gev(p2,p1,mu-dx,ls,ksi))/dx;
      theta_der[1][1]=(q2_curr-qdiff_gev(p2,p1,mu,ls-dx,ksi))/dx;
      theta_der[1][2]=(q2_curr-qdiff_gev(p2,p1,mu,ls,ksi-dx))/dx;
      theta_der[2][0]=(q3_curr-qdiff_gev(p3,p2,mu-dx,ls,ksi))/dx;
      theta_der[2][1]=(q3_curr-qdiff_gev(p3,p2,mu,ls-dx,ksi))/dx;
      theta_der[2][2]=(q3_curr-qdiff_gev(p3,p2,mu,ls,ksi-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_gev(p1,MISSING_VALUE,mu-dx,ls,ksi))/dx;
      theta_der[0][1]=(q1_curr-qratio_gev(p1,MISSING_VALUE, mu,ls-dx,ksi))/dx;
      theta_der[0][2]=(q1_curr-qratio_gev(p1,MISSING_VALUE,mu,ls,ksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_gev(p2,p1,mu-dx,ls,ksi))/dx;
      theta_der[1][1]=(q2_curr-qratio_gev(p2,p1,mu,ls-dx,ksi))/dx;
      theta_der[1][2]=(q2_curr-qratio_gev(p2,p1,mu,ls,ksi-dx))/dx;
      theta_der[2][0]=(q3_curr-qratio_gev(p3,p2,mu-dx,ls,ksi))/dx;
      theta_der[2][1]=(q3_curr-qratio_gev(p3,p2,mu,ls-dx,ksi))/dx;
      theta_der[2][2]=(q3_curr-qratio_gev(p3,p2,mu,ls,ksi-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 3, 1);
  doubledelete(theta_der,3);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(distribution_strictly_positive_data && q1_curr<=0.0)
    return -1e+200;

  if(distribution_strictly_positive_data)
    ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
      0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  else
    ret+=-0.5*log(2.0*M_PI)-log(q1_sd)-
      0.5*(q1_curr-q1_mu)*(q1_curr-q1_mu)/q1_sd/q1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq3_sd)-log(q3_curr)-
    0.5*(log(q3_curr)-logq3_mu)*(log(q3_curr)-logq3_mu)/logq3_sd/logq3_sd;

  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}



double log_f_gev(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);
  double ksi=par[2];
  
  if(ksi==0.0)
    return -(x-mu)/sigma - exp(-(x-mu)/sigma) - log(sigma);
  else if(ksi>0.0 && x<mu-sigma/ksi)
    return -1e+200;
  else if(ksi<0.0 && x>mu-sigma/ksi)
    return -1e+200;
  else 
    return -logsigma+(-1.0/ksi-1.0)*log(1.0+ksi*(x-mu)/sigma) -
      pow(1.0+ksi*(x-mu)/sigma, -1.0/ksi);
}

double log_F_gev(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);
  double ksi=par[2];
  
  if(ksi==0.0)
    return -exp(-(x-mu)/sigma);
  else if(ksi>0.0 && x<mu-sigma/ksi)
    return -1e+200;
  else if(ksi<0.0 && x>mu-sigma/ksi)
    return 0.0;
  else
    return -pow(1.0+ksi*(x-mu)/sigma,-1.0/ksi);
}


double loglik_gev(double **data, 
		  int numrows, 
		  int /* numcolumns */,
		  int numparams, 
		  double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_gev, log_F_gev, 3);

  return ret;
}



// log-GEV support functions:
int loggev_likelihood_n;
double *loggev_likelihood_X;
double loggev_likelihood(double *arg)
{
  int n=loggev_likelihood_n;
  double sigma=arg[0];
  double mu=arg[1];
  double ksi=arg[2];
  double ret=0.0;
  double *x=loggev_likelihood_X;

  if(sigma<=0.0)
    return -1000000.0;
  
  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	double f;
	
	if(x[i]<=0.0)
	  return -1e+200;

	if(ksi==0.0)
	  {
	    f=1.0/sigma/x[i] * exp(-(log(x[i])-mu)/sigma) * exp(-exp(-(log(x[i])-mu)/sigma));
	  }
	else
	  {
	    if((ksi>0.0 && log(x[i])<mu-sigma/ksi) ||
	       (ksi<0.0 && log(x[i])>mu-sigma/ksi))
	      f=0.0;
	    else
	      f=1.0/sigma/x[i] * pow(1.0+ksi*(log(x[i])-mu)/sigma, -1.0/ksi-1.0) * 
		exp(-pow(1.0+ksi*(log(x[i])-mu)/sigma, -1.0/ksi));
	  } 

	if(f>0.0)
	  ret+=log(f);
	else
	  ret-=1000000.0;
      }

  return ret;
} 

/* MCMC stuff */
double loggev_mu_init=MISSING_VALUE, loggev_sigma_init=MISSING_VALUE, 
  loggev_ksi_init=MISSING_VALUE;
int first_loggev_init=1;
void init_loggev(int numpar, double *par, int, double * /*hyperpar */)
{
  if(loggev_mu_init!=MISSING_VALUE && first_loggev_init)
    par[0]=loggev_mu_init;
  else
    par[0]=gauss();
  
  if(loggev_sigma_init!=MISSING_VALUE && first_loggev_init)
    par[1]=log(loggev_sigma_init);
  else
    par[1]=gauss();
  
  if(loggev_ksi_init!=MISSING_VALUE && first_loggev_init)
    par[2]=loggev_ksi_init;
  else
    par[2]=gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);

  first_loggev_init=0;
}

double qdiff_loggev(double p, double p_ref, double mu, 
		    double logsigma, double ksi)
{
  double sigma=exp(logsigma);
  double ret;

  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma/ksi*(pow(-log(p),-ksi)-1.0))-exp(mu+sigma/ksi*(pow(-log(p_ref),-ksi)-1.0));
  else
    ret=exp(mu+sigma/ksi*(pow(-log(p),-ksi)-1.0));
  return ret;
}

double qratio_loggev(double p, double p_ref, double mu, 
		     double logsigma, double ksi)
{
  double sigma=exp(logsigma);
  double ret;

  if(p_ref>0.0 && p_ref<1.0)
    ret=exp(mu+sigma/ksi*(pow(-log(p),-ksi)-1.0)) /
      exp(mu+sigma/ksi*(pow(-log(p_ref),-ksi)-1.0));
  else
    ret=exp(mu+sigma/ksi*(pow(-log(p),-ksi)-1.0));
  return ret;
}

double logprior_loggev(int numparams, 
		    double *par,
		    int /* num_hyperparameters */,
		    double * /*hyperpar*/)
{
  // hyper parameters fetched from global parameter list 
  // in the start of the file
  double p1=dist_p1, p2=dist_p2, p3=dist_p3;
  
  double mu=par[0];
  double ls=par[1]; // log(sigma)
  double ksi=par[2];
  
  double **theta_der=make_matrix(3,3);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_loggev(p1,MISSING_VALUE,mu,ls,ksi) : 
    qratio_loggev(p1,MISSING_VALUE,mu,ls,ksi);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_loggev(p2,p1,mu,ls,ksi) : 
    qratio_loggev(p2,p1,mu,ls,ksi);
  double q3_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_loggev(p3,p2,mu,ls,ksi) : 
    qratio_loggev(p3,p2,mu,ls,ksi);
  
  if(q2_curr<=0.0)
    return -1e+200;
  if(q3_curr<=0.0)
    return -1e+200;

  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_loggev(p1,MISSING_VALUE,mu-dx,ls,ksi))/dx;
      theta_der[0][1]=(q1_curr-qdiff_loggev(p1,MISSING_VALUE, mu,ls-dx,ksi))/dx;
      theta_der[0][2]=(q1_curr-qdiff_loggev(p1,MISSING_VALUE,mu,ls,ksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_loggev(p2,p1,mu-dx,ls,ksi))/dx;
      theta_der[1][1]=(q2_curr-qdiff_loggev(p2,p1,mu,ls-dx,ksi))/dx;
      theta_der[1][2]=(q2_curr-qdiff_loggev(p2,p1,mu,ls,ksi-dx))/dx;
      theta_der[2][0]=(q3_curr-qdiff_loggev(p3,p2,mu-dx,ls,ksi))/dx;
      theta_der[2][1]=(q3_curr-qdiff_loggev(p3,p2,mu,ls-dx,ksi))/dx;
      theta_der[2][2]=(q3_curr-qdiff_loggev(p3,p2,mu,ls,ksi-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_loggev(p1,MISSING_VALUE,
					     mu-dx,ls,ksi))/dx;
      theta_der[0][1]=(q1_curr-qratio_loggev(p1,MISSING_VALUE, 
					     mu,ls-dx,ksi))/dx;
      theta_der[0][2]=(q1_curr-qratio_loggev(p1,MISSING_VALUE,
					     mu,ls,ksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_loggev(p2,p1,mu-dx,ls,ksi))/dx;
      theta_der[1][1]=(q2_curr-qratio_loggev(p2,p1,mu,ls-dx,ksi))/dx;
      theta_der[1][2]=(q2_curr-qratio_loggev(p2,p1,mu,ls,ksi-dx))/dx;
      theta_der[2][0]=(q3_curr-qratio_loggev(p3,p2,mu-dx,ls,ksi))/dx;
      theta_der[2][1]=(q3_curr-qratio_loggev(p3,p2,mu,ls-dx,ksi))/dx;
      theta_der[2][2]=(q3_curr-qratio_loggev(p3,p2,mu,ls,ksi-dx))/dx;
    }
  
  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 3, 1);
  doubledelete(theta_der,3);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  if(q1_curr<=0.0 || q2_curr<=0.0 || q3_curr<=0.0)
    return -1e+200;
  
  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq3_sd)-log(q3_curr)-
    0.5*(log(q3_curr)-logq3_mu)*(log(q3_curr)-logq3_mu)/logq3_sd/logq3_sd;
  
  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}


double log_f_loggev(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);
  double ksi=par[2];
  
  if(x<=0.0)
    return -1e+200;

  if(ksi==0.0)
    return -(log(x)-mu)/sigma - exp(-(log(x)-mu)/sigma) - log(sigma) - log(x);
  else if(ksi>0.0 && log(x)<mu-sigma/ksi)
    return -1e+200;
  else if(ksi<0.0 && log(x)>mu-sigma/ksi)
    return -1e+200;
  else 
    return -logsigma+(-1.0/ksi-1.0)*log(1.0+ksi*(log(x)-mu)/sigma) -
      pow(1.0+ksi*(log(x)-mu)/sigma, -1.0/ksi) - log(x);
}

double log_F_loggev(double x, int /*numparams*/, double *par)
{
  double mu=par[0];
  double logsigma=par[1], sigma=exp(logsigma);
  double ksi=par[2];
  
  if(x<=0.0)
    return -1e+200;
  
  if(ksi==0.0)
    return -exp(-(log(x)-mu)/sigma);
  else if(ksi>0.0 && log(x)<mu-sigma/ksi)
    return -1e+200;
  else if(ksi<0.0 && log(x)>mu-sigma/ksi)
    return 0.0;
  else
    return -pow(1.0+ksi*(log(x)-mu)/sigma,-1.0/ksi);
}



double loglik_loggev(double **data, 
		     int numrows, 
		     int /* numcolumns */,
		     int numparams, 
		     double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_loggev, log_F_loggev, 3);
  
  return ret;
}



// WEIBULL support functions:
int weibull_likelihood_n;
double *weibull_likelihood_X;
double weibull_likelihood(double *arg)
{
  int n=weibull_likelihood_n;
  double sigma=arg[0];
  double ksi=arg[1];
  double ret=0.0;
  double *x=weibull_likelihood_X;
  
  if(sigma<=0.0 || ksi<=0.0)
    return -1000000.0;
  
  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	double f=0.0;
	
	if(x[i]>0)
	  f=ksi/sigma * pow(x[i]/sigma, ksi-1.0) * 
	    exp(-pow(x[i]/sigma, ksi));
			    
	if(f>0.0)
	  ret+=log(f);
	else
	  ret-=1000000.0;
      }
  
  return ret;
} 

/* MCMC stuff */
void init_weibull(int numpar, double *par, int, double */*hyperpar*/)
{
  par[0]=gauss();
  par[1]=1.0+0.2*gauss();
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_weibull(double p, double p_ref, double logsigma, double logksi)
{
  double ret;
  double sigma=exp(logsigma), ksi=exp(logksi);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=(sigma*pow(-log(1.0-p),1.0/ksi))-(sigma*pow(-log(1.0-p_ref),1.0/ksi));
  else
    ret=sigma*pow(-log(1.0-p),1.0/ksi);
  return ret;
}

double qratio_weibull(double p, double p_ref, double logsigma, double logksi)
{
  double ret;
  double sigma=exp(logsigma), ksi=exp(logksi);
  
  if(p_ref>0.0 && p_ref<1.0)
    ret=(sigma*pow(-log(1.0-p),1.0/ksi))/(sigma*pow(-log(1.0-p_ref),1.0/ksi));
  else
    ret=sigma*pow(-log(1.0-p),1.0/ksi);
  return ret;
}

double logprior_weibull(int numparams, 
			double *par,
			int /* num_hyperparameters */,
			double */*hyperpar*/)
{
  double logsigma=par[0];
  double logksi=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_weibull(p1,MISSING_VALUE,logsigma,logksi) : 
    qratio_weibull(p1,MISSING_VALUE,logsigma,logksi);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_weibull(p2,p1,logsigma,logksi) : 
    qratio_weibull(p2,p1,logsigma,logksi);
  
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_weibull(p1,MISSING_VALUE,
					     logsigma-dx,logksi))/dx;
      theta_der[0][1]=(q1_curr-qdiff_weibull(p1,MISSING_VALUE,
					     logsigma,logksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_weibull(p2,p1,logsigma-dx,logksi))/dx;
      theta_der[1][1]=(q2_curr-qdiff_weibull(p2,p1,logsigma,logksi-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_weibull(p1,MISSING_VALUE,
					     logsigma-dx,logksi))/dx;
      theta_der[0][1]=(q1_curr-qratio_weibull(p1,MISSING_VALUE,
					     logsigma,logksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_weibull(p2,p1,logsigma-dx,logksi))/dx;
      theta_der[1][1]=(q2_curr-qratio_weibull(p2,p1,logsigma,logksi-dx))/dx;
    }

  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);

  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_weibull(double x, int /*numparams*/, double *par)
{
  double logsigma=par[0], sigma=exp(logsigma);
  double logksi=par[1], ksi=exp(logksi);

  if(x<=0.0)
    return -1e+200;

  double ret=logksi-logsigma+(ksi-1.0)* log(x/sigma) - 
    pow(x/sigma, ksi);

  return ret;
}

double log_F_weibull(double x, int /*numparams*/, double *par)
{
  double logsigma=par[0], sigma=exp(logsigma);
  double logksi=par[1], ksi=exp(logksi);

  if(x<=0.0)
    return -1e+200;

  double ret=log(1.0-exp(-pow(x/sigma, ksi)));

  return ret;
}

double loglik_weibull(double **data, 
		      int numrows, 
		      int /* numcolumns */,
		      int numparams, 
		      double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_weibull, log_F_weibull, 2);
  
  return ret;
}




// PARETO support functions:
int pareto_likelihood_n;
double *pareto_likelihood_X;
double pareto_likelihood(double *arg)
{
  int n=pareto_likelihood_n;
  double alfa=arg[0];
  double k=arg[1];
  double ret=0.0;
  double *x=pareto_likelihood_X;
  
  if(alfa<0.0)
    return -1e+6;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	double f;
	
	if(x[i]<0.0)
	  f=0.0;
	else if(k>0 && x[i]>alfa/k)
	  f=0.0;
	else if(k!=0.0)
	  f=1/alfa * pow(1.0-k*x[i]/alfa, 1.0/k-1.0);
	else
	  f=1/alfa * exp(-x[i]/alfa);

	if(f>0.0)
	  ret+=log(f);
	else
	  {
	    ret-=1e+6;
	    return ret;
	  }
      }

  return ret;
}

/* MCMC stuff */
void init_pareto(int numpar, double *par, int, double * /*hyperpar*/)
{
  par[0]=gauss();
  par[1]=exp(0.3*gauss());
  
  if(numpar>2) // extra parameters?
    init_extra(par+2, numpar-2);
}

double qdiff_pareto(double p, double p_ref, double logsigma, double ksi)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    {
      if(ksi==0.0)
	ret=-sigma*log(1.0-p)+sigma*log(1.0-p_ref);
      else
	ret=sigma/ksi*(pow(1.0-p,-ksi)-1.0)-
	  sigma/ksi*(pow(1.0-p_ref,-ksi)-1.0);
    }
  else
    {
      if(ksi==0.0)
	ret=-sigma*log(1.0-p);
      else
	ret=sigma/ksi*(pow(1.0-p,-ksi)-1.0);
    }
  
  return ret;
}

double qratio_pareto(double p, double p_ref, double logsigma, double ksi)
{
  double ret;
  double sigma=exp(logsigma);
  
  if(p_ref>0.0 && p_ref<1.0)
    {
      if(ksi==0.0)
	ret=(-sigma*log(1.0-p))/(-sigma*log(1.0-p_ref));
      else
	ret=(sigma/ksi*(pow(1.0-p,-ksi)-1.0)) /
	  (sigma/ksi*(pow(1.0-p_ref,-ksi)-1.0));
    }
  else
    {
      if(ksi==0.0)
	ret=-sigma*log(1.0-p);
      else
	ret=sigma/ksi*(pow(1.0-p,-ksi)-1.0);
    }
  
  return ret;
}

double logprior_pareto(int numparams, 
		       double *par,
		       int /* num_hyperparameters */,
		       double */*hyperpar*/)
{
  double logsigma=par[0];
  double ksi=par[1];
  
  double p1=dist_p1, p2=dist_p2;
  double **theta_der=make_matrix(2,2);
  double dx=0.0001;
  
  double q1_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_pareto(p1,MISSING_VALUE,logsigma,ksi) : 
    qratio_pareto(p1,MISSING_VALUE,logsigma,ksi);
  double q2_curr=!has_ratio_based_higher_order_quantile_prior ?
    qdiff_pareto(p2,p1,logsigma,ksi) : 
    qratio_pareto(p2,p1,logsigma,ksi);
  
  if(q1_curr<=0.0)
    return -1e+200;
  if(q2_curr<=0.0)
    return -1e+200;
  
  if(!has_ratio_based_higher_order_quantile_prior)
    {
      theta_der[0][0]=(q1_curr-qdiff_pareto(p1,MISSING_VALUE,
					    logsigma-dx,ksi))/dx;
      theta_der[0][1]=(q1_curr-qdiff_pareto(p1,MISSING_VALUE,
					    logsigma,ksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qdiff_pareto(p2,p1,logsigma-dx,ksi))/dx;
      theta_der[1][1]=(q2_curr-qdiff_pareto(p2,p1,logsigma,ksi-dx))/dx;
    }
  else
    {
      theta_der[0][0]=(q1_curr-qratio_pareto(p1,MISSING_VALUE,
					    logsigma-dx,ksi))/dx;
      theta_der[0][1]=(q1_curr-qratio_pareto(p1,MISSING_VALUE,
					    logsigma,ksi-dx))/dx;
      theta_der[1][0]=(q2_curr-qratio_pareto(p2,p1,logsigma-dx,ksi))/dx;
      theta_der[1][1]=(q2_curr-qratio_pareto(p2,p1,logsigma,ksi-dx))/dx;
    }

  // Calculate transformation term:
  double logdet=determinant_matrix(theta_der, 2, 1);
  doubledelete(theta_der,2);
  
  if(!(logdet> -1e+200 && logdet<1e+200))
    return -1e+200;
  
  double ret=logdet;
  
  ret+=-0.5*log(2.0*M_PI)-log(logq1_sd)-log(q1_curr)-
    0.5*(log(q1_curr)-logq1_mu)*(log(q1_curr)-logq1_mu)/logq1_sd/logq1_sd;
  ret+=-0.5*log(2.0*M_PI)-log(logq2_sd)-log(q2_curr)-
    0.5*(log(q2_curr)-logq2_mu)*(log(q2_curr)-logq2_mu)/logq2_sd/logq2_sd;
  
  if(numparams>2) // extra parameters?
    {
      double extra=logprior_extra(par+2, numparams-2);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_pareto(double x, int /*numparams*/, double *par)
{
  double logsigma=par[0], sigma=exp(logsigma);
  double ksi=par[1];

  if(x<=0.0 || (ksi<0.0 && x>-sigma/ksi))
    return -1e+200;
  
  double ret;
  if(ksi==0.0)
    ret = -x/sigma - log(sigma);
  else 
    ret = -logsigma + (-1.0/ksi-1.0)*log(1.0+ksi*x/sigma);

  return ret;
}

double log_F_pareto(double x, int /*numparams*/, double *par)
{
  double logsigma=par[0], sigma=exp(logsigma);
  double ksi=par[1];

  if(x<=0.0)
    return -1e+200;
  
  if(ksi<0.0 && x>-sigma/ksi)
    return 0.0;
  
  double ret;
  
  if(ksi!=0.0)
    ret = log(1.0 - pow(1.0+ksi*x/sigma, -1.0/ksi));
  else
    ret=log(1.0 - exp(-x/sigma));
  
  return ret;
}

double loglik_pareto(double **data, 
		     int numrows, 
		     int /* numcolumns */,
		     int numparams, 
		     double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_pareto, log_F_pareto, 2);
  
  return ret;
}


int planck_likelihood_n;
double *planck_likelihood_X;
double planck_likelihood(double *arg)
{
  int n=planck_likelihood_n;
  double N=arg[0];
  double temp=arg[1];
  double lambda0=arg[2];
  double ret=0.0;
  double *x=planck_likelihood_X;

  for(int i=0;i<n;i++)
    if(x[i]!=MISSING_VALUE)
      {
	double f;
	
	if(x[i]<=lambda0 || temp<0.0)
	  f=0.0;
	else
	  f=1/(exp(lgamma(N+1.0))*riemann_zeta(N+1.0)*
	       pow(temp, N+1.0)*pow(x[i]-lambda0, N+2.0)*
	       (exp(1.0/((x[i]-lambda0)*temp))-1.0));

	if(f>0.0)
	  ret+=log(f);
	else
	  ret-=1000.0;
      }

  return ret;
} 


/* MCMC stuff */
void init_planck(int numpar, double *par, int, double *hyperpar)
{
  double lambda0_mu=hyperpar[0];
  double lambda0_sd=hyperpar[1];
  double logtemp_mu=hyperpar[2];
  double logtemp_sd=hyperpar[3];
  double logn_mu=hyperpar[4];
  double logn_sd=hyperpar[5];
  
  par[0]=lambda0_mu+lambda0_sd*gauss();
  par[1]=logtemp_mu+logtemp_sd*gauss();
  par[2]=logn_mu+logn_sd*gauss();
  
  if(numpar>3) // extra parameters?
    init_extra(par+3, numpar-3);
}

double logprior_planck(int numparams, 
		       double *par,
		       int /* num_hyperparameters */,
		       double *hyperpar)
{
  double lambda0_mu=hyperpar[0];
  double lambda0_sd=hyperpar[1];
  double logtemp_mu=hyperpar[2];
  double logtemp_sd=hyperpar[3];
  double logn_mu=hyperpar[4];
  double logn_sd=hyperpar[5];
  
  double lambda0=par[0];
  double logtemp=par[1];
  double logn=par[2];
  
  double ret=-0.5*log(2.0*M_PI)-log(lambda0_sd)-
    0.5*(lambda0-lambda0_mu)*(lambda0-lambda0_mu)/lambda0_sd/lambda0_sd;
  ret+= -0.5*log(2.0*M_PI)-log(logtemp_sd)-
    0.5*(logtemp-logtemp_mu)*(logtemp-logtemp_mu)/logtemp_sd/logtemp_sd;
  ret+= -0.5*log(2.0*M_PI)-log(logn_sd)-
    0.5*(logn-logn_mu)*(logn-logn_mu)/logn_sd/logn_sd;
  
  if(numparams>3) // extra parameters?
    {
      double extra=logprior_extra(par+3, numparams-3);
      if(extra<=-1e+200)
	return -1e+200;
      ret += extra;
    }

  return ret;
}

double log_f_planck(double x, int /*numparams*/, double *par)
{
  double lambda0=par[0];
  double logtemp=par[1], temp=exp(logtemp);
  double logn=par[2], n=exp(logn);

  if(x<=lambda0)
    return -1e+200;
  
  double ret=-(lgamma(n+1.0)+log(riemann_zeta(n+1.0))+
	       (n+1.0)*log(temp)+(n+2.0)*log(x-lambda0)+
	       log(exp(1.0/((x-lambda0)*temp))-1.0));

  return ret;
}

double log_F_planck(double x, int /*numparams*/, double *par)
{
  double lambda0=par[0];
  //double logtemp=par[1], temp=exp(logtemp);
  //double logn=par[2], n=exp(logn);

  if(x<=lambda0)
    return -1e+200;
  
  double ret=0.0; // unknown!

  return ret;
}


double loglik_planck(double **data, 
		     int numrows, 
		     int /* numcolumns */,
		     int numparams, 
		     double *par)
{
  double ret=loglik_general(data[0],numrows,numparams,par,
			    log_f_planck, log_F_planck, 3);
  
  return ret;
}



// ************************************************************* //
//                                                               //   
//               DISTRIBUTION                                    //
//                                                               // 
// The super-class representing a generic distribution           //
//                                                               // 
// ************************************************************* //  


double distribution::pi=3.141592327;
bool distribution::randomization_done=false;

#ifdef GSL
gsl_rng *distribution::gslptr=NULL;
#endif //GSL

//             FUNCTION
// Should return the probability function value for a given
// argument for the subclasses;
double distribution::function(double)
{
  return 0.0;
}

// Copy threshold and historcial info to global strings, 
// copy estimate meta info to distribution object and
// return an array of strings describing the total set of
// parameter names given the standard parameter names from
// the distribution ("names") plus historical estimates. 
char **distribution::set_hist_info_and_names(int num_thresholds, 
					     historic_threshold *threshold,
					     int num_historical_data,
					     historic_extreme_data *histdata,
					     char **names, 
					     int num_param, 
					     int *num_extra, 
					     int *num_param_extra)
{
  int i,numextra=0;
  char **extra_names=NULL;

  // Remove pervious mcmc estimates (if any):
  if(mcmc_estimate_mu)
    delete [] mcmc_estimate_mu;
  mcmc_estimate_mu=NULL;
  if(mcmc_estimate_sd)
    delete [] mcmc_estimate_sd;
  mcmc_estimate_sd=NULL;
  if(mcmc_estimate_lower)
    delete [] mcmc_estimate_lower;
  mcmc_estimate_lower=NULL;
  if(mcmc_estimate_upper)
    delete [] mcmc_estimate_upper;
  mcmc_estimate_upper=NULL;
  doubledelete(mcmc_estimated,num_hist_estimated);
  mcmc_estimated=NULL;

  num_logprob_thresholds=num_thresholds;
  logprob_threshold=new historic_threshold[num_thresholds];
  for(i=0;i<num_thresholds;i++)
    logprob_threshold[i]=threshold[i];
  
  // Sort thresholds from lower to upper
  // (In addition, there's a zeroth threshold=0 for systematic data).
  qsort(logprob_threshold, size_t(num_thresholds),
	sizeof(historic_threshold), compare_historic_threshold_values);
  
  if(num_historical_data>0)
    {
      num_logprob_hist=num_historical_data;
      logprob_hist=new historic_extreme_data[num_historical_data];

      for(i=0;i<num_historical_data;i++)
	{
	  logprob_hist[i]=histdata[i];

	  if(histdata[i].lower_limit!=MISSING_VALUE || 
	     histdata[i].upper_limit!=MISSING_VALUE)
	    numextra++;
	}
      
      if(numextra>0)
	{
	  extra_names=new char*[numextra];
	  int j=0;
	  for(i=0;i<num_historical_data;i++)
	    {
	      if(histdata[i].lower_limit!=MISSING_VALUE || 
		 histdata[i].upper_limit!=MISSING_VALUE)
		{
		  extra_names[j]=new char[100];
		  int k=0;
		  // find threshold it belongs to:
		  for(k=0;k<num_logprob_thresholds;k++)
		    if(histdata[i].year>=threshold[k].start_year &&
		       histdata[i].year<=threshold[k].end_year)
		      break;
		  if(k<num_logprob_thresholds)
		    sprintf(extra_names[j], "hist_%04d", 
			    histdata[i].year); 
		  else
		    sprintf(extra_names[j], "sys_%04d", 
			    histdata[i].year);
		  j++;
		}
	    }
	  
	  // Fill out meta info for estimated values:
	  num_hist_estimated=numextra;
	  hist_names=new char*[numextra];
	  estimate_year=new int[numextra];
	  threshold_value=new double[numextra];
	  for(i=0;i<numextra;i++)
	    {
	      hist_names[i]=new char[100];
	      strcpy(hist_names[i], extra_names[i]);
	    }
	  
	  j=0;
	  for(i=0;i<num_historical_data;i++)
	    {
	      if(histdata[i].lower_limit!=MISSING_VALUE || 
		 histdata[i].upper_limit!=MISSING_VALUE)
		{
		  estimate_year[j]=histdata[i].year;
		  
		  int k=0;
		  // find threshold it belongs to:
		  for(k=0;k<num_logprob_thresholds;k++)
		    if(histdata[i].year>=threshold[k].start_year &&
		       histdata[i].year<=threshold[k].end_year)
		      break;
		  if(k>=num_logprob_thresholds)
		    {
		      threshold_value[j]=0.0;
		      if(!histdata[i].systematic_camuflaged_as_historic)
			printf("Error: historical data for year %d outside "
			       "threshold definitions!\n", histdata[i].year);
		    }
		  else
		    threshold_value[j]=threshold[k].threshold_value;
		  
		  j++;
		}
	    }			     
	}
    }

  if(num_extra)
    *num_extra=numextra;

  if(num_param_extra)
    *num_param_extra=num_param+numextra;

  char **ret=new char*[num_param+numextra];
  
  for(i=0;i<num_param;i++)
    {
      ret[i]=new char[100];
      strcpy(ret[i], names[i]);
    }
  for(i=0;i<numextra;i++)
    {
      ret[i+num_param]=new char[100];
      strcpy(ret[i+num_param], extra_names[i]);
    }
  
  doubledelete(extra_names,numextra);

  return ret;
}

void distribution::store_historical_mcmc_estimates(double **pars, 
						   int num_mcmc,
						   int numparam,
						   bool show_plots)
{
  mcmc_estimate_mu=new double[num_hist_estimated];
  mcmc_estimate_sd=new double[num_hist_estimated];
  mcmc_estimate_lower=new double[num_hist_estimated];
  mcmc_estimate_upper=new double[num_hist_estimated];
  mcmc_estimated=new double*[num_hist_estimated];
  for(int i=0;i<num_hist_estimated;i++)
    {
      mcmc_estimated[i]=new double[num_mcmc];
      for(int j=0;j<num_mcmc;j++)
	mcmc_estimated[i][j]=pars[j][i+numparam];
      
      mcmc_estimate_mu[i]=
	find_statistics(mcmc_estimated[i],num_mcmc,MEAN);
      mcmc_estimate_sd[i]=
	find_statistics(mcmc_estimated[i],num_mcmc,
			STANDARD_DEVIATION);
      mcmc_estimate_lower[i]=
	find_statistics(mcmc_estimated[i],num_mcmc,PERCENTILE_2_5);
      mcmc_estimate_upper[i]=
	find_statistics(mcmc_estimated[i],num_mcmc,
			PERCENTILE_97_5);

      if(show_plots)
	show_mcmc_parameter(mcmc_estimated[i], 
			    num_mcmc, hist_names[i]);
    }
}


//            ACCUMULATE
// Finds the accumulated probability function and puts it
// in 'distrib_val';
void distribution::accumulate(void)
{
  accumulated=true;

  if(accumulated_function_exists) // no need to do numerical integration...
    {
      functional_accumulation();
      return;
    }

  register int i;
  double x,min=MINIM(minval-9.0*sdev, mean-10.0*sdev), sum_min=0.0;

  if(status != DISTRIBUTION_FOUND)
    return;

  // Traverse from 'min' (representing 'minus infinity') to
  // the smallest value in the serie, finding the accumulated 
  // probability for this value;
  for(x=min; x<minval; x+=step)
    sum_min += function(x) * step;

  // Find the step length;
  step = (maxval - minval) / (((double) (distrib_len-1)));
  // Traverse the distribution and multiply each value with the step length;
  for(i=0; i<distrib_len; i++)
    distrib_val[i] *= step;

  // Set the first value to the probability for finding the smallest value;
  distrib_val[0] = sum_min;
  // Find the rest of the accumulated probabilities;
  for(i=1; i<distrib_len; i++)
    distrib_val[i] += distrib_val[i-1];
}



//              FLOAT_TO_DOUBLE
// transforms a float array to a double array;
double *distribution::float_to_double(float *in_array, int in_len)
{
  double *out=new double[in_len];
  for(register int i=0; i<in_len; i++)
    out[i] = (double) in_array[i];

  return out;
}


//               DOUBLE_TO_FLOAT
// transforms a double array to a float array;
float *distribution::double_to_float(double *in_array, int in_len, 
				     bool inverse_sort)
{
  float *out=new float[in_len];
  for(register int i=0; i<in_len; i++)
    if(!inverse_sort)
      out[i] = (float) in_array[i];
    else
      out[in_len-1-i] = (float) in_array[i];

  return out;
}

//               DOUBLE_TO_FLOAT
// transforms a double array to a double array;
double *distribution::double_to_double(double *in_array, int in_len, 
				       bool inverse_sort)
{
  double *out=new double[in_len];
  for(register int i=0; i<in_len; i++)
    if(!inverse_sort)
      out[i] = in_array[i];
    else
      out[in_len-1-i] = in_array[i];

  return out;
}



//          CLEANUP
// cleanup...
void distribution::cleanup(void)
{
  if(distrib_arg)
    delete [] distrib_arg;
  distrib_arg=NULL;

  if(distrib_val)
    delete [] distrib_val;
  distrib_val=NULL;
  
  distrib_len=0;

  if(origval)
    delete [] origval;
  origval=NULL;
  origlen=0;

  minval=1e+30;
  maxval=-1e+30;
  status=DISTRIBUTION_NOT_FETCHED;
}



//        CONSTRUCTOR
// empty constructor
distribution::distribution()
{
  minval=1e+30;
  maxval=-1e+30;
  numparam=0;
  num_mcmc=burnin=spacing=num_temp=0;
  parnames=NULL;
  parstatus=NULL;
  param_prior_mu=param_prior_sd=param_prior_p=NULL;
  doshowmcmc=doshowdebug=false;
  allow_neg=true;
  ratio_based_higher_order_quantile_prior=false;

  if(!randomization_done)
    {
      time_t t;
      randomization_done=true;

#ifdef GSL      
      gslptr=gsl_rng_alloc(gsl_rng_rand48);
      gsl_rng_set(gslptr, time(&t));
#endif //GSL
    }

  origlen=0;
  origval=NULL;
  accumulated=false;
  distrib_arg=NULL;
  distrib_val=NULL;
  distrib_len=0;
  status=DISTRIBUTION_NOT_FETCHED;
  accumulated_function_exists=false;
  est_met=EST_UNKNOWN;
  visited=false;
  bayesian_model_log_likelihood=bayesian_model_probability=MISSING_VALUE;
  strcpy(shortname,"???");

  num_hist_estimated=0;
  hist_names=NULL;
  mcmc_estimated=NULL; 
  mcmc_estimate_mu=NULL;
  mcmc_estimate_sd=NULL;
  mcmc_estimate_lower=NULL;
  mcmc_estimate_upper=NULL;
  estimate_year=NULL;
  threshold_value=NULL;
}

// empty constructor
distribution::distribution(char *short_name)
{
  strcpy(shortname, short_name);
  
  minval=1e+30;
  maxval=-1e+30;
  numparam=0;
  num_mcmc=burnin=spacing=num_temp=0;
  parnames=NULL;
  parstatus=NULL;
  param_prior_mu=param_prior_sd=param_prior_p=NULL;
  doshowmcmc=doshowdebug=false;
  allow_neg=true;
  ratio_based_higher_order_quantile_prior=false;
  
  if(!randomization_done)
    {
      time_t t;
      randomization_done=true;

#ifdef GSL      
      gslptr=gsl_rng_alloc(gsl_rng_rand48);
      gsl_rng_set(gslptr, time(&t));
#endif //GSL
    }

  origlen=0;
  origval=NULL;
  accumulated=false;
  distrib_arg=NULL;
  distrib_val=NULL;
  distrib_len=0;
  status=DISTRIBUTION_NOT_FETCHED;
  accumulated_function_exists=false;
  est_met=EST_UNKNOWN;
  visited=false;
  bayesian_model_log_likelihood=bayesian_model_probability=MISSING_VALUE;

  num_hist_estimated=0;
  hist_names=NULL;
  mcmc_estimated=NULL; 
  mcmc_estimate_mu=NULL;
  mcmc_estimate_sd=NULL;
  mcmc_estimate_lower=NULL;
  mcmc_estimate_upper=NULL;
  estimate_year=NULL;
  threshold_value=NULL;
}



//        CONSTRUCTOR
// Makes an object and puts a times serie into it, using the Set-method;
distribution::distribution(double *val, int len, double min, double max, 
			   int num_in_distrib, bool do_accumulate, 
			   ESTIMATION_METHOD use_est_met)
{
  origlen=0;
  origval=NULL;
  distrib_arg=NULL;
  distrib_val=NULL;
  numparam=0;
  bayesian_model_log_likelihood=bayesian_model_probability=MISSING_VALUE;
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met);
  strcpy(shortname,"???");

  num_hist_estimated=0;
  hist_names=NULL;
  mcmc_estimated=NULL; 
  mcmc_estimate_mu=NULL;
  mcmc_estimate_sd=NULL;
  mcmc_estimate_lower=NULL;
  mcmc_estimate_upper=NULL;
  estimate_year=NULL;
  threshold_value=NULL;
  ratio_based_higher_order_quantile_prior=false;
}



//        CONSTRUCTOR
// Makes an object and puts a times serie into it, using the Set-method;
distribution::distribution(float *val, int len, float min, float max, 
			   int num_in_distrib, bool do_accumulate, 
			   ESTIMATION_METHOD use_est_met)
{
  origlen=0;
  origval=NULL;
  distrib_arg=NULL;
  distrib_val=NULL;
  numparam=0;
  bayesian_model_log_likelihood=bayesian_model_probability=MISSING_VALUE;
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met);
  strcpy(shortname,"???");

  num_hist_estimated=0;
  hist_names=NULL;
  mcmc_estimated=NULL; 
  mcmc_estimate_mu=NULL;
  mcmc_estimate_sd=NULL;
  mcmc_estimate_lower=NULL;
  mcmc_estimate_upper=NULL;
  estimate_year=NULL;
  threshold_value=NULL;
  ratio_based_higher_order_quantile_prior=false;
}



//        DESTRUCTOR
distribution::~distribution()
{
  cleanup();
}



//             SET
// This method should plug the given dataset into this moduke
// and find the corresponding distribution;
void distribution::Set(double *, int, 
		       double, double, int, 
		       bool, ESTIMATION_METHOD)
{
  // virtual method, do nothing
  status=DISTRIBUTION_NOT_FETCHED;
}



//             SET
// This method calls the corresponding Set-method with double-arrays...
void distribution::Set(float *val, int len, 
		       float min, float max, int num_in_distrib, 
		       bool do_accumulate, 
		       ESTIMATION_METHOD use_est_met)
{
  double *dval = float_to_double(val, len);
  double dmin = (double) min, dmax = (double) max;
  
  Set(dval, len, dmin, dmax, num_in_distrib, do_accumulate,use_est_met);
}


//          PRINTHELP
// This method should send long a description of the distribution to
// the given output stream;
void distribution::printhelp(std::ostream& /* out */)
{
  // virtual method, do nothing
}


//            DESCIPTION
// This method should give a short, one line description of the distribution 
// as a string;
char *distribution::description(void)
{
  // virtual method, do nothing
  return (char *) NULL;
}


//            DESCIPTION
// This method should give a shorter, one line description of the distribution 
// as a string;
char *distribution::short_description(void)
{
  // virtual method, do nothing
  return (char *) NULL;
}


//        SHOWQUANTILES
// This method should show an extreme value table for a distribution
void distribution::showquantiles(std::ostream &out, METHOD met,
				 double meanextreme, double scaletime,
				 int bootstrap_repetitions, 
				 bool resample, 
				 bool bootstrap_parameters)
{
  double timeintervals[8]={5,10,20,50,100,200,500,1000};
  register int i;

  if(bootstrap_repetitions)
    randify();

  out << std::endl;
  out << description() << std::endl;
  if(num_hist_estimated && hist_names && mcmc_estimate_mu &&
     mcmc_estimate_lower && mcmc_estimate_upper)
    {
      out << "Ekstremer estimert fra grenseverdier:" << std::endl;
      for(i=0;i<num_hist_estimated;i++)
	out << hist_names[i] << "=" << mcmc_estimate_mu[i] << 
	  " ( " << mcmc_estimate_lower[i] << " - " << 
	  mcmc_estimate_upper[i] << " )" << std::endl;
    }

  if(met==MIN)
    out << "Minimums-kvantiler:" << std::endl;
  else
    out << "Maksimums-kvantiler:" << std::endl;
  out << "--------------" << std::endl;
  out << "Gjentaks-     M�le-    ";
  if(meanextreme!=MISSING_VALUE)
    out << "    Relative";
  if(bootstrap_repetitions || (est_met==EST_BAYES && num_mcmc>0))
    out << "  �vre   Nedre ";
  out << std::endl;
  out << "intervall     verdier  ";
  if(meanextreme!=MISSING_VALUE)
    out << "    m�le-";
  if(bootstrap_repetitions || (est_met==EST_BAYES && num_mcmc>0))
    out << "    estimat estimat";
  out << std::endl;
  out << "  (�r)                 ";
  //out << "  (�r)   (i SI enhter) ";
  if(meanextreme!=MISSING_VALUE)
    out << "    verdier";
  if(bootstrap_repetitions || (est_met==EST_BAYES && num_mcmc>0))
    out << "                    ";
  out << std::endl;
  out << "---------------------------------------------"  << std::endl;
  out << std::endl;

  for(i=0;i<8;i++)
    {
      double upper, lower;
      double extremevalue=get_quantile(met==MIN ? true : false,
				       timeintervals[i], YEAR1, scaletime,
				       bootstrap_repetitions, &upper, &lower,
				       resample, bootstrap_parameters);
      double maxquantile=upper, minquantile=lower;
      char buffer[200];

      sprintf(buffer,"%4d      %7.2f      ", 
	      (int) timeintervals[i], extremevalue);
      if(meanextreme!=MISSING_VALUE)
	sprintf(buffer+strlen(buffer), "   %6.3f", extremevalue/meanextreme);
      if(bootstrap_repetitions || (est_met==EST_BAYES && num_mcmc>0))
	sprintf(buffer+strlen(buffer), " %7.2f  %7.2f", 
		minquantile, maxquantile);
      out << buffer << std::endl;
    }
}

 
//        GETQUANTILES
// This method should return the repreat value for a given repeat time
double distribution::get_quantile(bool minanalysis, 
				  double repeat_time, BASE_TIME btime, 
				  double scaletime, 
				  int bootstrap_repetitions,
				  double *upper, double *lower, 
				  bool resample, 
				  bool bootstrap_parameters)
{
  double F = minanalysis ? scaletime/(repeat_time*YEAR1/btime) :
    1.0-scaletime/(repeat_time*YEAR1/btime);
  
  use_orig_curve();
  if(F<=0.0 || F>=1.0)
    return MISSING_VALUE;
  
  double quantile=get_quantile(F);
  double origminval=minval, origmaxval=maxval;
  
  if(est_met==EST_BAYES && num_mcmc>0 && upper && lower)
    {
      *upper=mcmc_quantile_statistics(F, PERCENTILE_97_5);
      *lower=mcmc_quantile_statistics(F, PERCENTILE_2_5);
    }
  else if(bootstrap_repetitions>1 && upper && lower)
    {
      int j,k;
      double *extremes=new double[bootstrap_repetitions];
      double *invalues=new double[origlen];
      double *real_origval=new double[origlen];
      int orig_distrib_len=distrib_len;
      double *orig_distrib_val=new double[orig_distrib_len];
      double *orig_distrib_arg=new double[orig_distrib_len];

      for(j=0;j<orig_distrib_len;j++)
	{
	  orig_distrib_arg[j]=distrib_arg[j];
	  orig_distrib_val[j]=distrib_val[j];
	}

      for(j=0;j<origlen;j++)
	real_origval[j]=origval[j];
      
      for(k=0;k<bootstrap_repetitions;k++)
	{
	  double newextreme=MISSING_VALUE;

	  while(newextreme==MISSING_VALUE || 
		!(newextreme>-1e+100 && newextreme<1e+100))
	    {
	      use_orig_curve();
	      
	      if(resample && !(bootstrap_parameters && est_met==EST_ML))
		for(j=0;j<origlen;j++)
		  invalues[j]=origval[int(floor(drand48()*double(origlen)))];
	      else if(!(bootstrap_parameters && est_met==EST_ML))
		{
		  for(j=0;j<origlen;j++)
		    {
		      origval[j]=real_origval[j];
		      invalues[j]=MISSING_VALUE;
		    }
		  
		  for(j=0;j<origlen;j++)
		    while(invalues[j]==MISSING_VALUE ||
			  !(invalues[j]>distrib_arg[0] && 
			    invalues[j]<distrib_arg[distrib_len-1]))
		      invalues[j]=get_quantile(drand48());
		}
	      else
		{
		  repick_parameters();
		  
		  for(j=0;j<origlen;j++)
		    distrib_val[j]=function(distrib_arg[j]);
		  
		  accumulated=false;
		  accumulate();
		}
	      
	      if(!(bootstrap_parameters && est_met==EST_ML))
		{
		  for(j=0;j<origlen;j++)
		    invalues[j] += get_zero_point();

		  accumulated=false;
		  Set(invalues, origlen, origminval, origmaxval, 
		      distrib_len, true, est_met);
		}

	      newextreme=get_quantile(F);

	      maxval=origmaxval;
	      minval=origminval;

	      for(j=0;j<origlen;j++)
		{
		  origval[j]=real_origval[j];
		  //distrib_val[j]=real_origval[j];
		}

	      // copy original distribution values back;
	      distrib_len=orig_distrib_len;
	      delete [] distrib_arg;
	      delete [] distrib_val;
	      distrib_val=new double[distrib_len];
	      distrib_arg=new double[distrib_len];
	      for(j=0;j<orig_distrib_len;j++)
		{
		  distrib_arg[j]=orig_distrib_arg[j];
		  distrib_val[j]=orig_distrib_val[j];
		}
	    }

	  extremes[k]=newextreme;
	}
    
      
      qsort(extremes, size_t(bootstrap_repetitions), sizeof(double),
	    compare_double);
      
      *upper=extremes[int(0.95*double(bootstrap_repetitions))];
      *lower=extremes[int(0.05*double(bootstrap_repetitions))];
      
     
      std::cout << repeat_time << " " << quantile << " " << 
	*upper << " " << *lower << " " << minval << " " << maxval <<  std::endl;
      std::cout << description() << std::endl << std::endl;
      
      int bufflen=origlen;
      double *buffer=new double[bufflen];
      for(int i=0;i<bufflen;i++)
	buffer[i]=origval[i];

      Set(buffer, bufflen, origminval, origmaxval, distrib_len, accumulated,
	  est_met);
      delete [] buffer;
      maxval=origmaxval;
      minval=origminval;
      for(j=0;j<origlen;j++)
	origval[j]=real_origval[j];
      
      // copy original distribution values back;
      distrib_len=orig_distrib_len;
      delete [] distrib_arg;
      delete [] distrib_val;
      distrib_val=new double[distrib_len];
      distrib_arg=new double[distrib_len];
      for(j=0;j<orig_distrib_len;j++)
	{
	  distrib_arg[j]=orig_distrib_arg[j];
	  distrib_val[j]=orig_distrib_val[j];
	}

      delete [] invalues;
      delete [] real_origval;
      delete [] orig_distrib_arg;
      delete [] orig_distrib_val;
      delete [] extremes;
    }
  
  return quantile;
}

double *distribution::mcmc_get_quantile(double prob)
{
  if(num_mcmc<=0)
    return NULL;

  double *val=new double[num_mcmc];
  int i;

  for(i=0;i<num_mcmc;i++)
    val[i]=mcmc_get_quantile_sample(prob, i);

  return val;
}

double distribution::mcmc_quantile_statistics(double prob, METHOD met)
{
  double *val=mcmc_get_quantile(prob);
  double ret=find_statistics(val,num_mcmc,met);

  delete [] val;
  
  return ret;
}

ESTIMATION_METHOD distribution::get_estimation_method(void)
{
  return est_met;
}

// Get number of MCMC samples (if Bayesian estimation)
int distribution::get_num_mcmc(void)
{
  return num_mcmc;
}

double distribution::mcmc_function_sample(double /*x*/, int /*sample_index*/)
{
  return MISSING_VALUE;
}

double distribution::mcmc_accumulated_function_sample(double /*x*/, 
						      int /*sample_index*/)
{
  return MISSING_VALUE;
}

double distribution::mcmc_get_quantile_sample(double /*prob*/, 
					      int /*sample_index*/)
{
  return MISSING_VALUE;
}
  
void distribution::use_orig_curve(void)
{
}

void distribution::repick_parameters(void)
{
}

// Return the zero-point, only used for the pareto distribution;
double distribution::get_zero_point(void)
{
  return 0.0;
}

double distribution::get_quantile(double accumulated_prob)
{
  double err=1e-10, currerr=1.0, x=MISSING_VALUE, prev_x=x;
  int i, numiter=200;
  
  if(!accumulated)
    accumulate();
  
  for(i=1;i<distrib_len;i++)
    if(distrib_val[i-1]<=accumulated_prob && accumulated_prob<=distrib_val[i])
      {
	x = distrib_arg[i-1] + (distrib_arg[i]-distrib_arg[i-1]) * 
	  (accumulated_prob-distrib_val[i-1]) / 
	  (distrib_val[i]-distrib_val[i-1]);
	break;
      }
  
  if(!accumulated_function_exists)
    return x;
  else
    prev_x=x;
  
  if(x==MISSING_VALUE)
    x=distrib_arg[distrib_len-1];
  
  i=0;
  // Use newtons method to solve F(x)=accumulated_prob
  while(i<numiter && currerr>err)
    {
      double accf=accumulated_function(x), func=function(x); 
      // double dF=(accf2-accf)/0.0001;

      if(func==0.0)
	return x;

      x = x - (accf-accumulated_prob)/func;

      currerr = ABSVAL(accumulated_function(x)-accumulated_prob);
      i++;
    }

  if(ABSVAL((currerr))>0.001)
    x=prev_x;

  return x;
}

//             FORMULA_PICTRUE_PATH
// This method should return the file name of a picture describing the 
// distribution;
char *distribution::formula_picture_path(void)
{
  // virtual method, do nothing
  return (char *) NULL;
}



//             GET_STATUS
// Returns wether finding the distribution was a success;
DISTRIBUTION_STATUS distribution::get_status(void)
{
  return status;
}


//             GET_DISTRIBUTION_ARGUMENT
// Returns the argument part of the probability distribution
// as a 'double' array;
double *distribution::get_distribution_argument(bool inverse_sort)
{
  return double_to_double(distrib_arg, distrib_len, inverse_sort);
}


//             GET_DISTRIBUTION_VALUE
// Returns the value part of the probability distribution
// as a 'double' array;
double *distribution::get_distribution_value(bool inverse_sort)
{
  return double_to_double(distrib_val, distrib_len, inverse_sort);
}


//             FGET_DISTRIBUTION_ARGUMENT
// Returns the argument part of the probability distribution
// as a 'float' array;
float *distribution::fget_distribution_argument(bool inverse_sort)
{
  float *fbuffer = double_to_float(distrib_arg, distrib_len, inverse_sort);
  return fbuffer;
}


//             FGET_DISTRIBUTION_VALUE
// Returns the value part of the probability distribution
// as a 'float' array;
float *distribution::fget_distribution_value(bool inverse_sort)
{
  float *fbuffer = double_to_float(distrib_val, distrib_len, inverse_sort);
  return fbuffer;
}


//             GET_DISTRIBUTION_LENGTH
//  Returns the length of the arrays;
int distribution::get_distribution_length(void)
{
  return distrib_len;
}


//             SET_MIN_AND_MAX
// Set the min and max value;
void distribution::set_min_and_max(double min, double max, int num_in_distrib)
{
  if(distrib_arg)
    delete [] distrib_arg;
  distrib_arg=NULL;
  if(distrib_val)
    delete [] distrib_val;
  distrib_val=NULL;

  minval = min; // set minimal value
  maxval = max; // set maximal value

  if(minval<0.0)
    minval*=1.001;
  else
    minval*=0.999;

  if(maxval<0.0)
    maxval*=0.999;
  else
    maxval*=1.001;

  distrib_len = num_in_distrib; // set the distribution array length
  // find the step length;
  step = (max-min) / ((double) num_in_distrib-1);

  // make the distribution arrays;
  distrib_arg=new double[distrib_len];
  distrib_val=new double[distrib_len];
}


//             SET_MIN_AND_MAX
// Set the min and max value;
void distribution::set_min_and_max(float min, float max, int num_in_distrib)
{
  double dmin=(double) min;
  double dmax=(double) max;
  
  set_min_and_max(dmin, dmax, num_in_distrib);
}


//             GET_STATS
// Returns statistical data about the distribution;
void distribution::get_stats(double *val, int len)
{
  double sum=0.0, var=0.0, logsum = 0.0, logvar = 0.0;
  register int i,j;
  truelen=0;
 
  if(origval)
    delete [] origval;
  origval=new double[len];
  for(i=0;i<len;i++)
    origval[i]=val[i];
  origlen=len;

  logstatus=DISTRIBUTION_FOUND;
  // traverse the dataset, finding the sum value...
  for(i=0; i<len; i++)
    if(val[i]!=MISSING_VALUE)
      {
	sum += val[i];
	truelen++; // increment the true length of the dataset
	// (length without missing values).
	
	// if a value is below or equal zero, we'll indicate that
	// logarithms are impossible
	if(val[i] <= 0.0)
	  logstatus = DISTRIBUTION_IMPOSSIBLE;
      }
    
  
  if(truelen<=0) // if no values were found..
    {
      // notify this in the status parameter and return;
      logstatus = status = DISTRIBUTION_IMPOSSIBLE;
      return;
    }

  mean = sum / truelen; // find the mean value
  
  // find the sum of squares;
  for(i=0; i<len; i++)
    if(val[i]!=MISSING_VALUE)
      var += (val[i]-mean)*(val[i]-mean);

  var /= truelen; // find the variation
  sdev = sqrt(var); // find the standard deviation
  
  skew=0.0;
  // find the skew
  for(i=0; i<len; i++)
    if(val[i]!=MISSING_VALUE)
      skew += (val[i]-mean)*(val[i]-mean)*(val[i]-mean);
  skew /= truelen;
  skew /= sdev*sdev*sdev;

  ex_curtosis=0.0;
  // find the curtosis
  for(i=0; i<len; i++)
    if(val[i]!=MISSING_VALUE)
      ex_curtosis += (val[i]-mean)*(val[i]-mean)*(val[i]-mean)*(val[i]-mean);
  ex_curtosis /= truelen;
  ex_curtosis /= sdev*sdev*sdev*sdev; // curtosis
  ex_curtosis -= 3.0; // excess curtosis
  
  // if we can use logarithmic values...
  if(logstatus == DISTRIBUTION_FOUND)
    {
      // find the logarithmic sum;
      for(i=0; i<len; i++)
	if(val[i]!=MISSING_VALUE)
	  logsum += log(val[i]);
      
      // find the logarithmic mean;
      logmean = logsum / truelen;
      
      // find the logarithmic sum of squares;
      for(i=0; i<len; i++)
	if(val[i]!=MISSING_VALUE)
	  logvar += (log(val[i])-logmean)*(log(val[i])-logmean);
      
      logvar /= truelen; // find the logarithmic variation
      logsdev = sqrt(logvar); // find the logarithmic standard deviation
    }


  // get order statistics for l-moments;
  qsort(val, size_t(len), sizeof(double), compare_double);

  // Calculate the 'b0', 'b1', 'b2', 'k', 'ki' and 'alfa' parameters;
  a0=a1=a2=b0=b1=b2=0.0;
  double n=(double) truelen;

  j=1;
  for(i=0; i<len; i++)
    if(val[i]!=MISSING_VALUE)
      {
	double jj=(double)j;

	// update first 3 ordinary moments:
	a0 += val[i]/n; // == mean
	a1 += (n-jj)*val[i]/((n-1.0)*n);
	a2 += (n-jj)*(n-jj-1.0)*val[i]/((n-2.0)*(n-1.0)*n);

	// Update first 3 l-moments:
	b0 += val[i]/n; // == mean
	b1 += (jj-1.0)*val[i]/((n-1)*n);
	b2 += (jj-1.0)*(jj-2.0)*val[i]/((n-2.0)*(n-1.0)*n);
	
	j++;
      }
  
  status = DISTRIBUTION_FOUND; // indicate that a distribution 
  // could be found...
}



double distribution::accumulated_function(double arg)
{
  if(!accumulated)
    accumulate();

  for(register int i=1;i<distrib_len;i++)
    if(distrib_arg[i-1]<=arg && arg<=distrib_arg[i])
      return distrib_val[i-1] + (distrib_val[i] - distrib_val[i-1]) *
	(arg - distrib_arg[i-1]) / (distrib_arg[i] - distrib_arg[i-1]);
  
  return MISSING_VALUE;
}

void distribution::functional_accumulation(void)
{
  for(int i=0;i<distrib_len;i++)
    if(distrib_val[i]!=MISSING_VALUE)
      distrib_val[i]=accumulated_function(distrib_arg[i]);
}


//          GET_MEAN
// Returns the mean value of the input dataset 
double distribution::get_mean(void)
{
  return mean;
}

// return max value;
double distribution::get_max_value(void)
{
  return maxval;
}

//return min value;
double distribution::get_min_value(void)
{
  return minval;
}

//          GET_STANDARD_DEVIATION
// Returns the standard deviation of the input dataset 
double distribution::get_standard_deviation(void)
{
  return sdev;
}



// LOGLIK
// Calculate the log-likelihood using the estimated distribution:
double distribution::log_lik(double *val, int len)
{
  double loglik=0.0;
  for(int i=0;i<len;i++)
    if(val[i]!=MISSING_VALUE)
      loglik+=log(function(val[i]));
  return loglik;
}

// BIC
// Calculate the Bayesian Information Criterion
// (only makes sense for ML estimates)
double distribution::bic(double *val, int len)
{
  double maxloglik=log_lik(val,len);
  double k=(double) numparam;
  double n=(double) len;
  
  double ret = -2.0*maxloglik + k*log(n);
  
  return ret;
}

// GET_BAYESIAN_LOG_MODEL_LIKELIHOOD
// Bayesian model log-likelihood (when applicable):
double distribution::get_bayesian_log_model_likelihood(void)
{
  return bayesian_model_log_likelihood;
}

// GET_BAYESIAN_MODEL_PROBABILIT
// Bayesian model probability (when applicable):
double distribution::get_bayesian_model_probability(void)
{
  return bayesian_model_probability;
}

char *distribution::get_short_name(void)
{
  return shortname;
}

// Hyper-parameter info for Bayesian analysis:
char **distribution::get_parameter_names(void)
{
  return parnames;
}

double *distribution::get_param_prior_mu(void)
{
  return param_prior_mu;
}

double *distribution::get_param_prior_sd(void)
{
  return param_prior_sd;
}

double *distribution::get_param_prior_p(void)
{
  return param_prior_sd;
}

PARAM_PRIOR_STATUS *distribution::get_param_status(void)
{
  return parstatus;
}

int distribution::get_num_par_combi(void) // counts parameters that can
// be real-valued or positive, depending on whether the data can be
// positive twice
{
  return num_par_combi;
}




  // fetch MCMC info for historical data (only relevant for extreme value 
  // analysis on positively definite data) and meta info:
int distribution::num_historical_estimates(void)
{
  return num_hist_estimated;
}

char **distribution::historical_event_names(void)
{
  return hist_names;
}

char *distribution::historical_event_name(int event_number)
{
  if(!hist_names || event_number<0 || event_number>=num_hist_estimated)
    return NULL;
  
  return hist_names[event_number];
}

double **distribution::get_mcmc_historical_events_estimates(void)
{
  return mcmc_estimated;
}

double *distribution::get_mcmc_historical_event_estimate(int event_number)
{
  if(!mcmc_estimated || event_number<0 || event_number>=num_hist_estimated)
    return NULL;
  
  return mcmc_estimated[event_number];
}

double *distribution::get_historical_events_estimates_mu(void)
{
  return mcmc_estimate_mu;
}

double *distribution::get_historical_events_estimates_sd(void)
{
  return mcmc_estimate_sd;
}

double *distribution::get_historical_events_estimates_upper(void)
{
  return mcmc_estimate_lower;
}

double *distribution::get_historical_events_estimates_lower(void)
{
  return mcmc_estimate_upper;
}

double distribution::get_historical_event_estimate_mu(int event_number)
{
  if(!mcmc_estimate_mu || event_number<0 || event_number>=num_hist_estimated)
    return MISSING_VALUE;
  
  return mcmc_estimate_mu[event_number];
}

double distribution::get_historical_event_estimate_sd(int event_number)
{
  if(!mcmc_estimate_sd || event_number<0 || event_number>=num_hist_estimated)
    return MISSING_VALUE;
  
  return mcmc_estimate_sd[event_number];
}

double distribution::get_historical_event_estimate_lower(int event_number)
{
  if(!mcmc_estimate_lower || event_number<0 || event_number>=num_hist_estimated)
    return MISSING_VALUE;
  
  return mcmc_estimate_lower[event_number];
}

double distribution::get_historical_event_estimate_upper(int event_number)
{
  if(!mcmc_estimate_upper || event_number<0 || event_number>=num_hist_estimated)
    return MISSING_VALUE;
  
  return mcmc_estimate_upper[event_number];
}

int *distribution::get_historical_events_years(void)
{
  return estimate_year;
}

int distribution::get_historical_event_year(int event_number)
{
  if(!estimate_year || event_number<0 || event_number>=num_hist_estimated)
    return (int) MISSING_VALUE;
  
  return estimate_year[event_number];
}

double *distribution::get_historical_events_thresholds(void)
{
  return threshold_value;
}

double distribution::get_historical_event_threshold(int event_number)
{
  if(!threshold_value || event_number<0 || event_number>=num_hist_estimated)
    return MISSING_VALUE;
  
  return threshold_value[event_number];
}




// ************************************************************* //
//                                                               //   
//               GAUSS_DISTRIBUTION                              //
//                                                               // 
// A subclass of 'distribution' representing a Gauss             //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Gauss distribution based on a given dataset.
gauss_distribution::gauss_distribution(double *val, int len, 
				       double min, double max, 
				       int num_in_distrib, 
				       bool do_accumulate,  
				       ESTIMATION_METHOD use_est_met,
				       bool allow_negative,
				       double *bayes_param_prior_mu, 
				       double *bayes_param_prior_sd,
				       double *bayes_param_prior_p,
				       int num_samples_, int burnin_, 
				       int spacing_, int num_temp_,
				       bool do_show_mcmc, 
				       bool do_show_debug,
				       bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("gauss")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=allow_negative;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=allow_negative ? false : true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


gauss_distribution::gauss_distribution() : distribution("gauss")
{
  init();
  init_hyperparameters();
  allow_neg=true;
  numparam=2;
  accumulated_function_exists=true;
}

gauss_distribution::~gauss_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void gauss_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  
}

void gauss_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  
  init();
}

void gauss_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=3;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  
  param_prior_sd[0]=1000.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void gauss_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}


//             SET
// Finds a Gauss distribution based on a given dataset.
void gauss_distribution::Set(double *val, int len, 
			     double min, double max, int num_in_distrib, 
			     bool do_accumulate, 
			     ESTIMATION_METHOD use_est_met,
			     // Historical (upper) threshold data:
			     int num_thresholds, 
			     historic_threshold *thresholds,
			     // Historical data:
			     int num_historical, 
			     historic_extreme_data *histdata)
{
  register int i;
  
  // set the min and max values
  set_min_and_max(min, max, num_in_distrib);
  // get statistical values;
  get_stats(val, len);
  
  mu=mean;
  sigma=sdev;

  est_met=use_est_met;
  sdev_mu=sdev_sigma=MISSING_VALUE;

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      visited=true;
    }

  // no distribution could be found?
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"mu","logsigma"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd;
      

      int num_extra=0;
      char **gauss_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	gauss_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	gauss_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,gauss_param_names,T,0.15, 
			 0,NULL,
			 init_gauss,logprior_gauss,loglik_gauss,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_gauss,loglik_gauss);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	    }
	}

      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(gauss_param_names,curr_numpar,pars,num_mcmc);
    }

  
  // traverse the dataset;
  for(i=0; i< distrib_len; i++)
    {
      double x = min + ((double) i)*step; // find the argument
      distrib_arg[i] = x; // set this argument array element
      distrib_val[i] = function(x); // set the value element
    }
  
  if(do_accumulate) // if we're to accumulate the distribution...
    accumulate(); // accumulate the data...
}

//            FUNCTION
// Returns the value of the Gauss distribution for a given argument
double gauss_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=1.0/sqrt(2.0*M_PI)/mcmc_sigma[i]*
	  exp(-0.5*(x-mcmc_mu[i])*(x-mcmc_mu[i])/mcmc_sigma[i]/mcmc_sigma[i]);
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return (exp( - 0.5*(x-mu) * (x-mu) / (sigma*sigma)) / 
	    sqrt(2*pi)/sigma);
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gauss distribution 
// for a given argument
double gauss_distribution::accumulated_function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=gsl_cdf_ugaussian_P((x-mcmc_mu[i])/mcmc_sigma[i]);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return gsl_cdf_ugaussian_P((x-mu)/sigma);
}


double gauss_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    return distribution::get_quantile(prob);
  else
    return mu+sigma*gsl_cdf_ugaussian_Pinv(prob);
}


//          PRINTHELP
// Sends a description of the Gauss distribution to the output stream;
void gauss_distribution::printhelp(std::ostream &out)
{
  out << "Normalfordelingen, eller Gauss-fordelingen, er en meget vanlig" << std::endl;
  out << "fordeling av verdier. I tilfeller der "
    "verdispranget fra en dag til den neste er tilfeldig" << std::endl;
  out << "(s�kallt 'random walk') vil verdiene "
    "fordele seg som dette. " << std::endl;
  out << "Fordelingen avhenger av verdienes "
    "gjennomsnittsverdi og standardavvik." << std::endl;
  out << "Gjennomsnittsverdien forteller hvor fordelingen "
    "vil toppe seg, mens" << std::endl;
  out << "standardavviket forteller hvor skarp toppen er." << std::endl;
  out << "Momentmetode og ML-estimering gir samme resultater her." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (18/10-2012)" << std::endl;
}


//          DECRIPTION
// Returns a short string description of the Gauss distribution
char *gauss_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Normalfordeling (%s): f(x)=exp(-(x-mean)^2/(2 sdev^2))/"
	    "sqr(2 pi sdev^2)  mu=%-7.3g+-%-6.2g sdev=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma);
  else
    sprintf(newline, "Normalfordeling (%s): f(x) = "
	    "exp(-(x-mean)^2/(2 sdev^2))/sqr(2 pi sdev^2), "
	    "mean=%-7.3g sdev=%-7.3g", est_method_name[(int) est_met], 
	    mu, sigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//          SHORT_DECRIPTION
// Returns a shorter string description of the Gauss distribution
char *gauss_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Normalfordeling (%s):mu=%-7.3g+-%-6.2g "
	    "sd=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma);
  else
    sprintf(newline, "Normalfordeling (%s): mu=%-7.3g sd=%-7.3g", 
	    est_method_name[(int) est_met], 
	    mu, sigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//          FORMULA_PICTRUE_PATH
// Returns the location of a picture describing the Gauss distribution
char *gauss_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/gauss3.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("gauss3.xbm").c_str());
#endif // NVE
  return newline;
}



double gauss_distribution::get_mu(void)
{
  return mu;
}

double gauss_distribution::get_sigma(void)
{
  return sigma;
}

void gauss_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
}

// Returns the MCMC 'mu' value;
double *gauss_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *gauss_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}


  // Get samples quantiles:
double gauss_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return 1.0/sqrt(2.0*M_PI)/mcmc_sigma[i]*
    exp(-0.5*(x-mcmc_mu[i])*(x-mcmc_mu[i])/mcmc_sigma[i]/mcmc_sigma[i]);
}

double gauss_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return gsl_cdf_ugaussian_P((x-mcmc_mu[i])/mcmc_sigma[i]);
}

double gauss_distribution::mcmc_get_quantile_sample(double prob, 
						     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return mcmc_mu[i]+mcmc_sigma[i]*gsl_cdf_ugaussian_Pinv(prob);
}



// ************************************************************* //
//                                                               //   
//               LOG_NORMAL_DISTRIBUTION                         //
//                                                               // 
// A subclass of 'distribution' representing a log-normal        //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a log-normal distribution based on a given dataset.
log_normal_distribution::log_normal_distribution(double *val, int len, 
						 double min, double max, 
						 int num_in_distrib, 
						 bool do_accumulate, 
						 ESTIMATION_METHOD 
						 use_est_met,
						 double *bayes_param_prior_mu, 
						 double *bayes_param_prior_sd,
						 double *bayes_param_prior_p,
						 int num_samples_, 
						 int burnin_, 
						 int spacing_, int num_temp_,
						 bool do_show_mcmc, 
						 bool do_show_debug,
						 bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("lognorm")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=false;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];

  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


log_normal_distribution::log_normal_distribution() : distribution("lognorm")
{
  init();
  init_hyperparameters();
  allow_neg=false;
  numparam=2;
  accumulated_function_exists=true;
}

log_normal_distribution::~log_normal_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void log_normal_distribution::init(void)
{
  mcmc_lmu=NULL;
  mcmc_lsigma=NULL;
  
}

void log_normal_distribution::cleanup(void)
{
  if(mcmc_lmu)
    delete [] mcmc_lmu;
  if(mcmc_lsigma)
    delete [] mcmc_lsigma;
  init();
}

void log_normal_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=2;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"lmu");
  strcpy(parnames[1],"lsigma");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_REAL;
  parstatus[1]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void log_normal_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}

//                SET
// Finds a log-normal distribution based on a given dataset.
void log_normal_distribution::Set(double *val, int len, 
				  double min, double max, int num_in_distrib, 
				  bool do_accumulate, 
				  ESTIMATION_METHOD use_est_met,
				  // Historical (upper) threshold data:
				  int num_thresholds, 
				  historic_threshold *thresholds,
				  // Historical data:
				  int num_historical, 
				  historic_extreme_data *histdata)
{
  register int i;

  // set the min and max values
  set_min_and_max(min, max, num_in_distrib);
  // get statistical data;
  get_stats(val, len);
  
  lmu=logmean;
  lsigma=logsdev;
  
  sdev_lmu=sdev_lsigma=MISSING_VALUE;
  est_met=use_est_met;
  
  if(!visited)
    {
      orig_lmu=lmu;
      orig_lsigma=lsigma;
      visited=true;
    }

  // if no logarithmic statistical data could be found...
  if(logstatus != DISTRIBUTION_FOUND)
    // set the status to the status of the logarithmic values
    status = logstatus; 
  
  // if logarithmic values weren't found, we'll abort this attempte and return;
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;
  
  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"lmu","loglsigma"};
      // lmu_mu, lmu_sd, loglsigma_mu, loglsigma_sd;
      
      int num_extra=0;
      char **ln_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	ln_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,	   
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	ln_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,ln_param_names,T,0.15, 
			 0,NULL,
			 init_lognormal,logprior_lognormal,loglik_lognormal,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_lognormal,loglik_lognormal);
      
      if(pars)
	{
	  mcmc_lmu=new double[num_mcmc];
	  mcmc_lsigma=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_lmu[i]=pars[i][0];
	      mcmc_lsigma[i]=exp(pars[i][1]);
	    }
	}

      lmu=find_statistics(mcmc_lmu, num_mcmc, MEAN);
      lsigma=find_statistics(mcmc_lsigma, num_mcmc, MEAN);
      sdev_lmu=find_statistics(mcmc_lmu, num_mcmc, STANDARD_DEVIATION);
      sdev_lsigma=find_statistics(mcmc_lsigma, num_mcmc, STANDARD_DEVIATION);
      
      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(ln_param_names,curr_numpar,pars,num_mcmc);
    }
  
  // traverse the dataset;
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      distrib_arg[i] = x; // set the argument array element
      distrib_val[i] = function(x); // set the value array element
    }

  if(do_accumulate)
    accumulate();
}



//            FUNCTION
// Returns the value of the log-normal distribution for a given argument
double log_normal_distribution::function(double x)
{
  if(x<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_lmu && mcmc_lsigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=1.0/sqrt(2.0*M_PI)/mcmc_lsigma[i]/x*
	  exp(-0.5*(log(x)-mcmc_lmu[i])*(log(x)-mcmc_lmu[i])/
	      mcmc_lsigma[i]/mcmc_lsigma[i]);
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return (exp( -(log(x)-lmu) *(log(x)-lmu) / (2.0*lsigma*lsigma)) / 
	    sqrt(2*pi)/lsigma/x);
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gauss distribution 
// for a given argument
double log_normal_distribution::accumulated_function(double x)
{
  if(x<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_lmu && mcmc_lsigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=gsl_cdf_ugaussian_P((log(x)-mcmc_lmu[i])/mcmc_lsigma[i]);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return gsl_cdf_ugaussian_P((log(x)-lmu)/lsigma);
}


double log_normal_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_lmu && mcmc_lsigma)
    return distribution::get_quantile(prob);
  else
    return exp(lmu+lsigma*gsl_cdf_ugaussian_Pinv(prob));
}


//           PRINTHELP
// Sends a description of the log-normal distribution to the output stream;
void log_normal_distribution::printhelp(std::ostream &out)
{
  out << "Lognormalfordelingen brukes n�r man forventer "
    "av logaritmen av verdiene er normalfordelt" << std::endl;
  out << "(se beskrivelsen av normalfordelingen). "
    "Fordelingen avhenger" << std::endl;
  out << "av gjennomsnittet og standardavviket til "
    "logaritmen til verdiene." << std::endl;
  out << "Pga. dette kan man kune benytte seg av denne "
    "fordelingen n�r alle verdiene er positive." << std::endl;
  out << "Fordelingen kan fungere bra for vannf�ringer." << std::endl;
  out << "Metoden bruker 1. og 2. ordens momenter av de logaritmiske "
    "verdiene," << std::endl;
  out << "som blir det samme som � kj�re ML-analyse p� de logaritmiske "
    "verdiene." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (18/10-2012)" << std::endl;
}


//           DESCRIPTION
// Returns a short string description of the log-normal distribution
char *log_normal_distribution::description(void)
{
  char *newline= new char[1000];
  
  if(sdev_lmu!=MISSING_VALUE && sdev_lsigma!=MISSING_VALUE)
    sprintf(newline, "Lognormalfordeling (%s): "
	    "f(x)=exp(-(log(x)-lmu)^2/(2 lsigma^2))/x/"
	    "sqr(2 pi lsigma^2)  lmu=%-7.3g+-%-6.2g lsigma=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], 
	    lmu, sdev_lmu, lsigma, sdev_lsigma);
  else
    sprintf(newline, "Lognormalfordeling (%s): f(x) = "
	    "exp(-(log(x)-lmu)^2/(2 lsigma^2))/x/sqr(2 pi lsigma^2), "
	    "lmu=%-7.3g lsigma=%-7.3g", est_method_name[(int) est_met], 
	    lmu, lsigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"),
	    100.0*bayesian_model_probability);
  return newline;
}

//           DESCRIPTION
// Returns a shorter string description of the log-normal distribution
char *log_normal_distribution::short_description(void)
{
  char *newline= new char[1000];
  
  if(sdev_lmu!=MISSING_VALUE && sdev_lsigma!=MISSING_VALUE)
    sprintf(newline, "Lognormalfordeling (%s): lmu=%-7.3g+-%-6.2g "
	    "ls=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], 
	    lmu, sdev_lmu, lsigma, sdev_lsigma);
  else
    sprintf(newline, "Lognormalfordeling (%s): f(x) = "
	    "lmu=%-7.3g ls=%-7.3g", est_method_name[(int) est_met], 
	    lmu, lsigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//           FORMULA_PICTURE_PATH
// Returns the location of a picture describing the log-normal distribution
char *log_normal_distribution::formula_picture_path(void)
{  
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/loggauss.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("loggauss.xbm").c_str());
#endif // NVE
  return newline;
}


//           GET_LOGMEAN
// Returns the logarithmic mean value of the input dataset and 
  // the log-normal distribution
double log_normal_distribution::get_lmu(void)
{
  return lmu;
}


//          GET_LOGSTANDARD_DEVIATION
// Returns the logarithmic standard deviation of the input dataset and 
// the log-normal distribution
double log_normal_distribution::get_lsigma(void)
{
  return lsigma;
}

void log_normal_distribution::use_orig_curve(void)
{
  lmu=orig_lmu;
  lsigma=orig_lsigma;
}



// Returns the MCMC 'lmu' value;
double *log_normal_distribution::get_mcmc_lmu(void)
{
  return mcmc_lmu;
}

// Returns the MCMC 'lsigma' value;
double *log_normal_distribution::get_mcmc_lsigma(void)
{
  return mcmc_lsigma;
}


  // Get samples quantiles:
double log_normal_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_lmu || !mcmc_lsigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return 1.0/sqrt(2.0*M_PI)/mcmc_lsigma[i]/x*
    exp(-0.5*(log(x)-mcmc_lmu[i])*(log(x)-mcmc_lmu[i])/
	mcmc_lsigma[i]/mcmc_lsigma[i]);
}

double log_normal_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_lmu || !mcmc_lsigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return gsl_cdf_ugaussian_P((log(x)-mcmc_lmu[i])/mcmc_lsigma[i]);
}

double log_normal_distribution::mcmc_get_quantile_sample(double prob, 
							int sample_index)
{
  if(num_mcmc<=0 || !mcmc_lmu || !mcmc_lsigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return exp(mcmc_lmu[i]+mcmc_lsigma[i]*gsl_cdf_ugaussian_Pinv(prob));
}





// ************************************************************* //
//                                                               //   
//               T_DISTRIBUTION                           //
//                                                               // 
// A subclass of 'distribution' representing a                   //
// Student t distribution.                                        //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Studen t distribution based on a given dataset.
t_distribution::t_distribution(double *val, int len, 
			       double min, double max, 
			       int num_in_distrib, 
			       bool do_accumulate,  
			       ESTIMATION_METHOD use_est_met,
			       bool allow_negative,
			       double *bayes_param_prior_mu, 
			       double *bayes_param_prior_sd,
			       double *bayes_param_prior_p,
			       int num_samples_, int burnin_, 
			       int spacing_, int num_temp_,
			       bool do_show_mcmc, 
			       bool do_show_debug,
			       bool ratio_based_prior,
			       // Historical (upper) threshold data:
			       int num_thresholds, 
			       historic_threshold *thresholds,
			       // Historical data:
			       int num_historical, 
			       historic_extreme_data *histdata) : 
  distribution("Student-t")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=allow_negative;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=allow_negative ? false : true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<3;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


t_distribution::t_distribution() : distribution("Student-t")
{
  init();
  init_hyperparameters();
  allow_neg=true;
  numparam=3;
  accumulated_function_exists=true;
}

t_distribution::~t_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void t_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  mcmc_nu=NULL;
  
}

void t_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  if(mcmc_nu)
    delete [] mcmc_nu;
  init();
}

void t_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=4;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  strcpy(parnames[2],"nu");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[3];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  param_prior_mu[3]=0.0;
  
  param_prior_sd[0]=1000.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  param_prior_sd[3]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.5;
  param_prior_p[2]=0.975;
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
}

void t_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}


//             SET
// Finds a Logistic distribution based on a given dataset.
void t_distribution::Set(double *val, int len, 
			 double min, double max, int num_in_distrib, 
			 bool do_accumulate, 
			 ESTIMATION_METHOD use_est_met,
			 // Historical (upper) threshold data:
			 int num_thresholds, 
			 historic_threshold *thresholds,
			 // Historical data:
			 int num_historical, 
			 historic_extreme_data *histdata)
{
  register int i;
  
  // set the min and max values
  set_min_and_max(min, max, num_in_distrib);
  // get statistical values;
  get_stats(val, len);

  mu=mean;
  nu=MAXIM(3.0, 4.0+6.0/ex_curtosis);
  
  sigma=sdev*sqrt((nu-2.0)/nu);
  
  est_met=use_est_met;
  sdev_mu=sdev_sigma=sdev_nu=MISSING_VALUE;

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      orig_nu=nu;
      visited=true;
    }
  
  // no distribution could be found?
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"mu","logsigma","logitnu"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd;
      
      int num_extra=0;
      char **t_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	t_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	t_param_names=dist_copy_strings(names, numparam);

      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,t_param_names,T,0.15, 
			 0,NULL,
			 init_tdist,logprior_tdist,loglik_tdist,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_tdist,loglik_tdist);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  mcmc_nu=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	      mcmc_nu[i]=0.03+1e+9*exp(pars[i][2])/(1.0+exp(pars[i][2]));
	    }
	}

      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      nu=find_statistics(mcmc_nu, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      sdev_nu=find_statistics(mcmc_nu, num_mcmc, STANDARD_DEVIATION);
      
      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(t_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double startparams[]={mu,log(sigma),log((nu-0.03)/1e+9/(1.0-(nu-0.03)/1e+9))};

      tdist_likelihood_n=len;
      tdist_likelihood_X=val;
      
      double *params=multinewtonraphson(tdist_likelihood, 3, 
					startparams, 1e-7, 
					bufferlen, false);
      mu=params[0];
      sigma=exp(params[1]);
      nu=0.03+1e+9*exp(params[2])/(1.0+exp(params[2]));

      double **ddf=newton_numeric_doubleder(params); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	iddf=inverse_matrix(ddf, 3);
      else
	iddf=make_matrix(3,3);

      sdev_mu=-iddf[0][0];
      sdev_sigma=-iddf[1][1];
      sdev_nu=-iddf[2][2];
      
      sdev_mu=sqrt(ABSVAL(sdev_mu));
      sdev_sigma=mu*sqrt(ABSVAL(sdev_sigma));
      sdev_nu=sqrt(ABSVAL(sdev_nu));
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;
      delete [] iddf[0];
      delete [] iddf[1];
      delete [] iddf[2];
      delete [] iddf;

      delete [] params;
    }

  // traverse the dataset;
  for(i=0; i< distrib_len; i++)
    {
      double x = min + ((double) i)*step; // find the argument
      distrib_arg[i] = x; // set this argument array element
      distrib_val[i] = function(x); // set the value element
    }
  
  if(do_accumulate) // if we're to accumulate the distribution...
    accumulate(); // accumulate the data...
}

//            FUNCTION
// Returns the value of the Logistic distribution for a given argument
double t_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=exp(lgamma((mcmc_nu[i]+1.0)/2.0) - 0.5*log(mcmc_nu[i]*M_PI) - lgamma(mcmc_nu[i]/2.0) - 
		 log(mcmc_sigma[i]) - 
		 (mcmc_nu[i]+1.0)/2.0*log(1.0+(x-mcmc_mu[i])*(x-mcmc_mu[i])/
					  mcmc_sigma[i]/mcmc_sigma[i]/mcmc_nu[i]));

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return exp(lgamma((nu+1.0)/2.0) - 0.5*log(nu*M_PI) - lgamma(nu/2.0) - log(sigma) - 
	       (nu+1.0)/2.0*log(1.0+(x-mu)*(x-mu)/sigma/sigma/nu));
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated t-distribution 
// for a given argument
double t_distribution::accumulated_function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=gsl_cdf_tdist_P((x-mcmc_mu[i])/mcmc_sigma[i],mcmc_nu[i]);

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return gsl_cdf_tdist_P((x-mu)/sigma,nu);
}


double t_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    return distribution::get_quantile(prob);
  else
    return mu+sigma*gsl_cdf_tdist_Pinv(prob,nu);
}


//          PRINTHELP
// Sends a description of the  Student t distribution to the output stream;
void t_distribution::printhelp(std::ostream &out)
{
  out << "Student-t-fordelingen, er en vanlig" << std::endl;
  out << "statistisk fordeling av verdier med ukjent varians." << std::endl;
  out << "Fordelingen avhenger av 3 parametre." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (6/5-2014)" << std::endl;
}


//          DESCRIPTION
// Returns a short string description of the  Studen t distribution
char *t_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Student-t (%s): "
	    "f(x)=Gamma((nu+1)/2)/Gamma(nu/2)/sqrt(pi*nu)/(1+(x-mu)^2/sigma^2/nu)^((nu+1)/2), "
	    "mu=%-7.3g+-%-6.2g sigma=%-7.3g+-%-6.2g nu=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma, nu, sdev_nu);
  else
    sprintf(newline, "Student-t (%s): "
	    "f(x)=Gamma((nu+1)/2)/Gamma(nu/2)/sqrt(pi*nu)/(1+(x-mu)^2/sigma^2/nu)^((nu+1)/2), "
	    "mu=%-7.3g sigma=%-7.3g nu=%-7.3g", est_method_name[(int) est_met], 
	    mu, sigma, nu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//          SHORT_DECRIPTION
// Returns a shorter string description of the t-distribution
char *t_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Student-t (%s): mu=%-7.3g+-%-6.2g "
	    "sigma=%-7.3g+-%-6.2g nu=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma, nu, sdev_nu);
  else
    sprintf(newline, "Student-t (%s): mu=%-7.3g sigma=%-7.3g nu=%-7.3g", 
	    est_method_name[(int) est_met], 
	    mu, sigma, nu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//          FORMULA_PICTRUE_PATH
// Returns the location of a picture describing the t-distribution
char *t_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/tdist.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("tdist.xbm").c_str());
#endif // NVE
  return newline;
}



double t_distribution::get_mu(void)
{
  return mu;
}

double t_distribution::get_sigma(void)
{
  return sigma;
}

double t_distribution::get_nu(void)
{
  return mu;
}

void t_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
  nu=orig_nu;
}

// Returns the MCMC 'mu' value;
double *t_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *t_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}

// Returns the MCMC 'nu' value;
double *t_distribution::get_mcmc_nu(void)
{
  return mcmc_nu;
}

  // Get samples quantiles:
double t_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return exp(lgamma((mcmc_nu[i]+1.0)/2.0) - 0.5*log(mcmc_nu[i]*M_PI) - lgamma(mcmc_nu[i]/2.0) - 
	     log(mcmc_sigma[i]) - 
	     (mcmc_nu[i]+1.0)/2.0*log(1.0+(x-mcmc_mu[i])*(x-mcmc_mu[i])/
				      mcmc_sigma[i]/mcmc_sigma[i]/mcmc_nu[i]));
}

double t_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return gsl_cdf_tdist_P((x-mcmc_mu[i])/mcmc_sigma[i],mcmc_nu[i]);
}

double t_distribution::mcmc_get_quantile_sample(double prob, 
						int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  
  gsl_set_error_handler (&tdist_handler);
  double ret=mcmc_mu[i]+mcmc_sigma[i]*gsl_cdf_tdist_Pinv(prob,mcmc_nu[i]);
  gsl_set_error_handler (NULL); 
  
  if(!(ret>-1e+200 && ret<1e+200))
    ret=MISSING_VALUE;
  
  return(ret);
}





// ************************************************************* //
//                                                               //   
//               LOGT_DISTRIBUTION                           //
//                                                               // 
// A subclass of 'distribution' representing a                   //
// Log-Student t distribution.                                        //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Log-Student t distribution based on a given dataset.
logt_distribution::logt_distribution(double *val, int len, 
				     double min, double max, 
				     int num_in_distrib, 
				     bool do_accumulate,  
				     ESTIMATION_METHOD use_est_met,
				     double *bayes_param_prior_mu, 
				     double *bayes_param_prior_sd,
				     double *bayes_param_prior_p,
				     int num_samples_, int burnin_, 
				     int spacing_, int num_temp_,
				     bool do_show_mcmc, 
				     bool do_show_debug,
				     bool ratio_based_prior,
				     // Historical (upper) threshold data:
				     int num_thresholds, 
				     historic_threshold *thresholds,
				     // Historical data:
				     int num_historical, 
				     historic_extreme_data *histdata) : 
  distribution("Log-Student-t")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=false;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<3;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  logq3_mu=param_prior_mu[2];
  logq3_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


logt_distribution::logt_distribution() : distribution("Log-Student-t")
{
  init();
  init_hyperparameters();
  allow_neg=true;
  numparam=3;
  accumulated_function_exists=true;
}

logt_distribution::~logt_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void logt_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  mcmc_nu=NULL;
  
}

void logt_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  if(mcmc_nu)
    delete [] mcmc_nu;
  init();
}

void logt_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=3;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  strcpy(parnames[2],"nu");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[3];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.5;
  param_prior_p[2]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  logq3_mu=param_prior_mu[2];
  logq3_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
}

void logt_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}


//             SET
// Finds a log-t-distribution based on a given dataset.
void logt_distribution::Set(double *val, int len, 
			    double min, double max, int num_in_distrib, 
			    bool do_accumulate, 
			    ESTIMATION_METHOD use_est_met,		
			    // Historical (upper) threshold data:
			    int num_thresholds, historic_threshold *thresholds,
			    // Historical data (limits or estimates):
			    int num_historical,historic_extreme_data *histdata)
{
  register int i;
  
  // set the min and max values
  set_min_and_max(min, max, num_in_distrib);
  // get statistical values;
  get_stats(val, len);
  
  double *val2=new double[len];
  for(i=0;i<len;i++)
    val2[i]=log(val[i]);
  t_distribution tt(val2,len,min,max,num_in_distrib,do_accumulate,EST_MOMENT);
  delete [] val2;
  mu=tt.get_mu();
  nu=tt.get_nu();
  sigma=tt.get_sigma();
  
  est_met=use_est_met;
  sdev_mu=sdev_sigma=sdev_nu=MISSING_VALUE;

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      orig_nu=nu;
      visited=true;
    }
  
  // no distribution could be found?
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"mu","logsigma","logitnu"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd;
      
      int num_extra=0;
      char **logt_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	logt_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	logt_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,logt_param_names,T,0.15, 
			 0,NULL,
			 init_logtdist,logprior_logtdist,loglik_logtdist,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_logtdist,loglik_logtdist);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  mcmc_nu=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	      mcmc_nu[i]=0.03+1e+9*exp(pars[i][2])/(1.0+exp(pars[i][2]));
	    }
	}

      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      nu=find_statistics(mcmc_nu, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      sdev_nu=find_statistics(mcmc_nu, num_mcmc, STANDARD_DEVIATION);
      
      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(logt_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double startparams[]={mu,log(sigma),log((nu-0.03)/1e+9/(1.0-(nu-0.03)/1e+9))};

      logtdist_likelihood_n=len;
      logtdist_likelihood_X=val;
      
      double *params=multinewtonraphson(logtdist_likelihood, 3, 
					startparams, 1e-7, 
					bufferlen, false);
      mu=params[0];
      sigma=exp(params[1]);
      nu=0.03+1e+9*exp(params[2])/(1.0+exp(params[2]));

      double **ddf=newton_numeric_doubleder(params); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	iddf=inverse_matrix(ddf, 3);
      else
	iddf=make_matrix(3,3);

      sdev_mu=-iddf[0][0];
      sdev_sigma=-iddf[1][1];
      sdev_nu=-iddf[2][2];
      
      sdev_mu=sqrt(ABSVAL(sdev_mu));
      sdev_sigma=mu*sqrt(ABSVAL(sdev_sigma));
      sdev_nu=sqrt(ABSVAL(sdev_nu));
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;
      delete [] iddf[0];
      delete [] iddf[1];
      delete [] iddf[2];
      delete [] iddf;

      delete [] params;
    }

  // traverse the dataset;
  for(i=0; i< distrib_len; i++)
    {
      double x = min + ((double) i)*step; // find the argument
      distrib_arg[i] = x; // set this argument array element
      distrib_val[i] = function(x); // set the value element
    }
  
  if(do_accumulate) // if we're to accumulate the distribution...
    accumulate(); // accumulate the data...
}

//            FUNCTION
// Returns the value of the log-t-distribution for a given argument
double logt_distribution::function(double x)
{
  if(x<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=exp(lgamma((mcmc_nu[i]+1.0)/2.0) - 0.5*log(mcmc_nu[i]*M_PI) - lgamma(mcmc_nu[i]/2.0) - 
		 log(mcmc_sigma[i]) - 
		 (mcmc_nu[i]+1.0)/2.0*log(1.0+(log(x)-mcmc_mu[i])*(log(x)-mcmc_mu[i])/
					  mcmc_sigma[i]/mcmc_sigma[i]/mcmc_nu[i]))/x;

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return exp(lgamma((nu+1.0)/2.0) - 0.5*log(nu*M_PI) - lgamma(nu/2.0) - log(sigma) - 
	       (nu+1.0)/2.0*log(1.0+(log(x)-mu)*(log(x)-mu)/sigma/sigma/nu))/x;
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated log-t-distribution 
// for a given argument
double logt_distribution::accumulated_function(double x)
{
  if(x<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=gsl_cdf_tdist_P((log(x)-mcmc_mu[i])/mcmc_sigma[i],mcmc_nu[i]);

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return gsl_cdf_tdist_P((log(x)-mu)/sigma,nu);
}


double logt_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    return distribution::get_quantile(prob);
  else
    return exp(mu+sigma*gsl_cdf_tdist_Pinv(prob,nu));
}


//          PRINTHELP
// Sends a description of the  Student t distribution to the output stream;
void logt_distribution::printhelp(std::ostream &out)
{
  out << "Log-Student-t-fordelingen, er en " << std::endl;
  out << "statistisk fordeling av strengt positive verdier." << std::endl;
  out << "Fordelingen avhenger av 3 parametre." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (6/5-2014)" << std::endl;
}


//          DESCRIPTION
// Returns a short string description of the  Studen t distribution
char *logt_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Log-Student-t (%s): "
	    "f(x)=Gamma((nu+1)/2)/Gamma(nu/2)/sqrt(pi*nu)/(1+(log(x)-mu)^2/sigma^2/nu)^((nu+1)/2)/x, "
	    "mu=%-7.3g+-%-6.2g sigma=%-7.3g+-%-6.2g nu=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma, nu, sdev_nu);
  else
    sprintf(newline, "Log-Student-t (%s): "
	    "f(x)=Gamma((nu+1)/2)/Gamma(nu/2)/sqrt(pi*nu)/(1+(log(x)-mu)^2/sigma^2/nu)^((nu+1)/2)/x, "
	    "mu=%-7.3g sigma=%-7.3g nu=%-7.3g", est_method_name[(int) est_met], 
	    mu, sigma, nu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//          SHORT_DECRIPTION
// Returns a shorter string description of the log-t-distribution
char *logt_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Log-Student-t (%s): mu=%-7.3g+-%-6.2g "
	    "sigma=%-7.3g+-%-6.2g nu=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma, nu, sdev_nu);
  else
    sprintf(newline, "Log-Student-t (%s): mu=%-7.3g sigma=%-7.3g nu=%-7.3g", 
	    est_method_name[(int) est_met], 
	    mu, sigma, nu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//          FORMULA_PICTRUE_PATH
// Returns the location of a picture describing the log-t-distribution
char *logt_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/logtdist.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("logtdist.xbm").c_str());
#endif // NVE
  return newline;
}



double logt_distribution::get_mu(void)
{
  return mu;
}

double logt_distribution::get_sigma(void)
{
  return sigma;
}

double logt_distribution::get_nu(void)
{
  return mu;
}

void logt_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
  nu=orig_nu;
}

// Returns the MCMC 'mu' value;
double *logt_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *logt_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}

// Returns the MCMC 'nu' value;
double *logt_distribution::get_mcmc_nu(void)
{
  return mcmc_nu;
}

  // Get samples quantiles:
double logt_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return exp(lgamma((mcmc_nu[i]+1.0)/2.0) - 0.5*log(mcmc_nu[i]*M_PI) - lgamma(mcmc_nu[i]/2.0) - 
	     log(mcmc_sigma[i]) - 
	     (mcmc_nu[i]+1.0)/2.0*log(1.0+(log(x)-mcmc_mu[i])*(log(x)-mcmc_mu[i])/
				      mcmc_sigma[i]/mcmc_sigma[i]/mcmc_nu[i]))/x;
}

double logt_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  double ret=gsl_cdf_tdist_P((log(x)-mcmc_mu[i])/mcmc_sigma[i],mcmc_nu[i]);

  return ret;
}

double logt_distribution::mcmc_get_quantile_sample(double prob, 
						int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  
  
  gsl_set_error_handler (&tdist_handler);
  double ret=exp(mcmc_mu[i]+mcmc_sigma[i]*gsl_cdf_tdist_Pinv(prob,mcmc_nu[i]));
  gsl_set_error_handler (NULL); 
  
  if(!(ret>-1e+200 && ret<1e+200))
    ret=MISSING_VALUE;
  
  return(ret);
}






// ************************************************************* //
//                                                               //   
//               LOGISTIC_DISTRIBUTION                           //
//                                                               // 
// A subclass of 'distribution' representing a                   //
// logistic distribution.                                        //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a logistic distribution based on a given dataset.
logistic_distribution::logistic_distribution(double *val, int len, 
					     double min, double max, 
					     int num_in_distrib, 
					     bool do_accumulate,  
					     ESTIMATION_METHOD use_est_met,
					     bool allow_negative,
					     double *bayes_param_prior_mu, 
					     double *bayes_param_prior_sd,
					     double *bayes_param_prior_p,
					     int num_samples_, int burnin_, 
					     int spacing_, int num_temp_,
					     bool do_show_mcmc, 
					     bool do_show_debug,
					     bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("logistic")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=allow_negative;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=allow_negative ? false : true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


logistic_distribution::logistic_distribution() : distribution("logistic")
{
  init();
  init_hyperparameters();
  allow_neg=true;
  numparam=2;
  accumulated_function_exists=true;
}

logistic_distribution::~logistic_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void logistic_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  
}

void logistic_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  init();
}

void logistic_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=3;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  
  param_prior_sd[0]=1000.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void logistic_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}


//             SET
// Finds a Logistic distribution based on a given dataset.
void logistic_distribution::Set(double *val, int len, 
				double min, double max, int num_in_distrib, 
				bool do_accumulate, 
				ESTIMATION_METHOD use_est_met,
				// Historical (upper) threshold data:
				int num_thresholds, 
				historic_threshold *thresholds,
				// Historical data:
				int num_historical, 
				historic_extreme_data *histdata)
{
  register int i;
  
  // set the min and max values
  set_min_and_max(min, max, num_in_distrib);
  // get statistical values;
  get_stats(val, len);

  
  // Calculate the 'alfa' and 'u' parameters;
  //alfa = sqrt(6)*sdev/pi;
  //u = mean - 0.5772 * alfa;
  double lambda2=2.0*b1-b0;
  sigma=lambda2;  
  mu=b0;
  
  est_met=use_est_met;
  sdev_mu=sdev_sigma=MISSING_VALUE;

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      visited=true;
    }
  
  // no distribution could be found?
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"mu","logsigma"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd;
      
      int num_extra=0;
      char **logist_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	logist_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	logist_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,logist_param_names,T,0.15, 
			 0,NULL,
			 init_logistic,logprior_logistic,loglik_logistic,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_logistic,loglik_logistic);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	    }
	}

      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      
      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(logist_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double startparams[]={mu,log(sigma)};

      logistic_likelihood_n=len;
      logistic_likelihood_X=val;
      
      double *params=multinewtonraphson(logistic_likelihood, 2, 
					startparams, 1e-7, 
					bufferlen, false);
      mu=params[0];
      sigma=exp(params[1]);

      double **ddf=newton_numeric_doubleder(params); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,2),0.0))
	iddf=inverse_matrix(ddf, 2);
      else
	iddf=make_matrix(2,2);

      sdev_mu=-iddf[0][0];
      sdev_sigma=-iddf[1][1];
      
      sdev_mu=sqrt(ABSVAL(sdev_mu));
      sdev_sigma=mu*sqrt(ABSVAL(sdev_sigma));
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf;
      delete [] iddf[0];
      delete [] iddf[1];
      delete [] iddf;

      delete [] params;
    }

  // traverse the dataset;
  for(i=0; i< distrib_len; i++)
    {
      double x = min + ((double) i)*step; // find the argument
      distrib_arg[i] = x; // set this argument array element
      distrib_val[i] = function(x); // set the value element
    }
  
  if(do_accumulate) // if we're to accumulate the distribution...
    accumulate(); // accumulate the data...
}

//            FUNCTION
// Returns the value of the Logistic distribution for a given argument
double logistic_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=1.0/mcmc_sigma[i]*exp(-(x-mcmc_mu[i])/mcmc_sigma[i])/
	  pow(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]),2.0);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return 1.0/sigma*exp(-(x-mu)/sigma)/pow(1.0+exp(-(x-mu)/sigma),2.0);
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Logistic distribution 
// for a given argument
double logistic_distribution::accumulated_function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=1.0/(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return 1.0/(1.0+exp(-(x-mu)/sigma));
}


double logistic_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    return distribution::get_quantile(prob);
  else
    return mu+sigma*log(prob/(1.0-prob));
}


//          PRINTHELP
// Sends a description of the  Logistic distribution to the output stream;
void logistic_distribution::printhelp(std::ostream &out)
{
  out << "Logistic-fordelingen, er en vanlig" << std::endl;
  out << "fordeling av verdier, noe brukt i ekstremverdianalyse." << std::endl;
  out << "Fordelingen avhenger av 2 parametre." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (6/5-2014)" << std::endl;
}


//          DESCRIPTION
// Returns a short string description of the  Logistic distribution
char *logistic_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Logisticfordeling (%s): "
	    "f(x)=1.0/sigma*exp(-(x-mu)/sigma)/(1.0+exp(-(x-mu)/sigma))^2, "
	    "mu=%-7.3g+-%-6.2g sdev=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma);
  else
    sprintf(newline, "Logisticfordeling (%s): "
	    "f(x)=1.0/sigma*exp(-(x-mu)/sigma)/(1.0+exp(-(x-mu)/sigma))^2, "
	    "mean=%-7.3g sdev=%-7.3g", est_method_name[(int) est_met], 
	    mu, sigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//          SHORT_DECRIPTION
// Returns a shorter string description of the Logistic distribution
char *logistic_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Logisticfordeling (%s):mu=%-7.3g+-%-6.2g "
	    "sigma=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma);
  else
    sprintf(newline, "Logisticfordeling (%s): mu=%-7.3g sigma=%-7.3g", 
	    est_method_name[(int) est_met], 
	    mu, sigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//          FORMULA_PICTRUE_PATH
// Returns the location of a picture describing the Logistic distribution
char *logistic_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/logistic.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("logistic.xbm").c_str());
#endif // NVE
  return newline;
}



double logistic_distribution::get_mu(void)
{
  return mu;
}

double logistic_distribution::get_sigma(void)
{
  return sigma;
}

void logistic_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
}

// Returns the MCMC 'mu' value;
double *logistic_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *logistic_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}


  // Get samples quantiles:
double logistic_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return 1.0/mcmc_sigma[i]*exp(-(x-mcmc_mu[i])/mcmc_sigma[i])/
    pow(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]),2.0);
}

double logistic_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return 1.0/(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));
}

double logistic_distribution::mcmc_get_quantile_sample(double prob, 
						     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return mcmc_mu[i]+mcmc_sigma[i]*log(prob/(1.0-prob));
}

// ************************************************************* //
//                                                               //   
//               LOGLOGISTIC_DISTRIBUTION                        //
//                                                               // 
// A subclass of 'distribution' representing a                   //
// log-logistic distribution.                                    //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a loglogistic distribution based on a given dataset.
loglogistic_distribution::loglogistic_distribution(double *val, int len, 
						   double min, double max, 
						   int num_in_distrib, 
						   bool do_accumulate,  
						   ESTIMATION_METHOD use_est_met,
						   double *bayes_param_prior_mu, 
						   double *bayes_param_prior_sd,
						   double *bayes_param_prior_p,
						   int num_samples_, int burnin_, 
						   int spacing_, int num_temp_,
						   bool do_show_mcmc, 
						   bool do_show_debug,
				       bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("log-logistic")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=false;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


loglogistic_distribution::loglogistic_distribution() : distribution("log-logistic")
{
  init();
  init_hyperparameters();
  allow_neg=false;
  numparam=2;
  accumulated_function_exists=true;
}

loglogistic_distribution::~loglogistic_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void loglogistic_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  
}

void loglogistic_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  init();
}

void loglogistic_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=2;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void loglogistic_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}


//             SET
// Finds a Loglogistic distribution based on a given dataset.
void loglogistic_distribution::Set(double *val, int len, 
				   double min, double max, int num_in_distrib, 
				   bool do_accumulate, 
				   ESTIMATION_METHOD use_est_met,
				   // Historical (upper) threshold data:
				   int num_thresholds, 
				   historic_threshold *thresholds,
				   // Historical data:
				   int num_historical, 
				   historic_extreme_data *histdata)
{
  register int i;
  
  // set the min and max values
  set_min_and_max(min, max, num_in_distrib);
  // get statistical values;
  get_stats(val, len);


  // l-moments from log-transformed values:
  double *val2=new double[len];
  for(i=0;i<len;i++)
    val2[i]=log(val[i]);
  logistic_distribution ld(val2,len,min,max,num_in_distrib,do_accumulate,EST_LMOMENT);
  delete [] val2;
  mu=ld.get_mu();
  sigma=ld.get_sigma();
  
  est_met=use_est_met;
  sdev_mu=sdev_sigma=MISSING_VALUE;

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      visited=true;
    }
  
  // no distribution could be found?
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"mu","logsigma"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd;
      
      int num_extra=0;
      char **loglog_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	loglog_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	loglog_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,loglog_param_names,T,0.15, 
			 0,NULL,
			 init_loglogistic,logprior_loglogistic,loglik_loglogistic,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_loglogistic,loglik_loglogistic);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	    }
	}

      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(loglog_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double startparams[]={mu,log(sigma)};

      loglogistic_likelihood_n=len;
      loglogistic_likelihood_X=val;
      
      double *params=multinewtonraphson(loglogistic_likelihood, 2, 
					startparams, 1e-7, 
					bufferlen, false);
      mu=params[0];
      sigma=exp(params[1]);

      double **ddf=newton_numeric_doubleder(params); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,2),0.0))
	iddf=inverse_matrix(ddf, 2);
      else
	iddf=make_matrix(2,2);

      sdev_mu=-iddf[0][0];
      sdev_sigma=-iddf[1][1];
      
      sdev_mu=sqrt(ABSVAL(sdev_mu));
      sdev_sigma=mu*sqrt(ABSVAL(sdev_sigma));
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf;
      delete [] iddf[0];
      delete [] iddf[1];
      delete [] iddf;

      delete [] params;
    }

  // traverse the dataset;
  for(i=0; i< distrib_len; i++)
    {
      double x = min + ((double) i)*step; // find the argument
      distrib_arg[i] = x; // set this argument array element
      distrib_val[i] = function(x); // set the value element
    }
  
  if(do_accumulate) // if we're to accumulate the distribution...
    accumulate(); // accumulate the data...
}

//            FUNCTION
// Returns the value of the Loglogistic distribution for a given argument
double loglogistic_distribution::function(double x)
{
  if(x<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=1.0/mcmc_sigma[i]/x*exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i])/
	  pow(1.0+exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]),2.0);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return 1.0/sigma/x*exp(-(log(x)-mu)/sigma)/pow(1.0+exp(-(log(x)-mu)/sigma),2.0);
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Loglogistic distribution 
// for a given argument
double loglogistic_distribution::accumulated_function(double x)
{
  if(x<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=1.0/(1.0+exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]));

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return 1.0/(1.0+exp(-(log(x)-mu)/sigma));
}


double loglogistic_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    return distribution::get_quantile(prob);
  else
    return exp(mu+sigma*log(prob/(1.0-prob)));
}


//          PRINTHELP
// Sends a description of the  Loglogistic distribution to the output stream;
void loglogistic_distribution::printhelp(std::ostream &out)
{
  out << "Loglogistic-fordelingen, er en vanlig" << std::endl;
  out << "fordeling av verdier, noe brukt i ekstremverdianalyse." << std::endl;
  out << "Fordelingen avhenger av 2 parametre og tillater kun positive verdier." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (6/5-2014)" << std::endl;
}


//          DESCRIPTION
// Returns a short string description of the  Loglogistic distribution
char *loglogistic_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Log-logisticfordeling (%s): "
	    "f(x)=1.0/sigma*exp(-(x-mu)/sigma)/(1.0+exp(-(x-mu)/sigma))^2, "
	    "mu=%-7.3g+-%-6.2g sdev=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma);
  else
    sprintf(newline, "Log-logisticfordeling (%s): "
	    "f(x)=1.0/sigma*exp(-(x-mu)/sigma)/(1.0+exp(-(x-mu)/sigma))^2, "
	    "mean=%-7.3g sdev=%-7.3g", est_method_name[(int) est_met], 
	    mu, sigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//          SHORT_DECRIPTION
// Returns a shorter string description of the Loglogistic distribution
char *loglogistic_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Log-logisticfordeling (%s):mu=%-7.3g+-%-6.2g "
	    "sigma=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma);
  else
    sprintf(newline, "Log-logisticfordeling (%s): mu=%-7.3g sigma=%-7.3g", 
	    est_method_name[(int) est_met], 
	    mu, sigma);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//          FORMULA_PICTRUE_PATH
// Returns the location of a picture describing the Loglogistic distribution
char *loglogistic_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/loglogistic.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("loglogistic.xbm").c_str());
#endif // NVE
  return newline;
}



double loglogistic_distribution::get_mu(void)
{
  return mu;
}

double loglogistic_distribution::get_sigma(void)
{
  return sigma;
}

void loglogistic_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
}

// Returns the MCMC 'mu' value;
double *loglogistic_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *loglogistic_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}


  // Get samples quantiles:
double loglogistic_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return 1.0/mcmc_sigma[i]/x*exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i])/
    pow(1.0+exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]),2.0);
}

double loglogistic_distribution::mcmc_accumulated_function_sample(double x, 
								  int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return 1.0/(1.0+exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]));
}

double loglogistic_distribution::mcmc_get_quantile_sample(double prob, 
						     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return exp(mcmc_mu[i]+mcmc_sigma[i]*log(prob/(1.0-prob)));
}



// ************************************************************* //
//                                                               //   
//               GENERALIZED_LOGISTIC_DISTRIBUTION               //
//                                                               // 
// A subclass of 'distribution' representing a generalized       //
// logistic distribution.                                        //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a logistic distribution based on a given dataset.
generalized_logistic_distribution::
  generalized_logistic_distribution(double *val, int len, 
				    double min, double max, 
				    int num_in_distrib, 
				    bool do_accumulate,  
				    ESTIMATION_METHOD use_est_met,
				    bool allow_negative,
				    double *bayes_param_prior_mu, 
				    double *bayes_param_prior_sd,
				    double *bayes_param_prior_p,
				    int num_samples_, int burnin_, 
				    int spacing_, int num_temp_,
				    bool do_show_mcmc, 
				    bool do_show_debug,
				    bool ratio_based_prior,
				    // Historical (upper) threshold data:
				    int num_thresholds, 
				    historic_threshold *thresholds,
				    // Historical data:
				    int num_historical, 
				    historic_extreme_data *histdata) : 
    distribution("generalized logistic")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=allow_negative;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=allow_negative ? false : true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<3;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


generalized_logistic_distribution::generalized_logistic_distribution() : distribution("generalized logistic")
{
  init();
  init_hyperparameters();
  allow_neg=true;
  numparam=3;
  accumulated_function_exists=true;
}

generalized_logistic_distribution::~generalized_logistic_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void generalized_logistic_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  
}

void generalized_logistic_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  init();
}

void generalized_logistic_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=4;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  strcpy(parnames[2],"k");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_BOTH;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[3];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  param_prior_mu[3]=0.0;
  
  param_prior_sd[0]=1000.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  param_prior_sd[3]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.5;
  param_prior_p[2]=0.975;
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
}

void generalized_logistic_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}


//             SET
// Finds a Logistic distribution based on a given dataset.
void generalized_logistic_distribution::Set(double *val, int len, 
					    double min, double max, 
					    int num_in_distrib, 
					    bool do_accumulate, 
					    ESTIMATION_METHOD use_est_met,
			     // Historical (upper) threshold data:
			     int num_thresholds, 
			     historic_threshold *thresholds,
			     // Historical data:
			     int num_historical, 
			     historic_extreme_data *histdata)
{
  register int i;
  
  // set the min and max values
  set_min_and_max(min, max, num_in_distrib);
  // get statistical values;
  get_stats(val, len);

  
  // Calculate the 'alfa' and 'u' parameters;
  //alfa = sqrt(6)*sdev/pi;
  //u = mean - 0.5772 * alfa;
  double lambda2=2.0*b1-b0;
  double tau3=(6.0*b2-6.0*b1+b0)/lambda2;
  k=-tau3;
  if(k==0.0)
    sigma=lambda2;
  else
    sigma=lambda2/exp(lgamma(1.0+k))/exp(lgamma(1.0-k));
  if(k==0.0)
    mu=b0;
  else
    mu=b0+(lambda2-sigma)/k;
  
  est_met=use_est_met;
  sdev_mu=sdev_sigma=sdev_k=MISSING_VALUE;

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      orig_k=k;
      visited=true;
    }
  
  // no distribution could be found?
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"mu","logsigma","k"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd;
      
      int num_extra=0;
      char **gl_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	gl_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	gl_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,gl_param_names,T,0.15, 
			 0,NULL,
			 init_glogistic,logprior_glogistic,loglik_glogistic,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_glogistic,loglik_glogistic);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  mcmc_k=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	      mcmc_k[i]=pars[i][2];
	    }
	}

      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      k=find_statistics(mcmc_k, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      sdev_k=find_statistics(mcmc_k, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(gl_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double startparams[]={mu,log(sigma),k};

      glogistic_likelihood_n=len;
      glogistic_likelihood_X=val;
      
      double *params=multinewtonraphson(glogistic_likelihood, 3, 
					startparams, 1e-7, 
					bufferlen, false);
      mu=params[0];
      sigma=exp(params[1]);
      k=params[2];

      double **ddf=newton_numeric_doubleder(params); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	iddf=inverse_matrix(ddf, 3);
      else
	iddf=make_matrix(3,3);

      sdev_mu=-iddf[0][0];
      sdev_sigma=-iddf[1][1];
      sdev_k=-iddf[2][2];
      
      sdev_mu=sqrt(ABSVAL(sdev_mu));
      sdev_sigma=mu*sqrt(ABSVAL(sdev_sigma));
      sdev_k=sqrt(ABSVAL(sdev_k));
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;
      delete [] iddf[0];
      delete [] iddf[1];
      delete [] iddf[2];
      delete [] iddf;

      delete [] params;
    }

  // traverse the dataset;
  for(i=0; i< distrib_len; i++)
    {
      double x = min + ((double) i)*step; // find the argument
      distrib_arg[i] = x; // set this argument array element
      distrib_val[i] = function(x); // set the value element
    }
  
  if(do_accumulate) // if we're to accumulate the distribution...
    accumulate(); // accumulate the data...
}

//            FUNCTION
// Returns the value of the Logistic distribution for a given argument
double generalized_logistic_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(mcmc_k[i]==0.0)
	  ret+=1.0/mcmc_sigma[i]*exp(-(x-mcmc_mu[i])/mcmc_sigma[i])/
	    pow(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]),2.0);
	else if((mcmc_k[i]>0.0 && x<=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]) || 
		(mcmc_k[i]<0.0 && x>=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]))
	  ret+=1.0/mcmc_sigma[i]*pow(1.0-mcmc_k[i]*(x-mcmc_mu[i])/mcmc_sigma[i],1.0/mcmc_k[i]-1.0)/
	    pow(1.0+pow(1.0-mcmc_k[i]*(x-mcmc_mu[i])/mcmc_sigma[i],1.0/mcmc_k[i]),2.0);

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    {
      if(k==0.0)
	return 1.0/sigma*exp(-(x-mu)/sigma)/pow(1.0+exp(-(x-mu)/sigma),2.0);
      else if((k>0.0 && x<=mu+sigma/k) || (k<0.0 && x>=mu+sigma/k))
	return 1.0/sigma*pow(1.0-k*(x-mu)/sigma,1.0/k-1.0)/
	  pow(1.0+pow(1.0-k*(x-mu)/sigma,1.0/k),2.0);
      else
	return 0.0;
    }
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Logistic distribution 
// for a given argument
double generalized_logistic_distribution::accumulated_function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(mcmc_k[i]==0.0)
	  ret+=1.0/(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));
	else if((mcmc_k[i]>0.0 && x<=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]) || 
		(mcmc_k[i]<0.0 && x>=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]))
	  ret+=1.0/(1.0+pow(1.0-mcmc_k[i]*(x-mcmc_mu[i])/mcmc_sigma[i],1.0/mcmc_k[i]));
	else if(mcmc_k[i]>0.0)
	  ret+=1.0;

      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    {
      if(k==0.0)
	return 1.0/(1.0+exp(-(x-mu)/sigma));
      else if((k>0.0 && x<=mu+sigma/k) || (k<0.0 && x>=mu+sigma/k))
	return 1.0/(1.0+pow(1.0-k*(x-mu)/sigma,1.0/k));
      else if(k>0.0)
	return 1.0;
      else
	return 0.0;
    }
}


double generalized_logistic_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma)
    return distribution::get_quantile(prob);
  else
    {
      if(k==0.0)
	return mu+sigma*log(prob/(1.0-prob));
      else
	return mu+sigma*(1.0-pow((1.0-prob)/prob,k))/k;
    }
}


//          PRINTHELP
// Sends a description of the Generalized Logistic distribution to the output stream;
void generalized_logistic_distribution::printhelp(std::ostream &out)
{
  out << "Generalized logistic-fordelingen, er en vanlig" << std::endl;
  out << "fordeling av verdier, noe brukt i ekstremverdianalyse." << std::endl;
  out << "Fordelingen avhenger av 3 parametre." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (6/5-2014)" << std::endl;
}


//          DESCRIPTION
// Returns a short string description of the Generalized Logistic distribution
char *generalized_logistic_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Generalized Logisticfordeling (%s): "
	    "f(x)=(1-k(x-mu)/sigma)^(1/k-1)/sigma/(1+(1-k(x-mu)/sigma)^(1/k))^2, "
	    "mu=%-7.3g+-%-6.2g sdev=%-7.3g+-%-6.2g k=%-7.3g+/-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma, k, sdev_k);
  else
    sprintf(newline, "Generalized Logisticfordeling (%s): "
	    "f(x)=(1-k(x-mu)/sigma)^(1/k-1)/sigma/(1+(1-k(x-mu)/sigma)^(1/k))^2, "
	    "mean=%-7.3g sdev=%-7.3g k=%-7.3g", est_method_name[(int) est_met], 
	    mu, sigma, k);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//          SHORT_DECRIPTION
// Returns a shorter string description of the Logistic distribution
char *generalized_logistic_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE)
    sprintf(newline, "Generalized Logisticfordeling (%s):mu=%-7.3g+-%-6.2g "
	    "sigma=%-7.3g+-%-6.2g k=%-7.3g+/-%-6.2g", 
	    est_method_name[(int) est_met], mu, sdev_mu, sigma, sdev_sigma, k, sdev_k);
  else
    sprintf(newline, "Generalized Logisticfordeling (%s): mu=%-7.3g sigma=%-7.3g k=%-7.3g", 
	    est_method_name[(int) est_met], 
	    mu, sigma,k);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//          FORMULA_PICTRUE_PATH
// Returns the location of a picture describing the Logistic distribution
char *generalized_logistic_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/glogistic.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("glogistic.xbm").c_str());
#endif // NVE
  return newline;
}



double generalized_logistic_distribution::get_mu(void)
{
  return mu;
}

double generalized_logistic_distribution::get_sigma(void)
{
  return sigma;
}

double generalized_logistic_distribution::get_k(void)
{
  return k;
}

void generalized_logistic_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
  k=orig_k;
}

// Returns the MCMC 'mu' value;
double *generalized_logistic_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *generalized_logistic_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}

// Returns the MCMC 'k' value;
double *generalized_logistic_distribution::get_mcmc_k(void)
{
  return mcmc_k;
}


  // Get samples quantiles:
double generalized_logistic_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_k ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(mcmc_k[i]==0.0)
    return 1.0/mcmc_sigma[i]*exp(-(x-mcmc_mu[i])/mcmc_sigma[i])/
      pow(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]),2.0);
  else if((mcmc_k[i]>0.0 && x<=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]) || 
		(mcmc_k[i]<0.0 && x>=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]))
    return 1.0/mcmc_sigma[i]*pow(1.0-mcmc_k[i]*(x-mcmc_mu[i])/mcmc_sigma[i],1.0/mcmc_k[i]-1.0)/
      pow(1.0+pow(1.0-mcmc_k[i]*(x-mcmc_mu[i])/mcmc_sigma[i],1.0/mcmc_k[i]),2.0);
  else
    return 0.0;
}

double generalized_logistic_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_k ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(mcmc_k[i]==0.0)
    return 1.0/(1.0+exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));
  else if((mcmc_k[i]>0.0 && x<=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]) || 
	  (mcmc_k[i]<0.0 && x>=mcmc_mu[i]+mcmc_sigma[i]/mcmc_k[i]))
    return 1.0/(1.0+pow(1.0-mcmc_k[i]*(x-mcmc_mu[i])/mcmc_sigma[i],1.0/mcmc_k[i]));
  else if(mcmc_k[i]>0.0)
    return 1.0;
  else
    return 0.0;
}

double generalized_logistic_distribution::mcmc_get_quantile_sample(double prob, 
						     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_k || 
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  if(mcmc_k[i]==0.0)
    return mcmc_mu[i]+mcmc_sigma[i]*log(prob/(1.0-prob));
  else
    return mcmc_mu[i]+mcmc_sigma[i]*(1.0-pow((1.0-prob)/prob,mcmc_k[i]))/mcmc_k[i];
}



// ************************************************************* //
//                                                               //   
//               GAMMA_DISTRIBUTION                              //
//                                                               // 
// A subclass of 'distribution' representing a 'gamma'           //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a gamma distribution based on a given dataset.
gamma_distribution::gamma_distribution(double *val, int len, 
				       double min, double max, 
				       int num_in_distrib, 
				       bool do_accumulate, 
				       ESTIMATION_METHOD use_est_met,
				       double *bayes_param_prior_mu, 
				       double *bayes_param_prior_sd,
				       double *bayes_param_prior_p,
				       int num_samples_, 
				       int burnin_, 
				       int spacing_, int num_temp_,
				       bool do_show_mcmc, 
				       bool do_show_debug,
				       bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("gamma")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=false;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}

gamma_distribution::gamma_distribution(double alfa_, double beta_,
				       double min, double max, 
				       int num_in_distrib) : 
  distribution("gamma")
{
  register int i;

  init();
  init_hyperparameters();
  allow_neg=false;
  numparam=2;
  accumulated_function_exists=true;
  
  est_met=EST_MOMENT;

  // find min and amx values;
  set_min_and_max(min, max, num_in_distrib);
  
  // calculate the 'alfa' and 'beta' parameters;
  alfa = alfa_;
  beta = beta_;

  // traverse the distribution
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      distrib_arg[i] = x; // set the argument array element
      distrib_val[i] = function(x); // set the value array element
    }

  status=DISTRIBUTION_FOUND;
  sdev=sqrt(alfa)*beta;
  mean=alfa*beta;
 
  accumulate();
}

gamma_distribution::gamma_distribution() : distribution("gamma")
{
  init();
  init_hyperparameters();
  allow_neg=false;
  numparam=2;
  accumulated_function_exists=true;
}

gamma_distribution::~gamma_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}

void gamma_distribution::init(void)
{
  mcmc_alfa=NULL;
  mcmc_beta=NULL;
  
}

void gamma_distribution::cleanup(void)
{
  if(mcmc_alfa)
    delete [] mcmc_alfa;
  if(mcmc_beta)
    delete [] mcmc_beta;
  init();
}

void gamma_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=2;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"alfa");
  strcpy(parnames[1],"beta");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void gamma_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(parstatus)
    delete [] parstatus;
}

//            SET
// Finds a gamma distribution based on a given dataset.
void gamma_distribution::Set(double *val, int len, 
			     double min, double max, int num_in_distrib, 
			     bool do_accumulate, 
			     ESTIMATION_METHOD use_est_met,
			     // Historical (upper) threshold data:
			     int num_thresholds, 
			     historic_threshold *thresholds,
			     // Historical data:
			     int num_historical, 
			     historic_extreme_data *histdata)
{
  register int i;
  
  est_met=use_est_met;

  // find min and amx values;
  set_min_and_max(min, max, num_in_distrib);
  // Get statistical values;
  get_stats(val, len);
  
  // if statistics couldn't be found...
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return; 
  
  // calculate the 'alfa' and 'beta' parameters;
  alfa = mean*mean/sdev/sdev;
  beta = sdev*sdev/mean;

  sdev_alfa=sdev_beta=MISSING_VALUE;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"logalfa","logbeta"};
      
      int num_extra=0;
      char **gamma_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	gamma_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	gamma_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,gamma_param_names,T,0.15, 
			 0,NULL,
			 init_gamma,logprior_gamma,loglik_gamma,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_gamma,loglik_gamma);
      
      if(pars)
	{
	  mcmc_alfa=new double[num_mcmc];
	  mcmc_beta=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_alfa[i]=exp(pars[i][0]);
	      mcmc_beta[i]=exp(pars[i][1]);
	    }
	}

      alfa=find_statistics(mcmc_alfa, num_mcmc, MEAN);
      beta=find_statistics(mcmc_beta, num_mcmc, MEAN);
      sdev_alfa=find_statistics(mcmc_alfa, num_mcmc, STANDARD_DEVIATION);
      sdev_beta=find_statistics(mcmc_beta, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(gamma_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(use_est_met==EST_ML)
    {
      int bufferlen=100;
      derivated_gamma_likelihood_n=len;
      derivated_gamma_mean=mean;
      derivated_gamma_logmean=logmean;
      
      alfa=newtons_method(derivated_gamma_likelihood, alfa, 1e-8, 
			  bufferlen, 0.0, 0.5 /* step length */, 
			  0.0/* minimal value */);
      beta=mean/alfa;
      
      double ddf_alfa=(derivated_gamma_likelihood(alfa+1e-6)-
		       derivated_gamma_likelihood(alfa))/1e-6;
      sdev_alfa=-1.0/ddf_alfa;
      double ddf_beta=alfa*len/beta/beta-2.0*len*mean/beta/beta/beta;
      sdev_beta=-1.0/ddf_beta;
      
      sdev_alfa=sqrt(ABSVAL(sdev_alfa));
      sdev_beta=sqrt(ABSVAL(sdev_beta));
    }

  if(!visited)
    {
      orig_alfa=alfa;
      orig_beta=beta;
      visited=true;
    }

  // traverse the distribution
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      distrib_arg[i] = x; // set the argument array element
      distrib_val[i] = function(x); // set the value array element
    }

  if(do_accumulate)
    accumulate();
}


//           FUNCTION
// Returns the value of the gamma distribution for a given argument
double gamma_distribution::function(double x)
{
  if(x<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=(pow(mcmc_beta[i], -mcmc_alfa[i]) * pow(x,mcmc_alfa[i]-1.0) * 
	  exp(-x/mcmc_beta[i]) / exp(lgamma(mcmc_alfa[i])));
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return (pow(beta, -alfa) * pow(x,alfa-1) * 
	  exp(-x/beta) / exp(lgamma(alfa)));
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gauss distribution 
// for a given argument
double gamma_distribution::accumulated_function(double x)
{
  if(x<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=gsl_cdf_gamma_P(x,mcmc_alfa[i],mcmc_beta[i]);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return gsl_cdf_gamma_P(x,alfa,beta);
}


double gamma_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    return distribution::get_quantile(prob);
  else
    return gsl_cdf_gamma_Pinv(prob,alfa,beta);
}



//           PRINTHELP
// Sends a description of the gamma distribution to the output stream;
void gamma_distribution::printhelp(std::ostream &out)
{
  out << "Gammafordelingen " << std::endl;
  out << "" << std::endl;
  out << "Dette er en forholdvis enkel toparameter-fordeling med" << std::endl;
  out << "positiv skjevhet (passer for vannf�ringsdata o.l.)." << std::endl;
  out << "Fordelingen b�r helst brukes p� verdi-fordelingen med kun "
    "positive verdier." << std::endl;
  out << "Moment-metoden bruker 1. og 2.ordens momenter (gjennomsnitt og" << 
    std::endl;
  out << "standardavvik) til � tilpasse fordelingen til observasjonene." << 
    std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (7/5-1999)" << std::endl;
}


//           DESCRIPTION
// Returns a short string description of the gamma distribution
char *gamma_distribution::description(void)
{
  char *newline= new char[1000];
  
  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, 
	    "Gamma (%s): f(x)=x^(alfa-1) exp(-x/beta)/"
	    "(beta^alfa Gamma(alfa))  alfa=%-7.3g+/-%-6.2g "
	    "beta=%-7.3g+/-%-6.2g", est_method_name[(int) est_met],
	    alfa, sdev_alfa, beta, sdev_beta);
  else
    sprintf(newline, 
	    "Gamma (%s): f(x)=x^(alfa-1) exp(-x/beta)/"
	    "(beta^alfa Gamma(alfa))  alfa=%-7.3g "
	    "beta=%-7.3g", est_method_name[(int) est_met],
	    alfa, beta);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(modell)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//           SHORT_DESCRIPTION
// Returns a shorter string description of the gamma distribution
char *gamma_distribution::short_description(void)
{
  char *newline= new char[1000];
  
  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, 
	    "Gamma (%s): alfa=%-7.3g+/-%-6.2g "
	    "beta=%-7.3g+/-%-6.2g", est_method_name[(int) est_met],
	    alfa, sdev_alfa, beta, sdev_beta);
  else
    sprintf(newline, 
	    "Gamma (%s): alfa=%-7.3g "
	    "beta=%-7.3g", est_method_name[(int) est_met],
	    alfa, beta);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(modell)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//           FORMULA_PICTURE_PATH
// Returns the location of a picture describing the gamma distribution
char *gamma_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/gamma.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("gamma.xbm").c_str());
#endif // NVE
  return newline;
}

//           GET_ALFA
// Returns the 'alfa' value of this distribution;
double gamma_distribution::get_alfa(void)
{
  return alfa;
}


//           GET_BETA
// Returns the 'beta' value of this distribution;
double gamma_distribution::get_beta(void)
{
  return beta;
}


void gamma_distribution::use_orig_curve(void)
{
  alfa=orig_alfa;
  beta=orig_beta;
}


void gamma_distribution::repick_parameters(void)
{
#ifdef GSL  
  alfa=orig_alfa+gsl_ran_gaussian(gslptr, sdev_alfa);
  beta=orig_beta+gsl_ran_gaussian(gslptr, sdev_beta);
#else
  alfa=orig_alfa+sdev_alfa*gauss();
  beta=orig_beta+sdev_beta*gauss();
#endif // GSL
}



// Returns the MCMC 'alfa' value;
double *gamma_distribution::get_mcmc_alfa(void)
{
  return mcmc_alfa;
}

// Returns the MCMC 'beta' value;
double *gamma_distribution::get_mcmc_beta(void)
{
  return mcmc_beta;
}


  // Get samples quantiles:
double gamma_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return (pow(mcmc_beta[i], -mcmc_alfa[i]) * pow(x,mcmc_alfa[i]-1.0) * 
	  exp(-x/mcmc_beta[i]) / exp(lgamma(mcmc_alfa[i])));
}

double gamma_distribution::mcmc_accumulated_function_sample(double x, 
							    int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return gsl_cdf_gamma_P(x,mcmc_alfa[i],mcmc_beta[i]);
}

double gamma_distribution::mcmc_get_quantile_sample(double prob, 
						    int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return gsl_cdf_gamma_Pinv(prob,mcmc_alfa[i],mcmc_beta[i]);
}



// ************************************************************* //
//                                                               //   
//               PEARSON3_DISTRIBUTION                           //
//                                                               // 
// A subclass of 'distribution' representing a 'Pearson, type 3' //
// distribution (a shifted gamme distribution).                  //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Pearson3 distribution based on a given dataset.
pearson3_distribution::pearson3_distribution(double *val, int len, 
					     double min, double max, 
					     int num_in_distrib, 
					     bool do_accumulate, 
					     ESTIMATION_METHOD use_est_met,
					     bool allow_negative,
					     double *bayes_param_prior_mu, 
					     double *bayes_param_prior_sd,
					     double *bayes_param_prior_p,
					     int num_samples_, 
					     int burnin_, 
					     int spacing_, int num_temp_,
					     bool do_show_mcmc, 
					     bool do_show_debug,
					     bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("Pearson3")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=allow_negative;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=allow_neg ? false : true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<3;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}

pearson3_distribution::pearson3_distribution(double alfa_, double beta_, double mu_,
					     double min, double max, 
					     int num_in_distrib) : 
  distribution("Pearson3")
{
  register int i;

  init();
  init_hyperparameters();
  allow_neg=true;
  numparam=3;
  accumulated_function_exists=true;
  
  est_met=EST_MOMENT;

  // find min and amx values;
  set_min_and_max(min, max, num_in_distrib);
  
  // calculate the 'alfa' and 'beta' parameters;
  alfa = alfa_;
  beta = beta_;
  mu=mu_;

  // traverse the distribution
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      distrib_arg[i] = x; // set the argument array element
      distrib_val[i] = function(x); // set the value array element
    }

  status=DISTRIBUTION_FOUND;
  sdev=sqrt(alfa)*beta;
  mean=alfa*beta;
 
  accumulate();
}

pearson3_distribution::pearson3_distribution() : distribution("Pearson3")
{
  init();
  init_hyperparameters();
  allow_neg=true;
  accumulated_function_exists=true;
  numparam=3;
  accumulated_function_exists=true;
}

pearson3_distribution::~pearson3_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}

void pearson3_distribution::init(void)
{
  mcmc_alfa=NULL;
  mcmc_beta=NULL;
  mcmc_mu=NULL;
  
}

void pearson3_distribution::cleanup(void)
{
  if(mcmc_alfa)
    delete [] mcmc_alfa;
  if(mcmc_beta)
    delete [] mcmc_beta;
  if(mcmc_mu)
    delete [] mcmc_mu;
  init();
}

void pearson3_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=4;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"alfa");
  strcpy(parnames[1],"beta");
  strcpy(parnames[2],"mu");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_BOTH;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[3];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  param_prior_mu[3]=0.0;
  
  param_prior_sd[0]=1000.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  param_prior_sd[3]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.5;
  param_prior_p[2]=0.975;
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
}

void pearson3_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(parstatus)
    delete [] parstatus;
}

//            SET
// Finds a gamma distribution based on a given dataset.
void pearson3_distribution::Set(double *val, int len, 
				double min, double max, int num_in_distrib, 
				bool do_accumulate, 
				ESTIMATION_METHOD use_est_met,
				// Historical (upper) threshold data:
				int num_thresholds, 
				historic_threshold *thresholds,
				// Historical data:
				int num_historical, 
				historic_extreme_data *histdata)
{
  register int i;
  
  est_met=use_est_met;

  // find min and amx values;
  set_min_and_max(min, max, num_in_distrib);
  // Get statistical values;
  get_stats(val, len);
  
  // if statistics couldn't be found...
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  // calculate the 'alfa' and 'beta' parameters;
  alfa=4.0/skew/skew;
  beta=sqrt(alfa/sdev/sdev);
  mu=mean-alfa/beta;

  sdev_alfa=sdev_beta=sdev_mu=MISSING_VALUE;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"logalfa","logbeta","mu"};
      
      int num_extra=0;
      char **p3_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	p3_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	p3_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,p3_param_names,T,0.15, 
			 0,NULL,
			 init_pearson3,logprior_pearson3,loglik_pearson3,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_pearson3,loglik_pearson3);
      
      if(pars)
	{
	  mcmc_alfa=new double[num_mcmc];
	  mcmc_beta=new double[num_mcmc];
	  mcmc_mu=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_alfa[i]=exp(pars[i][0]);
	      mcmc_beta[i]=exp(pars[i][1]);
	      mcmc_mu[i]=pars[i][2];
	    }
	}

      alfa=find_statistics(mcmc_alfa, num_mcmc, MEAN);
      beta=find_statistics(mcmc_beta, num_mcmc, MEAN);
      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sdev_alfa=find_statistics(mcmc_alfa, num_mcmc, STANDARD_DEVIATION);
      sdev_beta=find_statistics(mcmc_beta, num_mcmc, STANDARD_DEVIATION);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(p3_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={log(alfa), log(beta), mu}, *output;
      
      pearson3_likelihood_n=len;   
      pearson3_likelihood_X=val;
      
      output=multinewtonraphson(pearson3_likelihood, 3, input, 1e-7, 
				bufferlen, false);
      
      alfa=exp(output[0]);
      beta=exp(output[1]);
      mu=output[2];

      double **ddf=newton_numeric_doubleder(output); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	{
	  iddf=inverse_matrix(ddf, 3);
	  if(iddf)
	    {
	      sdev_alfa=-iddf[0][0];
	      sdev_beta=-iddf[1][1];
	      sdev_mu=-iddf[2][2];
	      
	      sdev_alfa=sqrt(ABSVAL(sdev_alfa));
	      sdev_beta=sqrt(ABSVAL(sdev_beta));
	      sdev_mu=sqrt(ABSVAL(sdev_mu));
	      
	      delete [] iddf[0];
	      delete [] iddf[1];
	      delete [] iddf[2];
	      delete [] iddf;
	    }
	}
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;

      delete [] output;
    }

  if(!visited)
    {
      orig_alfa=alfa;
      orig_beta=beta;
      visited=true;
    }

  // traverse the distribution
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      distrib_arg[i] = x; // set the argument array element
      distrib_val[i] = function(x); // set the value array element
    }

  if(do_accumulate)
    accumulate();
}


//           FUNCTION
// Returns the value of the Pearson3 distribution for a given argument
double pearson3_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(x>mcmc_mu[i])
	  ret+=(pow(mcmc_beta[i], -mcmc_alfa[i]) * pow(x-mcmc_mu[i],mcmc_alfa[i]-1.0) * 
		exp(-(x-mcmc_mu[i])/mcmc_beta[i]) / exp(lgamma(mcmc_alfa[i])));
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(x<=mu)
    return 0.0;
  else
    return (pow(beta, -alfa) * pow(x-mu,alfa-1) * 
	  exp(-(x-mu)/beta) / exp(lgamma(alfa)));
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gauss distribution 
// for a given argument
double pearson3_distribution::accumulated_function(double x)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(x>mcmc_mu[i])
	  ret+=gsl_cdf_gamma_P(x-mcmc_mu[i],mcmc_alfa[i],mcmc_beta[i]);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(x<=0.0)
    return 0.0;
  else
    return gsl_cdf_gamma_P(x-mu,alfa,beta);
}


double pearson3_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    return distribution::get_quantile(prob);
  else
    return mu+gsl_cdf_gamma_Pinv(prob,alfa,beta);
}



//           PRINTHELP
// Sends a description of the Pearson3 distribution to the output stream;
void pearson3_distribution::printhelp(std::ostream &out)
{
  out << "Pearson3-fordelingen " << std::endl;
  out << "" << std::endl;
  out << "Dette er en treparameter-fordeling med" << std::endl;
  out << "positiv skjevhet (passer for vannf�ringsdata o.l.)." << std::endl;
  out << "Den er en forskj�vet gamma-fordeling, s� den tillater negative verdier, "
    "men bare ned til en nedre verdi (=mu-parameteren)." << std::endl;
  out << "Moment-metoden bruker 1. 2. og 3. ordens momenter (gjennomsnitt, " << 
    std::endl;
  out << "standardavvik og skjevhet) til � tilpasse fordelingen til observasjonene." << 
    std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (6/5-2014)" << std::endl;
}


//           DESCRIPTION
// Returns a short string description of the Pearson 3 distribution
char *pearson3_distribution::description(void)
{
  char *newline= new char[1000];
  
  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, 
	    "Pearson3 (%s): f(x)=(x-mu)^(alfa-1) exp(-(x-mu)/beta)/"
	    "(beta^alfa Gamma(alfa))  alfa=%-7.3g+/-%-6.2g "
	    "beta=%-7.3g+/-%-6.2g mu=%-7.3g+/-%-6.2g", est_method_name[(int) est_met],
	    alfa, sdev_alfa, beta, sdev_beta, mu, sdev_mu);
  else
    sprintf(newline, 
	    "Pearson3 (%s): f(x)=(x-mu)^(alfa-1) exp(-(x-mu)/beta)/"
	    "(beta^alfa Gamma(alfa))  alfa=%-7.3g "
	    "beta=%-7.3g mu=%-7.3g", est_method_name[(int) est_met],
	    alfa, beta, mu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(modell)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//           SHORT_DESCRIPTION
// Returns a shorter string description of the Pearson 3 distribution
char *pearson3_distribution::short_description(void)
{
  char *newline= new char[1000];
  
  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, 
	    "Pearson3 (%s): alfa=%-7.3g+/-%-6.2g "
	    "beta=%-7.3g+/-%-6.2g mu=%-7.3g+/-%-6.2g", est_method_name[(int) est_met],
	    alfa, sdev_alfa, beta, sdev_beta, mu, sdev_mu);
  else
    sprintf(newline, 
	    "Pearson3 (%s): alfa=%-7.3g "
	    "beta=%-7.3g mu=%-7.3g", est_method_name[(int) est_met],
	    alfa, beta,mu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(modell)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//           FORMULA_PICTURE_PATH
// Returns the location of a picture describing the Pearson 3 distribution
char *pearson3_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/pearson3.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("pearson3.xbm").c_str());
#endif // NVE
  return newline;
}

//           GET_ALFA
// Returns the 'alfa' value of this distribution;
double pearson3_distribution::get_alfa(void)
{
  return alfa;
}


//           GET_BETA
// Returns the 'beta' value of this distribution;
double pearson3_distribution::get_beta(void)
{
  return beta;
}

//           GET_MU
// Returns the 'mu' value of this distribution;
double pearson3_distribution::get_mu(void)
{
  return mu;
}


void pearson3_distribution::use_orig_curve(void)
{
  alfa=orig_alfa;
  beta=orig_beta;
  mu=orig_mu;
}


void pearson3_distribution::repick_parameters(void)
{
#ifdef GSL  
  alfa=orig_alfa+gsl_ran_gaussian(gslptr, sdev_alfa);
  beta=orig_beta+gsl_ran_gaussian(gslptr, sdev_beta);
  mu=orig_mu+gsl_ran_gaussian(gslptr, sdev_mu);
#else
  alfa=orig_alfa+sdev_alfa*gauss();
  beta=orig_beta+sdev_beta*gauss();
  mu=orig_mu+sdev_mu*gauss();
#endif // GSL
}



// Returns the MCMC 'alfa' value;
double *pearson3_distribution::get_mcmc_alfa(void)
{
  return mcmc_alfa;
}

// Returns the MCMC 'beta' value;
double *pearson3_distribution::get_mcmc_beta(void)
{
  return mcmc_beta;
}

// Returns the MCMC 'mu' value;
double *pearson3_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}


  // Get samples quantiles:
double pearson3_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(x<=mcmc_mu[i])
    return 0.0;
  
  return (pow(mcmc_beta[i], -mcmc_alfa[i]) * pow(x-mcmc_mu[i],mcmc_alfa[i]-1.0) * 
	  exp(-(x-mcmc_mu[i])/mcmc_beta[i]) / exp(lgamma(mcmc_alfa[i])));
}

double pearson3_distribution::mcmc_accumulated_function_sample(double x, 
							    int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(x<=mcmc_mu[i])
    return 0.0;
  
  return gsl_cdf_gamma_P(x-mcmc_mu[i],mcmc_alfa[i],mcmc_beta[i]);
}

double pearson3_distribution::mcmc_get_quantile_sample(double prob, 
						    int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return mcmc_mu[i]+gsl_cdf_gamma_Pinv(prob,mcmc_alfa[i],mcmc_beta[i]);
}



// ***************************************************************** //
//                                                                   //   
//               LOGPEARSON3_DISTRIBUTION                            //
//                                                                   // 
// A subclass of 'distribution' representing a Log-'Pearson, type 3' //
// distribution (a shifted gamme distribution).                      //
//                                                                   // 
// ***************************************************************** //  

// Constructor
// Makes a Log-Pearson3 distribution based on a given dataset.
logpearson3_distribution::
logpearson3_distribution(double *val, int len, 
			 double min, double max, 
			 int num_in_distrib, 
			 bool do_accumulate, 
			 ESTIMATION_METHOD use_est_met,
			 double *bayes_param_prior_mu, 
			 double *bayes_param_prior_sd,
			 double *bayes_param_prior_p,
			 int num_samples_, 
			 int burnin_, 
			 int spacing_, int num_temp_,
			 bool do_show_mcmc, 
			 bool do_show_debug,
			 bool ratio_based_prior,
			 // Historical (upper) threshold data:
			 int num_thresholds, 
			 historic_threshold *thresholds,
			 // Historical data:
			 int num_historical, 
			 historic_extreme_data *histdata) : 
  distribution("Log-Pearson3")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=false;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  int i;
  
  distribution_strictly_positive_data=true;
  
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<3;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  logq3_mu=param_prior_mu[2];
  logq3_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}

logpearson3_distribution::logpearson3_distribution(double alfa_, double beta_, double mu_,
					     double min, double max, 
					     int num_in_distrib) : 
  distribution("Log-Pearson3")
{
  register int i;

  init();
  init_hyperparameters();
  allow_neg=false;
  distribution_strictly_positive_data=true;
  numparam=3;
  accumulated_function_exists=true;
  
  est_met=EST_MOMENT;

  // find min and amx values;
  set_min_and_max(min, max, num_in_distrib);
  
  // calculate the 'alfa' and 'beta' parameters;
  alfa = alfa_;
  beta = beta_;
  mu=mu_;

  // traverse the distribution
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      distrib_arg[i] = x; // set the argument array element
      distrib_val[i] = function(x); // set the value array element
    }

  status=DISTRIBUTION_FOUND;
  sdev=sqrt(alfa)*beta;
  mean=alfa*beta;
 
  accumulate();
}

logpearson3_distribution::logpearson3_distribution() : distribution("Log-Pearson3")
{
  init();
  init_hyperparameters();
  allow_neg=false;
  numparam=3;
  accumulated_function_exists=true;
}

logpearson3_distribution::~logpearson3_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}

void logpearson3_distribution::init(void)
{
  mcmc_alfa=NULL;
  mcmc_beta=NULL;
  mcmc_mu=NULL;
  
}

void logpearson3_distribution::cleanup(void)
{
  if(mcmc_alfa)
    delete [] mcmc_alfa;
  if(mcmc_beta)
    delete [] mcmc_beta;
  if(mcmc_mu)
    delete [] mcmc_mu;
  init();
}

void logpearson3_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=3;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"alfa");
  strcpy(parnames[1],"beta");
  strcpy(parnames[2],"mu");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_BOTH;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[3];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.5;
  param_prior_p[2]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  logq3_mu=param_prior_mu[2];
  logq3_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
}

void logpearson3_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(parstatus)
    delete [] parstatus;
}

//            SET
// Finds a log-Pearson3 distribution based on a given dataset.
void logpearson3_distribution::Set(double *val, int len, 
				   double min, double max, 
				   int num_in_distrib, 
				   bool do_accumulate, 
				   ESTIMATION_METHOD use_est_met,
				   // Historical (upper) threshold data:
				   int num_thresholds, 
				   historic_threshold *thresholds,
				   // Historical data:
				   int num_historical, 
				   historic_extreme_data *histdata)
{
  register int i;
  
  est_met=use_est_met;

  // find min and amx values;
  set_min_and_max(min, max, num_in_distrib);
  // Get statistical values;
  get_stats(val, len);
  
  // if statistics couldn't be found...
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  double *val2=new double[len];
  for(i=0;i<len;i++)
    val2[i]=log(val[i]);
  pearson3_distribution p3(val2,len,min,max,num_in_distrib,do_accumulate,EST_MOMENT);
  // calculate the 'alfa' and 'beta' parameters;
  alfa=p3.get_alfa();
  beta=p3.get_beta();
  mu=p3.get_mu();

  sdev_alfa=sdev_beta=sdev_mu=MISSING_VALUE;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"logalfa","logbeta","mu"};
      
      int num_extra=0;
      char **lp3_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	lp3_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	lp3_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,lp3_param_names,T,0.15, 
			 0,NULL,
			 init_logpearson3,logprior_logpearson3,loglik_logpearson3,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_logpearson3,loglik_logpearson3);
      
      if(pars)
	{
	  mcmc_alfa=new double[num_mcmc];
	  mcmc_beta=new double[num_mcmc];
	  mcmc_mu=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_alfa[i]=exp(pars[i][0]);
	      mcmc_beta[i]=exp(pars[i][1]);
	      mcmc_mu[i]=pars[i][2];
	    }
	}

      alfa=find_statistics(mcmc_alfa, num_mcmc, MEAN);
      beta=find_statistics(mcmc_beta, num_mcmc, MEAN);
      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sdev_alfa=find_statistics(mcmc_alfa, num_mcmc, STANDARD_DEVIATION);
      sdev_beta=find_statistics(mcmc_beta, num_mcmc, STANDARD_DEVIATION);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(lp3_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={log(alfa), log(beta), mu}, *output;
      
      logpearson3_likelihood_n=len;   
      logpearson3_likelihood_X=val;
      
      output=multinewtonraphson(logpearson3_likelihood, 3, input, 1e-7, 
				bufferlen, false);
      
      alfa=exp(output[0]);
      beta=exp(output[1]);
      mu=output[2];

      double **ddf=newton_numeric_doubleder(output); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	{
	  iddf=inverse_matrix(ddf, 3);
	  if(iddf)
	    {
	      sdev_alfa=-iddf[0][0];
	      sdev_beta=-iddf[1][1];
	      sdev_mu=-iddf[2][2];
	      
	      sdev_alfa=sqrt(ABSVAL(sdev_alfa));
	      sdev_beta=sqrt(ABSVAL(sdev_beta));
	      sdev_mu=sqrt(ABSVAL(sdev_mu));
	      
	      delete [] iddf[0];
	      delete [] iddf[1];
	      delete [] iddf[2];
	      delete [] iddf;
	    }
	}
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;

      delete [] output;
    }

  if(!visited)
    {
      orig_alfa=alfa;
      orig_beta=beta;
      visited=true;
    }

  // traverse the distribution
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      distrib_arg[i] = x; // set the argument array element
      distrib_val[i] = function(x); // set the value array element
    }

  if(do_accumulate)
    accumulate();
}


//           FUNCTION
// Returns the value of the log-Pearson3 distribution for a given argument
double logpearson3_distribution::function(double x)
{
  if(x<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(log(x)>mcmc_mu[i])
	  ret+=(pow(mcmc_beta[i], -mcmc_alfa[i]) * pow(log(x)-mcmc_mu[i],mcmc_alfa[i]-1.0) * 
		exp(-(log(x)-mcmc_mu[i])/mcmc_beta[i]) / exp(lgamma(mcmc_alfa[i])))/x;
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(log(x)<=mu)
    return 0.0;
  else
    return (pow(beta, -alfa) * pow(log(x)-mu,alfa-1) * 
	  exp(-(log(x)-mu)/beta) / exp(lgamma(alfa)))/x;
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gauss distribution 
// for a given argument
double logpearson3_distribution::accumulated_function(double x)
{
  if(x<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(log(x)>mcmc_mu[i])
	  ret+=gsl_cdf_gamma_P(log(x)-mcmc_mu[i],mcmc_alfa[i],mcmc_beta[i]);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(log(x)<=0.0)
    return 0.0;
  else
    return gsl_cdf_gamma_P(log(x)-mu,alfa,beta);
}


double logpearson3_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    return distribution::get_quantile(prob);
  else
    return exp(mu+gsl_cdf_gamma_Pinv(prob,alfa,beta));
}



//           PRINTHELP
// Sends a description of the log-Pearson3 distribution to the output stream;
void logpearson3_distribution::printhelp(std::ostream &out)
{
  out << "Log-Pearson, type 3-fordelingen " << std::endl;
  out << "" << std::endl;
  out << "Dette er en treparameter-fordeling med" << std::endl;
  out << "positiv skjevhet (passer for vannf�ringsdata o.l.)." << std::endl;
  out << "Den tillater ikke negative verdier, "
    "og har i tillegg en nedre positiv grense (fastsatt av mu-parameteren)." << std::endl;
  out << "Moment-metoden bruker 1. 2. og 3. ordens momenter (gjennomsnitt, " << 
    std::endl;
  out << "standardavvik og skjevhet) til � tilpasse fordelingen til observasjonene." << 
    std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (6/5-2014)" << std::endl;
}


//           DESCRIPTION
// Returns a short string description of the log-Pearson3 distribution
char *logpearson3_distribution::description(void)
{
  char *newline= new char[1000];
  
  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, 
	    "Log-Pearson3 (%s): f(x)=(log(x)-mu)^(alfa-1) exp(-(log(x)-mu)/beta)/"
	    "(beta^alfa Gamma(alfa))/x  alfa=%-7.3g+/-%-6.2g "
	    "beta=%-7.3g+/-%-6.2g mu=%-7.3g+/-%-6.2g", est_method_name[(int) est_met],
	    alfa, sdev_alfa, beta, sdev_beta, mu, sdev_mu);
  else
    sprintf(newline, 
	    "Log-Pearson3 (%s): f(x)=(log(x)-mu)^(alfa-1) exp(-(log(x)-mu)/beta)/"
	    "(beta^alfa Gamma(alfa))/x  alfa=%-7.3g "
	    "beta=%-7.3g mu=%-7.3g", est_method_name[(int) est_met],
	    alfa, beta, mu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(modell)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//           SHORT_DESCRIPTION
// Returns a shorter string description of the log-Pearson3 distribution
char *logpearson3_distribution::short_description(void)
{
  char *newline= new char[1000];
  
  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, 
	    "Log-Pearson3 (%s): alfa=%-7.3g+/-%-6.2g "
	    "beta=%-7.3g+/-%-6.2g mu=%-7.3g+/-%-6.2g", est_method_name[(int) est_met],
	    alfa, sdev_alfa, beta, sdev_beta, mu, sdev_mu);
  else
    sprintf(newline, 
	    "Log-Pearson3 (%s): alfa=%-7.3g "
	    "beta=%-7.3g mu=%-7.3g", est_method_name[(int) est_met],
	    alfa, beta,mu);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(modell)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//           FORMULA_PICTURE_PATH
// Returns the location of a picture describing the log-Pearson3 distribution
char *logpearson3_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/logpearson3.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("logpearson3.xbm").c_str());
#endif // NVE
  return newline;
}

//           GET_ALFA
// Returns the 'alfa' value of this distribution;
double logpearson3_distribution::get_alfa(void)
{
  return alfa;
}


//           GET_BETA
// Returns the 'beta' value of this distribution;
double logpearson3_distribution::get_beta(void)
{
  return beta;
}

//           GET_MU
// Returns the 'mu' value of this distribution;
double logpearson3_distribution::get_mu(void)
{
  return mu;
}


void logpearson3_distribution::use_orig_curve(void)
{
  alfa=orig_alfa;
  beta=orig_beta;
  mu=orig_mu;
}


void logpearson3_distribution::repick_parameters(void)
{
#ifdef GSL  
  alfa=orig_alfa+gsl_ran_gaussian(gslptr, sdev_alfa);
  beta=orig_beta+gsl_ran_gaussian(gslptr, sdev_beta);
  mu=orig_mu+gsl_ran_gaussian(gslptr, sdev_mu);
#else
  alfa=orig_alfa+sdev_alfa*gauss();
  beta=orig_beta+sdev_beta*gauss();
  mu=orig_mu+sdev_mu*gauss();
#endif // GSL
}



// Returns the MCMC 'alfa' value;
double *logpearson3_distribution::get_mcmc_alfa(void)
{
  return mcmc_alfa;
}

// Returns the MCMC 'beta' value;
double *logpearson3_distribution::get_mcmc_beta(void)
{
  return mcmc_beta;
}

// Returns the MCMC 'mu' value;
double *logpearson3_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}


  // Get samples quantiles:
double logpearson3_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(x<=0.0 || log(x)<=mcmc_mu[i])
    return 0.0;
  
  return (pow(mcmc_beta[i], -mcmc_alfa[i]) * pow(log(x)-mcmc_mu[i],mcmc_alfa[i]-1.0) * 
	  exp(-(log(x)-mcmc_mu[i])/mcmc_beta[i]) / exp(lgamma(mcmc_alfa[i])))/x;
}

double logpearson3_distribution::mcmc_accumulated_function_sample(double x, 
							    int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(x<=0.0 || log(x)<=mcmc_mu[i])
    return 0.0;
  
  return gsl_cdf_gamma_P(log(x)-mcmc_mu[i],mcmc_alfa[i],mcmc_beta[i]);
}

double logpearson3_distribution::mcmc_get_quantile_sample(double prob, 
							  int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return exp(mcmc_mu[i]+gsl_cdf_gamma_Pinv(prob,mcmc_alfa[i],mcmc_beta[i]));
}



// ************************************************************* //
//                                                               //   
//               BETA_DISTRIBUTION                               //
//                                                               // 
// A subclass of 'distribution' representing a 'beta'            //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a beta distribution based on a given dataset.
beta_distribution::beta_distribution(double *val, int len, 
				     double min, double max, 
				     int num_in_distrib, 
				     bool do_accumulate, 
				     ESTIMATION_METHOD use_est_met,
				     double *bayes_param_prior_mu, 
				     double *bayes_param_prior_sd,
				     double *bayes_param_prior_p,
				     int num_samples_, 
				     int burnin_, 
				     int spacing_, int num_temp_,
				     bool do_show_mcmc, 
				     bool do_show_debug,
				     bool ratio_based_prior,
				     // Historical (upper) threshold data:
				     int num_thresholds, 
				     historic_threshold *thresholds,
				     // Historical data:
				     int num_historical, 
				     historic_extreme_data *histdata) : 
  distribution("beta")
{
  init();
  init_hyperparameters();
  allow_neg=false;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  numparam=2; // min and max are set explicitely and are not counted here
  
  distribution_strictly_positive_data=allow_neg ? false : true;
  
  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];

  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


beta_distribution::beta_distribution() : distribution("beta")
{
  init();
  init_hyperparameters();
  allow_neg=false;
  numparam=2;
  accumulated_function_exists=true;
}

beta_distribution::~beta_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}

void beta_distribution::init(void)
{
  mcmc_alfa=NULL;
  mcmc_beta=NULL;
  
}

void beta_distribution::cleanup(void)
{
  if(mcmc_alfa)
    delete [] mcmc_alfa;
  if(mcmc_beta)
    delete [] mcmc_beta;
  init();
}

void beta_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=2;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"alfa");
  strcpy(parnames[1],"beta");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void beta_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}

//              SET
// Finds a beta distribution based on a given dataset.
void beta_distribution::Set(double *val, int len, 
			    double min, double max, int num_in_distrib, 
			    bool do_accumulate, 
			    ESTIMATION_METHOD use_est_met,
			    // Historical (upper) threshold data:
			    int num_thresholds, 
			    historic_threshold *thresholds,
			    // Historical data:
			    int num_historical, 
			    historic_extreme_data *histdata)
{
  double sdev_redist, mean_redist;
  register int i;
  
  est_met=use_est_met;
  
  // find min and max values;
  set_min_and_max(min, max, num_in_distrib);
  // Find statistical values;
  get_stats(val, len);
  
  // if statistical data couldn't be made;
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;
  
  // Find the 'alfa' and 'beta' parameters;
  alfa = mean*mean/sdev/sdev;
  beta = sdev*sdev/mean; 

  // find the normalized (from 0 to 1) mean value;
  mean_redist = (mean-minval)/(maxval-minval);
  // find the normalized standard deviation;
  sdev_redist = sdev/(maxval-minval);
  // normalize the 'alfa' parameter;
  alfa=((1.0 - mean_redist) * (mean_redist * mean_redist) / 
	(sdev_redist * sdev_redist)) - 
    mean_redist;
  // normalize the 'beta' parameter;
  beta = alfa * (1.0 / mean_redist - 1.0);
  sdev_alfa=sdev_beta=MISSING_VALUE;

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"logalfa","logbeta"};
      // logalfa_mu, logalfa_sd, logbeta_mu, logbeta_sd
      
      int num_extra=0;
      char **beta_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	beta_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
      else
	beta_param_names=dist_copy_strings(names, numparam);

      beta_min=(minval==0.0 ? 0.0 : minval-1e-7);
      beta_max=(maxval==1.0 ? 1.0 : maxval+1e-7);
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,beta_param_names,T,0.15, 
			 0,NULL,
			 init_beta,logprior_beta,loglik_beta,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_beta,loglik_beta);
      
      if(pars)
	{
	  mcmc_alfa=new double[num_mcmc];
	  mcmc_beta=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_alfa[i]=exp(pars[i][0]);
	      mcmc_beta[i]=exp(pars[i][1]);
	    }
	}

      alfa=find_statistics(mcmc_alfa, num_mcmc, MEAN);
      beta=find_statistics(mcmc_beta, num_mcmc, MEAN);
      sdev_alfa=find_statistics(mcmc_alfa, num_mcmc, STANDARD_DEVIATION);
      sdev_beta=find_statistics(mcmc_beta, num_mcmc, STANDARD_DEVIATION);
      
      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(beta_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double startparams[]={alfa,beta};

      beta_likelihood_n=len;
      beta_likelihood_X=val;
      beta_min=(minval==0.0 ? 0.0 : minval-1e-7);
      beta_max=(maxval==1.0 ? 1.0 : maxval+1e-7);
      
      double *params=multinewtonraphson(beta_likelihood, 2, 
					startparams, 1e-7, 
					bufferlen, false);
      alfa=params[0];
      beta=params[1];

      double **ddf=newton_numeric_doubleder(params); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,2),0.0))
	iddf=inverse_matrix(ddf, 2);
      else
	iddf=make_matrix(2,2);

      sdev_alfa=-iddf[0][0];
      sdev_beta=-iddf[1][1];

      sdev_alfa=sqrt(ABSVAL(sdev_alfa));
      sdev_beta=sqrt(ABSVAL(sdev_beta));

      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf;
      delete [] iddf[0];
      delete [] iddf[1];
      delete [] iddf;

      delete [] params;
    }

  if(!visited)
    {
      orig_alfa=alfa;
      orig_beta=beta;
      visited=true;
    }

  // set a buffer value;
  betafunc=exp(lgamma(alfa))*exp(lgamma(beta))/
    exp(lgamma(alfa+beta));

  // traverse the distribution;
  for(i=0; i< distrib_len; i++)
    {
      // find the argument
      double x = min + ((double) i)*step;
      
      distrib_arg[i] = x; // set the argument element
      distrib_val[i] = function(x); // set the value element
    }
      
  if(do_accumulate)
    accumulate();
}


//           FUNCTION
// Returns the value of the beta distribution for a given argument
double beta_distribution::function(double arg)
{
  if(arg<=minval || arg>=maxval)
    return 0.0;

  double x=(arg-minval)/(maxval-minval);
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=pow(x, mcmc_alfa[i]-1.0) * pow(1.0-x, mcmc_beta[i]-1.0)*
	  exp(lgamma(mcmc_alfa[i]+mcmc_beta[i]))/
	  (exp(lgamma(mcmc_alfa[i]))*exp(lgamma(mcmc_beta[i]))) / (maxval-minval);
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return (pow(x, alfa-1.0) * pow(1.0-x, beta-1.0) / 
	  betafunc) /(maxval-minval);
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated beta distribution 
// for a given argument
double beta_distribution::accumulated_function(double arg)
{
  if(arg<=minval)
    return 0.0;
  else if(arg>maxval)
    return 1.0;
  
  double x=(arg-minval)/(maxval-minval);
  
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=gsl_cdf_beta_P(x,mcmc_alfa[i],mcmc_beta[i]);
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return gsl_cdf_beta_P(x,alfa,beta);
}


double beta_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_beta)
    return distribution::get_quantile(prob);
  else
    return minval+(maxval-minval)*gsl_cdf_beta_Pinv(prob,alfa,beta);
}



//          PRINTHELP
// Sends a description of the beta distribution to the output stream;
void beta_distribution::printhelp(std::ostream &out)
{
  out << "Betafordelingen" << std::endl;
  out << "" << std::endl;
  out << "Dette er en toparameter-fordeling der verdiene har en " << std::endl;
  out << "�vre og en nedre grense, nemlig 1 og 0 henholdsvis." << std::endl;
  out << "En b�r passe p� � manuelt sette �vre og nedre grense p�" << std::endl;
  out << "verdi-aksen, da dette er grensene som vil brukes i" << std::endl;
  out << "betafordelings-approksimasjonen. Den nedre grensen b�r" << std::endl;
  out << "v�re litt mindre enn den minste verdien som finnes i" << std::endl;
  out << "utvalget av verdier. Tilsvarende b�r den �vre grensen" << std::endl;
  out << "litt h�yere enn den st�rste verdien i utvalget." << std::endl;
  out << "Moment-metoden bruker 1. og 2.ordens momenter (gjennomsnitt og" << 
    std::endl;
  out << "standardavvik) til � tilpasse fordelingen til observasjonene." << 
    std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (10/5-1999)" << std::endl;
}


//            DESCRIPTION
// Returns a short string description of the beta distribution
char *beta_distribution::description(void)
{
  char *newline= new char[1000];

  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, "Beta (%s):  f(x)=(x-min)^(alfa-1)  "
	    "(max-x)^(beta-1)/B(alfa,beta)  alfa=%-7.3g+/-%6.2g "
	    "beta=%-7.3g+/-%6.2g", est_method_name[(int) est_met], 
	    alfa, sdev_alfa, beta, sdev_beta);
  else
    sprintf(newline, "Beta (%s):  f(x)=(x-min)^(alfa-1)  "
	    "(max-x)^(beta-1)/B(alfa,beta)  alfa=%-7.3g "
	    "beta=%-7.3g", est_method_name[(int) est_met], 
	    alfa, beta);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//            SHORT_DESCRIPTION
// Returns a shorter string description of the beta distribution
char *beta_distribution::short_description(void)
{
  char *newline= new char[1000];

  if(sdev_alfa!=MISSING_VALUE && sdev_beta!=MISSING_VALUE)
    sprintf(newline, "Beta (%s): alfa=%-7.3g+/-%6.2g "
	    "beta=%-7.3g+/-%6.2g", est_method_name[(int) est_met], 
	    alfa, sdev_alfa, beta, sdev_beta);
  else
    sprintf(newline, "Beta (%s): alfa=%-7.3g "
	    "beta=%-7.3g", est_method_name[(int) est_met], 
	    alfa, beta);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(model)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


//            FORMULA_PICTURE_PATH
// Returns the location of a picture describing the beta distribution
char *beta_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/beta.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("beta.xbm").c_str());
#endif // NVE
  return newline;
}


//          GET_ALFA
// Returns the 'alfa' value;
double beta_distribution::get_alfa(void)
{
  return alfa;
}

//          GET_BETA
// Returns the 'beta' value;
double beta_distribution::get_beta(void)
{
  return beta;
}


void beta_distribution::use_orig_curve(void)
{
  alfa=orig_alfa;
  beta=orig_beta;
}


void beta_distribution::repick_parameters(void)
{
#ifdef GSL
  alfa=orig_alfa+gsl_ran_gaussian(gslptr, sdev_alfa);
  beta=orig_beta+gsl_ran_gaussian(gslptr, sdev_beta);
#else
  alfa=orig_alfa+sdev_alfa*gauss();
  beta=orig_beta+sdev_beta*gauss();
#endif //  GSL
}


// Returns the MCMC 'alfa' value;
double *beta_distribution::get_mcmc_alfa(void)
{
  return mcmc_alfa;
}

// Returns the MCMC 'beta' value;
double *beta_distribution::get_mcmc_beta(void)
{
  return mcmc_beta;
}


  // Get samples quantiles:
double beta_distribution::mcmc_function_sample(double arg, int sample_index)
{
  if(arg<=minval || arg>=maxval)
    return 0.0;

  double x=(arg-minval)/(maxval-minval);

  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return pow(x, mcmc_alfa[i]-1.0) * pow(1.0-x, mcmc_beta[i]-1.0)*
    exp(lgamma(mcmc_alfa[i]+mcmc_beta[i]))/
    (exp(lgamma(mcmc_alfa[i]))*exp(lgamma(mcmc_beta[i])));
}

double beta_distribution::mcmc_accumulated_function_sample(double arg, 
							   int sample_index)
{
  if(arg<=minval)
    return 0.0;
  else if(arg>maxval)
    return 1.0;
  
  double x=(arg-minval)/(maxval-minval);
  
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return gsl_cdf_gamma_P(x,mcmc_alfa[i],mcmc_beta[i]);
}

double beta_distribution::mcmc_get_quantile_sample(double prob, 
						   int sample_index)
{
  if(num_mcmc<=0 || !mcmc_alfa || !mcmc_beta ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return minval+(maxval-minval)*gsl_cdf_beta_Pinv(prob,mcmc_alfa[i],mcmc_beta[i]);
}







// ************************************************************* //
//                                                               //   
//               GUMBEL_DISTRIBUTION                             //
//                                                               // 
// A subclass of 'distribution' representing a Gumbel            //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Gumbel distribution based on a given dataset.
gumbel_distribution::gumbel_distribution(double *val, int len, 
					 double min, double max, 
					 int num_in_distrib, 
					 bool do_accumulate, 
					 ESTIMATION_METHOD use_est_met,
					 bool allow_negative,
					 double *bayes_param_prior_mu, 
					 double *bayes_param_prior_sd, 
					 double *bayes_param_prior_p,
					 int num_samples_, int burnin_, 
					 int spacing_, int num_temp_,
					 bool do_show_mcmc, 
					 bool do_show_debug,
					 bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("gumbel")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=allow_negative;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;

  distribution_strictly_positive_data=allow_negative ? false : true;
  
  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];

  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}

gumbel_distribution::gumbel_distribution() : distribution("gumbel")
{
  init();
  init_hyperparameters();
  allow_neg=true;
  numparam=2;
  accumulated_function_exists=true;
}

gumbel_distribution::~gumbel_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void gumbel_distribution::init(void)
{
  mcmc_alfa=NULL;
  mcmc_u=NULL;
  
}

void gumbel_distribution::cleanup(void)
{
  if(mcmc_alfa)
    delete [] mcmc_alfa;
  if(mcmc_u)
    delete [] mcmc_u;
  init();
}

void gumbel_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=3;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"alfa");
  strcpy(parnames[1],"u");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_BOTH;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  
  param_prior_sd[0]=1000.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void gumbel_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}

//             SET
// Finds a Gumbel distribution based on a given dataset.
void gumbel_distribution::Set(double *val, int len, 
			      double min, double max, int num_in_distrib, 
			      bool do_accumulate, 
			      ESTIMATION_METHOD use_est_met,
			     // Historical (upper) threshold data:
			     int num_thresholds, 
			     historic_threshold *thresholds,
			     // Historical data:
			     int num_historical, 
			     historic_extreme_data *histdata)
{
  register int i;

  cleanup();
  est_met=use_est_met;

  // Find min and max values;
  set_min_and_max(min, max, num_in_distrib);
  // Retrieve statistical values;
  get_stats(val, len);
  
  // If no such values could be found..
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;
  
  if(status==DISTRIBUTION_FOUND)
    {
      // Calculate the 'alfa' and 'u' parameters;
      //alfa = sqrt(6)*sdev/pi;
      //u = mean - 0.5772 * alfa;
      double lambda2=2.0*b1-b0;
      alfa = lambda2/log(2.0);
      u = b0 - 0.57721566*alfa;
      sdev_alfa=sdev_u=MISSING_VALUE;
    }

  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"logalfa","u"};
      
      int num_extra=0;
      char **gumbel_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	gumbel_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata,
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	gumbel_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,gumbel_param_names,T,0.15, 
			 0,NULL,
			 init_gumbel,logprior_gumbel,loglik_gumbel,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_gumbel,loglik_gumbel);
      
      if(pars)
	{
	  mcmc_alfa=new double[num_mcmc];
	  mcmc_u=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_alfa[i]=exp(pars[i][0]);
	      mcmc_u[i]=pars[i][1];
	    }
	}

      alfa=find_statistics(mcmc_alfa, num_mcmc, MEAN);
      u=find_statistics(mcmc_u, num_mcmc, MEAN);
      sdev_alfa=find_statistics(mcmc_alfa, num_mcmc, STANDARD_DEVIATION);
      sdev_u=find_statistics(mcmc_u, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(gumbel_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={sqrt(alfa),u}, *output;
      
      gumbel_likelihood_n=len;     
      gumbel_likelihood_X=val;
      
      output=gsl_optimization_cover(gumbel_likelihood, 2, input, 1e-7, 
				    bufferlen, false);
      
      alfa=output[0]*output[0];
      u=output[1];
      
      set_newton_dimension(2);
      set_newton_func(gumbel_likelihood);
      set_newton_derivated_func(newton_numeric_derivated);
      double **ddf=newton_numeric_doubleder(output);
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,2),0.0))
	iddf=inverse_matrix(ddf, 2);
      else
	iddf=make_matrix(2,2);
      
      sdev_alfa=-iddf[0][0];
      sdev_u=-iddf[1][1];
      
      sdev_alfa=sqrt(ABSVAL(sdev_alfa));
      sdev_u=sqrt(ABSVAL(sdev_u));
      
      doubledelete(ddf,2);
      doubledelete(iddf,2);

      delete [] output;
    }
  
  if(!visited)
    {
      orig_alfa=alfa;
      orig_u=u;
      visited=true;
    }

  // traverse the distribution;
  for(i=0; i< distrib_len; i++)
    {
      // Find the argmuent;
      double x = min + ((double) i)*step;

      distrib_arg[i] = x;  // set the argument element    
      distrib_val[i] = function(x); // set the value element
    }

  if(do_accumulate)
    accumulate();
}


//           FUNCTION
// Returns the value of the Gumbel distribution for a given argument
double gumbel_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_u)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=((1.0/mcmc_alfa[i]) * exp(-(x-mcmc_u[i])/mcmc_alfa[i] - 
				       exp(-(x-mcmc_u[i])/mcmc_alfa[i])));
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return ((1.0/alfa) * exp(-(x-u)/alfa - 
			   exp(-(x-u)/alfa)));
}

//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gumbel distribution 
// for a given argument
double gumbel_distribution::accumulated_function(double x)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_u)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=exp(-exp(-(x-mcmc_u[i])/mcmc_alfa[i]));
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return exp(-exp(-(x-u)/alfa));
}

double gumbel_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_u)
    return distribution::get_quantile(prob);
  else
    return u-alfa*log(-log(prob));
}

  
//             PRINTHELP
// Sends a description of the Gumbel distribution to the output stream;
void gumbel_distribution::printhelp(std::ostream &out)
{
  out << "Gumbelfordelingen" << std::endl;
  out << "" << std::endl;
  out << "Dette er en toparameter-fordeling som ofte brukes "
    "i forbindelse med" << std::endl;
  out << "ekstremverdi-analyse, f.eks. flomfrekvensanalyse." << std::endl;
  out << "Moment-metoden finner i dette tilfelle fordelingen ved � bruke " <<
    std::endl;
  out << "l-momenter (b0 og b1)." << std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (7/5-1999)" << std::endl;
}


//             DESCRIPTION
// Returns a short string description of the Gumbel distribution
char *gumbel_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_alfa!=MISSING_VALUE && sdev_u!=MISSING_VALUE)
    sprintf(newline, "Gumbel (%s): f(x)=(1/alfa)exp(-(x-u)/alfa-"
	    "exp(-(x-u)/alfa))  alfa=%-7.3g+-%-6.2g u=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], alfa, sdev_alfa, u, sdev_u);
  else
    sprintf(newline, "Gumbel (%s): f(x)=(1/alfa)exp(-(x-u)/alfa-"
	    "exp(-(x-u)/alfa))  alfa=%-7.3g u=%-7.3g", 
	    est_method_name[(int) est_met], alfa, u);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//             SHORT_DESCRIPTION
// Returns a shorter string description of the Gumbel distribution
char *gumbel_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_alfa!=MISSING_VALUE && sdev_u!=MISSING_VALUE)
    sprintf(newline, "Gumbel (%s): alfa=%-7.3g+-%-6.2g u=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], alfa, sdev_alfa, u, sdev_u);
  else
    sprintf(newline, "Gumbel (%s): alfa=%-7.3g u=%-7.3g", 
	    est_method_name[(int) est_met], alfa, u);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//             FORMULA_PICTURE_PATH
// Returns the location of a picture describing the Gumbel distribution
char *gumbel_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/gumbel.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("gumbel.xbm").c_str());
#endif // NVE
  return newline;
}


//              GET_ALFA
// Returns the 'alfa' value;
double gumbel_distribution::get_alfa(void)
{
  return alfa;
}


//              GET_U
// Returns the 'u' value;
double gumbel_distribution::get_u(void)
{
  return u;
}

void gumbel_distribution::use_orig_curve(void)
{
  alfa=orig_alfa;
  u=orig_u;
}


// Returns the MCMC 'alfa' value;
double *gumbel_distribution::get_mcmc_alfa(void)
{
  return mcmc_alfa;
}

// Returns the MCMC 'u' value;
double *gumbel_distribution::get_mcmc_u(void)
{
  return mcmc_u;
}


  // Get samples quantiles:
double gumbel_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_u || !mcmc_alfa ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return ((1.0/mcmc_alfa[i]) * exp(-(x-mcmc_u[i])/mcmc_alfa[i] - 
			   exp(-(x-mcmc_u[i])/mcmc_alfa[i])));
}

double gumbel_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_u || !mcmc_alfa ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return exp(-exp(-(x-mcmc_u[i])/mcmc_alfa[i]));
}

double gumbel_distribution::mcmc_get_quantile_sample(double prob, 
						     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_u || !mcmc_alfa ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return mcmc_u[i]-mcmc_alfa[i]*log(-log(prob));
}

  
void gumbel_distribution::repick_parameters(void)
{
#ifdef GSL
  alfa=orig_alfa+gsl_ran_gaussian(gslptr, sdev_alfa);
  u=orig_u+gsl_ran_gaussian(gslptr, sdev_u);
#else
  alfa=orig_alfa+sdev_alfa*gauss();
  u=orig_u+sdev_u*gauss();
#endif // GSL
}


// ************************************************************* //
//                                                               //   
//               LOGGUMBEL_DISTRIBUTION                          //
//                                                               // 
// A subclass of 'distribution' representing a log-Gumbel        //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a log-Gumbel distribution based on a given dataset.
loggumbel_distribution::loggumbel_distribution(double *val, int len, 
					       double min, double max, 
					       int num_in_distrib, 
					       bool do_accumulate, 
					       ESTIMATION_METHOD use_est_met,
					       double *bayes_param_prior_mu, 
					       double *bayes_param_prior_sd, 
					       double *bayes_param_prior_p,
					       int num_samples_, int burnin_, 
					       int spacing_, int num_temp_,
					       bool do_show_mcmc, 
					       bool do_show_debug,
					       bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("loggumbel")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=false;
  accumulated_function_exists=true;
  distribution_strictly_positive_data=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  
  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];

  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}

loggumbel_distribution::loggumbel_distribution() : distribution("loggumbel")
{
  init();
  init_hyperparameters();
  allow_neg=false;
  distribution_strictly_positive_data=true;
  numparam=2;
  accumulated_function_exists=true;
}

loggumbel_distribution::~loggumbel_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}


void loggumbel_distribution::init(void)
{
  mcmc_alfa=NULL;
  mcmc_u=NULL;
  
}

void loggumbel_distribution::cleanup(void)
{
  if(mcmc_alfa)
    delete [] mcmc_alfa;
  if(mcmc_u)
    delete [] mcmc_u;
  init();
}

void loggumbel_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=2;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"alfa");
  strcpy(parnames[1],"u");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_BOTH;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void loggumbel_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}

//             SET
// Finds a log-Gumbel distribution based on a given dataset.
void loggumbel_distribution::Set(double *val, int len, 
			      double min, double max, int num_in_distrib, 
			      bool do_accumulate, 
			      ESTIMATION_METHOD use_est_met,
				 // Historical (upper) threshold data:
				 int num_thresholds, 
				 historic_threshold *thresholds,
				 // Historical data:
				 int num_historical, 
				 historic_extreme_data *histdata)
{
  register int i;

  cleanup();
  est_met=use_est_met;

  // Find min and max values;
  set_min_and_max(min, max, num_in_distrib);
  // Retrieve statistical values;
  get_stats(val, len);
  
  // If no such values could be found..
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  // Calculate p-moment estimates by log-transforming and applying the Gumbel
  // distribution
 
  double *val2=new double[len];
  for(i=0;i<len;i++)
    val2[i]=log(val[i]);
  gumbel_distribution gumb(val2, len, min, max, num_in_distrib, do_accumulate,EST_LMOMENT);      
  delete [] val2;

  alfa = gumb.get_alfa();
  u = gumb.get_u();;
  sdev_alfa=sdev_u=MISSING_VALUE;
  
  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,1.7,2.4,3.4,4.6,5.8,7.0,8.0};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      char *names[]={"logalfa","u"};
      
      int num_extra=0;
      char **lg_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	lg_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	lg_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,lg_param_names,T,0.15, 
			 0,NULL,
			 init_loggumbel,logprior_loggumbel,loglik_loggumbel,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_loggumbel,loglik_loggumbel);
      
      if(pars)
	{
	  mcmc_alfa=new double[num_mcmc];
	  mcmc_u=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_alfa[i]=exp(pars[i][0]);
	      mcmc_u[i]=pars[i][1];
	    }
	}
      
      alfa=find_statistics(mcmc_alfa, num_mcmc, MEAN);
      u=find_statistics(mcmc_u, num_mcmc, MEAN);
      sdev_alfa=find_statistics(mcmc_alfa, num_mcmc, STANDARD_DEVIATION);
      sdev_u=find_statistics(mcmc_u, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(lg_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={sqrt(alfa),u}, *output;
      
      loggumbel_likelihood_n=len;     
      loggumbel_likelihood_X=val;
      
      output=gsl_optimization_cover(loggumbel_likelihood, 2, input, 1e-7, 
				    bufferlen, false);
      
      alfa=output[0]*output[0];
      u=output[1];
      
      set_newton_dimension(2);
      set_newton_func(loggumbel_likelihood);
      set_newton_derivated_func(newton_numeric_derivated);
      double **ddf=newton_numeric_doubleder(output);
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,2),0.0))
	iddf=inverse_matrix(ddf, 2);
      else
	iddf=make_matrix(2,2);
      
      sdev_alfa=-iddf[0][0];
      sdev_u=-iddf[1][1];
      
      sdev_alfa=sqrt(ABSVAL(sdev_alfa));
      sdev_u=sqrt(ABSVAL(sdev_u));
      
      doubledelete(ddf,2);
      doubledelete(iddf,2);

      delete [] output;
    }
  
  if(!visited)
    {
      orig_alfa=alfa;
      orig_u=u;
      visited=true;
    }

  // traverse the distribution;
  for(i=0; i< distrib_len; i++)
    {
      // Find the argmuent;
      double x = min + ((double) i)*step;

      distrib_arg[i] = x;  // set the argument element    
      distrib_val[i] = function(x); // set the value element
    }

  if(do_accumulate)
    accumulate();
}


//           FUNCTION
// Returns the value of the log-Gumbel distribution for a given argument
double loggumbel_distribution::function(double x)
{
  if(x<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_alfa && mcmc_u)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=((1.0/mcmc_alfa[i]/x) * exp(-(log(x)-mcmc_u[i])/mcmc_alfa[i] - 
				       exp(-(log(x)-mcmc_u[i])/mcmc_alfa[i])));
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return ((1.0/alfa/x) * exp(-(log(x)-u)/alfa - 
			       exp(-(log(x)-u)/alfa)));
}

//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated log-Gumbel distribution 
// for a given argument
double loggumbel_distribution::accumulated_function(double x)
{
  if(x<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_alfa && mcmc_u)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	ret+=exp(-exp(-(log(x)-mcmc_u[i])/mcmc_alfa[i]));
      ret/=double(num_mcmc);
      
      return ret;
    }
  else
    return exp(-exp(-(log(x)-u)/alfa));
}

double loggumbel_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_alfa && mcmc_u)
    return distribution::get_quantile(prob);
  else
    return exp(u-alfa*log(-log(prob)));
}

  
//             PRINTHELP
// Sends a description of the log-Gumbel distribution to the output stream;
void loggumbel_distribution::printhelp(std::ostream &out)
{
  out << "Gumbelfordelingen" << std::endl;
  out << "" << std::endl;
  out << "Dette er en toparameter-fordeling som kan brukes "
    "i forbindelse med" << std::endl;
  out << "ekstremverdi-analyse p� strengt positive data, f.eks. flomfrekvensanalyse." << std::endl;
  out << "Moment-metoden finner i dette tilfelle fordelingen ved � bruke " <<
    std::endl;
  out << "l-momenter (b0 og b1) for log-transformerte data." << std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (5/5-2014)" << std::endl;
}


//             DESCRIPTION
// Returns a short string description of the log-Gumbel distribution
char *loggumbel_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_alfa!=MISSING_VALUE && sdev_u!=MISSING_VALUE)
    sprintf(newline, "Log-Gumbel (%s): f(x)=(1/alfa*x)exp(-(log(x)-u)/alfa-"
	    "exp(-(log(x)-u)/alfa))  alfa=%-7.3g+-%-6.2g u=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], alfa, sdev_alfa, u, sdev_u);
  else
    sprintf(newline, "Log-Gumbel (%s): f(x)=(1/alfa*x)exp(-(log(x)-u)/alfa-"
	    "exp(-(log(x)-u)/alfa))  alfa=%-7.3g u=%-7.3g", 
	    est_method_name[(int) est_met], alfa, u);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//             SHORT_DESCRIPTION
// Returns a shorter string description of the log-Gumbel distribution
char *loggumbel_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_alfa!=MISSING_VALUE && sdev_u!=MISSING_VALUE)
    sprintf(newline, "Log-Gumbel (%s): alfa=%-7.3g+-%-6.2g u=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met], alfa, sdev_alfa, u, sdev_u);
  else
    sprintf(newline, "Log-Gumbel (%s): alfa=%-7.3g u=%-7.3g", 
	    est_method_name[(int) est_met], alfa, u);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//             FORMULA_PICTURE_PATH
// Returns the location of a picture describing the log-Gumbel distribution
char *loggumbel_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/loggumbel.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("loggumbel.xbm").c_str());
#endif // NVE
  return newline;
}


//              GET_ALFA
// Returns the 'alfa' value;
double loggumbel_distribution::get_alfa(void)
{
  return alfa;
}


//              GET_U
// Returns the 'u' value;
double loggumbel_distribution::get_u(void)
{
  return u;
}

void loggumbel_distribution::use_orig_curve(void)
{
  alfa=orig_alfa;
  u=orig_u;
}


// Returns the MCMC 'alfa' value;
double *loggumbel_distribution::get_mcmc_alfa(void)
{
  return mcmc_alfa;
}

// Returns the MCMC 'u' value;
double *loggumbel_distribution::get_mcmc_u(void)
{
  return mcmc_u;
}


  // Get samples quantiles:
double loggumbel_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_u || !mcmc_alfa ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return ((1.0/mcmc_alfa[i]/x) * exp(-(log(x)-mcmc_u[i])/mcmc_alfa[i] - 
			   exp(-(log(x)-mcmc_u[i])/mcmc_alfa[i])));
}

double loggumbel_distribution::mcmc_accumulated_function_sample(double x, 
								int sample_index)
{
  if(num_mcmc<=0 || !mcmc_u || !mcmc_alfa ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  return exp(-exp(-(log(x)-mcmc_u[i])/mcmc_alfa[i]));
}

double loggumbel_distribution::mcmc_get_quantile_sample(double prob, 
							int sample_index)
{
  if(num_mcmc<=0 || !mcmc_u || !mcmc_alfa ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  int i=sample_index;
  return exp(mcmc_u[i]-mcmc_alfa[i]*log(-log(prob)));
}

  
void loggumbel_distribution::repick_parameters(void)
{
#ifdef GSL
  alfa=orig_alfa+gsl_ran_gaussian(gslptr, sdev_alfa);
  u=orig_u+gsl_ran_gaussian(gslptr, sdev_u);
#else
  alfa=orig_alfa+sdev_alfa*gauss();
  u=orig_u+sdev_u*gauss();
#endif // GSL
}



// ************************************************************* //
//                                                               //   
//               GEV_DISTRIBUTION                                //
//                                                               // 
// A subclass of 'distribution' representing a GEV (General      //
// Extreme Value) distribution.                                  //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a GEV distribution based on a given dataset.
gev_distribution::gev_distribution(double *val, int len, 
				   double min, double max, 
				   int num_in_distrib, 
				   bool do_accumulate, 
				   ESTIMATION_METHOD use_est_met,
				   bool allow_negative,
				   // hyper-parameter specification 
				   // should match 'num_par_combi' in length
				   double *bayes_param_prior_mu, 
				   double *bayes_param_prior_sd,
				   double *bayes_param_prior_p,
				   int num_samples_, int burnin_, 
				   int spacing_, int num_temp_,
				   bool do_show_mcmc, 
				   bool do_show_debug,
				   bool ratio_based_prior,
				   // Historical (upper) threshold data:
				   int num_thresholds, 
				   historic_threshold *thresholds,
				   // Historical data:
				   int num_historical, 
				   historic_extreme_data *histdata) : 
  distribution("GEV")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=allow_negative;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  
  distribution_strictly_positive_data=allow_negative ? false : true;

  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<3;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];

  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


// Constructor
// Makes a GEV distribution based on parameter sepcification:
gev_distribution::gev_distribution(double mu_, double sigma_, double ksi_,
				   double min, double max, 
				   int num_in_distrib, 
				   bool do_accumulate) : 
  distribution("GEV")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=true;
  accumulated_function_exists=true;
  Set(mu_, sigma_, ksi_, min, max, num_in_distrib, do_accumulate);
}

gev_distribution::gev_distribution() : distribution("GEV")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=true;
  accumulated_function_exists=true;
}

gev_distribution::~gev_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}

void gev_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  mcmc_ksi=NULL;
}

void gev_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  if(mcmc_ksi)
    delete [] mcmc_ksi;
  init();
}

void gev_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=2;
  num_par_combi=4;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  strcpy(parnames[2],"ksi");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_REAL;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[3];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  param_prior_mu[3]=0.0;
  
  param_prior_sd[0]=1000.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  param_prior_sd[3]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.5;
  param_prior_p[2]=0.975;
  
  q1_mu=param_prior_mu[0];
  q1_sd=param_prior_sd[0];
  logq1_mu=param_prior_mu[1];
  logq1_sd=param_prior_sd[1];
  logq2_mu=param_prior_mu[2];
  logq2_sd=param_prior_sd[2];
  logq3_mu=param_prior_mu[3];
  logq3_sd=param_prior_sd[3];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
}

void gev_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}

//             SET
// Finds a GEV distribution based on a given dataset.
void gev_distribution::Set(double *val, int len, 
			   double min, double max, int num_in_distrib, 
			   bool do_accumulate, 
			   ESTIMATION_METHOD use_est_met,
			   // Historical (upper) threshold data:
			   int num_thresholds, 
			   historic_threshold *thresholds,
			   // Historical data:
			   int num_historical, 
			   historic_extreme_data *histdata)
{
  register int i;

  est_met=use_est_met;
  
  // Find min and max values;
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      set_min_and_max(min, max, num_in_distrib);
      // Retrieve statistical values;
      get_stats(val, len);
      
      // If no such values could be found..
      if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
	return;
    }

  if(status==DISTRIBUTION_FOUND)
    {
      double c = (2.0*b1-b0)/(3.0*b2-b0) - log(2.0)/log(3.0);
      ksi = -7.8590*c - 2.9554*c*c;
      if(ksi==0.0)
	{
	  sigma = (2.0*b1-b0)/log(2.0);
	  mu = b0 - 0.57721566*sigma;
	}
      else
	{
	  double gam=exp(lgamma(-ksi+1.0));
	  double pow2=pow(2.0, ksi);
	  double fact=(1.0-pow2);
	  
	  sigma = -(2.0*b1-b0)*ksi / (gam*fact);
	  mu   = b0 - sigma*(gam-1.0)/ksi;
	}
      
      sdev_mu=sdev_sigma=sdev_ksi=MISSING_VALUE;  
      est_met=use_est_met;
    }
  
  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,2.0,3.0,4.0,4.7,6.0,7.0,8.0};
      char *names[]={"mu","logsigma","ksi"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd,
      // ksi_mu, ksi_sd;
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      
      gev_mu_init=mu;
      gev_sigma_init=sigma;
      gev_ksi_init=ksi;
      first_gev_init=1;
      
      int num_extra=0;
      char **gev_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	gev_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	gev_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,gev_param_names, T,0.15, 
			 0, NULL,
			 init_gev,logprior_gev,loglik_gev,
			 doshowdebug ? false : true, 
			 false, doshowmcmc);

      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_gev,loglik_gev);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  mcmc_ksi=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	      mcmc_ksi[i]=pars[i][2];
	    }
	}
      
      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      ksi=find_statistics(mcmc_ksi, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      sdev_ksi=find_statistics(mcmc_ksi, num_mcmc, STANDARD_DEVIATION);
      
      // cleanup:
      delete [] T;

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(gev_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={ABSVAL((sigma)), mu, ksi}, *output;
      
      gev_likelihood_n=len;   
      gev_likelihood_X=val;
      
      output=multinewtonraphson(gev_likelihood, 3, input, 1e-7, 
				bufferlen, false);
      
      sigma=output[0];
      mu=output[1];
      ksi=output[2];
      
      double **ddf=newton_numeric_doubleder(output); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	{
	  iddf=inverse_matrix(ddf, 3);
	  if(iddf)
	    {
	      sdev_sigma=-iddf[0][0];
	      sdev_mu=-iddf[1][1];
	      sdev_ksi=-iddf[2][2];
	      
	      sdev_sigma=sqrt(ABSVAL(sdev_sigma));
	      sdev_mu=sqrt(ABSVAL(sdev_mu));
	      sdev_ksi=sqrt(ABSVAL(sdev_ksi));
	      
	      delete [] iddf[0];
	      delete [] iddf[1];
	      delete [] iddf[2];
	      delete [] iddf;
	    }
	}
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;

      delete [] output;
    }

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      orig_ksi=ksi;
      visited=true;
    }
  
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      // traverse the distribution;
      for(i=0; i< distrib_len; i++)
	{
	  // Find the argmuent;
	  double x = min + ((double) i)*step;
	  
	  distrib_arg[i] = x;  // set the argument element    
	  distrib_val[i] = function(x); // set the value element
	}
      
      if(do_accumulate)
	accumulate();
    }
}

void gev_distribution::Set(double mu_, double sigma_, double ksi_,
			   double min, double max, 
			   int num_in_distrib, 
			   bool do_accumulate)
{
  mu=mu_;
  sigma=sigma_;
  ksi=ksi_;
  
  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      orig_ksi=ksi;
      visited=true;
    }

  // Find min and max values;
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      set_min_and_max(min, max, num_in_distrib);

      // traverse the distribution;
      for(int i=0; i< distrib_len; i++)
	{
	  // Find the argmuent;
	  double x = min + ((double) i)*step;
	  
	  distrib_arg[i] = x;  // set the argument element    
	  distrib_val[i] = function(x); // set the value element
	}
      
      if(do_accumulate)
	accumulate();
    }
}


//           FUNCTION
// Returns the value of the GEV distribution for a given argument
double gev_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(mcmc_ksi[i]==0.0)
	  ret+=1.0/mcmc_sigma[i] * exp(-(x-mcmc_mu[i])/mcmc_sigma[i]) * 
	    exp(-exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));
	else
	  {
	    if(!(mcmc_ksi[i]>0.0 && x<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]) &&
	       !(mcmc_ksi[i]<0.0 && x>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]))
	      ret+=1.0/mcmc_sigma[i] * 
		pow(1.0+mcmc_ksi[i]*(x-mcmc_mu[i])/mcmc_sigma[i], 
		    -1.0/mcmc_ksi[i]-1.0) * 
		exp(-pow(1.0+mcmc_ksi[i]*(x-mcmc_mu[i])/mcmc_sigma[i], 
			 -1.0/mcmc_ksi[i]));
	  }
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(ksi==0.0)
    return 1.0/sigma * exp(-(x-mu)/sigma) * exp(-exp(-(x-mu)/sigma));
  else
    {
      if(ksi>0.0 && x<mu-sigma/ksi)
	return 0.0;
      else if(ksi<0.0 && x>mu-sigma/ksi)
	return 0.0;

      return 1.0/sigma * pow(1.0+ksi*(x-mu)/sigma, -1.0/ksi-1.0) * 
	exp(-pow(1.0+ksi*(x-mu)/sigma, -1.0/ksi));
    }
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gumbel distribution 
// for a given argument
double gev_distribution::accumulated_function(double x)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(mcmc_ksi[i]==0.0)
	  ret+=exp(-exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));
	else
	  {
	    if(mcmc_ksi[i]<0.0 && x>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i])
	      ret+=1.0;
	    else if(!(mcmc_ksi[i]>0.0 && 
		      x<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]) &&
		    !(mcmc_ksi[i]<0.0 && 
		      x>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]))
	      ret+=exp(-pow(1.0+mcmc_ksi[i]*(x-mcmc_mu[i])/mcmc_sigma[i], 
			    -1.0/mcmc_ksi[i]));
	  }
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(ksi==0.0)
    {
      return exp(-exp(-(x-mu)/sigma));
    }
  else
    {
      if(ksi>0.0 && x<mu-sigma/ksi)
	return 0.0;
      else if(ksi<0.0 && x>mu-sigma/ksi)
	return 1.0;
      
      return exp(-pow(1.0+ksi*(x-mu)/sigma, -1.0/ksi));
    }
}


double gev_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma && mcmc_ksi)
    return distribution::get_quantile(prob);
  else if(ksi==0.0)
    return mu-sigma*log(-log(prob));
  else
    return mu+sigma/ksi*(pow(-log(prob),-ksi)-1.0);
}


//             PRINTHELP
// Sends a description of the GEV distribution to the output stream;
void gev_distribution::printhelp(std::ostream &out)
{
  out << "GEV (General Extreme Value)-fordelingen" << std::endl;
  out << "" << std::endl;
  out << "Dette er en treparameter-fordeling som ofte brukes "
    "i forbindelse med" << std::endl;
  out << "ekstremverdi-analyse, f.eks. flomfrekvensanalyse" << std::endl;
  out << "n�r det er snakk om ekstremer over perioder (�r) hellers" << std::endl;
  out << "enn ekstremer over terskel (peak-over-threshold)" << std::endl;
  out << "Moment-metoden finner fordelingen ved � bruke l-momenter (b0, b1 "
    "og b2)." << std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (17/4-2013)" << std::endl;
}


//             DESCRIPTION
// Returns a short string description of the GEV distribution
char *gev_distribution::description(void)
{
  char *newline= new char[1000];

  if(ksi==0.0)
    {
      if(sdev_sigma!=MISSING_VALUE && sdev_mu!=MISSING_VALUE)
	sprintf(newline, "GEV/Gumbel (%s): f(x)=1/s exp(-(x-mu)/s) "
		"exp(-exp(-(x-mu)/s))  mu=%-7.3g+-%-6.2g "
		"s=%-7.3g+-%-6.2g", est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma);
      else
	sprintf(newline, "GEV/Gumbel (%s): f(x)=1/s exp(-(x-mu)/s) "
		"exp(-exp(-(x-mu)/s))  mu=%-7.3g "
		"s=%-7.3g", est_method_name[(int) est_met],
		mu, sigma);
    }	
  else
    {
      if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE &&
	 sdev_ksi!=MISSING_VALUE)
	sprintf(newline, "GEV (%s): f(x)=1/s (1.0+(ksi(x-mu)/s)^"
		"(-1/ksi-1) exp(-(1.0+(ksi(x-mu)/s))^(-1/ksi))  "
		"mu=%-7.3g+-%-6.2g s=%-7.3g+-%-6.2g ksi=%-7.3g+-%-6.2g", 
		est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma, ksi, sdev_ksi);
      else
	sprintf(newline, "GEV (%s): f(x)=1/s (1.0+(ksi(x-mu)/s)^"
		"(-1/ksi-1) exp(-(1.0+(ksi(x-mu)/s))^(-1/ksi))  "
		"mu=%-7.3g s=%-7.3g ksi=%-7.3g", 
		est_method_name[(int) est_met],
		mu, sigma, ksi);
    }
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}



//             SHORT_DESCRIPTION
// Returns a shorter string description of the GEV distribution
char *gev_distribution::short_description(void)
{
  char *newline= new char[1000];

  if(ksi==0.0)
    {
      if(sdev_sigma!=MISSING_VALUE && sdev_mu!=MISSING_VALUE)
	sprintf(newline, "GEV/Gumbel (%s): mu=%-7.3g+-%-6.2g "
		"s=%-7.3g+-%-6.2g", est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma);
      else
	sprintf(newline, "GEV/Gumbel (%s): mu=%-7.3g "
		"s=%-7.3g", est_method_name[(int) est_met],
		mu, sigma);
    }	
  else
    {
      if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE &&
	 sdev_ksi!=MISSING_VALUE)
	sprintf(newline, "GEV (%s): mu=%-7.3g+-%-6.2g s=%-7.3g+-%-6.2g "
		"ksi=%-7.3g+-%-6.2g", 
		est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma, ksi, sdev_ksi);
      else
	sprintf(newline, "GEV (%s): mu=%-7.3g s=%-7.3g ksi=%-7.3g", 
		est_method_name[(int) est_met],
		mu, sigma, ksi);
    }
  
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  
  return newline;
}

//             FORMULA_PICTURE_PATH
// Returns the location of a picture describing the GEV distribution
char *gev_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/gev2.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("gev2.xbm").c_str());
#endif // NVE
  return newline;
}




//              GET_B0
// Returns the 'b0' value;
double gev_distribution::get_b0(void)
{
  return b0;
}


//              GET_B1
// Returns the 'b1' value;
double gev_distribution::get_b1(void)
{
  return b1;
}


//              GET_B2
// Returns the 'b2' value;
double gev_distribution::get_b2(void)
{
  return b2;
}


//              GET_MU
// Returns the 'mu' value;
double gev_distribution::get_mu(void)
{
  return mu;
}

//              GET_SIGMA
// Returns the 'sigma' value;
double gev_distribution::get_sigma(void)
{
  return sigma;
}


//              GET_KSI
// Returns the 'ksi' value;
double gev_distribution::get_ksi(void)
{
  return ksi;
}


void gev_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
  ksi=orig_ksi;
}

// Returns the MCMC 'mu' value;
double *gev_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *gev_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}

// Returns the MCMC 'ksi' value;
double *gev_distribution::get_mcmc_ksi(void)
{
  return mcmc_ksi;
}


// Get samples quantiles:
double gev_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;

  int i=sample_index;	
  if(mcmc_ksi[i]==0.0)
    return 1.0/mcmc_sigma[i] * exp(-(x-mcmc_mu[i])/mcmc_sigma[i]) * 
      exp(-exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));
  else
    {
      if(!(mcmc_ksi[i]>0.0 && x<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]) &&
	 !(mcmc_ksi[i]<0.0 && x>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]))
	return 1.0/mcmc_sigma[i] * 
	  pow(1.0+mcmc_ksi[i]*(x-mcmc_mu[i])/mcmc_sigma[i], 
	      -1.0/mcmc_ksi[i]-1.0) * 
	  exp(-pow(1.0+mcmc_ksi[i]*(x-mcmc_mu[i])/mcmc_sigma[i], 
		   -1.0/mcmc_ksi[i]));
      else
	return 0.0;
    }
}

double gev_distribution::mcmc_accumulated_function_sample(double x, 
							  int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;

  int i=sample_index;
  if(mcmc_ksi[i]==0.0)
    return exp(-exp(-(x-mcmc_mu[i])/mcmc_sigma[i]));
  else
    {
      if(mcmc_ksi[i]<0.0 && x>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i])
	return 1.0;
      else if(mcmc_ksi[i]>0.0 && x<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i])
	return 0.0;
      else 
	return exp(-pow(1.0+mcmc_ksi[i]*(x-mcmc_mu[i])/mcmc_sigma[i], 
			-1.0/mcmc_ksi[i]));
    }
}

double gev_distribution::mcmc_get_quantile_sample(double prob, 
						  int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(mcmc_ksi[i]==0)
    return mcmc_mu[i]-mcmc_sigma[i]*log(-log(prob));
  else
    return mcmc_mu[i]+mcmc_sigma[i]/mcmc_ksi[i]*
      (pow(-log(prob),-mcmc_ksi[i])-1.0);
}
  


void gev_distribution::repick_parameters(void)
{
#ifdef GSL
  mu=orig_mu+gsl_ran_gaussian(gslptr, sdev_mu);
  sigma=orig_sigma+gsl_ran_gaussian(gslptr, sdev_sigma);
  ksi=orig_ksi+gsl_ran_gaussian(gslptr, sdev_ksi);
#else
  mu=orig_mu+sdev_mu*gauss();
  sigma=orig_sigma+sdev_sigma*gauss();
  ksi=orig_ksi+sdev_ksi*gauss();
#endif
}



// ************************************************************* //
//                                                               //   
//               LOGGEV_DISTRIBUTION                             //
//                                                               // 
// A subclass of 'distribution' representing a log-GEV (log-     //
// General Extreme Value) distribution.                          //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a GEV distribution based on a given dataset.
loggev_distribution::loggev_distribution(double *val, int len, 
					 double min, double max, 
					 int num_in_distrib, 
					 bool do_accumulate, 
					 ESTIMATION_METHOD use_est_met,
					 // hyper-parameter specification 
					 // should match 'num_par_combi' 
					 // in length
					 double *bayes_param_prior_mu, 
					 double *bayes_param_prior_sd,
					 double *bayes_param_prior_p,
					 int num_samples_, int burnin_, 
					 int spacing_, int num_temp_,
					 bool do_show_mcmc, 
					 bool do_show_debug,
					 bool ratio_based_prior,
					 // Historical (upper) threshold data:
					 int num_thresholds, 
					 historic_threshold *thresholds,
					 // Historical data:
					 int num_historical, 
					 historic_extreme_data *histdata) : 
  distribution("Log-GEV")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=false;
  accumulated_function_exists=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  
  distribution_strictly_positive_data=true;

  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<3;i++)
      param_prior_p[i]=bayes_param_prior_p[i];
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  logq3_mu=param_prior_mu[2];
  logq3_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];

  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


// Constructor
// Makes a log-GEV distribution based on parameter sepcification:
loggev_distribution::loggev_distribution(double mu_, double sigma_, double ksi_,
					 double min, double max, 
					 int num_in_distrib, 
					 bool do_accumulate) : 
  distribution("Log-GEV")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=false;
  distribution_strictly_positive_data=true;
  accumulated_function_exists=true;
  Set(mu_, sigma_, ksi_, min, max, num_in_distrib, do_accumulate);
}

loggev_distribution::loggev_distribution() : distribution("Log-GEV")
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=false;
  distribution_strictly_positive_data=true;
  accumulated_function_exists=true;
}

loggev_distribution::~loggev_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}

void loggev_distribution::init(void)
{
  mcmc_mu=NULL;
  mcmc_sigma=NULL;
  mcmc_ksi=NULL;
}

void loggev_distribution::cleanup(void)
{
  if(mcmc_mu)
    delete [] mcmc_mu;
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  if(mcmc_ksi)
    delete [] mcmc_ksi;
  init();
}

void loggev_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=2;
  num_par_combi=3;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"mu");
  strcpy(parnames[1],"sigma");
  strcpy(parnames[2],"ksi");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_BOTH;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_REAL;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[3];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  param_prior_sd[2]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.5;
  param_prior_p[2]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  logq3_mu=param_prior_mu[2];
  logq3_sd=param_prior_sd[2];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  dist_p3=param_prior_p[2];
}

void loggev_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(param_prior_p)
    delete [] param_prior_p;
  if(parstatus)
    delete [] parstatus;
}

//             SET
// Finds a log-GEV distribution based on a given dataset.
void loggev_distribution::Set(double *val, int len, 
			      double min, double max, int num_in_distrib, 
			      bool do_accumulate, 
			      ESTIMATION_METHOD use_est_met,
			      // Historical (upper) threshold data:
			      int num_thresholds, 
			      historic_threshold *thresholds,
			      // Historical data:
			      int num_historical, 
			      historic_extreme_data *histdata)
{
  register int i;

  est_met=use_est_met;
  
  // Find min and max values;
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      set_min_and_max(min, max, num_in_distrib);
      // Retrieve statistical values;
      get_stats(val, len);
      
      // If no such values could be found..
      if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
	return;
    }


  // L-moment estimation performed my log-transformation and 
  // l-moment GEV analysis
  double *val2=new double[len];
  for(i=0;i<len;i++)
    val2[i]=log(val[i]);
  gev_distribution gev(val2,len,min,max,num_in_distrib,do_accumulate, EST_LMOMENT);
  delete [] val2;
  ksi=gev.get_ksi();
  sigma=gev.get_sigma();
  mu=gev.get_mu();

  sdev_mu=sdev_sigma=sdev_ksi=MISSING_VALUE;  
  
  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,2.0,3.0,4.0,4.7,6.0,7.0,8.0};
      char *names[]={"mu","logsigma","ksi"};
      // mu_mu, mu_sd, logmu_mu, logmu_sd, logsigma_mu, logsigma_sd,
      // ksi_mu, ksi_sd;
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      
      loggev_mu_init=mu;
      loggev_sigma_init=sigma;
      loggev_ksi_init=ksi;
      first_loggev_init=1;
      
      int num_extra=0;
      char **lgev_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	lgev_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	lgev_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,lgev_param_names, T,0.15, 
			 0, NULL,
			 init_loggev,logprior_loggev,loglik_loggev,
			 doshowdebug ? false : true, 
			 false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_loggev,loglik_loggev);
      
      if(pars)
	{
	  mcmc_mu=new double[num_mcmc];
	  mcmc_sigma=new double[num_mcmc];
	  mcmc_ksi=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_mu[i]=pars[i][0];
	      mcmc_sigma[i]=exp(pars[i][1]);
	      mcmc_ksi[i]=pars[i][2];
	    }
	}
      
      mu=find_statistics(mcmc_mu, num_mcmc, MEAN);
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      ksi=find_statistics(mcmc_ksi, num_mcmc, MEAN);
      sdev_mu=find_statistics(mcmc_mu, num_mcmc, STANDARD_DEVIATION);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      sdev_ksi=find_statistics(mcmc_ksi, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(lgev_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={ABSVAL((sigma)), mu, ksi}, *output;
      
      loggev_likelihood_n=len;   
      loggev_likelihood_X=val;
      
      output=multinewtonraphson(loggev_likelihood, 3, input, 1e-7, 
				bufferlen, false);
      
      sigma=output[0];
      mu=output[1];
      ksi=output[2];

      double **ddf=newton_numeric_doubleder(output); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	{
	  iddf=inverse_matrix(ddf, 3);
	  if(iddf)
	    {
	      sdev_sigma=-iddf[0][0];
	      sdev_mu=-iddf[1][1];
	      sdev_ksi=-iddf[2][2];
	      
	      sdev_sigma=sqrt(ABSVAL(sdev_sigma));
	      sdev_mu=sqrt(ABSVAL(sdev_mu));
	      sdev_ksi=sqrt(ABSVAL(sdev_ksi));
	      
	      delete [] iddf[0];
	      delete [] iddf[1];
	      delete [] iddf[2];
	      delete [] iddf;
	    }
	}
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;

      delete [] output;
    }

  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      orig_ksi=ksi;
      visited=true;
    }
  
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      // traverse the distribution;
      for(i=0; i< distrib_len; i++)
	{
	  // Find the argmuent;
	  double x = min + ((double) i)*step;
	  
	  distrib_arg[i] = x;  // set the argument element    
	  distrib_val[i] = function(x); // set the value element
	}
      
      if(do_accumulate)
	accumulate();
    }
}

void loggev_distribution::Set(double mu_, double sigma_, double ksi_,
			      double min, double max, 
			      int num_in_distrib, 
			      bool do_accumulate)
{
  mu=mu_;
  sigma=sigma_;
  ksi=ksi_;
  
  if(!visited)
    {
      orig_mu=mu;
      orig_sigma=sigma;
      orig_ksi=ksi;
      visited=true;
    }

  // Find min and max values;
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      set_min_and_max(min, max, num_in_distrib);

      // traverse the distribution;
      for(int i=0; i< distrib_len; i++)
	{
	  // Find the argmuent;
	  double x = min + ((double) i)*step;
	  
	  distrib_arg[i] = x;  // set the argument element    
	  distrib_val[i] = function(x); // set the value element
	}
      
      if(do_accumulate)
	accumulate();
    }
}


//           FUNCTION
// Returns the value of the GEV distribution for a given argument
double loggev_distribution::function(double x)
{
  if(x<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(mcmc_ksi[i]==0.0)
	  ret+=1.0/mcmc_sigma[i]/x * exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]) * 
	    exp(-exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]));
	else
	  {
	    if(!(mcmc_ksi[i]>0.0 && log(x)<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]) &&
	       !(mcmc_ksi[i]<0.0 && log(x)>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]))
	      ret+=1.0/mcmc_sigma[i]/x * 
		pow(1.0+mcmc_ksi[i]*(log(x)-mcmc_mu[i])/mcmc_sigma[i], 
		    -1.0/mcmc_ksi[i]-1.0) * 
		exp(-pow(1.0+mcmc_ksi[i]*(log(x)-mcmc_mu[i])/mcmc_sigma[i], 
			 -1.0/mcmc_ksi[i]));
	  }
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(ksi==0.0)
    return 1.0/sigma/x * exp(-(log(x)-mu)/sigma) * exp(-exp(-(log(x)-mu)/sigma));
  else
    {
      if(ksi>0.0 && log(x)<mu-sigma/ksi)
	return 0.0;
      else if(ksi<0.0 && log(x)>mu-sigma/ksi)
	return 0.0;

      return 1.0/sigma/x * pow(1.0+ksi*(log(x)-mu)/sigma, -1.0/ksi-1.0) * 
	exp(-pow(1.0+ksi*(log(x)-mu)/sigma, -1.0/ksi));
    }
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gumbel distribution 
// for a given argument
double loggev_distribution::accumulated_function(double x)
{
  if(x<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(mcmc_ksi[i]==0.0)
	  ret+=exp(-exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]));
	else
	  {
	    if(mcmc_ksi[i]<0.0 && log(x)>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i])
	      ret+=1.0;
	    else if(!(mcmc_ksi[i]>0.0 && 
		      log(x)<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]) &&
		    !(mcmc_ksi[i]<0.0 && 
		      log(x)>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]))
	      ret+=exp(-pow(1.0+mcmc_ksi[i]*(log(x)-mcmc_mu[i])/mcmc_sigma[i], 
			    -1.0/mcmc_ksi[i]));
	  }
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(ksi==0.0)
    {
      return exp(-exp(-(log(x)-mu)/sigma));
    }
  else
    {
      if(ksi>0.0 && log(x)<mu-sigma/ksi)
	return 0.0;
      else if(ksi<0.0 && log(x)>mu-sigma/ksi)
	return 1.0;
      
      return exp(-pow(1.0+ksi*(log(x)-mu)/sigma, -1.0/ksi));
    }
}


double loggev_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_mu && mcmc_sigma && mcmc_ksi)
    return distribution::get_quantile(prob);
  else if(ksi==0.0)
    return exp(mu-sigma*log(-log(prob)));
  else
    return exp(mu+sigma/ksi*(pow(-log(prob),-ksi)-1.0));
}


//             PRINTHELP
// Sends a description of the GEV distribution to the output stream;
void loggev_distribution::printhelp(std::ostream &out)
{
  out << "Log-GEV (log-General Extreme Value)-fordelingen" << std::endl;
  out << "" << std::endl;
  out << "Dette er en treparameter-fordeling som kan brukes "
    "i forbindelse med" << std::endl;
  out << "ekstremverdi-analyse p� strengt positive ting, f.eks. flomfrekvensanalyse" << std::endl;
  out << "n�r det er snakk om ekstremer over perioder (�r) hellers" << std::endl;
  out << "enn ekstremer over terskel (peak-over-threshold)" << std::endl;
  out << "Moment-metoden finner fordelingen ved � bruke l-momenter (b0, b1 "
    "og b2) for log-transformerte data." << std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (5/5-2014)" << std::endl;
}


//             DESCRIPTION
// Returns a short string description of the GEV distribution
char *loggev_distribution::description(void)
{
  char *newline= new char[1000];

  if(ksi==0.0)
    {
      if(sdev_sigma!=MISSING_VALUE && sdev_mu!=MISSING_VALUE)
	sprintf(newline, "Log-GEV/Gumbel (%s): f(x)=1/(s*x) exp(-(log(x)-mu)/s) "
		"exp(-exp(-(log(x)-mu)/s))  mu=%-7.3g+-%-6.2g "
		"s=%-7.3g+-%-6.2g", est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma);
      else
	sprintf(newline, "Log-GEV/Gumbel (%s): f(x)=1/(s*x) exp(-(log(x)-mu)/s) "
		"exp(-exp(-(log(x)-mu)/s))  mu=%-7.3g "
		"s=%-7.3g", est_method_name[(int) est_met],
		mu, sigma);
    }	
  else
    {
      if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE &&
	 sdev_ksi!=MISSING_VALUE)
	sprintf(newline, "Log-GEV (%s): f(x)=1/(s*x) (1.0+(ksi(log(x)-mu)/s)^"
		"(-1/ksi-1) exp(-(1.0+(ksi(log(x)-mu)/s))^(-1/ksi))  "
		"mu=%-7.3g+-%-6.2g s=%-7.3g+-%-6.2g ksi=%-7.3g+-%-6.2g", 
		est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma, ksi, sdev_ksi);
      else
	sprintf(newline, "Log-GEV (%s): f(x)=1/(s*x) (1.0+(ksi(log(x)-mu)/s)^"
		"(-1/ksi-1) exp(-(1.0+(ksi(log(x)-mu)/s))^(-1/ksi))  "
		"mu=%-7.3g s=%-7.3g ksi=%-7.3g", 
		est_method_name[(int) est_met],
		mu, sigma, ksi);
    }
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}



//             SHORT_DESCRIPTION
// Returns a shorter string description of the GEV distribution
char *loggev_distribution::short_description(void)
{
  char *newline= new char[1000];

  if(ksi==0.0)
    {
      if(sdev_sigma!=MISSING_VALUE && sdev_mu!=MISSING_VALUE)
	sprintf(newline, "Log-GEV/Gumbel (%s): mu=%-7.3g+-%-6.2g "
		"s=%-7.3g+-%-6.2g", est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma);
      else
	sprintf(newline, "Log-GEV/Gumbel (%s): mu=%-7.3g "
		"s=%-7.3g", est_method_name[(int) est_met],
		mu, sigma);
    }	
  else
    {
      if(sdev_mu!=MISSING_VALUE && sdev_sigma!=MISSING_VALUE &&
	 sdev_ksi!=MISSING_VALUE)
	sprintf(newline, "Log-GEV (%s): mu=%-7.3g+-%-6.2g s=%-7.3g+-%-6.2g "
		"ksi=%-7.3g+-%-6.2g", 
		est_method_name[(int) est_met],
		mu, sdev_mu, sigma, sdev_sigma, ksi, sdev_ksi);
      else
	sprintf(newline, "Log-GEV (%s): mu=%-7.3g s=%-7.3g ksi=%-7.3g", 
		est_method_name[(int) est_met],
		mu, sigma, ksi);
    }
  
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  
  return newline;
}

//             FORMULA_PICTURE_PATH
// Returns the location of a picture describing the GEV distribution
char *loggev_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/loggev.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("loggev.xbm").c_str());
#endif // NVE
  return newline;
}




//              GET_B0
// Returns the 'b0' value;
double loggev_distribution::get_b0(void)
{
  return b0;
}


//              GET_B1
// Returns the 'b1' value;
double loggev_distribution::get_b1(void)
{
  return b1;
}


//              GET_B2
// Returns the 'b2' value;
double loggev_distribution::get_b2(void)
{
  return b2;
}


//              GET_MU
// Returns the 'mu' value;
double loggev_distribution::get_mu(void)
{
  return mu;
}

//              GET_SIGMA
// Returns the 'sigma' value;
double loggev_distribution::get_sigma(void)
{
  return sigma;
}


//              GET_KSI
// Returns the 'ksi' value;
double loggev_distribution::get_ksi(void)
{
  return ksi;
}


void loggev_distribution::use_orig_curve(void)
{
  mu=orig_mu;
  sigma=orig_sigma;
  ksi=orig_ksi;
}

// Returns the MCMC 'mu' value;
double *loggev_distribution::get_mcmc_mu(void)
{
  return mcmc_mu;
}

// Returns the MCMC 'sigma' value;
double *loggev_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}

// Returns the MCMC 'ksi' value;
double *loggev_distribution::get_mcmc_ksi(void)
{
  return mcmc_ksi;
}


// Get samples quantiles:
double loggev_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;

  if(x<=0.0)
    return 0.0;

  int i=sample_index;	
  if(mcmc_ksi[i]==0.0)
    return 1.0/mcmc_sigma[i]/x * exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]) * 
      exp(-exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]));
  else
    {
      if(!(mcmc_ksi[i]>0.0 && log(x)<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]) &&
	 !(mcmc_ksi[i]<0.0 && log(x)>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i]))
	return 1.0/mcmc_sigma[i]/x * 
	  pow(1.0+mcmc_ksi[i]*(log(x)-mcmc_mu[i])/mcmc_sigma[i], 
	      -1.0/mcmc_ksi[i]-1.0) * 
	  exp(-pow(1.0+mcmc_ksi[i]*(log(x)-mcmc_mu[i])/mcmc_sigma[i], 
		   -1.0/mcmc_ksi[i]));
      else
	return 0.0;
    }
}

double loggev_distribution::mcmc_accumulated_function_sample(double x, 
							     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;

  if(x<=0.0)
    return 0.0;
  
  int i=sample_index;
  if(mcmc_ksi[i]==0.0)
    return exp(-exp(-(log(x)-mcmc_mu[i])/mcmc_sigma[i]));
  else
    {
      if(mcmc_ksi[i]<0.0 && log(x)>mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i])
	return 1.0;
      else if(mcmc_ksi[i]>0.0 && log(x)<mcmc_mu[i]-mcmc_sigma[i]/mcmc_ksi[i])
	return 0.0;
      else 
	return exp(-pow(1.0+mcmc_ksi[i]*(log(x)-mcmc_mu[i])/mcmc_sigma[i], 
			-1.0/mcmc_ksi[i]));
    }
}

double loggev_distribution::mcmc_get_quantile_sample(double prob, 
						     int sample_index)
{
  if(num_mcmc<=0 || !mcmc_mu || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(mcmc_ksi[i]==0)
    return exp(mcmc_mu[i]-mcmc_sigma[i]*log(-log(prob)));
  else
    return exp(mcmc_mu[i]+mcmc_sigma[i]/mcmc_ksi[i]*
	       (pow(-log(prob),-mcmc_ksi[i])-1.0));
}
  


void loggev_distribution::repick_parameters(void)
{
#ifdef GSL
  mu=orig_mu+gsl_ran_gaussian(gslptr, sdev_mu);
  sigma=orig_sigma+gsl_ran_gaussian(gslptr, sdev_sigma);
  ksi=orig_ksi+gsl_ran_gaussian(gslptr, sdev_ksi);
#else
  mu=orig_mu+sdev_mu*gauss();
  sigma=orig_sigma+sdev_sigma*gauss();
  ksi=orig_ksi+sdev_ksi*gauss();
#endif
}





// ************************************************************* //
//                                                               //   
//               WEIBULL_DISTRIBUTION                            //
//                                                               // 
// A subclass of 'distribution' representing a Ewibull           //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Weibull distribution based on a given dataset.
weibull_distribution::weibull_distribution(double *val, int len, 
					   double min, double max, 
					   int num_in_distrib, 
					   bool do_accumulate, 
					   ESTIMATION_METHOD use_est_met,
					   // hyper-parameter specification 
					   // should match 'num_par_combi' 
					   // in length
					   double *bayes_param_prior_mu, 
					   double *bayes_param_prior_sd,
					   double *bayes_param_prior_p,
					   int num_samples_, int burnin_, 
					   int spacing_, int num_temp_,
					   bool do_show_mcmc, 
					   bool do_show_debug,
					   bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("Weibull")
{
  init();
  init_hyperparameters();
  numparam=2;
  accumulated_function_exists=true;
  allow_neg=false;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  
  distribution_strictly_positive_data=true;
  
  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];

  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;

  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


// Constructor
// Makes a Weibull distribution based on parameter sepcification:
weibull_distribution::weibull_distribution(double sigma_, double ksi_,
					   double min, double max, 
					   int num_in_distrib, 
					   bool do_accumulate) : 
  distribution("Weibull")
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=false;
  accumulated_function_exists=true;
  Set(sigma_, ksi_, min, max, num_in_distrib, do_accumulate);
}

// empty constructor;
weibull_distribution::weibull_distribution() : distribution("Weibull") 
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=false;
  accumulated_function_exists=true;
}
  

weibull_distribution::~weibull_distribution()
{
  cleanup();
  cleanup_hyperparameters();
}

void weibull_distribution::init(void)
{
  mcmc_sigma=NULL;
  mcmc_ksi=NULL;
}

void weibull_distribution::cleanup(void)
{
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  if(mcmc_ksi)
    delete [] mcmc_ksi;
  init();
}

void weibull_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=2;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"sigma");
  strcpy(parnames[1],"ksi");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void weibull_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(parstatus)
    delete [] parstatus;
}

//             SET
// Finds a Weibull distribution based on a given dataset.
void weibull_distribution::Set(double *val, int len, 
			       double min, double max, int num_in_distrib, 
			       bool do_accumulate, 
			       ESTIMATION_METHOD use_est_met,
			       // Historical (upper) threshold data:
			       int num_thresholds, 
			       historic_threshold *thresholds,
			       // Historical data:
			       int num_historical, 
			       historic_extreme_data *histdata)
{
  register int i;

  est_met=use_est_met;
  
  // Find min and max values;
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      set_min_and_max(min, max, num_in_distrib);
      // Retrieve statistical values;
      get_stats(val, len);
      
      // If no such values could be found..
      if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
	return;
    }

  double l1=b0, l2=2*b1-b0;
  // l-moment estimation:
  ksi=-log(2)/log(1.0-l2/l1);
  sigma=l1/exp(lgamma(1.0+1.0/ksi));
  
  sdev_sigma=sdev_ksi=MISSING_VALUE;
  
  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,2.0,3.0,4.0,4.7,6.0,7.0,8.0};
      char *names[]={"logsigma","logksi"};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      
      int num_extra=0;
      char **weibull_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	weibull_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	weibull_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,weibull_param_names, T,0.15, 
			 0,NULL,
			 init_weibull,logprior_weibull,loglik_weibull,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  0,NULL,
					  logprior_weibull,loglik_weibull);
      
      if(pars)
	{
	  mcmc_sigma=new double[num_mcmc];
	  mcmc_ksi=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_sigma[i]=exp(pars[i][0]);
	      mcmc_ksi[i]=exp(pars[i][1]);
	    }
	}
      
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      ksi=find_statistics(mcmc_ksi, num_mcmc, MEAN);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      sdev_ksi=find_statistics(mcmc_ksi, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(weibull_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={ABSVAL((sigma)), ABSVAL((ksi))}, *output;
      
      weibull_likelihood_n=len;   
      weibull_likelihood_X=val;
      
      output=multinewtonraphson(weibull_likelihood, 2, input, 1e-7, 
				bufferlen, false);
      
      sigma=output[0];
      ksi=output[1];
      
      double **ddf=newton_numeric_doubleder(output); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,2),0.0))
	{
	  iddf=inverse_matrix(ddf, 2);
	  if(iddf)
	    {
	      sdev_sigma=-iddf[0][0];
	      sdev_ksi=-iddf[1][1];
	      
	      sdev_sigma=sqrt(ABSVAL(sdev_sigma));
	      sdev_ksi=sqrt(ABSVAL(sdev_ksi));
	      
	      delete [] iddf[0];
	      delete [] iddf[1];
	      delete [] iddf;
	    }
	}
      
      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf;

      delete [] output;
    }

  if(!visited)
    {
      orig_sigma=sigma;
      orig_ksi=ksi;
      visited=true;
    }
  
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      // traverse the distribution;
      for(i=0; i< distrib_len; i++)
	{
	  // Find the argmuent;
	  double x = min + ((double) i)*step;
	  
	  distrib_arg[i] = x;  // set the argument element    
	  distrib_val[i] = function(x); // set the value element
	}
      
      if(do_accumulate)
	accumulate();
    }
}

void weibull_distribution::Set(double sigma_, double ksi_,
			       double min, double max, 
			       int num_in_distrib, 
			       bool do_accumulate)
{
  sigma=sigma_;
  ksi=ksi_;
  
  if(!visited)
    {
      orig_sigma=sigma;
      orig_ksi=ksi;
      visited=true;
    }
  
  // Find min and max values;
  if(min!=MISSING_VALUE && max!=MISSING_VALUE &&
     num_in_distrib!=(int)MISSING_VALUE && num_in_distrib>0)
    {
      set_min_and_max(min, max, num_in_distrib);
      
      // traverse the distribution;
      for(int i=0; i< distrib_len; i++)
	{
	  // Find the argmuent;
	  double x = min + ((double) i)*step;
	  
	  distrib_arg[i] = x;  // set the argument element    
	  distrib_val[i] = function(x); // set the value element
	}
      
      if(do_accumulate)
	accumulate();
    }
}


//           FUNCTION
// Returns the value of the Weibull distribution for a given argument
double weibull_distribution::function(double x)
{
  if(est_met==EST_BAYES && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(x>=0)
	  ret+=mcmc_ksi[i]/mcmc_sigma[i] * pow(x/mcmc_sigma[i], 
					       mcmc_ksi[i]-1.0) * 
	    exp(-pow(x/mcmc_sigma[i], mcmc_ksi[i]));
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(x<=0.0)
    return 0.0;
  else 
    return ksi/sigma * pow(x/sigma, ksi-1.0) * 
      exp(-pow(x/sigma, ksi));
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gumbel distribution 
// for a given argument
double weibull_distribution::accumulated_function(double x)
{
  if(0 && est_met==EST_BAYES && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;

      for(i=0;i<num_mcmc;i++)
	if(x>=0)
	  ret+=1.0-exp(-pow(x/mcmc_sigma[i], mcmc_ksi[i]));
      
      ret/=double(num_mcmc);
      
      return ret;
    }
 else if(x<=0.0)
    return 0.0;
  else
    return 1.0-exp(-pow(x/sigma, ksi));
}


double weibull_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_sigma && mcmc_ksi)
    return distribution::get_quantile(prob);
  else
    return sigma*pow(-log(1.0-prob),1.0/ksi);
}


//             PRINTHELP
// Sends a description of the Weibull distribution to the output stream;
void weibull_distribution::printhelp(std::ostream &out)
{
  out << "Weibullfordelingen" << std::endl;
  out << "" << std::endl;
  out << "Dette er en toparameter-fordeling som ofte brukes "
    "i forbindelse med" << std::endl;
  out << "overlevelsesanalyse og av og til i ekstremverdi-analyse." << std::endl;
  out << "Moment-metoden finner fordelingen ved � bruke l-momenter (b0, b1)." 
      << std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (17/4-2013)" << std::endl;
}


//             DESCRIPTION
// Returns a short string description of the Weibull distribution
char *weibull_distribution::description(void)
{
  char *newline= new char[1000];

  if(sdev_sigma!=MISSING_VALUE && sdev_ksi!=MISSING_VALUE)
    sprintf(newline, "Weibull (%s): f(x)=ksi/s (x/s)^(ksi-1) exp(-(x/s)^ksi)  "
	    "s=%-7.3g+-%-6.2g ksi=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met],
	    sigma, sdev_sigma, ksi, sdev_ksi);
  else
    sprintf(newline, "Weibull (%s): f(x)=ksi/s (x/s)^(ksi-1) exp(-(x/s)^ksi) "
	    "s=%-7.3g ksi=%-7.3g", 
	    est_method_name[(int) est_met],
	    sigma, ksi);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//             SHORT_DESCRIPTION
// Returns a shorter string description of the Weibull distribution
char *weibull_distribution::short_description(void)
{
  char *newline= new char[1000];

  if(sdev_sigma!=MISSING_VALUE && sdev_ksi!=MISSING_VALUE)
    sprintf(newline, "Weibull (%s): "
	    "s=%-7.3g+-%-6.2g ksi=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met],
	    sigma, sdev_sigma, ksi, sdev_ksi);
  else
    sprintf(newline, "Weibull (%s): "
	    "s=%-7.3g ksi=%-7.3g", 
	    est_method_name[(int) est_met],
	    sigma, ksi);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

//             FORMULA_PICTURE_PATH
// Returns the location of a picture describing the Weibull distribution
char *weibull_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/weibull.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("weibull.xbm").c_str());
#endif // NVE
  return newline;
}




//              GET_B0
// Returns the 'b0' value;
double weibull_distribution::get_b0(void)
{
  return b0;
}


//              GET_B1
// Returns the 'b1' value;
double weibull_distribution::get_b1(void)
{
  return b1;
}


//              GET_B2
// Returns the 'b2' value;
double weibull_distribution::get_b2(void)
{
  return b2;
}



//              GET_SIGMA
// Returns the 'sigma' value;
double weibull_distribution::get_sigma(void)
{
  return sigma;
}


//              GET_KSI
// Returns the 'ksi' value;
double weibull_distribution::get_ksi(void)
{
  return ksi;
}

void weibull_distribution::use_orig_curve(void)
{
  sigma=orig_sigma;
  ksi=orig_ksi;
}

// Returns the MCMC 'sigma' value;
double *weibull_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}

// Returns the MCMC 'ksi' value;
double *weibull_distribution::get_mcmc_ksi(void)
{
  return mcmc_ksi;
}


// Get samples quantiles:
double weibull_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;

  int i=sample_index;
  if(x<0)
    return 0.0;
  
  return mcmc_ksi[i]/mcmc_sigma[i] * pow(x/mcmc_sigma[i], mcmc_ksi[i]-1.0) * 
    exp(-pow(x/mcmc_sigma[i], mcmc_ksi[i]));
}

double weibull_distribution::mcmc_accumulated_function_sample(double x, 
							  int sample_index)
{
  if(num_mcmc<=0 || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;

  int i=sample_index;
  if(x<0)
    return 0.0;
  
  return (1.0-exp(-pow(x/mcmc_sigma[i], mcmc_ksi[i])));
}

double weibull_distribution::mcmc_get_quantile_sample(double prob, 
						      int sample_index)
{
  if(num_mcmc<=0 || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  return mcmc_sigma[i]*pow(-log(1.0-prob),1.0/mcmc_ksi[i]);
}
  
void weibull_distribution::repick_parameters(void)
{
#ifdef GSL
  sigma=orig_sigma+gsl_ran_gaussian(gslptr, sdev_sigma);
  ksi=orig_ksi+gsl_ran_gaussian(gslptr, sdev_ksi);
#else
  sigma=orig_sigma+sdev_sigma*gauss();
  ksi=orig_ksi+sdev_ksi*gauss();
#endif
}



// ************************************************************* //
//                                                               //   
//               PARETO_DISTRIBUTION                             //
//                                                               // 
// A subclass of 'distribution' representing a Pareto            //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Pareto distribution based on a given dataset.
pareto_distribution::pareto_distribution(double *val, int len, 
					 double min, double max, 
					 int num_in_distrib, 
					 bool do_accumulate, 
					 ESTIMATION_METHOD use_est_met,
					 double zero_point,
					 // hyper-parameter specification 
					 // should match 'num_par_combi' 
					 // in length
					 double *bayes_param_prior_mu, 
					 double *bayes_param_prior_sd, 
					 double *bayes_param_prior_p,
					 int num_samples_, int burnin_, 
					 int spacing_, int num_temp_,
					 bool do_show_mcmc, 
					 bool do_show_debug,
					 bool ratio_based_prior,
				       // Historical (upper) threshold data:
				       int num_thresholds, 
				       historic_threshold *thresholds,
				       // Historical data:
				       int num_historical, 
				       historic_extreme_data *histdata) : 
  distribution("Pareto")
{
  init();
  init_hyperparameters();
  numparam=2;
  accumulated_function_exists=true;
  set_zero_point(zero_point);
  allow_neg=false;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  
  distribution_strictly_positive_data=true;
  
  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];
  if(bayes_param_prior_p)
    for(i=0;i<2;i++)
      param_prior_p[i]=bayes_param_prior_p[i];

  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
  
  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}


// empty constructor;
pareto_distribution::pareto_distribution() : distribution("Pareto") 
{
  init();
  init_hyperparameters();
  numparam=2;
  allow_neg=false;
  zeropoint=0.0;
  accumulated_function_exists=true;
}
  
// destructor;
pareto_distribution::~pareto_distribution() 
{
  cleanup();
  cleanup_hyperparameters();
}
  
void pareto_distribution::set_zero_point(double zero_point)
{
  zeropoint=zero_point;
}


void pareto_distribution::init(void)
{
  mcmc_sigma=NULL;
  mcmc_ksi=NULL;
}

void pareto_distribution::cleanup(void)
{
  if(mcmc_sigma)
    delete [] mcmc_sigma;
  if(mcmc_ksi)
    delete [] mcmc_ksi;
  init();
}

void pareto_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=1;
  num_par_combi=2;
  numparam=2;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"sigma");
  strcpy(parnames[1],"ksi");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_POS;
  parstatus[1]=PARAM_PRIOR_REAL;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  param_prior_p=new double[2];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  
  param_prior_sd[0]=10.0;
  param_prior_sd[1]=10.0;
  
  param_prior_p[0]=0.025;
  param_prior_p[1]=0.975;
  
  logq1_mu=param_prior_mu[0];
  logq1_sd=param_prior_sd[0];
  logq2_mu=param_prior_mu[1];
  logq2_sd=param_prior_sd[1];
  dist_p1=param_prior_p[0];
  dist_p2=param_prior_p[1];
}

void pareto_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(parstatus)
    delete [] parstatus;
}


//             SET
// Finds a Pareto distribution based on a given dataset.
void pareto_distribution::Set(double *val, int len, 
			      double min, double max, int num_in_distrib, 
			      bool do_accumulate, 
			      ESTIMATION_METHOD use_est_met,
			      // Historical (upper) threshold data:
			      int num_thresholds, 
			      historic_threshold *thresholds,
			      // Historical data:
			      int num_historical, 
			      historic_extreme_data *histdata)
{
  register int i;
  double *valbuffer=new double[len];
  
  for(i=0;i<len;i++)
    valbuffer[i]=val[i]-zeropoint;
  
  est_met=use_est_met;
  
  // Find min and max values;
  set_min_and_max(min, max, num_in_distrib);
  // Retrieve statistical values;
  get_stats(valbuffer, len);
  
  // If no such values could be found..
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  // L-moment method:
  sigma = 2.0*a1*a0/(a0-2.0*a1);
  ksi   = -(a0/(a0-2.0*a1) - 2.0);
  sdev_sigma=sdev_ksi=MISSING_VALUE;
  
  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,2.0,3.0,4.0,4.7,6.0,7.0,8.0};
      char *names[]={"logsigma","ksi"};
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      
      int num_extra=0;
      char **pareto_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	pareto_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	pareto_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &valbuffer, len, 1, 
			 curr_numpar,pareto_param_names, T,0.15, 
			 0,NULL,
			 init_pareto,logprior_pareto,loglik_pareto,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &valbuffer, len, 1,
					  0,NULL,
					  logprior_pareto,loglik_pareto);
      
      if(pars)
	{
	  mcmc_sigma=new double[num_mcmc];
	  mcmc_ksi=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_sigma[i]=exp(pars[i][0]);
	      mcmc_ksi[i]=pars[i][1];
	    }
	}
      
      sigma=find_statistics(mcmc_sigma, num_mcmc, MEAN);
      ksi=find_statistics(mcmc_ksi, num_mcmc, MEAN);
      sdev_sigma=find_statistics(mcmc_sigma, num_mcmc, STANDARD_DEVIATION);
      sdev_ksi=find_statistics(mcmc_ksi, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(pareto_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=100;
      double input[]={sigma, -ksi}, *output;
      
      pareto_likelihood_n=len;   
      pareto_likelihood_X=valbuffer;
      
      if(sigma<0)
	input[0]=-sigma;
      if(ksi<0.0 && pareto_likelihood(input)<-5.0e+5)
	input[1]=-ksi;
      
      output=multinewtonraphson(pareto_likelihood, 2, input, 1e-7, 
				bufferlen, false);
      
      sigma=output[0];
      ksi=-output[1];
      
      if(!visited)
	{
	  double **ddf=newton_numeric_doubleder(output); 
	  double **iddf=NULL;
	  if(!almost_equal(determinant_matrix(ddf,2),0.0))
	    iddf=inverse_matrix(ddf, 2);
	  else
	    iddf=make_matrix(2,2);
	  
	  sdev_sigma=-iddf[0][0];
	  sdev_ksi=-iddf[1][1];
	  
	  sdev_sigma=sqrt(ABSVAL(sdev_sigma));
	  sdev_ksi=sqrt(ABSVAL(sdev_ksi));
	  
	  delete [] ddf[0];
	  delete [] ddf[1];
	  delete [] ddf;
	  delete [] iddf[0];
	  delete [] iddf[1];
	  delete [] iddf;
	}

      delete [] output;
    }

  if(!visited)
    {
      orig_sigma=sigma;
      orig_ksi=ksi;
      visited=true;
    }

  // traverse the distribution;
  for(i=0; i< distrib_len; i++)
    {
      // Find the argmuent;
      double x = min + ((double) i)*step;

      distrib_arg[i] = x;  // set the argument element    
      distrib_val[i] = function(x); // set the value element
    }

  if(do_accumulate)
    accumulate();

  delete [] valbuffer;
}


//           FUNCTION
// Returns the value of the Pareto distribution for a given argument
double pareto_distribution::function(double x)
{
  double x_rescaled=x-zeropoint;
  
  if(x_rescaled<=0.0)
    return 0.0;

  if(est_met==EST_BAYES && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;
      for(i=0;i<num_mcmc;i++)
	if(!(mcmc_ksi[i]<0.0 && x_rescaled>=-mcmc_sigma[i]/mcmc_ksi[i]))
	  {
	    if(mcmc_ksi[i]!=0.0)
	      ret+=1.0/mcmc_sigma[i] * 
		pow(1.0+mcmc_ksi[i]*x_rescaled/mcmc_sigma[i], 
		    -1.0/mcmc_ksi[i]-1.0);
	    else
	      ret+=1.0/mcmc_sigma[i] * exp(-x_rescaled/mcmc_sigma[i]);
	  }

      ret/=double(num_mcmc);

      return ret;
    }
  else if(ksi<0.0 && x_rescaled>=-sigma/ksi)
    return 0.0;
  else
    {
      if(ksi!=0.0)
	return 1.0/sigma * pow(1.0+ksi*x_rescaled/sigma, -1.0/ksi-1.0);
      else
	return 1.0/sigma * exp(-x_rescaled/sigma);
    }
}


//           ACCUMULATED_FUNCTION
// Returns the value of the accumulated Gumbel distribution 
// for a given argument
double pareto_distribution::accumulated_function(double x)
{
  double x_rescaled=x-zeropoint;

  if(x_rescaled<=0.0)
    return 0.0;
  
  if(est_met==EST_BAYES && mcmc_sigma && mcmc_ksi)
    {
      double ret=0.0;
      int i;
      
      for(i=0;i<num_mcmc;i++)
	if(mcmc_ksi[i]<0.0 && x_rescaled>=-mcmc_sigma[i]/mcmc_ksi[i])
	  ret+=1.0;
	else
	  {
	    if(mcmc_ksi[i]!=0.0)
	      ret += 1.0 - pow(1.0+mcmc_ksi[i]*x_rescaled/mcmc_sigma[i], 
			       -1.0/mcmc_ksi[i]);
	    else
	      ret+=1.0 - exp(-x_rescaled/mcmc_sigma[i]);
	  }

      ret/=double(num_mcmc);

      return ret;
    }
  else if(ksi<0.0 && x_rescaled>=-sigma/ksi)
    return 1.0;
  else
    {
      if(ksi!=0.0)
	return 1.0 - pow(1.0+ksi*x_rescaled/sigma, -1.0/ksi);
      else
	return 1.0 - exp(-x_rescaled/sigma);
    }
}


double pareto_distribution::get_quantile(double prob)
{
  if(est_met==EST_BAYES && mcmc_sigma && mcmc_ksi)
    return distribution::get_quantile(prob);
  else if(ksi==0.0)
    return zeropoint-sigma*log(1.0-prob);
  else
    return zeropoint+sigma/ksi*(pow(1-prob,-ksi)-1.0);
}


//             PRINTHELP
// Sends a description of the Pareto distribution to the output stream;
void pareto_distribution::printhelp(std::ostream &out)
{
  out << "Pareto-fordelingen" << std::endl;
  out << "" << std::endl;
  out << "Dette er en toparameter-fordeling som ofte brukes "
    "i forbindelse med" << std::endl;
  out << "ekstremverdi-analyse, f.eks. flomfrekvensanalyse." << std::endl;
  out << "Fordelingen brukes n�r det i stedet for � hentes inn �rs-topper "
    "hentes topper over en gitt terskel-verdi (peak-over-threshold-"
    "analyse)." << std::endl;
  out << "Moment-metoden finner fordelingen ved � bruke l-momenter "
    "(a0 og a1)." << std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "Lokasjonsparameteren mu blir som regel enten bare satt til "
    "null" << std::endl;
  out << "eller lik terskelen i en peak-over-threshold-analyse." << std::endl;
  out << "Dermed har fordelingen i praksis kun to parametre, sigma og ksi." 
      << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (25/4-2013)" << std::endl;
}


//             DESCRIPTION
// Returns a short string description of the Pareto distribution
char *pareto_distribution::description(void)
{
  char *newline= new char[1000];

  if(ksi==0.0)
    {
      if(sdev_sigma!=MISSING_VALUE)
	sprintf(newline, "Pareto (%s): f(x)=exp(-x/sigma)/sigma  "
		"sigma=%-7.3g+-%-6.2g, x=x'-%5.3f",  
		est_method_name[(int) est_met],
		sigma, sdev_sigma, zeropoint);
      else
	sprintf(newline, "Pareto (%s): f(x)=exp(-x/alfa)/alfa  "
		"alfa=%-7.3g, x=x'-%5.3f",  
		est_method_name[(int) est_met],
		sigma, zeropoint);
    }  
  else
    {
      if(sdev_sigma!=MISSING_VALUE && sdev_ksi!=MISSING_VALUE)
	sprintf(newline, "Pareto (%s): f(x)=1/sigma "
		"(1.0-(ksi x/igma)^(-1/ksi-1)  "
		"sigma=%-7.3g+-%-6.2g ksi=%-7.3g+-%-6.2g x=x'-%5.3f", 
		est_method_name[(int) est_met],
		sigma, sdev_sigma, ksi, sdev_ksi,zeropoint);
      else
	sprintf(newline, "Pareto (%s): f(x)=1/sigma "
		"(1.0-(ksi x/sigma)^(-1/ksi-1)  "
		"sigma=%-7.3g ksi=%-7.3g x=x'-%5.3f", 
		est_method_name[(int) est_met],
		sigma, ksi, zeropoint);
    }
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"),
	    100.0*bayesian_model_probability);
  return newline;
}


//             SHORT_DESCRIPTION
// Returns a shorter string description of the Pareto distribution
char *pareto_distribution::short_description(void)
{
  char *newline= new char[1000];

  if(ksi==0.0)
    {
      if(sdev_sigma!=MISSING_VALUE)
	sprintf(newline, "Pareto (%s): "
		"sigma=%-7.3g+-%-6.2g, x=x'-%5.3f",  
		est_method_name[(int) est_met],
		sigma, sdev_sigma, zeropoint);
      else
	sprintf(newline, "Pareto (%s): "
		"alfa=%-7.3g, x=x'-%5.3f",  
		est_method_name[(int) est_met],
		sigma, zeropoint);
    }  
  else
    {
      if(sdev_sigma!=MISSING_VALUE && sdev_ksi!=MISSING_VALUE)
	sprintf(newline, "Pareto (%s): "
		"sigma=%-7.3g+-%-6.2g ksi=%-7.3g+-%-6.2g x=x'-%5.3f", 
		est_method_name[(int) est_met],
		sigma, sdev_sigma, ksi, sdev_ksi,zeropoint);
      else
	sprintf(newline, "Pareto (%s): "
		"sigma=%-7.3g ksi=%-7.3g x=x'-%5.3f", 
		est_method_name[(int) est_met],
		sigma, ksi, zeropoint);
    }
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%",
					  (char *) "P(model)=%7.3g%%"),
	    100.0*bayesian_model_probability);
  return newline;
}


//             FORMULA_PICTURE_PATH
// Returns the location of a picture describing the Pareto distribution
char *pareto_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/pareto.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("pareto.xbm").c_str());
#endif // NVE
  return newline;
}





//              GET_KSI
// Returns the 'ksi' value;
double pareto_distribution::get_ksi(void)
{
  return ksi;
}


//              GET_SIGMA
// Returns the 'sigma' value;
double pareto_distribution::get_sigma(void)
{
  return sigma;
}

// Return the zero-point;
double pareto_distribution::get_zero_point(void)
{
  return zeropoint;
}

void pareto_distribution::use_orig_curve(void)
{
  sigma=orig_sigma;
  ksi=orig_ksi;
}


void pareto_distribution::repick_parameters(void)
{
#ifdef GSL
  sigma=orig_sigma+gsl_ran_gaussian(gslptr, sdev_sigma);
  ksi=orig_ksi+gsl_ran_gaussian(gslptr, sdev_ksi);
#else
  sigma=orig_sigma+sdev_sigma*gauss();
  ksi=orig_ksi+sdev_ksi*gauss();
#endif // GSL
}


// Returns the MCMC 'sigma' value;
double *pareto_distribution::get_mcmc_sigma(void)
{
  return mcmc_sigma;
}

// Returns the MCMC 'ksi' value;
double *pareto_distribution::get_mcmc_ksi(void)
{
  return mcmc_ksi;
}


// Get samples quantiles:
double pareto_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  double x_rescaled=x-zeropoint;
  int i=sample_index;
  if(x_rescaled<=0.0 || 
     (mcmc_ksi[i]<0.0 && x_rescaled>=-mcmc_sigma[i]/mcmc_ksi[i]))
    return 0.0;
  
  if(mcmc_ksi[i]==0.0)
    return 1.0/mcmc_sigma[i] * exp(-x_rescaled/mcmc_sigma[i]);
  else
   return 1.0/mcmc_sigma[i] * pow(1.0+mcmc_ksi[i]*x_rescaled/mcmc_sigma[i], 
				  -1.0/mcmc_ksi[i]-1.0);
}

double pareto_distribution::mcmc_accumulated_function_sample(double x, 
							  int sample_index)
{
  if(num_mcmc<=0 || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;

  double x_rescaled=x-zeropoint;
  int i=sample_index;
  if(x_rescaled<=0.0)
    return 0.0;
  else if(mcmc_ksi[i]<0.0 && x_rescaled>=-mcmc_sigma[i]/mcmc_ksi[i])
    return 1.0;
  
  if(mcmc_ksi[i]==0.0)
    return 1.0 - exp(-x_rescaled/mcmc_sigma[i]);
  else
    return 1.0 - pow(1.0+mcmc_ksi[i]*x_rescaled/mcmc_sigma[i], 
		     -1.0/mcmc_ksi[i]);
}

double pareto_distribution::mcmc_get_quantile_sample(double prob, 
						  int sample_index)
{
  if(num_mcmc<=0 || !mcmc_sigma || !mcmc_ksi ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(mcmc_ksi[i]==0)
    return zeropoint-mcmc_sigma[i]*log(1.0-prob);
  else
    return zeropoint+mcmc_sigma[i]/mcmc_ksi[i]*(pow(1-prob,-mcmc_ksi[i])-1.0);
}
  


// ************************************************************* //
//                                                               //   
//               PLANCK_DISTRIBUTION                             //
//                                                               // 
// A subclass of 'distribution' representing a Planck            //
// distribution.                                                 //
//                                                               // 
// ************************************************************* //  

// Constructor
// Makes a Planck distribution based on a given dataset.
planck_distribution::planck_distribution(double *val, int len, 
					 double min, double max, 
					 int num_in_distrib, 
					 bool do_accumulate, 
					 ESTIMATION_METHOD use_est_met,
					 // should match 'num_par_combi' 
					 // in length
					 double *bayes_param_prior_mu, 
					 double *bayes_param_prior_sd,
					 int num_samples_, int burnin_, 
					 int spacing_, int num_temp_,
					 bool do_show_mcmc, 
					 bool do_show_debug,
					 bool ratio_based_prior,
					 // Historical (upper) threshold data:
					 int num_thresholds, 
					 historic_threshold *thresholds,
					 // Historical data:
					 int num_historical, 
					 historic_extreme_data *histdata) : 
  distribution("Planck")
{
  init();
  init_hyperparameters();
  numparam=3;
  accumulated_function_exists=false;
  allow_neg=true;
  ratio_based_higher_order_quantile_prior=ratio_based_prior;
  has_ratio_based_higher_order_quantile_prior=ratio_based_prior;
  
  int i;
  if(bayes_param_prior_mu)
    for(i=0;i<num_par_combi;i++)
      param_prior_mu[i]=bayes_param_prior_mu[i];
  if(bayes_param_prior_sd)
    for(i=0;i<num_par_combi;i++)
      param_prior_sd[i]=bayes_param_prior_sd[i];

  if(num_samples_>0)
    num_mcmc=num_samples_;
  if(burnin_>0)
    burnin=burnin_;
  if(spacing_>0)
    spacing=spacing_;
  if(num_temp_>0)
    num_temp=num_temp_;
  doshowmcmc=do_show_mcmc;
  doshowdebug=do_show_debug;
  
  Set(val, len, min, max, num_in_distrib, do_accumulate, use_est_met,
      num_thresholds, thresholds, num_historical, histdata);
}

planck_distribution::planck_distribution() : distribution("Planck") 
{
  init();
  init_hyperparameters();
  numparam=3;
  allow_neg=true;
  accumulated_function_exists=false;
}
  
// destructor;
planck_distribution::~planck_distribution() 
{
  cleanup();
  cleanup_hyperparameters();
}
  

void planck_distribution::init(void)
{
  mcmc_lambda0=NULL;
  mcmc_temp=NULL;
  mcmc_n=NULL;
}

void planck_distribution::cleanup(void)
{
  if(mcmc_lambda0)
    delete [] mcmc_lambda0;
  if(mcmc_temp)
    delete [] mcmc_temp;
  if(mcmc_n)
    delete [] mcmc_n;
  init();
}

void planck_distribution::init_hyperparameters(void)
{
  num_mcmc=1000;
  burnin=1000;
  spacing=10;
  num_temp=3;
  num_par_combi=3;
  numparam=3;
  
  parnames=new char*[numparam];
  for(int i=0;i<numparam;i++)
    parnames[i]=new char[20];
  strcpy(parnames[0],"x0");
  strcpy(parnames[1],"temp");
  strcpy(parnames[2],"n");
  
  parstatus=new PARAM_PRIOR_STATUS[numparam];
  parstatus[0]=PARAM_PRIOR_REAL;
  parstatus[1]=PARAM_PRIOR_POS;
  parstatus[2]=PARAM_PRIOR_POS;
  
  param_prior_mu=new double[num_par_combi];
  param_prior_sd=new double[num_par_combi];
  
  param_prior_mu[0]=0.0;
  param_prior_mu[1]=0.0;
  param_prior_mu[2]=0.0;
  
  param_prior_sd[0]=1000.0/1.96;
  param_prior_sd[1]=10.0/1.96;
  param_prior_sd[2]=10.0/1.96;
}

void planck_distribution::cleanup_hyperparameters(void)
{
  doubledelete(parnames, numparam);
  if(param_prior_mu)
    delete [] param_prior_mu;
  if(param_prior_sd)
    delete [] param_prior_sd;
  if(parstatus)
    delete [] parstatus;
}



//             SET
// Finds a Planck distribution based on a given dataset.
void planck_distribution::Set(double *val, int len, 
			      double min, double max, int num_in_distrib, 
			      bool do_accumulate, 
			      ESTIMATION_METHOD use_est_met,
			      // Historical (upper) threshold data:
			      int num_thresholds, 
			      historic_threshold *thresholds,
			      // Historical data:
			      int num_historical, 
			      historic_extreme_data *histdata)
{
  register int i;

  est_met=use_est_met;
  // Find min and max values;
  set_min_and_max(min, max, num_in_distrib);
  // Retrieve statistical values;
  get_stats(val, len);
  
  // If no such values could be found..
  if(status != DISTRIBUTION_FOUND && est_met!=EST_BAYES)
    return;

  lambda0=temp=n=MISSING_VALUE;
  if(skew>1.0)
    {
      // Find n using Newton's method
      double n0;
      n=n0=4.0;
      for(i=0;i<1000000 && ABSVAL(n0-n)/n>0.0001 && n>3.0; i++)
	{
	  n0=n;
	  n = n0 - (planckskew(n0)-skew)/derivated_planckskew(n0);
	}
    }
  else
    n=30.0;
  
  temp = sqrt(sigma_zeta(n))/sdev;
  lambda0 = mean - riemann_zeta(n)/(n*temp*riemann_zeta(n+1));

  sdev_n=sdev_temp=sdev_lambda0=MISSING_VALUE;
  
  if(est_met==EST_BAYES)
    {
      double Tbuff[]={1.0,2.0,3.0,4.0,4.7,6.0,7.0,8.0};
      char *names[]={"x0","log_temp","log_n"};
      double hyperpar[]={param_prior_mu[0], param_prior_sd[0],
			 param_prior_mu[1], param_prior_sd[1],
			 param_prior_mu[2], param_prior_sd[2]};
      // x0_mu, x0_sd, log_temp_mu, log_temp_sd,log_n_mu, log_n_sd;
      double *T=new double[8];
      for(i=0;i<8;i++)
	T[i]=Tbuff[i];
      
      int num_extra=0;
      char **planck_param_names=NULL;
      int curr_numpar=numparam;
      if(num_thresholds>0) // Historical data?
	planck_param_names=
	  set_hist_info_and_names(num_thresholds,thresholds,
				  num_historical,histdata, 
				  names, numparam,
				  &num_extra, &curr_numpar);
	// PS, only bayesian treatment has support for historical data
	// PSS: historical data requires threshold data
      else
	planck_param_names=dist_copy_strings(names, numparam);
      
      double **pars=mcmc(num_mcmc, burnin, spacing, num_temp,
			 &val, len, 1, 
			 curr_numpar,planck_param_names, T,0.15, 
			 num_par_combi, hyperpar,
			 init_planck,logprior_planck,loglik_planck,
			 doshowdebug ? false : true, false, doshowmcmc);
      delete [] T;
      
      bayesian_model_log_likelihood= 
	log_model_likelihood_multistudent(numparam*(num_mcmc*spacing+burnin),
					  pars, curr_numpar, num_mcmc,
					  &val, len, 1,
					  num_par_combi,hyperpar,
					  logprior_planck,loglik_planck);
      
      if(pars)
	{
	  mcmc_lambda0=new double[num_mcmc];
	  mcmc_temp=new double[num_mcmc];
	  mcmc_n=new double[num_mcmc];
	  for(i=0;i<num_mcmc;i++)
	    {
	      mcmc_lambda0[i]=pars[i][0];
	      mcmc_temp[i]=exp(pars[i][1]);
	      mcmc_n[i]=exp(pars[i][2]);
	    }
	}
      
      lambda0=find_statistics(mcmc_lambda0, num_mcmc, MEAN);
      temp=find_statistics(mcmc_temp, num_mcmc, MEAN);
      n=find_statistics(mcmc_n, num_mcmc, MEAN);
      sdev_lambda0=find_statistics(mcmc_lambda0, num_mcmc, STANDARD_DEVIATION);
      sdev_temp=find_statistics(mcmc_temp, num_mcmc, STANDARD_DEVIATION);
      sdev_n=find_statistics(mcmc_n, num_mcmc, STANDARD_DEVIATION);

      if(num_extra>0)
	store_historical_mcmc_estimates(pars, num_mcmc, numparam, false);
      
      cleanup_hist_and_names(planck_param_names,curr_numpar,pars,num_mcmc);
    }
  else if(est_met==EST_ML)
    {
      int bufferlen=10;
      double input[]={n, temp, lambda0}, *output;

      planck_likelihood_n=len;   
      planck_likelihood_X=val;
      
      output=multinewtonraphson(planck_likelihood, 3, input, 1e-5, 
				bufferlen, false);
      
      n=output[0];
      temp=output[1];
      lambda0=output[2];

      double **ddf=newton_numeric_doubleder(output); 
      double **iddf=NULL;
      if(!almost_equal(determinant_matrix(ddf,3),0.0))
	iddf=inverse_matrix(ddf, 3);
      else
	iddf=make_matrix(3,3);

      sdev_n=-iddf[0][0];
      sdev_temp=-iddf[1][1];
      sdev_lambda0=-iddf[2][2];

      sdev_n=sqrt(ABSVAL(sdev_n));
      sdev_temp=sqrt(ABSVAL(sdev_temp));
      sdev_lambda0=sqrt(ABSVAL(sdev_lambda0));

      delete [] ddf[0];
      delete [] ddf[1];
      delete [] ddf[2];
      delete [] ddf;
      delete [] iddf[0];
      delete [] iddf[1];
      delete [] iddf[2];
      delete [] iddf;

      delete [] output;
    }

  if(!visited)
    {
      orig_n=n;
      orig_temp=temp;
      orig_lambda0=lambda0;
      visited=true;
    }

  // traverse the distribution;
  for(i=0; i< distrib_len; i++)
    {
      // Find the argmuent;
      double x = min + ((double) i)*step;

      distrib_arg[i] = x;  // set the argument element    
      distrib_val[i] = function(x); // set the value element
    }

  if(do_accumulate)
    accumulate();
}


// Sends a description of the Planck distribution to the output stream;
void planck_distribution::printhelp(std::ostream &out)
{
  out << "Planck-fordelingen, er en vanlig" << std::endl;
  out << "fordeling av verdier i fysikken. Etter en konform "
    "transformasjon skal de fleste tidsserier" << std::endl;
  out << "ha en form som en Planck-fordeling "
    "if�lge de enkleste hvis endringene skjer via de enkleste " << std::endl << 
    "reglene for interaksjon med milj�et " << std::endl;
  out << "Fordelingen avhenger av verdienes "
    "gjennomsnittsverdi, standardavvik og skjevhet" << std::endl <<
    "(som ikke b�r v�re under eller lik 1." << std::endl;
  out << "Gjennomsnittsverdien forteller hvor fordelingen "
    "vil toppe seg, mens" << std::endl;
  out << "standardavviket forteller hvor skarp toppen er." << std::endl;
  out << "Moment-metoden bruker 1ste,2dre og 3dje ordens momenter " << std::endl;
  out << "(gjennomsnitt, standardavvik og skjevehet) til � tilpasse " << std::endl;
  out << "fordelingen til observasjonene." << std::endl;
  out << "Max-likelihood er en numerisk metode for � finne den tilpassingen" <<
    std::endl;
  out << "som gj�r observasjonene mest sannsynelige." << std::endl;
  out << "" << std::endl;
  out << " - Trond Reitan (30/5-2000)" << std::endl;
}


// Returns a short string description of the Planck distribution
char *planck_distribution::description(void)
{
  char *newline= new char[1000];
  if(sdev_lambda0!=MISSING_VALUE && sdev_n!=MISSING_VALUE &&
     sdev_temp!=MISSING_VALUE)
    sprintf(newline, "Planck (%s): "
	    "f(x)=1/gamma(n+1)zeta(n+1)T^(n+1)x^(n+2)exp(1/((x-x0)T)))"  
	    "  x0=%-7.3g+-%-6.2g T=%-7.3g+-%-6.2g n=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met],
	    lambda0, sdev_lambda0, temp, sdev_temp, n, sdev_n);
  else
    sprintf(newline, "Planck (%s): "
	    "f(x)=1/gamma(n+1)zeta(n+1)T^(n+1)x^(n+2)exp(1/((x-x0)T)))"  
	    "  x0=%-7.3g T=%-7.3g n=%-7.3g", 
	    est_method_name[(int) est_met],
	    lambda0, temp, n);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}

// Returns a shorter string description of the Planck distribution
char *planck_distribution::short_description(void)
{
  char *newline= new char[1000];
  if(sdev_lambda0!=MISSING_VALUE && sdev_n!=MISSING_VALUE &&
     sdev_temp!=MISSING_VALUE)
    sprintf(newline, "Planck (%s): "  
	    "x0=%-7.3g+-%-6.2g T=%-7.3g+-%-6.2g n=%-7.3g+-%-6.2g", 
	    est_method_name[(int) est_met],
	    lambda0, sdev_lambda0, temp, sdev_temp, n, sdev_n);
  else
    sprintf(newline, "Planck (%s): "  
	    "x0=%-7.3g T=%-7.3g n=%-7.3g", 
	    est_method_name[(int) est_met],
	    lambda0, temp, n);
  if(est_met==EST_BAYES && bayesian_model_probability!=MISSING_VALUE)
    sprintf(newline+strlen(newline), WHAT((char *) "P(modell)=%7.3g%%", 
					  (char *) "P(model)=%7.3g%%"), 
	    100.0*bayesian_model_probability);
  return newline;
}


// Returns the location of a picture describing the Planck distribution
char *planck_distribution::formula_picture_path(void)
{
  char *newline= new char[400];
#ifndef NVE
#ifdef LIBDIR
  sprintf(newline, "%s/planck3.xbm", LIBDIR);
#else
  strcpy(newline,"");
#endif // LIBDIR
#else // NVE specific code
  strcpy(newline,(char*)hydraenvir::path::icon("planck3.xbm").c_str());
#endif // NVE
  return newline;
}


// Returns the value of the Planck distribution for a given argument
double planck_distribution::function(double arg)
{
  if(est_met==EST_BAYES && mcmc_lambda0 && mcmc_temp && mcmc_n)
    {
      double ret=0.0;
      int i;
      for(i=0;i<num_mcmc;i++)
	if(!(arg<=mcmc_lambda0[i] || mcmc_lambda0[i]==MISSING_VALUE))
	  ret+=1.0/(exp(lgamma(mcmc_n[i]+1.0))*riemann_zeta(mcmc_n[i]+1.0)*
	      pow(mcmc_temp[i], mcmc_n[i]+1.0)*pow(arg-mcmc_lambda0[i], mcmc_n[i]+2.0)*
	      (exp(1.0/((arg-mcmc_lambda0[i])*mcmc_temp[i]))-1.0));
      
      ret/=double(num_mcmc);
      
      return ret;
    }
  else if(arg<=lambda0 || lambda0==MISSING_VALUE)
    return 0.0;
  else
    return 1.0/(exp(lgamma(n+1.0))*riemann_zeta(n+1.0)*
	      pow(temp, n+1.0)*pow(arg-lambda0, n+2.0)*
	      (exp(1.0/((arg-lambda0)*temp))-1.0));
}


  
// Returns the 'lambda0' value;
double planck_distribution::get_lambda0(void)
{
  return lambda0;
}


// Returns the 'temperature' value;
double planck_distribution::get_temp(void)
{
  return temp;
}


// Returns the 'n' (dimension) value;
double planck_distribution::get_n(void)
{
  return n;
}

void planck_distribution::use_orig_curve(void)
{
  n=orig_n;
  temp=orig_temp;
  lambda0=orig_lambda0;
}


void planck_distribution::repick_parameters(void)
{
#ifdef GSL
  n=orig_n+gsl_ran_gaussian(gslptr, sdev_n);
  temp=orig_temp+gsl_ran_gaussian(gslptr, sdev_temp);
  lambda0=orig_lambda0+gsl_ran_gaussian(gslptr, sdev_lambda0);
#else
  n=orig_n+sdev_n*gauss();
  temp=orig_temp+sdev_temp*gauss();
  lambda0=orig_lambda0+sdev_lambda0*gauss();
#endif // GSL
}


// Returns the MCMC 'lambda0' value;
double *planck_distribution::get_mcmc_lambda0(void)
{
  return mcmc_lambda0;
}

// Returns the MCMC 'temp' value;
double *planck_distribution::get_mcmc_temp(void)
{
  return mcmc_temp;
}

// Returns the MCMC 'temp' value;
double *planck_distribution::get_mcmc_n(void)
{
  return mcmc_n;
}


// Get samples quantiles:
double planck_distribution::mcmc_function_sample(double x, int sample_index)
{
  if(num_mcmc<=0 || !mcmc_lambda0 || !mcmc_temp || !mcmc_n ||
     sample_index<0 || sample_index>num_mcmc)
    return MISSING_VALUE;
  
  int i=sample_index;
  if(x<=mcmc_lambda0[i] || mcmc_lambda0[i]==MISSING_VALUE)
    return 0.0;
  
  return 1.0/(exp(lgamma(mcmc_n[i]+1.0))*riemann_zeta(mcmc_n[i]+1.0)*
	      pow(mcmc_temp[i], mcmc_n[i]+1.0)*pow(x-mcmc_lambda0[i], mcmc_n[i]+2.0)*
	      (exp(1.0/((x-mcmc_lambda0[i])*mcmc_temp[i]))-1.0));
}



//               COMPOSITE_BAYESIAN_DISTRIBUTION
// The class consisting of composite distribution treated
// in a Bayesian fashion.

composite_bayesian_distribution::composite_bayesian_distribution(
   distribution **distribs, int num_dists) : distribution()
{
  int i,j;

  dist=NULL;
  p_model=NULL;
  p_cumulative=NULL;
  numdist=0;

  if(num_dists<=1)
    {
      std::cerr << "Program error: Cannot do composite Bayesian analysis on no "
	"or a single distribution!" << std::endl;
      return;
    }

  for(i=0;i<num_dists;i++)
    {
      if(distribs[i]->est_met!=EST_BAYES)
	{
	  std::cerr << "Program error. Doing Bayesian composite analysis on "
	    "non-Bayesian distributions!" << std::endl;
	  return;
	}
      if(i>0 && distribs[i-1]->accumulated!=distribs[i]->accumulated)
	{
	  std::cerr << "Program error. Doing Bayesian composite analysis on "
	    "distributions where some have accumulated probabilities and "
	    "some have probability densities!" << std::endl;
	  return;
	}
    }
  
  dist=distribs;
  numdist=num_dists;
  
  minval=dist[0]->minval;
  maxval=dist[0]->maxval;
  step=dist[0]->step;
  mean=dist[0]->mean;
  logmean=dist[0]->logmean;
  logsdev=dist[0]->logsdev;
  sdev=dist[0]->sdev;
  skew=dist[0]->skew;
  a0=dist[0]->a0;
  a1=dist[0]->a1;
  a2=dist[0]->a2;
  b0=dist[0]->b0;
  b1=dist[0]->b1;
  b2=dist[0]->b2;
  truelen=distrib_len=origlen=dist[0]->distrib_len;
  num_mcmc=10*dist[0]->num_mcmc;

  distrib_arg=new double[distrib_len];
  for(i=0;i<distrib_len;i++)
    distrib_arg[i]=dist[0]->distrib_arg[i];
  
  numparam=0;
  est_met=EST_BAYES;
  accumulated_function_exists=false;
  accumulated=dist[0]->accumulated;
  
  double *loglik_model=new double[numdist];
  for(i=0;i<numdist;i++)
    loglik_model[i]=dist[i]->get_bayesian_log_model_likelihood();
  double maxloglik=find_statistics(loglik_model, numdist, MAX);
  
  p_model=new double[numdist];
  p_cumulative=new double[numdist];
  for(i=0;i<numdist;i++)
    p_model[i]=exp(loglik_model[i]-maxloglik);
  double sum_p=find_statistics(p_model, numdist,SUM);
  for(i=0;i<numdist;i++)
    p_model[i]/=sum_p;
  for(i=0;i<numdist;i++)
    dist[i]->bayesian_model_probability=p_model[i];
  p_cumulative[0]=p_model[0];
  for(i=1;i<numdist;i++)
    p_cumulative[i]=p_cumulative[i-1]+p_model[i];
  sum_p=find_statistics(p_cumulative, numdist,SUM);
  for(i=0;i<numdist;i++)
    p_cumulative[i]/=sum_p;
  
  origval=new double[distrib_len];
  distrib_val=new double[distrib_len];
  for(i=0;i<distrib_len;i++)
    {
      distrib_val[i]=0.0;
      for(j=0;j<numdist;j++)
	distrib_val[i]+=p_model[j]*dist[j]->distrib_val[i];
      origval[i]=distrib_val[i];
    }
}

composite_bayesian_distribution::~composite_bayesian_distribution()
{
  /* do not delete dist, as it is externally defined
  if(dist)
    delete [] dist;
  */
  if(p_model)
    delete [] p_model;
  if(p_cumulative)
    delete [] p_cumulative;
  numdist=0;
}

// Returns the value of the composite distribution for a given argument
double composite_bayesian_distribution::function(double arg)
{
  double ret=0.0;
  for(int i=0;i<numdist;i++)
    ret+=dist[i]->function(arg);
  return ret;
}


double composite_bayesian_distribution::accumulated_function(double arg)
{
  double ret=0.0;
  for(int i=0;i<numdist;i++)
    ret+=dist[i]->accumulated_function(arg);
  return ret;
}

// Returns a short string description of the composite distribution
char *composite_bayesian_distribution::description(void)
{
  char *newline= new char[1000];
  strcpy(newline, WHAT((char *)  "Bayesiansk modellsnitt:", 
			(char *) "Bayesian model mean:"));
  for(int i=0;i<numdist;i++)
    sprintf(newline+strlen(newline), "%s%5.2f%s", (i>0 ? "+" : ""),
	    dist[i]->bayesian_model_probability,dist[i]->shortname);
  return newline;
}

// Returns a short string description of the Planck distribution
char *composite_bayesian_distribution::short_description(void)
{
  char *newline= new char[1000];
  strcpy(newline, WHAT((char *)  "Bayesiansk modellsnitt:", 
			(char *) "Bayesian model mean:"));
  for(int i=0;i<numdist;i++)
    sprintf(newline+strlen(newline), "%s%5.2f%s", (i>0 ? "+" : ""),
	    dist[i]->bayesian_model_probability,dist[i]->shortname);
  return newline;
}


double *composite_bayesian_distribution::
get_cumulative_model_probabilities(void)
{
  return p_cumulative;
}

double *composite_bayesian_distribution::
get_model_probabilities(void)
{
  return p_model;
}

int composite_bayesian_distribution::sample_model(void)
{
  int i=0;
  double r=drand48();
  for(i=0;i<numdist;i++)
    if(r<p_cumulative[i])
      return i;
  return numdist-1;
}

// Get samples quantiles:
double composite_bayesian_distribution::mcmc_function_sample(double x, 
							     int sample_index)
{
  int m=sample_model();
  return dist[m]->mcmc_function_sample(x, sample_index % dist[m]->num_mcmc);
}

double composite_bayesian_distribution::
mcmc_accumulated_function_sample(double x,int sample_index)
{
  int m=sample_model();
  return dist[m]->mcmc_accumulated_function_sample(x, sample_index % 
						   dist[m]->num_mcmc);
}

double composite_bayesian_distribution::
mcmc_get_quantile_sample(double prob, int sample_index)
{
  int m=sample_model();
  return dist[sample_model()]->mcmc_get_quantile_sample(prob, sample_index % 
							dist[m]->num_mcmc);
}

