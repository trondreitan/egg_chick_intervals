/*
 * $Id: interpolation.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/interpolation.C $
 */

#include <hydrasub/hydrabase/interpolation.H>
#ifdef GSL
#include <gsl/gsl_linalg.h>
#endif // GSL
#include <cmath>
#include <fstream>

// initialize the math module
void geo_interpolation::init(void)
{
  x=y=z=NULL;
  numpoints=numvar=numtriangles=0;
  scheme=UNKNOWN_INTERPOLATION_SCHEME;
#ifdef GSL
  variogram_matrix=NULL;
  inverse_variogram_matrix=NULL;
#endif // GSL
  variogram=vardist=NULL;
  triangles=NULL;
}

// cleanup all arrays in the math module
void geo_interpolation::cleanup(void)
{
  if(x)
    delete [] x;
  if(y)
    delete [] y;
  if(z)
    delete [] z;
#ifdef GSL  
  if(variogram_matrix)
    gsl_matrix_free(variogram_matrix);
  if(inverse_variogram_matrix)
    gsl_matrix_free(inverse_variogram_matrix);
#endif // GSL
  if(variogram)
    delete [] variogram;
  if(vardist)
    delete [] vardist;
  if(triangles)
    delete [] triangles;
  init();
}

// Set the input measurements and do what's necessray to do
// interpolation on these points;
void geo_interpolation::Set(INTERPOLATION_SCHEME scheme_, int num_points,
			    double *X, double *Y, double *Z)
{
  scheme=scheme_;
  numpoints=num_points;
  x=new double[numpoints];
  y=new double[numpoints];
  z=new double[numpoints];
  
  for(int i=0;i<numpoints;i++)
    {
      x[i]=X[i];
      y[i]=Y[i];
      z[i]=Z[i];
    }

  // find max distance between any two points;
  find_max_distance();

  if(scheme==GAUSS_KRIGING || scheme==SPHERICAL_KRIGING || 
     scheme==EXP_KRIGING || scheme==LIN_KRIGING ||
     scheme==QUAD_KRIGING || scheme==RATIONAL_KRIGING || scheme==HOLE_KRIGING)
    init_kriging();
  else if(scheme==TRIANGULAR_NEIGHBOURS)
    init_triangular();
}

// find the maximal distance between the measured points;
void geo_interpolation::find_max_distance(void)
{
  maxdist=0.0;

  for(int i=0;i<numpoints;i++)
    for(int j=0;j<numpoints;j++)
      maxdist=MAXIM(maxdist, (x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]));
  
  maxdist=sqrt(maxdist);
}

// Find the raw values for the variogram 
void geo_interpolation::find_variogram(void)
{
  double step=5.0*maxdist/double(numpoints);
  int i,j,index,numbuffer=int(maxdist/step)+1;
  double *varbuffer=new double[numbuffer];
  int *numhits=new int[numbuffer];
  
  // find statistical values;
  mean=0.0; variance=0.0;

  for(i=0;i<numpoints;i++)
    mean+=z[i];
  mean/=double(numpoints);
  for(i=0;i<numpoints;i++)
    variance+=(z[i]-mean)*(z[i]-mean);
  variance/=double(numpoints-1);
  //cout << "mean=" << mean << " var=" << variance << endl;

  for(i=0;i<numbuffer;i++)
    {
      varbuffer[i]=0.0;
      numhits[i]=0;
    }

  // find the sum products for each pair of points
  for(i=0;i<numpoints;i++)
    for(j=0;j<numpoints;j++)
      {
	double dx=x[i]-x[j];
	double dy=y[i]-y[j];
	double r=sqrt(dx*dx+dy*dy);
	double cross=(z[i]-z[j])*(z[i]-z[j]);

	index=int((r+step/2.0)/step);
	if(index>=0 && index<numbuffer)
	  {
	    varbuffer[index]+=cross;
	    numhits[index]++;
	  }
      }

  // divide the sum products with the number of hits;
  numvar=numbuffer;
  for(i=numbuffer-1;i>=0;i--)
    if(numhits[i]>0)
      varbuffer[i]/=double(numhits[i]);
    else if(i>0)
      numvar=i+1;

  // only count up to the last increasing variogram value
  for(i=1;i<numvar;i++)
    if(varbuffer[i]<varbuffer[i-1])
      break;
  numvar=i;

  // set the variogram arrays;
  variogram=new double[numvar];
  vardist=new double[numvar];
  for(i=0;i<numvar;i++)
    {
      variogram[i]=varbuffer[i];
      vardist[i]=i*step;
    }


  delete [] numhits;
  delete [] varbuffer;
}

// Return a gauss-adjusted variogram value for a given distance;
double geo_interpolation::gauss_variogram(double distance)
{
  double ret;
  double c0=variogram[0];
  double a=vardist[numvar-1];
  double c1=variogram[numvar-1]-c0;

  if(distance==0)
    ret=0.0;
  else
    ret=c0+c1*(1.0-exp(-3.0*distance*distance/a/a));

  return ret;
}

// Return a spherical-adjusted variogram value for a given distance;
double geo_interpolation::sphere_variogram(double distance)
{
  double ret;
  double c0=variogram[0];
  double a=vardist[numvar-1];
  double c1=variogram[numvar-1]-c0;
  double h=distance/a;

  if(distance==0)
    ret=0.0;
  else if(h<1.0)
    ret=c0+c1*(1.5*h-0.5*h*h*h);
  else
    ret=c0+c1;

  return ret;
}

// Return a piecewise linear-adjusted variogram value for a given distance;
double geo_interpolation::lin_variogram(double distance)
{
  int i;
  double ret=0.0;
  
  for(i=1;i<numvar;i++)
    if(distance>=vardist[i-1] && distance<vardist[i])
      break;
  if(i>=numvar)
    i=numvar-1;

  double var1=variogram[i-1];
  double var2=variogram[i];

  ret=linear(vardist[i-1], var1, vardist[i], var2, distance);
  
  return ret;
}

// Return a exponensial-adjusted variogram value for a given distance;
double geo_interpolation::exp_variogram(double distance)
{
  double ret;
  double c0=variogram[0];
  double a=vardist[numvar-1];
  double c1=variogram[numvar-1]-c0;
  double h=distance/a;

  if(distance==0)
    ret=0.0;
  else 
    ret=c0+c1*(1-exp(-h));

  return ret;
}

// Return a quadratic-adjusted variogram value for a given distance;
double geo_interpolation::quad_variogram(double distance)
{
  double ret;
  double c0=variogram[0];
  double a=vardist[numvar-1];
  double c1=variogram[numvar-1]-c0;
  double h=distance/a;

  if(distance==0)
    ret=0.0;
  else if(h<1.0)
    ret=c0+c1*(2.0*h-h*h);
  else
    ret=c0+c1;

  return ret;
}

// Return a rational quadratic-adjusted variogram value for a given distance;
double geo_interpolation::rational_variogram(double distance)
{
  double ret;
  double c0=variogram[0];
  double a=vardist[numvar-1];
  double c1=variogram[numvar-1]-c0;
  double h=distance/a;

  if(distance==0)
    ret=0.0;
  else 
    ret=c0+c1*(h*h/(1+h*h));

  return ret;
}


// Return a hole-adjusted variogram value for a given distance;
double geo_interpolation::hole_variogram(double distance)
{
  double ret;
  double c0=variogram[0];
  double a=vardist[numvar-1];
  double c1=variogram[numvar-1]-c0;
  double h=distance/a;

  if(distance==0)
    ret=0.0;
  else 
    ret=c0+c1*(1.0-sin(2.0*M_PI*h)/(2.0*M_PI*h));

  return ret;
}

// Return an adjusted variogram value for a given distanceand
// and arbitrary variogram adjustment scheme;
double geo_interpolation::variogram_value(double x0, double y0, 
					  double x1, double y1)
{
  double r=sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0));
  double ret=0.0;

  switch(scheme)
    {
    case GAUSS_KRIGING:
      ret=gauss_variogram(r);
      break;
    case SPHERICAL_KRIGING:
      ret=sphere_variogram(r);
      break;
    case EXP_KRIGING:
      ret=exp_variogram(r);
      break;
    case LIN_KRIGING:
      ret=lin_variogram(r);
      break;
    case QUAD_KRIGING:
      ret=quad_variogram(r);
      break;
    case RATIONAL_KRIGING:
      ret=rational_variogram(r);
      break;
    case HOLE_KRIGING:
      ret=hole_variogram(r);
      break;
    default:
      break;
    }

  return ret;
}

// initialize the math module when triangulation is required;
void geo_interpolation::init_triangular(void)
{
  triangles=delaunay_triangulation(x, y, numpoints, &numtriangles);
}

// initialize the math module when kriging is required;
void geo_interpolation::init_kriging(void)
{
  int i, j, sign=1;

  find_variogram();

  // make the matrixes;
#ifdef GSL  
  variogram_matrix=gsl_matrix_alloc(numpoints+1, numpoints+1);
  inverse_variogram_matrix=gsl_matrix_alloc(numpoints+1, numpoints+1);
  gsl_permutation *perm=gsl_permutation_calloc(numpoints+1);

  gsl_permutation_init(perm);


  // Set the values of the variogram matrix
  for(i=0;i<numpoints;i++)
    for(j=0;j<numpoints;j++)
      gsl_matrix_set(variogram_matrix, i, j, 
		     variogram_value(x[i],y[i],x[j],y[j]));
  for(i=0;i<numpoints;i++)
    gsl_matrix_set(variogram_matrix, i, numpoints, 1.0);
  for(j=0;j<numpoints;j++)
    gsl_matrix_set(variogram_matrix, numpoints, j, 1.0);
  gsl_matrix_set(variogram_matrix, numpoints, numpoints, 0.0);

  // invert the matrix;
  gsl_linalg_LU_decomp(variogram_matrix, perm, &sign);
  gsl_linalg_LU_invert(variogram_matrix, perm, inverse_variogram_matrix);  

  gsl_permutation_free(perm);
#endif // GSL
}

// find the indexes of the 'number' nearest neighbours in the measurement
// array to a given point;
int *geo_interpolation::find_nearest_neighbour_index(double x0, double y0, 
						     int number)
{
  int *nearest=new int[number], i, j, k;

  for(i=0;i<number;i++)
    {
      double mindistsquare=MISSING_VALUE;
      
      for(j=0;j<numpoints;j++)
	{
	  int found=0;
	  
	  for(k=0;k<i;k++)
	    if(nearest[k]==j)
	      found=1;

	  if(!found)
	    {
	      double distsquare=(x[j]-x0)*(x[j]-x0)+(y[j]-y0)*(y[j]-y0);
	      
	      if(distsquare<mindistsquare || mindistsquare==MISSING_VALUE)
		{
		  mindistsquare=distsquare;
		  nearest[i]=j;
		}
	    }
	}
    }
  
  return nearest;
}

// check if (x0,y0) lies withing the triangle (x1,y1),(x2,y2),(x3,y3);
bool within_triangle(double x0, double y0, 
			double x1, double y1,
			double x2, double y2, 
			double x3, double y3)
{
  // contruct the vectors A=(x1,y1)->(x2,y2), B=(x1,y1)->(x3,y3) and
  // C=(x1,y1)->(x0,y0)
  double xa=x2-x1, ya=y2-y1, xb=x3-x1, yb=y3-y1, xd=x0-x1, yd=y0-y1;

  // construct the vector D as a product of A and B (D=aA+bB)
  double a=xd*yb-xb*yd, b=xa*yd-xd*ya, det=xa*yb-xb*ya;
  a/=det;
  b/=det;

  if(a>=0.0 && b>=0.0 && a+b<=1.0)
    return true;
  else
    return false;
}

// find the x coordinate of the circumcircle of a triangle;
double circumcircle_center_x(double x1, double y1,
			     double x2, double y2, double x3, double y3)
{
  // Make the vectors A=(p3-p1) and B=(p2-p1), where pn=(xn,yn)
  double xa=x3-x1, ya=y3-y1, xb=x2-x1, yb=y2-y1;
  
  // Find the coefficient 'k' in the equation; A+kNA=B+lNB where
  // NA is the normal of the vector A and NB is the same for B
  // This will give the center of the circumcirle...
  double k=(xb*(xb-xa)+yb*(yb-ya))/(ya*xb-xa*yb);

  // find the center y coordiante;
  double xc=x1+0.5*(xa+k*ya);

  return xc;
}

// find the y coordinate of the circumcircle of a triangle;
double circumcircle_center_y(double x1, double y1,
			     double x2, double y2, double x3, double y3)
{
  // Make the vectors A=(p3-p1) and B=(p2-p1), where pn=(xn,yn)
  double xa=x3-x1, ya=y3-y1, xb=x2-x1, yb=y2-y1;
  
  // Find the coefficient 'k' in the equation; A+kNA=B+lNB where
  // NA is the normal of the vector A and NB is the same for B
  // This will give the center of the circumcirle...
  double k=(xb*(xb-xa)+yb*(yb-ya))/(ya*xb-xa*yb);

  // find the center y coordiante;
  double yc=y1+0.5*(ya-k*xa);

  return yc;
}

// check if (x0,y0) lies withing the circumcircle of the 
// triangle (x1,y1),(x2,y2),(x3,y3);
bool within_circumcircle(double x0, double y0, double x1, double y1,
			    double x2, double y2, double x3, double y3)
{
  // find the center coordiantes;
  double xc=circumcircle_center_x(x1,y1,x2,y2,x3,y3);
  double yc=circumcircle_center_y(x1,y1,x2,y2,x3,y3);

  // find the square radius;
  double rsquare=((xc-x1)*(xc-x1)+(yc-y1)*(yc-y1));
  
  if((x0-xc)*(x0-xc)+(y0-yc)*(y0-yc)<rsquare)
    return true;
  else
    return false;
}

// Find the angle of the vector from (x0,y0) to (x1,y1);
double find_angle(double x0, double y0, double x1, double y1)
{
  double arctan=(y1-y0)/(x1-x0);
  double angle=atan(arctan);

  if(x1<x0)
    angle+=M_PI;
  else if(angle<0.0)
    angle+=2.0*M_PI;
  
  return angle;
}

// find the area of a triangle (x1,y1),(x2,y2),(x3,y3);
double find_triangle_area(double x1, double y1,
			  double x2, double y2, 
			  double x3, double y3)
{
  // contruct the vectors A=(x1,y1)->(x2,y2), B=(x1,y1)->(x3,y3) and
  // C=(x1,y1)->(x0,y0)
  double xa=x2-x1, ya=y2-y1, xb=x3-x1, yb=y3-y1;

  double dotprod=ABSVAL(((xa*yb-xb*ya)/2.0));

  return dotprod;
}

// find the indexes of the vertexes whose delaunay triangulation contains
// the given point;
int *geo_interpolation::find_triangular_neighbour_index(double x0, double y0,
							bool *extrapolated)
{
  int i, *tri_index=new int[3];

  *extrapolated=false;

  // traverse all triangles;
  for(i=0;i<numtriangles;i++)
    {
      double x1=x[triangles[i].index1], y1=y[triangles[i].index1];
      double x2=x[triangles[i].index2], y2=y[triangles[i].index2];
      double x3=x[triangles[i].index3], y3=y[triangles[i].index3];

      // if the examined point is within the examined triangle....
      if(within_triangle(x0, y0, x1, y1, x2, y2, x3, y3))
	{
	  // set the indexes and return;
	  tri_index[0]=triangles[i].index1;
	  tri_index[1]=triangles[i].index2;
	  tri_index[2]=triangles[i].index3;
	  return tri_index;
	}
    }

  *extrapolated=true;

  // The examined point was not inside any triangle, we'll need to extrapolate;
  double minsquare=MISSING_VALUE; // minimal square distance to a triangle

  // traverse all triangles again;
  for(i=0;i<numtriangles;i++)
    {
      // fetch the coordinates of the examined triangle;
      double x1=x[triangles[i].index1], y1=y[triangles[i].index1];
      double x2=x[triangles[i].index2], y2=y[triangles[i].index2];
      double x3=x[triangles[i].index3], y3=y[triangles[i].index3];

      // fetch the square distance to the circumcirle center of the triangle;
      double xc=circumcircle_center_x(x1, y1, x2, y2, x3, y3);
      double yc=circumcircle_center_y(x1, y1, x2, y2, x3, y3);
      double squaredist=(xc-x0)*(xc-x0)+(yc-y0)*(yc-y0);
      
      // if this is less than any previously examined triangles...
      if(minsquare==MISSING_VALUE || squaredist<minsquare)
	{
	  // store the square distance and it's indexes;
	  minsquare=squaredist;
	  tri_index[0]=triangles[i].index1;
	  tri_index[1]=triangles[i].index2;
	  tri_index[2]=triangles[i].index3;
	}
    }

  return tri_index; // return the nearest triangle indexes...
}

// interpolate using nearest neightbour;
double geo_interpolation::nearest_neighbour_value(double x0, double y0)
{
  int *nearest=find_nearest_neighbour_index(x0, y0, 1);
  double ret=z[nearest[0]];
  
  delete [] nearest;
  
  return ret;
}

// interpolate using the two nearest neightbour;
double geo_interpolation::nearest_two_neighbours_value(double x0, double y0)
{
  int *nearest=find_nearest_neighbour_index(x0, y0, 2);

  double dist12= // distance between the two nearest points
    sqrt((x[nearest[1]]-x[nearest[0]])*(x[nearest[1]]-x[nearest[0]])+
	 (y[nearest[1]]-y[nearest[0]])*(y[nearest[1]]-y[nearest[0]]));

  // dot product yeilds the dist12 times the projected vector between 
  // (x0,y0) and the nearest point
  double dotprod=(x0-x[nearest[0]])*(x[nearest[1]]-x[nearest[0]])+
    (y0-y[nearest[0]])*(y[nearest[1]]-y[nearest[0]]);

  // linear interpolation between the values of the two nearest points
  double ret=linear(0.0, z[nearest[0]], dist12, z[nearest[1]], dotprod/dist12);

  delete [] nearest;
  
  return ret;
}

// interpolate using the three nearest neightbour (dangerous) or
// using triangulation;
double geo_interpolation::nearest_three_neighbours_value(double x0, double y0,
							 bool extrapolate)
{
  int i, sign=1;
  int *nearest;

#ifdef GSL
  gsl_matrix *matrix=gsl_matrix_alloc(3,3);
  gsl_matrix *matrix2=gsl_matrix_alloc(3,3);
  gsl_permutation *perm=gsl_permutation_calloc(3);
  gsl_permutation_init(perm);
#endif // GSL
  
  bool extrapolated;

  if(scheme==THREE_NEAREST_NEIGHBOURS)
    nearest=find_nearest_neighbour_index(x0, y0, 3);
  else // scheme==TRIANGULAR_NEIGHBOURS
    nearest=find_triangular_neighbour_index(x0, y0, &extrapolated);
  
  // want to interpolate using a plane; z=ax+by+c 
  double a=0,b=0,c=0;

#ifdef GSL
  // put the coordinates of the vertex of the triangle as well as the 
  // measured values in the vertexes into a matrix;
  for(i=0;i<3;i++)
    {
      gsl_matrix_set(matrix, i, 0, x[nearest[i]]);
      gsl_matrix_set(matrix, i, 1, y[nearest[i]]);
      gsl_matrix_set(matrix, i, 2, 1);
    }

  // invert the matrix;
  gsl_linalg_LU_decomp(matrix, perm, &sign);
  gsl_linalg_LU_invert(matrix, perm, matrix2);

  // find the paramteters z=ax+by+c that runs trouch all three vertexes;
  a=gsl_matrix_get(matrix2, 0, 0)*z[nearest[0]]+
    gsl_matrix_get(matrix2, 0, 1)*z[nearest[1]]+
    gsl_matrix_get(matrix2, 0, 2)*z[nearest[2]];
  b=gsl_matrix_get(matrix2, 1, 0)*z[nearest[0]]+
    gsl_matrix_get(matrix2, 1, 1)*z[nearest[1]]+
    gsl_matrix_get(matrix2, 1, 2)*z[nearest[2]];
  c=gsl_matrix_get(matrix2, 2, 0)*z[nearest[0]]+
    gsl_matrix_get(matrix2, 2, 1)*z[nearest[1]]+
    gsl_matrix_get(matrix2, 2, 2)*z[nearest[2]];

  // cleanup;
  gsl_matrix_free(matrix);
  gsl_matrix_free(matrix2);
  gsl_permutation_free(perm);
#endif // GSL

  // find the interpolated (or extrapolated) value in the examined point;
  double z0=a*x0+b*y0+c;
  if(z0>1.0)
    {
	std::cout << "noe er galt!" << std::endl;
    }

  delete [] nearest;

  if(extrapolated && !extrapolate)
    return 0.0;

  return z0;
}


// interpolate using inverse distance
double geo_interpolation::inverse_distance_value(double x0, double y0)
{
  int i;

  // check if this points is exactly the same as a sammpled point
  for(i=0;i<numpoints;i++)
    if(x[i]==x0 && y[i]==y0)
      return z[i];

  double *weights=new double[numpoints], sum=0.0, ret=0.0;

  // Find the weights based on inverse square distance
  for(i=0;i<numpoints;i++)
    weights[i]=1.0/sqrt((x0-x[i])*(x0-x[i])+(y0-y[i])*(y0-y[i]));

  // normalize the weights;
  for(i=0;i<numpoints;i++)
    sum+=weights[i];
  for(i=0;i<numpoints;i++)
    weights[i]/=sum;

  // find the interpolation value as a sum over weights;
  for(i=0;i<numpoints;i++)
    ret += z[i]*weights[i];

  delete [] weights;

  return ret;
}

// interpolate using square inverse distance
double geo_interpolation::inverse_square_distance_value(double x0, double y0)
{
  int i;

  // check if this points is exactly the same as a sammpled point
  for(i=0;i<numpoints;i++)
    if(x[i]==x0 && y[i]==y0)
      return z[i];

  double *weights=new double[numpoints], sum=0.0, ret=0.0;

  // Find the weights based on inverse square distance
  for(i=0;i<numpoints;i++)
    weights[i]=1.0/((x0-x[i])*(x0-x[i])+(y0-y[i])*(y0-y[i]));

  // normalize the weights;
  for(i=0;i<numpoints;i++)
    sum+=weights[i];
  for(i=0;i<numpoints;i++)
    weights[i]/=sum;

  // find the interpolation value as a sum over weights;
  for(i=0;i<numpoints;i++)
    ret += z[i]*weights[i];

  delete [] weights;

  return ret;
}


// interpolate using cube inverse distance
double geo_interpolation::inverse_cube_distance_value(double x0, double y0)
{
  int i;

  // check if this points is exactly the same as a sammpled point
  for(i=0;i<numpoints;i++)
    if(x[i]==x0 && y[i]==y0)
      return z[i];

  double *weights=new double[numpoints], sum=0.0, ret=0.0;

  // Find the weights based on inverse square distance
  for(i=0;i<numpoints;i++)
    weights[i]=1.0/((x0-x[i])*(x0-x[i])+(y0-y[i])*(y0-y[i]))/
      sqrt((x0-x[i])*(x0-x[i])+(y0-y[i])*(y0-y[i]));

  // normalize the weights;
  for(i=0;i<numpoints;i++)
    sum+=weights[i];
  for(i=0;i<numpoints;i++)
    weights[i]/=sum;

  // find the interpolation value as a sum over weights;
  for(i=0;i<numpoints;i++)
    ret += z[i]*weights[i];

  delete [] weights;

  return ret;
}

// interpolate using quad inverse distance
double geo_interpolation::inverse_quad_distance_value(double x0, double y0)
{
  int i;

  // check if this points is exactly the same as a sammpled point
  for(i=0;i<numpoints;i++)
    if(x[i]==x0 && y[i]==y0)
      return z[i];

  double *weights=new double[numpoints], sum=0.0, ret=0.0;

  // Find the weights based on inverse square distance
  for(i=0;i<numpoints;i++)
    weights[i]=1.0/((x0-x[i])*(x0-x[i])+(y0-y[i])*(y0-y[i]))/
      ((x0-x[i])*(x0-x[i])+(y0-y[i])*(y0-y[i]));

  // normalize the weights;
  for(i=0;i<numpoints;i++)
    sum+=weights[i];
  for(i=0;i<numpoints;i++)
    weights[i]/=sum;

  // find the interpolation value as a sum over weights;
  for(i=0;i<numpoints;i++)
    ret += z[i]*weights[i];

  delete [] weights;

  return ret;
}

// interpolate using kriging
double geo_interpolation::kriging(double x0, double y0)
{
  double *lambda=new double[numpoints]; // weight coefficients
  double *var0=new double[numpoints]; // variogram values for this point
  double sum=0.0;
  int i,j;

  // fetch variogram values for the given point and put it in a vector;
  for(i=0;i<numpoints;i++)
    var0[i]=variogram_value(x0, y0, x[i], y[i]);

  // multiply the variogram matrix with this vector;
  for(i=0;i<numpoints;i++)
    {
      lambda[i]=0.0;
      
#ifdef GSL
      for(j=0;j<numpoints;j++)
	lambda[i] += gsl_matrix_get(inverse_variogram_matrix, i, j)*var0[j];
      lambda[i] += gsl_matrix_get(inverse_variogram_matrix, i, numpoints);
#endif // GSL
    }

  // normalize the found parameters;
  sum=0.0;
  for(i=0;i<numpoints;i++)
    sum+=lambda[i];

  for(i=0;i<numpoints;i++)
    lambda[i]/=sum;

  // find the weighted average of measured values;
  sum=0.0;
  for(i=0;i<numpoints;i++)
    sum+=lambda[i]*z[i];

  delete [] lambda;
  delete [] var0;

  return sum;
}

// start a new math module;
geo_interpolation::geo_interpolation(INTERPOLATION_SCHEME scheme_, 
				     int num_points,
				     double *X, double *Y, double *Z)
{
  init();
  Set(scheme_, num_points, X, Y, Z);
}

// delete a math module;
geo_interpolation::~geo_interpolation()
{
  cleanup();
}

// do interpolation for a given point;
double geo_interpolation::find_value(double x0, double y0,bool extrapolate)
{
  switch(scheme)
    {
    case NEAREST_NEIGHBOUR:
      return nearest_neighbour_value(x0,y0);
      break;
    case TWO_NEAREST_NEIGHBOURS:
      return nearest_two_neighbours_value(x0,y0);
      break;
    case THREE_NEAREST_NEIGHBOURS:
    case TRIANGULAR_NEIGHBOURS:
      return nearest_three_neighbours_value(x0,y0, extrapolate);
      break;
    case GAUSS_KRIGING:
    case SPHERICAL_KRIGING:
    case EXP_KRIGING:
    case LIN_KRIGING:
    case QUAD_KRIGING:
    case RATIONAL_KRIGING:
    case HOLE_KRIGING:
      return kriging(x0,y0);
      break;
    case INVERSE_DISTANCE:
      return inverse_distance_value(x0,y0);
      break;
    case INVERSE_SQUARE_DISTANCE:
      return inverse_square_distance_value(x0,y0);
      break;
    case INVERSE_CUBE_DISTANCE:
      return inverse_cube_distance_value(x0,y0);
      break;
    case INVERSE_QUAD_DISTANCE:
      return inverse_quad_distance_value(x0,y0);
      break;
    case UNKNOWN_INTERPOLATION_SCHEME:
    default:
      return MISSING_VALUE;
    }
}

// return the maximal z measurement;
double geo_interpolation::maxz(void)
{
  double max=z[0];
  for(int i=1;i<numpoints;i++)
    max=MAXIM(max, z[i]);

  return max;
}

// compare routine for vertexangles
int compare_vertexangle(const void *i, const void *j) 
{
  vertexangle *v1=(vertexangle *) i, *v2=(vertexangle *) j;
  double v =  v1->angle - v2->angle;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compare_vertecangle */


// returns an *array* (not a linked list) of delaunay triangles
// corresponing to the given set of points. The triangles is specified with
// three numbers referring to indexes in the x- and y-array.
triangle *delaunay_triangulation(double *x, double *y, int numpoints,
				 int *number_of_triangles)
{
  int i,j;
  triangle *ptr, *triangles;

  double *xbuffer=new double[numpoints+3];
  double *ybuffer=new double[numpoints+3];
  triangle *tbuffer=NULL, *ttail=NULL;;
  double xmin=x[0], xmax=x[0], ymin=y[0], ymax=y[0], spanx, spany;
  intlist *iptr;

  // find minimal and maximal coordinate values;
  for(i=1;i<numpoints;i++)
    {
      xmin=MINIM(xmin, x[i]);
      xmax=MAXIM(xmax, x[i]);
      ymin=MINIM(ymin, y[i]);
      ymax=MAXIM(ymax, y[i]);
    }
  spanx=xmax-xmin;
  spany=ymax-ymin;

  // make the spanning points
  xbuffer[0]=xmin-10.0*spanx; ybuffer[0]=ymin-spany;
  xbuffer[1]=xmax+10.0*spanx; ybuffer[1]=ymin-spany;
  xbuffer[2]=(xmax+xmin)/2.0; ybuffer[2]=ymax+20.0*spany;

  tbuffer=new triangle(NULL);
  tbuffer->Set(0,1,2);
  ttail=tbuffer;

  // make an array containing the spanning points and the internal points;
  for(i=0;i<numpoints;i++)
    {
      xbuffer[i+3]=x[i];
      ybuffer[i+3]=y[i];
    }

  // traverse the internal points;
  for(i=3;i<numpoints+3;i++)
    {
      intlist *polygon_indexes=NULL, *ptail=NULL;

      // traverse the triangle list;
      for(ptr=tbuffer; ptr; )
	{
	  triangle *ptr2=ptr;
	  ptr=ptr->suc();

	  if(ptr2->index1!=i && ptr2->index2!=i && ptr2->index3!=i)
	    {
	      // check if the currently examined point is within
	      // the currently examined triangle;
	      if(within_circumcircle(xbuffer[i], ybuffer[i],
				     xbuffer[ptr2->index1], 
				     ybuffer[ptr2->index1],
				     xbuffer[ptr2->index2], 
				     ybuffer[ptr2->index2],
				     xbuffer[ptr2->index3], 
				     ybuffer[ptr2->index3]))
		{
		  // insert index numbers of the triangle into the 
		  // insertion polygon (if neccesarry);
		  if(!polygon_indexes ||
		     !polygon_indexes->contains(ptr2->index1))
		    {
		      ptail=new intlist(ptail, NULL, ptr2->index1);
		      if(!polygon_indexes)
			polygon_indexes=ptail;
		    }

		  if(!polygon_indexes ||
		     !polygon_indexes->contains(ptr2->index2))
		    {
		      ptail=new intlist(ptail, NULL, ptr2->index2);
		      if(!polygon_indexes)
			polygon_indexes=ptail;
		    }

		  if(!polygon_indexes ||
		     !polygon_indexes->contains(ptr2->index3))
		    {
		      ptail=new intlist(ptail, NULL, ptr2->index3);
		      if(!polygon_indexes)
			polygon_indexes=ptail;
		    }

		  // remove the triangle;
		  if(tbuffer==ptr2)
		    tbuffer=ptr2->suc();
		  ptr2->removefromlist();
		  delete ptr2;
		}
	    }
	}

      ttail = (tbuffer ? ((triangle *) tbuffer->getlast()) : NULL);

      if(polygon_indexes) // traverse the insertion polygon index list?
	{
	  int numvertex=polygon_indexes->number_of_elements();
	  vertexangle *angles=new vertexangle[numvertex];
	  
	  // insert the contents of the index list togeither with the
	  // vertexes angle to the currently examined point into an array;
	  j=0;
	  for(iptr=polygon_indexes; iptr; iptr=iptr->suc())
	    {
	      double angle=find_angle(xbuffer[i], ybuffer[i], 
				      xbuffer[iptr->getvalue()], 
				      ybuffer[iptr->getvalue()]);
	      angles[j].index=iptr->getvalue();
	      angles[j].angle=angle;
	      j++;
	    }
	  
	  // sort the vertexes according the the angles;
	  qsort(angles, size_t(numvertex), sizeof(vertexangle), 
		compare_vertexangle);
	  
	  // fill the insertion polygon with new triangles;
	  for(j=1;j<numvertex;j++)
	    {
	      ttail=new triangle(ttail);
	      if(tbuffer==NULL)
		tbuffer=ttail;
	      ttail->Set(i, angles[j-1].index, angles[j].index);
	    }
	  ttail=new triangle(ttail);
	  if(tbuffer==NULL)
	    tbuffer=ttail;
	  ttail->Set(i, angles[numvertex-1].index, angles[0].index);
	  
	  // clean up the insertion point list;
	  for(iptr=polygon_indexes; iptr;)
	    {
	      intlist *iptr2=iptr;
	      iptr=polygon_indexes=iptr->suc();
	      
	      iptr2->removefromlist();
	      delete iptr2;
	    }

	  delete [] angles;
	}
    }
  
  // remove the triangles involving the three spanning points;
  for(ptr=tbuffer; ptr; )
    {
      triangle *ptr2=ptr;
      ptr=ptr->suc();

      if(ptr2->index1<3 || ptr2->index2<3 || ptr2->index3<3)
	{
	  if(tbuffer==ptr2)
	    tbuffer=ptr2->suc();
	  ptr2->removefromlist();
	  delete ptr2;
	}
    }

  // put the contents of the triangle set 'tbuffer' into an array;
  int numtriangles=(tbuffer ? tbuffer->number_of_elements() : 0);
  triangles=new triangle[numtriangles];

  i=0;
  for(ptr=tbuffer; ptr; ptr=ptr->suc())
    {
      triangles[i].index1=ptr->index1-3;
      triangles[i].index2=ptr->index2-3;
      triangles[i].index3=ptr->index3-3;
      i++;
    }

  // cleanup
  for(ptr=tbuffer; ptr; )
    {
      triangle *ptr2=ptr;
      ptr=ptr->suc();

      ptr2->removefromlist();
      delete ptr2;
    }

  // cleanup
  delete [] xbuffer;
  delete [] ybuffer;

  // return parameters;
  *number_of_triangles=numtriangles;
  return triangles;
}






