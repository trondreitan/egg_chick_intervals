#include <hydrasub/hydrabase/kalman.H>
#include <hydrasub/hydrabase/linalg.H>
#include <cmath>

void kalman_filter_result::init(void)
{
  num_meas=dim=0;
  loglik=1e-200;
  t=NULL;
  P_k_now=P_k_prev=NULL;
  x_k_now=x_k_prev=NULL;
}

void kalman_filter_result::cleanup(void)
{
  int k;
  
  if(t)
    delete [] t;
  if(P_k_now)
    {
      for(k=0;k<num_meas;k++)
	doubledelete(P_k_now, dim);
      delete [] P_k_now;
    }
    
  if(P_k_prev)
    {
      for(k=0;k<num_meas;k++)
	doubledelete(P_k_prev, dim);
      delete [] P_k_prev;
    }
    
  doubledelete(x_k_now, num_meas);
  doubledelete(x_k_prev, num_meas);

  init();
}

kalman_filter_result::kalman_filter_result()
{
  init();
}

kalman_filter_result::kalman_filter_result(int number_of_measurements, 
					   int dimension)
{
  init();
  
  num_meas=number_of_measurements;
  dim=dimension;
  
  t=new double[num_meas];
  x_k_now=make_matrix(num_meas, dim);
  x_k_prev=make_matrix(num_meas, dim);
  
  int k;
  P_k_now=new double**[num_meas];
  P_k_prev=new double**[num_meas];
  for(k=0;k<num_meas;k++)
    {
      P_k_now[k]=make_matrix(dim,dim);
      P_k_prev[k]=make_matrix(dim,dim);
    }
}

kalman_filter_result::~kalman_filter_result()
{
  cleanup();
}


void kalman_smoother_result::init(void)
{
  num_meas=dim=0;
  t=NULL;
  P_k_allmeas=NULL;
  x_k_allmeas=NULL;
}

void kalman_smoother_result::cleanup(void)
{
  int k;
  
  if(t)
    delete [] t;
  if(P_k_allmeas)
    {
      for(k=0;k<num_meas;k++)
	doubledelete(P_k_allmeas, dim);
      delete [] P_k_allmeas;
    }
    
  doubledelete(x_k_allmeas, num_meas);

  init();
}

kalman_smoother_result::kalman_smoother_result()
{
  init();
}

kalman_smoother_result::kalman_smoother_result(int number_of_measurements, 
					       int dimension)
{
  init();

  num_meas=number_of_measurements;
  dim=dimension;
  
  t=new double[num_meas];
  x_k_allmeas=make_matrix(num_meas, dim);
  
  int k;
  P_k_allmeas=new double**[num_meas];
  for(k=0;k<num_meas;k++)
    P_k_allmeas[k]=make_matrix(dim,dim);
}

kalman_smoother_result::~kalman_smoother_result()
{
  cleanup();
}





kalman_filter_result *kalman_filter(int num_meas,      // n
				    int state_dimension,  // p
				    int meas_dimension,   // q
				    double *t_k, // an n dimensional array of times
				    double **meas, // num_meas vectors

				    // Initial knowledge about first state:
				    double *x_1_0, // p dimensional vector
				    double **P_1_0, // p x p dimensional matrix
				    
				    // meas = H_k*state + N(0,R_k)
				    // H_k is a q x p dimensional matrix
				    double**(*H_k)(int /*index*/, 
						   double /*time*/,
						   double */*state*/,
						   double **/*variance*/),
				    // Set as missing those part of
				    // the measurement vector which isn't 
				    // measured at the moment
				    
				    // state_k=F_k*state_(k-1) + u_k + N(0,Q_k)
				    // F_k is thus a p x p dimensional matrix
				    double**(*F_k)(int /*index*/, 
						   double /*time*/,
						   double /*timediff*/,
						   double */*state*/,
						   double **/*variance*/),
				    
				    // var(state_k|state_(k-1))=Q_k
				    // Q_k is thus a p x p dimensional matrix
				    double **(*Q_k)(int /*index*/, 
						    double /*time*/,
						    double /*timediff*/,
						    double */*state*/,
						    double **/*variance*/),
				    
				    // var(meas|state)=R_k
				    // R_k is thus a q x q dimensional matrix
				    double **(*R_k)(int /*index*/, 
						    double /*time*/,
						    double */*state*/,
						    double **/*variance*/),

				    // state_k=F_k*state_(k-1) + u_k +
				    // N(0,Q_k)
				    // u_k is thus a  p dimensional vector
				    double*(*u_k)(int /*index*/, 
						  double /*time*/,
						  double /*timediff*/,
						  double */*state*/,
						  double **/*variance*/)
				    )
{
  int i,j,k,l,m;
  int n=num_meas, p=state_dimension, q=meas_dimension;
  kalman_filter_result *res=new kalman_filter_result(n, p);
  
  res->loglik=0.0;
  res->dim=p;

  for(k=0;k<num_meas;k++)
    {
      res->t[k]=t_k[k];
      
      if(k>0) // Update from state k-1 | k-1   to  state k | k-1
	{
	  double *u=u_k(k,t_k[k],t_k[k]-t_k[k-1],
			       res->x_k_now[k-1], res->P_k_now[k-1]);
	  double **F=F_k(k,t_k[k],t_k[k]-t_k[k-1],
			 res->x_k_now[k-1], res->P_k_now[k-1]);
	  double **Q=Q_k(k,t_k[k],t_k[k]-t_k[k-1],
			 res->x_k_now[k-1], res->P_k_now[k-1]);
	  
	  // x_k_(k-1) = F_k*x_(k-1)_(k-1) + u_k 
	  for(i=0;i<p;i++)
	    {
	      res->x_k_prev[k][i]=u[i];
	      for(j=0;j<p;j++)
		res->x_k_prev[k][i]+=F[i][j]*res->x_k_now[k-1][j];
	    }
	  
	  double **FP=make_matrix(p,p);
	  for(i=0;i<p;i++)
	    for(j=0;j<p;j++)
	      for(l=0;l<p;l++)
		FP[i][j]+=F[i][l]*res->P_k_now[k-1][l][j];
	  
	  // P_k_(k-1) = Q_k + F_k * P_(k-1),(k-1) * F_k' :
	  for(i=0;i<p;i++)
	    for(j=0;j<p;j++)
	      {
		res->P_k_prev[k][i][j]=Q[i][j];
		for(l=0;l<p;l++)
		  res->P_k_prev[k][i][j]+=FP[i][l]*F[j][l];
	      }

	  delete [] u;
	  doubledelete(F,p);
	  doubledelete(Q,p);
	  doubledelete(FP,p);
	}
      
      // Count number of measurements in the current time point:
      int curr_num_meas=0;
      for(i=0;i<q;i++)
	if(meas[k][i]!=MISSING_VALUE)
	  curr_num_meas++;

      double *x_k_prev =(k>0 ? res->x_k_prev[k] : x_1_0);
      double **P_k_prev=(k>0 ? res->P_k_prev[k] : P_1_0);
      
      if(curr_num_meas==0) // no measurements, state | k = state | k-1
	{
	  for(i=0;i<p;i++)
	    {
	      res->x_k_now[k][i]=x_k_prev[i];
	      for(j=0;j<p;j++)
		res->P_k_now[k][i][j]=P_k_prev[i][j];
	    }
	  // no updating of log-likelihood
	}
      else if(curr_num_meas==1) // one single measurement
	{
	  double y_k=0;
	  int index=0;
	  for(i=0;i<q;i++)
	    if(meas[k][i]!=MISSING_VALUE)
	      {
		index=i;
		y_k=meas[k][i];
	      }
	  
	  double **Rk=R_k(i,t_k[i],x_k_prev,P_k_prev);
	  double **H=H_k(k, t_k[k], x_k_prev,P_k_prev);
	  
	  double z_k=y_k;
	  for(j=0;j<p;j++)
	    z_k-=H[index][j]*x_k_prev[j];
	  
	  // S=Hk' P_k_prev Hk + Rk
	  double S=Rk[index][index];
	  for(l=0;l<p;l++)
	    for(m=0;m<p;m++)
	      S+=H[index][l]*P_k_prev[l][m]*H[index][m];
	  
	  // Innovation term:
	  // Calculate K = P_k,(k-1) * H_k' * inv(S_k)
	  double *K=new double[p];
	  for(i=0;i<p;i++)
	    {
	      K[i]=0.0;
	      for(j=0;j<p;j++)
		K[i] += P_k_prev[i][j]*H[index][j]/S;
	    }
	  
	  // Calculate x_k,k = x_k,(k-1) + K_k*z_k
	  for(i=0;i<p;i++)
	    res->x_k_now[k][i] = x_k_prev[i] + K[i]*z_k;
	  
	  // Calculate P_k,k=P_k,(k-1) - K_k*H_k*P_k,(k-1)
	  for(i=0;i<p;i++)
	    for(j=0;j<p;j++)
	      {
		res->P_k_now[k][i][j]=P_k_prev[i][j];
		for(l=0;l<p;l++)
		  res->P_k_now[k][i][j] -= K[i]*H[index][l]*P_k_prev[l][j];
	      }

	  res->loglik -= 0.5*(log(2.0*M_PI) + log(S) + z_k*z_k/S);
	  
	  /* DEBUG
	  printf("k=%d t=%f l1=%f x_k_prev=%f x_k_now=%f \n", 
		 k, t_k[k], res->loglik, x_k_prev[0], res->x_k_now[k][0]);
	  if(!(res->loglik> -1e+20 && res->loglik < 1e+20 &&
	       x_k_prev[0]> -1000 && x_k_prev[0]<1000 &&
	       res->x_k_now[k][0]> -1000 && res->x_k_now[k][0]<1000))
	    {
	      printf("error!\n");
	    }
	  */

	  doubledelete(Rk,q);
	  doubledelete(H, q);
	}
      else // multiple measurements
	{
	  int q2=curr_num_meas;
	  double **S=make_matrix(q2,q2);
	  double **Rk=R_k(k, t_k[k], x_k_prev, P_k_prev);
	  double **H=H_k(k, t_k[k], x_k_prev, P_k_prev);
	  double *y_k=new double[q2],*z_k=new double[q2],*zeros_k=new double[q2];
	  int *index=new int[q2];
	  
	  j=0;
	  for(i=0;i<q;i++)
	    if(meas[k][i]!=MISSING_VALUE)
	      {
		y_k[j]=meas[k][i];
		index[j]=i;
		j++;
	      }
	  
	  for(i=0;i<q2;i++)
	    {
	      z_k[i]=y_k[i];
	      for(j=0;j<p;j++)
		z_k[i]-=H[index[i]][j]*x_k_prev[j];
	      zeros_k[i]=0.0;
	    }
	  
	  // S=Hk' P_k_prev Hk + Rk
	  for(i=0;i<q2;i++)
	    for(j=0;j<q2;j++)
	      {
		S[i][j]=Rk[index[i]][index[j]];
		for(l=0;l<p;l++)
		  for(m=0;m<p;m++)
		    S[i][j]+=H[index[i]][l]*P_k_prev[l][m]*H[index[j]][m];
	      }
	  
	  double **S_inv=inverse_matrix(S, q2);
	  
	  // Innovation term:
	  // Calculate K = P_k,(k-1) * H_k' * inv(S_k)
	  double **K=make_matrix(p,q2);
	  for(i=0;i<p;i++)
	    for(l=0;l<q2;l++)
	      {
		for(j=0;j<p;j++)
		  for(m=0;m<q2;m++)
		    K[i][l] += P_k_prev[i][j]*H[index[m]][j]*
		      S_inv[m][l];
	      }
	  
	  // Calculate x_k,k = x_k,(k-1) + K_k*z_k
	  for(i=0;i<p;i++)
	    {
	      res->x_k_now[k][i] = x_k_prev[i];
	      for(j=0;j<q2;j++)
		res->x_k_now[k][i] += K[i][j]*z_k[j];
	    }
	  
	  // Calculate P_k,k=P_k,(k-1) - K_k*H_k*P_k,(k-1)
	  for(i=0;i<p;i++)
	    for(j=0;j<p;j++)
	      {
		res->P_k_now[k][i][j]=P_k_prev[i][j];
		
		for(l=0;l<p;l++)
		  for(m=0;m<q2;m++)
		    res->P_k_now[k][i][j] -= K[i][m]*H[index[m]][l]*
		      P_k_prev[l][j];
	      }
	  
	  res->loglik += multinormal_pdf(z_k, zeros_k, S, q2, true);
	  
	  /* DEBUG
	  printf("k=%d t=%f l2=%f x_k_prev=%f x_k_now=%f\n", 
		 k, t_k[k], res->loglik, 
		 x_k_prev[0], res->x_k_now[k][0]);
	  if(!(res->loglik> -1e+20 && res->loglik < 1e+20 &&
	       x_k_prev[0]> -1000 && x_k_prev[0]<1000 &&
	       res->x_k_now[k][0]> -1000 && res->x_k_now[k][0]<1000))
	    {
	      printf("error!\n");
	    }
	  */
	  
	  doubledelete(Rk,q);
	  doubledelete(H, q);
	  doubledelete(S,q2);
	  doubledelete(S_inv,q2);
	  doubledelete(K,q2);
	  delete [] y_k;
	  delete [] z_k;
	  delete [] zeros_k;
	  delete [] index;
	}
    }
  
  return res;
}



kalman_smoother_result *kalman_smoother(kalman_filter_result *filter,
					
				    // state_k=F_k*state_(k-1) + u_k +
				    // N(0,Q_k)
				    // F_k is thus a p x p dimensional matrix
				    double**(*F_k)(int /*index*/, 
						   double /*time*/,
						   double /*timediff*/,
						   double */*state*/,
						   double **/*variance*/),
				    
				    // state_k=F_k*state_(k-1) + u_k +
				    // N(0,Q_k)
				    // u_k is thus a  p dimensional vector
				    double*(*u_k)(int /*index*/, 
						  double /*time*/,
						  double /*timediff*/,
						  double */*state*/,
						  double **/*variance*/)
				    )
{
  int i,j,k,l;
  int n=filter->num_meas, p=filter->dim;
  kalman_smoother_result *res=new kalman_smoother_result(n, p);
  double **C_k=make_matrix(p,p);
  double **PAbuffer=make_matrix(p,p);

  for(k=0;k<n;k++)
    {
      res->t[k]=filter->t[k];
      for(i=0;i<p;i++)
	{
	  res->x_k_allmeas[k][i]=filter->x_k_now[k][i];
	  for(j=0;j<p;j++)
	    res->P_k_allmeas[k][i][j]=filter->P_k_now[k][i][j];
	}
    }

  for(k=(n-2);k>=0;k--)
    {
      double **P_k_prevbuffer=make_matrix(p,p);
      for(i=0;i<p;i++)
	for(j=0;j<p;j++)
	  P_k_prevbuffer[i][j]=filter->P_k_prev[k+1][i][j];
      double **P_k_plus_1_inv=inverse_matrix(P_k_prevbuffer,p);
      double **F_k_next=F_k(k+1, res->t[k+1],
			    res->t[k+1] - res->t[k],
			    filter->x_k_now[k],
			    filter->P_k_now[k]);
      double *u_k_next=u_k(k+1, res->t[k+1],
			   res->t[k+1] - res->t[k],
			   filter->x_k_now[k],
			   filter->P_k_now[k]);
      
      for(i=0;i<p;i++)
	for(j=0;j<p;j++)
	  {
	    PAbuffer[i][j]=0.0;
	    for(l=0;l<p;l++)
	      PAbuffer[i][j]+=filter->P_k_now[k][i][l]*F_k_next[j][l];
	  }
	  
      for(i=0;i<p;i++)
	for(j=0;j<p;j++)
	  {
	    C_k[i][j]=0.0;
	    for(l=0;l<p;l++)
	      C_k[i][j]+=PAbuffer[i][l]*P_k_plus_1_inv[l][j];
	  }
	  
      double *x_k_buffer=new double[p];
      for(i=0;i<p;i++)                    
	{
	  x_k_buffer[i]=res->x_k_allmeas[k+1][i]-u_k_next[i];
	  for(l=0;l<p;l++)
	    x_k_buffer[i]-=F_k_next[i][l]*filter->x_k_now[k][l];
	}
      
      for(i=0;i<p;i++)
	{
	  res->x_k_allmeas[k][i]=filter->x_k_now[k][i];
	  for(l=0;l<p;l++)
	    res->x_k_allmeas[k][i]+=C_k[i][l]*x_k_buffer[l];
	}
      
      double **P1=make_matrix(p,p), **P2=make_matrix(p,p);
      
      for(i=0;i<p;i++)
	for(j=0;j<p;j++)
	  {
	    P1[i][j]=0.0;
	    for(l=0;l<p;l++)
	      P1[i][j]+=res->P_k_allmeas[k+1][i][l]*C_k[j][l];
	  }
      for(i=0;i<p;i++)
	for(j=0;j<p;j++)
	  {
	    P2[i][j]=0.0;
	    for(l=0;l<p;l++)
	      P2[i][j]+=filter->P_k_prev[k+1][i][l]*C_k[j][l];
	  }
      
      for(i=0;i<p;i++)
	for(j=0;j<p;j++)
	  {
	    res->P_k_allmeas[k][i][j]=filter->P_k_now[k][i][j];
	    
	    for(l=0;l<p;l++)
	      res->P_k_allmeas[k][i][j]+=C_k[i][l]*(P1[l][j]-P2[l][j]);
	  }
      
      doubledelete(P_k_prevbuffer, p);
      doubledelete(P_k_plus_1_inv,p);
      delete [] x_k_buffer;
      doubledelete(P1,p);
      doubledelete(P2,p);
      delete [] u_k_next;
      doubledelete(F_k_next,p);
    }

  doubledelete(C_k,p);
  doubledelete(PAbuffer,p);

  return res;
}
			    
