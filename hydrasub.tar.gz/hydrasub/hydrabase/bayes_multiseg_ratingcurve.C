#include "bayes_multiseg_ratingcurve.H"
#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/linalg.H>
#include <gsl/gsl_cdf.h>
#include <cmath>

// ****************************************
//
//   SEGMENTED_CURVE
//
// ****************************************


void segmented_curve::init(void)
{
  numseg=0;
  a=MISSING_VALUE;
  b=NULL;
  h0=NULL;
  hs=NULL;
  s2=MISSING_VALUE;
  psi=MISSING_VALUE;
  extrapol=NULL;
}

void segmented_curve::cleanup(void)
{
  if(b)
    delete [] b;
  if(h0)
    delete [] h0;
  if(hs)
    delete [] hs;
  if(extrapol)
    delete [] extrapol;
  init();
}

segmented_curve::segmented_curve()
{
  init();
}

segmented_curve::segmented_curve(int num_seg, double a1, double *exponents,
				 double *zerostages, double *segmentlimits, 
				 double sigma_squared, double log_prob)
{
  init();
  
  set_content(num_seg, a1, exponents, zerostages, 
	      segmentlimits, sigma_squared, log_prob);
}

segmented_curve::segmented_curve(int num_seg, double a1, double *exponents,
				 double *zerostages, double *segmentlimits, 
				 double sigma_squared)
{
  init();

  set_content(num_seg, a1, exponents, zerostages, 
	      segmentlimits, sigma_squared, MISSING_VALUE);
}

segmented_curve::segmented_curve(int num_seg, double *coefs)
{
  init();
  
  numseg=num_seg;
  set_content(num_seg, coefs[0], &(coefs[1]), &(coefs[1+num_seg]),
	      &(coefs[1+2*num_seg]), coefs[3*num_seg], MISSING_VALUE);
}

segmented_curve::segmented_curve(int num_seg, double a1, double *exponents,
				 double *zerostages, double *segmentlimits, 
				 double sigma_squared, double log_prob, 
				 bool *extrapolated)
{
  init();

  set_content(num_seg, a1, exponents, zerostages, 
	      segmentlimits, sigma_squared, log_prob,extrapolated);
}

segmented_curve::segmented_curve(int num_seg, double a1, double *exponents,
				 double *zerostages, double *segmentlimits, 
				 double sigma_squared, bool *extrapolated)
{
  init();

  set_content(num_seg, a1, exponents, zerostages, 
	      segmentlimits, sigma_squared, MISSING_VALUE,extrapolated);
}

segmented_curve::segmented_curve(int num_seg, double *coefs, bool *extrapolated)
{
  init();
  
  numseg=num_seg;
  set_content(num_seg, coefs[0], &(coefs[1]), &(coefs[1+num_seg]),
	      &(coefs[1+2*num_seg]), coefs[3*num_seg], MISSING_VALUE,extrapolated);
}

segmented_curve::segmented_curve(segmented_curve *orig)
{
  init();

  copy(orig);
}

segmented_curve::~segmented_curve()
{
  cleanup();
}


void segmented_curve::copy(segmented_curve *orig)
{
  cleanup();
  
  numseg=orig->numseg;
  a=orig->a;

  b=new double[numseg];
  h0=new double[numseg];
  if(numseg>1)
    hs=new double[numseg-1];

  int i;
  for(i=0;i<numseg;i++)
    {
      b[i]=orig->b[i];
      h0[i]=orig->h0[i];
      if(i<(numseg-1))
	hs[i]=orig->hs[i];
    }
  
  if(orig->extrapol)
    {
      extrapol=new bool[numseg];
      for(i=0;i<numseg;i++)
	extrapol[i]=orig->extrapol[i];
    }
  else
    extrapol=NULL;
  
  s2=orig->s2;
  psi=orig->psi;
}

double *segmented_curve::get_coef_array(int *dim_)
{
  int l2, dim=1+3*numseg;
  double *coefs=new double[dim];
  
  coefs[0]=a;
  for(l2=0;l2<numseg;l2++)
    coefs[1+l2]=b[l2];
  for(l2=0;l2<numseg;l2++)
    coefs[1+numseg+l2]=h0[l2];
  for(l2=0;l2<(numseg-1);l2++)
    coefs[1+2*numseg+l2]=hs[l2];
  coefs[3*numseg]=s2;
  
  if(dim_)
    *dim_=dim;
  
  return coefs;
}

int segmented_curve::get_coef_array_length(int num_seg)
{
  int dim=1+3*num_seg;
  return dim;
}

int segmented_curve::get_number_of_segments(void)
{
  return numseg;
}

int segmented_curve::get_numseg(void)
{
  return numseg;
}

int segmented_curve::get_numseg_interpolated(void)
{
  int len=0,i;
  for(i=0;i<numseg;i++)
    if(!extrapol || !extrapol[i])
      len++;
  
  return len;
}

double segmented_curve::get_constant(void)
{
  return exp(a);
}

double segmented_curve::get_a(void)
{
  return a;
}
  
double segmented_curve::get_a_interpolated(void)
{
  if(!extrapol || !extrapol[0])
    return a;
  else
    {
      int i=0;
      for(i=0;i<numseg;i++)
	if(!extrapol[i])
	  return get_a(i+1);
      return MISSING_VALUE;
    }
}

double segmented_curve::get_constant(int segment_number)
{
  double a_index=get_a(segment_number);

  if(a_index==MISSING_VALUE)
    return MISSING_VALUE;
  else
    return exp(a_index);
}

void segmented_curve::set_a(double new_a)
{
  a=new_a;
}
  
void segmented_curve::set_constant(double new_constant)
{
  if(new_constant>0.0)
    a=log(new_constant);
  else
    a=MISSING_VALUE;
}



double segmented_curve::get_a(int segment_number)
{
  double a_index=a;

  if(segment_number<=0 || segment_number>numseg)
    return MISSING_VALUE;

  for(int i=1;i<segment_number;i++)
    a_index += b[i-1]*log(hs[i-1]-h0[i-1])-b[i]*log(hs[i-1]-h0[i]);

  return a_index;
}
  
double segmented_curve::get_exponent(int segment_number)
{
  if(segment_number>0 && segment_number<=numseg)
    return b[segment_number-1];
  else
    return MISSING_VALUE;
}

double segmented_curve::get_b(int segment_number)
{
  if(segment_number>0 && segment_number<=numseg)
    return b[segment_number-1];
  else
    return MISSING_VALUE;
}

double *segmented_curve::get_exponent_array(void)
{
  return b;
}

double *segmented_curve::get_b_array(void)
{
  return b;
}
  
double *segmented_curve::get_b_array_interpolated(void)
{
  int len=0,i;
  for(i=0;i<numseg;i++)
    if(!extrapol || !extrapol[i])
      len++;

  if(len==0)
    return NULL;
  
  double *bi=new double[len];
  int j=0;
  for(i=0;i<numseg;i++)
    if(!extrapol || !extrapol[i])
      bi[j++]=b[i];
  
  return bi;
}
  
double segmented_curve::get_zerostage(int segment_number)
{
  if(segment_number>0 && segment_number<=numseg)
    return h0[segment_number-1];
  else
    return MISSING_VALUE;
}

double segmented_curve::get_h0(int segment_number)
{
  if(segment_number>0 && segment_number<=numseg)
    return h0[segment_number-1];
  else
    return MISSING_VALUE;
}

double *segmented_curve::get_zerostage_array(void)
{
  return h0;
}

double *segmented_curve::get_h0_array(void)
{
  return h0;
}
  
double *segmented_curve::get_zerostage_array_interpolated(void)
{
  return get_h0_array_interpolated();
}

double *segmented_curve::get_h0_array_interpolated(void)
{
  int len=0,i;
  for(i=0;i<numseg;i++)
    if(!extrapol || !extrapol[i])
      len++;

  if(len==0)
    return NULL;
  
  double *h0i=new double[len];
  int j=0;
  for(i=0;i<numseg;i++)
    if(!extrapol || !extrapol[i])
      h0i[j++]=h0[i];

  return h0i;
}
  
double segmented_curve::get_segmentlimit(int segment_number)
{
  if(segment_number>0 && segment_number<numseg)
    return hs[segment_number-1];
  else
    return MISSING_VALUE;
}

double segmented_curve::get_hs(int segment_number)
{
  if(segment_number>0 && segment_number<numseg)
    return hs[segment_number-1];
  else
    return MISSING_VALUE;
}

double *segmented_curve::get_segmentlimit_array(void)
{
  return hs;
}

double *segmented_curve::get_hs_array(void)
{
  return hs;
}

double *segmented_curve::get_hs_array_interpolated(void)
{
  int len=0,i;
  for(i=0;i<(numseg-1);i++)
    if(!extrapol || !extrapol[i])
      len++;

  if(len==0)
    return NULL;
  
  double *hsi=new double[len];
  int j=0;
  for(i=0;i<(numseg-1);i++)
    if(!extrapol || !extrapol[i])
      hsi[j++]=hs[i];

  return hsi;
}
  

double segmented_curve::get_sigma_squared(void)
{
  return s2;
}

double segmented_curve::get_s2(void)
{
  return s2;
}

double segmented_curve::get_sigma(void)
{
  return sqrt(s2);
}

void segmented_curve::set_sigma(double new_sigma)
{
  s2=new_sigma*new_sigma;
}

double segmented_curve::get_s(void)
{
  return sqrt(s2);
}

bool segmented_curve::is_extrapoled(int segment_number)
{
  if(extrapol && segment_number>0 && segment_number<=numseg)
    return extrapol[segment_number-1];
  else
    return false;
}

bool *segmented_curve::is_extrapoled_array(void)
{
  return extrapol;
}

void segmented_curve::set_extrapoled(int segment_number, bool new_status)
{
  if(extrapol && segment_number>0 && segment_number<numseg)
    extrapol[segment_number-1]=new_status;
}

void segmented_curve::set_extrapoled_array(bool *new_status)
{
  if(!extrapol)
    extrapol=new bool[numseg];
  for(int i=0;i<numseg;i++)
    extrapol[i]=new_status[i];
}

  
double segmented_curve::get_log_probability_density(void)
{
  return psi;
}

double segmented_curve::get_psi(void)
{
  return psi;
}

double segmented_curve::get_log_prob(void)
{
  return psi;
}

void segmented_curve::set_log_prob(double new_log_prob)
{
  psi=new_log_prob;
}

double segmented_curve::get_probability_density(void)
{
  return exp(psi);
}
  
void segmented_curve::set_content(int num_seg, double a1, double *exponents,
				  double *zerostages, double *segmentlimits, 
				  double sigma_squared, double log_prob,
				  bool *extrapolated)
{
  cleanup();
  
  numseg=num_seg;
  a=a1;

  b=new double[numseg];
  h0=new double[numseg];
  if(numseg>1)
    hs=new double[numseg-1];

  int i;
  for(i=0;i<numseg;i++)
    {
      b[i]=exponents[i];
      h0[i]=zerostages[i];
    }

  for(i=0;i<(numseg-1);i++)
    {
      hs[i]=segmentlimits[i];
      if(hs[i]<h0[i] || hs[i]<h0[i+1] || (i>0 && hs[i]<hs[i-1]))
	{
	  //cout << "Noe er galt (5)!" << endl;
	}
    }

  if(extrapol)
    delete [] extrapol;
  if(extrapolated)
    {
      extrapol=new bool[numseg];
      for(i=0;i<numseg;i++)
	extrapol[i]=extrapolated[i];
    }
  else
    extrapol=NULL;
  
  s2=sigma_squared;
  psi=log_prob;
}
  
double segmented_curve::get_discharge(double stage)
{
  double Q=0.0, h=stage;

  if(h>h0[0])
    {
      double as=a;
      int seg=0;

      for(seg=0;seg<(numseg-1);seg++)
	{
	  if(h<=hs[seg])
	    break;
	  else
	    as+=b[seg]*log(hs[seg]-h0[seg])-b[seg+1]*log(hs[seg]-h0[seg+1]);
	}
      
      Q=exp(as+b[seg]*log(h-h0[seg]));
    }

  return Q;
}

double segmented_curve::get_stage(double discharge)
{
  double q=log(discharge), h=h0[0];

  if(discharge>0.0)
    {
      double as=a;
      int seg;
      
      for(seg=0;seg<(numseg-1);seg++)
	{
	  double qs=as+b[seg]*log(hs[seg]-h0[seg]);

	  if(q<=qs)
	    break;
	  else
	    as+=b[seg]*log(hs[seg]-h0[seg])-b[seg+1]*log(hs[seg]-h0[seg+1]);
	}
      
      h=h0[seg]+exp((q-as)/b[seg]);
    }

  return h;
}


void segmented_curve::print(void)
{
  int i;
  std::cout << "Numseg=" << numseg << std::endl;
  std::cout << "a=" << a << std::endl;
  std::cout << "b=";
  for(i=0;i<numseg;i++)
    std::cout << b[i] << " ";
  std::cout << std::endl;
  std::cout << "h0=";
  for(i=0;i<numseg;i++)
    std::cout << h0[i] << " ";
  std::cout << std::endl;
  if(numseg>1)
    {
      std::cout << "hs=";
      for(i=0;i<(numseg-1);i++)
	std::cout << hs[i] << " ";
      std::cout << std::endl;
    }
  std::cout << "s=" << sqrt(s2) << std::endl;
  std::cout << "logprob=" << psi << std::endl << std::endl;
}

void segmented_curve::print(FILE *f)
{
  int i;
  
  for(i=0;i<numseg;i++)
    if(i<(numseg-1))
      fprintf(f, "a%d=%7.3f b%d=%7.3f h0%d=%7.3f hs%d=%7.3f ", 
	      i+1, get_a(i+1), i+1, b[i], i+1, h0[i], i+1, hs[i]);
    else
      fprintf(f, "a%d=%7.3f b%d=%7.3f h0%d=%7.3f ",
	      i+1, get_a(i+1), i+1, b[i], i+1, h0[i]);

  fprintf(f, " s=%7.3f\n", sqrt(s2));
}



// ****************************************
//
//   SEGMENTED_CURVE_ANALYSIS
//
// ****************************************





void segmented_curve_analysis::init(void)
{
  len=0;
  q=h=NULL;
  hmin=hmax=MISSING_VALUE;
  samples=NULL;
  modus_curves=NULL;
  num_mcmc=num_imp=0;
  priors=NULL;
  prob_mod=NULL;
  cumulative_prob_mod=NULL;
  loglikelihood_mod=NULL;
  median_curve=NULL;
  mean_curve=NULL;

  extrapolated_samples=NULL;
  extrapolated_prob_mod=extrapolated_cumulative_prob_mod=NULL;
  lambda=NULL;
  extrapolated_minseg=extrapolated_maxseg=num_extrapolated=0;
  extrapolated_max_stage=MISSING_VALUE;
  
  weights=NULL;
  
  h_table_len=q_table_len=0;
  h_table=NULL;
  q_table=NULL;
  hmin_table=hmax_table=
    qmin_table=qmax_table=MISSING_VALUE;
  lower_q_table=NULL;
  median_q_table=NULL;
  upper_q_table=NULL;
  lower_h_table=NULL;
  median_h_table=NULL; 
  upper_h_table=NULL;
  
}

void segmented_curve_analysis::cleanup(void)
{
  if(samples)
    {
      for(int j=(min_seg-1);j<max_seg;j++)
	{
	  for(int i=0;i<num_mcmc;i++)
	    delete samples[j][i];
	  delete [] samples[j];
	}
      delete [] samples;
    }
  // do not delete priors as this is an external pointer

  // Extrapolation tables:
  if(extrapolated_samples)
    {
      for(int i=0;i<num_extrapolated;i++)
	delete extrapolated_samples[i];
      delete [] extrapolated_samples;
    }
  if(extrapolated_prob_mod)
    delete [] extrapolated_prob_mod;
  if(extrapolated_cumulative_prob_mod)
    delete [] extrapolated_cumulative_prob_mod;
  if(lambda)
    delete [] lambda;

  if(modus_curves)
    doubledelete(modus_curves, max_seg-min_seg+1);
  
  if(prob_mod)
    delete [] prob_mod;
  if(cumulative_prob_mod)
    delete [] cumulative_prob_mod;
  if(loglikelihood_mod)
    delete [] loglikelihood_mod;
  if(median_curve)
    delete median_curve;
  if(mean_curve)
    delete mean_curve;

  if(q)
    delete [] q;
  if(h) 
    delete [] h;
  if(weights)
    delete [] weights;

  if(h_table)
    delete [] h_table;
  if(q_table)
    delete [] q_table;
  if(lower_q_table)
    delete [] lower_q_table;
  if(median_q_table)
    delete [] median_q_table;
  if(upper_q_table)
    delete [] upper_q_table;
  if(lower_h_table)
    delete [] lower_h_table;
  if(median_h_table)
    delete [] median_h_table;
  if(upper_h_table)
    delete [] upper_h_table;

  init();
}


double segmented_curve_analysis::Bj(double h_curr, int seg, 
				    segmented_curve *curve)
{
  int numseg=curve->get_numseg();
  double *hs=curve->get_hs_array();
  double *h0=curve->get_h0_array();
  
  if(seg<0 || seg>=numseg)
    return MISSING_VALUE;

  double ret;

  if(seg>=1 && h_curr<hs[seg-1])
    ret=0.0;
  else if(h_curr<=h0[seg])
    return MISSING_VALUE;
  else
    {
      if(seg==0 && (numseg==1 || h_curr<hs[seg]))
	ret=log(h_curr-h0[seg]);
      else if(seg==(numseg-1) || h_curr<hs[seg])
	ret=log(h_curr-h0[seg])-log(hs[seg-1]-h0[seg]);
      else // h_curr>=hs[seg]
	{
	  if(seg==0)
	    ret=log(hs[seg]-h0[seg]);
	  else
	    ret=log(hs[seg]-h0[seg])-log(hs[seg-1]-h0[seg]);
	}
    }

  return ret;
}


double segmented_curve_analysis::find_SS(segmented_curve *curve)
{
  double SS=0.0, res;
  int i,j, numseg=curve->get_numseg();
  double *b=curve->get_b_array();
  double a1=curve->get_a();
  
  for(j=0;j<numseg;j++)	
    if(b[j]==MISSING_VALUE)
      return 1e+216;
      
  for(i=0;i<len;i++)
    {
      res=q[i]-a1;
      for(j=0;j<numseg;j++)
	{
	  double bj=Bj(h[i],j,curve);
	  if(bj==MISSING_VALUE)
	    return MISSING_VALUE;

	  if(!(bj>-1e+100 && bj<1e+100))
	    {
	      std::cout << " noe er galt!" << std::endl;
	      bj=Bj(h[i],j,curve);
	      return MISSING_VALUE;
	    }
	  
	  res-=b[j]*bj;
	}
      
      if(weights)
	SS+=res*res/weights[i]/weights[i];
      else
	SS+=res*res;
    }
  
  return SS;
}


double segmented_curve_analysis::logprob(segmented_curve *curve, double T, 
					 bool include_extra)
{
  int i, numseg=curve->get_numseg_interpolated();
  double a1=curve->get_a_interpolated();
  double *b=curve->get_b_array_interpolated();
  double *h0=curve->get_h0_array_interpolated();
  double *hs=curve->get_hs_array_interpolated();
  double s2=curve->get_s2();
  bool can_have_extrapol=(include_extra || numseg!=curve->get_numseg()) ? true : false;
  
  if(!b || !h0)
    return -1e+216;

  if(numseg>1 && !hs)
    {
      delete [] b;
      delete [] h0;
      return -1e+216;
    }
  
  if(hmin<=h0[0])
    {
      delete [] b;
      delete [] h0;
      if(hs)
	delete [] hs;
      return -1e+216;
    }
  
  for(i=0;i<(numseg-1);i++)
    if(hs && (h0[i+1]>hs[i] || h0[i]>hs[i] || (!can_have_extrapol && hs[i]<hmin) || 
	      (!can_have_extrapol && hs[i]>hmax)))
      {
	delete [] b;
	delete [] h0;
	if(hs)
	  delete [] hs;
	return -1e+216;
      }
  
  for(i=0;i<(numseg-2);i++)
    if(hs[i]>=hs[i+1])
      {
	delete [] b;
	delete [] h0;
	if(hs)
	  delete [] hs;
	return -1e+216;
      }
  
  if(s2<0.0)
    {
      delete [] b;
      delete [] h0;
      if(hs)
	delete [] hs;
      return -1e+216;
    }

  double contrib_prior=priors->loglikelihood_prior_contrib(numseg, a1, b, 
							   h0, hs, s2);
  double n=(double) len;
  double SS=find_SS(curve);
  
  if(SS==MISSING_VALUE)
    {
      delete [] b;
      delete [] h0;
      if(hs)
	delete [] hs;
      return -1e+216;
    }

  // contribution from the exponensial data part of the likelihood function;
  double contrib_lik=-0.5*n*log(2.0*M_PI)-0.5*n*log(s2)-0.5*SS/s2;

  int num_restr=0;
  double *restr_stage=NULL, *restr_q_lower = NULL, *restr_q_upper = NULL;
  if(priors && priors->num_internal_restrictions()>0)
    {
      num_restr=priors->num_internal_restrictions();
      restr_stage=priors->stage_internal_restrictions();
      restr_q_lower=priors->logdischarge_lower_internal_restrictions();
      restr_q_upper=priors->logdischarge_upper_internal_restrictions();
    }
  if(num_restr>0 && restr_stage && restr_q_lower && restr_q_upper)
    {
      for(i=0;i<num_restr;i++)
	{
	  double q_curve=curve->get_discharge(restr_stage[i]);
	  
	  if(q_curve<=0.0)
	    return -1e+200;
	  q_curve=log(q_curve);
	  
	  if(restr_q_lower[i]!=MISSING_VALUE &&
	     restr_q_upper[i]!=MISSING_VALUE)
	    {
	      double q_mean=(restr_q_lower[i]+restr_q_upper[i])/2.0;
	      double q_sd=(restr_q_upper[i]-restr_q_lower[i])/2.0/1.96;
	      double res=q_mean-q_curve;
	      
	      contrib_lik += -0.5*log(2.0*M_PI)-log(q_sd)-
		0.5*res*res/q_sd/q_sd;
	    }
	  else if(restr_q_lower[i]!=MISSING_VALUE)
	    {
	      if(q_curve<restr_q_lower[i])
		{
		  delete [] b;
		  delete [] h0;
		  if(hs)
		    delete [] hs;
		  return -1e+200;
		}
	    }
	  else if(restr_q_upper[i]!=MISSING_VALUE)
	    {
	      if(q_curve>restr_q_upper[i])
		{
		  delete [] b;
		  delete [] h0;
		  if(hs)
		    delete [] hs;
		  return -1e+200;
		}
	    }
	}

    }

  if(include_extra)
    {
      int num_extra=0;
      double *extra_stage=NULL, *extra_q_lower = NULL, *extra_q_upper = NULL;
      if(priors && priors->num_extrapolation_restrictions()>0)
	{
	  num_extra=priors->num_extrapolation_restrictions();
	  extra_stage=priors->stage_extrapolation_restrictions();
	  extra_q_lower=priors->logdischarge_lower_extrapolation_restrictions();
	  extra_q_upper=priors->logdischarge_upper_extrapolation_restrictions();
	}
      if(num_extra>0 && extra_stage && extra_q_lower && extra_q_upper)
	{
	  for(i=0;i<num_extra;i++)
	    {
	      double q_curve=curve->get_discharge(extra_stage[i]);
	      
	      if(q_curve<=0.0)
		return -1e+200;
	      q_curve=log(q_curve);
	      
	      if(extra_q_lower[i]!=MISSING_VALUE &&
		 extra_q_upper[i]!=MISSING_VALUE)
		{
		  double q_mean=(extra_q_lower[i]+extra_q_upper[i])/2.0;
		  double q_sd=(extra_q_upper[i]-extra_q_lower[i])/2.0/1.96;
		  double res=q_mean-q_curve;
		  
		  contrib_lik += -0.5*log(2.0*M_PI)-log(q_sd)-
		    0.5*res*res/q_sd/q_sd;
		}
	      else if(extra_q_lower[i]!=MISSING_VALUE)
		{
		  if(q_curve<extra_q_lower[i])
		    {
		      delete [] b;
		      delete [] h0;
		      if(hs)
			delete [] hs;
		      return -1e+200;
		    }
		}
	      else if(extra_q_upper[i]!=MISSING_VALUE)
		{
		  if(q_curve>extra_q_upper[i])
		    {
		      delete [] b;
		      delete [] h0;
		      if(hs)
			delete [] hs;
		      return -1e+200;
		    }
		}
	    }
	  
	}
    }
  
  double ret = contrib_prior + contrib_lik;
  
  delete [] b;
  delete [] h0;
  if(hs)
    delete [] hs;
  
  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;
  
  curve->psi=ret/T;
  
  return ret/T;
}


double segmented_curve_analysis::gibbs_sigma2(segmented_curve *curve, 
					      double T, gsl_rng *rptr)
{
  double n=(double) len;
  double sigma_a=priors->get_sigma_a();
  double sigma_b=priors->get_sigma_b();
  double sigma_a_star=sigma_a+n/2.0;
  double sigma_b_star=sigma_b;
  
  sigma_b_star+=find_SS(curve)/2.0;
  
  if(T!=1.0)
    {
      sigma_a_star=(sigma_a_star+1.0-T)/T;
      sigma_b_star/=T;
    }
  
  double s2=1.0/gsl_ran_gamma(rptr, sigma_a_star, 1.0/sigma_b_star);

  return s2;
}


void segmented_curve_analysis::
get_linear_proposal_hyperparameters(segmented_curve *curve,
				    double T, double **m_star_, 
				    double ***V_star_)
{
  int numseg=curve->get_numseg(), dim=numseg+1;
  double s2=curve->get_s2();
  double **XtX=new double*[dim], **V_star, 
    **inv_V_star=new double*[dim], **inv_V;
  int i,j,k, n2=priors ? priors->num_internal_lower_and_upper() : 0;
  double **X=new double*[len+n2];
  
  double **V=priors->get_linear_V(numseg);
  double *m=priors->get_linear_mean(numseg);
  
  inv_V=inverse_matrix(V,dim);
  for(j=0;j<dim;j++)
    {
      XtX[j]=new double[dim];
      for(k=0;k<dim;k++)
	XtX[j][k]=0.0;
    }
  for(j=0;j<dim;j++)
    inv_V_star[j]=new double[dim];
  
  for(i=0;i<len;i++)
    {
      X[i]=new double[dim];
      X[i][0]=1.0;
      for(j=0;j<numseg;j++)
	X[i][j+1]=Bj(h[i],j,curve);
      
      for(j=0;j<dim;j++)
	for(k=j;k<dim;k++)
	  if(weights)
	    XtX[j][k] += X[i][j]*X[i][k]/weights[i]/weights[i]/s2;
	  else
	    XtX[j][k] += X[i][j]*X[i][k]/s2;
    }
  int i2=0;
  int num_restr=0;
  double *restr_stage=NULL, *restr_q_lower = NULL, *restr_q_upper = NULL;
  if(priors && priors->num_internal_restrictions()>0)
    {
      num_restr=priors->num_internal_restrictions();
      restr_stage=priors->stage_internal_restrictions();
      restr_q_lower=priors->logdischarge_lower_internal_restrictions();
      restr_q_upper=priors->logdischarge_upper_internal_restrictions();
    }
  for(i=0;i<num_restr;i++)
    if(restr_q_lower[i]!=MISSING_VALUE && restr_q_upper[i]!=MISSING_VALUE)
      {
	double q_sd=(restr_q_upper[i]-restr_q_lower[i])/2.0/1.96;
	
	if(i2>=n2)
	  {
	    std::cerr << "Mismatch between number of upper+lower restrictions "
	      "found in restriction set " << i2+1 << " and previously defined "
	      "size of upper+lower restrictions " << n2 << "!" << std::endl;
	    exit(0);
	  }

	X[len+i2]=new double[dim];
	X[len+i2][0]=1.0;
	for(j=0;j<numseg;j++)
	  X[len+i2][j+1]=Bj(restr_stage[i],j,curve);
	
	for(j=0;j<dim;j++)
	  for(k=j;k<dim;k++)
	    XtX[j][k] += X[len+i2][j]*X[len+i2][k]/q_sd/q_sd;
	
	i2++;
      }
  if(i2!=n2)
    {
      std::cerr << "Mismatch between number of upper+lower restrictions "
	"found in restriction set " << i2 << " and previously defined "
	"size of upper+lower restrictions " << n2 << "!" << std::endl;
      exit(0);
    }
  
  for(j=0;j<dim;j++)
    for(k=0;k<j;k++)
      XtX[j][k]=XtX[k][j];
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      inv_V_star[j][k]=inv_V[j][k]+XtX[j][k];
  
  V_star=inverse_matrix(inv_V_star,dim);
  
  double *m_star_raw=new double[dim], *m_star=new double[dim];
  
  for(j=0;j<dim;j++)
    m_star_raw[j]=m_star[j]=0.0;
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      m_star_raw[j]+=inv_V[j][k]*m[k];
  for(i=0;i<len;i++)
    for(j=0;j<dim;j++)
      {
	if(weights)
	  m_star_raw[j]+=q[i]*X[i][j]/s2/weights[i]/weights[i];
	else
	  m_star_raw[j]+=q[i]*X[i][j]/s2;
      }
  i2=0;
  for(i=0;i<num_restr;i++)
    if(restr_q_lower[i]!=MISSING_VALUE && restr_q_upper[i]!=MISSING_VALUE)
      {
	double q_mean=(restr_q_upper[i]+restr_q_lower[i])/2.0;
	double q_sd=(restr_q_upper[i]-restr_q_lower[i])/2.0/1.96;
	
	for(j=0;j<dim;j++)
	  m_star_raw[j]+=q_mean*X[len+i2][j]/q_sd/q_sd;
	
	i2++;
      }
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      m_star[j]+=V_star[j][k]*m_star_raw[k];
  
  doubledelete(X,len+n2);
  doubledelete(XtX,dim);
  doubledelete(inv_V_star,dim);
  doubledelete(inv_V,dim);
  delete [] m_star_raw;
  
  if(T!=1.0)
    for(j=0;j<dim;j++)
      for(k=0;k<dim;k++)
	V_star[j][k]*=T;

  *m_star_=m_star;
  *V_star_=V_star;
}  


double segmented_curve_analysis::gibbs_linear(segmented_curve *curve, double T,
					      double *new_a1, double **new_b, 
					      gsl_rng *rptr)
{
  double *m_star, **V_star, ret;
  int numseg=curve->get_numseg(), j, dim=numseg+1;

  get_linear_proposal_hyperparameters(curve, T, &m_star, &V_star);
  double **linsamples=sample_from_multinormal(1,m_star,V_star,dim,rptr);
  
  double *b=new double[numseg];

  *new_a1=linsamples[0][0];
  for(j=0;j<numseg;j++)
    b[j]=linsamples[0][j+1];
  *new_b=b;

  ret=multinormal_pdf(linsamples[0],m_star,V_star,dim,true);
  
  delete [] m_star;
  doubledelete(V_star,dim);
  doubledelete(linsamples,1);
  
  return ret;
}

double segmented_curve_analysis::
get_proposal_logdensity(segmented_curve *proposed_curve,
			double T)
{
  int j,numseg=proposed_curve->get_numseg(),dim=numseg+1;
  double *m_star, **V_star;
  double ret, *beta=new double[dim];
  
  beta[0]=proposed_curve->get_a();
  for(j=1;j<=numseg;j++)
    beta[j]=proposed_curve->get_b(j);
  
  get_linear_proposal_hyperparameters(proposed_curve, T, 
				      &m_star, &V_star);
  
  ret=multinormal_pdf(beta,m_star,V_star,dim,true);
  
  delete [] m_star;
  doubledelete(V_star,dim);
  delete [] beta;
  
  return ret;
}

int segmented_curve_analysis::
draw_from_model(segmented_curve **prev_curve, double *prev_logprob,
		int num_temp, double *T,
		gsl_rng *rptr, double *rw_hs, double *rw_h0, 
		int h0_update /* =-1 means all h0's are updated */,
		int hs_update /* =-1 means all hs's are updated. If not
				 accpetance for this is reported */)
{
  int t,l, acc=0, num_seg=prev_curve[0]->numseg;
  double new_logprob;

  for(t=0;t<num_temp;t++)
    {
      double steptype=sqrt(T[t]);
      double r=drand48();
      if(r<0.1)
	steptype/=10.0;
      else if(r<0.2)
	steptype/=300.0;
      else if(r<0.3)
	steptype/=10000.0;
      else if(r<0.4)
	steptype*=10.0;
      else if(r<0.5)
	steptype*=100.0;
      
      // Update s^2
      prev_curve[t]->s2=gibbs_sigma2(prev_curve[t], T[t], rptr);
      prev_logprob[t]=prev_curve[t]->psi=logprob(prev_curve[t], T[t]);
      double *prev_hs=prev_curve[t]->hs;

      // Update hs:
      for(l=0;l<(num_seg-1);l++)
	if(hs_update<0 || hs_update==l)
	  {
	    double new_hs=prev_hs[l]+gsl_ran_gaussian(rptr,steptype*rw_hs[l]);
	    segmented_curve *newcurve=new segmented_curve(prev_curve[t]);
	    
	    newcurve->hs[l]=new_hs;
	    
	    new_logprob=logprob(newcurve, T[t]);
	    
	    if(log(drand48()) < new_logprob-prev_logprob[t])
	      {
		prev_curve[t]->hs[l]=new_hs;
		prev_curve[t]->psi=new_logprob;
		prev_logprob[t]=new_logprob;

		if(hs_update>=0)
		  acc=1;
	      }

	    delete newcurve;
	  }

      // Update h01, h02, a1, b1, b2:
      double *new_h0=new double[num_seg];
      for(l=0;l<num_seg;l++)
	new_h0[l]=prev_curve[t]->h0[l]+
	  gsl_ran_gaussian(rptr, steptype*rw_h0[l]);
 
      int is_h0_ok=1;
      if(new_h0[0]>=hmin)
	is_h0_ok=0;
      for(l=0;l<(num_seg-1);l++)
	if(new_h0[l]>=prev_curve[t]->hs[l] || 
	   new_h0[l+1]>=prev_curve[t]->hs[l])
	  is_h0_ok=0;

      if(is_h0_ok)
	{
	  if(h0_update>=0 && h0_update<num_seg)
	    for(l=0;l<num_seg;l++)
	      if(l!=h0_update)
		new_h0[l]=prev_curve[t]->h0[l];

	  segmented_curve *newcurve=new segmented_curve(prev_curve[t]);
	  for(l=0;l<num_seg;l++)
	    newcurve->h0[l]=new_h0[l];

	  double *new_b, new_a1;
	  double new_proposal=
	    gibbs_linear(newcurve, T[t], &new_a1, &new_b, rptr);
	  if(!(new_a1>-1e+200 && new_a1<1e+200))
	    {
	      std::cout << "Noe er galt med a1(4)!" << std::endl;
	    }
	  newcurve->a=new_a1;
	  for(l=0;l<num_seg;l++)
	    newcurve->b[l]=new_b[l];
	  
	  new_logprob=logprob(newcurve, T[t]);
	  
	  double prev_proposal=
	    get_proposal_logdensity(prev_curve[t], T[t]);	  
	  //double next_proposal=get_proposal_logdensity(newcurve, T[t]);

	  if(log(drand48())<
	     ((new_logprob-prev_logprob[t])-(new_proposal-prev_proposal)))
	    {
	      prev_curve[t]->copy(newcurve);
	      prev_logprob[t]=new_logprob;
	
	      if(t==0 && hs_update<0)
		acc=1;
	    }

	  delete [] new_b;
	  delete newcurve;
	}

      delete [] new_h0;
    }

  return acc;
}






void segmented_curve_analysis::switch_temp(double new_logprob1, 
					   double new_logprob2,
					   segmented_curve *curve_temp1,
					   segmented_curve *curve_temp2, 
					   int t, double *prev_logprob)
{
  segmented_curve *buffer_curve=new segmented_curve(curve_temp1);
  
  curve_temp1->copy(curve_temp2);
  curve_temp2->copy(buffer_curve);

  delete buffer_curve;

  prev_logprob[t+1]=new_logprob1;
  prev_logprob[t]=new_logprob2;
}

segmented_curve_analysis::segmented_curve_analysis()
{
  init();
}

segmented_curve_analysis::segmented_curve_analysis(segmented_curve_analysis 
						   *orig)
{
  init();

  num_mcmc=orig->num_mcmc;
  num_imp=orig->num_imp;
  indep=orig->indep;
  priors=orig->priors;
  len=orig->len;
  num_meas=orig->num_meas;
  num_temp=orig->num_temp;
  max_seg=orig->max_seg;
  min_seg=orig->min_seg;
  most_probable_model=orig->most_probable_model;
  chosen_model=orig->chosen_model;
  
  if(orig->median_curve)
    median_curve=new segmented_curve(orig->median_curve);
  if(orig->mean_curve)
    mean_curve=new segmented_curve(orig->mean_curve);
  
  int l,i;

  prob_mod=new double[max_seg];
  cumulative_prob_mod=new double[max_seg];
  loglikelihood_mod=new double[max_seg];
  for(i=0;i<max_seg;i++)
    {
      prob_mod[i]=orig->prob_mod[i];
      cumulative_prob_mod[i]=orig->cumulative_prob_mod[i];
      loglikelihood_mod[i]=orig->loglikelihood_mod[i];
    }
  
  q=new double[num_meas];
  h=new double[num_meas];
  if(orig->weights)
    weights=new double[num_meas];
  else
    weights=NULL;
  for(i=0;i<num_meas;i++)
    {
      q[i]=orig->q[i];
      h[i]=orig->h[i];
      if(orig->weights)
	weights[i]=orig->weights[i];
    }
  hmin=orig->hmin;
  hmax=orig->hmax;
    
  samples=new segmented_curve**[max_seg];
  for(l=0;l<(min_seg-1);l++)
    samples[l]=NULL;
  
  for(l=(min_seg-1);l<max_seg;l++)
    {
      samples[l]=new segmented_curve*[num_mcmc];
      for(i=0;i<num_mcmc;i++)
	samples[l][i]=new segmented_curve(orig->samples[l][i]);
    }

  if(orig->h_table_len>0 && orig->h_table && orig->lower_q_table && 
     orig->median_q_table && orig->upper_q_table)
    {
      h_table_len=orig->h_table_len;
      h_step=orig->h_step;
      
      hmin_table=orig->hmin_table;
      hmax_table=orig->hmax_table;
      
      h_table=new double[h_table_len];
      lower_q_table=new double[h_table_len];
      median_q_table=new double[h_table_len];
      upper_q_table=new double[h_table_len];
      
      for(i=0;i<h_table_len;i++)
	{
	  h_table[i]=orig->h_table[i];
	  lower_q_table[i]=orig->lower_q_table[i];
	  median_q_table[i]=orig->median_q_table[i];
	  upper_q_table[i]=orig->upper_q_table[i];
	}
    }

  if(orig->extrapolated_samples && orig->num_extrapolated>0)
    {
      num_extrapolated=orig->num_extrapolated;
      extrapolated_samples=new segmented_curve*[num_extrapolated];
      lambda=new double[num_extrapolated];
      for(i=0;i<num_extrapolated;i++)
	{
	  extrapolated_samples[i]=
	    new segmented_curve(orig->extrapolated_samples[i]);
	  lambda[i]=orig->lambda[i];
	}

      extrapolated_minseg=orig->extrapolated_minseg;
      extrapolated_maxseg=orig->extrapolated_maxseg;
      extrapolated_max_stage=orig->extrapolated_max_stage;
      
      extrapolated_prob_mod=new double[extrapolated_maxseg];
      extrapolated_cumulative_prob_mod=new double[extrapolated_maxseg];
    
      for(i=extrapolated_minseg-1;i<extrapolated_maxseg;i++)
	{
	  extrapolated_prob_mod[i]=orig->extrapolated_prob_mod[i];
	  extrapolated_cumulative_prob_mod[i]=
	    orig->extrapolated_cumulative_prob_mod[i];
	}
    }

  if(orig->q_table_len>0 && orig->q_table && orig->lower_h_table && 
     orig->median_h_table && orig->upper_h_table)
    {
      q_table_len=orig->q_table_len;
      
      qmin_table=orig->qmin_table;
      qmax_table=orig->qmax_table;

      q_table=new double[q_table_len];
      lower_h_table=new double[q_table_len];
      median_h_table=new double[q_table_len];
      upper_h_table=new double[q_table_len];
      
      for(i=0;i<q_table_len;i++)
	{
	  q_table[i]=orig->q_table[i];
	  lower_h_table[i]=orig->lower_h_table[i];
	  median_h_table[i]=orig->median_h_table[i];
	  upper_h_table[i]=orig->upper_h_table[i];
	}
    }
}

segmented_curve_analysis::~segmented_curve_analysis()
{
  cleanup();
}


void segmented_curve_analysis::
do_analysis(// measurements
	    int numdata, double *stage, double *discharge,
	    
	    // MCMC settings:
	    int num_mcmc_samples, int num_model_importance,

	    // Prior:
	    segmented_priors *priors_, 

	    // More MCMC settings
	    int burnin, int indep_spacing, int numtemp,
	    
	    // Minimum/maxmimum model to analyze:
	    int maxseg, int minseg,
	    
	    // Measurement weights for dealing with varying quality:
	    double *measurement_weights)
{
  int i, l, l2, t;
  
  max_seg=maxseg;
  min_seg=minseg;
  num_temp=numtemp;
  num_mcmc=num_mcmc_samples;
  num_imp=num_model_importance;
  indep=indep_spacing;
  
  priors=priors_;

  // Store the measurements:
  len=num_meas=numdata;
  q=new double[num_meas];
  h=new double[num_meas];
  if(measurement_weights)
    weights=new double[num_meas];
  else
    weights=NULL;
  for(i=0;i<num_meas;i++)
    {
      q[i]=log(discharge[i]);
      h[i]=stage[i];
      if(measurement_weights)
	weights[i]=measurement_weights[i];
    }    
  
  hmin=find_statistics(h,num_meas,MIN);
  hmax=find_statistics(h,num_meas,MAX);
  
  // DEBUG:
  printf("Measurements:\n");
  for(i=0;i<num_meas;i++)
    {
      if(weights)
	printf("%03d: %7.3f %7.3f %6.2f\n", i+1, h[i], q[i], weights[i]);
      else
	printf("%03d: %7.3f %7.3f\n", i+1, h[i], q[i]);
    }
  printf("Prior:\n");
  priors->print();
  printf("hmin=%7.3f hmax=%7.3f\n", hmin, hmax);


  double *T=new double[num_temp];
  
  // Initialize GSL random generator:
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  
  // Make the sample array:
  samples=new segmented_curve**[max_seg];
  for(l=0;l<(min_seg-1);l++)
    samples[l]=NULL;
  for(l=(min_seg-1);l<max_seg;l++)
    samples[l]=new segmented_curve*[num_mcmc];

  // Make the object vector holding previous simulation values 
  // for each temperature and for each number of segments:
  
  double **prev_logprob=new double*[max_seg];
  for(l=0;l<max_seg;l++)
    prev_logprob[l]=new double[num_temp];

  segmented_curve ***prev_curve = new segmented_curve**[max_seg];
  for(l=0;l<max_seg;l++)
    {
      prev_curve[l] = new segmented_curve*[num_temp];
      for(t=0;t<num_temp;t++)
	prev_curve[l][t]=NULL;
    }

  int *numswaps=NULL;

  if(num_temp>1)
    numswaps = new int[num_temp-1];
  
  // First sample for all models;
  for(l=(min_seg-1);l<max_seg;l++)
    {
      for(t=0;t<num_temp;t++)
	{
	  if(t==0)
	    T[t]=1.0;
	  else
	    T[t]=2.0*T[t-1];
	  if(num_temp>1 && t<num_temp-1)
	    numswaps[t]=0; 
	  
	  double a1 = priors->get_a_mu(l+1)+
	    gsl_ran_gaussian(rptr, priors->get_a_sd(l+1));
	  double *b=new double[l+1];
	  double *h0=new double[l+1];
	  double *hs=NULL;
	  if(l>0)
	    hs = new double[l];

	  for(l2=0;l2<(l+1);l2++)
	    {
	      b[l2]=priors->get_b_mu(l+1, l2)+
		gsl_ran_gaussian(rptr, priors->get_b_sd(l+1,l2));

	      if(l2==0 && priors->get_lognormal_h0(l+1,l2+1) &&
		 priors->get_h0_max(l+1,l2+1))
		h0[l2]=MINIM(hmin,priors->get_h0_max(l+1,l2+1))-drand48();
	      else if(l2==0 && priors->get_lognormal_h01() && 
		      priors->get_h01_max()!=MISSING_VALUE)
		h0[l2]=MINIM(hmin,priors->get_h01_max())-drand48();
	      else
		h0[l2]=hmin-drand48();

	      if(l2<l)
		hs[l2]=hmin+drand48()*(hmax-hmin);
	    }
	  if(l>1)
	    qsort(hs,l, sizeof(double), compare_double); 
	  
	  double s2=priors->get_sigma_a()>0.0 ? 
	    1.0/gsl_ran_gamma(rptr,priors->get_sigma_a(),
			      1.0/(priors->get_sigma_b())) : 1.0e+5*drand48();
	  
	  prev_curve[l][t]=new segmented_curve(l+1, a1, b, h0, hs, s2);
	  prev_logprob[l][t]=logprob(prev_curve[l][t], T[t]);

	  delete [] b;
	  delete [] h0;
	  if(hs)
	    delete [] hs;
	}
    }
  
  // burnin non-adaptive samples for each model;
  double **rw_hs=new double*[max_seg], **rw_h0=new double*[max_seg];
  for(l=0;l<max_seg;l++)
    {
      rw_hs[l]=new double[max_seg];
      rw_h0[l]=new double[max_seg];
      for(l2=0;l2<=l;l2++)
	{
	  rw_h0[l][l2]=0.1;
	  if(l2<l)
	    rw_hs[l][l2]=0.1;
	}
      
      if(l>=min_seg-1)
	for(i=0;i<burnin;i++)
	  {
	    draw_from_model(prev_curve[l], prev_logprob[l], num_temp, T, rptr,
			    rw_hs[l], rw_h0[l], -1, -1);
	    //std::cout << i << ":" << std::endl;
	    //prev_curve[l][0]->print();
	  }
    }
  
  // adaptive samples for each model:
  for(l=(min_seg-1);l<max_seg;l++)
    {
      for(i=0;i<burnin;i+=100)
	{
	  for(l2=0;l2<=l;l2++) // adapt rw_h0
	    {
	      int acc=0;
	      for(int j=0;j<100;j++)
		acc+=draw_from_model(prev_curve[l], prev_logprob[l],
				     num_temp, T, rptr,
				     rw_hs[l], rw_h0[l], l2, -1);
	      double accrate=double(acc)/double(100);
	      
	      rw_h0[l][l2]*=exp((accrate-0.33)*2.0);
	    }
	  
	  for(l2=0;l2<l;l2++) // adapt rw_hs
	    {
	      int acc=0;
	      for(int j=0;j<100;j++)
		acc+=draw_from_model(prev_curve[l], prev_logprob[l],
				     num_temp, T, rptr,
				     rw_hs[l], rw_h0[l], -1, l2);
	      double accrate=double(acc)/double(100);
	      
	      rw_hs[l][l2]*=exp((accrate-0.33)*2.0);
	    }
	}
    }     
  
  
  // MCMC sampling:
  for(l=(min_seg-1);l<max_seg;l++)
    {
      int index=0;
      for(i=1;i<=num_mcmc*indep+burnin;i++)
	{
	  if((l+1)>=2 && drand48()<0.1 && num_temp>1) 
	    // try tempering algorithm?
	    {
	      int t=(int) floor(drand48()*double(num_temp-1));
	      
	      double new_logprob1=
		logprob(prev_curve[l][t], T[t+1]);
	      double new_logprob2=
		logprob(prev_curve[l][t+1], T[t]);
	      
	      // swap parameters between distribution t 
	      // and distribution t+1
	      if(log(drand48())< new_logprob1+new_logprob2-
		 prev_logprob[l][t]-prev_logprob[l][t+1])
		{
		  switch_temp(new_logprob1, new_logprob2,
			      prev_curve[l][t], prev_curve[l][t+1], 
			      t, prev_logprob[l]);
		  numswaps[t]++;
		}
	    }
	  else // no tempering proposal
	    {
	      draw_from_model(prev_curve[l],
			      prev_logprob[l],
			      ((l+1)==1 ? 1 : num_temp), 
			      T, rptr, rw_hs[l], 
			      rw_h0[l], -1, -1);
	    }

	  if(l>0 && prev_curve[l][0]->get_hs(l)>hmax)
	    {
	      std::cout <<  prev_curve[l][0]->get_hs(l) << " > " << hmax << 
		" Dette skal ikke g� an!" << std::endl;
	      std::cout << logprob(prev_curve[l][0], T[0]) << std::endl;
	    }
	  
	  if(i>burnin && (i-burnin)%indep==0)
	    samples[l][index++]=new segmented_curve(prev_curve[l][0]);
	}
    }

  for(t=0;t<num_temp-1;t++)
    std::cout << "Number of swaps from " << t+1 << " to " << 
      t+2 << " : " << numswaps[t] << std::endl;

  doubledelete(prev_logprob, max_seg);
  doubledelete(prev_logprob, max_seg);
  doubledelete(rw_hs, max_seg);
  doubledelete(rw_h0, max_seg);

  for(i=l;l<max_seg;l++)
    {
      for(t=0;t<num_temp;t++)
	if(prev_curve[l][t])
	  delete prev_curve[l][t];
      delete [] prev_curve[l];
    }
  delete [] prev_curve;
  delete [] numswaps;


  // Get mean and correlation for the coefficients 
  // in the different models:
  double **mu_coefs=new double*[max_seg];
  double ***sigma_coefs=new double**[max_seg];
  int *dims=new int[max_seg];
  double *mean_logprob=new double[max_seg];
  double max_mean_logprob=MISSING_VALUE;
  
  for(l=(min_seg-1);l<max_seg;l++)
    {
      double **csamples=new double*[num_mcmc];

      dims[l]=4+3*l;
      for(i=0;i<num_mcmc;i++)
	csamples[i]=samples[l][i]->get_coef_array();
      
      mu_coefs[l]=find_mean_of_vectors(num_mcmc, csamples, dims[l]);
      sigma_coefs[l]=find_estimated_variance(num_mcmc, csamples,
					     mu_coefs[l], dims[l]);
      
      segmented_curve *new_curve=new segmented_curve(l+1, mu_coefs[l]);
      mean_logprob[l]=logprob(new_curve, T[0]);
      
      if(max_mean_logprob==MISSING_VALUE || max_mean_logprob<mean_logprob[l])
	max_mean_logprob=mean_logprob[l];
      
      delete new_curve;
      doubledelete(csamples, num_mcmc);
    }

  double *probsum=new double[max_seg];
  for(l=0;l<max_seg;l++)
    probsum[l]=0.0;

  // Importance sampling in order to calculate
  // the model probabilities:
  for(l=(min_seg-1);l<max_seg;l++)
    for(i=0;i<num_imp;i++)
      {
	double **csample=sample_from_multinormal(1, mu_coefs[l], 
						 sigma_coefs[l], 
						 dims[l], rptr);
	//if(i==0)
	//for(int j=0;j<dims[l];j++)
	//  csample[0][j]=mu_coefs[l][j];
	double prop_g=exp(multinormal_pdf(*csample, mu_coefs[l], 
					  sigma_coefs[l], dims[l], 
					  true));
	//if(l==1)
	//{
	//  std::cout << "Model nr 2" << std::endl;
	//}
	segmented_curve *new_curve=new segmented_curve(l+1, csample[0]);
	double new_logprob=logprob(new_curve, T[0]);
	double prob=exp(new_logprob-mean_logprob[l]);
	
	double w=1.0/prop_g;
	double limit=exp(200.0);
	
	if(!(w>-limit && w<limit))
	  {
	    std::cout << "noe er galt2!" << std::endl;
	    w=1.0/multinormal_pdf(*csample, mu_coefs[l], 
				  sigma_coefs[l], dims[l]);
	  }
	
	if(!(prob>-limit && prob<limit))
	  {
	     std::cout << "noe er galt3!" << std::endl;
	     prob=exp(logprob(new_curve, T[0])-mean_logprob[l]);
	  }
	
	//std::cout << i << " " << l << " " << prop_g << " " << 
	//  w << " " << prob << " " << w*prob << " " << probsum[l] << std::endl;
	probsum[l] += w*prob;
	
	doubledelete(csample,1);
	delete new_curve;
      }
  
  for(l=0;l<max_seg;l++)
    {
      probsum[l]/=double(num_imp);
      std::cout << "log_probsum" << l << "=" << 
	log(probsum[l])+mean_logprob[l] << std::endl;
      if(!(probsum[l]> -1e+200 && probsum[l]<1e+200))
	{
	  std::cerr << "Model " << l+1 << " failed! No model "
	    "probability estimated!" << std::endl;
	  probsum[l]=-1e+200;
	}
    }
  
  
  if(loglikelihood_mod)
    delete [] loglikelihood_mod;
  loglikelihood_mod=new double[max_seg];
  for(l=0;l<max_seg;l++)
    loglikelihood_mod[l]=log(probsum[l])+mean_logprob[l];
  
  // Calculate the model probabilities:
  double *p=new double[max_seg];
  double totalprobsum=0.0;
  for(l=(min_seg-1);l<max_seg;l++)
    totalprobsum+=probsum[l]*exp(mean_logprob[l]-max_mean_logprob)*
      priors->get_probability_of_model(l+1);
  for(l=0;l<(min_seg-1);l++)
    p[l]=0.0;
  for(l=(min_seg-1);l<max_seg;l++)
    p[l]=probsum[l]*exp(mean_logprob[l]-max_mean_logprob)*
      priors->get_probability_of_model(l+1)/totalprobsum;
  
  prob_mod=p;
  double max_prob=0.0;
  
  cumulative_prob_mod=new double[max_seg];
  for(l=0;l<max_seg;l++)
    {
      if(l==0)
	cumulative_prob_mod[l]=prob_mod[l];
      else
	cumulative_prob_mod[l]=cumulative_prob_mod[l-1]+prob_mod[l];
      
      if(prob_mod[l]>max_prob)
	{
	  max_prob=prob_mod[l];
	  most_probable_model=chosen_model=l+1;
	}
    }
  
  get_mean_and_median_curve();
  
  delete [] T;
  delete [] dims;
  delete [] probsum;
  delete [] mean_logprob;
}


// Samples a new segmented curve:
segmented_curve *segmented_curve_analysis::
sample_extrapolated_curve(int max_stage, double *newlambda,
			  segmented_curve *usecurve, 
			  bool include_lower, bool include_upper, 
			  int max_number_of_extra_segments)
{
  static int first=1;
  static gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  if(first)
    gsl_rng_set(rptr, rand());
  first=0;
  
  static segmented_priors default_prior(100);
  
  int mod,l,j;
  segmented_curve *curr_curve=NULL;
  if(!usecurve)
    {
      // Draw a random segmentation model within the measurement setg:
      double r=drand48();
      for(l=(min_seg-1);l<max_seg;l++)
	if(r<cumulative_prob_mod[l])
	  break;
      // l is now the number of segmentations
      mod=l+1; // number of segments
      
      // Draw a random curve within this segmentation:
      int index=(int) floor(drand48()*double(num_mcmc));
      curr_curve=samples[l][index];
      
      //if(mod>1 && curr_curve->get_hs(mod-1)>hmax)
      //{
	  //std::cout << "Noe er galt(6)!" << std::endl;
      //}
    }
  else
    {
      mod=usecurve->get_numseg();
      curr_curve=usecurve;
    }

  // DEBUG: return curr_curve;
  
  // Draw lambda:
  double a0=1.0, b0=1.0/3.3; // 95% cred. approximately
  // between (1/12 and 12)
  double a_star=curr_curve->get_numseg()+a0; // number of segmentations+prior
  double b_star=b0+(hmax-hmin);
  double lambda=0.0;
  if(newlambda)
    *newlambda=gsl_ran_gamma(rptr, a_star, 1.0/b_star);
  else
    lambda=gsl_ran_gamma(rptr, a_star, 1.0/b_star);
  //std::cout << "i=" << i << " lambda=" << *newlambda << 
  // " hmin=" << hmin << " hmax=" << hmax << " l=" << l << std::endl;
  
  // Draw upper segments:
  int num_upper_seg=0; // number of new segments between
  // hmax and max_stage
  double upper_b[1000];
  double upper_h0[1000];
  double upper_hs[1000];
  
  upper_b[0]=upper_h0[0]=MISSING_VALUE; 
  // (shared with upper segment within the dataset
  
  // DEBUG:
  //include_upper=include_lower=false;

  double curr_h=hmax+gsl_ran_exponential(rptr,1.0/(newlambda ? *newlambda : lambda));
  double prev_h0=curr_curve->get_h0(mod);
  if(include_upper)
    while(curr_h<max_stage && num_upper_seg<1000 &&
	  (max_number_of_extra_segments<=0 || 
	   num_upper_seg<max_number_of_extra_segments))
      {
	upper_hs[num_upper_seg]=curr_h;
	
	num_upper_seg++;
	
	// Draw new b:
	double mub, sdb;
	if(priors && (priors->is_lin_detailed() || 
		      priors->is_lin_extremely_detailed()))
	  {
	    mub=default_prior.get_overall_b_mu();
	    sdb=default_prior.get_overall_b_sd();
	  }
	else
	  {
	    mub=priors->get_overall_b_mu();
	    sdb=priors->get_overall_b_sd();
	  }
	upper_b[num_upper_seg]=mub+sdb*gsl_ran_ugaussian(rptr);
	
	do
	  {
	    // draw new h0:
	    double muh0, sdh0;
	    if(priors && priors->is_h0_detailed())
	      {
		muh0=prev_h0;//default_prior.get_h02_mu();
		sdh0=default_prior.get_h02_sd();
	      }
	    else
	      {
		muh0=prev_h0;//priors->get_h02_mu();
		sdh0=priors->get_h02_sd();
	      }
	    upper_h0[num_upper_seg]=muh0+sdh0*gsl_ran_ugaussian(rptr);
	  } while(upper_h0[num_upper_seg]>=curr_h);
	
	prev_h0=upper_h0[num_upper_seg];
	upper_hs[num_upper_seg]=MISSING_VALUE;
	
	curr_h += gsl_ran_exponential(rptr,1.0/(newlambda ? *newlambda : lambda));
	//std::cout << "upper: " << num_upper_seg << " " << curr_h << 
	//" " << max_stage << std::endl;

	if(num_upper_seg>0 && (upper_h0[num_upper_seg-1]>upper_hs[num_upper_seg-1] ||
			       upper_h0[num_upper_seg]>upper_hs[num_upper_seg-1] ||
			       upper_hs[num_upper_seg-1]>curr_h))
	  {
	    std::cout << "Noe er galt!" << std::endl;
	  }
      } 
  
  // Draw lower segments:
  int num_lower_seg=0; // number of new segments between
  // hmax and max_stage
  double lower_b[1000];
  double lower_h0[1000];
  double lower_hs[1000];
  double lower_a[1000];
  
  lower_a[0]=lower_b[0]=lower_h0[0]=MISSING_VALUE; 
  // (shared with lowest segment within the dataset
  
  curr_h=hmin-gsl_ran_exponential(rptr,1.0/(newlambda ? *newlambda : lambda));
  prev_h0=curr_curve->get_h0(1);
  
  double prev_a=curr_curve->get_a(1);
  double prev_b=curr_curve->get_b(1);
  //std::cout << "lower: " << num_lower_seg << " " << curr_h << 
  //" " << prev_h0 << std::endl;
  if(include_lower) 
    while(curr_h>prev_h0 && num_lower_seg<1000 &&
	  (max_number_of_extra_segments<=0 || 
	   num_upper_seg+num_lower_seg<max_number_of_extra_segments))
      {
	lower_hs[num_lower_seg]=curr_h;
	
	// Draw new b:
	double mub, sdb;
	if(priors && (priors->is_lin_detailed() || 
		      priors->is_lin_extremely_detailed()))
	  {
	    mub=default_prior.get_overall_b_mu();
	    sdb=default_prior.get_overall_b_sd();
	  }
	else
	  {
	    mub=priors->get_overall_b_mu();
	    sdb=priors->get_overall_b_sd();
	  }
	lower_b[num_lower_seg]=mub+sdb*gsl_ran_ugaussian(rptr);
	
	do
	  {
	    // draw new h0:
	    double muh0, sdh0;
	    if(priors && priors->is_h0_detailed())
	      {
		muh0=prev_h0;//-default_prior.get_h02_mu();
		sdh0=default_prior.get_h02_sd();
	      }
	    else
	      {
		muh0=prev_h0;//-priors->get_h02_mu();
		sdh0=priors->get_h02_sd();
	      }
	    lower_h0[num_lower_seg]=muh0+sdh0*gsl_ran_ugaussian(rptr);
	  } while(lower_h0[num_lower_seg]>curr_h);
	
	lower_a[num_lower_seg]=prev_a+prev_b*log(curr_h-prev_h0)-
	  lower_b[num_lower_seg]*log(curr_h-lower_h0[num_lower_seg]);
	
	prev_h0=lower_h0[num_lower_seg];
	prev_b=lower_b[num_lower_seg];
	prev_a=lower_a[num_lower_seg];
	
	num_lower_seg++;
	
	curr_h -= gsl_ran_exponential(rptr,1.0/(newlambda ? *newlambda : lambda));
	//std::cout << "lower:" << num_lower_seg << " " << 
	//curr_h << " " << prev_h0 << std::endl;
      } 
  
  // Make a new curve based on curve within dataset and
  // upper and lower extrapolations
  
  int new_num_seg=mod+num_lower_seg+num_upper_seg;
  double a=prev_a, *b=new double[new_num_seg],
    *h0=new double[new_num_seg],*hs=new double[new_num_seg];
  double s2=curr_curve->get_s2(), psi=curr_curve->get_psi();
  bool *extrapol=new bool[new_num_seg];
  
  for(j=0;j<num_lower_seg;j++)
    {
      b[j]=lower_b[num_lower_seg-j-1];
      h0[j]=lower_h0[num_lower_seg-j-1];
      hs[j]=lower_hs[num_lower_seg-j-1];
      extrapol[j]=true;
    }
  for(j=0;j<mod;j++)
    {
      b[j+num_lower_seg]=curr_curve->get_b(j+1);
      h0[j+num_lower_seg]=curr_curve->get_h0(j+1);
      if(j<(mod-1))
	hs[j+num_lower_seg]=curr_curve->get_hs(j+1);
      else if(num_upper_seg>0)
	hs[j+num_lower_seg]=upper_hs[0];
      extrapol[j+num_lower_seg]=false;
    }
  for(j=0;j<num_upper_seg;j++)
    {
      b[j+num_lower_seg+mod]=upper_b[j+1];
      h0[j+num_lower_seg+mod]=upper_h0[j+1];
      hs[j+num_lower_seg+mod]=upper_hs[j+1];
      extrapol[j+num_lower_seg+mod]=true;
    }
  
  segmented_curve *newcurve=
    new segmented_curve(new_num_seg, a, b, h0, hs, s2, psi, extrapol);
  
  delete [] b;
  delete [] h0;
  delete [] hs;
  delete [] extrapol;
  
  return newcurve;
}

double segmented_curve_analysis::
log_extrapolation_density(segmented_curve *curve)
{
  double ret=0.0;

  int num_extra=0;
  double *extra_stage=NULL, *extra_q_lower = NULL, *extra_q_upper = NULL;
  if(priors && priors->num_extrapolation_restrictions()>0)
    {
      num_extra=priors->num_extrapolation_restrictions();
      extra_stage=priors->stage_extrapolation_restrictions();
      extra_q_lower=priors->logdischarge_lower_extrapolation_restrictions();
      extra_q_upper=priors->logdischarge_upper_extrapolation_restrictions();
    }
  
  if(!extra_q_lower || !extra_q_upper || !extra_stage)
    return ret;
  
  for(int i=0;i<num_extra;i++)
    {
      if(curve->get_discharge(extra_stage[i])==0.0)
	return -1e+200;
      
      double q=log(curve->get_discharge(extra_stage[i]));
      
      if(extra_q_lower[i]!=MISSING_VALUE && extra_q_upper[i]!=MISSING_VALUE)
	{
	  double mu=(extra_q_upper[i]+extra_q_lower[i])/2.0;
	  double sd=(extra_q_upper[i]-extra_q_lower[i])/2.0/1.96;
	  
	  ret += -0.5*log(2.0*M_PI)-log(sd)-0.5*(q-mu)*(q-mu)/sd/sd;
	}
      else if(extra_q_lower[i]!=MISSING_VALUE)
	{
	  if(q<extra_q_lower[i])
	    return -1e+200;
	}
      else if(extra_q_upper[i]!=MISSING_VALUE)
	{
	  if(q>extra_q_upper[i])
	    return -1e+200;
	}
    }

  return ret;
}

// Uses the analysis (including MCMC samples) to make
// extrapolated curve samples using a Poisson process model
// for segments:
void segmented_curve_analysis::set_extrapolation_samples(double max_stage, 
							 int num_samples)
{
  extrapolated_max_stage=max_stage;
  num_extrapolated=num_samples;
  
  extrapolated_samples=new segmented_curve*[num_extrapolated];
  lambda=new double[num_extrapolated];
  
  extrapolated_minseg=extrapolated_maxseg=0;
  
  int i;
  //std::cout << "Starting extrapolation sampling\n";
  int num_extra=0;
  if(priors && priors->num_extrapolation_restrictions()>0)
    num_extra=priors->num_extrapolation_restrictions();
  
  for(i=0;i<num_extrapolated;i++)
    {
      //std::cout << "i=" << i << std::endl;
      segmented_curve *newcurve=sample_extrapolated_curve(max_stage, lambda+i);
      
      if(num_extra>0) // Handle extrapolation prior restrictions
	{
	  double logdens=log_extrapolation_density(newcurve);
	  while(logdens<= -1e+200)
	    {
	      if(newcurve)
		delete newcurve;
	      newcurve=sample_extrapolated_curve(max_stage, lambda+i);
	      logdens=log_extrapolation_density(newcurve);
	    }
	  
	  
	  // Quick MCMC sampling with independent proposal equal to
	  // posterior process model. (Which makes process model
	  // posterior probability distribution cancel out in the MCMC):
	  for(int j=0;j<200;j++)
	    {
	      double newlambda = 0.0;
	      segmented_curve *propcurve=
		sample_extrapolated_curve(max_stage, lambda+i);
					  //&newlambda);
	      double newlogdens=log_extrapolation_density(propcurve);
	      
	      if(log(drand48())< newlogdens-logdens)
		{
		  delete newcurve;
		  newcurve=propcurve;
		  lambda[i]=newlambda;
		  logdens=newlogdens;
		}
	      else 
		delete propcurve;
	    }
	  
	}
      
      extrapolated_samples[i]=newcurve;
      int new_num_seg=newcurve->get_numseg();
      
      if(extrapolated_minseg==0 || new_num_seg<extrapolated_minseg)
	extrapolated_minseg=new_num_seg;
      if(extrapolated_maxseg==0 || new_num_seg>extrapolated_maxseg)
	extrapolated_maxseg=new_num_seg;
    }
  //std::cout << "Ending extrapolation sampling\n";
  
  extrapolated_prob_mod=new double[extrapolated_maxseg];
  for(i=0;i<extrapolated_maxseg;i++)
    extrapolated_prob_mod[i]=0.0;
  for(i=0;i<num_extrapolated;i++)
    extrapolated_prob_mod[extrapolated_samples[i]->get_numseg()-1]++;
  for(i=0;i<extrapolated_maxseg;i++)
    extrapolated_prob_mod[i]/=double(num_extrapolated);
  
  extrapolated_cumulative_prob_mod=new double[extrapolated_maxseg];
  extrapolated_cumulative_prob_mod[0]=extrapolated_prob_mod[0];
  for(i=1;i<extrapolated_maxseg;i++)
    extrapolated_cumulative_prob_mod[i]=extrapolated_cumulative_prob_mod[i-1]+
      extrapolated_prob_mod[i];
}


void segmented_curve_analysis::get_mean_and_median_curve(void)
{
  int i,l;

  // Calculate the mean and median of the 
  // most probable model:
  double *a=new double[num_mcmc];
  double **b=new double*[chosen_model];
  for(i=0;i<chosen_model;i++)
    b[i]=new double[num_mcmc];
  double **h0=new double*[chosen_model];
  for(i=0;i<chosen_model;i++)
    h0[i]=new double[num_mcmc];
  double **hs=NULL;
  if(chosen_model>1)
    {
      hs=new double*[chosen_model-1];
      for(l=0;l<(chosen_model-1);l++)
	hs[l]=new double[num_mcmc];
    }
  double *s2=new double[num_mcmc];

  for(i=0;i<num_mcmc;i++)
    {
      a[i]=samples[chosen_model-1][i]->get_a();
      for(l=0;l<chosen_model;l++)
	b[l][i]=samples[chosen_model-1][i]->get_b(l+1);
      for(l=0;l<chosen_model;l++)
	h0[l][i]=samples[chosen_model-1][i]->get_h0(l+1);
      if(chosen_model>1)
	{
	  for(l=0;l<(chosen_model-1);l++)
	    hs[l][i]=samples[chosen_model-1][i]->get_hs(l+1);
	}
      s2[i]=samples[chosen_model-1][i]->get_sigma_squared();
    }
  
  double median_a=find_statistics(a, num_mcmc, MEDIAN);
  double *median_b=new double[chosen_model];
  for(l=0;l<chosen_model;l++)
    median_b[l]=find_statistics(b[l], num_mcmc, MEDIAN);
  double *median_h0=new double[chosen_model];
  for(l=0;l<chosen_model;l++)
    median_h0[l]=find_statistics(h0[l], num_mcmc, MEDIAN);
  double *median_hs=NULL;
  if(chosen_model>1)
    {
      median_hs=new double[chosen_model-1];
      for(l=0;l<(chosen_model-1);l++)
	median_hs[l]=find_statistics(hs[l], num_mcmc, MEDIAN);
    }
  double median_s2=find_statistics(s2, num_mcmc, MEDIAN);
  median_curve=new segmented_curve(chosen_model,
				   median_a, median_b, median_h0,
				   median_hs, median_s2);

  double mean_a=find_statistics(a, num_mcmc, MEAN);
  double *mean_b=new double[chosen_model];
  for(l=0;l<chosen_model;l++)
    mean_b[l]=find_statistics(b[l], num_mcmc, MEAN);
  double *mean_h0=new double[chosen_model];
  for(l=0;l<chosen_model;l++)
    mean_h0[l]=find_statistics(h0[l], num_mcmc, MEAN);
  double *mean_hs=NULL;
  if(chosen_model>1)
    {
      mean_hs=new double[chosen_model-1];
      for(l=0;l<(chosen_model-1);l++)
	mean_hs[l]=find_statistics(hs[l], num_mcmc, MEAN);
    }
  double mean_s2=find_statistics(s2, num_mcmc, MEAN);
  mean_curve=new segmented_curve(chosen_model,
				 mean_a, mean_b, mean_h0,
				 mean_hs, mean_s2);

  delete [] median_b;
  delete [] median_h0;
  if(median_hs)
    delete [] median_hs;
  delete [] mean_b;
  delete [] mean_h0;
  if(mean_hs)
    delete [] mean_hs;
  delete [] a;
  delete [] s2;
  doubledelete(b, chosen_model);
  doubledelete(h0, chosen_model);
  if(chosen_model>1)
    doubledelete(hs, chosen_model-1);
}

// Sets the analysis structure from external information. If chosen
// model is not set (chosen_model<=0), it is set to the most probable model.
void segmented_curve_analysis::load_analysis(int chosenmodel,
					     segmented_curve ***in_samples,
					     double *in_probs,
					     double *in_loglikelihoods,
					     int in_num_mcmc, int in_num_imp, 
					     int in_indep,
					     segmented_priors *in_priors, 
					     // external pointer.
					     int in_num_meas, 
					     int in_num_temp, 
					     int in_max_seg, int in_min_seg,
					     double *in_q, double *in_h, 
					     double in_hmin, double in_hmax,
					     double *measurement_weights)
{
  cleanup();
  
  chosen_model=chosenmodel;
  num_mcmc=in_num_mcmc;
  num_imp=in_num_imp;
  indep=in_indep;
  len=num_meas=in_num_meas;
  num_temp=in_num_temp;
  max_seg=in_max_seg;
  min_seg=in_min_seg;
  
  if(in_priors)
    priors=new segmented_priors(in_priors);
  else
    priors=NULL;

  int i,l;
  q=new double[len];
  h=new double[len];
  if(measurement_weights)
    weights=new double[num_meas];
  else
    weights=NULL;
  for(i=0;i<len;i++)
    {
      q[i]=in_q[i];
      h[i]=in_h[i];
      if(measurement_weights)
	weights[i]=measurement_weights[i];
    }
  
  hmin=in_hmin;
  hmax=in_hmax;
    
  samples=new segmented_curve**[max_seg];
  for(l=(min_seg-1);l<max_seg;l++)
    {
      samples[l]=new segmented_curve*[num_mcmc];
      for(i=0;i<num_mcmc;i++)
	samples[l][i]=new segmented_curve(in_samples[l][i]);
    }
  
  if(loglikelihood_mod)
    delete [] loglikelihood_mod;
  loglikelihood_mod=new double[max_seg];
  for(l=0;l<max_seg;l++)
    if(in_loglikelihoods)
      loglikelihood_mod[l]=in_loglikelihoods[l];
    else
      loglikelihood_mod[l]=MISSING_VALUE;
  
  double *p=new double[max_seg];
  for(l=0;l<max_seg;l++)
    p[l]=in_probs[l];
  
  double totalprobsum=0.0;
  for(l=0;l<max_seg;l++)
    totalprobsum+=p[l];
  for(l=0;l<max_seg;l++)
    p[l]/=totalprobsum;
  
  prob_mod=p;
  double max_prob=0.0;
  cumulative_prob_mod=new double[max_seg];
  for(l=0;l<max_seg;l++)
    {
      if(l==0)
	cumulative_prob_mod[l]=prob_mod[l];
      else
	cumulative_prob_mod[l]=cumulative_prob_mod[l-1]+prob_mod[l];
      
      if(prob_mod[l]>max_prob)
	{
	  max_prob=prob_mod[l];
	  most_probable_model=l+1;
	  if(chosen_model<=0)
	    chosen_model=most_probable_model;
	}
    }
  
  get_mean_and_median_curve();
}

int segmented_curve_analysis::get_most_probable_model(void)
{
  return most_probable_model;
}

int segmented_curve_analysis::get_chosen_model(void)
{
  return chosen_model;
}

void segmented_curve_analysis::set_chosen_model(int best_model)
{
  chosen_model=best_model;
}

double segmented_curve_analysis::get_probability_of_model(int num_seg)
{
  return prob_mod[num_seg-1];
}

double segmented_curve_analysis::get_loglikelihood_of_model(int num_seg)
{
  return loglikelihood_mod[num_seg-1];
}

double segmented_curve_analysis::get_median_a(void)
{
  if(median_curve)
    return median_curve->get_a();
  else
    return MISSING_VALUE;
}


double segmented_curve_analysis::get_median_b(int seg)
{
  if(median_curve && seg>0 && seg<=chosen_model)
    return median_curve->get_b(seg);
  else
    return MISSING_VALUE;
}

double *segmented_curve_analysis::get_median_b_array(void)
{
  if(!median_curve)
    return NULL;

  double *b=new double[chosen_model];
  for(int i=0;i<chosen_model;i++)
    b[i]=median_curve->get_b(i+1);

  return b;
}


double segmented_curve_analysis::get_median_h0(int seg)
{
  if(median_curve && seg>0 && seg<=chosen_model)
    return median_curve->get_h0(seg);
  else
    return MISSING_VALUE;
}

double *segmented_curve_analysis::get_median_h0_array(void)
{
  if(!median_curve)
    return NULL;

  double *h0=new double[chosen_model];
  for(int i=0;i<chosen_model;i++)
    h0[i]=median_curve->get_h0(i+1);

  return h0;
}


double segmented_curve_analysis::get_median_hs(int seg)
{
  if(median_curve && seg>0 && seg<chosen_model)
    return median_curve->get_hs(seg);
  else
    return MISSING_VALUE;
}

double *segmented_curve_analysis::get_median_hs_array(void)
{
  if(!median_curve || chosen_model<=1)
    return NULL;
  
  double *hs=new double[chosen_model];
  for(int i=0;i<(chosen_model-1);i++)
    hs[i]=median_curve->get_hs(i+1);

  return hs;
}

double segmented_curve_analysis::get_median_sigma_squared(void)
{
  if(median_curve)
    return median_curve->get_s2();
  else
    return MISSING_VALUE;
}

double segmented_curve_analysis::get_median_sigma(void)
{
  if(median_curve)
    return sqrt(median_curve->get_s2());
  else
    return MISSING_VALUE;
}

segmented_curve *segmented_curve_analysis::get_median_curve(void)
{
  return median_curve;
}

segmented_curve *segmented_curve_analysis::get_median_curve(int num_seg)
{
  int i,l;
  double *a=new double[num_mcmc];
  double **b=new double*[num_seg];
  for(l=0;l<num_seg;l++)
    b[l]=new double[num_mcmc];
  double **h0=new double*[num_seg];
  for(l=0;l<num_seg;l++)
    h0[l]=new double[num_mcmc];
  double **hs=new double*[num_seg];
  for(l=0;l<num_seg;l++)
    hs[l]=new double[num_mcmc];
  double *s2=new double[num_mcmc];

  for(i=0;i<num_mcmc;i++)
    {
      a[i]=samples[num_seg-1][i]->get_a();
      for(l=0;l<num_seg;l++)
	b[l][i]=samples[num_seg-1][i]->get_b(l+1);
      for(l=0;l<num_seg;l++)
	h0[l][i]=samples[num_seg-1][i]->get_h0(l+1);
      if(num_seg>1)
	{
	  for(l=0;l<(num_seg-1);l++)
	    hs[l][i]=samples[num_seg-1][i]->get_hs(l+1);
	}
      s2[i]=samples[num_seg-1][i]->get_sigma_squared();
    }
  
  double median_a=find_statistics(a, num_mcmc, MEDIAN);
  double *median_b=new double[num_seg];
  for(l=0;l<num_seg;l++)
    median_b[l]=find_statistics(b[l], num_mcmc, MEDIAN);
  double *median_h0=new double[num_seg];
  for(l=0;l<num_seg;l++)
    median_h0[l]=find_statistics(h0[l], num_mcmc, MEDIAN);
  double *median_hs=NULL;
  if(num_seg>1)
    {
      median_hs=new double[num_seg-1];
      for(l=0;l<(num_seg-1);l++)
	median_hs[l]=find_statistics(hs[l], num_mcmc, MEDIAN);
    }
  double median_s2=find_statistics(s2, num_mcmc, MEDIAN);
  segmented_curve *model_median_curve=
    new segmented_curve(num_seg,
			median_a, median_b, median_h0,
			median_hs, median_s2);
  
  delete [] a;
  doubledelete(b,num_seg);
  doubledelete(h0,num_seg);
  doubledelete(hs,num_seg);
  delete [] s2;
  delete [] median_b;
  delete [] median_h0;
  if(median_hs)
    delete [] median_hs;
  
  return model_median_curve;
}

segmented_curve *segmented_curve_analysis::get_mean_curve(int num_seg)
{
  int i,l;
  double *a=new double[num_mcmc];
  double **b=new double*[num_seg];
  for(l=0;l<num_seg;l++)
    b[l]=new double[num_mcmc];
  double **h0=new double*[num_seg];
  for(l=0;l<num_seg;l++)
    h0[l]=new double[num_mcmc];
  double **hs=new double*[num_seg];
  for(l=0;l<num_seg;l++)
    hs[l]=new double[num_mcmc];
  double *s2=new double[num_mcmc];

  for(i=0;i<num_mcmc;i++)
    {
      a[i]=samples[num_seg-1][i]->get_a();
      for(l=0;l<num_seg;l++)
	b[l][i]=samples[num_seg-1][i]->get_b(l+1);
      for(l=0;l<num_seg;l++)
	h0[l][i]=samples[num_seg-1][i]->get_h0(l+1);
      if(num_seg>1)
	{
	  for(l=0;l<(num_seg-1);l++)
	    hs[l][i]=samples[num_seg-1][i]->get_hs(l+1);
	}
      s2[i]=samples[num_seg-1][i]->get_sigma_squared();
    }
  
  double mean_a=find_statistics(a, num_mcmc, MEAN);
  double *mean_b=new double[num_seg];
  for(l=0;l<num_seg;l++)
    mean_b[l]=find_statistics(b[l], num_mcmc, MEAN);
  double *mean_h0=new double[num_seg];
  for(l=0;l<num_seg;l++)
    mean_h0[l]=find_statistics(h0[l], num_mcmc, MEAN);
  double *mean_hs=NULL;
  if(num_seg>1)
    {
      mean_hs=new double[num_seg-1];
      for(l=0;l<(num_seg-1);l++)
	mean_hs[l]=find_statistics(hs[l], num_mcmc, MEAN);
    }
  double mean_s2=find_statistics(s2, num_mcmc, MEAN);
  segmented_curve *model_mean_curve=
    new segmented_curve(num_seg,
			mean_a, mean_b, mean_h0,
			mean_hs, mean_s2);
  
  delete [] a;
  doubledelete(b,num_seg);
  doubledelete(h0,num_seg);
  doubledelete(hs,num_seg);
  delete [] s2;
  delete [] mean_b;
  delete [] mean_h0;
  if(mean_hs)
    delete [] mean_hs;
  
  return model_mean_curve;
}

int logprob_numseg;
segmented_curve_analysis *logprob_pt;
double logprob_optim(double *x)
{
  segmented_curve *pt=new segmented_curve(logprob_numseg, x);
  double ret=logprob_pt->logprob(pt, 1.0);

  delete pt;
  return ret;
}

int logprob_extrapol_numseg;
segmented_curve_analysis *logprob_extrapol_pt;
double logprob_extrapol_optim(double *x)
{
  segmented_curve *pt=new segmented_curve(logprob_extrapol_numseg, x);
  double ret=logprob_extrapol_pt->logprob(pt, 1.0, true);
  
  delete pt;
  return ret;
}

void segmented_curve_analysis::set_modus_curve(int num_seg, 
					       segmented_curve 
					       *modus_estimate)
{
  int i;
  if(!modus_curves) // initialize if not already done
    {
      modus_curves=new segmented_curve*[max_seg-min_seg+1];
      for(i=min_seg;i<=max_seg;i++)
	modus_curves[i-min_seg]=NULL;
    }
  
  if(modus_curves[num_seg-min_seg])
    delete modus_curves[num_seg-min_seg];
  modus_curves[num_seg-min_seg]=new segmented_curve(modus_estimate);
}


segmented_curve *segmented_curve_analysis::get_modus_curve(int num_seg, double max_stage)
{
  int i,k;
  if(!modus_curves) // initialize if not already done
    {
      modus_curves=new segmented_curve*[max_seg-min_seg+1];
      for(i=min_seg;i<=max_seg;i++)
	modus_curves[i-min_seg]=NULL;
    }

  // Only do a modus operation once per model
  if(modus_curves[num_seg-min_seg])
    {
      segmented_curve *ret=new segmented_curve(modus_curves[num_seg-min_seg]);
      return ret;
    }
  
  int num_samples=num_mcmc/10, opt_index;
  segmented_curve **curve_sample=new segmented_curve*[num_samples];
  segmented_curve **curve_optim_sample=new segmented_curve*[num_samples];
  double maxprob;
  
  curve_sample[0]=get_median_curve(num_seg);
  curve_sample[1]=get_mean_curve(num_seg);
  for(i=2;i<num_samples;i++)
    {
      int index=(int) floor(double(num_mcmc)*drand48());
      curve_sample[i]=new segmented_curve(samples[num_seg-1][index]);
    }

  int num_extra=0;
  double *extra_stage=NULL;
  if(priors && priors->num_extrapolation_restrictions()>0)
    {
      num_extra=priors->num_extrapolation_restrictions();
      extra_stage=priors->stage_extrapolation_restrictions();
    }
  
  for(i=0;i<num_samples;i++)
    {
      int dim, maxiter=1000;
      double *start_coefs=curve_sample[i]->get_coef_array(&dim);
      
      logprob_numseg=num_seg;
      logprob_pt=this;
      double *opt_coefs=gsl_optimization_cover(logprob_optim, dim,
					       start_coefs, 0.00001, 
					       maxiter,false);
      curve_optim_sample[i]=new segmented_curve(num_seg, opt_coefs);
      
      double curr_prob=logprob(curve_optim_sample[i], 1.0);
      
      if(i==0 || curr_prob>maxprob)
	{
	  maxprob=curr_prob;
	  opt_index=i;
	}
      
      delete [] opt_coefs;
      delete [] start_coefs;
    }
  
  segmented_curve *best=new segmented_curve(curve_optim_sample[opt_index]);
  double bestprob=logprob(best, 1.0, true);
  
  if(num_extra>0 && best->get_numseg()<priors->get_max_seg())
    {
      int num_over=0, num_under=0;
      for(k=0;k<num_extra;k++)
	if(extra_stage[k]>hmax)
	  num_over++; 
	else
	  num_under++;
      
      int maxk=priors->get_max_seg()-best->get_numseg();
      for(k=1;k<=maxk;k++) // Number of possible extra segments outside the interpolated area
	for(i=0;i<num_samples/maxk;i++)
	  {
	    segmented_curve *newcurve=NULL;
	    do
	      {
		if(newcurve)
		  delete newcurve;
		newcurve=sample_extrapolated_curve(max_stage,NULL,
						   curve_optim_sample[opt_index],
						   num_under ? true : false,
						   num_over ? true : false,
						   k);
	      }
	    while(newcurve->get_numseg() != curve_optim_sample[opt_index]->get_numseg()+k);
	    
	    double newprob=logprob(newcurve, 1.0, true)-gsl_cdf_chisq_Pinv(0.95,double(k));
	    if(newprob > bestprob)
	      {
		delete best;
		best=newcurve;
		bestprob=newprob;
	      }
	    else
	      delete newcurve;
	  }
    }
  
  // Cleanup:
  for(i=0;i<num_samples;i++)
    {
      delete curve_sample[i];
      delete curve_optim_sample[i];
    }  
  delete [] curve_sample;
  delete [] curve_optim_sample;
  
  // Store a copy internally for later use:
  modus_curves[num_seg-min_seg]=new segmented_curve(best);
  
  return best;
}

segmented_curve *segmented_curve_analysis::get_best_modus_curve(double max_stage)
{
  return get_modus_curve(chosen_model,max_stage);
}

double segmented_curve_analysis::get_mean_a(void)
{
  if(mean_curve)
    return mean_curve->get_a();
  else
    return MISSING_VALUE;
}


double segmented_curve_analysis::get_mean_b(int seg)
{
  if(mean_curve && seg>0 && seg<=chosen_model)
    return mean_curve->get_b(seg);
  else
    return MISSING_VALUE;
}

double *segmented_curve_analysis::get_mean_b_array(void)
{
  if(!mean_curve)
    return NULL;

  double *b=new double[chosen_model];
  for(int i=0;i<chosen_model;i++)
    b[i]=mean_curve->get_b(i+1);

  return b;
}


double segmented_curve_analysis::get_mean_h0(int seg)
{
  if(mean_curve && seg>0 && seg<=chosen_model)
    return mean_curve->get_h0(seg);
  else
    return MISSING_VALUE;
}

double *segmented_curve_analysis::get_mean_h0_array(void)
{
  if(!mean_curve)
    return NULL;

  double *h0=new double[chosen_model];
  for(int i=0;i<chosen_model;i++)
    h0[i]=mean_curve->get_h0(i+1);

  return h0;
}


double segmented_curve_analysis::get_mean_hs(int seg)
{
  if(mean_curve && seg>0 && seg<chosen_model)
    return mean_curve->get_hs(seg);
  else
    return MISSING_VALUE;
}

double *segmented_curve_analysis::get_mean_hs_array(void)
{
  if(!mean_curve || chosen_model<=1)
    return NULL;
  
  double *hs=new double[chosen_model];
  for(int i=0;i<(chosen_model-1);i++)
    hs[i]=mean_curve->get_hs(i+1);

  return hs;
}

double segmented_curve_analysis::get_mean_sigma_squared(void)
{
  if(mean_curve)
    return mean_curve->get_s2();
  else
    return MISSING_VALUE;
}

double segmented_curve_analysis::get_mean_sigma(void)
{
  if(mean_curve)
    return sqrt(mean_curve->get_s2());
  else
    return MISSING_VALUE;
}

segmented_curve *segmented_curve_analysis::get_mean_curve(void)
{
  return mean_curve;
}


/* num_seg=1 gives the constant from all models */
double *segmented_curve_analysis::get_a_samples(int *len, int num_seg) 
{
  if(num_seg>max_seg) // num-seg<0 is interpreted as 'all models'
    {
      *len=0;
      return NULL;
    }
  
  *len=num_mcmc;

  double *a=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    {
      if(num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;

	  if(mod<=max_seg)
	    a[i]=samples[mod-1][i]->get_a();
	  else
	    a[i]=MISSING_VALUE;
	}
      else
	a[i]=samples[num_seg-1][i]->get_a();
    }

  return a;
}


double *segmented_curve_analysis::get_higher_a_samples(int *len, int num_seg, 
						       int seg)
{
  if(num_seg<0 || num_seg>max_seg || seg>num_seg || seg<1)
    {
      *len=0;
      return NULL;
    }

  *len=num_mcmc;

  double *a=new double[*len];
  int i,l;

  for(i=0;i<num_mcmc;i++)
    {
      a[i]=samples[num_seg-1][i]->get_a();
      for(l=2;l<=seg;l++)
	{
	  double b1=samples[num_seg-1][i]->get_b(l-1);
	  double b2=samples[num_seg-1][i]->get_b(l);
	  double h01=samples[num_seg-1][i]->get_h0(l-1);
	  double h02=samples[num_seg-1][i]->get_h0(l);
	  double hs=samples[num_seg-1][i]->get_hs(l-1);

	  a[i] += b1*log(hs-h01)-b2*log(hs-h02);
	}
    }
  
  return a;
}

double *segmented_curve_analysis::get_b_samples(int *len, int num_seg, 
						int seg)
{
  if(num_seg<0 || num_seg>max_seg || seg>num_seg || seg<1)
    {
      *len=0;
      return NULL;
    }

  *len=num_mcmc;

  double *b=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    b[i]=samples[num_seg-1][i]->get_b(seg);
  
  return b;
}


double *segmented_curve_analysis::get_h0_samples(int *len, int num_seg, 
						 int seg)
{
  if(num_seg<=0 || num_seg>max_seg || seg>num_seg || seg<1)
    {
      *len=0;
      return NULL;
    }

  *len=num_mcmc;;

  double *h0=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    h0[i]=samples[num_seg-1][i]->get_h0(seg);
  
  return h0;
}


/* num_seg=1 gives the constant from all models */
double *segmented_curve_analysis::get_h01_samples(int *len, int num_seg) 
{
  if(num_seg>max_seg) // num-seg<0 is interpreted as 'all models'
    {
      *len=0;
      return NULL;
    }

  *len=num_mcmc;

  double *h01=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    {
      if(num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;

	  if(mod<=max_seg)
	    h01[i]=samples[mod-1][i]->get_h0(1);
	  else
	    h01[i]=MISSING_VALUE;
	}
      else
	h01[i]=samples[num_seg-1][i]->get_h0(1);
    }

  return h01;
}

double *segmented_curve_analysis::get_hs_samples(int *len, int num_seg, 
						 int seg)
{
  if(num_seg<=1 || num_seg>max_seg || seg>=num_seg || seg<1)
    {
      *len=0;
      return NULL;
    }

  *len=num_mcmc;

  double *hs=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    hs[i]=samples[num_seg-1][i]->get_hs(seg);
  
  return hs;
}


/* num_seg=1 gives the constant from all models */
double *segmented_curve_analysis::get_s2_samples(int *len, int num_seg) 
{
  if(num_seg>max_seg)
    {
      *len=0;
      return NULL;
    }
  
  *len=num_mcmc;

  double *s2=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    {
      if(num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;

	  if(mod<=max_seg)
	    s2[i]=samples[mod-1][i]->get_s2();
	  else
	    s2[i]=MISSING_VALUE;
	}
      else
	s2[i]=samples[num_seg-1][i]->get_s2();
    }

  return s2;
}


/* num_seg=1 gives the constant from all models */
double *segmented_curve_analysis::get_s_samples(int *len, int num_seg) 
{
  if(num_seg>max_seg)
    {
      *len=0;
      return NULL;
    }

  *len=num_mcmc;

  double *s=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    {
      if(num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    s[i]=samples[mod-1][i]->get_s();
	  else
	    s[i]=MISSING_VALUE;
	}
      else
	s[i]=samples[num_seg-1][i]->get_s();
    }

  return s;
}

/* num_seg=1 gives the constant from all models */
double *segmented_curve_analysis::get_logprob_samples(int *len, int num_seg) 
{
  if(num_seg>max_seg)
    {
      *len=0;
      return NULL;
    }

  *len=num_mcmc;

  double *lp=new double[*len];
  int i;
  for(i=0;i<num_mcmc;i++)
    {
      if(num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    lp[i]=samples[mod-1][i]->get_log_probability_density();
	  else
	    lp[i]=MISSING_VALUE;
	}
      else
	lp[i]=samples[num_seg-1][i]->get_log_probability_density();
    }

  return lp;
}

segmented_curve ***segmented_curve_analysis::get_curves(void)
{
  return samples;
}

segmented_curve **segmented_curve_analysis::
get_curves_for_model(int model_num_seg)
{
  return samples[model_num_seg-1];
}


int segmented_curve_analysis::number_of_mcmc_simulations(void)
{
  return num_mcmc;
}

int segmented_curve_analysis::number_of_importance_samples(void)
{
  return num_imp;
}

int segmented_curve_analysis::get_spacing(void)
{
  return indep;
}


// Extrapolation inference:
int segmented_curve_analysis::get_num_extrapolated(void)
{
  if(num_extrapolated<=0 || !extrapolated_samples)
    return 0;
  else
    return num_extrapolated;
}

double *segmented_curve_analysis::get_extrapolation_discharge(double stage)
{
  if(get_num_extrapolated()<=0)
    return NULL;
  
  double *dis=new double[num_extrapolated];
  for(int i=0;i<num_extrapolated;i++)
    {
      dis[i]=extrapolated_samples[i]->get_discharge(stage);
      if(!(dis[i] > -1e+200 && dis[i] < 1e+200))
	{
	  extrapolated_samples[i]->print();
	  std::cout << stage << " " << 
	    extrapolated_samples[i]->get_discharge(stage) << std::endl;
	}
    }
  
  return dis;
}

double *segmented_curve_analysis::
get_extrapolation_discharge_prediction(double stage)
{
  if(get_num_extrapolated()<=0)
    return NULL;
  
  double *dis=new double[num_extrapolated];
  for(int i=0;i<num_extrapolated;i++)
    {
      dis[i]=extrapolated_samples[i]->get_discharge(stage)*
	exp(extrapolated_samples[i]->get_sigma()*gauss());
      if(!(dis[i] > -1e+200 && dis[i] < 1e+200))
	{
	  extrapolated_samples[i]->print();
	  std::cout << stage << " " << 
	    extrapolated_samples[i]->get_discharge(stage) << std::endl;
	}
    }
  
  return dis;
}

double *segmented_curve_analysis::get_extrapolation_stage(double discharge)
{
  if(get_num_extrapolated()<=0)
    return NULL;
  
  double *stage=new double[num_extrapolated];
  for(int i=0;i<num_extrapolated;i++)
    stage[i]=extrapolated_samples[i]->get_stage(discharge);
  return stage;
}

double segmented_curve_analysis::
get_median_extrapolation_discharge(double stage)
{
  if(get_num_extrapolated()<=0)
    return MISSING_VALUE;
  
  double *dis=get_extrapolation_discharge(stage);
  double ret=find_statistics(dis, num_extrapolated, MEDIAN);
  delete [] dis;
  
  return ret;
}

double segmented_curve_analysis::
get_median_extrapolation_stage(double discharge)
{
  if(get_num_extrapolated()<=0)
    return MISSING_VALUE;
  
  double *stage=get_extrapolation_stage(discharge);
  double ret=find_statistics(stage, num_extrapolated, MEDIAN);
  delete [] stage;
  
  return ret;
}

double segmented_curve_analysis::
get_mean_extrapolation_discharge(double stage)
{
  if(get_num_extrapolated()<=0)
    return MISSING_VALUE;
  
  double *dis=get_extrapolation_discharge(stage);
  double ret=find_statistics(dis, num_extrapolated, MEAN);
  delete [] dis;
  
  return ret;
}

double segmented_curve_analysis::
get_mean_extrapolation_stage(double discharge)
{
  if(get_num_extrapolated()<=0)
    return MISSING_VALUE;
  
  double *stage=get_extrapolation_stage(discharge);
  double ret=find_statistics(stage, num_extrapolated, MEAN);
  delete [] stage;
  
  return ret;
}

double segmented_curve_analysis::
get_discharge_extrapolation_quantile(double stage, double percent)
{
  if(get_num_extrapolated()<=0)
    return MISSING_VALUE;
  
  double *dis=get_extrapolation_discharge(stage);
  double ret=find_percentile(dis, num_extrapolated, percent/100.0);
  delete [] dis;
  
  return ret;
}

double segmented_curve_analysis::
get_discharge_prediction_extrapolation_quantile(double stage, double percent)
{
  if(get_num_extrapolated()<=0)
    return MISSING_VALUE;
  
  double *dis=get_extrapolation_discharge_prediction(stage);
  double ret=find_percentile(dis, num_extrapolated, percent/100.0);
  delete [] dis;
  
  return ret;
}

double segmented_curve_analysis::
get_stage_extrapolation_quantile(double discharge, double percent)
{
  if(get_num_extrapolated()<=0)
    return MISSING_VALUE;
  
  double *stage=get_extrapolation_stage(discharge);
  double ret=find_percentile(stage, num_extrapolated, percent/100.0);
  delete [] stage;
  
  return ret;
}

int segmented_curve_analysis::min_extrapolation_num_seg(void)
{
  if(get_num_extrapolated()<=0)
    return (int) MISSING_VALUE;
  return extrapolated_minseg;
}

int segmented_curve_analysis::max_extrapolation_num_seg(void)
{
  if(get_num_extrapolated()<=0)
    return (int) MISSING_VALUE;
  return extrapolated_maxseg;
}

double segmented_curve_analysis::prob_extrapolation_num_seg(int num_seg)
{
  if(get_num_extrapolated()<=0 || num_seg<=0 || num_seg>extrapolated_maxseg)
    return MISSING_VALUE;
  return extrapolated_prob_mod[num_seg-1];
}

double segmented_curve_analysis::
cumulative_prob_extrapolation_num_seg(int num_seg)
{
  if(get_num_extrapolated()<=0 || num_seg<=0 || num_seg>extrapolated_maxseg)
    return MISSING_VALUE;
  return extrapolated_cumulative_prob_mod[num_seg-1];
}

double *segmented_curve_analysis::get_lambda(void)
{
  if(get_num_extrapolated()<=0)
    return NULL;
  return lambda; 
}

segmented_curve **segmented_curve_analysis::get_extrapolation_curves(void)
{
  if(get_num_extrapolated()<=0)
    return NULL;
  return extrapolated_samples;
}




double segmented_curve_analysis::get_median_discharge(double stage, 
						      int model_num_seg)
{
  double *Q=new double[num_mcmc];
  for(int i=0;i<num_mcmc;i++)
    {
      if(model_num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    Q[i]=samples[mod-1][i]->get_discharge(stage);
	  else
	    Q[i]=MISSING_VALUE;
	}
      else
	Q[i]=samples[model_num_seg-1][i]->get_discharge(stage);
    }

  double med_Q=find_statistics(Q, num_mcmc, MEDIAN);

  delete [] Q;

  return med_Q;
}


double segmented_curve_analysis::get_median_stage(double discharge, 
						  int model_num_seg)
{
  double *h=new double[num_mcmc];
  for(int i=0;i<num_mcmc;i++)  
    {
      if(model_num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    h[i]=samples[mod-1][i]->get_stage(discharge);
	  else
	    h[i]=MISSING_VALUE;
	}
      else
	h[i]=samples[model_num_seg-1][i]->get_stage(discharge);
    }
 
  double med_h=find_statistics(h, num_mcmc, MEDIAN);

  delete [] h;

  return med_h;
}


double segmented_curve_analysis::get_discharge_quantile(double stage, 
							double percent, 
							int model_num_seg)
{
  if(num_mcmc<=0)
    return MISSING_VALUE;
  static int first=1;
  if(first && num_mcmc>1000000)
    {
      std::cerr << "Extreme number of MCMC samples:" << num_mcmc << "!" << std::endl;
      first=0;
    }
  
  double *Q=new double[num_mcmc];
  for(int i=0;i<num_mcmc;i++)
    {
      if(model_num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    Q[i]=samples[mod-1][i]->get_discharge(stage);
	  else
	    Q[i]=MISSING_VALUE;
	}
      else
	Q[i]=samples[model_num_seg-1][i]->get_discharge(stage);
    }
 
  double quantile_Q=find_percentile(Q, num_mcmc, percent/100.0);

  delete [] Q;

  return quantile_Q;
}


double segmented_curve_analysis::get_stage_quantile(double discharge, 
						    double percent, 
						    int model_num_seg)
{
  double *h=new double[num_mcmc];
  for(int i=0;i<num_mcmc;i++)
    {
      if(model_num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    h[i]=samples[mod-1][i]->get_stage(discharge);
	  else
	    h[i]=MISSING_VALUE;
	}
      else
	h[i]=samples[model_num_seg-1][i]->get_stage(discharge);
    }
 
  double quantile_h=find_percentile(h, num_mcmc, percent/100.0);

  delete [] h;

  return quantile_h;
}


double segmented_curve_analysis::get_mean_discharge(double stage, 
						    int /* model_num_seg */)
{
  double Qtot=0.0;
  for(int l=(min_seg-1);l<max_seg;l++)
    for(int i=0;i<num_mcmc;i++)
      Qtot+=prob_mod[l]*samples[l][i]->get_discharge(stage); 

  double mean_Q=Qtot/double(num_mcmc);

  return mean_Q;
}


double segmented_curve_analysis::get_mean_stage(double discharge, 
						int /* model_num_seg */)
{
  double htot=0.0;
  for(int l=(min_seg-1);l<max_seg;l++)
    for(int i=0;i<num_mcmc;i++)
      htot+=prob_mod[l]*samples[l][i]->get_stage(discharge);
 
  double mean_h=htot/double(num_mcmc);

  return mean_h;
}

double segmented_curve_analysis::get_sdev_discharge(double stage, 
						    int /* model_num_seg */)
{
  double *Q_samp=get_discharge_samples(stage);
  double sdev_Q=find_statistics(Q_samp, num_mcmc, STANDARD_DEVIATION);
  
  delete [] Q_samp;
  
  return sdev_Q;
}


double segmented_curve_analysis::get_sdev_stage(double discharge, 
						int /* model_num_seg */)
{
  double *h_samp=get_stage_samples(discharge);
  double sdev_h=find_statistics(h_samp, num_mcmc, STANDARD_DEVIATION);
  
  delete [] h_samp;
  
  return sdev_h;
}

double *segmented_curve_analysis::get_discharge_samples(double stage, 
							int model_num_seg)
{
  double *Q=new double[num_mcmc];
  for(int i=0;i<num_mcmc;i++) 
    {
      if(model_num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    Q[i]=samples[mod-1][i]->get_discharge(stage);
	  else
	    Q[i]=MISSING_VALUE;
	}
      else
	Q[i]=samples[model_num_seg-1][i]->get_discharge(stage);
    }
 
  return Q;
}

// effect of the curve uncertainty on the mean stage given a
// set of stage values that are transformed into discharge,
// averaged and transformed back to stage.
double segmented_curve_analysis::get_mean_stage_quantile(double *stages, 
							 int len, 
							 double percent,
							 int simlen)
{
  double *h=new double[simlen];
  for(int i=0;i<simlen;i++) 
    {
      int mod,l;
      double r=drand48();
      int index=(int) floor(drand48()*double(num_mcmc));

      for(l=(min_seg-1);l<max_seg;l++)
	if(r<cumulative_prob_mod[l])
	  break;
      mod=l+1;
      
      if(mod<=max_seg)
	{
	  double *Q_curr=new double[len];
	  for(int j=0;j<len;j++)
	    Q_curr[j]=samples[mod-1][index]->get_discharge(stages[j]);
	  double Q=find_statistics(Q_curr,len,MEAN);
	  delete [] Q_curr;
	  
	  h[i]=samples[mod-1][index]->get_stage(Q);
	}
      else
	h[i]=MISSING_VALUE;
    }
 
  double quantile_h=find_percentile(h, simlen, percent/100.0);
  
  delete [] h;

  return quantile_h;
}

double *segmented_curve_analysis::get_stage_samples(double discharge, 
						    int model_num_seg)
{
  double *h=new double[num_mcmc];
  for(int i=0;i<num_mcmc;i++)
    {
      if(model_num_seg<0)
	{
	  int mod,l;
	  double r=drand48();
	  for(l=(min_seg-1);l<max_seg;l++)
	    if(r<cumulative_prob_mod[l])
	      break;
	  mod=l+1;
	  
	  if(mod<=max_seg)
	    h[i]=samples[mod-1][i]->get_stage(discharge);
	  else
	    h[i]=MISSING_VALUE;
	}
      else
	h[i]=samples[model_num_seg-1][i]->get_stage(discharge);
    }
  
  return h;
}

// creates a table of stage values with lower 2.5%, median and upper 97.5% 
// quantiles. Returns false, if this didnt go well because
// of minimal h0 being larger than max_stage.
bool segmented_curve_analysis::make_credibility_bands(double max_stage)
{
  int len, i;
  double *h01s=get_h01_samples(&len);

  hmin_table=find_statistics(h01s,len,MIN);
  hmax_table=max_stage;

  h_step=0.01;
  h_table_len=(int) ceil((hmax_table-hmin_table)/h_step);
  
  if(h_table_len<2)
    return false;

  if(h_table)
    delete [] h_table;
  h_table=new double[h_table_len];
  if(lower_q_table)
    delete [] lower_q_table;
  lower_q_table=new double[h_table_len];
  if(median_q_table)
    delete [] median_q_table;
  median_q_table=new double[h_table_len];
  if(upper_q_table)
    delete [] upper_q_table;
  upper_q_table=new double[h_table_len];

  /* DEBUG options: a graph of the tables:
  FILE *p=popen("vvgraph -x h -y Q","w");
  fprintf(p, "# Column 1: median\n");
  fprintf(p, "# Column 2: lower\n");
  fprintf(p, "# Column 3: upper\n");
  fprintf(p, "######################\n");
  */
  double h=hmin_table;
  for(i=0;i<h_table_len;i++)
    {
      h_table[i]=h;
      if(num_extrapolated<=0 || !extrapolated_samples)
	{
	  lower_q_table[i]=get_discharge_quantile(h, 2.5);
	  median_q_table[i]=get_discharge_quantile(h, 50.0);
	  upper_q_table[i]=get_discharge_quantile(h, 97.5);
	}
      else
	{
	  lower_q_table[i]=get_discharge_extrapolation_quantile(h, 2.5);
	  median_q_table[i]=get_discharge_extrapolation_quantile(h, 50.0);
	  upper_q_table[i]=get_discharge_extrapolation_quantile(h, 97.5);
	}
      /* DEBUG graph command:
      fprintf(p, "%f %f %f %f\n", h_table[i],median_q_table[i],
	      lower_q_table[i],upper_q_table[i]);
      */
      h+=h_step;
    }
  /* DEBUG close graph
  pclose(p);
  */


  qmin_table=0.0;
  qmax_table=get_discharge_quantile(hmax_table, 97.5);
  
  q_table_len=300;
  q_step=(qmax_table-qmin_table)/double(q_table_len);

  if(q_table)
    delete [] q_table;
  q_table=new double[q_table_len];
  if(lower_h_table)
    delete [] lower_h_table;
  lower_h_table=new double[q_table_len];
  if(median_h_table)
    delete [] median_h_table;
  median_h_table=new double[q_table_len];
  if(upper_h_table)
    delete [] upper_h_table;
  upper_h_table=new double[q_table_len];
  
  double q=qmin_table;
  for(i=0;i<q_table_len;i++)
    {
      q_table[i]=q;
      if(num_extrapolated<=0 || !extrapolated_samples)
	{
	  lower_h_table[i]=get_stage_quantile(q, 2.5);
	  median_h_table[i]=get_stage_quantile(q, 50.0);
	  upper_h_table[i]=get_stage_quantile(q, 97.5);
	}
      else
	{
	  lower_h_table[i]=get_stage_extrapolation_quantile(q, 2.5);
	  median_h_table[i]=get_stage_extrapolation_quantile(q, 50.0);
	  upper_h_table[i]=get_stage_extrapolation_quantile(q, 97.5);
	}

      q+=q_step;
    }

  return true;
}

double segmented_curve_analysis::get_lower_discharge_band(double stage)
{
  int index=(int) floor((stage-hmin_table)/(hmax_table-hmin_table)*
			double(h_table_len));
  if(index<0 || index>=h_table_len)
    return MISSING_VALUE;
  if(index==(h_table_len-1))
    return lower_q_table[index];
  
  double step=stage-h_table[index];
  double q_lower=(1.0-step/h_step)*lower_q_table[index]+
    (step/h_step)*lower_q_table[index+1];
  
  return q_lower;
}

double segmented_curve_analysis::get_median_discharge_band(double stage)
{
  int index=(int) floor((stage-hmin_table)/(hmax_table-hmin_table)*
			double(h_table_len));
  if(index<0 || index>=h_table_len)
    return MISSING_VALUE;
  if(index==(h_table_len-1))
    return median_q_table[index];
  
  double step=stage-h_table[index];
  double q_median=(1.0-step/h_step)*median_q_table[index]+
    (step/h_step)*median_q_table[index+1];
  
  return q_median;
}

double segmented_curve_analysis::get_upper_discharge_band(double stage)
{
  int index=(int) floor((stage-hmin_table)/(hmax_table-hmin_table)*
			double(h_table_len));
  if(index<0 || index>=h_table_len)
    return MISSING_VALUE;
  if(index==(h_table_len-1))
    return upper_q_table[index];
  
  double step=stage-h_table[index];
  double q_upper=(1.0-step/h_step)*upper_q_table[index]+
    (step/h_step)*upper_q_table[index+1];
  
  return q_upper;
}

double segmented_curve_analysis::get_lower_stage_band(double discharge)
{
  int index=(int) floor((discharge-qmin_table)/(qmax_table-qmin_table)*
			double(q_table_len));
  if(index<0 || index>=q_table_len)
    return MISSING_VALUE;
  if(index==(q_table_len-1))
    return lower_h_table[index];
  
  double step=discharge-q_table[index];
  double h_lower=(1.0-step/q_step)*lower_h_table[index]+
    (step/q_step)*lower_h_table[index+1];
  
  return h_lower;
}

double segmented_curve_analysis::get_median_stage_band(double discharge)
{
  int index=(int) floor((discharge-qmin_table)/(qmax_table-qmin_table)*
			double(q_table_len));
  if(index<0 || index>=q_table_len)
    return MISSING_VALUE;
  if(index==(q_table_len-1))
    return median_h_table[index];
  
  double step=discharge-q_table[index];
  double h_median=(1.0-step/q_step)*median_h_table[index]+
    (step/q_step)*median_h_table[index+1];
  
  return h_median;
}

double segmented_curve_analysis::get_upper_stage_band(double discharge)
{
  int index=(int) floor((discharge-qmin_table)/(qmax_table-qmin_table)*
			double(q_table_len));
  if(index<0 || index>=q_table_len)
    return MISSING_VALUE;
  if(index==(q_table_len-1))
    return upper_h_table[index];
  
  double step=discharge-q_table[index];
  double h_upper=(1.0-step/q_step)*upper_h_table[index]+
    (step/q_step)*upper_h_table[index+1];
  
  return h_upper;
}



int segmented_curve_analysis::get_max_seg(void)
{
  return max_seg;
}

int segmented_curve_analysis::get_min_seg(void)
{
  return min_seg;
}

double segmented_curve_analysis::get_hmin(void)
{
  return hmin;
}

double segmented_curve_analysis::get_hmax(void)
{
  return hmax;
}


void segmented_curve_analysis::print(FILE *f)
{
  for(int seg=min_seg;seg<=max_seg;seg++)
    {
      fprintf(f, WHAT((char *) "%d segments modell, P(seg=%d)=%g%%\n", 
		      (char *) "%d segment model, P(seg=%d)=%g%%\n"), 
	      seg, seg, ((double) prob_mod[seg-1])*100.0);
      
      for(int i=0;i<num_mcmc;i++)
	{
	  fprintf(f, WHAT((char *) "Trekning nr. %5d: ", 
			  (char *) "Sample number %5d: "), i+1);
	  samples[seg-1][i]->print(f);
	}
      
      if(seg<max_seg)
	fprintf(f, "\n\n*****************************************\n\n");
    }
}




segmented_curve_analysis_list::
segmented_curve_analysis_list(segmented_curve_analysis_list *prev,
			      segmented_curve_analysis *orig,
			      DateTime start_time, DateTime end_time) :
  double_linked_list((double_linked_list *) prev, NULL),
  segmented_curve_analysis(orig)
{
  start=start_time;
  end=end_time;
}

segmented_curve_analysis_list *segmented_curve_analysis_list::suc(void)
{
  return (segmented_curve_analysis_list *) getnext();
}

segmented_curve_analysis_list *segmented_curve_analysis_list::
get_analysis(DateTime dt)
{
  if(dt>=start.StartOfDay() && (end==NoDateTime || dt<end.EndOfDay()))
    return this;
  else if(suc())
    return suc()->get_analysis(dt);
  else
    return NULL;
}


// Uses the analysis (including MCMC samples) to make
// extrapolated curve samples using a Poisson process model
// for segments for all analysis in this list:
void segmented_curve_analysis_list::
set_extrapolation_samples_for_all(double max_stage, int num_samples)
{
  for(segmented_curve_analysis_list *ptr=this; ptr; ptr=ptr->suc())
    ptr->set_extrapolation_samples(max_stage, num_samples);
}


DateTime segmented_curve_analysis_list::get_start_time(void)
{
  return start;
}

DateTime segmented_curve_analysis_list::get_end_time(void)
{
  return end;
}
  
void segmented_curve_analysis_list::set_start_time(DateTime new_start)
{
  start=new_start;
}

void segmented_curve_analysis_list::set_end_time(DateTime new_end)
{
  end=new_end;
}






