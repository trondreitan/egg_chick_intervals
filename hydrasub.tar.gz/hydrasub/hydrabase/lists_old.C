/*
 * $Id: lists.C 2614 2015-11-24 18:09:01Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/lists.C $
 */

#include <hydrasub/hydrabase/lists.H>

#if defined(_WIN32) || defined(_WIN64)
#define strcasecmp _stricmp
#endif

// *******************************************************
//                   DOUBLE_LINKED_LIST
// Just as the name says, a double linked list, used
// as a parent class when implementing various classes
// that needs to be linked lists.
// *******************************************************


// constructors;

// constructor
// create a period editor without surroundings
double_linked_list::double_linked_list()
{
  next=prev=NULL;
} // double_linked_list::double_linked_list


// constructor
// object that will point to the previous head of a list
double_linked_list::double_linked_list(double_linked_list *head) 
{
  next=head;
  if(head)
    head->prev=this;
  prev=NULL;
} // double_linked_list::double_linked_list


// constructor
// put the object in the middle of the list
double_linked_list::double_linked_list(double_linked_list *previtem,
				       double_linked_list *nextitem)
{
  next=nextitem;
  prev=previtem;
  
  if(prev)
    prev->next=this;

  if(next)
    next->prev=this;
} // double_linked_list::double_linked_list


// destructor
// delete recursively down a chain...
double_linked_list::~double_linked_list()
{
  if(next)
    delete next;
} // double_linked_list::~double_linked_list


  // Put a new element into a list with prev=prevelem and next=prevelem->next,
  // so that the new lsit will be prevelem->new->next
void double_linked_list::put_into(double_linked_list *prevelem)
{
  prev=prevelem;
  if(prev)
    next=prevelem->next;
  else
    next=NULL;
  if(next)
    next->prev=this;
  if(prev)
    prev->next=this;
}


//                 REMOVEFROMLIST
// removes an object from a linked list...
void double_linked_list::removefromlist(void)
{
  if(prev)
    prev->next=next;
  if(next)
    next->prev=prev;
  prev=NULL;
  next=NULL;
} // double_linked_list::removefromlist


//                 GETLAST
// Fetches the last object in a list
double_linked_list *double_linked_list::getlast(void)
{
  register double_linked_list *pt;
  for(pt=this;pt->getnext();pt=pt->getnext()); // get the last item
  return pt;
} // double_linked_list::getlast


//                 GETHEAD
// Fetches the first object in a list
double_linked_list *double_linked_list::gethead(void)
{
  register double_linked_list *pt;
  for(pt=this;pt->getprev();pt=pt->getprev()); // get the last item
  return pt;
} // double_linked_list::getlast


//             GET_REL_NEXT
// Gets the element 'num' places next to this element
double_linked_list * double_linked_list::get_rel_next(int num)
{
  register int i;
  double_linked_list *pt=this;
  for(i=1;i<=num && pt;i++)
    pt=pt->getnext();
  return pt;
}

//             GET_FROM_START
// Gets the element 'num' places next to the head of the list
double_linked_list *double_linked_list::get_from_start(int num)
{
  register int i;
  double_linked_list *pt=this->gethead();
  for(i=1;i<=num && pt;i++)
    pt=pt->getnext();
  return pt;
}


//             GET_REL_PREV
// Gets the element 'num' places previous to this element
double_linked_list *double_linked_list::get_rel_prev(int num)
{
  register int i;
  double_linked_list *pt=this;
  for(i=1;i<=num && pt;i++)
    pt=pt->getprev();
  return pt;
}

//             GET_FROM_END
// Gets the element 'num' places previous to the end of the list
double_linked_list *double_linked_list::get_from_end(int num)
{
  register int i;
  double_linked_list *pt=this->getlast();
  for(i=1;i<=num && pt;i++)
    pt=pt->getprev();
  return pt;
}

bool double_linked_list::appears_in_list(double_linked_list *elem)
{
  double_linked_list *pt=this;

  do
    {
      if(pt==elem)
	return true;
    } while((pt=pt->getnext()) != NULL);
  
  return false;
}

//                  JOIN
// append this list with the head of another...
void double_linked_list::join(double_linked_list *head2)
{
  double_linked_list  *pt=getlast();

  pt->next=head2;
  head2->prev=pt;
} // double_linked_list::join

// uses 'join'
void double_linked_list::append(double_linked_list *item)
{
  join(item);
}

// counts the number of elements following (and including) the present
int double_linked_list::number_of_elements(void)
{
  int i=0;
  for(register double_linked_list *pt=this; pt; pt=pt->getnext())
    i++;
  return i;
}

void double_linked_list::setprev(double_linked_list *item)
{
  prev=item;
  if(item)
    item->next=this;
}

void double_linked_list::setnext(double_linked_list *item)
{
  next=item;
  if(item)
    item->prev=this;
}

// Functions used for adding elements into a double_linked_list

void into_the_start(double_linked_list *new_elem,
		    double_linked_list **start)
{
  if(!*start)
    *start=new_elem;
  else
    {
      new_elem->setnext(*start);
      *start=new_elem;
    }
}

// put a single element into the tail of a list
// update the start pointer
void into_the_tail(double_linked_list *new_elem,
		   double_linked_list **start)
{
  if(!*start)
    *start=new_elem;
  else
    {
      double_linked_list *end=(*start)->getlast();
      new_elem->setprev(end);
    }
}

// put a single element into the start of a list
// update the start and end pointers
void into_the_start(double_linked_list *new_elem,
		    double_linked_list **start,
		    double_linked_list **end)
{
  if(!*start)
    *start=*end=new_elem;
  else
    {
      new_elem->setnext(*start);
      *start=new_elem;
    }
}

// put a single element into the end of a list
// update the start and end pointers
void into_the_tail(double_linked_list *new_elem,
		   double_linked_list **start,
		   double_linked_list **end)
{
  if(!*start)
    *start=*end=new_elem;
  else
    {
      new_elem->setprev(*end);
      *end=new_elem;
    }
}








stringlist::stringlist(char *string_in) : double_linked_list()
{
  strcpy(string,string_in);
}

stringlist::stringlist(stringlist *previtem, stringlist *nextitem,
		       char *string_in) : 
  double_linked_list((double_linked_list *) previtem,
		     (double_linked_list *) nextitem)
{
  strcpy(string,string_in);
}

char *stringlist::getstring(void)
{
  return string;
}

void stringlist::setstring(char *str)
{
  strcpy(string,str);
}

stringlist *stringlist::least(void)
{
  stringlist *leastptr=NULL;
  char leaststr[1000];
  for(char *strptr=leaststr;strptr<leaststr+1000;strptr++)
    *strptr=(char) 255;

  for(stringlist *ptr=this; ptr; ptr=(stringlist *)ptr->getnext())
    if(strcmp(ptr->getstring(),leaststr)<0)
      {
	strcpy(leaststr,ptr->getstring());
	leastptr=ptr;
      }

  return leastptr;
}

stringlist *stringlist::caseleast(void)
{
  stringlist *leastptr=NULL;
  char leaststr[1000];
  for(char *strptr=leaststr;strptr<leaststr+1000;strptr++)
    *strptr=(char) 255;

  for(stringlist *ptr=this; ptr; ptr=(stringlist *)ptr->getnext())
    if(strcasecmp(ptr->getstring(),leaststr)<0)
      {
	strcpy(leaststr,ptr->getstring());
	leastptr=ptr;
      }
  
  return leastptr;
}

stringlist *stringlist::most(void)
{
  stringlist *mostptr=NULL;
  char moststr[1000];
  for(char *strptr=moststr;strptr<moststr+1000;strptr++)
    *strptr=(char) 1;
  
  for(stringlist *ptr=this; ptr; ptr=(stringlist *)ptr->getnext())
    if(strcmp(ptr->getstring(),moststr)>0)
      {
	strcpy(moststr,ptr->getstring());
	mostptr=ptr;
      }

  return mostptr;
}

stringlist *stringlist::casemost(void)
{
  stringlist *mostptr=NULL;
  char moststr[1000];
  for(char *strptr=moststr;strptr<moststr+1000;strptr++)
    *strptr=(char) 0;
  
  for(stringlist *ptr=this; ptr; ptr=(stringlist *)ptr->getnext())
    if(strcasecmp(ptr->getstring(),moststr)>0)
      {
	strcpy(moststr,ptr->getstring());
	mostptr=ptr;
      }

  return mostptr;
}





valuelist::valuelist(double value_in) : double_linked_list()
{
  value=value_in;
}

valuelist::valuelist(valuelist *previtem, valuelist *nextitem,
		     double value_in) : 
  double_linked_list((double_linked_list *) previtem,
		     (double_linked_list *) nextitem)
{
  value=value_in;
}

double valuelist::getvalue(void)
{
  return value;
}

void valuelist::setvalue(double new_value)
{
  value=new_value;
}

valuelist *valuelist::least(void)
{
  valuelist *leastptr=NULL;
  double leastval=value;
  
  for(valuelist *ptr=this; ptr; ptr=(valuelist *)ptr->getnext())
    if(ptr->value < leastval)
      {
	leastval=ptr->value;
	leastptr=ptr;
      }

  return leastptr;
}

valuelist *valuelist::most(void)
{
  valuelist *mostptr=NULL;
  double mostval=value;
  
  for(valuelist *ptr=this; ptr; ptr=(valuelist *)ptr->getnext())
    if(ptr->value < mostval)
      {
	mostval=ptr->value;
	mostptr=ptr;
      }

  return mostptr;
}

valuelist *valuelist::suc(void)
{
  return (valuelist *) getnext();
}

double *valuelist::getarray(int &size)
{
  size=number_of_elements();
  double *ret=new double[size];

  int i=0;
  for(valuelist *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->value;
      
  return ret;
}


valuelist *get_value_file(char *filename)
{
  ifstream in;
  char line[10000];
  valuelist *head=NULL, *tail=NULL;

  in.open(filename, ios::in);
  if(in.fail())
    {
      cerr << "Could not open the file " << filename << "!" << endl;
      return NULL;
    }
  
  in.getline(line,9999);
  while(!in.eof())
    {
      double val;

      if(line[0]!='#' && sscanf(line,"%lf",&val)==1)
	{
	  tail=new valuelist(tail,NULL,val);
	  if(!head)
	    head=tail;
	}
      
      in.getline(line,9999);
    }
  in.close();

  if(!head)
    cerr << "Could not find any value content in the file " << 
      filename << endl;

  return head;
}


timeserielist::timeserielist(DateTime time_in, double value_in) : 
  double_linked_list()
{
  dt=time_in;
  value=value_in;
}

timeserielist::timeserielist(timeserielist *previtem, timeserielist *nextitem,
			     DateTime time_in, double value_in) : 
  double_linked_list((double_linked_list *) previtem,
		     (double_linked_list *) nextitem)
{
  dt=time_in;
  value=value_in;
}

double timeserielist::getvalue(void)
{
  return value;
}

DateTime timeserielist::gettime(void)
{
  return dt;
}

void timeserielist::setvalue(double new_value)
{
  value=new_value;
}

void timeserielist::settime(DateTime new_time)
{
  dt=new_time;
}

timeserielist *timeserielist::suc(void)
{
  return (timeserielist *) getnext();
}

double *timeserielist::getvaluearray(int &size)
{
  size=number_of_elements();
  double *ret=new double[size];

  int i=0;
  for(timeserielist *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->value;
      
  return ret;
}


DateTime *timeserielist::gettimearray(int &size)
{
  size=number_of_elements();
  DateTime *ret=new DateTime[size];

  int i=0;
  for(timeserielist *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->dt;
      
  return ret;
}


timeserielist *get_timeserie_file(char *filename)
{
  ifstream in;
  char line[10000];
  timeserielist *head=NULL, *tail=NULL;

  in.open(filename, ios::in);
  if(in.fail())
    {
      cerr << "Could not open the file " << filename << "!" << endl;
      return NULL;
    }
  
  in.getline(line,9999);
  while(!in.eof())
    {
      int yr,mnd,day,h,m;
      double val;

      if(sscanf(line,"%04d%02d%02d/%02d%02d %lf", 
		&yr, &mnd, &day, &h, &m, &val)==6)
	{
	  DateTime dt(yr,mnd,day,h,m);
	  
	  tail=new timeserielist(tail,NULL,dt,val);
	  if(!head)
	    head=tail;
	}
      else if(sscanf(line,"%02d/%02d/%04d %02d:%02d %lf", 
		     &day, &mnd, &yr, &h, &m, &val)==6)
	{
	  DateTime dt(yr,mnd,day,h,m);
	  
	  tail=new timeserielist(tail,NULL,dt,val);
	  if(!head)
	    head=tail;
	}
      else if(sscanf(line,"%02d/%02d/%04d %lf", 
		     &day, &mnd, &yr, &val)==4)
	{
	  DateTime dt(yr,mnd,day,12,00);
	  
	  tail=new timeserielist(tail,NULL,dt,val);
	  if(!head)
	    head=tail;
	}

      in.getline(line,9999);
    }
  in.close();

  if(!head)
    cerr << "Could not find any timeserie content in the file " << 
      filename << endl;

  return head;
}

timeserielist_2d::timeserielist_2d(DateTime time_in, double value_1, double value_2) : 
  double_linked_list()
{
  dt=time_in;
  value1=value_1;
  value2=value_2;
}

timeserielist_2d::timeserielist_2d(timeserielist_2d *previtem, 
				   timeserielist_2d *nextitem,
				   DateTime time_in, double value_1, double value_2) : 
  double_linked_list((double_linked_list *) previtem,
		     (double_linked_list *) nextitem)
{
  dt=time_in;
  value1=value_1;
  value2=value_2;
}

double timeserielist_2d::getvalue1(void)
{
  return value1;
}

double timeserielist_2d::getvalue2(void)
{
  return value2;
}

DateTime timeserielist_2d::gettime(void)
{
  return dt;
}

void timeserielist_2d::setvalue1(double new_value1)
{
  value1=new_value1;
}

void timeserielist_2d::setvalue2(double new_value2)
{
  value2=new_value2;
}

void timeserielist_2d::settime(DateTime new_time)
{
  dt=new_time;
}

timeserielist_2d *timeserielist_2d::suc(void)
{
  return (timeserielist_2d *) getnext();
}

double *timeserielist_2d::getvalue1array(int &size)
{
  size=number_of_elements();
  double *ret=new double[size];

  int i=0;
  for(timeserielist_2d *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->value1;
      
  return ret;
}

double *timeserielist_2d::getvalue2array(int &size)
{
  size=number_of_elements();
  double *ret=new double[size];

  int i=0;
  for(timeserielist_2d *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->value2;
      
  return ret;
}


DateTime *timeserielist_2d::gettimearray(int &size)
{
  size=number_of_elements();
  DateTime *ret=new DateTime[size];

  int i=0;
  for(timeserielist_2d *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->dt;
      
  return ret;
}


timeserielist_2d *get_timeserie_2d_file(char *filename)
{
  ifstream in;
  char line[10000];
  timeserielist_2d *head=NULL, *tail=NULL;

  in.open(filename, ios::in);
  if(in.fail())
    {
      cerr << "Could not open the file " << filename << "!" << endl;
      return NULL;
    }
  
  in.getline(line,9999);
  while(!in.eof())
    {
      int yr,mnd,day,h,m;
      double val1, val2;

      if(sscanf(line,"%04d%02d%02d/%02d%02d %lf %lf", 
		&yr, &mnd, &day, &h, &m, &val1, &val2)==7)
	{
	  DateTime dt(yr,mnd,day,h,m);
	  
	  tail=new timeserielist_2d(tail,NULL,dt,val1, val2);
	  if(!head)
	    head=tail;
	}
      else if(sscanf(line,"%02d/%02d/%04d %lf %lf", 
		     &day, &mnd, &yr, &val1, &val2)==5)
	{
	  DateTime dt(yr,mnd,day,12,00);
	  
	  tail=new timeserielist_2d(tail,NULL,dt,val1,val2);
	  if(!head)
	    head=tail;
	}
      else if(sscanf(line,"%02d/%02d/%04d %02d:%02d %lf %lf", 
		     &day, &mnd, &yr, &h, &m, &val1, &val2)==7)
	{
	  DateTime dt(yr,mnd,day,h,m);
	  
	  tail=new timeserielist_2d(tail,NULL,dt,val1,val2);
	  if(!head)
	    head=tail;
	}

      in.getline(line,9999);
    }
  in.close();

  if(!head)
    cerr << "Could not find any timeserie_2d content in the file " << 
      filename << endl;

  return head;
}


intlist::intlist(int value_in) : double_linked_list()
{
  value=value_in;
}

intlist::intlist(intlist *previtem, intlist *nextitem,
		 int value_in) : 
  double_linked_list((double_linked_list *) previtem,
		     (double_linked_list *) nextitem)
{
  value=value_in;
}

int intlist::getvalue(void)
{
  return value;
}

void intlist::setvalue(int new_value)
{
  value=new_value;
}

intlist *intlist::least(void)
{
  intlist *leastptr=NULL;
  int leastval=value;
  
  for(intlist *ptr=this; ptr; ptr=(intlist *)ptr->getnext())
    if(ptr->value < leastval)
      {
	leastval=ptr->value;
	leastptr=ptr;
      }

  return leastptr;
}

intlist *intlist::most(void)
{
  intlist *mostptr=NULL;
  int mostval=value;
  
  for(intlist *ptr=this; ptr; ptr=(intlist *)ptr->getnext())
    if(ptr->value < mostval)
      {
	mostval=ptr->value;
	mostptr=ptr;
      }

  return mostptr;
}

bool intlist::contains(int number)
{
  for(intlist *ptr=this; ptr; ptr=(intlist *)ptr->getnext())
    if(ptr->value==number)
      return true;
  return false;
}

int *intlist::getarray(int &size)
{
  size=number_of_elements();
  int *ret=new int[size];

  int i=0;
  for(intlist *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->value;
      
  return ret;
}

intlist *intlist::suc(void)
{
  return (intlist *) getnext();
}


longintlist::longintlist(long int value_in) : double_linked_list()
{
  value=value_in;
}

longintlist::longintlist(longintlist *previtem, longintlist *nextitem,
		 long int value_in) : 
  double_linked_list((double_linked_list *) previtem,
		     (double_linked_list *) nextitem)
{
  value=value_in;
}

long int longintlist::getvalue(void)
{
  return value;
}

void longintlist::setvalue(long int new_value)
{
  value=new_value;
}

longintlist *longintlist::least(void)
{
  longintlist *leastptr=NULL;
  long int leastval=value;
  
  for(longintlist *ptr=this; ptr; ptr=(longintlist *)ptr->getnext())
    if(ptr->value < leastval)
      {
	leastval=ptr->value;
	leastptr=ptr;
      }

  return leastptr;
}

longintlist *longintlist::most(void)
{
  longintlist *mostptr=NULL;
  long int mostval=value;
  
  for(longintlist *ptr=this; ptr; ptr=(longintlist *)ptr->getnext())
    if(ptr->value < mostval)
      {
	mostval=ptr->value;
	mostptr=ptr;
      }

  return mostptr;
}

bool longintlist::contains(long int number)
{
  for(longintlist *ptr=this; ptr; ptr=(longintlist *)ptr->getnext())
    if(ptr->value==number)
      return true;
  return false;
}

long int *longintlist::getarray(int &size)
{
  size=number_of_elements();
  long int *ret=new long int[size];

  int i=0;
  for(longintlist *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->value;
      
  return ret;
}

longintlist *longintlist::suc(void)
{
  return (longintlist *) getnext();
}

// Makes an ordered list out of the list starting with 'head'
// Deletes that list in the process.
stringlist *order_stringlist(stringlist *head,ORDER_SCHEME type)
{
  stringlist *newhead=NULL,*newtail=NULL;

  while(head)
    {
      stringlist *leastptr = NULL;

      switch(type)
	{
	case ORDER_LEAST:
	  leastptr=head->least();
	  break;
	case ORDER_CASELEAST:
	  leastptr=head->caseleast();
	  break;
	  case ORDER_MOST:
	  leastptr=head->most();
	  break;
	case ORDER_CASEMOST:
	  leastptr=head->casemost();
	  break;
	}

      if(leastptr==head)
	head=(stringlist *) head->getnext();
      
      leastptr->removefromlist();
      
      if(!newhead)
	newhead=newtail=new stringlist(leastptr->getstring());
      else
	newtail=new stringlist(newtail,NULL,leastptr->getstring());

      delete leastptr;
    }

  return newhead;
}

// Makes an ordered list out of the list starting with 'head'
// Deletes that list in the process.
intlist *order_intlist(intlist *head,ORDER_SCHEME type)
{
  intlist *newhead=NULL,*newtail=NULL;

  while(head)
    {
      intlist *leastptr = NULL;

      switch(type)
	{
	case ORDER_LEAST:
	  leastptr=head->least();
	  break;
	case ORDER_MOST:
	  leastptr=head->most();
	  break;
	default:
	  break;
	}

      if(leastptr==head)
	head=(intlist *) head->getnext();
      
      leastptr->removefromlist();
      
      if(!newhead)
	newhead=newtail=new intlist(leastptr->getvalue());
      else
	newtail=new intlist(newtail,NULL,leastptr->getvalue());
      
      delete leastptr;
    }

  return newhead;
}

// Makes an ordered list out of the list starting with 'head'
// Deletes that list in the process.
longintlist *order_longintlist(longintlist *head,ORDER_SCHEME type)
{
  longintlist *newhead=NULL,*newtail=NULL;

  while(head)
    {
      longintlist *leastptr = NULL;

      switch(type)
	{
	case ORDER_LEAST:
	  leastptr=head->least();
	  break;
	case ORDER_MOST:
	  leastptr=head->most();
	  break;
	default:
	  break;
	}

      if(leastptr==head)
	head=(longintlist *) head->getnext();
      
      leastptr->removefromlist();
      
      if(!newhead)
	newhead=newtail=new longintlist(leastptr->getvalue());
      else
	newtail=new longintlist(newtail,NULL,leastptr->getvalue());
      
      delete leastptr;
    }

  return newhead;
}


// Makes an ordered list out of the list starting with 'head'
// Deletes that list in the process.
valuelist *order_valuelist(valuelist *head,ORDER_SCHEME type)
{
  valuelist *newhead=NULL,*newtail=NULL;

  while(head)
    {
      valuelist *leastptr = NULL;

      switch(type)
	{
	case ORDER_LEAST:
	  leastptr=head->least();
	  break;
	case ORDER_MOST:
	  leastptr=head->most();
	  break;
	default:
	  break;
	}

      if(leastptr==head)
	head=(valuelist *) head->getnext();
      
      leastptr->removefromlist();
      
      if(!newhead)
	newhead=newtail=new valuelist(leastptr->getvalue());
      else
	newtail=new valuelist(newtail,NULL,leastptr->getvalue());
      
      delete leastptr;
    }

  return newhead;
}

timelist::timelist(DateTime dt_in) : double_linked_list()
{
  dt=dt_in;
}

timelist::timelist(timelist *previtem, timelist *nextitem, DateTime dt_in)  : 
  double_linked_list((double_linked_list *) previtem,
		     (double_linked_list *) nextitem)
{
  dt=dt_in;
}

DateTime timelist::gettime(void)
{
  return dt;
}

void timelist::settime(DateTime new_time)
{
  dt=new_time;
}

timelist *timelist::least(void)
{
  timelist *leastptr=NULL;
  DateTime leasttime=dt;
  
  for(timelist *ptr=this; ptr; ptr=ptr->suc())
    if(ptr->dt < leasttime)
      {
	leasttime=ptr->dt;
	leastptr=ptr;
      }

  return leastptr;
}

timelist *timelist::most(void)
{
  timelist *mostptr=NULL;
  DateTime mosttime=dt;
  
  for(timelist *ptr=this; ptr; ptr=ptr->suc())
    if(ptr->dt > mosttime)
      {
	mosttime=ptr->dt;
	mostptr=ptr;
      }

  return mostptr;
}

timelist *timelist::suc(void)
{
  return (timelist *) getnext();
}

bool timelist::contains(DateTime checktime)
{
  for(timelist *ptr=this; ptr; ptr=ptr->suc())
    if(ptr->dt==checktime)
      return true;
  return false;
}

DateTime *timelist::getarray(int &size)
{
  size=number_of_elements();
  DateTime *dtimes=new DateTime[size];

  int i=0;
  for(timelist *ptr=this; ptr; ptr=ptr->suc())
    dtimes[i++]=ptr->dt;
      
  return dtimes;
}

// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_2d sorting using qsort() 
// ######################################################################
int compare_double_2d_x(const void *i, const void *j) 
{
  double v =  ((double_2d *)i)->x - ((double_2d *)j)->x;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */


// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_2d sorting using qsort() 
// ######################################################################
int compare_double_2d_y(const void *i, const void *j) 
{
  double v =  ((double_2d *)i)->y - ((double_2d *)j)->y;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

list_2d::list_2d(double_2d content_, list_2d *prev) :
  double_linked_list((double_linked_list *) prev, NULL)
{
  content=content_;
}

list_2d::~list_2d()
{
  list_2d *next=suc();

  this->removefromlist();

  delete next;
}

double_2d list_2d::get_content(void)
{
  return content;
}

void list_2d::set_content(double_2d new_content)
{
  content=new_content;
}

list_2d *list_2d::suc()
{
  return (list_2d *) getnext(); 
}

double_2d *list_2d::get_array(int *len)
{
  *len=number_of_elements();

  int i=0;
  double_2d *ret=new double_2d[*len];
  for(list_2d *ptr=this;ptr;ptr=ptr->suc(),i++)
    ret[i]=ptr->get_content();

  return ret;
}





double_2d *get_2d_data_file(char *filename, int *len, bool dosort)
{
  list_2d *head=NULL, *tail=NULL;
  ifstream in;
  char line[10000];

  in.open(filename, ios::in);
  if(in.fail())
    {
      printf("Couldn't open file \"%s\"", filename);
      exit(0);
    }
  
  in.getline(line,9999);
  while(!in.eof())
    {
      double x,y;
      double_2d newcontent;

      if(sscanf(line,"%lf %lf", &x, &y)==2)
	{
	  newcontent.x=x;
	  newcontent.y=y;

	  tail=new list_2d(newcontent,tail);
	  if(!head)
	    head=tail;
	}

      in.getline(line,9999);
    }
  
  double_2d *ret=head->get_array(len);
  if(dosort)
    qsort(ret, (size_t) *len, sizeof(double_2d), compare_double_2d_x);
  
  delete head;

  return ret;
}







// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_3d sorting using qsort() 
// ######################################################################
int compare_double_3d_x(const void *i, const void *j) 
{
  double v =  ((double_3d *)i)->x - ((double_3d *)j)->x;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */


// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_3d sorting using qsort() 
// ######################################################################
int compare_double_3d_y(const void *i, const void *j) 
{
  double v =  ((double_3d *)i)->y - ((double_3d *)j)->y;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_3d sorting using qsort() 
// ######################################################################
int compare_double_3d_z(const void *i, const void *j) 
{
  double v =  ((double_3d *)i)->z - ((double_3d *)j)->z;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

list_3d::list_3d(double_3d content_, list_3d *prev) :
  double_linked_list((double_linked_list *) prev, NULL)
{
  content=content_;
}

list_3d::~list_3d()
{
  list_3d *next=suc();

  this->removefromlist();

  delete next;
}

double_3d list_3d::get_content(void)
{
  return content;
}

void list_3d::set_content(double_3d new_content)
{
  content=new_content;
}

list_3d *list_3d::suc()
{
  return (list_3d *) getnext(); 
}

double_3d *list_3d::get_array(int *len)
{
  *len=number_of_elements();

  int i=0;
  double_3d *ret=new double_3d[*len];
  for(list_3d *ptr=this;ptr;ptr=ptr->suc(),i++)
    ret[i]=ptr->get_content();

  return ret;
}





double_3d *get_3d_data_file(char *filename, int *len, bool dosort)
{
  list_3d *head=NULL, *tail=NULL;
  ifstream in;
  char line[10000];

  in.open(filename, ios::in);
  if(in.fail())
    {
      printf("Couldn't open file \"%s\"", filename);
      exit(0);
    }
  
  in.getline(line,9999);
  while(!in.eof())
    {
      double x,y,z;
      double_3d newcontent;

      if(sscanf(line,"%lf %lf %lf", &x, &y, &z)==3)
	{
	  newcontent.x=x;
	  newcontent.y=y;
	  newcontent.z=z;

	  tail=new list_3d(newcontent,tail);
	  if(!head)
	    head=tail;
	}

      in.getline(line,9999);
    }
  
  double_3d *ret=head->get_array(len);
  if(dosort)
    qsort(ret, (size_t) *len, sizeof(double_3d), compare_double_3d_x);

  delete head;

  return ret;
}



// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_4d sorting using qsort() 
// ######################################################################
int compare_double_4d_x(const void *i, const void *j) 
{
  double v =  ((double_4d *)i)->x - ((double_4d *)j)->x;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */


// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_4d sorting using qsort() 
// ######################################################################
int compare_double_4d_y(const void *i, const void *j) 
{
  double v =  ((double_4d *)i)->y - ((double_4d *)j)->y;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_4d sorting using qsort() 
// ######################################################################
int compare_double_4d_z(const void *i, const void *j) 
{
  double v =  ((double_4d *)i)->z - ((double_4d *)j)->z;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */

// ######################################################################
// Return    : int
// Parameters: i, j - two values which will be compared
// Purpose   : compare routine for double_4d sorting using qsort() 
// ######################################################################
int compare_double_4d_w(const void *i, const void *j) 
{
  double v =  ((double_4d *)i)->w - ((double_4d *)j)->w;
  if(v < 0)
    return -1;
  else if(v == 0)
    return 0;
  else
    return 1;
} /* compar */


list_4d::list_4d(double_4d content_, list_4d *prev) :
  double_linked_list((double_linked_list *) prev, NULL)
{
  content=content_;
}

list_4d::~list_4d()
{
  list_4d *next=suc();

  this->removefromlist();

  delete next;
}

double_4d list_4d::get_content(void)
{
  return content;
}

void list_4d::set_content(double_4d new_content)
{
  content=new_content;
}

list_4d *list_4d::suc()
{
  return (list_4d *) getnext(); 
}

double_4d *list_4d::get_array(int *len)
{
  *len=number_of_elements();

  int i=0;
  double_4d *ret=new double_4d[*len];
  for(list_4d *ptr=this;ptr;ptr=ptr->suc(),i++)
    ret[i]=ptr->get_content();

  return ret;
}





double_4d *get_4d_data_file(char *filename, int *len, bool dosort)
{
  list_4d *head=NULL, *tail=NULL;
  ifstream in;
  char line[10000];

  in.open(filename, ios::in);
  if(in.fail())
    {
      printf("Couldn't open file \"%s\"", filename);
      exit(0);
    }
  
  in.getline(line,9999);
  while(!in.eof())
    {
      double x,y,z,w;
      double_4d newcontent;

      if(sscanf(line,"%lf %lf %lf %lf", &x, &y, &z, &w)==4)
	{
	  newcontent.x=x;
	  newcontent.y=y;
	  newcontent.z=z;
	  newcontent.w=w;

	  tail=new list_4d(newcontent,tail);
	  if(!head)
	    head=tail;
	}

      in.getline(line,9999);
    }
  
  double_4d *ret=head->get_array(len);
  if(dosort)
    qsort(ret, (size_t) *len, sizeof(double_4d), compare_double_4d_x);

  delete head;

  return ret;
}



csv::csv() : double_linked_list()
{
  len=0;
  val=NULL;
  names=NULL;
}

csv::csv(char *infile, char sep) : double_linked_list()
{
  ifstream in;
  char line[10000];
  csv *head=this, *tail=NULL;

  in.open(infile, ios::in);
  if(in.fail())
    {
      cerr << "Could not open the file " << infile << "!" << endl;
      return;
    }
  
  in.getline(line,9999);
  len=1;
  int i,slen=strlen(line);
  for(i=0;i<slen;i++)
    if(line[i]==sep)
      len++;
  names=new char*[len];
  for(i=0;i<len;i++)
    names[i]=new char[100];
  int j=0,k=0;
  for(i=0;i<slen;i++)
    {
      if(line[i]!=sep)
	{
	  names[j][k]=line[i];
	  k++;
	}
      
      if(line[i]==sep || i==(slen-1))
	{
	  names[j][k]='\0';
	  j++;
	  k=0;
	}
    }
  
  int lineno=1;
  in.getline(line,9999);
  while(!in.eof())
    {
      char *ptr=line;
      double *vals=new double[len];

      lineno++;

      for(i=0;i<len;i++)
	{
	  vals[i]=MISSING_VALUE;
	  if(ptr[1]==sep || ptr[1]=='\0' || ptr[1]=='\n' || ptr[1]==(char)13)
	    ptr++;
	  else
	    {
	      ptr=getnextdouble(ptr,vals+i);
	      if(i<(len-1) && ptr==NULL)
		{
		  cout << i << " " << len << " " << (long int) ptr << endl;
		  cerr << "Error in line " << lineno << 
		    "! Too few values!" << endl;
		  cerr << line << endl;
		  if(head)
		    delete head;
		  delete [] vals;
		  return;
		}
	    }
	}
	 
      if(lineno==2)
	{
	  val=new double[len];
	  for(i=0;i<len;i++)
	    val[i]=vals[i];
	  tail=head;
	}
      else
	tail=new csv(tail, len, vals);

      in.getline(line,9999);
    }
  in.close();

  return;
}

csv::csv(csv *prev, int new_len, double *new_values) : 
  double_linked_list((double_linked_list *) prev, NULL) 
{
  len=new_len;
  val=new double[len];
  for(int i=0;i<len;i++)
    val[i]=new_values[i];
  names=NULL;
}


csv::csv(csv *prev, int new_len, double *new_values, char **new_names) : 
  double_linked_list((double_linked_list *) prev, NULL) 
{
  len=new_len;
  val=new double[len];
  names=new char*[len];
  for(int i=0;i<len;i++)
    {
      names[i]=new char[100];
      val[i]=new_values[i];
      strcpy(names[i],new_names[i]);
    }
}

csv::~csv()
{
  if(len>0)
    {
      doubledelete(names,len);
      if(val)
	delete [] val;
    }
}

csv *csv::prev(void)
{
  return (csv *) getprev();
}

csv *csv::suc(void)
{
  return (csv *) getnext();
}


int csv::get_length(void)
{
  return len;
}

double csv::get_value(int number)
{
  if(number<0 || number>len || val==NULL)
    {
      cerr << "Programming error - number out of range in csv::get_value" << endl;
      return MISSING_VALUE;
    }
  return val[number];
}

double *csv::get_values(void)
{
  return val;
}

// returns values not only from this element
// but also all subsequent elements:
double **csv::get_all_values(int *num_elem)
{
  int i=0,j,num=number_of_elements();
  double **ret=new double*[num];
  
  for(csv *ptr=this;ptr;ptr=ptr->suc())
    {
      ret[i]=new double[len];
      for(j=0;j<len;j++)
	ret[i][j]=ptr->val[j];
      i++;
    }
  
  if(num_elem)
    *num_elem=num;

  return ret;
}

char *csv::get_name(int number)
{
  if(number<0 || number>len || names==NULL)
    {
      cerr << "Programming error - number out of range in csv::get_name" << endl;
      return NULL;
    }
  return names[number];
}

char **csv::get_names(void)
{
  return names;
}

csv *read_csv(char *infile, char sep)
{
  ifstream in;
  char line[10000];
  csv *head=NULL, *tail=NULL;
  char **names;

  in.open(infile, ios::in);
  if(in.fail())
    {
      cerr << "Could not open the file " << infile << "!" << endl;
      return NULL;
    }
  
  in.getline(line,9999);
  int len=1;
  int i,slen=strlen(line);
  for(i=0;i<slen;i++)
    if(line[i]==sep)
      len++;
  names=new char*[len];
  for(i=0;i<len;i++)
    names[i]=new char[100];
  int j=0,k=0;
  for(i=0;i<slen;i++)
    {
      if(line[i]!=sep)
	{
	  names[j][k]=line[i];
	  k++;
	}
      
      if(line[i]==sep || i==(slen-1))
	{
	  names[j][k]='\0';
	  j++;
	  k=0;
	}
    }
  
  int lineno=1;
  in.getline(line,9999);
  while(!in.eof())
    {
      char *ptr=line;
      double *vals=new double[len];

      lineno++;

      for(i=0;i<len;i++)
	{
	  vals[i]=MISSING_VALUE;
	  if(ptr[1]==sep || ptr[1]=='\0' || ptr[1]=='\n' || ptr[1]==(char)13)
	    ptr++;
	  else
	    {
	      ptr=getnextdouble(ptr,vals+i);
	      if(i<(len-1) && ptr==NULL)
		{
		  cout << i << " " << len << " " << (long int) ptr << endl;
		  cerr << "Error in line " << lineno << 
		    "! Too few values!" << endl;
		  if(head)
		    delete head;
		  delete [] vals;
		  return NULL;
		}
	    }
	}
	 
      if(lineno==2)
	{
	  head=new csv(NULL, len, vals, names); 
	  tail=head;
	}
      else
	tail=new csv(tail, len, vals);

      in.getline(line,9999);
    }
  in.close();

  return head;
}

void csv::show(ostream &out)
{
  int i;
  for(i=0;i<len;i++)
    {
      out << names[i];
      if(i<(len-1))
	out << ";";
    }
  out << endl;

  for(csv *ptr=this;ptr;ptr=ptr->suc())
    {
      for(i=0;i<len;i++)
	{
	  if(ptr->val[i]!=MISSING_VALUE)
	    out << ptr->val[i];
	  if(i<(len-1))
	    out << ";";
	}
      out << endl;
    }
}
