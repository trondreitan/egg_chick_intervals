/*
 * $Id: complex.C 2138 2012-11-13 11:23:47Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/complex.C $
 */

#include <hydrasub/hydrabase/complex.H>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_fft_complex.h>


complex::complex()
{
  GSL_SET_COMPLEX(&com, 0.0, 0.0);
}

complex::complex(double realpart)
{
  GSL_SET_COMPLEX(&com, realpart, 0.0);
}

complex::complex(double realpart, double imagpart)
{
  GSL_SET_COMPLEX(&com, realpart, imagpart);
}

complex::complex(double radius, double angle, int /* radial */)
{
  com=gsl_complex_polar(radius, angle);
}

complex::complex(const complex &orig)
{
  com=orig.com;
}
  
complex& complex::operator= (const complex &orig)
{
  com=orig.com;
  return *this;
}

complex& complex::operator= (const double &orig)
{
  GSL_SET_COMPLEX(&com,orig,0.0);
  return *this;
}

complex& complex::operator= (const float &orig)
{
  GSL_SET_COMPLEX(&com,(double) orig,0.0);
  return *this;
}

complex& complex::operator= (const int &orig)
{
  GSL_SET_COMPLEX(&com,(double) orig,0.0);
  return *this;
}

complex operator+ (const complex &c1, const complex &c2)
{
  gsl_complex com=gsl_complex_add(c1.com, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator+ (const complex &c1, const double &c2)
{
  gsl_complex com2=gsl_complex_rect(c2,0), 
    com=gsl_complex_add(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator+ (const double &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect(c1,0), 
    com=gsl_complex_add(c2.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator+ (const complex &c1, const float &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_add(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator+ (const float &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_add(c2.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator+ (const complex &c1, const int &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_add(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator+ (const int &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_add(c2.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}


complex operator- (const complex &c1, const complex &c2)
{
  gsl_complex com=gsl_complex_sub(c1.com, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator- (const complex &c1, const double &c2)
{
  gsl_complex com2=gsl_complex_rect(c2,0), 
    com=gsl_complex_sub(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator- (const double &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect(c1,0), 
    com=gsl_complex_sub(com2, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator- (const complex &c1, const float &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_sub(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator- (const float &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_sub(com2, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator- (const complex &c1, const int &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_sub(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator- (const int &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_sub(c2.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator* (const complex &c1, const complex &c2)
{
  gsl_complex com=gsl_complex_mul(c1.com, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator* (const complex &c1, const double &c2)
{
  gsl_complex com2=gsl_complex_rect(c2,0), 
    com=gsl_complex_mul(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator* (const double &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect(c1,0), 
    com=gsl_complex_mul(com2, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator* (const complex &c1, const float &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_mul(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator* (const float &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_mul(com2, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator* (const complex &c1, const int &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_mul(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator* (const int &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_mul(c2.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator/ (const complex &c1, const complex &c2)
{
  gsl_complex com=gsl_complex_div(c1.com, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator/ (const complex &c1, const double &c2)
{
  gsl_complex com2=gsl_complex_rect(c2,0), 
    com=gsl_complex_div(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator/ (const double &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect(c1,0), 
    com=gsl_complex_div(com2, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator/ (const complex &c1, const float &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_div(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator/ (const float &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_div(com2, c2.com);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator/ (const complex &c1, const int &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c2,0), 
    com=gsl_complex_div(c1.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

complex operator/ (const int &c1, const complex &c2)
{
  gsl_complex com2=gsl_complex_rect((double) c1,0), 
    com=gsl_complex_div(c2.com, com2);
  double re=GSL_REAL(com), im=GSL_IMAG(com);
  return complex(re, im);
}

void operator+= (complex &c1,const complex &c2)
{
  c1=c1+c2;
}

void operator+= (complex &c1,const double &c2)
{
  c1=c1+c2;
}

void operator+= (complex &c1,const float &c2)
{
  c1=c1+c2;
}

void operator+= (complex &c1,const int &c2)
{
  c1=c1+c2;
}

void operator-= (complex &c1,const complex &c2)
{
  c1=c1-c2;
}

void operator-= (complex &c1,const double &c2)
{
  c1=c1-c2;
}

void operator-= (complex &c1,const float &c2)
{
  c1=c1-c2;
}

void operator-= (complex &c1,const int &c2)
{
  c1=c1-c2;
}

void operator*= (complex &c1,const complex &c2)
{
  c1=c1*c2;
}

void operator*= (complex &c1,const double &c2)
{
  c1=c1*c2;
}

void operator*= (complex &c1,const float &c2)
{
  c1=c1*c2;
}

void operator*= (complex &c1,const int &c2)
{
  c1=c1*c2;
}

void operator/= (complex &c1,const complex &c2)
{
  c1=c1/c2;
}

void operator/= (complex &c1,const double &c2)
{
  c1=c1/c2;
}

void operator/= (complex &c1,const float &c2)
{
  c1=c1/c2;
}

void operator/= (complex &c1,const int &c2)
{
  c1=c1/c2;
}

void operator++ (complex &c1)
{
  c1=c1+1;
}
  
void operator++ (complex &c1, int)
{
  c1=c1+1;
}

void operator-- (complex &c1)
{
  c1=c1-1;
}

void operator-- (complex &c1, int)
{
  c1=c1-1;
}

// logical operators
int operator== (const complex &c1, const complex &c2)
{
  return int(GSL_REAL(c1.com)==GSL_REAL(c2.com) &&
	     GSL_IMAG(c1.com)==GSL_IMAG(c2.com));
}

int operator!= (const complex &c1, const complex &c2)
{
  return int(GSL_REAL(c1.com)!=GSL_REAL(c2.com) ||
	     GSL_IMAG(c1.com)!=GSL_IMAG(c2.com));
}


double complex::Real_value(void)
{
  return GSL_REAL(com);
}

double complex::Imaginary_value(void)
{
  return GSL_IMAG(com);
}

double complex::Re(void)
{
  return GSL_REAL(com);
}

double complex::Im(void)
{
  return GSL_IMAG(com);
}

void complex::set(double real, double imag)
{
  com=gsl_complex_rect(real, imag);
}

void complex::set_polar(double radius, double angle)
{
  com=gsl_complex_polar(radius, angle);
}


double complex::angle(void)
{
  return gsl_complex_arg(com);
}

double complex::radius(void)
{
  return gsl_complex_abs(com);
}

double complex::abs(void)
{
  return gsl_complex_abs(com);
}

double complex::abs2(void) // R^2
{
  return gsl_complex_abs2(com);
}



complex *fft_forward(complex *input,int len)
{
  gsl_fft_complex_wavetable * wavetable;
  gsl_fft_complex_workspace * workspace;
  
  wavetable = gsl_fft_complex_wavetable_alloc (len);
  workspace = gsl_fft_complex_workspace_alloc (len);
  
  int i;
  gsl_complex *buffer=new gsl_complex[len];
  for(i=0;i<len;i++)
    buffer[i]=input[i].com;
  
  gsl_fft_complex_forward ((gsl_complex_packed_array) buffer, 1, len, 
			   wavetable, workspace);
  
  gsl_fft_complex_wavetable_free (wavetable);
  gsl_fft_complex_workspace_free (workspace);

  complex *ret=new complex[len];
  for(i=0;i<len;i++)
    ret[i].com=buffer[i];
  delete [] buffer;
  
  return ret;
}

complex *fft_forward(double *input,int len)
{
  complex *buffer=new complex[len];
  for(int i=0;i<len;i++)
    buffer[i]=input[i];
  
  complex *ret=fft_forward(buffer,len);
  delete [] buffer;

  return ret;
}

complex *fft_backward(complex *input,int len)
{
  gsl_fft_complex_wavetable * wavetable;
  gsl_fft_complex_workspace * workspace;
  
  wavetable = gsl_fft_complex_wavetable_alloc (len);
  workspace = gsl_fft_complex_workspace_alloc (len);
  
  int i;
  gsl_complex *buffer=new gsl_complex[len];
  for(i=0;i<len;i++)
    buffer[i]=input[i].com;
  
  gsl_fft_complex_backward ((gsl_complex_packed_array) buffer, 1, len, 
			    wavetable, workspace);
  
  gsl_fft_complex_wavetable_free (wavetable);
  gsl_fft_complex_workspace_free (workspace);

  complex *ret=new complex[len];
  for(i=0;i<len;i++)
    ret[i].com=buffer[i];
  delete [] buffer;
  
  return ret;
}

complex *fft_backward(double *input,int len)
{
  complex *buffer=new complex[len];
  for(int i=0;i<len;i++)
    buffer[i]=input[i];
  
  complex *ret=fft_backward(buffer,len);
  delete [] buffer;

  return ret;
}

double *fft_forward_strength(double *input,int len)
{
  complex *buffer=fft_forward(input,len);
  double *ret=new double[len/2];

  for(int i=0;i<len/2;i++)
    ret[i]=buffer[i].abs();
  
  delete [] buffer;

  return ret;
}
  

complex complex::conjugate(void)
{
  complex ret;

  ret.com=gsl_complex_conjugate(com);
  return ret;
}

complex complex::inverse(void)
{
  complex ret;

  ret.com=gsl_complex_inverse(com);
  return ret;
}

complex complex::negative(void)
{
  complex ret;

  ret.com=gsl_complex_negative(com);
  return ret;
}
 
double complex_abs(complex &orig)
{
  return orig.abs();
}

double complex_abs2(complex &orig)
{
  return orig.abs2();
}

complex complex_sqrt(complex &orig)
{
  complex ret;

  ret.com=gsl_complex_sqrt(orig.com);
  return ret;
}

complex complex_pow(complex &a, complex &b)
{
  complex ret;

  ret.com=gsl_complex_pow(a.com, b.com);
  return ret;
}

complex complex_exp(complex &a)
{
  complex ret;

  ret.com=gsl_complex_exp(a.com);
  return ret;
}

complex complex_log(complex &a)
{
  complex ret;

  ret.com=gsl_complex_log(a.com);
  return ret;
}

complex complex_log10(complex &a)
{
  complex ret;

  ret.com=gsl_complex_log10(a.com);
  return ret;
}

complex complex_logb(complex &a,complex &b)
{
  complex ret;

  ret.com=gsl_complex_log_b(a.com,b.com);
  return ret;
}


complex complex_sin(complex &a)
{
  complex ret;

  ret.com=gsl_complex_sin(a.com);
  return ret;
}

complex complex_cos(complex &a)
{
  complex ret;

  ret.com=gsl_complex_cos(a.com);
  return ret;
}

complex complex_sec(complex &a)
{
  complex ret;

  ret.com=gsl_complex_sec(a.com);
  return ret;
}

complex complex_csc(complex &a)
{
  complex ret;

  ret.com=gsl_complex_csc(a.com);
  return ret;
}

complex complex_tan(complex &a)
{
  complex ret;

  ret.com=gsl_complex_tan(a.com);
  return ret;
}

complex complex_cot(complex &a)
{
  complex ret;

  ret.com=gsl_complex_cot(a.com);
  return ret;
}


complex complex_asin(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arcsin(a.com);
  return ret;
}

complex complex_acos(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arccos(a.com);
  return ret;
}

complex complex_asec(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arcsec(a.com);
  return ret;
}

complex complex_acsc(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arccsc(a.com);
  return ret;
}

complex complex_atan(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arctan(a.com);
  return ret;
}

complex complex_acot(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arccot(a.com);
  return ret;
}


complex complex_sinh(complex &a)
{
  complex ret;

  ret.com=gsl_complex_sinh(a.com);
  return ret;
}

complex complex_cosh(complex &a)
{
  complex ret;

  ret.com=gsl_complex_cosh(a.com);
  return ret;
}

complex complex_sech(complex &a)
{
  complex ret;

  ret.com=gsl_complex_sech(a.com);
  return ret;
}

complex complex_csch(complex &a)
{
  complex ret;

  ret.com=gsl_complex_csch(a.com);
  return ret;
}

complex complex_tanh(complex &a)
{
  complex ret;

  ret.com=gsl_complex_tanh(a.com);
  return ret;
}

complex complex_coth(complex &a)
{
  complex ret;

  ret.com=gsl_complex_coth(a.com);
  return ret;
}


complex complex_asinh(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arcsinh(a.com);
  return ret;
}

complex complex_acosh(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arccosh(a.com);
  return ret;
}

complex complex_asech(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arcsech(a.com);
  return ret;
}

complex complex_acsch(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arccsch(a.com);
  return ret;
}

complex complex_atanh(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arctanh(a.com);
  return ret;
}

complex complex_acoth(complex &a)
{
  complex ret;

  ret.com=gsl_complex_arccoth(a.com);
  return ret;
}


std::ostream& operator<<(std::ostream &out,  complex &c)
{
  char line[100];
  double re=c.Real_value();
  double im=c.Imaginary_value();

  sprintf(line, "%8.4g+%8.4gi", re,im);
  out << line;

  return out;
}

std::istream& operator>>(std::istream &in, complex &c)
{
  double re,im;

  in >> re;
  in >> im;

  c.set(re,im);

  return in;
}



complexlist::complexlist(complex value_in) : double_linked_list()
{
  value=value_in;
}
 
complexlist::complexlist(complexlist *previtem, complexlist *nextitem,
                     complex value_in) :
  double_linked_list((double_linked_list *) previtem,
                     (double_linked_list *) nextitem)
{
  value=value_in;
}
                                                                                                                                     
complex complexlist::getvalue(void)
{
  return value;
}
                                                                                                                                     
void complexlist::setvalue(complex new_value)
{
  value=new_value;
}

complexlist *complexlist::suc(void)
{
  return (complexlist *) getnext();
}
 
complex *complexlist::getarray(int &size)
{
  size=number_of_elements();
  complex *ret=new complex[size];
 
  int i=0;
  for(complexlist *ptr=this; ptr; ptr=ptr->suc())
    ret[i++]=ptr->value;
       
  return ret;
}
 
 
