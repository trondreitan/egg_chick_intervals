#include <hydrasub/hydrabase/tables.H>

void cell_content::copy(cell_content &orig)
{
  cell_type=orig.cell_type;
  switch(orig.cell_type)
    {
    case TABLE_DATETIME:
      cell_datetime=orig.cell_datetime;
      break;
    case TABLE_INT:
      cell_int=orig.cell_int;
      break;
    case TABLE_DOUBLE:
      cell_double=orig.cell_double;
      break;
    case TABLE_CHAR:
      cell_char=orig.cell_char;
      break;
    case TABLE_STRING:
      strcpy(cell_string, orig.cell_string);
      break;
    case TABLE_UNKNOWN_CONTENT:
    default:
      std::cerr << "Unknown cell content" << std::endl;
      break;
    }
}

void cell_content::print(FILE *f)
{
  switch(cell_type)
    {
    case TABLE_DATETIME:
      fprintf(f,"%04d-%02d-%02d %02d:%02d:%02d",
	     cell_datetime.getYear(), cell_datetime.getMonth(),
	     cell_datetime.getDay(), cell_datetime.getHour(),
	     cell_datetime.getMinute(), cell_datetime.getSecond());
      break;
    case TABLE_INT:
      fprintf(f, "%d",cell_int);
      break;
    case TABLE_DOUBLE:
      fprintf(f, "%f",cell_double);
      break;
    case TABLE_CHAR:
      fprintf(f, "%c",cell_char);
      break;
    case TABLE_STRING:
      fprintf(f, "%s",cell_string);
      break;
    case TABLE_UNKNOWN_CONTENT:
    default:
      std::cerr << "Unknown cell content" << std::endl;
      break;
    }
}

attributes::attributes(stringlist *namelist)
{
  keys=NULL;

  if(!namelist)
    {
      size=0;
      names=NULL;
      return;
    }
  
  size=namelist->number_of_elements();
  names=new char*[size];
  tabcont=new TABLE_CONTENT[size];

  int i=0;
  for(stringlist *ptr=namelist;ptr;ptr=(stringlist *)ptr->getnext())
    {
      names[i]=new char[strlen(ptr->getstring())+2];
      strcpy(names[i], ptr->getstring());
      tabcont[i]=TABLE_DOUBLE;
      i++;
    }
}

attributes::attributes(int size_, char const* const* names_)
{
  size=size_;
  
  names=new char*[size];
  keys=NULL;
  tabcont=new TABLE_CONTENT[size];

  for(int i=0;i<size;i++)
    {
      names[i]=new char[strlen(names_[i])+2];
      strcpy(names[i],names_[i]);
      tabcont[i]=TABLE_DOUBLE;
    }
}

attributes::attributes(int size_, char const* const* names_, int *keys_)
{
  size=size_;
  
  names=new char*[size];
  keys=new int[size];
  tabcont=new TABLE_CONTENT[size];

  for(int i=0;i<size;i++)
    {
      names[i]=new char[strlen(names_[i])+2];
      strcpy(names[i],names_[i]);
      keys[i]=keys_[i];
      tabcont[i]=TABLE_DOUBLE;
    }
}

attributes::attributes(int size_, TABLE_CONTENT *table_content, char const* const* names_)
{
  size=size_;
  
  names=new char*[size];
  keys=NULL;
  tabcont=new TABLE_CONTENT[size];

  for(int i=0;i<size;i++)
    {
      names[i]=new char[strlen(names_[i])+2];
      strcpy(names[i],names_[i]);
      tabcont[i]=table_content[i];
    }
}

attributes::attributes(int size_, TABLE_CONTENT *table_content, 
		       char const* const* names_, int *keys_)
{
  size=size_;
  
  names=new char*[size];
  keys=new int[size];
  tabcont=new TABLE_CONTENT[size];

  for(int i=0;i<size;i++)
    {
      names[i]=new char[strlen(names_[i])+2];
      strcpy(names[i],names_[i]);
      keys[i]=keys_[i];
      tabcont[i]=table_content[i];
    }
}

attributes::attributes(attributes *orig)
{
  int i;

  if(!orig)
    {
      std::cerr << "Program error in attributes constructor!" << std::endl;
      return;
    }

  size=orig->size;
  names=NULL;
  tabcont=NULL;
  keys=NULL;

  if(orig->names)
    {
      names=new char*[size];
      for(i=0;i<size;i++)
	{
	  names[i]=NULL;
	  if(orig->names[i])
	    {
	      names[i]=new char[strlen(orig->names[i])+5];
	      strcpy(names[i], orig->names[i]);
	    }
	}
    }

  if(orig->keys)
    {
      keys=new int[size];
      for(i=0;i<size;i++)
	keys[i]=orig->keys[i];
    }

  if(orig->tabcont)
    {
      tabcont=new TABLE_CONTENT[size];
      for(i=0;i<size;i++)
	tabcont[i]=orig->tabcont[i];
    }
}

attributes::~attributes()
{
  doubledelete(names,size);
  if(keys)
    delete [] keys;
  if(tabcont)
    delete [] tabcont;
  keys=NULL;
  names=NULL;
  tabcont=NULL;
  size=0;
}

int attributes::get_size(void)
{
  return size;
}

char *attributes::get_name(int pos)
{
  if(names && pos>=0 && pos<size && names[pos])
    return names[pos];
  else
    return NULL;
}

int attributes::get_key(int pos)
{
  if(keys && pos>=0 && pos<size)
    return keys[pos];
  else
    return (int) MISSING_VALUE;
}

TABLE_CONTENT attributes::get_content_type(int pos)
{
  if(tabcont && pos>=0 && pos<size)
    return tabcont[pos];
  else
    return TABLE_UNKNOWN_CONTENT;
}

void attributes::append(TABLE_CONTENT new_content, 
			const char *new_name, int new_key)
{
  int i, ncol=size;

  char **newnames=NULL;
  int *newkeys=NULL;
  TABLE_CONTENT *newcont=NULL;

  if(new_name && names)
    {
      newnames=new char*[ncol+1];
      for(i=0;i<ncol;i++)
	{
	  newnames[i]=new char[strlen(names[i])+2];
	  strcpy(newnames[i],names[i]);
	}
      newnames[ncol]=new char[strlen(new_name)+2];
      strcpy(newnames[ncol], new_name);
    }
  
  if(keys)
    {
      newkeys=new int[ncol+1];
      for(i=0;i<ncol;i++)
	newkeys[i]=keys[i];
      newkeys[ncol]=new_key;
    }
  
  if(tabcont)
    {
      newcont=new TABLE_CONTENT[ncol+1];
      for(i=0;i<ncol;i++)
	newcont[i]=tabcont[i];
      newcont[ncol]=new_content;
    }
  
  doubledelete(names,ncol);
  names=newnames;

  if(keys)
    delete [] keys;
  keys=newkeys;

  if(tabcont)
    delete [] tabcont;
  tabcont=newcont;

  size++;
}

int attributes::get_position(const char *name)
{
  int i=0;
  
  if(!names || size<=0)
    return -1;

  for(i=0;i<size;i++)
    {
      if(names[i] && !strcasecmp(name,names[i]))
	return i;
    }

  return -1;
}

int attributes::get_position(int key)
{
  int i=0;

  if(!keys || size<=0)
    return -1;

  for(i=0;i<size;i++)
    {
      if(key==keys[i])
	return i;
    }
  
  return -1;
}

void attributes::set_name(int pos, const char *new_name)
{
  if(names && pos>=0 && pos<size && names[pos])
    {
      delete [] names[pos];
      names[pos]=new char[strlen(new_name)+2];
      strcpy(names[pos], new_name);
    }
  else
    std::cerr << "Program error - attributes::set_name usage error!" << std::endl;
}

void attributes::set_key(int pos, int new_key)
{
  if(keys && pos>=0 && pos<size)
    keys[pos]=new_key;
  else
    std::cerr << "Program error - attributes::set_key usage error!" << std::endl;
}

void attributes::set_content_type(int pos, TABLE_CONTENT new_tab_cont)
{
  if(tabcont && pos>=0 && pos<size)
    tabcont[pos]=new_tab_cont;
  else
    std::cerr << "Program error - attributes::set_tab_cont usage error!" << std::endl;
}

table_row::table_row(int size_)
{
  size=size_;
 
  cells=new cell_content[size];
  for(int i=0;i<size;i++)
    {
      cells[i].cell_double=0.0;
      cells[i].cell_type=TABLE_DOUBLE;
      strcpy(cells[i].cell_string,"");
    }
}

table_row::table_row(int size_, cell_content *cells_)
{
  size=size_;
 
  cells=new cell_content[size];
  for(int i=0;i<size;i++)
    cells[i].copy(cells_[i]);
}

table_row::table_row(table_row *orig)
{
  if(!orig)
    {
      std::cerr << "Program error in table_row constructor!" << std::endl;
      return;
    }
  
  size=orig->size;
  cells=new cell_content[size];
  for(int i=0;i<size;i++)
    cells[i].copy(orig->cells[i]);
}

table_row::table_row(attributes *orig)
{
  if(!orig)
    {
      std::cerr << "Program error in table_row constructor!" << std::endl;
      return;
    }

  size=orig->get_size();
  cells=new cell_content[size];
  for(int i=0;i<size;i++)
    {
      cells[i].cell_type=orig->get_content_type(i);
      cells[i].cell_double=MISSING_VALUE;
      cells[i].cell_int=(int)MISSING_VALUE;
      cells[i].cell_datetime=NoDateTime;
      cells[i].cell_char='\0';
      strcpy(cells[i].cell_string,"");
    }
}

table_row::~table_row()
{
  if(cells)
    delete [] cells;
  cells=NULL;
  size=0;
}

int table_row::get_size(void)
{
  return size;
}

DateTime table_row::get_datetime(int pos)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_DATETIME)
    return cells[pos].cell_datetime;
  else
    return NoDateTime;
}

int table_row::get_int(int pos)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_INT)
    return cells[pos].cell_int;
  else
    return (int) MISSING_VALUE;
}

double table_row::get_double(int pos)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_DOUBLE)
    return cells[pos].cell_double;
  else
    return MISSING_VALUE;
}

char table_row::get_char(int pos)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_CHAR)
    return cells[pos].cell_char;
  else
    return '\0';
}

char *table_row::get_string(int pos)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_STRING)
    return cells[pos].cell_string;
  else
    return NULL;
}

TABLE_CONTENT table_row::get_type(int pos)
{
  if(pos>=0 && pos<size && cells)
    return cells[pos].cell_type;
  else
    return TABLE_UNKNOWN_CONTENT;
}

void table_row::print(FILE *f, int pos)
{
  if(pos>=0 && pos<size && cells)
    cells[pos].print(f);
}
  
void table_row::append(TABLE_CONTENT new_type)
{
  int i,ncol=size;
  cell_content *newcells=new cell_content[ncol+1];

  for(i=0;i<ncol;i++)
    newcells[i]=cells[i];

  newcells[i].cell_type=new_type;
  newcells[i].cell_double=MISSING_VALUE;
  newcells[i].cell_int=(int)MISSING_VALUE;
  newcells[i].cell_datetime=NoDateTime;
  newcells[i].cell_char='\0';
  strcpy(newcells[i].cell_string,"");

  delete [] cells;
  cells=newcells;
  size++;
}

void table_row::set(int pos, DateTime new_dt)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_DATETIME)
    cells[pos].cell_datetime=new_dt;
  else
    std::cerr << "Program error - table_row::set(datetime) usage error!" << std::endl;
}

void table_row::set(int pos, int new_int)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_INT)
    cells[pos].cell_int=new_int;
  else
    {
      std::cerr << "Program error - table_row::set(int) usage error!" << 
	std::endl;
    }
}

void table_row::set(int pos, double new_dbl)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_DOUBLE)
    cells[pos].cell_double=new_dbl;
  else
    std::cerr << "Program error - table_row::set(double) usage error!" << std::endl;
}

void table_row::set_type(int pos, TABLE_CONTENT new_type)
{
  if(pos>=0 && pos<size && cells)
    cells[pos].cell_type=new_type;
  else
    std::cerr << "Program error - table_row::set_type usage error!" << std::endl;
}

void table_row::set(int pos, char new_char)
{
  if(pos>=0 && pos<size && cells && cells[pos].cell_type==TABLE_CHAR)
    cells[pos].cell_char=new_char;
  else
    std::cerr << "Program error - table_row::set(char) usage error!" << std::endl;
}

void table_row::set(int pos, const char *new_string)
{
  if(pos>=0 && pos<size && cells)
    {
      switch(cells[pos].cell_type)
	{
	case TABLE_STRING:
	  if(strlen(new_string)<29)
	    strcpy(cells[pos].cell_string, new_string);
	  else
	    strncpy(cells[pos].cell_string, new_string,28);
	  cells[pos].cell_string[29]='\0';
	  break;
	case TABLE_CHAR:
	  cells[pos].cell_char=new_string[0];
	  break;
	case TABLE_DATETIME:
	  {
	    int yr,mnd,day,hour,min,sec;
	    if(sscanf(new_string,"%04d-%02d-%02d %02d:%02d:%02d",
		      &yr,&mnd,&day,&hour,&min,&sec)==6)
	      {
		DateTime dt(yr,mnd,day,hour,min,sec);

		if(dt.legal())
		  cells[pos].cell_datetime=dt;
		else
		  {
		    std::cerr << "Format error for date time: " << 
		      new_string << std::endl;
		  }
	      }
	    else if(sscanf(new_string,"%02d.%02d.%04d %02d:%02d:%02d",
			   &day,&mnd,&yr,&hour,&min,&sec)==6)
	      {
		DateTime dt(yr,mnd,day,hour,min,sec);

		if(dt.legal())
		  cells[pos].cell_datetime=dt;
		else
		  {
		    std::cerr << "Format error for date time: " << 
		      new_string << std::endl;
		  }
	      }
	    else if(sscanf(new_string,"%02d.%02d.%04d %02d:%02d",
			   &day,&mnd,&yr,&hour,&min)==5)
	      {
		DateTime dt(yr,mnd,day,hour,min);

		if(dt.legal())
		  cells[pos].cell_datetime=dt;
		else
		  {
		    std::cerr << "Format error for date time: " << 
		      new_string << std::endl;
		  }
	      }
	    else
	      {
		std::cerr << "Format error for date time: " << new_string << std::endl;
	      }
	    
	    break;
	  }
	case TABLE_INT:
	  cells[pos].cell_int=atoi(new_string);
	  break;
	case TABLE_DOUBLE:
	  cells[pos].cell_double=atof(new_string);
	  break;
	case TABLE_UNKNOWN_CONTENT:
	default:
	  std::cerr << "Program error - table_row::set(string) "
	    "usage error!" << std::endl;
	  break;
	}
    }
  else
    std::cerr << "Program error - table_row::set(string) usage error!" << std::endl;
}

bool table_row::is_equal(table_row *comprow)
{
  if(size!=comprow->size)
    return false;

  for(int i=0;i<size;i++)
    {
      if(cells[i].cell_type!=comprow->cells[i].cell_type)
	return false;

      switch(cells[i].cell_type)
	{
	case TABLE_DATETIME:
	  if(cells[i].cell_datetime!=comprow->cells[i].cell_datetime)
	    return false;
	  break;
	case TABLE_INT:
	  if(cells[i].cell_int!=comprow->cells[i].cell_int)
	    return false;
	  break;
	case TABLE_DOUBLE:
	  if(!almost_equal(cells[i].cell_double,
			   comprow->cells[i].cell_double))
	    return false;
	  break;
	case TABLE_CHAR:
	  if(cells[i].cell_char!=comprow->cells[i].cell_char)
	    return false;
	  break;
	case TABLE_STRING:
	  if(strcmp(cells[i].cell_string, comprow->cells[i].cell_string))
	    return false;
	  break;
	default:
	  return false;
	  break;
	}
    }

  return true;
}

bool table_row::is_equal(table_row *comprow, int colnum)
{
  if(colnum<0 || colnum>=size)
    return false;

  if(size!=comprow->size)
    return false;

  switch(cells[colnum].cell_type)
    {
    case TABLE_DATETIME:
      if(cells[colnum].cell_datetime!=comprow->cells[colnum].cell_datetime)
	return false;
      break;
    case TABLE_INT:
      if(cells[colnum].cell_int!=comprow->cells[colnum].cell_int)
	return false;
      break;
    case TABLE_DOUBLE:
      if(!almost_equal(cells[colnum].cell_double,
		       comprow->cells[colnum].cell_double))
	return false;
      break;
    case TABLE_CHAR:
      if(cells[colnum].cell_char!=comprow->cells[colnum].cell_char)
	return false;
      break;
    case TABLE_STRING:
      if(strcmp(cells[colnum].cell_string, comprow->cells[colnum].cell_string))
	return false;
      break;
    default:
      return false;
      break;
    }

  return true;
}


tablelist::tablelist(attributes *attrib, table_row **rows_, int length_)
{
  int i,j;

  table_attrib=new attributes(attrib);
  
  rows=NULL;
  length=length_;
  sort_column_num=-1;

  if(length>0)
    {
      rows=new table_row*[length];
      for(i=0;i<length;i++)
	{
	  rows[i]=new table_row(rows_[i]);
	  for(j=0;j<table_attrib->get_size();j++)
	    if(table_attrib->get_content_type(j)!=rows[i]->get_type(j))
	      {
		std::cerr << "Program error: type mismatch in "
		  "tablelist constructor!" << std::endl;
		return;
	      }
	}
    }
}

tablelist::tablelist(tablelist *orig, bool only_active)
{
  table_attrib=new attributes(orig->table_attrib);
  rows=NULL;
  
  sort_column_num=orig->sort_column_num;

  if(only_active)
    {
      int active=get_column_number("active");

      if(active<0)
	{
	  std::cerr << "Program error - "
	    "no active column in tablelist constructor" << std::endl;
	  return;
	}

      int numsel=0,i=0;

      for(i=0;i<get_rows();i++)
	if(get_cell_int(active,i))
	  numsel++;
  
      if(numsel>0)
	{
	  length=numsel;
	  rows=new table_row*[length];

	  int j=0;
	  for(i=0;i<get_rows();i++)
	    if(get_cell_int(active,i))
	      rows[j++]=new table_row(orig->rows[i]);
	}
    }
  else
    {
      length=orig->length;
      rows=new table_row*[length];

      for(int i=0;i<length;i++)
	rows[i]=new table_row(orig->rows[i]);
    }
}

tablelist::~tablelist()
{
  if(table_attrib)
    delete table_attrib;
  table_attrib=NULL;
  if(rows)
    {
      for(int i=0;i<length;i++)
	delete rows[i];
      delete [] rows;
    }
  rows=NULL;
  length=0;
}
  
tablelist *tablelist::get_selection(int *active)
{
  int i,j,newlen=0;

  for(i=0;i<length;i++)
    if(active[i])
      newlen++;

  table_row **new_rows=new table_row*[newlen];
  j=0;
  for(i=0;i<length;i++)
    if(active[i])
      new_rows[j++]=new table_row(rows[i]);

  tablelist *newlist=new tablelist(table_attrib, new_rows, newlen);
  newlist->sort_column_num=sort_column_num;
  
  for(i=0;i<newlen;i++)
    delete new_rows[i];
  delete [] new_rows;
  
  return newlist;
}

int tablelist::get_columns(void)
{
  return table_attrib->get_size();
}

int tablelist::get_rows(void)
{
  return length;
}

char *tablelist::get_column_name(int pos)
{
  return table_attrib->get_name(pos);
}

TABLE_CONTENT tablelist::get_column_type(int pos)
{
  return table_attrib->get_content_type(pos);
}

int tablelist::get_column_key(int pos)
{
  return table_attrib->get_key(pos);
}

void tablelist::set_column_name(int pos, const char *new_name)
{
  table_attrib->set_name(pos,new_name);
}

void tablelist::set_column_type(int pos, TABLE_CONTENT new_type)
{
  table_attrib->set_content_type(pos, new_type);

  for(int i=0;i<length;i++)
    rows[i]->set_type(pos, new_type);
}

void tablelist::set_column_key(int pos, int new_key)
{
  table_attrib->set_key(pos,new_key);
}

table_row *tablelist::get_row(int row_num)
{
  if(row_num>=0 && row_num<length)
    return rows[row_num];
  else
    return NULL;
}

table_row **tablelist::get_all_rows(void)
{
  return rows;
}

attributes *tablelist::get_attributes(void)
{
  return table_attrib;
}

DateTime tablelist::get_cell_datetime(int col, int row)
{
  if(row>=0 && row<length)
    return rows[row]->get_datetime(col);
  else
    return NoDateTime;
}

double tablelist::get_cell_double(int col, int row)
{
  if(row>=0 && row<length)
    return rows[row]->get_double(col);
  else
    return MISSING_VALUE;
}

int tablelist::get_cell_int(int col, int row)
{
  if(row>=0 && row<length)
    return rows[row]->get_int(col);
  else
    return (int) MISSING_VALUE;
}

char tablelist::get_cell_char(int col, int row)
{
  if(row>=0 && row<length)
    return rows[row]->get_char(col);
  else
    return '\0';
}

char *tablelist::get_cell_string(int col, int row)
{
  if(row>=0 && row<length)
    return rows[row]->get_string(col);
  else
    return NULL;
}

DateTime *tablelist::get_column_datetime(int col)
{
  int ncol=get_columns(),nrow=get_rows();

  if(col>=0 && col<ncol && nrow>0)
    {
      DateTime *ret=new DateTime[nrow];
     
      for(int i=0;i<nrow;i++)
	ret[i]=rows[i]->get_datetime(col);
      
      return ret;
    }
  else
    return NULL;
}

double *tablelist::get_column_double(int col)
{
  int ncol=get_columns(),nrow=get_rows();

  if(col>=0 && col<ncol && nrow>0)
    {
      double *ret=new double[nrow];
     
      for(int i=0;i<nrow;i++)
	ret[i]=rows[i]->get_double(col);
      
      return ret;
    }
  else
    return NULL;
}

int *tablelist::get_column_int(int col)
{
  int ncol=get_columns(),nrow=get_rows();

  if(col>=0 && col<ncol && nrow>0)
    {
      int *ret=new int[nrow];
     
      for(int i=0;i<nrow;i++)
	ret[i]=rows[i]->get_int(col);
      
      return ret;
    }
  else
    return NULL;
}

char *tablelist::get_column_char(int col)
{
  int ncol=get_columns(),nrow=get_rows();

  if(col>=0 && col<ncol && nrow>0)
    {
      char *ret=new char[nrow];
     
      for(int i=0;i<nrow;i++)
	ret[i]=rows[i]->get_char(col);
      
      return ret;
    }
  else
    return NULL;
}

char **tablelist::get_column_string(int col)
{
  int ncol=get_columns(),nrow=get_rows();

  if(col>=0 && col<ncol && nrow>0)
    {
      char **ret=new char*[nrow];
     
      for(int i=0;i<nrow;i++)
	{
	  ret[i]=new char[30];
	  strcpy(ret[i], rows[i]->get_string(col));
	}
      
      return ret;
    }
  else
    return NULL;
}

void tablelist::append_column(TABLE_CONTENT new_column_type,
			      const char *new_column_name, int new_key)
{
  int nrow=get_rows();
  
  table_attrib->append(new_column_type, new_column_name, new_key);
  
  for(int i=0;i<nrow;i++)
    rows[i]->append(new_column_type);
}

void tablelist::set_cell(int col, int row, DateTime new_dt)
{
  if(row>=0 && row<length)
    rows[row]->set(col, new_dt);
  else
    std::cerr << "Program error in tablelist::set_cell(datetime)" << std::endl;
}

void tablelist::set_cell(int col, int row, double new_dbl)
{
  if(row>=0 && row<length)
    rows[row]->set(col, new_dbl);
  else
    std::cerr << "Program error in tablelist::set_cell(double)" << std::endl;
}

void tablelist::set_cell(int col, int row, int new_int)
{
  if(row>=0 && row<length)
    rows[row]->set(col, new_int);
  else
    std::cerr << "Program error in tablelist::set_cell(int)" << std::endl;
}

void tablelist::set_cell(int col, int row, char new_char)
{
  if(row>=0 && row<length)
    rows[row]->set(col, new_char);
  else
    std::cerr << "Program error in tablelist::set_cell(char)" << std::endl;
}

void tablelist::set_cell(int col, int row, const char *new_string)
{
  if(row>=0 && row<length)
    rows[row]->set(col, new_string);
  else
    std::cerr << "Program error in tablelist::set_cell(string)" << std::endl;
}



int tablelist::get_column_number(const char *name)
{
  return table_attrib->get_position(name);
}

int tablelist::get_column_number(int key)
{
  return table_attrib->get_position(key);
}

void tablelist::remove_row(int row_num)
{
  if(length==1)
    {
      length=0;
      delete rows[0];
      delete [] rows;
      rows=NULL;
      return;
    }

  int i;
  table_row **new_rows=new table_row*[length-1];
  for(i=0;i<=row_num-1;i++)
    new_rows[i]=new table_row(rows[i]);
  for(i=row_num+1;i<length;i++)
    new_rows[i-1]=new table_row(rows[i]);

  for(i=0;i<length;i++)
    delete rows[i];
  delete [] rows;
  rows=new_rows;
  length--;
}

void tablelist::clear(void)
{
  for(int i=0;i<length;i++)
    delete rows[i];
  delete [] rows;
  rows=NULL;
  length=0;
}

void tablelist::insert_row(int row_num, table_row *new_row)
{
  int i;
  table_row **new_rows=new table_row*[length+1];
  for(i=0;i<row_num;i++)
    new_rows[i]=new table_row(rows[i]);
  new_rows[row_num]=new table_row(new_row);
  for(i=row_num;i<length;i++)
    new_rows[i+1]=new table_row(rows[i]);

  if(rows && length>0)
    {
      for(i=0;i<length;i++)
	delete rows[i];
      delete [] rows;
    }

  rows=new_rows;
  length++;
}

int tablelist_qsort_colnum, tablelist_qsort_doinverse, tablelist_qsort_active;
int compare_rows(const void *i, const void *j) 
{
  table_row *r1=*(table_row **) i;
  table_row *r2=*(table_row **) j;

  int ret=0;

  switch(r1->get_type(tablelist_qsort_colnum))
    {
    case TABLE_DATETIME:
      if(r1->get_datetime(tablelist_qsort_colnum)>
	 r2->get_datetime(tablelist_qsort_colnum))
	ret=1;
      else if(r1->get_datetime(tablelist_qsort_colnum)<
	 r2->get_datetime(tablelist_qsort_colnum))
	ret=-1;
      break;
    case TABLE_DOUBLE:
      if(r1->get_double(tablelist_qsort_colnum)>
	 r2->get_double(tablelist_qsort_colnum))
	ret=1;
      else if(r1->get_double(tablelist_qsort_colnum)<
	 r2->get_double(tablelist_qsort_colnum))
	ret=-1;
      break;
    case TABLE_INT:
      if(r1->get_int(tablelist_qsort_colnum)>
	 r2->get_int(tablelist_qsort_colnum))
	ret=1;
      else if(r1->get_int(tablelist_qsort_colnum)<
	 r2->get_int(tablelist_qsort_colnum))
	ret=-1;
      break;
    case TABLE_CHAR:
      if(r1->get_char(tablelist_qsort_colnum)>
	 r2->get_char(tablelist_qsort_colnum))
	ret=1;
      else if(r1->get_char(tablelist_qsort_colnum)<
	 r2->get_char(tablelist_qsort_colnum))
	ret=-1;
      break;
    case TABLE_STRING:
      ret=strcmp(r1->get_string(tablelist_qsort_colnum),
		 r2->get_string(tablelist_qsort_colnum));
      break;
    default:
      break;
    }
  if(tablelist_qsort_doinverse)
    ret=-ret;

  if(tablelist_qsort_active>=0
     && r1->get_type(tablelist_qsort_active)==TABLE_INT)
    {
      if(r1->get_int(tablelist_qsort_active)==1 &&
	 r2->get_int(tablelist_qsort_active)==0)
	ret=-1;
      else if(r1->get_int(tablelist_qsort_active)==0 &&
	 r2->get_int(tablelist_qsort_active)==1)
	ret=1;
    }

  return ret;
} /* compare_rows */


void tablelist::sort_by_column(int column_number, bool inverse)
{
  tablelist_qsort_active=table_attrib->get_position("active");

  sort_column_num=tablelist_qsort_colnum=column_number;
  
  if(inverse)
    tablelist_qsort_doinverse=1;
  else
    tablelist_qsort_doinverse=0;
 
  qsort(rows, size_t(length), sizeof(table_row*), compare_rows);
}

void tablelist::sort_by_column(const char *name, bool inverse)
{
  int pos=get_column_number(name);
  if(pos>=0)
    sort_by_column(pos, inverse);
  else
    std::cerr << "Program error: sort_by_column(name) failed!" << std::endl;
}

void tablelist::sort_by_column(bool inverse, int key)
{
  int pos=get_column_number(key);
  if(pos>=0)
    sort_by_column(pos, inverse);
  else
    std::cerr << "Program error: sort_by_column(key) failed!" << std::endl;
}

int tablelist::sorted_by_column(void)
{
  return sort_column_num;
}

bool tablelist::is_equal(int rownum1, int rownum2)
{
  if(rownum1<0 || rownum2<0 || rownum1>=length || rownum2>=length)
    return false;
  return rows[rownum1]->is_equal(rows[rownum2]);
}

bool tablelist::is_equal(int rownum1, int rownum2, int colnum)
{
  if(rownum1<0 || rownum2<0 || rownum1>=length || rownum2>=length)
    return false;
  return rows[rownum1]->is_equal(rows[rownum2], colnum);
}

// Send contents to file:
void tablelist::to_csv(const char *filename)
{
  int i,j;

  FILE *f=fopen(filename, "w");
  if(!f)
    {
      std::cerr << (WHAT((char *) "Klarte ikke � �pne fil for skriving", 
		    (char *) "Could not open file for writing!")) << std::endl;
      return;
    }

  for(i=0;i<table_attrib->get_size();i++)
    fprintf(f,"%s%s", table_attrib->get_name(i),
	    i<(table_attrib->get_size()-1) ? ";" : "\n");
  
  for(j=0;j<length;j++)
    {
      for(i=0;i<table_attrib->get_size();i++)
	{
	  rows[j]->print(f,i);
	  if(i<(table_attrib->get_size()-1))
	    fprintf(f,";");
	  else
	    fprintf(f,"\n");
	}
    }
  
  fclose(f);
}

char **get_csv_strings(const char *line, int *linelen)
{
  int i,len=1,slen=strlen(line);
  for(i=0;i<slen;i++)
    if(line[i]==';')
      len++;
  
  *linelen=len;
  char **str=new char*[len];
  for(i=0;i<len;i++)
    str[i]=new char[slen];
  
  int j=0,k=0;
  for(i=0;i<slen;i++)
    {
      if(line[i]==';' || line[i]=='\0' || line[i]=='\r')
	{
	  str[k][j]='\0';
	  j=0;
	  k++;
	}
      else
	{
	  str[k][j]=line[i];
	  j++;
	}
    }

  return str;
}

// Read contents from csv file. Only for tablelist
// objects with predefined attributed. Checks if attribute
// names correspond, and if not or any other operation failed,
// returns false.
bool tablelist::from_csv(const char *filename)
{
  std::ifstream in;
  
  in.open(filename, std::ios::in);
  if(in.fail())
    {
      std::cerr << (WHAT((char *) "Klarte � �pne filen ", 
			 (char *) "Failed to open file ")) << filename << std::endl;
      return false;
    }
  
  char line[1000];
  in.getline(line,999);
  // read first line and compare to already existing
  int i,linelen;
  char **attribnames=get_csv_strings(line, &linelen);
  if(linelen!=table_attrib->get_size())
    {
      std::cerr << (WHAT((char *) "Antall kolonner i filen matcher ikke de "
			 "predefinerte kolonnene!", 
			 (char *) "The number of columns in the file does not "
			 "match the predfined number!")) << std::endl;
      return false;
    }
  
  for(i=0;i<linelen;i++)
    {
      char *tablename_i=table_attrib->get_name(i);
      if(strcmp(attribnames[i], tablename_i))
	{
	  std::cerr << (WHAT((char *) "Kolonnenavnene i filen matcher ikke de "
			     "predefinerte navnene for kolonne nr. ", 
			     (char *) "The column names in the file do not "
			     "match the predefined ones for column "
			     "number ")) << 
	    i << "!" << std::endl;
	  return false;
	}
    }
  doubledelete(attribnames,linelen);
  
  int lineno=1;
  in.getline(line,999);
  while(!in.fail())
    {
      lineno++;
      
      char **linecontents=get_csv_strings(line, &linelen);
      if(linelen!=table_attrib->get_size())
	{
	  std::cerr << (WHAT((char *) "Antall kolonner i filen matcher ikke "
			     "de predefinerte kolonnene for linje nummer ", 
			     (char *) "The number of columns in the file "
			     "does not match the predfined number for "
			     "line number ")) <<  
	    lineno << std::endl;
	  return false;
	}
      
      table_row *newrow=new table_row(table_attrib);
      for(i=0;i<linelen;i++)
	newrow->set(i, linecontents[i]);
      
      insert_row(length, newrow);
      
      doubledelete(linecontents,linelen);
      delete newrow;
      
      in.getline(line,999);
    }

  in.close();
  
  return true;
}
