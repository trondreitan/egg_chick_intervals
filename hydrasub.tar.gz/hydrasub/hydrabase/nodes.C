/*
 * $Id: nodes.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/nodes.C $
 */

#include <hydrasub/hydrabase/nodes.H>
#include <cstdlib>
#include <cmath>


thread::thread()
{
  r=0.0;
  m=0.0;
  g=0.0;
  f0=0.0;
  a=0.0;
  d=0.0;

  init();
}

thread::thread(double r_, double m_, double a_, double f0_, double g_, 
	       double d_, node *origin_, node *destination_, 
	       bool inchild1,  bool inchild2, 
	       bool outchild1, bool outchild2)
{
  r=r_;
  m=m_;
  a=a_;
  f0=f0_;
  g=g_;
  d=d_;
  origin=origin_;
  destination=destination_;

  init();

  keep_in_child1=inchild1;
  keep_in_child2=inchild2;
  keep_out_child1=outchild1;
  keep_out_child2=outchild2;
}

thread::thread(thread *origthread, node *origin_, node *destination_, 
	       bool inchild1,  bool inchild2, 
	       bool outchild1, bool outchild2)
{
  copy_thread(origthread);
  origin=origin_;
  destination=destination_;

  init();

  keep_in_child1=inchild1;
  keep_in_child2=inchild2;
  keep_out_child1=outchild1;
  keep_out_child2=outchild2;
}

thread::~thread()
{
  //node *dbuffer=destination;
  //destination = NULL;
  //delete dbuffer;
}

void thread::init(void)
{
  strength=r;
  current_r=r;
  fire=0.0;
  keep_in_child1=keep_in_child2=keep_out_child1=keep_out_child2=true;
}

node *thread::get_orig(void)
{
  return origin;
}

node *thread::get_dest(void)
{
  return destination;
}

bool thread::keep_inchild1(void)
{
  return keep_in_child1;
}

bool thread::keep_inchild2(void)
{
  return keep_in_child2;
}

bool thread::keep_outchild1(void)
{
  return keep_out_child1;
}

bool thread::keep_outchild2(void)
{
  return keep_out_child2;
}


void thread::remove_from_inchild1(void)
{
  keep_in_child1=false;
}

void thread::remove_from_inchild2(void)
{
  keep_in_child2=false;
}

void thread::remove_from_outchild1(void)
{
  keep_out_child1=false;
}

void thread::remove_from_outchild2(void)
{
  keep_out_child2=false;
}


double thread::get_r(void)
{
  return r;
}

double thread::get_m(void)
{
  return m;
}

double thread::get_a(void)
{
  return a;
}

double thread::get_f0(void)
{
  return f0;
}

double thread::get_g(void)
{
  return g;
}

double thread::get_d(void)
{
  return d;
}


void thread::change_r(double new_r)
{
  r=new_r;
  strength=r;
  current_r=r;
}

void thread::change_m(double new_m)
{
  m=new_m;
}

void thread::change_a(double new_a)
{
  a=new_a;
}

void thread::change_f0(double new_f0)
{
  f0=new_f0;
}

void thread::change_g(double new_g)
{
  g=new_g;
}

void thread::change_d(double new_d)
{
  d=new_d;
}


void thread::increment(void)
{
  double Reaction=0.0;

  if(destination && origin)
    {
      double destfire=destination->get_fire();
      
      if(destination->get_output_fire()!=MISSING_VALUE)
	destfire=destination->get_output_fire();
      
      Reaction=(origin->get_old_fire() - f0) *
	(destfire - f0) / (1.0 - f0) / (1.0 - f0);
    }

  strength = current_r + m*(strength-current_r) + a*Reaction;
  current_r = (1.0-d)*(current_r + g*(strength-current_r));

  if(origin)
    fire = origin->get_fire();
  else
    fire=0.0;
}

void thread::do_fire(double fire_value)
{
  fire=fire_value;
}

double thread::get_fire(void)
{
  return fire;
}

double thread::get_strength(void)
{
  return strength;
}

void thread::change_var(int varnum, bool absolute, double proc)
{
  switch(varnum % 6)
    {
    case 0:
      increase_r(absolute, proc);
      break;
    case 1:
      increase_m(absolute, proc);
      break;
    case 2:
      increase_a(absolute, proc);
      break;
    case 3:
      increase_f0(absolute, proc);
      break;
    case 4:
      increase_g(absolute, proc);
      break;
    case 5:
      increase_d(absolute, proc);
      break;
    }
}

void thread::increase_r(bool absolute, double proc)
{
  if(absolute)
    r += proc/100.0;
  else
    r += r*proc/100.0;
  
  strength=r;
  current_r=r;
}

void thread::decrease_r(bool absolute, double proc)
{
  if(absolute)
    r -= proc/100.0;
  else
    r -= r*proc/100.0;

  strength=r;
  current_r=r;
}


void thread::increase_m(bool absolute, double proc)
{
  if(absolute)
    m += proc/100.0;
  else
    m += m*proc/100.0;
}

void thread::decrease_m(bool absolute, double proc)
{
  if(absolute)
    m -= proc/100.0;
  else
    m -= m*proc/100.0;
}


void thread::increase_a(bool absolute, double proc)
{
  if(absolute)
    a += proc/100.0;
  else
    a += a*proc/100.0;
}

void thread::decrease_a(bool absolute, double proc)
{
  if(absolute)
    a -= proc/100.0;
  else
    a -= a*proc/100.0;
}


void thread::increase_f0(bool absolute, double proc)
{
  if(absolute)
    f0 += proc/100.0;
  else
    f0 += f0*proc/100.0;
}

void thread::decrease_f0(bool absolute, double proc)
{
  if(absolute)
    f0 -= proc/100.0;
  else
    f0 -= f0*proc/100.0;
}

  
void thread::increase_g(bool absolute, double proc)
{
  if(absolute)
    g += proc/100.0;
  else
    g += g*proc/100.0;
}

void thread::decrease_g(bool absolute, double proc)
{
  if(absolute)
    g -= proc/100.0;
  else
    g -= g*proc/100.0;
}

void thread::increase_d(bool absolute, double proc)
{
  if(absolute)
    d += proc/100.0;
  else
    d += d*proc/100.0;
}

void thread::decrease_d(bool absolute, double proc)
{
  if(absolute)
    d -= proc/100.0;
  else
    d -= d*proc/100.0;
}

void thread::copy_thread(thread *origthread)
{
  r=origthread->r;
  m=origthread->m;
  a=origthread->a;
  f0=origthread->f0;
  g=origthread->g;
  d=origthread->d;
}

void thread::print(std::ostream &out)
{
  char buffer[200];
  sprintf(buffer, "r=%f m=%f a=%f f0=%f g=%f d=%f", 
	  r, m, a, f0, g, d);
  out << buffer << std::endl;
}




threadlist::threadlist(thread *th, threadlist *previtem) :
  double_linked_list( (double_linked_list *) previtem, NULL) 
{
  contents = th;
}

threadlist::~threadlist()
{
  threadlist *next = get_next_threadlistelement();
  
  removefromlist();

  if(next)
    delete next;
}

threadlist *threadlist::get_threadlistelement_number(int num)
{
  return (threadlist *) get_rel_next(num);
}

threadlist *threadlist::get_next_threadlistelement(void)
{
  return (threadlist *) getnext();
}

thread *threadlist::get_thread(void)
{
  return contents;
}

void threadlist::append_threadlistelement(threadlist *newitem)
{
  append((double_linked_list *) newitem);
}




// init
void node::init(void)
{
  s=olds=current_r=r;
  fire=oldfire=0.0;
  in_synapses = in_tail = out_synapses = out_tail = NULL;
  thread_from_child1_to_child2 = thread_from_child2_to_child1 = true;
  outputfire=MISSING_VALUE;
  fatigue=0.0;
  fatigue_level=0.0;
  fatigue_decrease=0.0;
  reload=0.0;
  lastfire=10000;
}


// cleanup and removes all in- and outgoing threads.
void node::cleanup(void)
{  
  if(out_synapses)
    {
      // traverse the out-threads;
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	{
	  thread *th=ptr->get_thread();
	  node *dest=th->destination;

	  if(dest && dest!=this)
	    dest->remove_synaps(th);
	  else
	    std::cout << "No destination!" << std::endl;

	  delete th;
	}

      delete out_synapses;
    }

  if(in_synapses)
    {
      // traverse the out-threads;
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	{
	  thread *th=ptr->get_thread();
	  node *orig=th->origin;

	  if(orig && orig!=this)
	    orig->remove_synaps(th);
	  else
	    std::cout << "No origin!" << std::endl;

	  delete th;
	}

      delete in_synapses;
    }
}

node::node(node *orignode)
{
  r=orignode->r;
  m=orignode->m;
  x0=orignode->x0;
  gamma=orignode->gamma;
  l=orignode->l;
  d=orignode->d;
  g=orignode->g;
  reload=orignode->reload;
  fatigue_level=orignode->fatigue_level;
  fatigue_decrease=orignode->fatigue_decrease;

  init();
}

node::node(double r_, double m_, double x0_, double l_, double gamma_,
	   double d_, double g_,
	   double reload_, double fatigue_level_, double fatigue_decrease_)
{
  r=r_;
  m=m_;
  x0=x0_;
  l=l_;
  gamma=gamma_;
  d=d_;
  g=g_;
  reload=reload_;
  fatigue_level=fatigue_level_;
  fatigue_decrease=fatigue_decrease_;

  init();
}

// cleans up and removes all in- and outgoing threads.
node::~node()
{
  cleanup();
}

thread *node::thread_in_to_node(double r_, double m_, double a_, 
				double f0_, double g_, double d_,
				node *outnode)
{
  thread *th=new thread(r_, m_, a_, f0_, g_, d_, outnode, this); 

  threadlist *newthread  = new threadlist(th, in_tail);
  in_tail = newthread;
  if(!in_synapses)
    in_synapses = newthread;
  
  if(outnode)
    {
      threadlist *newthread2 = new threadlist(th, outnode->out_tail);
      outnode->out_tail = newthread2;
      if(!outnode->out_synapses)
	outnode->out_synapses = newthread2;
    }

  return th;
}

thread *node::thread_out_of_node(double r_, double m_, double a_, 
				 double f0_, double g_, double d_,
				 node *innode)
{
  thread *th=new thread(r_, m_, a_, f0_, g_, d_, this, innode); 

  threadlist *newthread  = new threadlist(th, out_tail);
  out_tail = newthread;
  if(!out_synapses)
    out_synapses = newthread;
  
  if(innode)
    {
      threadlist *newthread2 = new threadlist(th, innode->in_tail);
      innode->in_tail = newthread2;
      if(!innode->in_synapses)
	innode->in_synapses = newthread2;
    }

  return th;
}

thread *node::thread_in_to_node(thread *origthread,
				node *outnode)
{
  return thread_in_to_node(origthread->get_r(), origthread->get_m(), 
			   origthread->get_a(), origthread->get_f0(), 
			   origthread->get_g(), origthread->get_d(), 
			   outnode);
}

thread *node::thread_out_of_node(thread *origthread,
				 node *innode)
{
  return thread_out_of_node(origthread->get_r(), origthread->get_m(), 
			    origthread->get_a(), origthread->get_f0(), 
			    origthread->get_g(), origthread->get_d(), 
			    innode);
}

// split the node into two "child nodes"
void node::split_node(node **newnode1, node **newnode2,
		      thread *standard_thread)
{
  node *n1=new node(this);
  node *n2=new node(this);
  threadlist *ptr = NULL;
  
  for(ptr=out_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    {
      thread *th=ptr->get_thread();

      if(th->keep_outchild1())
	n1->thread_out_of_node(th, th->destination);

      if(th->keep_outchild2())
	n2->thread_out_of_node(th, th->destination); 
    }

  for(ptr=in_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    {
      thread *th=ptr->get_thread();

      if(th->keep_inchild1())
	n1->thread_in_to_node(th, th->origin);

      if(th->keep_inchild2())
	n2->thread_in_to_node(th, th->origin);
    }

  if(thread_from_child1_to_child2 && standard_thread)
    n1->thread_out_of_node(standard_thread, n2);

  if(thread_from_child2_to_child1 && standard_thread)
    n2->thread_out_of_node(standard_thread, n1);

  *newnode1=n1;
  *newnode2=n2;
}

threadlist *node::get_in_threads(void)
{
  return in_synapses;
}

threadlist *node::get_out_threads(void)
{
  return out_synapses;
}








void node::start_increment(void)
{
  double input=0.0,transformed_s, x=drand48();

  for(threadlist *ptr=in_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    {
      thread *th=ptr->get_thread();

      if(th)
	input += th->get_strength() * th->get_fire();
    }

  s = current_r + m*(s-current_r) + input;
  current_r = current_r + g*(s-current_r);
  transformed_s = 1.0/(1.0+exp(-(s-x0-fatigue-
				 10000.0*exp(-reload*double(lastfire)))/l));
  fatigue /= (1.0+fatigue_decrease); 
  

  fire = gamma*transformed_s + 
    (1.0-gamma)/(1.0 + exp((log(x/(x+1.0))-
			    log(transformed_s/(transformed_s+1.0)))/gamma));  

  fatigue += fatigue_level*fire;
  if(fatigue>10000.0)
    fatigue=10000.0;

  if(fire>0.5)
    lastfire=1;
  else
    lastfire++;
}

void node::middle_increment(void)
{
  for(threadlist *ptr=out_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    if(ptr->get_thread())
      ptr->get_thread()->increment();
}

void node::end_increment(void)
{
  s = s * (1.0 - fire*d);
  oldfire=fire;
  olds=s;
}

thread *node::getthread(int number)
{
  if(!out_synapses)
    return NULL;

  if(out_synapses->number_of_elements() <= number)
    {
      number -= out_synapses->number_of_elements();
      if(!in_synapses || in_synapses->number_of_elements() <= number)
	return NULL;

      threadlist *ptr = in_synapses->get_threadlistelement_number(number);
      
      if(ptr)
	return ptr->get_thread();
      else
	return NULL;
    }

  return out_synapses->get_threadlistelement_number(number)->get_thread();
}
  

void node::remove_synaps(int number)
{
  //if( !out_synapses || number < 0 )
    return;

  int totnum=out_synapses->number_of_elements()+
    in_synapses->number_of_elements();
  thread *th;

  number %= totnum;

  if(out_synapses->number_of_elements() <= number)
    {
      number -= out_synapses->number_of_elements();
      if(!in_synapses || in_synapses->number_of_elements() <= number)
	return;

      threadlist *ptr = in_synapses->get_threadlistelement_number(number);
      
      if(!ptr)
	return;

      th=ptr->get_thread();
      if(th && th->destination && th->destination!=this)
	th->destination->remove_synaps(th);

      if(ptr==in_synapses)
	in_synapses=in_synapses->get_next_threadlistelement();
      if(ptr==in_tail)
	in_tail = (threadlist *) in_tail->getprev();

      ptr->removefromlist();
      delete ptr;
      //if(th)
      //delete th;

      return;
    }

  threadlist *ptr=out_synapses->get_threadlistelement_number(number);
  
  if(!ptr)
    return;

  th=ptr->get_thread();
  if(th && th->origin && th->origin!=this)
    th->origin->remove_synaps(th);

  if(ptr==out_synapses)
    out_synapses=out_synapses->get_next_threadlistelement();
  if(ptr==out_tail)
    out_tail = (threadlist *) out_tail->getprev();

  ptr->removefromlist();
  
  delete ptr;
  //if(th)
  //delete th;
}

void node::remove_synaps(thread *th)
{
  threadlist *ptr;

  for(ptr=out_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    if(ptr->get_thread()==th)
      {
	if(ptr==out_synapses && ptr)
	  out_synapses=ptr->get_next_threadlistelement();
	if(ptr==out_tail && ptr)
	  out_tail = (threadlist *) out_tail->getprev();

	ptr->removefromlist();
	delete ptr;

	return;
      }

  for(ptr=in_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    if(ptr->get_thread()==th)
      {
	if(ptr==in_synapses && ptr)
	  in_synapses=ptr->get_next_threadlistelement();
	if(ptr==in_tail && ptr)
	  in_tail = (threadlist *) in_tail->getprev();

	ptr->removefromlist();
	delete ptr;

	return;
      }
}  

void node::remove_synaps_fromchild1(int number)
{
  int totnum=out_synapses->number_of_elements()+
    in_synapses->number_of_elements();

  if(number==0)
    thread_from_child1_to_child2=false;
  number--;

  if(!out_synapses || number < 0 )
    return;

  number %= totnum;

  if(out_synapses->number_of_elements() <= number)
    {
      number -= out_synapses->number_of_elements();
      if(!in_synapses || in_synapses->number_of_elements() <= number)
	return;

      thread *ptr = 
	in_synapses->get_threadlistelement_number(number)->get_thread();
      
      if(ptr)
	ptr->remove_from_inchild1();

      return;
    }

  thread *ptr=out_synapses->get_threadlistelement_number(number)->get_thread();

  if(ptr)
    ptr->remove_from_outchild1();
}  

void node::remove_synaps_fromchild2(int number)
{
  if(number==0)
    thread_from_child2_to_child1=false;
  number--;

  if( !out_synapses || number < 0 )
    return;

  if(out_synapses->number_of_elements() <= number)
    {
      number -= out_synapses->number_of_elements();
      if(!in_synapses || in_synapses->number_of_elements() <= number)
	return;

      thread *ptr = 
	in_synapses->get_threadlistelement_number(number)->get_thread();
      
      if(ptr)
	ptr->remove_from_inchild2();

      return;
    }

  thread *ptr=out_synapses->get_threadlistelement_number(number)->get_thread();

  if(ptr)
    ptr->remove_from_outchild2();
}  

double node::get_r(void)
{
  return r;
}
  
double node::get_m(void)
{
  return m;
}
  
double node::get_x0(void)
{
  return x0;
}
  
double node::get_l(void)
{
  return l;
}
  
double node::get_g(void)
{
  return g;
}
  
double node::get_gamma(void)
{
  return gamma;
}
  
double node::get_d(void)
{
  return d;
}
  
double node::get_reload(void)
{
  return reload;
}

double node::get_fatigue_level(void)
{
  return fatigue_level;
}

double node::get_fatigue_decrease(void)
{
  return fatigue_decrease;
}


double node::get_state(void)
{
  return s;
}
  
double node::get_default_state(void)
{
  return current_r;
}
  
double node::get_old_state(void)
{
  return olds;
}
  

double node::get_fire(void)
{
  return fire;
}
  

double node::get_output_fire(void)
{
  return outputfire;
}

void node::set_fire(double newfire)
{
  fire = newfire;
}


void node::set_output_fire(double newfire)
{
  outputfire=newfire;
}

double node::get_old_fire(void)
{
  return oldfire;
}
  

void node::change_r(double new_r)
{
  r=new_r;
}
  
void node::change_m(double new_m)
{
  m=new_m;
}
  
void node::change_x0(double new_x0)
{
  x0=new_x0;
}
  
void node::change_l(double new_l)
{
  l=new_l;
}
  
void node::change_gamma(double new_gamma)
{
  gamma=new_gamma;
}
  
void node::change_g(double new_g)
{
  g=new_g;
}
  
void node::change_d(double new_d)
{
  d=new_d;
}
  
void node::change_reload(double new_reload)
{
  reload=new_reload;
}

void node::change_fatigue_level(double new_fatigue_level)
{
  fatigue_level=new_fatigue_level;
}

void node::change_fatigue_decrease(double new_fatigue_decrease)
{
  fatigue_decrease=new_fatigue_decrease;
}


void node::change_var(int varnum, bool absolute, double proc)
{
  switch(varnum % 10)
    {
    case 0:
      increase_r(absolute, proc);
      break;
    case 1:
      increase_m(absolute, proc);
      break;
    case 2:
      increase_x0(absolute, proc);
      break;
    case 3:
      increase_l(absolute, proc);
      break;
    case 4:
      increase_gamma(absolute, proc);
      break;
    case 5:
      increase_g(absolute, proc);
      break;
    case 6:
      increase_d(absolute, proc);
      break;
    case 7:
      increase_reload(absolute, proc);
      break;
    case 8:
      increase_fatigue_level(absolute, proc);
      break;
    case 9:
      increase_fatigue_decrease(absolute, proc);
      break;
    }
}

void node::change_threads(int varnum, bool in, bool out, 
			  bool absolute, double proc)
{
  switch(varnum % 6)
    {
    case 0:
      increase_tr(in, out, absolute, proc);
      break;
    case 1:
      increase_tm(in, out, absolute, proc);
      break;
    case 2:
      increase_ta(in, out, absolute, proc);
      break;
    case 3:
      increase_tf0(in, out, absolute, proc);
      break;
    case 4:
      increase_tg(in, out, absolute, proc);
      break;
    case 5:
      increase_td(in, out, absolute, proc);
      break;
    }
}

void node::change_thread(int varnum, bool absolute, 
			 double proc, int threadnum)
{
  switch(varnum % 6)
    {
    case 0:
      increase_tnr(absolute, threadnum, proc);
      break;
    case 1:
      increase_tnm(absolute, threadnum, proc);
      break;
    case 2:
      increase_tna(absolute, threadnum, proc);
      break;
    case 3:
      increase_tnf0(absolute, threadnum, proc);
      break;
    case 4:
      increase_tng(absolute, threadnum, proc);
      break;
    case 5:
      increase_tnd(absolute, threadnum, proc);
      break;
    }
}

void node::increase_x0(bool absolute, double proc)
{
  if(absolute)
    x0 += proc/100.0;
  else
    x0 += x0*proc/100.0;
}
  
void node::decrease_x0(bool absolute, double proc)
{
  if(absolute)
    x0 -= proc/100.0;
  else
    x0 -= x0*proc/100.0;
}
  

void node::increase_l(bool absolute, double proc)
{
  if(absolute)
    l += proc/100.0;
  else
    l += l*proc/100.0;
}
  
void node::decrease_l(bool absolute, double proc)
{
  if(absolute)
    l -= proc/100.0;
  else
    l -= l*proc/100.0;
}
  

void node::increase_m(bool absolute, double proc)
{
  if(absolute)
    m += proc/100.0;
  else    
    m += m*proc/100.0;
}
  
void node::decrease_m(bool absolute, double proc)
{
  if(absolute)
    m -= proc/100.0;
  else
    m -= m*proc/100.0;
}
  

void node::increase_r(bool absolute, double proc)
{
  if(absolute)
    r += proc/100.0;
  else
    r += r*proc/100.0;
}
  
void node::decrease_r(bool absolute, double proc)
{
  if(absolute)
    r -= proc/100.0;
  else
    r -= r*proc/100.0;
}
  

void node::increase_g(bool absolute, double proc)
{
  if(absolute)
    g += proc/100.0;
  else    
    g += g*proc/100.0;
}
  
void node::decrease_g(bool absolute, double proc)
{
  if(absolute)
    g -= proc/100.0;
  else
    g -= g*proc/100.0;
}
  

void node::increase_d(bool absolute, double proc)
{
  if(absolute)
    d += proc/100.0;
  else
    d += d*proc/100.0;
}
  
void node::decrease_d(bool absolute, double proc)
{
  if(absolute)
    d -= proc/100.0;
  else
    d -= d*proc/100.0;
}
  

void node::increase_gamma(bool absolute, double proc)
{
  if(absolute)
    gamma += proc/100.0;
  else
    gamma += gamma*proc/100.0;
}
  
void node::decrease_gamma(bool absolute, double proc)
{
  if(absolute)
    gamma -= proc/100.0;
  else
    gamma -= gamma*proc/100.0;
}
  

void node::increase_reload(bool absolute, double proc)
{
  if(absolute)
    reload += proc/100.0;
  else
    reload += gamma*proc/100.0;
}
  
void node::decrease_reload(bool absolute, double proc)
{
  if(absolute)
    reload -= proc/100.0;
  else
    reload -= gamma*proc/100.0;
}
  

void node::increase_fatigue_level(bool absolute, double proc)
{
  if(absolute)
    fatigue_level += proc/100.0;
  else
    fatigue_level += gamma*proc/100.0;
}
  
void node::decrease_fatigue_level(bool absolute, double proc)
{
  if(absolute)
    fatigue_level -= proc/100.0;
  else
    fatigue_level -= gamma*proc/100.0;
}
  
void node::increase_fatigue_decrease(bool absolute, double proc)
{
  if(absolute)
    fatigue_decrease += proc/100.0;
  else
    fatigue_decrease += gamma*proc/100.0;
}
  
void node::decrease_fatigue_decrease(bool absolute, double proc)
{
  if(absolute)
    fatigue_decrease -= proc/100.0;
  else
    fatigue_decrease -= gamma*proc/100.0;
}
  


void node::increase_tr(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_r(absolute, proc);
    }
  
  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_r(absolute, proc);
    }
}
  
void node::decrease_tr(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_r(absolute, proc);
    }
  
  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_r(absolute, proc);
    }
}

void node::increase_tm(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_m(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_m(absolute, proc);
    }
}
  
void node::decrease_tm(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr;
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_m(absolute, proc);
    }
  
  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr;
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_m(absolute, proc);
    }
}  


void node::increase_ta(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_a(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_a(absolute, proc);
    }
}
  
void node::decrease_ta(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_r(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_r(absolute, proc);
    }
}
  

void node::increase_tf0(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_f0(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_f0(absolute, proc);
    }
}

void node::decrease_tf0(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_f0(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_f0(absolute, proc);
    }
}

void node::increase_tg(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_g(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_g(absolute, proc);
    }
}
  
void node::decrease_tg(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_g(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_g(absolute, proc);
    }
}
  
void node::increase_td(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_d(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->increase_d(absolute, proc);
    }
}
  
void node::decrease_td(bool in, bool out, bool absolute, double proc)
{
  if(out)
    {
      for(threadlist *ptr=out_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_d(absolute, proc);
    }

  if(in)
    {
      for(threadlist *ptr=in_synapses; ptr; 
	  ptr=ptr->get_next_threadlistelement())
	if(ptr->get_thread())
	  ptr->get_thread()->decrease_d(absolute, proc);
    }
}
  


void node::increase_tnr(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->increase_r(absolute, proc);
}
  
void node::decrease_tnr(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->decrease_r(absolute, proc);
}
  

void node::increase_tnm(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->increase_m(absolute, proc);
}
  
void node::decrease_tnm(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->decrease_m(absolute, proc);
}
  

void node::increase_tna(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->increase_a(absolute, proc);
}
  
void node::decrease_tna(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->decrease_a(absolute, proc);
}
  

void node::increase_tng(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->increase_g(absolute, proc);
}
  
void node::decrease_tng(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->decrease_g(absolute, proc);
}
  
void node::increase_tnd(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->increase_d(absolute, proc);
}
  
void node::decrease_tnd(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->decrease_d(absolute, proc);
}
  

void node::increase_tnf0(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->increase_f0(absolute, proc);
}
  
void node::decrease_tnf0(bool absolute, int num, double proc)
{
  thread *th=getthread(num);

  if(th)
    th->decrease_f0(absolute, proc);
}



// conversion functions;  
double p2r(double pval)
{
  return log(pval/(1.0-pval));
}

double r2p(double r)
{
  return 1.0/(1.0+exp(-r));
}

double r2rp(double r)
{
  return r/2.0+sqrt((r/2.0)*(r/2.0)+1);
}

double rp2r(double rp)
{
  return rp - 1.0/rp;
}

double p2rp(double p)
{
  return r2rp(p2r(p));
}

double rp2p(double rp)
{
  return r2p(rp2r(rp));
}

void node::print(std::ostream &out)
{
  char buffer[200];

  threadlist *ptr;
  sprintf(buffer, "r=%f m=%f x0=%f l=%f ga=%f d=%f g=%f "
	  "re=%f fl=%f fd=%f",
	  r, m, x0, l ,gamma, d, g, reload, fatigue_level, 
	  fatigue_decrease);
  out << buffer << std::endl;
  out << "in_synapses:" << std::endl;
  for(ptr=in_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    ptr->get_thread()->print(out);
  out << "out_synapses:" << std::endl;
  for(ptr=out_synapses; ptr; ptr=ptr->get_next_threadlistelement())
    ptr->get_thread()->print(out);
}
