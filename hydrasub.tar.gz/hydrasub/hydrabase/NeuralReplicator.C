/*
 * $Id: NeuralReplicator.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydrabase/NeuralReplicator.C $
 */

#include <hydrasub/hydrabase/NeuralReplicator.H>
#include <cmath>

const char compsign[]={'=', '<', '>', '!'};

const INSTRCUTION_TYPE instr_type[NUM_INSTRUCTIONS]={ACTIVATE, DEACTIVATE, 
						     ACTIVATEL, DEACTIVATEL,
						     CHN, CHNPROS, CHNODE, 
						     CHSTTHREAD,
						     CHALLTH, CHTHREAD, 
						     STOP, REM, REM1, REM2, 
						     IF1, IF2, IF3, IF4,
						     INC1, INC2, 
						     DEC1, DEC2,
						     HALF1, HALF2, 
						     DOUBLE1, DOUBLE2, 
						     NEG1, NEG2,
						     CHANGEVAR1,CHANGEVAR2,
						     CHANGEVAR3,CHANGEVAR4,
						     CHANGEVAR5};

const bool var1_isreal[]={false,false,false,false,
			     true,true,true,true};

const bool var2_isreal[]={false,true,true,true,true,true,true,
			     true,true,true,true,true,true,true,
			     true};
const bool var3_isreal[]={false, false, false, false, false,
			     false, false, false, false};

// ************************************************
//
//                 NEURALREPLICATOR
//
// This set of classes and methods should provide
// 'machine language' for making neural nets of
// the type described in 'nodes.H'. It should be
// possible to mutate the code, usch that another 
// net might be made in the next replication of
// the development of a neural net. 
//
//                 Trond Reitan
//                  19/11-2000
//
// ************************************************


bool compare_using_sign(COMP_SIGN sign, unsigned int integer1, 
			   unsigned int integer2)
{
    switch(sign)
    {
	case EQUAL:
	    if(integer1==integer2)
		return true;
	    break;
	case LESSTHAN: 
	    if(integer1<integer2)
		return true;
	    break;
	case GREATERTHAN:
	    if(integer1>integer2)
		return true;
	    break;
	case NOTEQUAL:
	    if(integer1!=integer2)
		return true;
	    break;
    }
    
    return false;
}


bool compare_using_sign(COMP_SIGN sign, double real1, double real2)
{
    switch(sign)
    {
	case EQUAL:
	    if(real1==real2)
		return true;
	    break;
	case LESSTHAN: 
	    if(real1<real2)
		return true;
	    break;
	case GREATERTHAN:
	    if(real1>real2)
		return true;
	    break;
	case NOTEQUAL:
	    if(real1!=real2)
		return true;
	    break;
    }
    
    return false;
}


//             instruction
// Contains meta-data about the different instructions that can be found
// in areplicator. It holds the four different codes, as well as
// argument length of each instruction.  

// Takes the place of the pointer as input;
instruction::instruction(replicatorset *rset, unsigned int cromnum, 
			 unsigned int pos, INSTRCUTION_TYPE type)
{
    // int numcrom=rset->get_number_of_cromosomes();
    cromosome_strand *fcromptr=rset->get_father_strand(cromnum);
    cromosome_strand *mcromptr=rset->get_mother_strand(cromnum);
    // unsigned int cromlen1 = fcromptr->get_bitlength();
    // unsigned int cromlen2 = mcromptr->get_bitlength();
    
    /*
      unsigned int fcromnum=fcromptr->get_unsigned_int(pos, 4) % numcrom;
      unsigned int mcromnum=mcromptr->get_unsigned_int(pos, 4) % numcrom;
      unsigned int fpos=fcromptr->get_unsigned_int(pos+4, 16) & cromlen1;
      unsigned int mpos=mcromptr->get_unsigned_int(pos+4, 16) % cromlen2;
    */
    
    
    activated *fatherpattern=rset->force_find_pattern(cromnum, pos, 10, false,
						      true, true);
    activated *motherpattern=rset->force_find_pattern(cromnum, pos, 10, true,
						      true, true);		      
    unsigned int fcromnum=fatherpattern->get_crom_num();
    unsigned int mcromnum=motherpattern->get_crom_num();
    unsigned int fpos=fatherpattern->get_position();
    unsigned int mpos=motherpattern->get_position();
    
    cromosome_strand *fcrom1=rset->get_father_strand(fcromnum);
    cromosome_strand *fcrom2=rset->get_father_strand(mcromnum);
    cromosome_strand *mcrom1=rset->get_mother_strand(fcromnum);
    cromosome_strand *mcrom2=rset->get_mother_strand(mcromnum);
    
    // get code length from father and mother strand;
    len1=MAXIM(4,fcromptr->get_unsigned_int(pos+20, 4));
    len2=MAXIM(4,mcromptr->get_unsigned_int(pos+20, 4));  
    
    // get codes from father and mother strand;
    code1 = fcrom1 ? fcrom1->get_unsigned_int(fpos, len1) : 0;
    code2 = fcrom2 ? fcrom2->get_unsigned_int(mpos, len2) : 0;
    code3 = mcrom1 ? mcrom1->get_unsigned_int(fpos, len1) : 0;
    code4 = mcrom2 ? mcrom2->get_unsigned_int(mpos, len2) : 0;
    
    metalen=25; // initialize meta length
    
    // initialize otal lengths
    totlen1=len1; 
    totlen2=len2;
    
    // store replicator set 
    repset=rset; 
    // store 
    typ=type;
    
    arglen11 = arglen12 = arglen13 = arglen14 = arglen21 = 
	arglen22 = arglen23 = arglen24 = 0;
    
    switch(type)
    {
	case ACTIVATE: 
	case DEACTIVATE: 
	    // get thread number lengths;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 3)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 3));
      
	    // get cromosome number lengths;
	    arglen12=MAXIM(2, fcromptr->get_unsigned_int(pos+33, 2)); 
	    arglen22=MAXIM(2, mcromptr->get_unsigned_int(pos+33, 2));

	    // get position lengths;
	    arglen13=MAXIM(2, fcromptr->get_unsigned_int(pos+37, 4)); 
	    arglen23=MAXIM(2, mcromptr->get_unsigned_int(pos+37, 4));

	    metalen += 28;
	    totlen1 += 1+1+1+1+2+1+1+2+arglen11+3+arglen12+arglen13;
	    totlen2 += 1+1+1+1+2+1+1+2+arglen21+3+arglen22+arglen23;

	    break;
	case ACTIVATEL: 
	case DEACTIVATEL:
	    // get thread number lengths;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 3)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 3));
      
	    // get cromosome number lengths;
	    arglen12=MAXIM(2, fcromptr->get_unsigned_int(pos+33, 2)); 
	    arglen22=MAXIM(2, mcromptr->get_unsigned_int(pos+33, 2));

	    // get position lengths;
	    arglen13=MAXIM(2, fcromptr->get_unsigned_int(pos+37, 4)); 
	    arglen23=MAXIM(2, mcromptr->get_unsigned_int(pos+37, 4));

	    // get length lengths;
	    arglen14=MAXIM(2, fcromptr->get_unsigned_int(pos+37, 4)); 
	    arglen24=MAXIM(2, mcromptr->get_unsigned_int(pos+37, 4));

	    metalen += 44;
	    totlen1 += 1+1+1+1+2+1+1+2+arglen11+3+arglen12+arglen13+arglen14;
	    totlen2 += 1+1+1+1+2+1+1+2+arglen21+3+arglen22+arglen23+arglen24;

	    break;
	case CHN:
	case CHNPROS: 

	    // get number/percentage lengths;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 4)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 4));

	    metalen += 16;
	    totlen1 += arglen11;
	    totlen2 += arglen21;

	    break;
	case CHALLTH:
	    totlen1 += 2; // two more bool variables in CHALLTH
	    totlen2 += 2;
	case CHNODE: 
	case CHSTTHREAD: 

	    // get variable number lengths;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 4)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 4));

	    // get percentage lengths;
	    arglen12=MAXIM(2, fcromptr->get_unsigned_int(pos+41, 4)); 
	    arglen22=MAXIM(2, mcromptr->get_unsigned_int(pos+41, 4));

	    metalen += 32;
	    totlen1 += 1 + arglen11 + arglen12;
	    totlen2 += 1 + arglen21 + arglen22;
      
	    break; 
	case CHTHREAD:
      
	    // get thread number lengths;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 4)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 4));

	    // get variable number lengths;
	    arglen12=MAXIM(2, fcromptr->get_unsigned_int(pos+41, 4)); 
	    arglen22=MAXIM(2, mcromptr->get_unsigned_int(pos+41, 4));

	    // get percentage lengths;
	    arglen13=MAXIM(2, fcromptr->get_unsigned_int(pos+57, 4)); 
	    arglen23=MAXIM(2, mcromptr->get_unsigned_int(pos+57, 4));

	    metalen += 48;
	    totlen1 += 1 + arglen11 + arglen12 + arglen13;
	    totlen2 += 1 + arglen21 + arglen22 + arglen23;
      

	    break; 
	case STOP:
	    // no input parameters
	    break; 
	case REM:
	case REM1:
	case REM2:
      
	    // get thread nmaxer lengths;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 4)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 4));

	    metalen += 16;
	    totlen1 += 2 + arglen11;
	    totlen2 += 2 + arglen21;

	    break;

	case IF1:
	case IF3:
      
	    // get var number length1;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 3)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 3));
      
	    // get var number length2;
	    arglen12=MAXIM(2, fcromptr->get_unsigned_int(pos+33, 3)); 
	    arglen22=MAXIM(2, mcromptr->get_unsigned_int(pos+33, 3));

	    // get action lengths;
	    arglen13=MAXIM(2, fcromptr->get_unsigned_int(pos+41, 4)); 
	    arglen23=MAXIM(2, mcromptr->get_unsigned_int(pos+41, 4));

	    metalen += 32;
	    totlen1 += 2+arglen11+arglen12+arglen13;
	    totlen2 += 2+arglen21+arglen22+arglen23;

	    break;

	case IF2:
	case IF4:
      
	    // get var number length;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 3)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 3));
      
	    // get number length;
	    arglen12=MAXIM(2, fcromptr->get_unsigned_int(pos+33, 4)); 
	    arglen22=MAXIM(2, mcromptr->get_unsigned_int(pos+33, 4));

	    // get action lengths;
	    arglen13=MAXIM(2, fcromptr->get_unsigned_int(pos+41, 4)); 
	    arglen23=MAXIM(2, mcromptr->get_unsigned_int(pos+41, 4));

	    metalen += 40;
	    totlen1 += 2+arglen11+arglen12+arglen13;
	    totlen2 += 2+arglen21+arglen22+arglen23;

	    break;

	case INC1:
	case INC2: 
	case DEC1:
	case DEC2:
	case HALF1:
	case HALF2: 
	case DOUBLE1:
	case DOUBLE2: 
	case NEG1:
	case NEG2:

	    // get var number length;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 3)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 3));

	    metalen += 8;
	    totlen1 += 2+arglen11;
	    totlen2 += 2+arglen21;

	    break;

	case CHANGEVAR1:
	case CHANGEVAR2:
	case CHANGEVAR3:
	case CHANGEVAR4:
	case CHANGEVAR5:

	    // get var number length1;
	    arglen11=MAXIM(2, fcromptr->get_unsigned_int(pos+25, 3)); 
	    arglen21=MAXIM(2, mcromptr->get_unsigned_int(pos+25, 3));
      
	    // get var number length2;
	    arglen12=MAXIM(2, fcromptr->get_unsigned_int(pos+33, 3)); 
	    arglen22=MAXIM(2, mcromptr->get_unsigned_int(pos+33, 3));

	    metalen += 16;
	    totlen1 += 5+arglen11+arglen12;
	    totlen2 += 5+arglen21+arglen22;
      
	    break;
	default:
	    break;
    }
}

// returns 0 if the instruction wasn't found, -1 if the 
// code was found from the father code and 1 if it came from the mother code
int instruction::check(cromosome_strand *strand, 
		       unsigned int pos)
{
    unsigned int fcheck1=0, fcheck2=0;

    if(!strand)
	return 0;

    fcheck1 = strand->get_unsigned_int(pos, len1); 
    fcheck2 = strand->get_unsigned_int(pos, len2);
  
    if(fcheck1!=0 && (fcheck1==code1 || fcheck1==code3))
	return -1;

    if(fcheck2!=0 && (fcheck2==code2 || fcheck2==code4))
	return 1;

    return 0;
}


INSTRCUTION_TYPE instruction::get_type(void)
{
    return typ;
}


unsigned int instruction::get_meta_length(void)
{
    return metalen;
}

unsigned int instruction::get_total_length1(void)
{
    return totlen1;
}

unsigned int instruction::get_code_length1(void)
{
    return len1;
}

unsigned int instruction::get_total_length2(void)
{
    return totlen2;
}

unsigned int instruction::get_code_length2(void)
{
    return len2;
}

// get ACT/DEACT-variables from the last checked posisiton
void instruction::get_act(cromosome_strand *strand, unsigned int pos,
			  bool fathercode,
			  bool *child1, bool *child2, 
			  bool *inthread, bool *outthread, 
			  COMP_SIGN *threadcomp, 
			  bool *male, bool *female, 
			  COMP_SIGN *gencomp, 
			  unsigned int *threadnum, unsigned int *gennum, 
			  unsigned int *actcromnum, unsigned int *actpos)
{
    *child1     = strand->get_bit(pos);
    *child2     = strand->get_bit(pos+1);
    *inthread   = strand->get_bit(pos+2);
    *outthread  = strand->get_bit(pos+3);
    *threadcomp = strand->get_comp_sign(pos+4);
    *male       = strand->get_bit(pos+6);
    *female     = strand->get_bit(pos+7);
    *gencomp    = strand->get_comp_sign(pos+8);
    *gennum     = strand->get_unsigned_int(pos+10, 3);

    if(fathercode) // found code from father-strand of cromosome 1 
    {
	*threadnum  = strand->get_unsigned_int(pos+13, arglen11);
      
	/*
	  activated *cp=repset->find_pattern(strand->get_cromosome_number(), 
	  pos+13+arglen11,
	  arglen13+arglen12, 
	  false, true, true);
	  if(cp)
	  {
	  *actcromnum = cp->get_crom_num();
	  *actpos     = cp->get_position();
	  delete cp;
	  }
	  else
	  {
	  *actcromnum = 2;
	  *actpos     = 0;
	  }
	*/
      
	*actcromnum = strand->get_unsigned_int(pos+13+arglen11, arglen12);
	*actpos     = strand->get_unsigned_long_int(pos+13+arglen11+arglen12, 
						    arglen13);
      
    }
    else // found code from mother-strand of cromosome 1
    {
	*threadnum  = strand->get_unsigned_int(pos+23, arglen21);

	/*
	  activated *cp=repset->find_pattern(strand->get_cromosome_number(), 
	  pos+13+arglen11,
	  arglen13+arglen12, 
	  true, true, true);
	  if(cp)
	  {
	  *actcromnum = cp->get_crom_num();
	  *actpos     = cp->get_position();
	  delete cp;
	  }
	  else
	  {
	  *actcromnum = 2;
	  *actpos     = 0;
	  }
	*/
      
	*actcromnum = strand->get_unsigned_int(pos+23+arglen21, arglen22);
	*actpos     = strand->get_unsigned_long_int(pos+13+arglen21+arglen22, 
						    arglen23);
    }
}

// get ACTL/DEACTL-variables from the last checked posisiton
void instruction::get_actl(cromosome_strand *strand, unsigned int pos,
			   bool fathercode,
			   bool *child1, bool *child2, 
			   bool *inthread, bool *outthread, 
			   COMP_SIGN *threadcomp, 
			   bool *male, bool *female, 
			   COMP_SIGN *gencomp, 
			   unsigned int *threadnum, unsigned int *gennum, 
			   unsigned int *actcromnum, 
			   unsigned int *actpos, 
			   unsigned int *actlen)
{
    *child1     = strand->get_bit(pos);
    *child2     = strand->get_bit(pos+1);
    *inthread   = strand->get_bit(pos+2);
    *outthread  = strand->get_bit(pos+3);
    *threadcomp = strand->get_comp_sign(pos+4);
    *male       = strand->get_bit(pos+6);
    *female     = strand->get_bit(pos+7);
    *gencomp    = strand->get_comp_sign(pos+8);
    *gennum     = strand->get_unsigned_int(pos+10, 3);

    if(fathercode) // found code from father-strand of cromosome 1 
    {
	*threadnum  = strand->get_unsigned_int(pos+13, arglen11);
	*actcromnum = strand->get_unsigned_int(pos+13+arglen11, arglen12);
	*actpos     = strand->get_unsigned_long_int(pos+13+arglen11+arglen12, 
						    arglen13);
	*actlen     = strand->get_unsigned_long_int(pos+13+arglen11+arglen12+
						    arglen13,
						    arglen14);
    }
    else // found code from mother-strand of cromosome 1
    {
	*threadnum  = strand->get_unsigned_int(pos+23, arglen21);
	*actcromnum = strand->get_unsigned_int(pos+23+arglen21, arglen22);
	*actpos     = strand->get_unsigned_long_int(pos+13+arglen21+arglen22, 
						    arglen23);
	*actlen     = strand->get_unsigned_long_int(pos+13+arglen21+arglen22+
						    arglen23,
						    arglen24);
    }
}
 

// Get the CHN vaiable from the last checked posisiton
void instruction::get_chn(cromosome_strand *strand, unsigned int pos,
			  bool fathercode, unsigned int *newn)
{
    if(fathercode)
	*newn = strand->get_unsigned_int(pos, arglen11);
    else
	*newn = strand->get_unsigned_int(pos, arglen21);
}


// Get the CHNPROS variable from the last checked posisiton
void instruction::get_chnpros(cromosome_strand *strand, unsigned int pos,
			      bool fathercode, double *pros)
{
    if(fathercode)
	*pros = strand->get_double(pos, arglen11, -100.0, 500.0);
    else
	*pros = strand->get_double(pos, arglen21, -100.0, 500.0);
}


// Get the CHNOD variables
void instruction::get_chnode(cromosome_strand *strand, unsigned int pos,
			     bool fathercode,
			     bool *absolute, unsigned int *varnum, 
			     double *pros)
{
    *absolute = strand->get_bit(pos);
  
    if(fathercode)
    {
	*varnum = strand->get_unsigned_int(pos+1, arglen11);
	*pros   = strand->get_double(pos+1+arglen11, arglen12, -500.0, 500.0);
    }
    else
    {
	*varnum = strand->get_unsigned_int(pos+1, arglen21);
	*pros   = strand->get_double(pos+1+arglen21, arglen22, -500.0, 500.0);
    }
}


// Get the CHSTTREAD variables
void instruction::get_chstthread(cromosome_strand *strand, 
				 unsigned int pos,
				 bool fathercode,
				 bool *absolute, unsigned int *varnum, 
				 double *pros)
{
    *absolute = strand->get_bit(pos);
  
    if(fathercode)
    {
	*varnum = strand->get_unsigned_int(pos+1, arglen11);
	*pros   = strand->get_double(pos+1+arglen11, arglen12, -500.0, 500.0);
    }
    else
    {
	*varnum = strand->get_unsigned_int(pos+1, arglen21);
	*pros   = strand->get_double(pos+1+arglen21, arglen22, -500.0, 500.0);
    }
}


// Get the CHALLTH variables
void instruction::get_challth(cromosome_strand *strand, unsigned int pos,
			      bool fathercode,
			      bool *in, bool *out, bool *absolute, 
			      unsigned int *varnum, double *pros)
{
    *in       = strand->get_bit(pos);
    *out      = strand->get_bit(pos+1);
    *absolute = strand->get_bit(pos+2);
  
    if(fathercode)
    {
	*varnum = strand->get_unsigned_int(pos+3, arglen11);
	*pros   = strand->get_double(pos+3+arglen11, arglen12, -500.0, 500.0);
    }
    else
    {
	*varnum = strand->get_unsigned_int(pos+3, arglen21);
	*pros   = strand->get_double(pos+3+arglen21, arglen22, -500.0, 500.0);
    }
}

 
// Get the CHTREAD variables
void instruction::get_chthread(cromosome_strand *strand, unsigned int pos,
			       bool fathercode,
			       bool *absolute, unsigned int *varnum, 
			       double *pros, unsigned int *threadnum)
{
    *absolute = strand->get_bit(pos);
  
    if(fathercode)
    {
	*varnum = strand->get_unsigned_int(pos+1, arglen11);
	*pros   = strand->get_double(pos+1+arglen11, arglen12, -500.0, 500.0);
	*threadnum = strand->get_unsigned_int(pos+1+arglen11+arglen12, arglen13);
    }
    else
    {
	*varnum = strand->get_unsigned_int(pos+1, arglen21);
	*pros   = strand->get_double(pos+1+arglen21, arglen22, -500.0, 500.0);
	*threadnum = strand->get_unsigned_int(pos+1+arglen21+arglen22, arglen23);
    }
}


// Get the REM/REM1/REM2 variables
void instruction::get_rem(cromosome_strand *strand, unsigned int pos,
			  bool fathercode,
			  bool *child1, bool *child2, 
			  unsigned int *threadnum) 
{
    *child1 = strand->get_bit(pos);
    *child2 = strand->get_bit(pos+1);
    if(fathercode)
	*threadnum = strand->get_unsigned_int(pos+2, arglen11);
    else
	*threadnum = strand->get_unsigned_int(pos+2, arglen21);
}

// Get the IF1/IF3 variables;
void instruction::get_ifclass(cromosome_strand *strand, unsigned int pos, 
			      bool fathercode, COMP_SIGN *comp,
			      unsigned int *varnum1, unsigned int *varnum2, 
			      unsigned int *actlen)
{
    *comp = strand->get_comp_sign(pos);

    if(fathercode)
    {
	*varnum1 = strand->get_unsigned_int(pos+2, arglen11);
	*varnum2 = strand->get_unsigned_int(pos+2+arglen11, arglen12);
	*actlen  = strand->get_unsigned_long_int(pos+2+arglen11+arglen12,
						 arglen13);
    }
    else
    {
	*varnum1 = strand->get_unsigned_int(pos+2, arglen21);
	*varnum2 = strand->get_unsigned_int(pos+2+arglen21, arglen22);
	*actlen  = strand->get_unsigned_long_int(pos+2+arglen21+arglen22,
						 arglen23);
    }
}

// Get the IF2/IF4 variables;
void instruction::get_if_num(cromosome_strand *strand, unsigned int pos, 
			     bool fathercode, COMP_SIGN *comp,
			     unsigned int *varnum, unsigned int *intnum, 
			     double *dbnum, unsigned int *actlen)
{
    *comp = strand->get_comp_sign(pos);

    if(fathercode)
    {
	*varnum  = strand->get_unsigned_int(pos+2, arglen11);
	*intnum  = strand->get_unsigned_long_int(pos+2+arglen11, arglen12);
	*dbnum   = strand->get_double(pos+2+arglen11, arglen12, -50.0, 50.0);
	*actlen  = strand->get_unsigned_long_int(pos+2+arglen11+arglen12,
						 arglen13);
    }
    else
    {
	*varnum  = strand->get_unsigned_int(pos+2, arglen21);
	*intnum  = strand->get_unsigned_long_int(pos+2+arglen21, arglen22);
	*dbnum   = strand->get_double(pos+2+arglen21, arglen22, -50.0, 50.0);
	*actlen  = strand->get_unsigned_long_int(pos+2+arglen21+arglen22,
						 arglen23);
    }
}

// Get the INC1/INC2(DEC1/DEC2/HALF1/HALF2/DOUBLE1/DOUBLE2(NEG1/NEG2 variables:
void instruction::get_oper(cromosome_strand *strand, unsigned int pos, 
			   bool fathercode,
			   unsigned int *varnum, bool *child1, bool *child2)
{
    *child1 = strand->get_bit(pos);
    *child2 = strand->get_bit(pos+1);
    if(fathercode)
	*varnum = strand->get_unsigned_int(pos+2, arglen11);
    else
	*varnum = strand->get_unsigned_int(pos+2, arglen21);
}

// Get the CHANGEVAR variables;
void instruction::get_changevar(cromosome_strand *strand, unsigned int pos, 
				bool fathercode,
				unsigned int *varnum1, unsigned int *varnum2,
				bool *child1, bool *child2, 
				CHANGE_OPER *oper)
{
    *child1 = strand->get_bit(pos);
    *child2 = strand->get_bit(pos+1);
  
    *oper = (CHANGE_OPER) strand->get_unsigned_int(pos+2, 3);

    if(fathercode)
	*varnum1 = strand->get_unsigned_int(pos+5, arglen11);
    else
	*varnum1 = strand->get_unsigned_int(pos+5, arglen21);

    if(fathercode)
	*varnum2 = strand->get_unsigned_int(pos+5+arglen11, arglen12);
    else
	*varnum2 = strand->get_unsigned_int(pos+5+arglen21, arglen22);
}


//              ACTIVATED
// This class represent a streach of a cromosome that's been activated
// (or deactivated).

// CONSTRUCTORS
activated::activated(activated *prev, unsigned int cromnum, 
		     unsigned int posnum, unsigned int length) :
    double_linked_list((double_linked_list *) prev, NULL)
{
    crom=cromnum;
    pos=posnum;
    len=length;
}

// copies a whole list
activated::activated(activated *prev, activated *original) :
    double_linked_list((double_linked_list *) prev, NULL)
{
    activated *next = (activated *) original->getnext(), *newnext;

    crom=original->crom;
    pos=original->pos;
    len=original->len;

    if(next)
	newnext = new activated(this, next);    
}

activated::~activated()
{
    activated *next = (activated *) getnext();

    removefromlist();

    if(next)
	delete next;
}

// get cromosome number
unsigned int activated::get_crom_num(void)
{
    return crom;
}

  
// get position
unsigned int activated::get_position(void)
{
    return pos;
}


// get bit length
unsigned int activated::get_length(void)
{
    return len;
}




//               COMMAND
// Contains structure common for all commands


// CONSTRUCTOR
command::command(command *prev, unsigned int cromnum, 
		 unsigned int posnum, 
		 unsigned int length,
		 INSTRCUTION_TYPE type) : activated((activated *) prev,
						    cromnum, posnum, length)
{
    typ=type;
}

command::~command()
{
    command *next=(command *) getnext();
  
    removefromlist();

    if(next)
	delete next ;
}

// Returns the command type;
INSTRCUTION_TYPE command::get_type(void)
{
    return typ;
}


// Makes a object of one of the subclasses of command, based on
// the instruction found and the strand it belongs to.
command *command::make_command(instruction &instr, cromosome_strand *strand,
			       unsigned int pos,
			       bool fathercode)
{
    command *commandptr=NULL;
    int totlen = fathercode ? instr.get_total_length1() : 
	instr.get_total_length2();
    int len = fathercode ? instr.get_code_length1() : 
	instr.get_code_length2();
    int cromnum = strand->get_cromosome_number();

    switch(instr.get_type())
    {
	case ACTIVATE: 
	{
	    // command variables;
	    bool child1, child2, inthread, outthread, male, female;
	    COMP_SIGN threadcomp, gencomp;
	    unsigned int threadnum, gennum, actcromnum;
	    unsigned int actpos;

	    // get data from cromosome;
	    instr.get_act(strand, pos+len, fathercode, &child1, &child2, &inthread,
			  &outthread, &threadcomp, &male, &female, &gencomp,
			  &threadnum, &gennum, &actcromnum, &actpos);
	    actpos=actpos% strand->get_bitlength();

	    // make command;
	    activation *act = new activation(NULL, cromnum, pos, totlen, 
					     child1, child2,
					     inthread, outthread, threadcomp, male,
					     female, gencomp, threadnum, gennum,
					     actcromnum, actpos);
					 
	    commandptr=act; // set it as the command to be returned

	    break;
	}
	case DEACTIVATE: 
	{
	    // command variables;
	    bool child1, child2, inthread, outthread, male, female;
	    COMP_SIGN threadcomp, gencomp;
	    unsigned int threadnum, gennum, deactcromnum;
	    unsigned int deactpos;

	    // get data from cromosome;
	    instr.get_act(strand, pos+len, fathercode, &child1, &child2,
			  &inthread, &outthread, &threadcomp, &male, &female, 
			  &gencomp, &threadnum, &gennum, 
			  &deactcromnum, &deactpos);
	    deactpos = deactpos % strand->get_bitlength();

	    // make command;
	    deactivation *deact = new deactivation(NULL, cromnum, pos, totlen, 
						   child1, child2,
						   inthread, outthread, 
						   threadcomp, male,
						   female, gencomp, 
						   threadnum, gennum,
						   deactcromnum, deactpos);
					 
	    commandptr=deact; // set it as the command to be returned

	    break;
	}
	case ACTIVATEL:
	{
	    // command variables;
	    bool child1, child2, inthread, outthread, male, female;
	    COMP_SIGN threadcomp, gencomp;
	    unsigned int threadnum, gennum, actcromnum;
	    unsigned int actpos, actlen;

	    // get data from cromosome;
	    instr.get_actl(strand, pos+len, fathercode, &child1, &child2, 
			   &inthread, &outthread, &threadcomp, &male, &female, 
			   &gencomp, &threadnum, &gennum, 
			   &actcromnum, &actpos, &actlen);
	    actpos = actpos % strand->get_bitlength();

	    // make command;
	    lengthactivation *actl = new lengthactivation(NULL, cromnum, 
							  pos, totlen, 
							  child1, child2,
							  inthread, outthread, 
							  threadcomp, male,
							  female, gencomp, 
							  threadnum, gennum,
							  actcromnum, actpos, 
							  actlen);
					 
	    commandptr=actl; // set it as the command to be returned

	    break;
	} 
	case DEACTIVATEL:
	{
	    // command variables;
	    bool child1, child2, inthread, outthread, male, female;
	    COMP_SIGN threadcomp, gencomp;
	    unsigned int threadnum, gennum, deactcromnum;
	    unsigned int deactpos, deactlen;

	    // get data from cromosome;
	    instr.get_actl(strand, pos+len, fathercode, &child1, &child2, 
			   &inthread, &outthread, &threadcomp, &male, &female, 
			   &gencomp, &threadnum, &gennum, 
			   &deactcromnum, &deactpos, &deactlen);
	    deactpos = deactpos % strand->get_bitlength();

	    // make command;
	    lengthdeactivation *deactl = new lengthdeactivation(NULL, cromnum, 
								pos, totlen, 
								child1, child2,
								inthread, 
								outthread, 
								threadcomp, male,
								female, gencomp, 
								threadnum, gennum,
								deactcromnum, 
								deactpos,
								deactlen);
					 
	    commandptr=deactl; // set it as the command to be returned


	    break;
	}
	case CHN: 
	{
	    unsigned int newn;

	    instr.get_chn(strand, pos+len, fathercode, &newn);

	    change_n *chn=new change_n(NULL, cromnum, pos, totlen, newn);
	
	    commandptr=chn; // set it as the command to be returned

	    break;
	}
	case CHNPROS: 
	{
	    double newnpros;

	    instr.get_chnpros(strand, pos+len, fathercode, &newnpros);

	    change_npros *chnpros=new change_npros(NULL, cromnum, 
						   pos, totlen, newnpros);
	
	    commandptr=chnpros; // set it as the command to be returned

	    break;
	}
	case CHNODE: 
	{
	    bool abs;
	    unsigned int varnum;
	    double pros;

	    instr.get_chnode(strand, pos+len, fathercode, &abs, &varnum, &pros);
	
	    change_node *chnode = new change_node(NULL, cromnum, pos, totlen,
						  abs, varnum, pros);

	    commandptr=chnode; // set it as the command to be returned

	    break;
	}
	case CHSTTHREAD: 
	{
	    bool abs;
	    unsigned int varnum;
	    double pros;

	    instr.get_chstthread(strand, pos+len, fathercode, 
				 &abs, &varnum, &pros);
	
	    change_standard_thread *chstth = 
		new change_standard_thread(NULL, cromnum, pos, totlen, 
					   abs, varnum, pros);

	    commandptr=chstth; // set it as the command to be returned

	    break;
	}
	case CHALLTH:
	{
	    bool abs, in, out;
	    unsigned int varnum;
	    double pros;

	    instr.get_challth(strand, pos+len, fathercode, 
			      &in, &out, &abs, &varnum, &pros);
	
	    change_all_threads *challth = 
		new change_all_threads(NULL, cromnum, pos, totlen, in, out,
				       abs, varnum, pros);

	    commandptr=challth; // set it as the command to be returned

	    break;
	} 
	case CHTHREAD: 
	{
	    bool abs;
	    unsigned int varnum, threadnum;
	    double pros;

	    instr.get_chthread(strand, pos+len, fathercode, 
			       &abs, &varnum, &pros, &threadnum);
	
	    change_thread *chth = 
		new change_thread(NULL, cromnum, pos, totlen, threadnum, 
				  abs, varnum, pros);

	    commandptr=chth; // set it as the command to be returned

	    break;
	}
	case STOP: 
	{
	    stop_command *stopcom=new stop_command(NULL, cromnum, pos, totlen);

	    commandptr=stopcom; // set it as the command to be returned

	    break;
	}
	case REM:
	case REM1:
	case REM2:
	{
	    bool usechild1, usechild2;
	    unsigned int threadnumber;

	    instr.get_rem(strand, pos+len, fathercode, &usechild1, &usechild2, 
			  &threadnumber);

	    remove_thread *rmth=new remove_thread(NULL, cromnum, pos, totlen,
						  usechild1, usechild2, 
						  threadnumber,instr.get_type());

	    commandptr=rmth; // set it as the command to be returned

	    break;
	}
	case IF1:
	case IF3:
	{
	    COMP_SIGN comp;
	    unsigned int varnum1, varnum2;
	    unsigned int actlen;

	    instr.get_ifclass(strand, pos+len, fathercode, &comp,
			      &varnum1, &varnum2, &actlen);

	    ifclass *ifobject=new ifclass(NULL, cromnum, pos, totlen, 
					  varnum1, varnum2, comp, 
					  instr.get_type()==IF1 ? false :
					  true, actlen);
				      
	    commandptr=ifobject;

	    break;
	}
	case IF2:
	case IF4:
	{
	    COMP_SIGN comp;
	    unsigned int varnum;
	    unsigned int intnum;
	    double dbnum;
	    unsigned int actlen;

	    instr.get_if_num(strand, pos+len, fathercode, &comp,
			     &varnum, &intnum, &dbnum, &actlen);

	    if_num *ifnum=new if_num(NULL, cromnum, pos, totlen, 
				     varnum, dbnum, intnum, comp, 
				     instr.get_type()==IF2 ? false :
				     true, actlen);
	
	    commandptr=ifnum;

	    break;
	}

	case INC1:
	case INC2: 
	case DEC1:
	case DEC2:
	case HALF1:
	case HALF2: 
	case DOUBLE1:
	case DOUBLE2: 
	case NEG1:
	case NEG2:
	{
	    bool child1, child2;
	    unsigned int varnum;
	
	    instr.get_oper(strand, pos+len, fathercode, 
			   &varnum, &child1, &child2);
	    single_operation *soper=new single_operation(NULL, cromnum, pos, totlen, 
							 varnum, child1, child2,
							 instr.get_type());

	    commandptr=soper;

	    break;
	}

	case CHANGEVAR1:
	case CHANGEVAR2:
	case CHANGEVAR3:
	case CHANGEVAR4:
	case CHANGEVAR5:
	{
	    bool child1, child2;
	    unsigned int varnum1, varnum2;
	    CHANGE_OPER changeoper;

	    instr.get_changevar(strand, pos+len, fathercode, 
				&varnum1, &varnum2, &child1, &child2, &changeoper);
	    changevar *chvar=new changevar(NULL, cromnum, pos, totlen, 
					   varnum1, varnum2, 
					   child1, child2, changeoper,
					   instr.get_type());

	    commandptr=chvar;

	    break;
	}
	default:
	    break;
    }

    return commandptr;
} 

//            ACTIVATION
// Represent a single ACTIVATE command



// CONSTRUCTOR
activation::activation(activation *prev, 
		       unsigned int cromnum_, unsigned int posnum_, 
		       unsigned int length_, 
		       bool child1_, bool child2_, 
		       bool inthread_, bool outthread_, 
		       COMP_SIGN threadcomp_, 
		       bool male_, bool female_, 
		       COMP_SIGN gencomp_, 
		       unsigned int threadnum_, unsigned int gennum_, 
		       unsigned int actcromnum_, unsigned int actpos_) :
    command((command *) prev, cromnum_, posnum_, length_, ACTIVATE)
{
    child1=child1_;
    child2=child2_;
    inthread=inthread_;
    outthread=outthread_;
    threadcomp=threadcomp_;
    male=male_;
    female=female_;
    gencomp=gencomp_;
    threadnum=threadnum_;
    gennum=gennum_;
    actcromnum=actcromnum_;
    actpos=actpos_;
}

bool activation::get_child1(void)
{
    return child1;
}

bool activation::get_child2(void)
{
    return child2;
}

bool activation::get_inthread(void)
{
    return inthread;
}

bool activation::get_outthread(void)
{
    return outthread;
}

COMP_SIGN activation::get_threadcomp(void)
{
    return threadcomp;
}

bool activation::get_male(void)
{
    return male;
}

bool activation::get_female(void)
{
    return female;
}

COMP_SIGN activation::get_gencomp(void)
{
    return gencomp;
}

unsigned int activation::get_threadnum(void)
{
    return threadnum;
}

unsigned int activation::get_gennum(void)
{
    return gennum;
}

unsigned int activation::get_actcromnum(void)
{
    return actcromnum;
}

unsigned int activation::get_actpos(void)
{
    return actpos;
}



//            DEACTIVATION
// Represent a single DEACTIVATE command



// CONSTRUCTOR
deactivation::deactivation(deactivation *prev, 
			   unsigned int cromnum_, 
			   unsigned int posnum_, 
			   unsigned int length_, 
			   bool child1_, bool child2_, 
			   bool inthread_, bool outthread_, 
			   COMP_SIGN threadcomp_, 
			   bool male_, bool female_, 
			   COMP_SIGN gencomp_, 
			   unsigned int threadnum_, unsigned int gennum_, 
			   unsigned int deactcromnum_, 
			   unsigned int deactpos_) :
    command((command *) prev, cromnum_, posnum_, length_, DEACTIVATE)
{
    child1=child1_;
    child2=child2_;
    inthread=inthread_;
    outthread=outthread_;
    threadcomp=threadcomp_;
    male=male_;
    female=female_;
    gencomp=gencomp_;
    threadnum=threadnum_;
    gennum=gennum_;
    deactcromnum=deactcromnum_;
    deactpos=deactpos_;
}

bool deactivation::get_child1(void)
{
    return child1;
}

bool deactivation::get_child2(void)
{
    return child2;
}

bool deactivation::get_inthread(void)
{
    return inthread;
}

bool deactivation::get_outthread(void)
{
    return outthread;
}

COMP_SIGN deactivation::get_threadcomp(void)
{
    return threadcomp;
}

bool deactivation::get_male(void)
{
    return male;
}

bool deactivation::get_female(void)
{
    return female;
}

COMP_SIGN deactivation::get_gencomp(void)
{
    return gencomp;
}

unsigned int deactivation::get_threadnum(void)
{
    return threadnum;
}

unsigned int deactivation::get_gennum(void)
{
    return gennum;
}

unsigned int deactivation::get_deactcromnum(void)
{
    return deactcromnum;
}

unsigned int deactivation::get_deactpos(void)
{
    return deactpos;
}



//             LENGTHACTIVATION
// Represents a single command of the type 'ACTIVATEL'

// CONSTRUCTOR
lengthactivation::lengthactivation(lengthactivation *prev, 
				   unsigned int cromnum_, 
				   unsigned int posnum_, 
				   unsigned int length_, 
				   bool child1_, bool child2_, 
				   bool inthread_, bool outthread_, 
				   COMP_SIGN threadcomp_, 
				   bool male_, bool female_, 
				   COMP_SIGN gencomp_, 
				   unsigned int threadnum_, 
				   unsigned int gennum_, 
				   unsigned int actcromnum_, 
				   unsigned int actpos_, 
				   unsigned int actlen_) :
    command((command *) prev, cromnum_, posnum_, length_, ACTIVATEL)
{
    child1=child1_;
    child2=child2_;
    inthread=inthread_;
    outthread=outthread_;
    threadcomp=threadcomp_;
    male=male_;
    female=female_;
    gencomp=gencomp_;
    threadnum=threadnum_;
    gennum=gennum_;
    actcromnum=actcromnum_;
    actpos=actpos_;
    actlen=actlen_;
}

bool lengthactivation::get_child1(void)
{
    return child1;
}

bool lengthactivation::get_child2(void)
{
    return child2;
}

bool lengthactivation::get_inthread(void)
{
    return inthread;
}

bool lengthactivation::get_outthread(void)
{
    return outthread;
}

COMP_SIGN lengthactivation::get_threadcomp(void)
{
    return threadcomp;
}

bool lengthactivation::get_male(void)
{
    return male;
}

bool lengthactivation::get_female(void)
{
    return female;
}

COMP_SIGN lengthactivation::get_gencomp(void)
{
    return gencomp;
}

unsigned int lengthactivation::get_threadnum(void)
{
    return threadnum;
}

unsigned int lengthactivation::get_gennum(void)
{
    return gennum;
}

unsigned int lengthactivation::get_actcromnum(void)
{
    return actcromnum;
}

unsigned int lengthactivation::get_actpos(void)
{
    return actpos;
}

unsigned int lengthactivation::get_actlen(void)
{
    return actlen;
}




//             LENGTHDEACTIVATION
// Represents a single command of the type 'DEACTIVATEL'

// CONSTRUCTOR
lengthdeactivation::lengthdeactivation(lengthdeactivation *prev, 
				       unsigned int cromnum_, 
				       unsigned int posnum_, 
				       unsigned int length_, 
				       bool child1_, bool child2_, 
				       bool inthread_, bool outthread_, 
				       COMP_SIGN threadcomp_, 
				       bool male_, bool female_, 
				       COMP_SIGN gencomp_, 
				       unsigned int threadnum_, 
				       unsigned int gennum_, 
				       unsigned int deactcromnum_, 
				       unsigned int deactpos_, 
				       unsigned int deactlen_) :
    command((command *) prev, cromnum_, posnum_, length_, DEACTIVATEL)
{
    child1=child1_;
    child2=child2_;
    inthread=inthread_;
    outthread=outthread_;
    threadcomp=threadcomp_;
    male=male_;
    female=female_;
    gencomp=gencomp_;
    threadnum=threadnum_;
    gennum=gennum_;
    deactcromnum=deactcromnum_;
    deactpos=deactpos_;
    deactlen=deactlen_;
}

bool lengthdeactivation::get_child1(void)
{
    return child1;
}

bool lengthdeactivation::get_child2(void)
{
    return child2;
}

bool lengthdeactivation::get_inthread(void)
{
    return inthread;
}

bool lengthdeactivation::get_outthread(void)
{
    return outthread;
}

COMP_SIGN lengthdeactivation::get_threadcomp(void)
{
    return threadcomp;
}

bool lengthdeactivation::get_male(void)
{
    return male;
}

bool lengthdeactivation::get_female(void)
{
    return female;
}

COMP_SIGN lengthdeactivation::get_gencomp(void)
{
    return gencomp;
}

unsigned int lengthdeactivation::get_threadnum(void)
{
    return threadnum;
}

unsigned int lengthdeactivation::get_gennum(void)
{
    return gennum;
}

unsigned int lengthdeactivation::get_deactcromnum(void)
{
    return deactcromnum;
}

unsigned int lengthdeactivation::get_deactpos(void)
{
    return deactpos;
}

unsigned int lengthdeactivation::get_deactlen(void)
{
    return deactlen;
}



//          CHANGE_N
// Represent a single CHN command


// CONSTRUCTOR
change_n::change_n(change_n *prev, unsigned int cromnum_, 
		   unsigned int posnum_, 
		   unsigned int length_, unsigned int new_n_) :
    command((command *) prev, cromnum_, posnum_, length_, CHN)
{
    new_n=new_n_;
}

unsigned int change_n::get_new_n(void)
{
    return new_n;
}


//          CHANGE_NPROS
// Represent a single CHNPROS command

// CONSTRUCTOR
change_npros::change_npros(change_npros *prev, unsigned int cromnum_, 
			   unsigned int posnum_, 
			   unsigned int length_, 
			   double new_npros_) :
    command((command *) prev, cromnum_, posnum_, length_, CHNPROS)
{
    new_npros = new_npros_;
}

double change_npros::get_new_npros(void)
{
    return new_npros;
}


//           CHANGE_NODE
// Represent a single CHNODE command

// CONSTRUCTOR
change_node::change_node(change_node *prev, unsigned int cromnum_, 
			 unsigned int posnum_, unsigned int length_, 
			 bool absolute, unsigned int varnum, double pros) :
    command((command *) prev, cromnum_, posnum_, length_, CHNODE)  
{
    abs=absolute;
    var_num=varnum;
    procent=pros;
}

bool change_node::use_absolute(void)
{
    return abs;
}

unsigned int change_node::get_var_num(void)
{
    return var_num;
}

double change_node::get_procent(void)
{
    return procent;
}


//           CHANGE_STANDARD_THREAD
// Represent a single CHSTTH command

// CONSTRUCTOR
change_standard_thread::change_standard_thread(change_standard_thread *prev, 
					       unsigned int cromnum_, 
					       unsigned int posnum_, 
					       unsigned int length_, 
					       bool absolute, 
					       unsigned int varnum, 
					       double pros) :
    command((command *) prev, cromnum_, posnum_, length_, CHSTTHREAD)  
{
    abs=absolute;
    var_num=varnum;
    procent=pros;
}

bool change_standard_thread::use_absolute(void)
{
    return abs;
}

unsigned int change_standard_thread::get_var_num(void)
{
    return var_num;
}

double change_standard_thread::get_procent(void)
{
    return procent;
}




//           CHANGE_ALL_THREADS
// Represent a single CHALLTH command

// CONSTRUCTOR
change_all_threads::change_all_threads(change_all_threads *prev, 
				       unsigned int cromnum_, 
				       unsigned int posnum_, 
				       unsigned int length_, 
				       bool in_threads, bool out_threads,
				       bool absolute, unsigned int varnum, 
				       double pros) :
    command((command *) prev, cromnum_, posnum_, length_, CHALLTH) 
{
    inthreads  = in_threads;
    outthreads = out_threads;
    abs=absolute;
    var_num=varnum;
    procent=pros;
}

bool change_all_threads::use_in_threads(void)
{
    return inthreads;
}

bool change_all_threads::use_out_threads(void)
{
    return outthreads;
}

bool change_all_threads::use_absolute(void)
{
    return abs;
}

unsigned int change_all_threads::get_var_num(void)
{
    return var_num;
}

double change_all_threads::get_procent(void)
{
    return procent;
}



//           CHANGE_THREAD
// Represent a single CHTHREAD command

// CONSTRUCTOR
change_thread::change_thread(change_thread *prev, 
			     unsigned int cromnum_, 
			     unsigned int posnum_, 
			     unsigned int length_, 
			     unsigned int thread_number, 
			     bool absolute, unsigned int varnum, 
			     double pros) :
    command((command *) prev, cromnum_, posnum_, length_, CHTHREAD)  
{
    thread_num=thread_number;
    abs=absolute;
    var_num=varnum;
    procent=pros;
}

unsigned int change_thread::get_thread_number(void)
{
    return thread_num;
}

bool change_thread::use_absolute(void)
{
    return abs;
}

unsigned int change_thread::get_var_num(void)
{
    return var_num;
}

double change_thread::get_procent(void)
{
    return procent;
}



//            STOP_COMMAND
// Represents a single STOP command

// CONSTRUCTOR
stop_command::stop_command(stop_command *prev, unsigned int cromnum_, 
			   unsigned int posnum_, 
			   unsigned int length_) :
    command((command *) prev, cromnum_, posnum_, length_, STOP)  
{
}


//                 REMOVE_THREAD
// Represents a single REM/REM1/REM2 command

// CONSTRUCTOR
remove_thread::remove_thread(remove_thread *prev, 
			     unsigned int cromnum_, 
			     unsigned int posnum_, 
			     unsigned int length_, 
			     bool usechild1, bool usechild2, 
			     unsigned int threadnumber,
			     INSTRCUTION_TYPE type_) :
    command((command *) prev, cromnum_, posnum_, length_, type_)  
{
    child1=usechild1;
    child2=usechild2;
    threadnum=threadnumber;
}

bool remove_thread::use_child1(void)
{
    return child1;
}

bool remove_thread::use_child2(void)
{
    return child2;
}

unsigned int remove_thread::get_thread_number(void)
{
    return threadnum;
}




//            IFCLASS
// Represents an 'if(var1,var2)' statement (IF1, IF3)

// CONSTRUCTOR
ifclass::ifclass(ifclass *prev,
		 unsigned int cromnum_, unsigned int posnum_, 
		 unsigned int length_, 
		 unsigned int varnum1_, unsigned int varnum2_,
		 COMP_SIGN comp_, bool dovar3, unsigned int actlen_) :
    command((command *) prev, cromnum_, posnum_, length_,
	    dovar3 ? IF3 : IF1)
{
    varnum1=varnum1_;
    varnum2=varnum2_;
    comp=comp_;
    do_var3=dovar3;
    actlen=actlen_;
}

unsigned int ifclass::get_varnum1(void)
{
    return varnum1;
}

unsigned int ifclass::get_varnum2(void)
{
    return varnum2;
}

unsigned int ifclass::get_actlen(void)
{
    return actlen;
}

COMP_SIGN ifclass::get_comp(void)
{
    return comp;
}

bool ifclass::get_do_var3(void)
{
    return do_var3;
}



//            IF_NUM
// Represents an 'if(var,number)' statement (IF2, IF4)

// CONSTRUCTOR
if_num::if_num(if_num *prev,
	       unsigned int cromnum_, unsigned int posnum_, 
	       unsigned int length_, 
	       unsigned int varnum_, 
	       double dbnumber_, unsigned int intnumber_,
	       COMP_SIGN comp_, bool dovar3, unsigned int actlen_) :
    command((command *) prev, cromnum_, posnum_, length_,
	    dovar3 ? IF4 : IF2)
{
    varnum=varnum_;
    dbnumber=dbnumber_;
    intnumber=intnumber_;
    comp=comp_;
    do_var3=dovar3;
    actlen=actlen_;
}

unsigned int if_num::get_varnum(void)
{
    return varnum;
}

double if_num::get_dbnumber(void)
{
    return dbnumber;
}

unsigned int if_num::get_intnumber(void)
{
    return intnumber;
}

unsigned int if_num::get_actlen(void)
{
    return actlen;
}

COMP_SIGN if_num::get_comp(void)
{
    return comp;
}

bool if_num::get_do_var3(void)
{
    return do_var3;
}

//             SINGLE_OPERATION
// Represent a single operation like half, negate,increment...

// CONSTRUCTOR
single_operation::single_operation(single_operation *prev,
				   unsigned int cromnum_, 
				   unsigned int posnum_, 
				   unsigned int length_, 
				   unsigned int varnum_, 
				   bool child1_, bool child2_,
				   INSTRCUTION_TYPE type_) :
    command((command *) prev, cromnum_, posnum_, length_,type_)
{
    varnum=varnum_;
    child1=child1_;
    child2=child2_;
}

unsigned int single_operation::get_varnum(void)
{
    return varnum;
}

bool single_operation::use_child1(void)
{
    return child1;
}

bool single_operation::use_child2(void)
{
    return child2;
}

//    CHANGEVAR
// Represents the CHANGEVAR1/...CHANGEVAR5 commands

// constructor
changevar::changevar(changevar *prev, unsigned int cromnum_, 
		     unsigned int posnum_, unsigned int length_, 
		     unsigned int varnum1_, unsigned int varnum2_, 
		     bool child1_, bool child2_, CHANGE_OPER changeoper_,
		     INSTRCUTION_TYPE type_)  :
    command((command *) prev, cromnum_, posnum_, length_,type_)
{
    varnum1=varnum1_;
    varnum2=varnum2_;
    child1=child1_;
    child2=child2_;
    changeoper=changeoper_;
}

unsigned int changevar::get_varnum1(void)
{
    return varnum1;
}

unsigned int changevar::get_varnum2(void)
{
    return varnum2;
}

bool changevar::use_child1(void)
{
    return child1;
}

bool changevar::use_child2(void)
{
    return child2;
}

CHANGE_OPER changevar::get_changeoper(void)
{
    return changeoper;
}



//                 CROMOSOME_STRAND
// Represents a single cromosome strand, either from the
// 'fathter' or the 'mother'.

void cromosome_strand::init(int newbitlen)
{
    longintlen = sizeof(int)*8;
  
    bitlen=newbitlen;

    if(bitlen>0)
    {
	arraylen = bitlen / longintlen;
	arraylen++;

	contents = new unsigned int[arraylen];  
    }
    else
    {
	arraylen=0;
	contents=NULL;
    }

    commands=commandtail=NULL;
}

void cromosome_strand::cleanup(void)
{
    if(contents && bitlen>0 && arraylen>0)
	delete [] contents;
    contents=NULL;
    bitlen=0;
    arraylen=0;

    while(commandtail)
    {
	command *prevtail = (command *) commandtail->getprev();
	commandtail->removefromlist();
	delete commandtail;
      
	commandtail=prevtail;
    }
    commands=commandtail=NULL;
}

// CONSTRCUTORS
// Makes a strand with random bits
cromosome_strand::cromosome_strand(replicatorset *ipt, int cromosome_number, 
				   int bit_length)
{
    pt=ipt;
    cromnum = cromosome_number;

    init(bit_length);
    for(unsigned int i=0;i<arraylen;i++)
	contents[i] = (unsigned int) random();
}

cromosome_strand::cromosome_strand(replicatorset *ipt, int cromosome_number, 
				   char *contents_, int bit_length)
{
    pt=ipt;
    cromnum = cromosome_number;

    init(bit_length);
    for(unsigned int i=0;i<arraylen;i++)
	contents[i] = contents_[i];
}

// Makes a strand by copying the contents of another (from spec. pos.)
cromosome_strand::cromosome_strand(replicatorset *ipt, int cromosome_number, 
				   cromosome_strand *parent,
				   unsigned int pos, 
				   int len)
{
    register unsigned int i;

    pt=ipt;
    cromnum = cromosome_number;

    if(len==-1)
	init((int) parent->get_bitlength() - (int) pos);
    else
	init(MAXIM((int) 1, 
		   MINIM((int) parent->get_bitlength() - (int) pos, 
			 (int) len)));
  

    if(pos==0 && len==-1) // copy all the contents
    {
	for(i=0;i<arraylen;i++)
	    contents[i] = parent->contents[i];
    }
    else
    {
	for(i=0;i<bitlen;i++)
	    set_bit(i, parent->get_bit(i+pos));
    }
}

// fetches a cromosome from a file
cromosome_strand::cromosome_strand(replicatorset *ipt, FILE *f)
{
    pt=ipt;
    longintlen = sizeof(int)*8;
    commands=commandtail=NULL;

    from_file(f);
}


// Makes a stand by joining two parent strands (meiosis)
cromosome_strand::cromosome_strand(replicatorset *ipt, int cromosome_number, 
				   cromosome_strand *parent1, 
				   cromosome_strand *parent2)
{
    unsigned int pos, arrpos;
    register unsigned int i;
    bool parent1_first = (drand48()>0.5) ? true : false;
    unsigned int newbitlen = (parent1_first) ? parent2->bitlen : 
	parent1->bitlen;

    pt=ipt;
    cromnum = cromosome_number;

    init(newbitlen);
  
    pos = (unsigned int) (((double) MINIM(parent1->bitlen, 
					       parent2->bitlen)) * drand48());
    arrpos = pos / longintlen;

    for(i=0; i<arrpos; i++)
	if(parent1_first)
	    contents[i]=parent1->contents[i];
	else
	    contents[i]=parent2->contents[i];

    for(i=0; i<pos-arrpos*longintlen; i++)
	if(parent1_first)
	    set_bit(arrpos*longintlen+i, parent1->get_bit(arrpos*longintlen+i));
	else
	    set_bit(arrpos*longintlen+i, parent2->get_bit(arrpos*longintlen+i));

    for(; i<longintlen; i++)
	if(parent1_first)
	    set_bit(arrpos*longintlen+i, parent2->get_bit(arrpos*longintlen+i));
	else
	    set_bit(arrpos*longintlen+i, parent1->get_bit(arrpos*longintlen+i));

    for(i=arrpos+1; i<arraylen; i++)
	if(parent1_first)
	    contents[i]=parent2->contents[i];
	else
	    contents[i]=parent1->contents[i];
}

cromosome_strand::~cromosome_strand()
{
    cleanup();
}

void cromosome_strand::to_file(FILE *f)
{
    fwrite(&bitlen, sizeof(unsigned int), 1, f);
    fwrite(&arraylen, sizeof(unsigned int), 1, f);
    fwrite(&cromnum, sizeof(unsigned int), 1, f);

    for(register unsigned int i=0;i<arraylen;i++)
	fwrite(&contents[i], sizeof(unsigned int), 1, f);
}

void cromosome_strand::from_file(FILE *f)
{
    fread(&bitlen, sizeof(unsigned int), 1, f);
    fread(&arraylen, sizeof(unsigned int), 1, f);
    fread(&cromnum, sizeof(unsigned int), 1, f);

    contents = new unsigned int[arraylen];  
    for(register unsigned int i=0;i<arraylen;i++)
	fread(&contents[i], sizeof(unsigned int), 1, f);
}



// mutation commands;

void cromosome_strand::point_mutate(unsigned int pos)
{
    set_bit(pos, (bool) !get_bit(pos));
}

cromosome_strand *cromosome_strand::copy(unsigned int pos, 
					 unsigned int len)
{
    //cout << "Copying!" << endl;

    if(pos >= (bitlen-longintlen) || bitlen<longintlen)
	return NULL;

    return new cromosome_strand(pt, this->cromnum, this, pos, len);
}

cromosome_strand *cromosome_strand::cut(unsigned int pos, 
					unsigned int len)
{
    //cout << "Cutting! -";

    register unsigned int i; 

    len=MINIM(len, bitlen-pos);

    if((bitlen-len)<3000 || pos>=(bitlen-longintlen))
	return NULL;

    cromosome_strand *ptr=copy(pos, len);
  
    if(ptr)
    {
	for(i=pos/longintlen; (i+len/longintlen)<arraylen;i++)
	    contents[i] = contents[i+len/longintlen];
      
	bitlen -= len;
	arraylen = bitlen / longintlen;
	if((bitlen % longintlen) != (longintlen-1))
	    arraylen++;
    }

    return ptr;
}

void cromosome_strand::flip(unsigned int pos, int len)
{
    register unsigned int i; 
  
    //cout << "Flipping!" << endl;

    if(len==-1)
	len=bitlen-pos;

    for(i=pos; i<pos+len/2; i++)
    {
	bool state = get_bit(i);

	set_bit(i, get_bit(pos+len-1-i));
	set_bit(pos+len-1-i, state);
    }
}

void cromosome_strand::negate(void)
{
    unsigned int  i;

    for(i=0;i<bitlen;i++)
	set_bit(i, get_bit(i) ? false : true);
}

void cromosome_strand::paste(cromosome_strand *streatch, unsigned int pos)
{
    register unsigned int i; 
    unsigned int arrpos=pos/longintlen;;
    unsigned int newarraylen = arraylen + streatch->arraylen + 1;
    unsigned int *newcontents = new unsigned int[newarraylen];

    //cout << "Pasting!" << endl;
  
    for(i=0;i<arrpos;i++)
	newcontents[i]=contents[i];

    for(i=0;i<streatch->arraylen;i++)
	newcontents[arrpos+i]=streatch->contents[i];

    for(i=arrpos; i<arraylen; i++)
	newcontents[streatch->arraylen + i] = contents[i];

    if(arraylen>0 && bitlen>0 && contents)
	delete [] contents;

    contents=newcontents;
    bitlen += streatch->bitlen;
    arraylen = newarraylen;
}

// Returns the first found position that matches the pattern
// Returns bitlength+1 if none are found
unsigned int cromosome_strand::find_pattern(cromosome_strand *pattern, 
						 unsigned int startpos)
{
    unsigned int pos, i;

    for(pos=startpos; pos<bitlen-pattern->bitlen; pos++)
    {
	for(i=0;i<pattern->bitlen;i++)
	    if(pattern->get_bit(i)!=get_bit(pos+i))
		break;
      
	if(i==pattern->bitlen)
	    return pos;
    }
  
    return bitlen+1;
}

void cromosome_strand::set_cromosome_number(unsigned int new_cromosome_number)
{
    cromnum = new_cromosome_number;
}

// Find available instructions on this strand and it's partner.
// Should be done after mutations...
void cromosome_strand::find_commands(instruction **instructions, 
				     int num_instructions,
				     cromosome_strand *partner_cromosome, 
				     double repair_ratio)
{
    register int i, j, k;
    int minbitlen=MINIM(bitlen, partner_cromosome->bitlen);

    //repair_ratio=0.0;
    commands=commandtail=NULL;
  
    for(i=0;i<minbitlen; i++)
    {
	int instruction_found1=0,instruction_found2=0;
	int inslen1=0, inslen2=0, inslen=0;
	bool fathercode1=true,fathercode2=true;
	instruction *instr=NULL;

	for(j=0;j<num_instructions && instruction_found1==0 && 
		instruction_found2==0; j++)
	{
	    instr=instructions[j];
	    instruction_found1=instr->check(this, i);
	    instruction_found2=instr->check(partner_cromosome, i);
	}
      
      
	if(instruction_found1<0) // father code found in this-strand?
	{
	    inslen1 = instr->get_total_length1();
	    fathercode1 = true;
	}
	else if(instruction_found1>0) // mother code found in this-strand?
	{
	    inslen1 = instr->get_total_length2();
	    fathercode1 = false;
	}

	if(instruction_found2<0) // father code found in the other strand?
	{
	    inslen2 = instr->get_total_length1();
	    fathercode2 = true;
	}
	else if(instruction_found2>0) // mother code found in the other strand?
	{
	    inslen2 = instr->get_total_length2();
	    fathercode2 = false;
	}
      

	if(inslen1==inslen2 && inslen1>0)
	{
	    for(j=i;j<i+inslen1 && j<minbitlen &&
		    instruction_found1!=0 && instruction_found2!=0;j++)
	    {
		if(get_bit(j) && !partner_cromosome->get_bit(j))
		    instruction_found2=0;
		else if(!get_bit(j) && partner_cromosome->get_bit(j))
		    instruction_found1=0;
	    }
	}

	// instruction from this cromosome found and is to be used?
	if(instruction_found1!=0 && 
	   (instruction_found2==0 || inslen2>inslen1))
	{
	    inslen=inslen1; 
	    // length = length found in this cromosome

	    if(instruction_found2==0) // the other cromosme hasn't
		// a command here (or command surpressed)
	    {
		// check if there is a command in the other cromosome
		// (surpressed instruction);
		bool found=false;

		for(k=i; 
		    k<MINIM((i+inslen), (int)partner_cromosome->get_bitlength());
		    k++)
		    for(j=0; j<num_instructions && !found; j++)
			if(instructions[j]->check(partner_cromosome, k) != 0)
			    found=true;

		// if no surpressed instruction was found and 
		// we're to repair it...
		if(!found && drand48() < repair_ratio) // repair ? 
		{
		    // copy contents from the cromosome to the other
		    for(j=i;j<i+inslen && j<minbitlen;j++)
			partner_cromosome->set_bit(j, get_bit(j));
		}
	    }

	    command *comptr = command::make_command(*instr, this, i, 
						    fathercode1);
	    command *comptr2 = command::make_command(*instr, this, i, 
						     fathercode1);

	    into_the_tail((double_linked_list *) comptr, 
			  (double_linked_list **) &commands, 
			  (double_linked_list **) &commandtail);
	    into_the_tail((double_linked_list *) comptr2, 
			  (double_linked_list **) &partner_cromosome->commands, 
			  (double_linked_list**)&partner_cromosome->commandtail);
	}

	// instruction from the partner found and is to be used?
	if(instruction_found2!=0)
	{
	    inslen=inslen2; 
	    // length = length found in this cromosome

	    if(instruction_found1==0) // this cromosme hasn't
		// a command here (or command surpressed)
	    {
		// check if there is a command in this cromosome
		// (surpressed instruction);
		bool found=false;

		for(k=i; 
		    k<MINIM((i+inslen), (int)partner_cromosome->get_bitlength());
		    k++)
		    for(j=0; j<num_instructions && !found; j++)
			if(instructions[j]->check(this, k) != 0)
			    found=true;

		// if no surpressed instruction was found and 
		// we're to repair it...
		if(!found && drand48() < repair_ratio) // repair ? 
		{
		    // copy contents from the other cromosome to this
		    for(j=i;j<i+inslen && j<minbitlen;j++)
			set_bit(j, partner_cromosome->get_bit(j));
		}
	    }
	  
	    command *comptr = command::make_command(*instr, partner_cromosome, 
						    i, fathercode2);
	    command *comptr2 = command::make_command(*instr, partner_cromosome, 
						     i, fathercode2);

	    into_the_tail((double_linked_list *) comptr, 
			  (double_linked_list **) &commands, 
			  (double_linked_list **) &commandtail);
	    into_the_tail((double_linked_list *) comptr2, 
			  (double_linked_list **) &partner_cromosome->commands, 
			  (double_linked_list**)&partner_cromosome->commandtail);
	}

	i += (unsigned int) inslen;
    }

    // more commands in this strand than the other?
    if(bitlen>partner_cromosome->bitlen)
    {
	for(i=partner_cromosome->bitlen; i<(int)bitlen; i++)
	{
	    int instruction_found=0, inslen=0;
	    bool fathercode=true;
	    instruction *instr=NULL;

	    for(j=0;j<num_instructions && instruction_found==0; j++)
	    {
		instr=instructions[j];
		instruction_found=instr->check(this, i);
	    }
	  
	    if(instruction_found<0) // father code found in this strand
	    {
		fathercode=true;
		inslen = instr->get_total_length1();
	    }
	    else if(instruction_found>0)
	    {
		fathercode=false;
		inslen = instr->get_total_length2();
	    }

	    command *comptr = command::make_command(*instr, this, i, fathercode);
	    command *comptr2 = command::make_command(*instr, this, i, fathercode);

	    into_the_tail((double_linked_list *) comptr, 
			  (double_linked_list **) &commands, 
			  (double_linked_list **) &commandtail);
	    into_the_tail((double_linked_list *) comptr2, 
			  (double_linked_list **) &partner_cromosome->commands, 
			  (double_linked_list**)&partner_cromosome->commandtail);
	  

	    i += inslen;
	}
    }
    // more commands in the other strand than this?
    else if(bitlen<partner_cromosome->bitlen)
    {
	for(i=bitlen; i<(int)partner_cromosome->bitlen; i++)
	{
	    int instruction_found=0, inslen=0;
	    bool fathercode=true;
	    instruction *instr=NULL;

	    for(j=0;j<num_instructions && instruction_found==0; j++)
	    {
		instr=instructions[j];
		instruction_found=instr->check(partner_cromosome, i);
	    }
	  
	    if(instruction_found<0) // father code found in this strand
	    {
		fathercode=true;
		inslen = instr->get_total_length1();
	    }
	    else if(instruction_found>0)
	    {
		fathercode=false;
		inslen = instr->get_total_length2();
	    }

	    command *comptr = command::make_command(*instr, partner_cromosome, 
						    i, fathercode);
	    command *comptr2 = command::make_command(*instr, partner_cromosome, 
						     i, fathercode);

	    into_the_tail((double_linked_list *) comptr, 
			  (double_linked_list **) &commands, 
			  (double_linked_list **) &commandtail);
	    into_the_tail((double_linked_list *) comptr2, 
			  (double_linked_list **) &partner_cromosome->commands, 
			  (double_linked_list**)&partner_cromosome->commandtail);
	  

	    i += inslen;
	}
    }

}

// return the number of bits in this strand
unsigned int cromosome_strand::get_bitlength(void)
{
    return bitlen;
}

// return the number of bits in this strand
unsigned int cromosome_strand::get_cromosome_number(void)
{
    return cromnum;
}



// Return activated instructions as an array of pointers to command objects;
command **cromosome_strand::get_activated_commands(nodeset &activeset, 
						   unsigned int *length)
{
    unsigned int len=0;
    register command *ptr;

    for(ptr=commands; ptr; ptr = (command *) ptr->getnext())
	if(activeset.active(cromnum, ptr->get_position(),
			    ptr->get_length()))
	    len++;
    
    if(len>0)
    {
	command **comarray;
	register unsigned int i=0;

	*length=len;
	comarray=new command*[len];
	for(ptr=commands; ptr; ptr = (command *) ptr->getnext())
	{
	    if(activeset.active(cromnum, ptr->get_position(),
				ptr->get_length()))
		comarray[i++]=ptr;
	}

	return comarray;
    }
    else
    {
	*length=0;
	return NULL;
    }
}



void cromosome_strand::set_bit(unsigned int pos, bool state)
{
    static unsigned int bit = 1 << (longintlen*8-1);
    unsigned int arrpos = pos /longintlen;
    unsigned int bitpos = pos % longintlen;
    unsigned int bit2 = bit >> bitpos;
  
    if(arrpos<arraylen)
    {
	if(state)
	    contents[arrpos] = contents[arrpos] | bit2;
	else
	    contents[arrpos] = contents[arrpos] & (~bit2);
    }
}

// Interpretation methods for fetching content from the strand;

bool cromosome_strand::get_bit(unsigned int pos)
{
    static unsigned int bit = 1 << (longintlen*8-1);
    unsigned int arrpos = pos /longintlen;
    unsigned int bitpos = pos % longintlen;
    unsigned int bit2 = bit >> bitpos;
 
    if(arrpos<arraylen)
    {
	if(contents[arrpos] & bit2)
	    return true;
	else
	    return false;
    }
    else
	return false;
}

COMP_SIGN cromosome_strand::get_comp_sign(unsigned int pos)
{
    return (COMP_SIGN) get_unsigned_int(pos, 2);  
}


int cromosome_strand::get_long_int(unsigned int pos, 
					unsigned int len)
{
    int ret=0;

    if(bitlen < (pos + (unsigned int) len))
	return 0;

    if(get_bit(pos))
	ret = (1 << (longintlen*8-1)); // negative number

    for(unsigned int i=1; i<len;i++)
    {
	int bit = 1 << (len - i - 1);
      
	if(get_bit(pos+i))
	    ret = ret | bit;
    }

    return ret;
}

unsigned int cromosome_strand::get_unsigned_long_int(unsigned int 
							  pos, 
							  unsigned int len)
{
    unsigned int ret=0;

    if(bitlen < (pos + (unsigned int) len))
	return 0;

    for(unsigned int i=0; i<len;i++)
    {
	unsigned int bit = 1 << (len - i - 1);
      
	if(get_bit(pos+i))
	    ret = ret | bit;
    }

    return ret;
}

int cromosome_strand::get_int(unsigned int pos, unsigned int len)
{
    int ret=0;

    if(bitlen < (pos + (unsigned int) len))
	return 0;

    if(get_bit(pos))
	ret = (1 << (sizeof(int)*8-1)); // negative number

    for(unsigned int i=1; i<len;i++)
    {
	int bit = 1 << (len - i - 1);
      
	if(get_bit(pos+i))
	    ret = ret | bit;
    }

    return ret;
}

unsigned int cromosome_strand::get_unsigned_int(unsigned int pos, 
						unsigned int len)
{
    unsigned int ret=0;

    if(bitlen < (pos + (unsigned int) len))
	return 0;

    for(unsigned int i=0; i<len;i++)
    {
	unsigned int bit = 1 << (len - i - 1);
      
	if(get_bit(pos+i))
	    ret = ret | bit;
    }

    return ret;
}

char cromosome_strand::get_char(unsigned int pos, unsigned int len)
{
    return (char) (get_int(pos, len) % 256);
}

unsigned char cromosome_strand::get_unsigned_char(unsigned int pos, 
						  unsigned int len)
{
    return (unsigned char) (get_unsigned_int(pos, len) % 256);
}

double cromosome_strand::get_double(unsigned int pos, unsigned int len, 
				    double start, double end)
{
    unsigned int l=get_unsigned_long_int(pos, len);
    double totd = pow(2.0, (int)len)-1.0;
  
    return start + ((double) l)/totd * (end-start);
}





//                 NODESET
// Represents the local variables that each neural node has

nodeset::nodeset(nodeset *prev, node *parent, thread *standard_thread, 
		 unsigned int localn, replicatorset *ipt) : 
    double_linked_list((double_linked_list *) prev, NULL)
{
    nodeparent=parent;
    standardthread = new thread(standard_thread, NULL, NULL);
    pt=ipt;
  
    activehead = activetail = deactivehead = deactivetail = NULL;
  
    stopped=false;
    local_n = localn;
    num_cromo = pt->get_number_of_cromosomes();
    numactivated =  numdeactivated =0;
    number=0;

    int1=int2=int3=int4=0;
    real1=real2=real3=real4=1.0;
}

nodeset::nodeset(nodeset *prev, nodeset *setparent, node *parent, 
		 replicatorset *ipt, int number_) : 
    double_linked_list((double_linked_list *) prev, NULL)
{
    nodeparent=parent;
    standardthread = new thread(setparent->standardthread, NULL, NULL);
    pt=ipt;
  
    activehead = activetail = deactivehead = deactivetail = NULL;
  
    if(setparent->activehead)
    {
	activehead = new activated(NULL, setparent->activehead);
	activetail = (activated *) activehead->getlast();
    }

    if(setparent->deactivehead)
    {
	deactivehead = new activated(NULL, setparent->deactivehead);
	deactivetail = (activated *) deactivehead->getlast();
    }

    stopped=false;
    local_n = setparent->local_n;
    num_cromo = pt->get_number_of_cromosomes();
    numactivated = setparent->numactivated;
    numdeactivated = setparent->numdeactivated;
    number=number_;

    int1 = setparent->int1;
    int2 = setparent->int2;
    int3 = setparent->int3;
    int4 = setparent->int4;

    real1 = setparent->real1;
    real2 = setparent->real2;
    real3 = setparent->real3;
    real4 = setparent->real4;
}

nodeset::~nodeset()
{
    if(activehead)
	delete activehead;
    activehead=NULL;

    if(deactivehead)
	delete deactivehead;
    deactivehead=NULL;

    if(standardthread)
	delete standardthread;
    standardthread=NULL;

    nodeset *next = (nodeset *) getnext();

    removefromlist();

    if(next)
	delete next;
}

void nodeset::activate(  unsigned int cromnum, unsigned int pos, 
			 unsigned int len)
{
    activetail = new activated(activetail, cromnum, pos, len);
    if(!activehead)
	activehead = activetail;
}

void nodeset::activate(activated *newactivation, unsigned int len)
{ 
    for(activated *ptr=newactivation; ptr; ptr=(activated *) ptr->getnext())
    {
	activetail = new activated(activetail, ptr->get_crom_num(),
				   ptr->get_position(), len);
      
	if(!activehead)
	    activehead = activetail;
    }
}

void nodeset::deactivate(unsigned int cromnum, unsigned int pos, 
			 unsigned int len)
{
    deactivetail = new activated(deactivetail, cromnum, pos, len);
    if(!deactivehead)
	deactivehead = deactivetail;
}

void nodeset::deactivate(activated *newdeactivation, unsigned int len)
{ 
    for(activated *ptr=newdeactivation; ptr; ptr=(activated *) ptr->getnext())
    {
	deactivetail = new activated(deactivetail, ptr->get_crom_num(),
				     ptr->get_position(), len);
      
	if(!deactivehead)
	    deactivehead = deactivetail;
    }
}

bool nodeset::is_stopped(void)
{
    return stopped;
}

void nodeset::set_stop(void)
{
    stopped=true;
}

  
node *nodeset::get_node(void)
{
    return nodeparent;
}

thread *nodeset::get_standard_thread(void)
{
    return standardthread;
}

unsigned int nodeset::get_local_n(void)
{
    return local_n;
}

bool nodeset::active(unsigned int cromnum, unsigned int pos, 
			unsigned int len)
{
    bool act=false;
    register activated *ptr;
  
    // is the streach activated?
    // (is it contained inside one 'activated' structure)
    for(ptr=activehead; ptr && !act; ptr = (activated *) ptr->getnext())
    {
	if(cromnum == ptr->get_crom_num() &&
	   pos >= ptr->get_position() &&
	   (pos+len) < (ptr->get_position() + ptr->get_length()))
	{
	    act = true;
	    break;
	}
    }

    // is the streach deactivated? 
    // (does it overlap with a 'deactivated' structure)
    for(ptr=deactivehead; ptr && act; ptr = (activated *) ptr->getnext())
    {
	if(cromnum == ptr->get_crom_num() &&
	   ((ptr->get_position()>=pos &&
	     ptr->get_position()<=(pos+len)) ||
	    ((ptr->get_position()+ptr->get_length())>=pos &&
	     (ptr->get_position()+ptr->get_length())<=(pos+len))))
	{
	    act=false;
	    return act;
	}
    }
    
    return act;
}

void nodeset::getact(command *com,
		     bool *child1, bool *child2, 
		     bool *male, bool *female, 
		     bool *thin, bool *thout, bool *deact,
		     COMP_SIGN *thsign, COMP_SIGN *gensign,
		     unsigned int *gennum, unsigned int *threadnum,
		     unsigned int *crom, unsigned int *pos,
		     unsigned int *l)
{
    activation *actptr = (activation *) com;
  
    *child1  = actptr->get_child1();
    *child2  = actptr->get_child2();
    *thin    = actptr->get_inthread();
    *thout   = actptr->get_outthread();
    *thsign  = actptr->get_threadcomp();
    *male    = actptr->get_male();
    *female  = actptr->get_female();
    *gensign = actptr->get_gencomp();
    *threadnum = actptr->get_threadnum();
    *gennum  = actptr->get_gennum();
    *crom    = actptr->get_actcromnum();
    *pos     = actptr->get_actpos();
    *l       = local_n;
    *deact   = false;
}  
  
void nodeset::getdeact(command *com,
		       bool *child1, bool *child2, 
		       bool *male, bool *female, 
		       bool *thin, bool *thout, bool *deact,
		       COMP_SIGN *thsign, COMP_SIGN *gensign,
		       unsigned int *gennum, unsigned int *threadnum,
		       unsigned int *crom, unsigned int *pos,
		       unsigned int *l)
{
    deactivation *actptr = (deactivation *) com;
  
    *child1  = actptr->get_child1();
    *child2  = actptr->get_child2();
    *thin    = actptr->get_inthread();
    *thout   = actptr->get_outthread();
    *thsign  = actptr->get_threadcomp();
    *male    = actptr->get_male();
    *female  = actptr->get_female();
    *gensign = actptr->get_gencomp();
    *threadnum = actptr->get_threadnum();
    *gennum  = actptr->get_gennum();
    *crom    = actptr->get_deactcromnum();
    *pos     = actptr->get_deactpos();
    *l       = local_n;
    *deact   = true;
}  
  

void nodeset::getactl(command *com,
		      bool *child1, bool *child2, 
		      bool *male, bool *female, 
		      bool *thin, bool *thout, bool *deact,
		      COMP_SIGN *thsign, COMP_SIGN *gensign,
		      unsigned int *gennum, unsigned int *threadnum,
		      unsigned int *crom, unsigned int *pos,
		      unsigned int *l)
{
    lengthactivation *actptr = (lengthactivation *) com;
  
    *child1  = actptr->get_child1();
    *child2  = actptr->get_child2();
    *thin    = actptr->get_inthread();
    *thout   = actptr->get_outthread();
    *thsign  = actptr->get_threadcomp();
    *male    = actptr->get_male();
    *female  = actptr->get_female();
    *gensign = actptr->get_gencomp();
    *threadnum = actptr->get_threadnum();
    *gennum  = actptr->get_gennum();
    *crom    = actptr->get_actcromnum();
    *pos     = actptr->get_actpos();
    *l       = actptr->get_actlen();
    *deact   = false;
}  
  
void nodeset::getdeactl(command *com,
			bool *child1, bool *child2, 
			bool *male, bool *female, 
			bool *thin, bool *thout, bool *deact,
			COMP_SIGN *thsign, COMP_SIGN *gensign,
			unsigned int *gennum, unsigned int *threadnum,
			unsigned int *crom, unsigned int *pos,
			unsigned int *l)
{
    lengthdeactivation *actptr = (lengthdeactivation *) com;
  
    *child1  = actptr->get_child1();
    *child2  = actptr->get_child2();
    *thin    = actptr->get_inthread();
    *thout   = actptr->get_outthread();
    *thsign  = actptr->get_threadcomp();
    *male    = actptr->get_male();
    *female  = actptr->get_female();
    *gensign = actptr->get_gencomp();
    *threadnum = actptr->get_threadnum();
    *gennum  = actptr->get_gennum();
    *crom    = actptr->get_deactcromnum();
    *pos     = actptr->get_deactpos();
    *l       = actptr->get_deactlen();
    *deact   = true;
}  
  

void nodeset::interprete_activate(unsigned int gen, command *com, 
				  int childnum)
{
    INSTRCUTION_TYPE type=com->get_type();
    bool child1=false, child2=false, male=false, 
	female=false, thin=false, thout=false, deact=false;
    COMP_SIGN thsign=NOTEQUAL, gensign=NOTEQUAL;
    unsigned int gennum=10, threadnum=10;
    unsigned int crom=0, pos=0, l=1000;
    threadlist *thl1=nodeparent->get_in_threads(),
	*thl2=nodeparent->get_out_threads();
  
    unsigned int numin = (thl1 ? thl1->number_of_elements() : 0),
	numout = (thl2 ? thl2->number_of_elements() : 0),
	numthreads = numin+numout;
    GENDER gender=pt->get_gender();

    switch(type)
    {
	case ACTIVATE:
	    getact(com, &child1, &child2, &male, &female, &thin, &thout, 
		   &deact, &thsign, &gensign, &threadnum, &gennum, &crom, &pos, &l);
	    break;
	case DEACTIVATE: 
	    getdeact(com, &child1, &child2, &male, &female, &thin, &thout, 
		     &deact, &thsign, &gensign, &threadnum, &gennum, &crom, &pos, 
		     &l);
	    break;
	case ACTIVATEL:
	    getactl(com, &child1, &child2, &male, &female, &thin, &thout, 
		    &deact, &thsign, &gensign, &threadnum, &gennum, &crom, &pos, 
		    &l);
	    break;
	case DEACTIVATEL:
	    getdeactl(com, &child1, &child2, &male, &female, &thin, &thout, 
		      &deact, &thsign, &gensign, &threadnum, &gennum, &crom, &pos, 
		      &l);
	    break;
	default:
	    break;
    }    

    // wrong child number?
    if(childnum==1 && !child1)
	return;
    if(childnum==2 && !child2)
	return;
    if(childnum==0 && (child1 || child2))
	return;

    // wrong number of threads?
    if(thin && thout && !compare_using_sign(thsign, numthreads, threadnum))
	return;
    else if(thin && !thout && !compare_using_sign(thsign, numin, threadnum))
	return;
    else if(!thin && thout && !compare_using_sign(thsign, numout, threadnum))
	return;

    // wrong gender?
    if(!male && !female && gender!=CLONE)
	return;
    if(!male && gender==MALE)
	return;
    if(!female && gender==FEMALE)
	return;

    // wrong cell generation?
    if(!compare_using_sign(gensign, gen, gennum))
	return;

    if(!deact)
	activate(crom, pos, l);
    else
	deactivate(crom, pos, l);
}

void nodeset::interprete_chn(command *com)
{
    change_n *chn = (change_n *) com;

    local_n = chn->get_new_n();
}

void nodeset::interprete_chnpros(command *com)
{
    change_npros *chn = (change_npros *) com;
    double pros = r2rp(chn->get_new_npros());

    local_n = (unsigned int) (pros * (double) local_n); 
}

void nodeset::interprete_chnode(command *com)
{
    change_node *chnode = (change_node *) com;
    bool abs = chnode->use_absolute();
    unsigned int var = chnode->get_var_num();
    double proc = chnode->get_procent();

    nodeparent->change_var(var, abs, proc);
}

void nodeset::interprete_chstthread(command *com)
{
    change_standard_thread *chst = (change_standard_thread *) com;
    bool abs = chst->use_absolute();
    unsigned int var = chst->get_var_num();
    double proc = chst->get_procent();

    standardthread->change_var(var, abs, proc);
}

void nodeset::interprete_challthreads(command *com)
{
    change_all_threads *chall = (change_all_threads *) com;
    bool abs = chall->use_absolute();
    bool usein = chall->use_in_threads();
    bool useout = chall->use_out_threads();
    unsigned int var = chall->get_var_num();
    double proc = chall->get_procent();

    if(!usein && !useout)
	usein=useout=true;

    nodeparent->change_threads(var, usein, useout, abs, proc);
}

void nodeset::interprete_chthread(command *com)
{
    change_thread *chth = (change_thread *) com;
    bool abs = chth->use_absolute();
    unsigned int var = chth->get_var_num();
    double proc = chth->get_procent();
    unsigned int threadnum = chth->get_thread_number();

    nodeparent->change_thread(var, abs, proc, threadnum);
}

// Interprete REM 
void nodeset::interprete_rem(command *com)
{
    remove_thread *rmth = (remove_thread *) com;
    bool usechild1 = rmth->use_child1();
    bool usechild2 = rmth->use_child2();
    unsigned int threadnum = rmth->get_thread_number();

    if(!usechild1)
	nodeparent->remove_synaps_fromchild1(threadnum);
    if(!usechild2)
	nodeparent->remove_synaps_fromchild2(threadnum);

    if(usechild1 && usechild2)
	nodeparent->remove_synaps(threadnum);

    //cout << FORM("%c %c %d", (usechild1 ? 'y' : 'n'), (usechild2 ? 'y' : 'n'),
    //       threadnum) << endl;
}

// Interprete REM1 and REM2
void nodeset::interprete_var_rem(unsigned int gen, command *com)
{
    remove_thread *rmth = (remove_thread *) com;
    bool child1 = rmth->use_child1();
    bool child2 = rmth->use_child2();
    unsigned int varnum = rmth->get_thread_number();
    int vartype = rmth->get_type()==REM1 ? 1 : 3;
    unsigned int threadnum = get_int_number(varnum, vartype, gen, 0);

    if(!child1)
	nodeparent->remove_synaps_fromchild1(threadnum);
    if(!child2)
	nodeparent->remove_synaps_fromchild2(threadnum);

    if(child1 && child2)
	nodeparent->remove_synaps(threadnum);
}

unsigned int nodeset::get_int_number(unsigned int varnum, int vartype,
					  unsigned int gen, int childnum)
{
    if(vartype<1 || vartype>3)
	return (unsigned int) MISSING_VALUE;

    threadlist *thl1=nodeparent->get_in_threads(),
	*thl2=nodeparent->get_out_threads();
    unsigned int numin = (thl1 ? thl1->number_of_elements() : 0),
	numout = (thl2 ? thl2->number_of_elements() : 0),
	numthreads = numin+numout;

    int var1=8, var2=17+6*numthreads, var3=9;

    if(vartype==1)
	varnum %= var1;
    else if(vartype==2)
	varnum %= (var1+var2);
    else
	varnum %= (var1+var2+var3);

    switch(varnum)
    {
	case 0:
	    return (unsigned int) int1;
	case 1:
	    return (unsigned int) int2;
	case 2:
	    return (unsigned int) int3;
	case 3:
	    return (unsigned int) int4;
	case 4:
	    return (unsigned int) real1;
	case 5:
	    return (unsigned int) real2;
	case 6:
	    return (unsigned int) real3;
	case 7:
	    return (unsigned int) real4;
	case 8:
	    return (unsigned int) local_n;
	case 9:
	    return (unsigned int) standardthread->get_r();
	case 10:
	    return (unsigned int) standardthread->get_m();
	case 11:
	    return (unsigned int) standardthread->get_a();
	case 12:
	    return (unsigned int) standardthread->get_f0();
	case 13:
	    return (unsigned int) standardthread->get_g();
	case 14:
	    return (unsigned int) standardthread->get_d();
	case 15:
	    return (unsigned int) nodeparent->get_r();
	case 16:
	    return (unsigned int) nodeparent->get_m();
	case 17:
	    return (unsigned int) nodeparent->get_x0();
	case 18:
	    return (unsigned int) nodeparent->get_l();
	case 19:
	    return (unsigned int) nodeparent->get_g();
	case 20:
	    return (unsigned int) nodeparent->get_gamma();
	case 21:
	    return (unsigned int) nodeparent->get_d();
	case 22:
	    return (unsigned int) nodeparent->get_reload();
	case 23:
	    return (unsigned int) nodeparent->get_fatigue_level();
	case 24:
	    return (unsigned int) nodeparent->get_fatigue_decrease();
	default:
	    if((int)varnum<(var1+var2)) // thread variable
	    {
		unsigned int varnum2=varnum-var1-17;
		unsigned int thnum=varnum2/6;
		unsigned int varnum3=varnum2%6;
		thread *th=nodeparent->getthread(thnum);

		if(!th)
		    return (unsigned int) MISSING_VALUE;

		switch(varnum3)
		{
		    case 0:
			return (unsigned int) th->get_r();
		    case 1:
			return (unsigned int) th->get_m();
		    case 2:
			return (unsigned int) th->get_a();
		    case 3:
			return (unsigned int) th->get_f0();
		    case 4:
			return (unsigned int) th->get_g();
		    case 5:
			return (unsigned int) th->get_d();
		}
	    }
	    else
	    {
		unsigned int varnum2=varnum-var1-var2;
	  
		switch(varnum2)
		{
		    case 0:
			return (unsigned int) gen;
		    case 1:
			return (unsigned int) numthreads;
		    case 2:
			return (unsigned int) numin;
		    case 3:
			return (unsigned int) numout;
		    case 4:
			return (unsigned int) pt->get_global_n();
		    case 5:
			return (unsigned int) pt->get_gender();
		    case 6:
			return (unsigned int) number;
		    case 7:
			return (unsigned int) childnum;
		}
	    }
	
    }

    return (unsigned int) MISSING_VALUE;
}
	
void nodeset::set_int_number(unsigned int varnum, int vartype,
			     unsigned int newint)
{
    if(vartype<1 || vartype>2)
	return;

    threadlist *thl1=nodeparent->get_in_threads(),
	*thl2=nodeparent->get_out_threads();
    unsigned int numin = (thl1 ? thl1->number_of_elements() : 0),
	numout = (thl2 ? thl2->number_of_elements() : 0),
	numthreads = numin+numout;

    int var1=8, var2=17+6*numthreads;

    if(vartype==1)
	varnum %= var1;
    else 
	varnum %= (var1+var2);

    switch(varnum)
    {
	case 0:
	    int1=newint;
	    break;
	case 1:
	    int2=newint;
	    break;
	case 2:
	    int3=newint;
	    break;
	case 3:
	    int4=newint;
	    break;
	case 4:
	    real1=(double) newint;
	    break;
	case 5:
	    real2=(double) newint;
	    break;
	case 6:
	    real3=(double) newint;
	    break;
	case 7:
	    real4=(double) newint;
	    break;
	case 8:
	    local_n=newint;
	    break;
	case 9:
	    standardthread->change_r((double) newint);
	    break;
	case 10:
	    standardthread->change_m((double) newint);
	    break;
	case 11:
	    standardthread->change_a((double) newint);
	    break;
	case 12:
	    standardthread->change_f0((double) newint);
	    break;
	case 13:
	    standardthread->change_g((double) newint);
	    break;
	case 14:
	    standardthread->change_d((double) newint);
	    break;
	case 15:
	    nodeparent->change_r((double) newint);
	    break;
	case 16:
	    nodeparent->change_m((double) newint);
	    break;
	case 17:
	    nodeparent->change_x0((double) newint);
	    break;
	case 18:
	    nodeparent->change_l((double) newint);
	    break;
	case 19:
	    nodeparent->change_g((double) newint);
	    break;
	case 20:
	    nodeparent->change_gamma((double) newint);
	    break;
	case 21:
	    nodeparent->change_d((double) newint);
	    break;
	case 22:
	    nodeparent->change_reload((double) newint);
	    break;
	case 23:
	    nodeparent->change_fatigue_level((double) newint);
	    break;
	case 24:
	    nodeparent->change_fatigue_decrease((double) newint);
	    break;
	default: // thread variable
	{
	    unsigned int varnum2=varnum-var1-17;
	    unsigned int thnum=varnum2/6;
	    unsigned int varnum3=varnum2%6;
	    thread *th=nodeparent->getthread(thnum);
	
	    if(!th)
		return;

	    switch(varnum3)
	    {
		case 0:
		    th->change_r((double) newint);
		    break;
		case 1:
		    th->change_m((double) newint);
		    break;
		case 2:
		    th->change_a((double) newint);
		    break;
		case 3:
		    th->change_f0((double) newint);
		    break;
		case 4:
		    th->change_g((double) newint);
		    break;
		case 5:
		    th->change_d((double) newint);
		    break;
	    }
	}
    }

}
	
	
void nodeset::set_double_number(unsigned int varnum, int vartype, double newdbl)
{
    if(vartype<1 || vartype>2)
	return;

    threadlist *thl1=nodeparent->get_in_threads(),
	*thl2=nodeparent->get_out_threads();
    unsigned int numin = (thl1 ? thl1->number_of_elements() : 0),
	numout = (thl2 ? thl2->number_of_elements() : 0),
	numthreads = numin+numout;

    int var1=8, var2=17+6*numthreads;

    if(vartype==1)
	varnum %= var1;
    else 
	varnum %= (var1+var2);

    switch(varnum)
    {
	case 0:
	    int1=(unsigned int) newdbl;
	    break;
	case 1:
	    int2=(unsigned int) newdbl;
	    break;
	case 2:
	    int3=(unsigned int) newdbl;
	    break;
	case 3:
	    int4=(unsigned int) newdbl;
	    break;
	case 4:
	    real1=newdbl;
	    break;
	case 5:
	    real2=newdbl;
	    break;
	case 6:
	    real3=newdbl;
	    break;
	case 7:
	    real4=newdbl;
	    break;
	case 8:
	    local_n=(unsigned int) newdbl;
	    break;
	case 9:
	    standardthread->change_r(newdbl);
	    break;
	case 10:
	    standardthread->change_m(newdbl);
	    break;
	case 11:
	    standardthread->change_a(newdbl);
	    break;
	case 12:
	    standardthread->change_f0(newdbl);
	    break;
	case 13:
	    standardthread->change_g(newdbl);
	    break;
	case 14:
	    standardthread->change_d(newdbl);
	    break;
	case 15:
	    nodeparent->change_r(newdbl);
	    break;
	case 16:
	    nodeparent->change_m(newdbl);
	    break;
	case 17:
	    nodeparent->change_x0(newdbl);
	    break;
	case 18:
	    nodeparent->change_l(newdbl);
	    break;
	case 19:
	    nodeparent->change_g(newdbl);
	    break;
	case 20:
	    nodeparent->change_gamma(newdbl);
	    break;
	case 21:
	    nodeparent->change_d(newdbl);
	    break;
	case 22:
	    nodeparent->change_reload(newdbl);
	    break;
	case 23:
	    nodeparent->change_fatigue_level(newdbl);
	    break;
	case 24:
	    nodeparent->change_fatigue_decrease(newdbl);
	    break;
	default: // thread variable
	{
	    unsigned int varnum2=varnum-var1-17;
	    unsigned int thnum=varnum2/6;
	    unsigned int varnum3=varnum2%6;
	    thread *th=nodeparent->getthread(thnum);
	
	    if(!th)
		return;

	    switch(varnum3)
	    {
		case 0:
		    th->change_r(newdbl);
		    break;
		case 1:
		    th->change_m(newdbl);
		    break;
		case 2:
		    th->change_a(newdbl);
		    break;
		case 3:
		    th->change_f0(newdbl);
		    break;
		case 4:
		    th->change_g(newdbl);
		    break;
		case 5:
		    th->change_d(newdbl);
		    break;
	    }
	}
    }

}
	
	
	
double nodeset::get_db_number(unsigned int varnum, int vartype,
			      unsigned int gen, int childnum)
{
    if(vartype<1 || vartype>3)
	return (double) MISSING_VALUE;

    threadlist *thl1=nodeparent->get_in_threads(),
	*thl2=nodeparent->get_out_threads();
    unsigned int numin = (thl1 ? thl1->number_of_elements() : 0),
	numout = (thl2 ? thl2->number_of_elements() : 0),
	numthreads = numin+numout;

    int var1=8, var2=17+6*numthreads, var3=9;

    if(vartype==1)
	varnum %= var1;
    else if(vartype==2)
	varnum %= (var1+var2);
    else
	varnum %= (var1+var2+var3);

    switch(varnum)
    {
	case 0:
	    return (double) int1;
	case 1:
	    return (double) int2;
	case 2:
	    return (double) int3;
	case 3:
	    return (double) int4;
	case 4:
	    return (double) real1;
	case 5:
	    return (double) real2;
	case 6:
	    return (double) real3;
	case 7:
	    return (double) real4;
	case 8:
	    return (double) local_n;
	case 9:
	    return (double) standardthread->get_r();
	case 10:
	    return (double) standardthread->get_m();
	case 11:
	    return (double) standardthread->get_a();
	case 12:
	    return (double) standardthread->get_f0();
	case 13:
	    return (double) standardthread->get_g();
	case 14:
	    return (double) standardthread->get_d();
	case 15:
	    return (double) nodeparent->get_r();
	case 16:
	    return (double) nodeparent->get_m();
	case 17:
	    return (double) nodeparent->get_x0();
	case 18:
	    return (double) nodeparent->get_l();
	case 19:
	    return (double) nodeparent->get_g();
	case 20:
	    return (double) nodeparent->get_gamma();
	case 21:
	    return (double) nodeparent->get_d();
	case 22:
	    return (double) nodeparent->get_reload();
	case 23:
	    return (double) nodeparent->get_fatigue_level();
	case 24:
	    return (double) nodeparent->get_fatigue_decrease();
	default:
	    if((int)varnum<(var1+var2)) // thread variable
	    {
		unsigned int varnum2=varnum-var1-17;
		unsigned int thnum=varnum2/6;
		unsigned int varnum3=varnum2%6;
		thread *th=nodeparent->getthread(thnum);

		if(!th)
		    return (double) MISSING_VALUE;

		switch(varnum3)
		{
		    case 0:
			return (double) th->get_r();
		    case 1:
			return (double) th->get_m();
		    case 2:
			return (double) th->get_a();
		    case 3:
			return (double) th->get_f0();
		    case 4:
			return (double) th->get_g();
		    case 5:
			return (double) th->get_d();
		}
	    }
	    else
	    {
		unsigned int varnum2=varnum-var1-var2;
	  
		switch(varnum2)
		{
		    case 0:
			return (double) gen;
		    case 1:
			return (double) numthreads;
		    case 2:
			return (double) numin;
		    case 3:
			return (double) numout;
		    case 4:
			return (double) pt->get_global_n();
		    case 5:
			return (double) pt->get_gender();
		    case 6:
			return (double) number;
		    case 7:
			return (double) childnum;
		}
	    }
	
    }

    return (double) MISSING_VALUE;
}
	
bool nodeset::get_use_real(unsigned int varnum, int vartype)
{
    if(vartype<1 || vartype>3)
	return false;;

    threadlist *thl1=nodeparent->get_in_threads(),
	*thl2=nodeparent->get_out_threads();
    unsigned int numin = (thl1 ? thl1->number_of_elements() : 0),
	numout = (thl2 ? thl2->number_of_elements() : 0),
	numthreads = numin+numout;

    int var1=8, var2=17+6*numthreads, var3=9;

    if(vartype==1)
	varnum %= var1;
    else if(vartype==2)
	varnum %= (var1+var2);
    else
	varnum %= (var1+var2+var3);

    switch(varnum)
    {
	case 0:
	case 1:
	case 2:
	case 3:
	    return false;
	case 4:
	case 5:
	case 6:
	case 7:
	    return true;
	case 8:
	    return false;
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 24:
	    return true;
	default:
	    if((int)varnum<(var1+var2)) // thread variable
		return true;
	    else
		return false;
    }

    return false;
}
		
// interprete IF1 and IF3			  
void nodeset::interprete_if(unsigned int gen, command *com, 
			    int childnum)
{
    if(!com)
	return;

    ifclass *ifobj = (ifclass *) com;
    COMP_SIGN comp = ifobj->get_comp();
    int vartype=ifobj->get_do_var3() ? 3 : 1;
    unsigned int int_1 = get_int_number(ifobj->get_varnum1(), vartype,
					     gen, childnum);
    unsigned int int_2 = get_int_number(ifobj->get_varnum2(), vartype,
					     gen, childnum);
    double db1 = get_db_number(ifobj->get_varnum1(), vartype, gen, childnum);
    double db2 = get_db_number(ifobj->get_varnum2(), vartype, gen, childnum);
    bool usereal1 = get_use_real(ifobj->get_varnum1(),vartype);
    bool usereal2 = get_use_real(ifobj->get_varnum2(),vartype);
    unsigned int crom=ifobj->get_crom_num();
    unsigned int pos=ifobj->get_position()+ifobj->get_length();
    unsigned int len=ifobj->get_actlen();

    if(usereal1 && !usereal2)
	db2=(double) int_2;
    else if(!usereal1 && usereal2)
	db1=(double) int_1;

    if(!usereal1 && !usereal2)
    {
	if(compare_using_sign(comp, int_1, int_2))
	    activate(crom, pos, len);
	else
	    deactivate(crom, pos, len);
    }
    else 
    {
	if(compare_using_sign(comp, db1, db2))
	    activate(crom, pos, len);
	else
	    deactivate(crom, pos, len);
    }
}

// interprete IF2 and IF4
void nodeset::interprete_if_num(unsigned int gen, command *com, int childnum)
{
    if(!com)
	return;

    if_num *ifobj = (if_num *) com;
    COMP_SIGN comp = ifobj->get_comp();
    int vartype=ifobj->get_do_var3() ? 3 : 1;
    unsigned int int_1 = get_int_number(ifobj->get_varnum(), vartype,
					     gen, childnum);
    unsigned int int_2 = ifobj->get_intnumber();
    double db1 = get_db_number(ifobj->get_varnum(),vartype, gen, childnum);
    double db2 = ifobj->get_dbnumber();
    bool usereal = get_use_real(ifobj->get_varnum(),vartype);
    unsigned int crom=ifobj->get_crom_num();
    unsigned int pos=ifobj->get_position()+ifobj->get_length();
    unsigned int len=ifobj->get_actlen();

    if(!usereal)
    {
	if(compare_using_sign(comp, int_1, int_2))
	    activate(crom, pos, len);
	else
	    deactivate(crom, pos, len);
    }
    else 
    {
	if(compare_using_sign(comp, db1, db2))
	    activate(crom, pos, len);
	else
	    deactivate(crom, pos, len);
    }
}

// interprete INC1/INC2/.../NEG1/NEG2
void nodeset::interprete_operation(command *com, int childnum)
{
    if(!com)
	return;

    single_operation *soper = (single_operation *) com;
    int vartype = (soper->get_type()==INC1 || soper->get_type()==DEC1 ||
		   soper->get_type()==HALF1 || soper->get_type()==DOUBLE1 ||
		   soper->get_type()==NEG1) ? 1 : 2; 
    unsigned int int_1 = get_int_number(soper->get_varnum(), vartype, 0, 0);
    double dbl = get_db_number(soper->get_varnum(), vartype, 0, 0);
    bool usereal = get_use_real(soper->get_varnum(), vartype);
    bool child1=soper->use_child1(), child2=soper->use_child2();

    if(childnum==0 && (child1 || child2))
	return;
    if(childnum==1 && !child1)
	return;
    if(childnum==2 && !child2)
	return;

    if(!usereal)
    {
	switch(soper->get_type())
	{
	    case INC1:
	    case INC2: 
		int_1++;
		break;
	    case DEC1:
	    case DEC2:
		int_1--;
		break;
	    case HALF1:
	    case HALF2: 
		int_1/=2;
		break;
	    case DOUBLE1:
	    case DOUBLE2: 
		int_1*=2;
		break;
	    case NEG1:
	    case NEG2:
		// NOP
		break;
	    default:
		break;
	}

	set_int_number(soper->get_varnum(), vartype, int_1);
    }
    else 
    {
	switch(soper->get_type())
	{
	    case INC1:
	    case INC2: 
		dbl++;
		break;
	    case DEC1:
	    case DEC2:
		dbl--;
		break;
	    case HALF1:
	    case HALF2: 
		dbl/=2.0;
		break;
	    case DOUBLE1:
	    case DOUBLE2: 
		dbl*=2.0;
		break;
	    case NEG1:
	    case NEG2:
		dbl = -dbl;
		break;
	    default:
		break;
	}

	set_double_number(soper->get_varnum(), vartype, dbl);
    }
}

// interprete INC1/INC2/.../NEG1/NEG2
void nodeset::interprete_changevar(unsigned int gen, command *com, int childnum)
{
    if(!com)
	return;

    changevar *chvar = (changevar *) com;
    int vartype1=1, vartype2=1;

    if(chvar->get_type()==CHANGEVAR4 || chvar->get_type()==CHANGEVAR5)
	vartype1=2;

    if(chvar->get_type()==CHANGEVAR2 || chvar->get_type()==CHANGEVAR4)
	vartype2=2;
    else if(chvar->get_type()==CHANGEVAR5)
	vartype2=5;

    unsigned int int_1 = get_int_number(chvar->get_varnum1(), vartype1, 
					     gen, childnum);
    unsigned int int_2 = get_int_number(chvar->get_varnum2(), vartype2, 
					     gen, childnum);

    double db1 = get_db_number(chvar->get_varnum1(), vartype1, gen, childnum);
    double db2 = get_db_number(chvar->get_varnum2(), vartype2, gen, childnum);
    bool usereal = get_use_real(chvar->get_varnum1(), vartype1);
    bool child1=chvar->use_child1(), child2=chvar->use_child2();

    if(childnum==0 && (child1 || child2))
	return;
    if(childnum==1 && !child1)
	return;
    if(childnum==2 && !child2)
	return;

    if(!usereal)
    {
	switch(chvar->get_changeoper())
	{
	    case CHANGE_SET1:
	    case CHANGE_SET2:
	    case CHANGE_SET3:
		int_1 = int_2;
		break;
	    case CHANGE_MOD:
		if(int_2>=1)
		    int_1 %= int_2;
		break;
	    case CHANGE_ADD:
		int_1 += int_2;
		break;
	    case CHANGE_SUB:
		int_1 -= int_2;
		break;
	    case CHANGE_MULT:
		int_1 *= int_2;
		break;
	    case CHANGE_DIV:
		if(int_2>=1)
		    int_1 /= int_2;
		break;
	}

	set_int_number(chvar->get_varnum1(), vartype1, int_1);
    }
    else 
    {
	switch(chvar->get_changeoper())
	{
	    case CHANGE_SET1:
	    case CHANGE_SET2:
	    case CHANGE_SET3:
		db1 = db2;
		break;
	    case CHANGE_MOD:
		if(int_2>=1)
		{
		    db1 -= floor(db1);
		    db1 += double(int_1%int_2);
		}
		break;
	    case CHANGE_ADD:
		db1 += db2;
		break;
	    case CHANGE_SUB:
		db1 -= db2;
		break;
	    case CHANGE_MULT:
		db1 *= db2;
		break;
	    case CHANGE_DIV:
		if(db2!=0.0)
		    db1 /= db2;
		break;
	}

	set_double_number(chvar->get_varnum1(), vartype1, db1);
    }
}


//                REPLICATORSET
// This represent the whole replicator, and contains
// methods for building a neural net from such a replicator

unsigned int replicatorset::get_number_of_cromosomes(void)
{
    return num_cromo;
}

cromosome_strand *replicatorset::get_father_strand(unsigned int
						   cromosome_number)
{
    return fatherstrands[cromosome_number];
}

cromosome_strand *replicatorset::get_mother_strand(unsigned int 
						   cromosome_number)
{
    return motherstrands[cromosome_number];
}

double replicatorset::mutatedouble(double incoming, double min, double max, 
				   double size)
{
    double rr=gauss()*variablemutatesize*size*(max-min);
    double ret = incoming+rr;
  
    ret=MINIM(ret, max);
    ret=MAXIM(ret, min);

    return ret;
}

unsigned int replicatorset::mutateint(unsigned int incoming, 
					   unsigned int min, 
					   unsigned int max,
					   unsigned int size)
{
    unsigned int ret=incoming;

    if(max-min<20)
    {
	if(drand48()<0.5)
	    ret-=size;
	else 
	    ret+=size;
    }
    else
    {
	double mindbl=double(min);
	double maxdbl=double(max);
	double rr1=(2.0*drand48()-1.0)*(maxdbl-mindbl)*pow(10.0, (int)size);
	double rr2=(2.0*drand48()-1.0)*ABSVAL(double(incoming))*pow(10.0, (int)size);
      
	if(incoming==0)
	    ret += (unsigned int) rr1;
	else
	    ret += (unsigned int) rr2;
    }

    ret=MINIM(ret, max);
    ret=MAXIM(ret, min);
  
    return ret;
}

double replicatorset::splice_dbl_and_mutate(double dbl1, double dbl2, 
					    double min, double max)
{
    double ret;

    if(drand48()<0.5)
	ret=dbl1;
    else
	ret=dbl2;

    if(drand48()<variablemutaterate)
	ret = mutatedouble(ret, min, max, 1.0);
    else if(drand48()<variablemutaterate/10.0)
	ret = mutatedouble(ret, min, max, 10.0);
    else if(drand48()<variablemutaterate/100.0)
	ret = mutatedouble(ret, min, max, 100.0);
    else if(drand48()<variablemutaterate/1000.0)
	ret = mutatedouble(ret, min, max, 1000.0);

    return ret;
}

unsigned int replicatorset::splice_int_and_mutate(unsigned int i1,
						       unsigned int i2,
						       unsigned int min,
						       unsigned int max)
{
    unsigned int  ret;

    if(drand48()<0.5)
	ret=i1;
    else
	ret=i2;

    if(drand48()<variablemutaterate)
	ret = mutateint(ret, min, max, 1);
    else if(drand48()<variablemutaterate/10.0)
	ret = mutateint(ret, min, max, 2);
    else if(drand48()<variablemutaterate/100.0)
	ret = mutateint(ret, min, max, 3);
    else if(drand48()<variablemutaterate/1000.0)
	ret = mutateint(ret, min, max, 4);

    return ret;
}

double replicatorset::find_dominant_dbl(double dbl1, double dbl2)
{
    if(dbl1==dbl2)
	return dbl1;

    char *con1=(char *) &dbl1;
    char *con2=(char *) &dbl2;

    cromosome_strand buffer1(this, 101, con1, 4);
    cromosome_strand buffer2(this, 102, con2, 4);
  
    buffer1.flip(0);
    buffer2.flip(0);

    unsigned int comp1=buffer1.get_unsigned_long_int(0, 32);
    unsigned int comp2=buffer2.get_unsigned_long_int(0, 32);

    if(comp1>comp2)
	return dbl1;
    else
	return dbl2;
}

unsigned int replicatorset::find_dominant_int(unsigned int i1,
						   unsigned int i2)
{
    if(i1==i2)
	return i1;

    char *con1=(char *) &i1;
    char *con2=(char *) &i2;

    cromosome_strand buffer1(this, 101, con1, 4);
    cromosome_strand buffer2(this, 102, con2, 4);
  
    buffer1.flip(0);
    buffer2.flip(0);

    unsigned int comp1=buffer1.get_unsigned_long_int(0, 32);
    unsigned int comp2=buffer2.get_unsigned_long_int(0, 32);

    if(comp1>comp2)
	return i1;
    else
	return i2;
}
  
void replicatorset::mutate(replicatorset *parent1, replicatorset *parent2)
{
    register int i,j;

    /*cout << FORM("parent 1: p=%g l=%g L=%g r=%g flip=%g", 
      parent1->pointmutationrate, parent1->linemutation, 
      parent1->linelen, parent1->flip_ratio) << endl;
      cout << FORM("parent 2: p=%g l=%g L=%g r=%g flip=%g", 
      parent2->pointmutationrate, parent2->linemutation, 
      parent2->linelen, parent2->flip_ratio) << endl;*/

    // point mutations;
    for(i=0; i<(int)num_cromo; i++)
    {
	double pointmut1 = parent1->pointmutationrate;
	double pointmut2 = parent2->pointmutationrate;

	if(i==0)
	{
	    pointmut1 = parent1->pointmutationrate_1;
	    pointmut2 = parent2->pointmutationrate_1;
	}
	else if(i==1)
	{
	    pointmut1 = parent1->pointmutationrate_2;
	    pointmut2 = parent2->pointmutationrate_2;
	}
	
	// parent 1;
	for(j=0; j<(int)fatherstrands[i]->get_bitlength(); j++)
	    if(drand48()<pointmut1)
		fatherstrands[i]->point_mutate(j);

	// parent 2;
	for(j=0; j<(int)motherstrands[i]->get_bitlength(); j++)
	    if(drand48()<pointmut2)
		motherstrands[i]->point_mutate(j);
    }

    unsigned int num_cromo2=num_cromo;
    // line mutations;
    for(i=0; i<(int)MINIM(num_cromo, num_cromo2); i++)
    {
	double linemut1 = parent1->linemutation;
	double linemut2 = parent2->linemutation;

	if(i==0)
	{
	    linemut1 = parent1->linemutation_1;
	    linemut2 = parent2->linemutation_1;
	}
	else if(i==1)
	{
	    linemut1 = parent1->linemutation_2;
	    linemut2 = parent2->linemutation_2;
	}
	
	// parent 1;
	for(j=0; i<(int)MINIM(num_cromo, num_cromo2) && 
		j<(int)(fatherstrands[i]->get_bitlength()-sizeof(int)*8) &&
		fatherstrands[i]->get_bitlength()>sizeof(int)*8; j++)
	{
	    if(drand48() < linemut1)
	    {
		double r=drand48();
		double len2 = exp(drand48() * log(linelen));
	      
		if(drand48()<0.1)
		    len2 *= 10.0;
		else if(drand48()<0.01)
		    len2 *= 100.0;
		else if(drand48()<0.001)
		    len2 *= 1000.0;
		else if(drand48()<0.0001)
		    len2 *= 10000.0;

		unsigned int len = MINIM((unsigned int ) len2,
					      fatherstrands[i]->get_bitlength());
		len=MAXIM(len, 1);

		if(r<0.1 && fatherstrands[i]->get_bitlength()>1024 && 
		   num_cromo2>3 && len>=fatherstrands[i]->get_bitlength()/5) 
		    // remove a cromosome
		{
		    int ii;

		    // prepend or append this cromosome to another?
		    if(drand48()<0.5) 
		    {
			do
			    ii=int(drand48()*num_cromo2);
			while(ii==i);
		      
			if(drand48()<0.5)
			{
			    fatherstrands[ii]->paste(fatherstrands[i], 0);
			    motherstrands[ii]->paste(motherstrands[i], 0);
			}
			else
			{
			    fatherstrands[ii]->paste(fatherstrands[i], 
						     fatherstrands[ii]->
						     get_bitlength());
			    motherstrands[ii]->paste(motherstrands[i],  
						     motherstrands[ii]->
						     get_bitlength());
			}
		    }

		    delete fatherstrands[i];
		    delete motherstrands[i];

		    num_cromo2--;

		    for(ii=i; ii<(int)num_cromo2;ii++)
		    {
			fatherstrands[ii]=fatherstrands[ii+1];
			motherstrands[ii]=motherstrands[ii+1];
		    }

		    fatherstrands[ii]=NULL;
		    motherstrands[ii]=NULL;

		    continue;
		}
		else if(r<0.2 && fatherstrands[i]->get_bitlength()>1024 && 
			num_cromo2<16 && len>=fatherstrands[i]->get_bitlength()/5) 
		    // extra cromosome
		{
		    cromosome_strand *cp=NULL, *cp2;
		    len = (unsigned int) (drand48() * (double) 
					       (fatherstrands[i]->get_bitlength() 
						- 1024)) + 1024;

		    if(drand48()<0.5) // make from random noise ?
		    {
			cp=new cromosome_strand(this, 1, 
						int(drand48()*10000.0)+1000);
		    }
		    else // make from the currentlu examined cromosome
		    {
			if(drand48()<0.5)
			    cp=fatherstrands[i]->copy(j, len);
			else
			    cp=fatherstrands[i]->cut(j, len);
		    }

		    if(cp)
		    {
			if(drand48()<parent1->flip_ratio)
			    cp->flip(0, -1);
		      
			num_cromo2++;
			cp->set_cromosome_number(num_cromo2-1);
		      
			cp2=new cromosome_strand(this, num_cromo2-1, cp);
		      
			fatherstrands[num_cromo2-1]=cp;
			motherstrands[num_cromo2-1]=cp2;
		    }
		}
		else if(r<0.25) // cut
		{
		    cromosome_strand *cp=fatherstrands[i]->cut(j, len);
		  
		    if(cp)
			delete cp;
		}
		else if(r<0.5) // cut & paste
		{
		    cromosome_strand *cp=fatherstrands[i]->cut(j, len);
		    unsigned int crom2=(int)(drand48()*((double) num_cromo2));
		    unsigned int pos2 = (unsigned int)
			(drand48() * (double) 
			 (fatherstrands[crom2]->get_bitlength()));
		  
		    if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*200.0-100.0));
		    }
		    else if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*1000.0-500.0));
		    }
		    else if(drand48()<0.5)
			crom2=i;

		    pos2=MINIM(MAXIM(pos2, 0), 
			       fatherstrands[crom2]->get_bitlength()-
			       sizeof(unsigned int)*8);

		    if(cp)
		    {
			if(drand48()<parent1->flip_ratio)
			    cp->flip(0, -1);
		      
			if((fatherstrands[crom2]->get_bitlength() +
			    cp->get_bitlength()) < MAXCROMLEN)
			    fatherstrands[crom2]->paste(cp, pos2);
		      
			delete cp;
		    }
		}
		else if(r<0.75)// copy & paste
		{
		    cromosome_strand *cp=fatherstrands[i]->copy(j, len);
		    unsigned int crom2=(int)(drand48()*((double) num_cromo2));
		    unsigned int pos2 = (unsigned int)
			(drand48() * (double) 
			 (fatherstrands[crom2]->get_bitlength()));
		  
		    if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*200.0-100.0));
		    }
		    else if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*1000.0-500.0));
		    }
		    else if(drand48()<0.5)
			crom2=i;

		    pos2=MINIM(MAXIM(pos2, 0), 
			       fatherstrands[crom2]->get_bitlength()-
			       sizeof(unsigned int)*8);

		    if(cp)
		    {
			if(drand48()<parent1->flip_ratio)
			    cp->flip(0, -1);
		      
		      
			if((fatherstrands[crom2]->get_bitlength() +
			    cp->get_bitlength()) < MAXCROMLEN)
			    fatherstrands[crom2]->paste(cp, pos2);
		      
			delete cp;
		    }
		}
		else if(drand48()<parent1->flip_ratio)
		    fatherstrands[i]->flip(j, len);
	    }
	}
      
      
	// parent 2;
	for(j=0; i<(int)MINIM(num_cromo, num_cromo2) &&
		j<(int)(motherstrands[i]->get_bitlength()-sizeof(int)*8) &&
		motherstrands[i]->get_bitlength()>sizeof(int)*8; j++)
	{
	    if(drand48() < linemut2)
	    {
		double r=drand48();
		double len2 = exp(drand48() * log(linelen));
	      
		if(drand48()<0.1)
		    len2 *= 10.0;
		else if(drand48()<0.01)
		    len2 *= 100.0;
		else if(drand48()<0.001)
		    len2 *= 1000.0;
		else if(drand48()<0.0001)
		    len2 *= 10000.0;

		unsigned int len = MINIM((unsigned int ) len2,
					      fatherstrands[i]->get_bitlength());
		len=MAXIM(len, 1);

		if(r<0.1 && motherstrands[i]->get_bitlength()>1024 && 
		   num_cromo2>3 && len>=motherstrands[i]->get_bitlength()/5) 
		    // remove a cromosome
		{
		    int ii;

		    // prepend or append this cromosome to another?
		    if(drand48()<0.5) 
		    {
			do
			    ii=int(drand48()*num_cromo2);
			while(ii==i);
		      
			if(drand48()<0.5)
			{
			    fatherstrands[ii]->paste(fatherstrands[i], 0);
			    motherstrands[ii]->paste(motherstrands[i], 0);
			}
			else
			{
			    fatherstrands[ii]->paste(fatherstrands[i], 
						     fatherstrands[ii]->
						     get_bitlength());
			    motherstrands[ii]->paste(motherstrands[i],  
						     motherstrands[ii]->
						     get_bitlength());
			}
		    }

		    delete fatherstrands[i];
		    delete motherstrands[i];

		    num_cromo2--;

		    for(ii=i; ii<(int)num_cromo2;ii++)
		    {
			fatherstrands[ii]=fatherstrands[ii+1];
			motherstrands[ii]=motherstrands[ii+1];
		    }

		    fatherstrands[ii]=NULL;
		    motherstrands[ii]=NULL;

		    continue;
		}
		else if(r<0.2 && motherstrands[i]->get_bitlength()>1024 && 
			num_cromo2<16 && len>=motherstrands[i]->get_bitlength()/5) 
		    // extra cromosome
		{
		    cromosome_strand *cp=NULL, *cp2;
		    len = (unsigned int) (drand48() * (double) 
					       (motherstrands[i]->get_bitlength() 
						- 1024)) + 1024;
		  
		    if(drand48()<0.5) // make from random noise ?
		    {
			cp=new cromosome_strand(this, 1, 
						int(drand48()*10000.0)+1000);
		    }
		    else // make from the currentlu examined cromosome
		    {
			if(drand48()<0.5)
			    cp=motherstrands[i]->copy(j, len);
			else
			    cp=motherstrands[i]->cut(j, len);
		    }

		    if(cp)
		    {
			if(drand48()<parent2->flip_ratio)
			    cp->flip(0, -1);
		      
			num_cromo2++;
			cp->set_cromosome_number(num_cromo2-1);
		      
			cp2=new cromosome_strand(this, num_cromo2-1, cp);
		      
			fatherstrands[num_cromo2-1]=cp;
			motherstrands[num_cromo2-1]=cp2;
		    }
		}
		else if(r<0.25) // cut
		{
		    cromosome_strand *cp=motherstrands[i]->cut(j, len);
		  
		    if(cp)
			delete cp;
		}
		else if(r<0.5) // cut & paste
		{
		    cromosome_strand *cp=motherstrands[i]->cut(j, len);
		    unsigned int crom2=(int)(drand48()*((double) num_cromo2));
		    unsigned int pos2 = (unsigned int)
			(drand48() * (double) 
			 (motherstrands[crom2]->get_bitlength()));
		  
		    if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*200.0-100.0));
		    }
		    else if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*1000.0-500.0));
		    }
		    else if(drand48()<0.5)
			crom2=i;

		    pos2=MINIM(MAXIM(pos2, 0), 
			       motherstrands[crom2]->get_bitlength()-
			       sizeof(unsigned int)*8);

		    if(cp)
		    {
			if(drand48()<parent2->flip_ratio)
			    cp->flip(0, -1);
		      
			if((motherstrands[crom2]->get_bitlength() +
			    cp->get_bitlength()) < MAXCROMLEN)
			    motherstrands[crom2]->paste(cp, pos2);
		      
			delete cp;
		    }
		}
		else if(r<0.75)// copy & paste
		{
		    cromosome_strand *cp=motherstrands[i]->copy(j, len);
		    unsigned int crom2=(int)(drand48()*((double) num_cromo2));
		    unsigned int pos2 = (unsigned int)
			(drand48() * (double) 
			 (motherstrands[crom2]->get_bitlength()));
		  
		    if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*200.0-100.0));
		    }
		    else if(drand48()<0.5)
		    {
			crom2=i;
			pos2=j+((unsigned int) (drand48()*1000.0-500.0));
		    }
		    else if(drand48()<0.5)
			crom2=i;

		    pos2=MINIM(MAXIM(pos2, 0), 
			       motherstrands[crom2]->get_bitlength()-
			       sizeof(unsigned int)*8);

		    if(cp)
		    {
			if(drand48()<parent2->flip_ratio)
			    cp->flip(0, -1);
		      
			if((motherstrands[crom2]->get_bitlength() + 
			    cp->get_bitlength()) < MAXCROMLEN)
			    motherstrands[crom2]->paste(cp, pos2);
		      
			delete cp;
		    }
		}
		else if(drand48()<parent2->flip_ratio)
		    motherstrands[i]->flip(j, len);
	    }
	}
    }

    if(num_cromo2>16)
	num_cromo=16;
    else
	num_cromo=num_cromo2;
}


// read meta data;
void replicatorset::read_cromosome1(replicatorset *parent1, 
				    replicatorset *parent2, bool dorepair)
{
    unsigned int pos=100;
    double repairbuffer;

    //
    // Read some basic variables from the cromosome;
    // 

    first_repair = MINIM(fatherstrands[0]->get_double(68, 12, 0.0, 1.0),
			 motherstrands[0]->get_double(68, 12, 0.0, 1.0));
    repairbuffer=first_repair;
    if(!dorepair)
	first_repair = -10.0;

    variablemutaterate = MINIM(fatherstrands[0]->get_double(pos, 24, 0.1, 1.0),
			       motherstrands[0]->get_double(pos, 24, 0.1, 1.0));
    variablemutaterate *= variablemutaterate;
    variablemutaterate *= variablemutaterate;
    pos+=24;
    variablemutatesize = MINIM(fatherstrands[0]->get_double(pos,24,0.01,0.1),
			       motherstrands[0]->get_double(pos,24,0.01,0.1));
    variablemutatesize *= variablemutatesize;
    pos+=24;
    // read gender;
    //int genderindex = (motherstrands[0]->get_bit(pos) ? 2 : 0);
    //genderindex += (fatherstrands[0]->get_bit(pos) ? 1 : 0);
    //gender = (GENDER) genderindex;  
    //gender = (GENDER) MAXIM(fatherstrands[0]->get_unsigned_int(pos, 2),
    //		  motherstrands[0]->get_unsigned_int(pos, 2));
  
    GENDER gender1 = (GENDER) fatherstrands[0]->get_unsigned_int(pos, 2);
    GENDER gender2 = (GENDER) motherstrands[0]->get_unsigned_int(pos, 2);

    if(gender1 == CLONE || gender2 == CLONE)
	gender = CLONE;
    else if(gender1 == HEMAPHRODITE)
    {
	if(gender2 == HEMAPHRODITE)
	    gender = HEMAPHRODITE;
	else if(gender2 == MALE)
	    gender = (drand48()>0.5) ? MALE : HEMAPHRODITE;
	else if(gender2 == FEMALE)
	    gender = (drand48()>0.5) ? FEMALE : HEMAPHRODITE;
    }
    else if(gender2 == HEMAPHRODITE)
    {
	if(gender1 == MALE)
	    gender = (drand48()>0.5) ? MALE : HEMAPHRODITE;
	else if(gender1 == FEMALE)
	    gender = (drand48()>0.5) ? FEMALE : HEMAPHRODITE;
    }
    else
	gender = (drand48()>0.5) ? MALE : FEMALE;

    pos +=2;
    // debug;
    // gender=HEMAPHRODITE;

    pos=68;
    first_repair = find_double_and_repair(pos, 12, 0.0, 1.0, MIN);
    if(!dorepair)
	first_repair = -10.0;


    if(parent1)
    {
	//
	// read global variables;
	//
      
	// find variables from parent 1;
	global_n1 = splice_int_and_mutate(parent1->global_n1, parent1->global_n2,
					  0,10000);
	pointmutationrate1 = splice_dbl_and_mutate(parent1->pointmutationrate1, 
						   parent1->pointmutationrate2,
						   0, 0.01);
	pointmutationrate_11 = splice_dbl_and_mutate(parent1->pointmutationrate_11, 
						     parent1->pointmutationrate_12,
						     0, 0.01);
	pointmutationrate_21 = splice_dbl_and_mutate(parent1->pointmutationrate_21, 
						     parent1->pointmutationrate_22,
						     0, 0.01);
	linemutation1 = splice_dbl_and_mutate(parent1->linemutation1, 
					      parent1->linemutation2, 0, 0.0005);
	linemutation_11 = splice_dbl_and_mutate(parent1->linemutation_11, 
						parent1->linemutation_12, 
						0, 0.0005);
	linemutation_21 = splice_dbl_and_mutate(parent1->linemutation_21, 
						parent1->linemutation_22, 
						0, 0.0005);
	flip_ratio1 = splice_dbl_and_mutate(parent1->flip_ratio1, 
					    parent1->flip_ratio2, 0, 1.0);
	negate_ratio1 = splice_dbl_and_mutate(parent1->negate_ratio1, 
					      parent1->negate_ratio2, 0, 1.0);
	linelen1 = splice_dbl_and_mutate(parent1->linelen1, parent1->linelen2, 
					 0, 10000);
	maxgen1 = splice_int_and_mutate(parent1->maxgen1, parent1->maxgen2, 1,5);
	repair_ratio1 = splice_dbl_and_mutate(parent1->repair_ratio1,
					      parent1->repair_ratio2, 0.0, 1.0);
      
	tr1 = splice_dbl_and_mutate(parent1->tr1, parent1->tr2, -30.0, 30.0);
	tm1 = splice_dbl_and_mutate(parent1->tm1, parent1->tm2, -30.0, 30.0);
	ta1 = splice_dbl_and_mutate(parent1->ta1, parent1->ta2, -30.0, 30.0);
	tf01 = splice_dbl_and_mutate(parent1->tf01, parent1->tf02, -3.0, 3.0);
	tg1 = splice_dbl_and_mutate(parent1->tg1, parent1->tg2, -30.0, 5.0);
	td1 = splice_dbl_and_mutate(parent1->td1, parent1->td2, -30.0, 5.0);
      
	r1 = splice_dbl_and_mutate(parent1->r1, parent1->r2, -30, 30);
	m1 = splice_dbl_and_mutate(parent1->m1, parent1->m2, -30, 30);
	x01 = splice_dbl_and_mutate(parent1->x01, parent1->x02, -30, 30);
	l1 = splice_dbl_and_mutate(parent1->l1, parent1->l2, -30, 30);
	gamma1 = splice_dbl_and_mutate(parent1->gamma1, parent1->gamma2,-30,30);
	d1 = splice_dbl_and_mutate(parent1->d1, parent1->d2, -30, 10);
	g1 = splice_dbl_and_mutate(parent1->g1, parent1->g2, -30, 10);
	reload1 = splice_dbl_and_mutate(parent1->reload1, parent1->reload2, 
					0.01, 10);
	fatigue_level1=splice_dbl_and_mutate(parent1->fatigue_level1, 
					     parent1->fatigue_level2, 0.01, 1);
	fatigue_decrease1=splice_dbl_and_mutate(parent1->fatigue_decrease1, 
						parent1->fatigue_decrease2, 
						0.01, 3);

	gor1 = splice_dbl_and_mutate(parent1->gor1, parent1->gor2, -30, 30);
	om1 = splice_dbl_and_mutate(parent1->om1, parent1->om2, -30, 30);
	ox01 = splice_dbl_and_mutate(parent1->ox01, parent1->ox02, -30, 30);
	ol1 = splice_dbl_and_mutate(parent1->ol1, parent1->ol2, -30, 30);
	ogamma1 = splice_dbl_and_mutate(parent1->ogamma1, parent1->ogamma2, 
					-30, 30);
	od1 = splice_dbl_and_mutate(parent1->od1, parent1->od2, -30, 10);
	og1 = splice_dbl_and_mutate(parent1->og1, parent1->og2, -30, 10);
	oreload1 = splice_dbl_and_mutate(parent1->oreload1, parent1->oreload2, 
					 0.01, 10);
	ofatigue_level1=splice_dbl_and_mutate(parent1->ofatigue_level1, 
					      parent1->ofatigue_level2, 0.01, 1);
	ofatigue_decrease1=splice_dbl_and_mutate(parent1->ofatigue_decrease1, 
						 parent1->ofatigue_decrease2, 
						 0.01, 3);
      
	outL1 = splice_dbl_and_mutate(parent1->outL1, parent1->outL2,-30.0,30.0);
	outX01 = splice_dbl_and_mutate(parent1->outX01, 
				       parent1->outX02, -30.0,30.0);
      
	// find variables from parent 2, if possible;
	if(parent2)
	{
	    global_n2 = splice_int_and_mutate(parent2->global_n1, 
					      parent2->global_n2, 0,10000);
	    pointmutationrate2=splice_dbl_and_mutate(parent2->pointmutationrate1,
						     parent2->pointmutationrate2,
						     0, 0.01);
	    pointmutationrate_12=splice_dbl_and_mutate(parent2->pointmutationrate_11,
						       parent2->pointmutationrate_12,
						       0, 0.01);
	    pointmutationrate_22=splice_dbl_and_mutate(parent2->pointmutationrate_21,
						       parent2->pointmutationrate_22,
						       0, 0.01);
	    linemutation2 = splice_dbl_and_mutate(parent2->linemutation1, 
						  parent2->linemutation2, 
						  0, 0.0005);
	    linemutation_12 = splice_dbl_and_mutate(parent2->linemutation_11, 
						    parent2->linemutation_12, 
						    0, 0.0005);
	    linemutation_22 = splice_dbl_and_mutate(parent2->linemutation_21, 
						    parent2->linemutation_22, 
						    0, 0.0005);
	    flip_ratio2 = splice_dbl_and_mutate(parent2->flip_ratio1, 
						parent2->flip_ratio2, 0, 1.0);
	    negate_ratio2 = splice_dbl_and_mutate(parent2->negate_ratio1, 
						  parent2->negate_ratio2, 
						  0, 1.0);
	    linelen2 = splice_dbl_and_mutate(parent2->linelen1, 
					     parent2->linelen2, 0, 10000);
	    maxgen2 = splice_int_and_mutate(parent2->maxgen1, parent2->maxgen2,
					    1,5);
	    repair_ratio2 = splice_dbl_and_mutate(parent2->repair_ratio1,
						  parent2->repair_ratio2, 
						  0.0, 1.0);
	  
	    tr2 = splice_dbl_and_mutate(parent2->tr1, parent2->tr2, -30.0, 30.0);
	    tm2 = splice_dbl_and_mutate(parent2->tm1, parent2->tm2, -30.0, 30.0);
	    ta2 = splice_dbl_and_mutate(parent2->ta1, parent2->ta2, -30.0, 30.0);
	    tf02 = splice_dbl_and_mutate(parent2->tf01, parent2->tf02,-3.0,3.0);
	    tg2 = splice_dbl_and_mutate(parent2->tg1, parent2->tg2, -30.0, 5.0);
	    td2 = splice_dbl_and_mutate(parent2->td1, parent2->td2, -30.0, 5.0);
	  
	    r2 = splice_dbl_and_mutate(parent2->r1, parent2->r2, -30, 30);
	    m2 = splice_dbl_and_mutate(parent2->m1, parent2->m2, -30, 30);
	    x02 = splice_dbl_and_mutate(parent2->x01, parent2->x02, -30, 30);
	    l2 = splice_dbl_and_mutate(parent2->l1, parent2->l2, -30, 30);
	    gamma2 = splice_dbl_and_mutate(parent2->gamma1, 
					   parent2->gamma2,-30,30);
	    d2 = splice_dbl_and_mutate(parent2->d1, parent2->d2, -30, 10);
	    g2 = splice_dbl_and_mutate(parent2->g1, parent2->g2, -30, 10);
	    reload2 = splice_dbl_and_mutate(parent2->reload1, parent2->reload2, 
					    0.01, 10);
	    fatigue_level2=splice_dbl_and_mutate(parent2->fatigue_level1, 
						 parent2->fatigue_level2, 
						 0.01, 1);
	    fatigue_decrease2=splice_dbl_and_mutate(parent2->fatigue_decrease1, 
						    parent2->fatigue_decrease2, 
						    0.01, 3);
      
	    gor2 = splice_dbl_and_mutate(parent2->gor1, parent2->gor2, -30, 30);
	    om2 = splice_dbl_and_mutate(parent2->om1, parent2->om2, -30, 30);
	    ox02 = splice_dbl_and_mutate(parent2->ox01, parent2->ox02, -30, 30);
	    ol2 = splice_dbl_and_mutate(parent2->ol1, parent2->ol2, -30, 30);
	    ogamma2 = splice_dbl_and_mutate(parent2->ogamma1, parent2->ogamma2, 
					    -30, 30);
	    od2 = splice_dbl_and_mutate(parent2->od1, parent2->od2, -30, 10);
	    og2 = splice_dbl_and_mutate(parent2->og1, parent2->og2, -30, 10);
	    oreload2 = splice_dbl_and_mutate(parent2->oreload1, 
					     parent2->oreload2, 
					     0.01, 10);
	    ofatigue_level2=splice_dbl_and_mutate(parent2->ofatigue_level1, 
						  parent2->ofatigue_level2, 
						  0.01, 1);
	    ofatigue_decrease2=splice_dbl_and_mutate(
		parent2->ofatigue_decrease1, 
		parent2->ofatigue_decrease2, 
		0.01, 3);
	  
	    outL2 = splice_dbl_and_mutate(parent2->outL1, parent2->outL2, 
					  -30.0,  30.0);
	    outX02 = splice_dbl_and_mutate(parent2->outX01, parent2->outX02, 
					   -30.0, 30.0);
	}
	else
	{
	    global_n2 = splice_int_and_mutate(global_n1, 
					      global_n1, 0,10000);
	    pointmutationrate2=splice_dbl_and_mutate(pointmutationrate1,
						     pointmutationrate1,
						     0, 0.01);
	    pointmutationrate_12=splice_dbl_and_mutate(pointmutationrate_11,
						       pointmutationrate_11,
						       0, 0.01);
	    pointmutationrate_22=splice_dbl_and_mutate(pointmutationrate_21,
						       pointmutationrate_21,
						       0, 0.01);
	    linemutation2 = splice_dbl_and_mutate(linemutation1, 
						  linemutation1, 0, 0.0005);
	    flip_ratio2 = splice_dbl_and_mutate(flip_ratio1, 
						flip_ratio1, 0, 1.0);
	    negate_ratio2 = splice_dbl_and_mutate(negate_ratio1, 
						  negate_ratio1, 0, 1.0);
	    linelen2 = splice_dbl_and_mutate(linelen1, 
					     linelen1, 0, 10000);
	    maxgen2 = splice_int_and_mutate(maxgen1, maxgen1,
					    1,5);
	    repair_ratio2 = splice_dbl_and_mutate(repair_ratio1,
						  repair_ratio1, 
						  0.0, 1.0);
	  
	    tr2 = splice_dbl_and_mutate(tr1, tr1, -30.0, 30.0);
	    tm2 = splice_dbl_and_mutate(tm1, tm1, -30.0, 30.0);
	    ta2 = splice_dbl_and_mutate(ta1, ta1, -30.0, 30.0);
	    tf02 = splice_dbl_and_mutate(tf01, tf01, -3.0,3.0);
	    tg2 = splice_dbl_and_mutate(tg1, tg1, -30.0, 5.0);
	    td2 = splice_dbl_and_mutate(td1, td1, -30.0, 5.0);
	  
	    r2 = splice_dbl_and_mutate(r1, r1, -30, 30);
	    m2 = splice_dbl_and_mutate(m1, m1, -30, 30);
	    x02 = splice_dbl_and_mutate(x01, x01, -30, 30);
	    l2 = splice_dbl_and_mutate(l1, l1, -30, 30);
	    gamma2 = splice_dbl_and_mutate(gamma1, 
					   gamma1,-30,30);
	    d2 = splice_dbl_and_mutate(d1, d1, -30, 10);
	    g2 = splice_dbl_and_mutate(g1, g1, -30, 10);
	    reload2 = splice_dbl_and_mutate(reload1, reload1, 
					    0.01, 10);
	    fatigue_level2=splice_dbl_and_mutate(fatigue_level1, fatigue_level1, 
						 0.01, 1);
	    fatigue_decrease2=splice_dbl_and_mutate(fatigue_decrease1, 
						    fatigue_decrease1, 
						    0.01, 3);
	  
	    gor2 = splice_dbl_and_mutate(gor1, gor1, -30, 30);
	    om2 = splice_dbl_and_mutate(om1, om1, -30, 30);
	    ox02 = splice_dbl_and_mutate(ox01, ox01, -30, 30);
	    ol2 = splice_dbl_and_mutate(ol1, ol1, -30, 30);
	    ogamma2 = splice_dbl_and_mutate(ogamma1, ogamma1, 
					    -30, 30);
	    od2 = splice_dbl_and_mutate(od1, od1, -30, 10);
	    og2 = splice_dbl_and_mutate(og1, og1, -30, 10);
	    oreload2 = splice_dbl_and_mutate(oreload1, oreload1, 
					     0.01, 10);
	    ofatigue_level2=splice_dbl_and_mutate(ofatigue_level1, 
						  ofatigue_level1, 
						  0.01, 1);
	    ofatigue_decrease2=splice_dbl_and_mutate(ofatigue_decrease1,
						     ofatigue_decrease1, 
						     0.01, 3);
	  
	    outL2 = splice_dbl_and_mutate(outL1, outL1, 
					  -30.0,  30.0);
	    outX02 = splice_dbl_and_mutate(outX01, outX01, 
					   -30.0, 30.0);
	}
      
	// find dominant variables;
      
	// max number of generations;
	global_n = find_dominant_int(global_n1, global_n2);
	pointmutationrate = find_dominant_dbl(pointmutationrate1,
					      pointmutationrate2);
	pointmutationrate_1 = find_dominant_dbl(pointmutationrate_11,
						pointmutationrate_12);
	pointmutationrate_2 = find_dominant_dbl(pointmutationrate_21,
						pointmutationrate_22);
	linemutation = find_dominant_dbl(linemutation1, linemutation2);
	linemutation_1 = find_dominant_dbl(linemutation_11, linemutation_12);
	linemutation_2 = find_dominant_dbl(linemutation_21, linemutation_22);
	flip_ratio = find_dominant_dbl(flip_ratio1, flip_ratio2);
	negate_ratio = find_dominant_dbl(negate_ratio1, negate_ratio2);
	linelen = find_dominant_dbl(linelen1, linelen2);
	maxgen = find_dominant_int(maxgen1, maxgen2);
	repair_ratio = find_dominant_dbl(repair_ratio1, repair_ratio2);
      
	// read standard thread values;
	tr = find_dominant_dbl(tr1, tr2);
	tm = find_dominant_dbl(tm1, tm2);
	ta = find_dominant_dbl(ta1, ta2);
	tf0 = find_dominant_dbl(tf01, tf02);
	tg = find_dominant_dbl(tg1, tg2);
	td = find_dominant_dbl(td1, td2);

	// read standard internal node
	r = find_dominant_dbl(r1, r2);
	m = find_dominant_dbl(m1, m2);
	x0 = find_dominant_dbl(x01, x02);
	l = find_dominant_dbl(l1, l2);
	gamma = find_dominant_dbl(gamma1, gamma2);
	d = find_dominant_dbl(d1, d2);
	g = find_dominant_dbl(g1, g2);
	reload = find_dominant_dbl(reload1, reload2);
	fatigue_level = find_dominant_dbl(fatigue_level1, fatigue_level2);
	fatigue_decrease=find_dominant_dbl(fatigue_decrease1,fatigue_decrease2);
      
	// read output node values
	gor = find_dominant_dbl(gor1, gor2);
	om = find_dominant_dbl(om1, om2);
	ox0 = find_dominant_dbl(ox01, ox02);
	ol = find_dominant_dbl(ol1, ol2);
	ogamma = find_dominant_dbl(ogamma1, ogamma2);
	od = find_dominant_dbl(od1, od2);
	og = find_dominant_dbl(og1, og2);
	oreload = find_dominant_dbl(oreload1, oreload2);
	ofatigue_level = find_dominant_dbl(ofatigue_level1, ofatigue_level2);
	ofatigue_decrease=find_dominant_dbl(ofatigue_decrease1,
					    ofatigue_decrease2);
      
	// Read additional output node values (for nodes that
	// should return real values rather than bool values);
	outL = find_dominant_dbl(outL1, outL2);
	outX0 = find_dominant_dbl(outX01, outX02);
    }
  
    standard_thread = new thread(tr, tm ,ta, tf0, tg, td);
    standard_internal = new node(r, m, x0, l, gamma, d, g, reload, 
				 fatigue_level, fatigue_decrease);
    standard_out = new node(gor, om, ox0, ol, ogamma, od, og, oreload,
			    ofatigue_level, ofatigue_decrease);
}

double replicatorset::find_double_and_repair(unsigned int &pos, 
					     unsigned int len,
					     double start, double end,
					     METHOD met)
{
    double fathervalue=fatherstrands[0]->get_double(pos, len, start, end);
    double mothervalue=motherstrands[0]->get_double(pos, len, start, end);
    double retvalue=mothervalue;
    unsigned int i;

    if(fathervalue!=mothervalue)
    {
      
	// use motherstand ?
	if((met==MAX && mothervalue>=fathervalue) ||
	   (met==MIN && mothervalue<=fathervalue))
	{
	    retvalue=mothervalue;
	  
	    // if we're to repair the father strand;
	    if(drand48() < first_repair) // repair ? 
	    {
		// copy contents from the mother cromosome to the father
		for(i=0;i<len && (i+pos)<fatherstrands[0]->get_bitlength() &&
			(i+pos)<motherstrands[0]->get_bitlength();i++)
		    fatherstrands[0]->set_bit(i+pos, 
					      motherstrands[0]->get_bit(i+pos));
	    }
	}
	else
	{
	    retvalue=mothervalue;
	  
	    // if we're to repair the mother strand;
	    if(drand48() < first_repair) // repair ? 
	    {
		// copy contents from the mother cromosome to the father
		for(i=0;i<len && (i+pos)<fatherstrands[0]->get_bitlength() &&
			(i+pos)<motherstrands[0]->get_bitlength();i++)
		    motherstrands[0]->set_bit(i+pos, 
					      fatherstrands[0]->get_bit(i+pos));
	    }
	}
    }

    pos += len;
    return retvalue;
}

unsigned int replicatorset::find_int_and_repair(unsigned int &pos, 
						unsigned int len,
						METHOD met,
						unsigned int max)
{
    unsigned int  fathervalue=fatherstrands[0]->get_unsigned_int(pos, len);
    unsigned int  mothervalue=motherstrands[0]->get_unsigned_int(pos, len);
    unsigned int  retvalue=mothervalue;
    unsigned int i;

    if(max>0)
    {
	fathervalue = fathervalue % max;
	mothervalue = mothervalue % max;
	retvalue=mothervalue;
    }

    if(fathervalue!=mothervalue)
    {
	// use motherstand ?
	if((met==MAX && mothervalue>=fathervalue) ||
	   (met==MIN && mothervalue<=fathervalue))
	{
	    retvalue=mothervalue;
	  
	    // if we're to repair the father strand;
	    if(drand48() < first_repair) // repair ? 
	    {
		// copy contents from the mother cromosome to the father
		for(i=0;i<len && (i+pos)<fatherstrands[0]->get_bitlength() &&
			(i+pos)<motherstrands[0]->get_bitlength();i++)
		    fatherstrands[0]->set_bit(i+pos, 
					      motherstrands[0]->get_bit(i+pos));
	    }
	}
	else
	{
	    retvalue=mothervalue;
	  
	    // if we're to repair the mother strand;
	    if(drand48() < first_repair) // repair ? 
	    {
		// copy contents from the mother cromosome to the father
		for(i=0;i<len && (i+pos)<fatherstrands[0]->get_bitlength() &&
			(i+pos)<motherstrands[0]->get_bitlength();i++)
		    motherstrands[0]->set_bit(i+pos, 
					      fatherstrands[0]->get_bit(i+pos));
	    }
	}
    }
      
    pos += len;
    return retvalue;
}


void replicatorset::read_cromosome2(bool dorepair)
{
    unsigned int i,pos=0;

    // find the instructions;
    for(i=0; i<NUM_INSTRUCTIONS; i++)
    {
	instruct[i] = new instruction(this, 1, pos, (INSTRCUTION_TYPE) i);
	pos += 64;
    }  

    for(i=0;i<num_cromo; i++)
	fatherstrands[i]->find_commands(instruct, NUM_INSTRUCTIONS,
					motherstrands[i], 
					dorepair ? repair_ratio : 0.0);
}

void replicatorset::read_instructions(void)
{
    register unsigned int i;
    register int j;
    node **inputnodes=new node*[numin];
    node **outputnodes=new node*[numout];
    node *startnode;

    // make the input nodes;
    for(i=0;i<numin;i++)
	inputnodes[i] = new node(0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 
				 10.0, 0.01, 1.0);

    // make the output nodes;
    for(i=0;i<numout;i++)
	outputnodes[i] = new node(standard_out);

    // make the starting node and connetct it to all the
    // input and output nodes;
    startnode=new node(standard_internal);
    for(i=0;i<numin;i++)
	startnode->thread_in_to_node(standard_thread, inputnodes[i]); 
    for(i=0;i<numout;i++)
	startnode->thread_out_of_node(standard_thread, outputnodes[i]); 

    // make the first nodeset;
    nhead=new nodeset(NULL, startnode, standard_thread,
		      global_n, this);
    ntail=nhead;
    // activate the first 'global_n' bits in cromosome number three;    

    //nhead->activate(2, 0, global_n);
    activated *startactivation1=force_find_pattern(3, 0, 12, true, true,
						   false);
    activated *startactivation2=force_find_pattern(3, 0, 12, false, true,
						   false);

    nhead->activate(startactivation1, global_n);
    nhead->activate(startactivation2, global_n);

    // traverse the generations
    for(i=0; i<maxgen; i++)
    {
	// make and array of all the current members of the nodeset;
	int len = nhead->number_of_elements();
	nodeset **narray= new nodeset*[len], *ptr;

	j=0;
	for(ptr=nhead; ptr; ptr = (nodeset *) ptr->getnext())
	    narray[j++]=ptr;

	// traverse the current members of the nodeset;
	for(j=len-1; j>=0; j--)
	{
	    if(!narray[j]->is_stopped()) // if this node isn't done...
		operate(narray[j], i); // read instructions beloning to this node
	}

	delete [] narray;
    }

    // make and array of the internal nodes;
    unsigned int numinternal=nhead->number_of_elements();
    node **internal=new node*[numinternal];
    nodeset *ptr;

    i=0;
    for(ptr=nhead; ptr; ptr = (nodeset *) ptr->getnext())
	internal[i++] = ptr->get_node();

    // normalize the internal nodes;
    for(i=0;i<numinternal;i++)
	normalize(internal[i]);

    // normalize the output nodes;
    for(i=0;i<numout;i++)
	normalize(outputnodes[i]);

    // make the neural net;
    nn=new neuralnet(inputnodes, numin,
		     outputnodes, numout, 
		     internal, numinternal);

    // cleanup;
    if(internal)
	delete [] internal;
    if(inputnodes)
	delete [] inputnodes;
    if(outputnodes)
	delete [] outputnodes;

  
    if(startactivation1)
	delete startactivation1;
  
    if(startactivation2)
	delete startactivation2;
  


    if(nhead)
	delete nhead;
    nhead=NULL;

    if(numnodes>0)
    {
	for(int type=(int) ACTIVATE; type<NUM_INSTRUCTIONS; type++)
	    num_instruction[type]/=double(numnodes);
	total_instructions/=double(numnodes);
    }
    else
    {
	for(int type=(int) ACTIVATE; type<NUM_INSTRUCTIONS; type++)
	    num_instruction[type]=0;
	total_instructions=0;
    }
}

void replicatorset::operate(nodeset *nset, unsigned int gen)
{
    command ***combuff=new command**[2*num_cromo], **commands;
    register unsigned int i,j,k;
    unsigned int *lengths=new unsigned int[2*num_cromo], totlen;
    int nodenum=1;

    for(i=0; i<num_cromo; i++)
    {
	combuff[i*2] = fatherstrands[i]->get_activated_commands(*nset,
								lengths+2*i);
	combuff[i*2+1] = motherstrands[i]->get_activated_commands(*nset,
								  lengths+2*i+1);

	//cout << "f" << i << " : " << lengths[2*i] << endl;
	//cout << "m" << i << " : " << lengths[2*i+1] << endl;
    }

    numnodes++;
    totlen=0;
    for(i=0;i<2*num_cromo;i++)
	totlen += lengths[i];

    commands = new command*[totlen];
    k=0;
    for(i=0; i<2*num_cromo; i++)
    {
	for(j=0;j<lengths[i];j++)
	    commands[k++]=combuff[i][j];
    }

    for(i=0;i<totlen;i++)
	interprete(nset, gen, commands[i]);

    if(!nset->is_stopped()) // do splitting
    {
	node *child1, *child2, *currnode=nset->get_node();
	thread *stthread = nset->get_standard_thread();
	nodeset *nchild1, *nchild2;

	currnode->split_node(&child1, &child2, stthread);
	delete currnode;

	ntail=new nodeset(ntail, nset, child1, this, nodenum++);
	nchild1=ntail;
	ntail=new nodeset(ntail, nset, child2, this, nodenum++);
	nchild2=ntail;

	if(nhead==nset)
	    nhead = (nodeset *) nhead->getnext();
	nset->removefromlist();
	delete nset;
      
	for(i=0;i<totlen;i++)
	    interprete_children(nchild1, nchild2, gen, commands[i]);
    }

    k=0;
    for(i=0; i<2*num_cromo; i++)
    {
	if(lengths[i] && combuff[i])
	    delete [] combuff[i];
    }
    delete [] combuff;
    delete [] commands;
    delete [] lengths;
}

void replicatorset::interprete(nodeset *nset, unsigned int gen, command *com)
{
    INSTRCUTION_TYPE type=com->get_type();

    num_instruction[type]++;
    total_instructions++;

    switch(type)
    {
	case ACTIVATE: 
	case DEACTIVATE: 
	case ACTIVATEL: 
	case DEACTIVATEL:
	    nset->interprete_activate(gen, com);
	    break;
	case CHN: 
	    nset->interprete_chn(com);
	    break;
	case CHNPROS: 
	    nset->interprete_chnpros(com);
	    break;
	case CHNODE: 
	    nset->interprete_chnode(com);
	    break;
	case CHSTTHREAD: 
	    nset->interprete_chstthread(com);
	    break;
	case CHALLTH: 
	    nset->interprete_challthreads(com);
	    break;
	case CHTHREAD: 
	    nset->interprete_chthread(com);
	    break;
	case STOP:
	    nset->set_stop();
	    break; 
	case REM:
	    nset->interprete_rem(com);
	    break;
	case REM1:
	case REM2:
	    nset->interprete_var_rem(gen, com);
	    break;
	case IF1:
	case IF3:
	    if(gen<2)
		nset->interprete_if(gen, com, 0);
	    break;
	case IF2:
	case IF4:
	    if(gen<2)
		nset->interprete_if_num(gen, com, 0);
	    break; 
	case INC1:
	case INC2: 
	case DEC1:
	case DEC2:
	case HALF1:
	case HALF2: 
	case DOUBLE1:
	case DOUBLE2: 
	case NEG1:
	case NEG2:      
	    nset->interprete_operation(com, 0);
	    break;
	case CHANGEVAR1:
	case CHANGEVAR2:
	case CHANGEVAR3:
	case CHANGEVAR4:
	case CHANGEVAR5:
	    nset->interprete_changevar(gen, com, 0);
	    break;
	default:
	    break;
    }
}

void replicatorset::interprete_children(nodeset *child1, nodeset *child2,
					unsigned int gen, command *com)
{
    INSTRCUTION_TYPE type=com->get_type();

    num_instruction[type]++;
    total_instructions++;

    if(type==ACTIVATE || type==DEACTIVATE || 
       type==ACTIVATEL || type==DEACTIVATEL) 
    {
	child1->interprete_activate(gen, com, 1);
	child2->interprete_activate(gen, com, 2);
    }
    else if(type==IF1 || type==IF3)
    {
	child1->interprete_if(gen, com, 1);
	child2->interprete_if(gen, com, 2);
    }
    else if(type==IF2 || type==IF4)
    {
	child1->interprete_if_num(gen, com, 1);
	child2->interprete_if_num(gen, com, 2);
    }
    else if(type>=INC1 && type<=NEG2)
    {
	child1->interprete_operation(com, 1);
	child2->interprete_operation(com, 2);
    }
    else if(type>=CHANGEVAR1 && type<=CHANGEVAR5)
    {
	child1->interprete_changevar(gen, com, 1);
	child2->interprete_changevar(gen, com, 2);
    }
    else
    {
	num_instruction[type]--;
	total_instructions--;
    }
}

activated *replicatorset::find_pattern(unsigned int cromnum,  
				       unsigned int pos, 
				       unsigned int len,  
				       bool from_mother,
				       bool do_negate, 
				       bool stop_when_found)
{
    unsigned int crom;
    activated *found=NULL, *tail=NULL;
    cromosome_strand *cp;

    if(cromnum>=num_cromo ||
       (from_mother && pos+len>motherstrands[cromnum]->get_bitlength()) ||
       (!from_mother && pos+len>fatherstrands[cromnum]->get_bitlength()))
	return NULL;

    if(from_mother)
	cp=motherstrands[cromnum]->copy(pos, len);
    else
	cp=fatherstrands[cromnum]->copy(pos, len);

    if(!cp)
	return NULL;

    if(do_negate)
	cp->negate();

    for(crom=2;crom<num_cromo;crom++)
    {
	unsigned int pos2=0;

	do
	{
	    pos2=fatherstrands[crom]->find_pattern(cp, pos2);
	    if(pos2<=fatherstrands[crom]->get_bitlength())
	    {
		tail=new activated(tail, crom, pos2, len);
		if(!found)
		    found=tail;
		pos2+=len;
		if(stop_when_found)
		    return found;
	    }
	} while(pos2<=fatherstrands[crom]->get_bitlength());

	do
	{
	    pos2=motherstrands[crom]->find_pattern(cp, pos2);
	    if(pos2<=motherstrands[crom]->get_bitlength())
	    {
		tail=new activated(tail, crom, pos2, len);
		if(!found)
		    found=tail;
		pos2+=len;
		if(stop_when_found)
		    return found;
	    }
	} while(pos2<=motherstrands[crom]->get_bitlength());
    }

    delete cp;

    return found;
}

activated *replicatorset::force_find_pattern(unsigned int cromnum,  
					     unsigned int pos, 
					     unsigned int startlen, 
					     bool from_mother,
					     bool do_negate, 
					     bool stop_when_found)
{
    unsigned int len=startlen;
    activated *found=NULL;

    found=find_pattern(cromnum, pos, len, from_mother, do_negate, 
		       stop_when_found);
    while(!found && startlen>0)
    {
	found=find_pattern(cromnum, pos, len, from_mother, do_negate, 
			   stop_when_found);
	len--;
    }

    return found;
}

void replicatorset::normalize(node *normnode)
{
    if(!normnode)
	return;
  
    double newgamma=r2p(normnode->get_gamma());
    normnode->change_gamma(newgamma);

    double newg=r2p(normnode->get_g());
    newg *= newg;
    //newg=pow(newg, 5.0);
    normnode->change_g(newg);

    double newm=r2p(normnode->get_m());
    //newm *= newm;
    //newm=pow(newm, 3.0);
    normnode->change_m(newm);

    double newd=r2p(normnode->get_d());
    newd *= newd;
    //newd=pow(newd, 5.0);
    normnode->change_d(newd);

    threadlist *ptr = normnode->get_in_threads();
    for(;ptr; ptr=(threadlist *) ptr->getnext())
    {
	thread *th=ptr->get_thread();
      
	newg=r2p(th->get_g());
	newg *= newg;
	//newg=pow(newg, 5.0);
	th->change_g(newg);

	newd=r2p(th->get_d());
	newd *= newd;
	//newd=pow(newd, 5.0);
	th->change_d(newd);

	newm=r2p(th->get_m());
	//newm *= newm;
	//newm=pow(newm, 3.0);
	th->change_m(newm);

	double newf0=r2p(th->get_f0());
	th->change_f0(newf0);

	double newa=r2p(th->get_a());
	newa *= newa;
	//newa = pow(newa, 2.0);
	th->change_a(newa);
    }
  
}

void replicatorset::init(void)
{
    register unsigned int i;

    for(i=0;i<16;i++)
    {
	fatherstrands[i]=NULL;
	motherstrands[i]=NULL;
    }

    num_cromo=0;

    nhead=ntail=NULL;
    global_n=1000;
    linelen=1.0;

    for(i=0;i<NUM_INSTRUCTIONS;i++)
    {
	instruct[i]=NULL;
	num_instruction[i]=0;
    }
    numnodes=0;
    total_instructions=0;

    nn=NULL;

    // initialize global variables;
    pointmutationrate=pointmutationrate1=pointmutationrate2=0.0001;
    pointmutationrate_1=pointmutationrate_11=pointmutationrate_12=0.0001;
    pointmutationrate_2=pointmutationrate_21=pointmutationrate_22=0.0001;
    linemutation=linemutation1=linemutation2=0.00001;
    linemutation_1=linemutation_11=linemutation_12=0.00001;
    linemutation_2=linemutation_21=linemutation_22=0.00001;
    repair_ratio=repair_ratio1=repair_ratio2=0.001;
    flip_ratio=flip_ratio1=flip_ratio2=0.5;
    negate_ratio=negate_ratio1=negate_ratio2=0.1;
    global_n=global_n1=global_n2=1000;
    maxgen=maxgen1=maxgen2=1;
    linelen=linelen1=linelen2=100;
    outL=outL1=outL2=1.0;
    outX0=outX01=outX02=0.0;

    // initialize standard thread variables;
    tr=tr1=tr2=1.0;
    tm=tm1=tm2=-25.0;
    ta=ta1=ta1=0.0;
    tf0=tf01=tf02=-2.5;
    tg=tg1=tg2=-25.0;
    td=td1=td2=-25.0;

    // initialize standard internal node variables;
    r=r1=r2=1.0;
    m=m1=m2=-25.0;
    x0=x01=x02=0.0;
    l=l1=l2=1.0;
    gamma=gamma1=gamma2=-30.0+60.0*drand48();
    d=d1=d2=-25.0;
    g=g1=g2=-25.0;
    reload1=reload2=reload=0.01+9.99*drand48();
    fatigue_level1=fatigue_level2=fatigue_level=0.01+0.99*drand48();
    fatigue_decrease1=fatigue_decrease2=fatigue_decrease=0.01+2.99*drand48();

    // initialize output node variables;
    gor=gor1=gor2=1.0;
    om=om1=om2=-25.0;
    ox0=ox01=ox02=0.0;
    ol=ol1=ol2=1.0;
    ogamma=ogamma1=ogamma2=-30.0+60.0*drand48();
    od=od1=od2=-25.0;
    og=og1=og2=-25.0;
    oreload1=oreload2=oreload=0.01+9.99*drand48();
    ofatigue_level1=ofatigue_level2=ofatigue_level=0.01+0.99*drand48();
    ofatigue_decrease1=ofatigue_decrease2=ofatigue_decrease=0.01+2.99*drand48();
}

void replicatorset::cleanup(void)
{
    register unsigned int i;

    for(i=0;i<16;i++)
    {
	if(fatherstrands[i])
	    delete fatherstrands[i];
	fatherstrands[i]=NULL;

	if(motherstrands[i])
	    delete motherstrands[i];
	motherstrands[i]=NULL;
    }

    if(nhead) 
	delete nhead;
    nhead=NULL;

    if(standard_thread)
	delete standard_thread;
    standard_thread=NULL;

    for(i=0;i<NUM_INSTRUCTIONS;i++)
	if(instruct[i])
	    delete instruct[i];

    if(nn)
	delete nn;
    nn=NULL;

    if(standard_internal)
	delete standard_internal;
    standard_internal=NULL;

    if(standard_out)
	delete standard_out;
    standard_out=NULL;

    init();
}


replicatorset::replicatorset(cromosome_strand *strands_from_father, 
			     cromosome_strand *strands_from_mother,
			     unsigned int number_of_cromosomes, 
			     int numinnodes, int numoutnodes)
{
    init();
  
    num_cromo=number_of_cromosomes;
    numin=numinnodes;
    numout=numoutnodes;
    for(unsigned int i=0;i<num_cromo;i++)
    {
	fatherstrands[i] = new cromosome_strand(this, i, 
						strands_from_father+i);
	motherstrands[i] = new cromosome_strand(this, i, 
						strands_from_mother+i);
    }
  
    read_cromosome1();
    read_cromosome2(false);
    read_instructions();
}
	
replicatorset::replicatorset(unsigned int number_of_cromosomes, 
			     int numinnodes, int numoutnodes,
			     unsigned int bitlen)
{
    init();
  
    num_cromo=number_of_cromosomes;
    numin=numinnodes;
    numout=numoutnodes;

    fatherstrands[0] = new cromosome_strand(this, 0, 2000);
    motherstrands[0] = new cromosome_strand(this, 0, 2000);
    fatherstrands[1] = new cromosome_strand(this, 1, 5000);
    motherstrands[1] = new cromosome_strand(this, 1, 5000);
    for(unsigned int i=2;i<num_cromo;i++)
    {
	fatherstrands[i] = new cromosome_strand(this, i, bitlen);
	motherstrands[i] = new cromosome_strand(this, i, bitlen);
    }
  
    read_cromosome1();
    read_cromosome2(false);
    read_instructions();
}
	
replicatorset::replicatorset(char *filename)
{
    init();

    from_file(filename);

    read_cromosome1(NULL, NULL, false);
    read_cromosome2(false);
    read_instructions();
}

replicatorset::replicatorset(FILE *f)
{
    init();

    from_file(f);

    read_cromosome1();
    read_cromosome2(false);
    read_instructions();
}

replicatorset::replicatorset(replicatorset *original, bool dorepair,
			     bool domutate)
{
    init();
  
    num_cromo = original->num_cromo;
    numin=original->numin;
    numout=original->numout;
    for(unsigned int i=0;i<num_cromo;i++)
    {
	fatherstrands[i] = new cromosome_strand(this, i, 
						original->fatherstrands[i]);
	motherstrands[i] = new cromosome_strand(this, i, 
						original->motherstrands[i]);
    }
  
    if(domutate)
	mutate(original, original);
    read_cromosome1(original,NULL, dorepair);
    gender=original->gender;
    read_cromosome2(dorepair);
    read_instructions();
}

replicatorset::replicatorset(replicatorset *father, replicatorset *mother,
			     bool domutate, bool dorepair)
{
    init();

    num_cromo = MINIM(mother->num_cromo, father->num_cromo);
    if(father->num_cromo>mother->num_cromo)
	num_cromo += (unsigned int) 
	    floor(drand48() * double(father->num_cromo-mother->num_cromo+1));
    else if(father->num_cromo<mother->num_cromo)
	num_cromo += (unsigned int) 
	    floor(drand48() * double(mother->num_cromo-father->num_cromo+1));

    numin=mother->numin;
    numout=mother->numout;

    for(unsigned int i=0;i<num_cromo;i++)
    {
	if(i<father->num_cromo)
	    fatherstrands[i] = new cromosome_strand(this, i, 
						    father->fatherstrands[i], 
						    father->motherstrands[i]);
	else
	    fatherstrands[i] = new cromosome_strand(this, i, 
						    mother->fatherstrands[i], 
						    mother->motherstrands[i]);

	if(father==mother) // clone
	    motherstrands[i]=new cromosome_strand(this, i, fatherstrands[i]);
	else // separate handling of motherstrands
	{
	    if(i<mother->num_cromo)
		motherstrands[i] = new cromosome_strand(this, i, 
							mother->fatherstrands[i], 
							mother->motherstrands[i]);
	    else
		motherstrands[i] = new cromosome_strand(this, i, 
							father->fatherstrands[i], 
							father->motherstrands[i]);
	}
    }

    if(domutate)
	mutate(father, mother);
    read_cromosome1(father, father==mother ? NULL : mother, dorepair);
    read_cromosome2(dorepair);
    read_instructions();
}

replicatorset::~replicatorset() 
{
    cleanup();
}

neuralnet *replicatorset::get_neural_net(void)
{
    return nn;
}

GENDER replicatorset::get_gender(void)
{
    return gender;
}

int replicatorset::get_max_generation(void)
{
    return maxgen;
}

double replicatorset::get_outx0(void)
{
    return outX0;
}

double replicatorset::get_outl(void)
{
    return outL;
}

void replicatorset::to_file(char *filename)
{
    FILE *f=fopen(filename, "w");
    if(!f)
    {
	std::cerr << "File '" << filename << "' couldn't be opened!" << std::endl;
	exit(0);
    }

    to_file(f);
  
    fclose(f);
}

void replicatorset::to_file(FILE *f)
{
    fwrite(&num_cromo, sizeof(unsigned int), 1, f);
    fwrite(&numin, sizeof(unsigned int), 1, f);
    fwrite(&numout, sizeof(unsigned int), 1, f);
    fwrite(&gender, sizeof(GENDER), 1, f);
    fwrite(&first_repair, sizeof(double), 1, f);

    // write dominant global variables;
    fwrite(&pointmutationrate, sizeof(double), 1, f);
    fwrite(&pointmutationrate_1, sizeof(double), 1, f);
    fwrite(&pointmutationrate_2, sizeof(double), 1, f);
    fwrite(&linemutation, sizeof(double), 1, f);
    fwrite(&linemutation_1, sizeof(double), 1, f);
    fwrite(&linemutation_2, sizeof(double), 1, f);
    fwrite(&repair_ratio, sizeof(double), 1, f);
    fwrite(&flip_ratio, sizeof(double), 1, f);
    fwrite(&negate_ratio, sizeof(double), 1, f);
    fwrite(&linelen, sizeof(double), 1, f);
    fwrite(&global_n, sizeof( unsigned int), 1, f);
    fwrite(&maxgen, sizeof(unsigned int), 1, f);
    // write parent 1 global variables;
    fwrite(&pointmutationrate1, sizeof(double), 1, f);
    fwrite(&pointmutationrate_11, sizeof(double), 1, f);
    fwrite(&pointmutationrate_21, sizeof(double), 1, f);
    fwrite(&linemutation1, sizeof(double), 1, f);
    fwrite(&linemutation_11, sizeof(double), 1, f);
    fwrite(&linemutation_21, sizeof(double), 1, f);
    fwrite(&repair_ratio1, sizeof(double), 1, f);
    fwrite(&flip_ratio1, sizeof(double), 1, f);
    fwrite(&negate_ratio1, sizeof(double), 1, f);
    fwrite(&linelen1, sizeof(double), 1, f);
    fwrite(&global_n1, sizeof( unsigned int), 1, f);
    fwrite(&maxgen1, sizeof(unsigned int), 1, f);
    // write parent 2 global variables;
    fwrite(&pointmutationrate2, sizeof(double), 1, f);
    fwrite(&pointmutationrate_12, sizeof(double), 1, f);
    fwrite(&pointmutationrate_22, sizeof(double), 1, f);
    fwrite(&linemutation2, sizeof(double), 1, f);
    fwrite(&linemutation_12, sizeof(double), 1, f);
    fwrite(&linemutation_22, sizeof(double), 1, f);
    fwrite(&repair_ratio2, sizeof(double), 1, f);
    fwrite(&flip_ratio2, sizeof(double), 1, f);
    fwrite(&negate_ratio2, sizeof(double), 1, f);
    fwrite(&linelen2, sizeof(double), 1, f);
    fwrite(&global_n2, sizeof( unsigned int), 1, f);
    fwrite(&maxgen2, sizeof(unsigned int), 1, f);  
  
    // write dominant standard thwrite;
    fwrite(&tr, sizeof(double), 1, f);
    fwrite(&tm, sizeof(double), 1, f);
    fwrite(&ta, sizeof(double), 1, f);
    fwrite(&tf0, sizeof(double), 1, f);
    fwrite(&tg, sizeof(double), 1, f);
    fwrite(&td, sizeof(double), 1, f);
    // write parent 1 standard thwrite;
    fwrite(&tr1, sizeof(double), 1, f);
    fwrite(&tm1, sizeof(double), 1, f);
    fwrite(&ta1, sizeof(double), 1, f);
    fwrite(&tf01, sizeof(double), 1, f);
    fwrite(&tg1, sizeof(double), 1, f);
    fwrite(&td1, sizeof(double), 1, f);
    // write parent 2 standard thwrite;
    fwrite(&tr2, sizeof(double), 1, f);
    fwrite(&tm2, sizeof(double), 1, f);
    fwrite(&ta2, sizeof(double), 1, f);
    fwrite(&tf02, sizeof(double), 1, f);
    fwrite(&tg2, sizeof(double), 1, f);
    fwrite(&td2, sizeof(double), 1, f);
  
    // write dominant standard internal node;
    fwrite(&r, sizeof(double), 1, f);
    fwrite(&m, sizeof(double), 1, f);
    fwrite(&x0, sizeof(double), 1, f);
    fwrite(&l, sizeof(double), 1, f);
    fwrite(&gamma, sizeof(double), 1, f);
    fwrite(&d, sizeof(double), 1, f);
    fwrite(&g, sizeof(double), 1, f);
    fwrite(&reload, sizeof(double), 1, f);
    fwrite(&fatigue_level, sizeof(double), 1, f);
    fwrite(&fatigue_decrease, sizeof(double), 1, f);
    // write parent 1 standard internal node;
    fwrite(&r1, sizeof(double), 1, f);
    fwrite(&m1, sizeof(double), 1, f);
    fwrite(&x01, sizeof(double), 1, f);
    fwrite(&l1, sizeof(double), 1, f);
    fwrite(&gamma1, sizeof(double), 1, f);
    fwrite(&d1, sizeof(double), 1, f);
    fwrite(&g1, sizeof(double), 1, f);
    fwrite(&reload1, sizeof(double), 1, f);
    fwrite(&fatigue_level1, sizeof(double), 1, f);
    fwrite(&fatigue_decrease1, sizeof(double), 1, f);
    // write parent 2 standard internal node;
    fwrite(&r2, sizeof(double), 1, f);
    fwrite(&m2, sizeof(double), 1, f);
    fwrite(&x02, sizeof(double), 1, f);
    fwrite(&l2, sizeof(double), 1, f);
    fwrite(&gamma2, sizeof(double), 1, f);
    fwrite(&d2, sizeof(double), 1, f);
    fwrite(&g2, sizeof(double), 1, f);
    fwrite(&reload2, sizeof(double), 1, f);
    fwrite(&fatigue_level2, sizeof(double), 1, f);
    fwrite(&fatigue_decrease2, sizeof(double), 1, f);

    // write dominant output node;
    fwrite(&gor, sizeof(double), 1, f);
    fwrite(&om, sizeof(double), 1, f);
    fwrite(&ox0, sizeof(double), 1, f);
    fwrite(&ol, sizeof(double), 1, f);
    fwrite(&ogamma, sizeof(double), 1, f);
    fwrite(&od, sizeof(double), 1, f);
    fwrite(&og, sizeof(double), 1, f);
    fwrite(&oreload, sizeof(double), 1, f);
    fwrite(&ofatigue_level, sizeof(double), 1, f);
    fwrite(&ofatigue_decrease, sizeof(double), 1, f);
    fwrite(&outL, sizeof(double), 1, f);
    fwrite(&outX0, sizeof(double), 1, f);
    // write parent 1 output node;
    fwrite(&gor1, sizeof(double), 1, f);
    fwrite(&om1, sizeof(double), 1, f);
    fwrite(&ox01, sizeof(double), 1, f);
    fwrite(&ol1, sizeof(double), 1, f);
    fwrite(&ogamma1, sizeof(double), 1, f);
    fwrite(&od1, sizeof(double), 1, f);
    fwrite(&og1, sizeof(double), 1, f);
    fwrite(&oreload1, sizeof(double), 1, f);
    fwrite(&ofatigue_level1, sizeof(double), 1, f);
    fwrite(&ofatigue_decrease1, sizeof(double), 1, f);
    fwrite(&outL1, sizeof(double), 1, f);
    fwrite(&outX01, sizeof(double), 1, f);
    // write parent 2 output node;
    fwrite(&gor2, sizeof(double), 1, f);
    fwrite(&om2, sizeof(double), 1, f);
    fwrite(&ox02, sizeof(double), 1, f);
    fwrite(&ol2, sizeof(double), 1, f);
    fwrite(&ogamma2, sizeof(double), 1, f);
    fwrite(&od2, sizeof(double), 1, f);
    fwrite(&og2, sizeof(double), 1, f);
    fwrite(&oreload2, sizeof(double), 1, f);
    fwrite(&ofatigue_level2, sizeof(double), 1, f);
    fwrite(&ofatigue_decrease2, sizeof(double), 1, f);
    fwrite(&outL2, sizeof(double), 1, f);
    fwrite(&outX02, sizeof(double), 1, f);

    for(unsigned int i=0;i<num_cromo;i++)
    {
	fatherstrands[i]->to_file(f);
	motherstrands[i]->to_file(f);
    }
}

void replicatorset::from_file(FILE *f)
{
    fread(&num_cromo, sizeof(unsigned int), 1, f);
    fread(&numin, sizeof(unsigned int), 1, f);
    fread(&numout, sizeof(unsigned int), 1, f);
    fread(&gender, sizeof(GENDER), 1, f);
    fread(&first_repair, sizeof(double), 1, f);

    // read dominant global variables;
    fread(&pointmutationrate, sizeof(double), 1, f);
    fread(&pointmutationrate_1, sizeof(double), 1, f);
    fread(&pointmutationrate_2, sizeof(double), 1, f);
    fread(&linemutation, sizeof(double), 1, f);
    fread(&linemutation_1, sizeof(double), 1, f);
    fread(&linemutation_2, sizeof(double), 1, f);
    fread(&repair_ratio, sizeof(double), 1, f);
    fread(&flip_ratio, sizeof(double), 1, f);
    fread(&negate_ratio, sizeof(double), 1, f);
    fread(&linelen, sizeof(double), 1, f);
    fread(&global_n, sizeof( unsigned int), 1, f);
    fread(&maxgen, sizeof(unsigned int), 1, f);
    // read parent 1 global variables;
    fread(&pointmutationrate1, sizeof(double), 1, f);
    fread(&pointmutationrate_11, sizeof(double), 1, f);
    fread(&pointmutationrate_21, sizeof(double), 1, f);
    fread(&linemutation1, sizeof(double), 1, f);
    fread(&linemutation_11, sizeof(double), 1, f);
    fread(&linemutation_21, sizeof(double), 1, f);
    fread(&repair_ratio1, sizeof(double), 1, f);
    fread(&flip_ratio1, sizeof(double), 1, f);
    fread(&negate_ratio1, sizeof(double), 1, f);
    fread(&linelen1, sizeof(double), 1, f);
    fread(&global_n1, sizeof( unsigned int), 1, f);
    fread(&maxgen1, sizeof(unsigned int), 1, f);
    // read parent 2 global variables;
    fread(&pointmutationrate2, sizeof(double), 1, f);
    fread(&pointmutationrate_12, sizeof(double), 1, f);
    fread(&pointmutationrate_22, sizeof(double), 1, f);
    fread(&linemutation2, sizeof(double), 1, f);
    fread(&linemutation_12, sizeof(double), 1, f);
    fread(&linemutation_22, sizeof(double), 1, f);
    fread(&repair_ratio2, sizeof(double), 1, f);
    fread(&flip_ratio2, sizeof(double), 1, f);
    fread(&negate_ratio2, sizeof(double), 1, f);
    fread(&linelen2, sizeof(double), 1, f);
    fread(&global_n2, sizeof( unsigned int), 1, f);
    fread(&maxgen2, sizeof(unsigned int), 1, f);  
  
    // read dominant standard thread;
    fread(&tr, sizeof(double), 1, f);
    fread(&tm, sizeof(double), 1, f);
    fread(&ta, sizeof(double), 1, f);
    fread(&tf0, sizeof(double), 1, f);
    fread(&tg, sizeof(double), 1, f);
    fread(&td, sizeof(double), 1, f);
    // read parent 1 standard thread;
    fread(&tr1, sizeof(double), 1, f);
    fread(&tm1, sizeof(double), 1, f);
    fread(&ta1, sizeof(double), 1, f);
    fread(&tf01, sizeof(double), 1, f);
    fread(&tg1, sizeof(double), 1, f);
    fread(&td1, sizeof(double), 1, f);
    // read parent 2 standard thread;
    fread(&tr2, sizeof(double), 1, f);
    fread(&tm2, sizeof(double), 1, f);
    fread(&ta2, sizeof(double), 1, f);
    fread(&tf02, sizeof(double), 1, f);
    fread(&tg2, sizeof(double), 1, f);
    fread(&td2, sizeof(double), 1, f);
  
    // read dominant standard internal node;
    fread(&r, sizeof(double), 1, f);
    fread(&m, sizeof(double), 1, f);
    fread(&x0, sizeof(double), 1, f);
    fread(&l, sizeof(double), 1, f);
    fread(&gamma, sizeof(double), 1, f);
    fread(&d, sizeof(double), 1, f);
    fread(&g, sizeof(double), 1, f);
    fread(&reload, sizeof(double), 1, f);
    fread(&fatigue_level, sizeof(double), 1, f);
    fread(&fatigue_decrease, sizeof(double), 1, f);
    // read parent 1 standard internal node;
    fread(&r1, sizeof(double), 1, f);
    fread(&m1, sizeof(double), 1, f);
    fread(&x01, sizeof(double), 1, f);
    fread(&l1, sizeof(double), 1, f);
    fread(&gamma1, sizeof(double), 1, f);
    fread(&d1, sizeof(double), 1, f);
    fread(&g1, sizeof(double), 1, f);
    fread(&reload1, sizeof(double), 1, f);
    fread(&fatigue_level1, sizeof(double), 1, f);
    fread(&fatigue_decrease1, sizeof(double), 1, f);
    // read parent 2 standard internal node;
    fread(&r2, sizeof(double), 1, f);
    fread(&m2, sizeof(double), 1, f);
    fread(&x02, sizeof(double), 1, f);
    fread(&l2, sizeof(double), 1, f);
    fread(&gamma2, sizeof(double), 1, f);
    fread(&d2, sizeof(double), 1, f);
    fread(&g2, sizeof(double), 1, f);
    fread(&reload2, sizeof(double), 1, f);
    fread(&fatigue_level2, sizeof(double), 1, f);
    fread(&fatigue_decrease2, sizeof(double), 1, f);

    // read dominant output node;
    fread(&gor, sizeof(double), 1, f);
    fread(&om, sizeof(double), 1, f);
    fread(&ox0, sizeof(double), 1, f);
    fread(&ol, sizeof(double), 1, f);
    fread(&ogamma, sizeof(double), 1, f);
    fread(&od, sizeof(double), 1, f);
    fread(&og, sizeof(double), 1, f);
    fread(&oreload, sizeof(double), 1, f);
    fread(&ofatigue_level, sizeof(double), 1, f);
    fread(&ofatigue_decrease, sizeof(double), 1, f);
    fread(&outL, sizeof(double), 1, f);
    fread(&outX0, sizeof(double), 1, f);
    // read parent 1 output node;
    fread(&gor1, sizeof(double), 1, f);
    fread(&om1, sizeof(double), 1, f);
    fread(&ox01, sizeof(double), 1, f);
    fread(&ol1, sizeof(double), 1, f);
    fread(&ogamma1, sizeof(double), 1, f);
    fread(&od1, sizeof(double), 1, f);
    fread(&og1, sizeof(double), 1, f);
    fread(&oreload1, sizeof(double), 1, f);
    fread(&ofatigue_level1, sizeof(double), 1, f);
    fread(&ofatigue_decrease1, sizeof(double), 1, f);
    fread(&outL1, sizeof(double), 1, f);
    fread(&outX01, sizeof(double), 1, f);
    // read parent 2 output node;
    fread(&gor2, sizeof(double), 1, f);
    fread(&om2, sizeof(double), 1, f);
    fread(&ox02, sizeof(double), 1, f);
    fread(&ol2, sizeof(double), 1, f);
    fread(&ogamma2, sizeof(double), 1, f);
    fread(&od2, sizeof(double), 1, f);
    fread(&og2, sizeof(double), 1, f);
    fread(&oreload2, sizeof(double), 1, f);
    fread(&ofatigue_level2, sizeof(double), 1, f);
    fread(&ofatigue_decrease2, sizeof(double), 1, f);
    fread(&outL2, sizeof(double), 1, f);
    fread(&outX02, sizeof(double), 1, f);

    for(unsigned int i=0;i<num_cromo;i++)
    {
	fatherstrands[i]=new cromosome_strand(this, f);
	motherstrands[i]=new cromosome_strand(this, f);
    }
}


void replicatorset::from_file(char *filename)
{
    FILE *f=NULL;

    f=fopen(filename, "r");
    if(!f)
    {
	std::cerr << "File '" << filename << "' couldn't be opened!" << std::endl;
	exit(0);
    }

    from_file(f);

    fclose(f);
}

  
double replicatorset::get_point_mutation_rate(void)
{
    return pointmutationrate;
}

double replicatorset::get_point_mutation_rate1(void)
{
    return pointmutationrate_1;
}

double replicatorset::get_point_mutation_rate2(void)
{
    return pointmutationrate_2;
}

double replicatorset::get_line_mutation_rate(void)
{
    return linemutation;
}

double replicatorset::get_line_mutation_rate1(void)
{
    return linemutation_1;
}

double replicatorset::get_line_mutation_rate2(void)
{
    return linemutation_2;
}

double replicatorset::get_flip_rate(void)
{
    return flip_ratio;
}

double replicatorset::get_negate_rate(void)
{
    return negate_ratio;
}

double replicatorset::get_line_length(void)
{
    return linelen;
}

unsigned int replicatorset::get_global_n(void)
{
    return global_n;
}

unsigned int replicatorset::get_max_number_of_generations(void)
{
    return maxgen;
}



double replicatorset::get_repair_ratio(void)
{
    return repair_ratio;
}

double replicatorset::get_first_repair(void)
{ 
    return first_repair;
}

double replicatorset::get_variable_mutation_rate(void)
{
    return variablemutaterate;
}

double replicatorset::get_variable_mutation_size(void)
{
    return variablemutatesize;
}

double replicatorset::get_num_instruction(INSTRCUTION_TYPE type)
{
    return num_instruction[type];
}

double replicatorset::get_total_instructions(void)
{
    return total_instructions;
}

int replicatorset::get_num_nodes(void)
{
    return numnodes;
}

thread *replicatorset::get_standard_thread(void)
{
    return standard_thread;
}

node *replicatorset::get_standard_internal(void)
{
    return standard_internal;
}

node *replicatorset::get_standard_out(void)
{
    return standard_out;
}
