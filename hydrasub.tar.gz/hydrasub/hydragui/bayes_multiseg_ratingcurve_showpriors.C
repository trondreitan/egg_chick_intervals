#include "bayes_multiseg_ratingcurve_showpriors.H"
#include <cmath>
#include <hydrasub/hydrabase/stagedischarge.H>

void segmented_rcurve_button::
Create(widget parent, char *txt, SEG_INT_TYPE type,
       segmented_rcurve_showpriors *ipt)
{
  build(parent,txt);
  btype=type;
  pt=ipt;
}

void segmented_rcurve_button::pushed(void)
{
  pt->take_action(btype);
}

void segmented_rcurve_toggle::
Create(widget parent, char *txt, SEG_INT_TYPE type,
       segmented_rcurve_showpriors *ipt)
{
  pt=NULL;
  build(parent, txt);
  btype=type;
  pt=ipt;
}

void segmented_rcurve_toggle::pushed(bool newstate)
{
  if(pt)
    {
      if(btype==SEG_INT_DETAILED_HS && newstate==False)
	pt->take_action(SEG_INT_HS_CANCEL);
      else if(btype==SEG_INT_DETAILED_H0 && newstate==False)
	pt->take_action(SEG_INT_H0_CANCEL);
      else if(btype==SEG_INT_DETAILED_LIN && newstate==False)
	pt->take_action(SEG_INT_LIN_CANCEL);
      else
	pt->take_action(btype);
    }
}

void segmented_rcurve_toggle::switch_off(void)
{
  segmented_rcurve_showpriors *buffer=pt;
  pt=NULL;
  ToggleButtonOff();
  pt=buffer;
}

void segmented_rcurve_toggle::switch_on(void)
{
  segmented_rcurve_showpriors *buffer=pt;
  pt=NULL;
  ToggleButtonOn();
  pt=buffer;
}


void lognormal_h01_toggle::Create(widget parent, 
				  segmented_rcurve_showpriors *ipt, 
				  bool state)
{
  pt=NULL;
  build(parent, WHAT((char *) "Sett maksimal bunnvannstand (h01)", 
		     (char *) "Set maximal zero plane (h01)"));
  if(state)
    ToggleButtonOn();
  else
    ToggleButtonOff();
  pt=ipt;
}

void lognormal_h01_toggle::pushed(bool state)
{
  if(pt)
    pt->set_lognormal_h01_state(state);
}

void h0sep_lognormal_toggle::Create(widget parent, 
				    segmented_rcurve_showpriors *ipt, 
				    int numseg_, int seg_,
				    bool state)
{
  pt=NULL;
  build(parent, WHAT((char *) "Sett maksimal h0", 
		     (char *) "Set maximal h0"));
  if(state)
    ToggleButtonOn();
  else
    ToggleButtonOff();
  numseg=numseg_;
  seg=seg_;
  pt=ipt;
}

void h0sep_lognormal_toggle::pushed(bool state)
{
  if(pt)
    pt->set_lognormal_h0_state(state, numseg, seg);
}



void srs_hypertext_label::Create(widget parent, SRS_HYPERTEXT_TYPE type_)
{
  char *labelstring=new char[1000];

  type=type_;

  switch(type)
    {
    case SRSH_INTERVAL:
      strcpy(labelstring,
	     WHAT((char *) "Om vannf�ringsintervaller", 
		  (char *) "About discharge inttervals"));
      break;
    case SRSH_PARAM:
      strcpy(labelstring,
	      WHAT((char *) "kurve-parametre",
		   (char *) "curve parameters"));
      break;
    case SRSH_EXPONENT: 
      strcpy(labelstring,
	      WHAT((char *) "Eksponent",
		   (char *) "Exponent"));
      break;
    case SRSH_CONSTANT:
      strcpy(labelstring,
	      WHAT((char *) "Konstant",
		   (char *) "Constant"));
      break;
    case SRSH_CORR:
      strcpy(labelstring,
	      WHAT((char *) "Korrelasjon",
		   (char *) "Correlation"));
      break;
    case SRSH_ZEROSTAGE:
      strcpy(labelstring,
	      WHAT((char *) "Bunnvannstand",
		   (char *) "Zero stage"));
      break;
    case SRSH_ZEROSTAGE2:
      strcpy(labelstring,
	      WHAT((char *) "nivellering",
		   (char *) "zero stage measurement"));
      break;
    case SRSH_ZEROSTAGE3:
      strcpy(labelstring,
	      WHAT((char *) "Maksimal bunnvannstand",
		   (char *) "Maximal zero stage"));
      break;
    case SRSH_ZEROSTAGE4:
      strcpy(labelstring,
	      WHAT((char *) "Relative bunnvannstand for �vre segmenter",
		   (char *) "Relative zero plane for upper segments"));
      break;
    case SRSH_SEG:
      strcpy(labelstring,
	      WHAT((char *) "Segmenterings-vannstand",
		   (char *) "Segmentation stage"));
      break;
    case SRSH_SIGMA:
      strcpy(labelstring,
	      WHAT((char *) "St�yens standardavvik, sigma:",
		   (char *) "Noise standard deviation, sigma:"));
      break;
    case SRSH_PROB_SEG:
      strcpy(labelstring,
	     WHAT((char *) "Segment-sannsynligheter:", 
		  (char *) "Segmentation probabilities:"));
      break;
    default:
      strcpy(labelstring,"???");
      break;
    }
  
  Build(parent, labelstring);
  delete [] labelstring;
}

void srs_hypertext_label::pushed(void)
{
  char *infostr=new char[20000];

  switch(type)
    {
    case SRSH_INTERVAL:
      strcpy(infostr,
	     WHAT((char *) "Vannf�ringsintervall settes n�r man har kunnskap\n"
		  "om ca. hva vannf�ringen skal v�re for en gitt vannstand\n"
		  "over �verste m�ling. Dette kan komme fra enkle\n"
		  "hydrauliske vurderinger eller avanserte hydrauliske\n"
		  "beregninger basert p� m�linger av profilen.\n"
		  "NB: Siden et intervall skal settes, m� du uansett ha et\n"
		  "forhold til usikkerhet p� estimatet.\n"
		  "NBB: Flere slike vannf�ringsintervaller kan settes.\n",
		  (char *) "Discharge intervals can be set when you have\n"
		  "knowledge concerning what the discharge should\n"
		  "approximately be for a given stage value. This knowledge\n"
		  "can come from simple hydraulic judgement or from\n"
		  "advanced hydraulic calculations based on measurements of\n"
		  "the profile's form.\n"
		  "PS: Since intervals are specified, you will in any case\n"
		  "need to relate to the uncertainty of the estimate.\n"
		  "PSS: More than one interval can be specified.\n"));
      break;
    case SRSH_PARAM:
      strcpy(infostr,
	     WHAT((char *) "Kurve-parametre er ting som eksponent (forbundet\n"
		  "med profilens form), bunnvannstand og detaljer "
		  "om ulike segmenter.\n"
		  "NB: Antall mulige segmenter (i dette vinduet) m� v�re\n"
		  "satt f�r kurve-parameter-f�rkunnskap kan settes.", 
		  (char *) "Curve parameters are things like the exponent\n"
		  "(connected to the shape of the profile), zero stage and\n"
		  "details concerning segments.\n"
		  "PS: The number of possible segments (in this winodw) must\n"
		  "be set before prior knowledge concerning curve parameters\n"
		  "can be set."));
      break;
    case SRSH_EXPONENT: 
      strcpy(infostr,
	     WHAT((char *) "Eksponenten er en kurve-parameter tett knyttet til profilens form.\n"
		  "Ligningen for vannf�ring har formen Q=C*(h-h0)^b, der 'b' er eksponenten.\n"
		  "Hvis man ogs� kan lage en power-law for profilens bredde som funksjon av\n"
		  "vannstands-h�yden, Bredde=k*(h-h0)^d, vil eksponenten v�re b=d+1.5 for\n"
		  "steder med hydrauliske sprang og b=d+1.67 for uniform str�mning.\n"
		  "F.eks, for et hydraulisk sprang for en rektangul�r profil, vil b=1.5,\n"
		  "mens for v-overl�p vil b=2.5. U-formede overl�p vil ha b ca. lik 2.0,\n"
		  "mens profiler som buer seg utover vil ha b>2.5.\n"
		  "Litt usikkerhet b�r uansett settes, f.eks. +/-0.1.\n"
		  "\n"
		  "Merk at i hovedvinduet settes f�rkunnskap for eksponent for *alle* segmenter\n"
		  "som betyr at man spesifiseres at i tilfelle flere segmenter b�r alle\n"
		  "segmentenes eksponenter v�re innenfor det gitte rimelighets-intervallet.\n"
		  "Har man oppfatning om ulike eksponenter p� ulike segmenter b�r detaljert\n"
		  "spesifiksjon foretas.\n"
		  "\n"
		  "Merk ogs� at rimelighets-intervallet ikke setter en absolutt grense for\n"
		  "hva slags estimater man f�r ut, men i stedet angir hvor det med 95%%\n"
		  "sannsynlighet er at eksponenten befinner seg. Dette for � kunne muliggj�re\n"
		  "at data kan antyde verdier utenfor grensen for intervallet, hvis dataene er\n"
		  "gode nok og i tilstrekkelig grad peker i retning av noe utenfor brukerens\n"
		  "rimelighets-grenseverdier.",
		  (char *) "The exponent is a curve parameter tightly linked to the shape of\n"
		  "the profile. The equation for discharge is Q=C*(h-h0)^b, where 'b' is the\n"
		  "exponent. If one also makes a power-law for the width of the river as a \n"
		  "function of the stage-height, width=k*(h-h0)^d, then for a hydraulic jump\n"
		  "the exponent will be b=d+1.5 and for uniform flow, it will be b=d+1.67.\n"
		  "So for instance, for a hydraulic jump for a rectangular profil then b=1.5,\n"
		  "while for a v-shape it will be b=2.5. For a U shaped profile b will\n"
		  "approcimately be 2.0 while for profiles which bends outwards then b>2.5.\n" 
		  "Some uncertainty should in any case be set, for instance +/-0.1.\n"
		  "\n"
		  "Note that in the main window, the prior knowledge for the exponents for\n"
		  "*all* segments is set, which means that in case of more than one segment,\n"
		  "then the exponents of all segments should be inside the given credibility\n"
		  "interval. If your prior knowledge contains different credibility\n"
		  "instervals for different segments, then a detailed specification of\n"
		  "credibility intervals is needed."
		  "\n"
		  "Note also that the credibility interval does not specify an absolute limit\n"
		  "for what kind of estimates one gets, but instead specifies an interval for\n"
		  "which there is 95%% prior probability for the value to be inside. This\n"
		  "makes it possible for the estiamte to be found outside that inteval, if\n"
		  "the data is good enough and points towards values outside the user-given\n"
		  "credibility interval."));
      break;
    case SRSH_CONSTANT:
      strcpy(infostr,
	     WHAT((char *) "Konstanten krever litt mer kunnskap om profilens form for �\n"
		  "sette enn det som er tilfelle for eksponenten. Konstanten, C, kan tolkes som\n"
		  "vannf�ringen n�r vannstanden st�r en meter over bunnen. Derfor avhenger den\n"
		  "b�de av form (rektangul�r, V, U eller buende utover), bredde og muligens\n"
		  "ruhet. For skarpkantede profiler finns det formler som kan beregne den,\n"
		  "men pass p� � sett en del usikkerhet uansett.\n"
		  "For naturlige profiler anbefales det � la f�r-kunnskapen st� som den\n"
		  "er og hellers la data estimere parameteren.\n"
		  "\n"
		  "Merk at konstanten bare settes for det laveste segmentet (i dataomr�det).\n"
		  "Konstantene for segmenter oppover settes ut ifra kontinuitets-krav, slik\n"
		  "at f.eks. konstant for segment nummer 2, C2, beregnes fra formelen\n"
		  "C*(hs1-h01)^b1 = C2*(hs1-h02)^b2, der hs1 er vannstanden for\n"
		  "det f�rste segmentskillet, h01 og h02 er bunnvannstanden til f�rste og andre\n"
		  "segment og tilsvarende b1 og b2 er eksponent for f�rste og andre segment.\n"
		  "\n"
		  "Merk ogs� at rimelighets-intervallet ikke setter en absolutt grense for\n"
		  "hva slags estimater man f�r ut, men i stedet angir hvor det med 95%%\n"
		  "sannsynlighet er at konstanten befinner seg. Dette for � kunne muliggj�re\n"
		  "at data kan antyde verdier utenfor grensen for intervallet, hvis dataene er\n"
		  "gode nok og i tilstrekkelig grad peker i retning av noe utenfor brukerens\n"
		  "rimelighets-grenseverdier.",
		  (char *) "The constant requires more prior knowledge concerning the profile \n"
		  "to set than for the exponent. The constant, C, can be interpreted as\n"
		  "the discharge when the stage is one meter above the bottom (zero stage).\n"
		  "Thus, it depends on the shape (rectangular, V, U, bending outwards),"
		  "the width and even possibly on the roughness of the river profile.\n"
		  "For sharp edged profiles, there are formulas for calculating the constant\n"
		  "but do put some uncertainty on it anyway.\n"
		  "For natural profiles is is perhaps best to leave the credibility interval\n"
		  "as it is, and let the data estimate the parameter.\n"
		  "\n"
		  "Note that the constant is only set for the lowest segment (in the data\n"
		  "range), while the constant of the other segments is set by the requirement\n"
		  "of continuity of the stage-discharge rating curve. Thus the constant for\n"
		  "for instance segment 2, C2, is set by the equation\n"
		  "C*(hs1-h01)^b1 = C2*(hs1-h02)^b2, \n"
		  "where hs1 is the stage value of the first segmentation, h01 and h02\n"
		  "is the zero stage of the first and second segment respectively and similarly\n"
		  "b1 and b2 is the exponent of the first and second segment.\n"
		  "\n"
		  "Note also that the credibility interval does not specify an absolute limit\n"
		  "for what kind of estimates one gets, but instead specifies an interval for\n"
		  "which there is 95%% prior probability for the value to be inside. This\n"
		  "makes it possible for the estiamte to be found outside that inteval, if\n"
		  "the data is good enough and points towards values outside the user-given\n"
		  "credibility interval."));
      break;
    case SRSH_CORR:
      strcpy(infostr,
	     WHAT((char *) "Korrelasjon er den line�re sammenhengen mellom konstant\n"
		  "(p� log-skala, da det er der line�r-antagelsene stemmer) og eksponenten\n"
		  "og for eksponenter for ulike segmenter. verdien som er satt i utgangspunktet\n"
		  "er satt utifra en gjennomgang av allerede estimerte kurver p� NVE anno 2004.\n"
		  "Hvis du setter f�rkunnskapen mer spesifikt, b�r du sette korrelasjonen\n"
		  "lik null, siden du neppe har en line�rsammenheng mellom f�rkunnskapen din\n"
		  "ang�ende ulike parametre.\n",
		  (char *) "The correlation is the linear relationship between constand\n"
		  "(on the log scale, as that is where the assumption of linearity holds)\n"
		  "and the exponent and between exponents for different segments.\n"
		  "If you set prior knowledge concerning exponent(s) or constant more\n"
		  "specifically, the correlation should be set to zero, as you probabily have\n"
		  "no linear dependency between your prior knowledge concerning different\n"
		  "parameters."));
      break;
    case SRSH_ZEROSTAGE:strcpy(infostr,
	     WHAT((char *) "Bunnvannstanden er den vannstanden der det ikke lenger renner\n"
		  "vann i elva. Hva denne er kommer an p� h�ydegrunnlaget som brukes\n"
		  "(lokalh�yde i forhold til en bolt, eller h�yde-over-havet, f.eks.).\n"
		  "Kjenner du h�ydegrunnlaget og har foretatt nivelleringer, alts� \n"
		  "bunnvannstandsm�linger, kan denne settes forholdsvis n�yaktig, der\n"
		  "n�yaktigheten kommer an p� hvor regul�r profilen er. Med skarpkantede\n"
		  "profiler kan bunnvannstanden muligens settes med 1cm oppl�sning. Har du\n"
		  "nivelleringer p� en natutlig profil med bare sm� steiner kan n�yaktigheten\n"
		  "kanskje settes til rundt 10cm oppl�sning. Store steiner og irregul�r bunn\n"
		  "kan fordre st�rre �n�yaktighet enn det ogs�, selv med nivelleringer.\n"
		  "Har du v�rt p� stedet og kjenner h�ydegrunnlaget, kan du kanskje sette\n"
		  "n�yaktigheten med 1-2m presisjon. Hvis du ikke har v�rt p� stedet men vet\n"
		  "at h�ydegrunnlaget er lokalh�yde, kan du kanskje bruke +/-10m. Men hvis\n"
		  "ikke (absolutt null kunnskap om stedet) (som er det som settes i starten),\n"
		  "brukes +/-Galdh�piggen.\n"
		  "\n"
		  "Merk at den bunnvannstanden som settes her er det som brukes som\n"
		  "bunnvannstands-parameter i laveste segment (i m�lt omr�de). Hvis\n"
		  "du mistenker segmentering under nederste m�lte vannstand, kan det hende\n"
		  "du b�r sette st�rre un�yaktighet for bunnvannstanden enn det du ellers\n"
		  "ville gj�re. Segmenter over nedre segment vil ogs� f� en bunnvannstand\n"
		  "estimert. Denne bunnvannstanden representerer det formen p� profilen i det\n"
		  "segmentet tilsier at bunnen ville v�rt p� hvis dette segmentet fortsatte\n"
		  "helt ned. Det er alts� forholdsvis teoretiske 'bunnvannstander' det dreier\n"
		  "seg om for �vre segmenter.\n"
		  "\n"
		  "Merk ogs� at rimelighets-intervallet ikke setter en absolutt grense for\n"
		  "hva slags estimater man f�r ut, men i stedet angir hvor det med 95%%\n"
		  "sannsynlighet er at bunnen befinner seg. Dette for � kunne muliggj�re\n"
		  "at data kan antyde verdier utenfor grensen for intervallet, hvis dataene er\n"
		  "gode nok og i tilstrekkelig grad peker i retning av noe utenfor brukerens\n"
		  "rimelighets-grenseverdier.\n"
		  "\n"
		  "Har du informasjon om en minste vannstand der det definitivt g�r vannf�ring\n"
		  "kan du sette en hard grense for �vre mulige bunnvannstand,\n"
		  "i tillegg til et 95%% troverdighetsintervall. Dette gj�re i s� tilfelle\n"
		  "i vindu for avansert spesifisering.",
		  (char *) "the zero stage is the stage value for which the river discharge\n"
		  "becomes zero, so that there's no water flowing in the river.\n"
		  "What this is depends on the height strategy used (height above sea level\n"
		  "or local height relative to a bolt). If you know the height strategy\n"
		  "and you have performed zero stage measurementsthen with a sharpedged\n"
		  "profile you may perhaps havea  precision of only 1-2cm. With a relatively\n"
		  "simple natural prfile with only small rocks, the precision can possibly be\n"
		  "just 10-20cm. With larger rocks or irregular profile, you may have to set\n"
		  "the precision to a larger interval even with zero stage measurements.\n"
		  "Without zerostage measurements but having visited the place, you might\n"
		  "perhaps have a percision of 1-2m, if you know the height strategy.\n"
		  "If you haven't visited the place, but know that the height strategy is\n"
		  "local heights, then perhaps +/-10m might suffice. But if absolutely nothing\n"
		  "is known about the palce or the height strategy, +/-2500m meter\n"
		  "(Galdh�piggen, the largest mountain in Norway) is used as a starting\n"
		  "interval.\n"
		  "\n"
		  "Note that the zero stage which is set here is the zero stage of the lowest\n"
		  "segment (in the measured stage interval). If you suspect that there are\n"
		  "segmentations below the loests measurement, then you should probably set\n"
		  "the credibility interval larger than you otherwise whould have done.\n"
		  "Segments above the lowest segment will also be associated with zero stages.\n"
		  "Such zero stages represent what the bottom would be like if the shape of\n"
		  "each segment was extended downwards. They are thus quite theoretical.\n"
		  "\n"
		  "Note also that the credibility interval does not specify an absolute limit\n"
		  "for what kind of estimates one gets, but instead specifies an interval for\n"
		  "which there is 95%% prior probability for the value to be inside. This\n"
		  "makes it possible for the estiamte to be found outside that inteval, if\n"
		  "the data is good enough and points towards values outside the user-given\n"
		  "credibility interval.\n"
		  "\n"
		  "If you now of a minimal stage value where you are certain that water flows\n"
		  "you can set a hard limit for maximal zero stage, in addition to a 95%%\n"
		  "credibility band. If so, this is set in the window for advanced settings."));
      break;
    case SRSH_ZEROSTAGE2:
      strcpy(infostr,
	     WHAT((char *) "Nivelleringer er m�linger av bunnvannstanden",
		  (char *) "Zero stage measurements are measurements of where the\n"
		  "bottom of the profile lies."));
      break;
    case SRSH_ZEROSTAGE3:
      strcpy(infostr,
	     WHAT((char *) "Maksimal bunnvannstand settes n�r man har vannstands-tisserier\n"
		  "som angir at det har runent vann i elva ned til et gitt niv�, slik at\n"
		  "man er 100%% sikker p� at bunnen m� v�re lavere enn et gitt niv�. Har\n"
		  "man andre grunner til � v�re 100%% sikker p� at bunnen er under et gitt\n"
		  "niv�, kan dette ogs� settes her."
		  "\n"
		  "I stedet for en normalfordeling som representatn for f�rkunnskapen, brukes\n"
		  "det da en log-normalfordeling for maskimal bunnvannstand minus\n"
		  "egentlig bunnvannstand." ,
		  (char *) "Maximal zero stage can be used if you have a stage time series\n"
		  "that indicate that the river has flowed down to a certain stage level,\n"
		  "so that you can be 100%% sure that the zero stage is lower than the\n"
		  "given value. other reasons for being 100%% sure that the zero stage\n"
		  "cannot take a given value can also mean you want to set this here."
		  "\n"
		  "instead of a normal distribution representing the prior knowledge\n"
		  "concerning the zero stage, a log-normal distribution for maximal zero\n"
		  "stage minus actual zzero stage is used."));
      break;
    case SRSH_ZEROSTAGE4:
      strcpy(infostr,
	     WHAT((char *) "Relativ teoretisk bunnvannstand for �vre segmenter er\n"
		  "forskjellen mellom bunnvannstand for et segment og det nedenfor. \n"
		  "Segmenter over nedre segment vil ogs� f� en bunnvannstand\n"
		  "estimert. Denne bunnvannstanden representerer det formen p� profilen i det\n"
		  "segmentet tilsier at bunnen ville v�rt p� hvis dette segmentet fortsatte\n"
		  "helt ned. Det er alts� forholdsvis teoretiske 'bunnvannstander' det dreier\n"
		  "seg om for �vre segmenter. Er forskjellen positivt, er bunnen p� neste\n"
		  "segment h�yere enn p� forrige og er forskjellen negativt er bunnen lavere p�\n"
		  "neste segment enn p� forrige. Relativ bunnvanstand gir en slags\n"
		  "f�rkunnskap om disse teoretiske bunnstandene selv n�r de ikke settes\n"
		  "eksplisitt (noe man ogs� kan gj�re).",
		  (char *) "Relative theoretical zero stage for upper segments is the\n"
		  "difference between the zero stage of on segment and the zero stage of\n"
		  "the one below. Segments above the lowest segment will also be associated\n"
		  "with zero stages. Such zero stages represent what the bottom would be\n"
		  "like if the shape of each segment was extended downwards. They are thus\n"
		  "quite theoretical. If the difference is positive, the zero plane of the\n"
		  "next segment is above the zero stage of the segment below. if the\n"
		  "difference is negative, the zero stage of the segment above is lower\n"
		  "than for the segment below. relative zero stage gives a posibility of\n"
		  "the prior knowledge concerning the zero stages of upper segments, without\n"
		  "specifying them in detail (which can also be done)."));
      break;
    case SRSH_SEG:
      strcpy(infostr,
	     WHAT((char *) "Segmenteringer er skiller mellom en parametrisk funksjonssamenheng\n"
		  "og en annen, begge p� power-law form, Q(h)=a(h-h0)^b.\n"
                  "Segmenterings-vannstanden er dermed vannstanden et slikt skille eventuelt\n"
		  "skjer p�. I f�rkunnskaps-vinduet gj�res dette indirekte, ved at man oppgir\n"
		  "hvilke vannf�ringer som er typiske p� stedet. Det antas s� at \n"
		  "segmenteringene fordeler seg over disse typiske vannf�ringene\n"
		  "(som gir vannstand ved at man g�r ut ifra power-law-ligningen for segmentet\n"
		  "nedenfor segmentskillet). Verdiene som ligger der fra f�r av er typiske\n"
		  "vannf�ringer fra stasjoner over hele Norge, s� hvis du vet mer om\n"
		  "stasjonen enn det, kan du forbedre f�rkunnskapen som brukes til � legge inn\n"
		  "segmenterings-vannstander.\n"
		  "\n"
		  "Videre kan man (hvis man g�r til avansert segmenterings-spesifisering) i\n"
		  "stedet velge � direkte spesifisere segmenterings-vannstander for hvert\n"
		  "tilfelle av antall segmenter. Dette krever mer inng�ende kjennskap til\n"
		  "elveprofilen og kan gjerne kombineres med � sette sannsynligheten for\n"
		  "antall segmenter ogs�.\n"
		  "\n"
		  "Selv om segment-skille kan ha gi en 'knekk' i vannstand-vannf�rings-\n"
		  "kurven (en diskontinuitet i kurvens deriverte), kan den\n"
		  "ikke for�rsake et 'vannf�ring-hopp' (en diskontinuitet i selve kurven).\n"
		  "Dette sikres ved at konstanten i power-law-sammenhengen 'ofres' for\n"
		  "h�yere segmenter, mer spesifikt settes den ut ifra de andre power-law-\n"
		  "parametrene (over og under segmentskillet) for � sikre kontinuitet i\n"
		  "segmentskillet.",
		  (char *) "Segmentations are change-points between one parametric function\n"
		  "and another, both on power-law form, Q(h)=a(h-h0)^b.\n"
		  "Segmentation stage is thus the stage at where such a change-point happens.\n"
		  "In the prior window this is done indirectly, by supplying the range\n"
		  "of typical discharge values at the station. It is then assumed that\n"
		  "the segmentations happens according to this distribution, which are\n"
		  "transformed from discharge to stage via the power-law relationship of\n"
		  "the segment below the segmentation. The values that are filled in by\n"
		  "default is taken from all stations in Norway, and can thus be improved\n"
		  "if you know something more specific about the station than that.\n"
		  "\n"
		  "On can instead (by pressing the 'advanced segmentation' button directly\n"
		  "specify the segmentation stages for each possible number of segmentations.\n"
		  "This is done if you know the river profile in more detail and is typically\n"
		  "followed by also setting the probability for each possible number of\n"
		  "segmentations.\n"
		  "n"
		  "Even though the segmentation can give a 'break' in the stage-discharge\n"
		  "curve (a discontinuity in the curve's derivative), it cannot give a\n"
		  "'jump' in the curve (a discontinuity in the curve itself). This is\n"
		  "ensured by 'sacrificing' the constant term of the power-law for all but\n"
		  "the lowest segment. More specifically, it is set from the other power-law\n"
		  "parameters (over and under the segmentation) in order to ensure\n"
		  "continuity."));
      break;
    case SRSH_SIGMA:
      strcpy(infostr,
	     WHAT((char *) "St�yens standardavvik, sigma, angir hvor mye vannf�rings-m�lingene\n"
		  "kan avvike fra kurven skyldende m�lest�y (tilfeldige feil i\n"
		  "instrumentering, kalibrering, avlesing, estimering etc.).\n"
		  "Standardavviket er teknisk sett kvadratroten av gjennomsnittelig\n"
		  "kvadrat-avvik mellom m�ling og gjennomsnitt (som skal ligge p� kurva i \n"
		  "v�rt tilfelle). Sigma er en parameter som inng�r i estimeringen\n"
		  "av vannf�ringskurven og som angir standardavviket til m�lefeilene i\n"
		  "vannf�ring p� logaritmisk skala. Logaritmisk skala benyttes for � kunne\n"
		  "at desto st�rre vannf�ring desto st�rre m�lefeil (alts� relative\n"
		  "usikkerhet) og at negative vannf�ringsm�linger ikke er mulig.\n"
		  "Det antas at m�lest�yen er normalfordelt p� log-skala. Normalfordelingen\n"
		  "har 68.3%% sannsynlighet innenfor +/-standardavvik (sigma) og 95%%\n"
		  "sannsynlighet innenfor +/-1.96standadavvik. P� vannf�rings-skala betyr\n"
		  "dette 68.3%% sannsynlighet innenfor */exp(sigma) av  kurva og 95%%\n"
		  "sannsynlighet innenfor */exp(1.96*sigma). For sm� verdier av sigma, vil\n"
		  "dette ca. bety */(1+sigma) med 68.3%% sannsynlighet og */(1+1.96*sigma) med\n"
		  "95%% sannsynlighet. Alts� kan man se p� sigma som det relative avviket, s�\n"
		  "sigma=0.05 betyr ca 5%% relativt avvik, f.eks. (N�yaktig: 5.13%% relativt\n"
		  "avvik).\n"
		  "\n"
		  "Merk at st�yen standardavvik (sigma) blir gitt for vannf�ringsm�linger med\n"
		  "middels kvalitet. For m�linger markert som 'gode' og 'd�rlige' antas det at\n"
		  "st�yen er proporsjonal med st�yen for middels m�linger, med en\n"
		  "proporsjonalitets-konstant som brukeren kan styre. Default, som brukes\n"
		  "hvis dette ikke settes av brukeren er 0.5 for 'gode' m�linger og 2\n"
		  "'d�rlige' m�linger. Alts�, hvis relativ m�lefeil er 5%% for middels\n"
		  "m�linger, er relativ m�lefeil for 'gode' m�linger 2.5%% og 10%% for\n"
		  "'d�rlige' m�linger. Proporsjonalitets-konstantene for 'gode' og 'd�rlige'\n"
		  "m�linger kan settes i opsjonene ('analyseinnstillinger) i hovedvinduet.",
		  (char *) "The standard deviation of the measurement noise, sigma,\n"
		  "represents how much the discharge measurements can deviate from the\n"
		  "rating curve because of measurement noise (random errors due to\n"
		  "instrumentation, instrument, reading, calibration, estimation etc.).\n"
		  "The standard deviation is technically the square root of the average\n"
		  "square deviation between measurement and average (which should be the\n"
		  "rating curve in our case). Sigma is a parameter that forms part of the\n"
		  "estimation of the rating curve, and is the standard deviation of the\n"
		  "measurement noise of discharge on the logarithmic scale. The logarithmic\n"
		  "scale is used because the the higher the discharge the larger the expected\n"
		  "deviations (thus relative measurement errors) and because negative\n"
		  "measurement are assumed to be impossible. It is assumed that the\n"
		  "measurement nosie on the log-scale is normally distributed. The normal\n"
		  "distribution has 68.3%% probability within +/sigma (the standard deviation)\n"
		  "and 95%% probability within 95%% probability. On the discharge scale\n"
		  "this means 68.3%% probability within /*exp(sigma) of the curve and\n"
		  "95%% probability within */exp(1.96*sigma) of the curve. For small values\n"
		  "of sigma, this will approximately mean */(1+sigma) with 68.3%% probability\n"
		  "and */(1+1.96*sigma) with 95%% probability. Thus, sigma can be viewed as\n"
		  "the relative measurement error, so that sigma=0.05 means approximately\n"
		  "5%% relative measurement error (more accurately, 5.13%% relative "
		  "measurement error).\n"
		  "\n"
		  "Note that the standard deviation of the measurement noise (sigma) is\n"
		  "assigned to discharge measurements of average quality. For measurements\n"
		  "marked as 'good' or 'bad, it is assumed that the measurement noise is\n"
		  "proportional to that of average measurements, with proportionality\n"
		  "constants that can be set by the user. Default, which is used if the user\n"
		  "do not set these, is 0.5 for 'good' measurements and 2.0 for 'bad'\n"
		  "measurements. Thus, if the relative measurement error is 5%% for average\n"
		  "measurements, it is 2.5%% for 'good' measurements and 10%% for 'bad'\n"
		  "measurements. The proportionality constant for 'good' and 'bad'\n"
		  "can be set by going to the options ('change analysis settings') in\n"
		  "the main window."));
      break;
    case SRSH_PROB_SEG:
      strcpy(infostr,
	     WHAT((char *) "Det dreier seg her om antall segmenter innenfor m�le-omr�det\n"
		  "(intervallet fra minste til st�rste vannstand i m�lingene).\n"
		  "Se for�vrig hjelpeteksten til segmenterings-vannstander for mer om\n"
		  "segmentskiller.\n"
		  "\n"
		  "Det er ikke er gitt p� forh�nd hvor mange segmenter man har, men i stedet"
		  "avgj�res dette p� bakgrunn av m�linger i kombinasjon med hydraulisk\n"
		  "innsikt. Den hydrauliske innsikten, som kommer fra kjennskap til "
		  "elveprofilen, kan tilsi at det sannsynligvis skjer et segmentskille\n"
		  "alts� en plass inne i m�leomr�det. Hvor p� vannstands-skalaen disse\n"
		  "segmentskillene er et separat sp�rsm�l som settes i opsjonene for \n"
		  "segmenterings-vannstand. Her settes i stedet sannsynligheten for antall\n"
		  "segmenter. Merk at f�r man i det hele tatt kan sette f�rkunnskap om\n"
		  "antall segmenter, m� antall segmenter avgrenses, noe som gj�res i\n"
		  "pre-vinduet til f�rkunnskapen. Normalt er antall segmenter begrenset til\n"
		  "3, men det er mulig � sette det ned til 2 eller opp til 4 eller mer.\n"
		  "Settes grensen opp, blir det ogs� flere sannsynligheter � spesifiser\n"
		  "her, hvis man har hydraulisk innsikt som kan brukes til dette, og analyse-\n"
		  "tiden vil g� opp betraktelig.\n"
		  "\n"
		  "N�r man beveger seg ut over m�legrunnlaget til kurven, benyttes en\n"
		  "annen metode for � angi muligheten og sannsynligheten for ytterligere\n"
		  "segmenteringer, nemlig det som kalles prosess-modellen. Her forestiller\n"
		  "man seg en segmenterings-prosess som tilfeldig str�r segmenteringer ut\n"
		  "over vannstands-skalaen. Hvor intensivt segmentetene utenfor\n"
		  "m�legrunnlages str�s kommer an p� hvor intensivt segmentene str�s inne\n"
		  "i m�legrunnlaget, m.a.o. det som kommer ut av analysen hva ang�r\n"
		  "sannsynligheten�for antall segmenter innenfor m�legrunnlaget. Dette igjen\n"
		  "kommer da fra data og f�r-kunnskapen om antall segmenter, som settes her.\n"
		  "\n"
		  "Hvis sannsynligheten for antall segmenter ikke settes av brukeren, gis\n"
		  "hver mulighet lik sannsynlighet. Hvis default avgrensing av antall\n"
		  "segmenter brukes, nemlig 1-3, vil da 33.3333...%% sannsynlighet gis\n"
		  "til hver 'modell', alts� hver mulig antall segmenter i m�leomr�det.\n"
		  "Bayesiansk analyse har \"Occham's razor\" innebygd, d.v.s. at hvis\n"
		  "det ikke er noe som eksplisitt tilsier ekstra segmenter, er det den\n"
		  "enkleste modellen som for st�rst � posteriori-sannsynlighet (alts� bare\n"
		  "ett segment).",
		  (char *) "This concerns the number of segments *within* the measurement\n"
		  "interval, i.e. the interval between the smallest and largest stage value\n"
		  "in the measurement set. See also the help text for segmentation stage\n"
		  "for more on segmentations.\n"
		  "\n"
		  "It is assumed that the number of segments is not known in advance, but\n"
		  "is instead inferred from the data and the hydraulic prior knowledge.\n"
		  "the hydraulic insight, which comes form knowing the river profile, can\n"
		  "be used for setting the probability for the number of segments within\n"
		  "the measurement interval. Where on the stage scale the these segmentations\n"
		  "take place is a separate question and can be assigned prior knowledge\n"
		  "in the frame for segmentation stage elsewhere in the prior window.\n"
		  "here, you can set the probability for the number of segments. But note\n"
		  "that before prior knowledge about the number of segments is given, the\n"
		  "possible range of the number of segments must be given in the pre-window\n"
		  "for the prior knowledge. Per default, 1-3 segments are considered possible,\n"
		  "but this can be adjusted so that the upper limit is set down to 2 or up to\n"
		  "4 or more. Note that if you set the upper limit up, there is more\n"
		  "probabilities to be set here and the analysis time can increase\n"
		  "considerably.\n"
		  "\n"
		  "When one moves outside the measurement interval, then another methods\n"
		  "is used for encoding the possibility of new segments, namely the\n"
		  "\"process model\". This model assumes that there is a process that\n"
		  "scatters segmentation points on the stage scale. How intensively\n"
		  "these segmentation points are scattered outisde the measurement interval\n"
		  "is determined by how intensively the segmentation points are scattered\n"
		  "within the measurement interval, i.e. that which comes out of the analysis\n"
		  "concerning the probability for the number of segments within the\n"
		  "measurement interval. This is again determined by the data and the\n"
		  "prior knowledge concerning the number of segments, which is set here.\n"
		  "\n"
		  "When the probabilities for the number of segments are not set by the\n"
		  "user, each possibility is given an equal probability. So if the default\n"
		  "limitation for the number of segments, 1-3, is used, then there will be\n"
		  "a 33.3333...%% probability for each 'model', i.e. each possible number\n"
		  "of segments within the measurement interval. Bayesian analysis has\n"
		  "\"Occham's razor\" built into it, which means that if there is nothing\n"
		  "in the measurements can suggest a segmentation, then the simplest model\n"
		  "(number of segments=1) is assigned the largest posterior probability."));
      break;
    default:
      strcpy(infostr,"???");
      break;
    }

  info.build(mainwin::toplevel, 
	     WHAT((char *) "Opplysning:", (char *) "Information:"),
	     infostr);

  delete [] infostr;
}



void segmented_rcurve_showpriors::set_lognormal_h0_state(bool state, int numseg, int seg)
{
  if(state)
    h0sep_h0_maxf[numseg-1][seg-1].Map();
  else
    h0sep_h0_maxf[numseg-1][seg-1].Unmap();
}

void segmented_rcurve_showpriors::set_lognormal_h01_state(bool state)
{
  if(state)
    h01_maxf.Map();
  else
    h01_maxf.Unmap();
}

void segmented_rcurve_showpriors::init_windows(void)
{
  problab=NULL;
  probf=NULL;
  linsepfr=NULL;
  linsepv=NULL;
  linseph=NULL;
  linsep_lab=NULL;
  linsep_a_startf=linsep_a_endf=NULL;
  linsep_b_startf=linsep_b_endf=NULL;
  linsep_corrf=NULL;
  h0sepfr=NULL;
  h0sepv=NULL;
  h0sep_lab=NULL;
  h0seph=NULL;
  h0sep_h0_startf=h0sep_h0_endf=h0sep_h0_maxf=NULL;
  h0sep_lognormal_tog=NULL;
  hssepfr=NULL;
  hssepv1=NULL;
  hssep_lab=NULL;
  hsseph=NULL;
  hssep_hs_startf=hssep_hs_endf=NULL;
  exp_label=const_lab=const_lab2=corr_lab=NULL;
  hssh_built=linsh_built=probsh_built=h0sh_built=false;
}

void segmented_rcurve_showpriors::cleanup_windows(void)
{
  if(problab)
    delete [] problab;
  if(probf)
    delete [] probf;
  if(linsepfr)
    delete [] linsepfr;
  if(linsepv)
    delete [] linsepv;
  if(linsep_lab)
    delete [] linsep_lab;
  doubledelete(linseph, max_num_seg);
  if(linsep_a_startf)
    delete [] linsep_a_startf;
  if(linsep_a_endf)
    delete [] linsep_a_endf;
  doubledelete(linsep_b_startf, max_num_seg);
  doubledelete(linsep_b_endf, max_num_seg);
  if(linsep_corrf)
    delete [] linsep_corrf;
  if(h0sepfr)
    delete [] h0sepfr;
  if(h0sepv)
    delete [] h0sepv;
  if(h0sep_lab)
    delete [] h0sep_lab;
  doubledelete(h0seph, max_num_seg);
  doubledelete(h0sep_h0_startf, max_num_seg);
  doubledelete(h0sep_h0_endf, max_num_seg);
  doubledelete(h0sep_h0_maxf, max_num_seg);
  doubledelete(h0sep_lognormal_tog, max_num_seg);
  if(hssepfr)
    delete [] hssepfr;
  if(hssepv1)
    delete [] hssepv1;
  if(hssep_lab)
    delete [] hssep_lab;
  doubledelete(hsseph, max_num_seg-1);
  doubledelete(hssep_hs_startf, max_num_seg-1);
  doubledelete(hssep_hs_endf, max_num_seg-1);
  if(exp_label)
    delete exp_label;
  if(const_lab)
    delete const_lab;
  if(const_lab2)
    delete const_lab2;
  if(corr_lab)
    delete corr_lab;

  init_windows();
}

// Check if something that must be positive actually is, show
// error message and return 'false if not:
bool segmented_rcurve_showpriors::check_positive(double value, 
						 char *parameter_name,
						 bool allow_zero,
						 int numseg, int seg,
						 shell *err_parent)
{
  shell *dparent = (err_parent==NULL ? ((shell *) this) : err_parent);
  
  char prestr[1000]="";
  if(numseg>0 && seg>0)
    {
      sprintf(prestr, 
	      WHAT((char *) "For modell med %d segmenter, segment %d: ",
		   (char *) "For model with %d segments, segment %d: "),
	      numseg, seg);
    }
  else if(numseg>0)
    {
      sprintf(prestr, 
	      WHAT((char *) "For modell med %d segmenter: ",
		   (char *) "For model with %d segments: "),
	      numseg);
    }

  if(value<0.0)
    {
      char errstr[1000];
      sprintf(errstr, 
	      WHAT((char *) "%s%s satt til %f, men kan ikke v�re negativ!", 
		   (char *) "%s%s satt til %f, but cannot be negative!"), 
	      prestr, parameter_name, value);
      err.build(*dparent, WHAT((char *) "Feil", (char *) "Error"),
		errstr);
      return false;
    }
  if(value==0.0 && !allow_zero)
    {
      char errstr[1000];
      sprintf(errstr, 
	      WHAT((char *) "%s%s kan ikke v�re eksakt null!", 
		   (char *) "%s%s cannot be exactly zero!"), 
	      prestr, parameter_name);
      err.build(*dparent, WHAT((char *) "Feil", (char *) "Error"),
		errstr);
      return false;
    }

  return true;
}

// Checks if upper/lower limits of 95% prior credibility interval
// makes sense, returns 'true' is so and 'false' if not. Also
// shows error/warning dialogs and if warning, asks the user whether
// he/she will continue.
bool segmented_rcurve_showpriors::
check_95_credibility_interval(double upper, double lower,
			      char *parameter_name,
			      int numseg, int seg,
			      shell *err_parent,
			      bool check_uncertainty_reasonable,
			      double slightly_unreasonable_uncert,
			      char *slightly_unreasonable_unit,
			      double very_unreasonable_uncert,
			      char *very_unreasonable_unit)
{
  shell *dparent = (err_parent==NULL ? ((shell *) this) : err_parent);
  
  char prestr[1000]="";
  if(numseg>0 && seg>0)
    {
      sprintf(prestr, 
	      WHAT((char *) "For modell med %d segmenter, segment %d: ",
		   (char *) "For model with %d segments, segment %d: "),
	      numseg, seg);
    }
  else if(numseg>0)
    {
      sprintf(prestr, 
	      WHAT((char *) "For modell med %d segmenter: ",
		   (char *) "For model with %d segments: "),
	      numseg);
    }

  if(upper<lower)
    {
      char errstr[1000];
      sprintf(errstr, 
	      WHAT((char *) "%s�vre avgrensing av 95%%%%-intervall for %s=%f er "
		   "mindre enn nedre avgrensing=%f!", 
		   (char *) "%sUpper limit of 95%%%% interval for %s=%f is less "
		   "than lower limit=%f!"), 
	      prestr, parameter_name, upper, lower);
      err.build(*dparent, WHAT((char *) "Feil", (char *) "Error"),
		errstr);
      return false;
    }
  else if(upper==lower)
    {
      char errstr[1000];
      sprintf(errstr, 
	      WHAT((char *) "%s�vre avgrensing av 95%%%%-intervall for %s er lik "
		   "nedre avgrensning(=%f)!", 
		   (char *) "%sUpper limit of 95%%%% interval for %s is equal to "
		   "lower limit(=%f)!"), 
	      prestr, parameter_name, upper);
      err.build(*dparent, WHAT((char *) "Feil", (char *) "Error"),
		errstr);
      return false;
    }
  else if(check_uncertainty_reasonable && upper<=lower+very_unreasonable_uncert)
    {
      char unitstr[1000];
      if(very_unreasonable_unit)
	strcpy(unitstr, very_unreasonable_unit);
      else 
	sprintf(unitstr, "%6.4f", 
		very_unreasonable_uncert);

      char warnstr[1000];
      sprintf(warnstr, 
	      WHAT((char *) "%s�vre avgrensning av 95%%%%-intervall for %s=%f "
		   "er mindre enn (eller lik) %s over nedre avgrensning=%f!\n"
		   "En slik presisjon kan da ikke v�re reell, "
		   "kan den?\nBeholde eller revurdere?",
		   (char *) "%sUpper limit of 95%%%% interval for %s=%f "
		   "is less than (or equal to) %s above lower limit=%f!\n"
		   "That precision cannot be real, can it?"
		   "Keep or adjust?"), 
	      prestr,parameter_name, upper, unitstr, lower);
      warn.build(*dparent, WHAT((char *) "Advarsel", (char *) "Warning"),
		 warnstr);
      return(warn.ok_or_cancel(WHAT((char *) "Beholde", (char *) "Keep"),
			    WHAT((char *) "Revurder", (char *) "Adjust")));
    }
  else if(check_uncertainty_reasonable && 
	  upper<=lower+slightly_unreasonable_uncert)
    {
      char unitstr[1000];
      if(slightly_unreasonable_unit)
	strcpy(unitstr, slightly_unreasonable_unit);
      else 
	sprintf(unitstr, "%6.4f", 
		slightly_unreasonable_uncert);

      char warnstr[1000];
      sprintf(warnstr, 
	      WHAT((char *) "%s�vre avgrensning av 95%%%%-intervall "
		   "for %s=%f er "
		   "mindre enn (eller lik) %s over nedre avgrensning=%f!\n"
		   "Har du virkelig en slik presisjon i "
		   "f�rkunnskapen?\nBeholde eller revurdere?",
		   (char *) "%sUpper limit of 95%%%% interval for %s=%f is "
		   "less than (or equal to) %s above lower limit=%f!\n"
		   "Do you really have that kind of precision?"
		   "Keep or adjust?"),
	      prestr, parameter_name, upper, unitstr, lower);
      warn.build(*dparent, WHAT((char *) "Advarsel", (char *) "Warning"),
		 warnstr);
      return(warn.ok_or_cancel(WHAT((char *) "Beholde", (char *) "Keep"),
			       WHAT((char *) "Revurder", (char *) "Adjust")));
    }
  
  return true;
}


void segmented_rcurve_showpriors::start_detailed_prob(void)
{
  if(!problab)
    {
      int i;
      
      problab=new label[max_num_seg];
      probf=new honlydigit[max_num_seg];
      
      probsh.build(*this,
         WHAT((char *) "Detaljert setting av segment-sannsynligheter",
	      (char *) "Detailed editing of segment probabilities"));
      probv1.build(probsh);
      for(i=0;i<(min_num_seg-1);i++)
	problab[i].build(probv1, 
          WHAT((char *) "Modell med %d segment har null sannsynlighet", 
	       (char *) "Model with %d segments has zero probability"), i+1); 
      for(i=(min_num_seg-1);i<max_num_seg;i++)
	{
	  char title[100];
	  sprintf(title, 
		  WHAT((char *) "Modell med %d segmenter har sannsynlighet:", 
		       (char *) "Model with %d segments has probability:"), 
		  i+1);
	  probf[i].build(probv1, 10, title);
	  probf[i].SetDouble(get_probability_of_model(i+1),3);
	}
      
      probsep.build(probv1);
      probh1.build(probv1);
      
      accept_probb.Create(probh1, "OK", SEG_INT_PROB_OK, this);
      accept_probb.Background("green");
      accept_probb.Foreground("black");
      
      cancel_probb.Create(probh1, WHAT((char *) "Avbryt", (char *) "Cancel"), 
			  SEG_INT_PROB_CANCEL, this);
      cancel_probb.Background("red");
      cancel_probb.Foreground("white");
      
      probsh_built=true;
    }
  
  probsh.Map();
}

void segmented_rcurve_showpriors::start_detailed_lin(void)
{
  copy_buffer_parameters_to_linear();

  int i,j;

  if(!linsh_built)
    {
      // make GUI arrays:
      linsepfr=new frame[max_num_seg];
      linsepv=new vrow[max_num_seg];
      linsep_lab=new label[max_num_seg];
      linseph=new hrow*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	linseph[i]=new hrow[3+i];
      linsep_a_startf=new honlydigit[max_num_seg];
      linsep_a_endf=new honlydigit[max_num_seg];
      linsep_b_startf=new honlydigit*[max_num_seg];
      linsep_b_endf=new honlydigit*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  linsep_b_startf[i]=new honlydigit[i+1];
	  linsep_b_endf[i]=new honlydigit[i+1];
	}
      linsep_corrf=new honlydigit[max_num_seg];

      linsh.build(*this,
         WHAT((char *) "Detaljert setting av line�re parametre",
	      (char *) "Detailed editing of linear parameters"));
      linv1.build(linsh);
      linsc.build(linv1);
      linsc.Height(500);
      linsc.Width(800);
      linscv1.build(linsc);
      for(i=0;i<max_num_seg;i++)
	{
	  linsepfr[i].build(linscv1);
	  linsepv[i].build(linsepfr[i]);
	  linsep_lab[i].build(linsepv[i],
			      WHAT((char *) "Modell med %d segmenter:",
				   (char *) "Model with %d segments:"), i+1);
	  linsep_lab[i].Background("white");
	  linseph[i][0].build(linsepv[i]);
	  linsep_a_startf[i].build(linseph[i][0], 10,
              WHAT((char *) "Det er 95%% sanns. for at "
		   "konstantleddet til det f�rste segmentet "
		   "er i f�lgende omr�de:", 
		   (char *) "It's 95%% prob. that the constant in "
		   "the first segment is in the following interval:"));
	  linsep_a_endf[i].build(linseph[i][0], 10, " - ");
	  
	  for(j=0;j<(i+1);j++)
	    {
	      linseph[i][j+1].build(linsepv[i]);
	      char title[1000];
	      sprintf(title, WHAT((char *) "Det er 95%%%% sanns. for at "
				  "eksponent nr. %d er i f�lgende omr�de:", 
				  (char *) "It's 95%%%% prob. that exponent "
				  "number %d is in the following interval:"), 
		      j+1);
	      linsep_b_startf[i][j].build(linseph[i][j+1], 10, title);
	      linsep_b_endf[i][j].build(linseph[i][j+1], 10, " - ");
	    }
	  
	  linseph[i][i+2].build(linsepv[i]);
	  linsep_corrf[i].build(linseph[i][i+2], 10,
             WHAT(( char *) "Korrelasjon mellom konstantledd og eksponenter:", 
		  (char *) "Correlation between constant and exponents:"));
	}
      
      linsep.build(linv1);
      linh1.build(linv1);
      
      accept_linb.Create(linh1, "OK", SEG_INT_LIN_OK, this);
      accept_linb.Background("green");
      accept_linb.Foreground("black");
      
      cancel_linb.Create(linh1, WHAT((char *) "Avbryt", (char *) "Cancel"), 
			  SEG_INT_LIN_CANCEL, this);
      cancel_linb.Background("red");
      cancel_linb.Foreground("white");

      linsh_built=true;
    }
  
  for(i=0;i<max_num_seg;i++)
    {
      linsep_a_startf[i].SetDouble(exp(get_a_mu(i+1)-1.96*
				       get_a_sd(i+1)),4);
      linsep_a_endf[i].SetDouble(exp(get_a_mu(i+1)+1.96*
				     get_a_sd(i+1)),4);
	  
      for(j=0;j<(i+1);j++)
	{
	  linsep_b_startf[i][j].SetDouble(get_b_mu(i+1,j+1)-1.96*
					  get_b_sd(i+1,j+1),4);
	  linsep_b_endf[i][j].SetDouble(get_b_mu(i+1,j+1)+1.96*
					get_b_sd(i+1,j+1),4);
	}
      
      linsep_corrf[i].SetDouble(get_cor(i+1),4);
    } 
  
  linsh.Map();
}

void segmented_rcurve_showpriors::start_detailed_h0(void)
{
  copy_buffer_parameters_to_h0();

  int i,j;

  if(!h0sh_built)
    {
      // make GUI arrays:
      h0sepfr=new frame[max_num_seg];
      h0sepv=new vrow[max_num_seg];
      h0sep_lab=new label[max_num_seg];
      h0seph=new hrow*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	h0seph[i]=new hrow[i+1];
      h0sep_h0_startf=new honlydigit*[max_num_seg];
      h0sep_h0_endf=new honlydigit*[max_num_seg];
      h0sep_lognormal_tog=new h0sep_lognormal_toggle*[max_num_seg];
      h0sep_h0_maxf=new honlydigit*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  h0sep_h0_startf[i]=new honlydigit[i+1];
	  h0sep_h0_endf[i]=new honlydigit[i+1];
	  h0sep_h0_maxf[i]=new honlydigit[i+1];
	  h0sep_lognormal_tog[i]=new h0sep_lognormal_toggle[i+1];
	}
      
      h0sh.build(*this,
         WHAT((char *) "Detaljert setting av h0-parametre",
	      (char *) "Detailed editing of h0 parameters"));
      h0v1.build(h0sh);
      h0sc.build(h0v1);
      h0sc.Height(500);
      h0sc.Width(800);
      h0scv1.build(h0sc);
      for(i=0;i<max_num_seg;i++)
	{
	  h0sepfr[i].build(h0scv1);
	  h0sepv[i].build(h0sepfr[i]);
	  h0sep_lab[i].build(h0sepv[i],
			      WHAT((char *) "Modell med %d segmenter:",
				   (char *) "Model with %d segments:"), i+1);
	  h0sep_lab[i].Background("white");
	  
	  for(j=0;j<(i+1);j++)
	    {
	      h0seph[i][j].build(h0sepv[i]);
	      char title[1000];
	      sprintf(title, 
		      WHAT((char *) "Det er 95%%%% sanns. for at "
			   "h0 nr. %d er i f�lgende omr�de:", 
			   (char *) "It's 95%%%% prob. that h0 number %d "
			   "is in the following interval:"), j+1);
	      h0sep_h0_startf[i][j].build(h0seph[i][j], 10, title);
	      h0sep_h0_endf[i][j].build(h0seph[i][j], 10, " - ");
	      h0sep_lognormal_tog[i][j].Create(h0seph[i][j],this,i+1,j+1,
					       (lognormal_h0 && 
						lognormal_h0[i]) ? 
					       (bool) lognormal_h0[i][j] : 
					       False);
	      h0sep_h0_maxf[i][j].build(h0seph[i][j], 10, "Max:");

	      if(lognormal_h0 && lognormal_h0[i] && lognormal_h0[i][j])
		{
		  h0sep_h0_maxf[i][j].Map();
		}
	      else
		{
		  h0sep_h0_maxf[i][j].Unmap();
		}

	    }
	}
      
      h0sep.build(h0v1);
      h0h1.build(h0v1);
      
      accept_h0b.Create(h0h1, "OK", SEG_INT_H0_OK, this);
      accept_h0b.Background("green");
      accept_h0b.Foreground("black");
      
      cancel_h0b.Create(h0h1, WHAT((char *) "Avbryt", (char *) "Cancel"), 
			  SEG_INT_H0_CANCEL, this);
      cancel_h0b.Background("red");
      cancel_h0b.Foreground("white");

      h0sh_built=true;
    }

  for(i=0;i<max_num_seg;i++)
    for(j=0;j<(i+1);j++)
      {	
	if(lognormal_h0 && lognormal_h0[i] && lognormal_h0[i][j])
	  h0sep_lognormal_tog[i][j].ToggleButtonOn();

	if(max_h0 && max_h0[i] && max_h0[i][j]!=MISSING_VALUE)
	  {
	    h0sep_h0_maxf[i][j].SetDouble(max_h0[i][j],4);
	    
	    if(get_h0_mu(i+1,j+1)!=MISSING_VALUE)
	      {
		double mu=get_h0_mu(i+1,j+1);
		double sd=get_h0_sd(i+1,j+1);
		double max=max_h0[i][j];
		
		h0sep_h0_startf[i][j].SetDouble(max-exp(mu+1.96*sd),
						4);
		h0sep_h0_endf[i][j].SetDouble(max-exp(mu-1.96*sd),4);
	      }
	  }
	
	if(get_h0_mu(i+1,j+1)!=MISSING_VALUE)
	  {
	    h0sep_h0_startf[i][j].SetDouble(get_h0_mu(i+1,j+1)-1.96*
					    get_h0_sd(i+1,j+1),4);
	    h0sep_h0_endf[i][j].SetDouble(get_h0_mu(i+1,j+1)+1.96*
					  get_h0_sd(i+1,j+1),4);
	  }
	else if(get_h01_mu()!=MISSING_VALUE && get_h01_sd()!=MISSING_VALUE)
	  {
	    h0sep_h0_startf[i][j].
	      SetDouble(get_h01_mu()-1.96*get_h01_sd(),4);
	    h0sep_h0_endf[i][j].
	      SetDouble(get_h01_mu()+1.96*get_h01_sd(),4);
	  }
      }
  
  h0sh.Map();
}

void segmented_rcurve_showpriors::start_detailed_hs(void)
{
  copy_buffer_parameters_to_hs();

  int i,j;

  if(!hssepfr)
    {
      // make GUI arrays:
      hssepfr=new frame[max_num_seg];
      hssepv1=new vrow[max_num_seg];
      hssep_lab=new label[max_num_seg];
      hsseph=new hrow*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	hsseph[i]=new hrow[i+1];
      hssep_hs_startf=new honlydigit*[max_num_seg];
      hssep_hs_endf=new honlydigit*[max_num_seg];
      for(i=0;i<max_num_seg;i++)
	{
	  hssep_hs_startf[i]=new honlydigit[i+1];
	  hssep_hs_endf[i]=new honlydigit[i+1];
	}
      
      hssh.build(*this,
         WHAT((char *) "Detaljert setting av hs-parametre",
	      (char *) "Detailed editing of hs parameters"));
      hsv1.build(hssh);
      hssc.build(hsv1);
      hssc.Height(500);
      hssc.Width(800);
      hsscv1.build(hssc);
      for(i=1;i<max_num_seg;i++)
	{
	  hssepfr[i].build(hsscv1);
	  hssepv1[i].build(hssepfr[i]);
	  hssep_lab[i].build(hssepv1[i],
			      WHAT((char *) "Modell med %d segmenter:",
				   (char *) "Model with %d segments:"), i+1);
	  hssep_lab[i].Background("white");
	  
	  for(j=0;j<i;j++)
	    {
	      hsseph[i][j].build(hssepv1[i]);
	      char title[1000];
	      sprintf(title, 
		      WHAT((char *) "Det er 95%%%% sanns. for at "
			   "hs nr. %d er i f�lgende omr�de:", 
			   (char *) "It's 95%%%% prob. that hs number %d "
			   "is in the following interval:"), j+1);
	      hssep_hs_startf[i][j].build(hsseph[i][j], 10, title);
	      hssep_hs_endf[i][j].build(hsseph[i][j], 10, " - ");
	    }
	}
      
      hssep.build(hsv1);
      hsh1.build(hsv1);
      
      accept_hsb.Create(hsh1, "OK", SEG_INT_HS_OK, this);
      accept_hsb.Background("green");
      accept_hsb.Foreground("black");
      
      cancel_hsb.Create(hsh1, WHAT((char *) "Avbryt", (char *) "Cancel"), 
			  SEG_INT_HS_CANCEL, this);
      cancel_hsb.Background("red");
      cancel_hsb.Foreground("white");
      
      hssh_built=true;
    }

  for(i=1;i<max_num_seg;i++)
    for(j=0;j<i;j++)
      {
	if(get_hs_mu(i+1,j+1)!=MISSING_VALUE)
	  {
	    hssep_hs_startf[i][j].SetDouble(get_hs_mu(i+1,j+1)-1.96*
					    get_hs_sd(i+1,j+1),4);
	    hssep_hs_endf[i][j].SetDouble(get_hs_mu(i+1,j+1)+1.96*
					  get_hs_sd(i+1,j+1),4);
	  }
	else
	  {
	    hssep_hs_startf[i][j].
	      SetDouble(0.0,4);
	    hssep_hs_endf[i][j].
	      SetDouble(0.0,4);
	  }
      }
  
  hssh.Map();
}


void segmented_rcurve_showpriors::prob_ok(void)
{
  double *probs=new double[max_num_seg];
  for(int i=0;i<max_num_seg;i++)
    {
      if((i+1)<min_num_seg)
	probs[i]=0.0;
      else
	{
	  probs[i]=probf[i].getdouble();
	  if(!check_positive(probs[i], 
			     WHAT((char *) "modell-sannsynlighet",
				  (char *) "model probability"), true, i+1))
	    {
	      delete [] probs;
	      return;
	    }
	}
    }
  
  set_model_probabilities(probs);
  
  delete [] probs;
  
  if(probsh_built)
    probsh.Unmap();
}

void segmented_rcurve_showpriors::prob_cancel(void)
{
  if(probsh_built)
    probsh.Unmap();
}
		     


void segmented_rcurve_showpriors::h0_ok(void)
{
  double **new_h0_mu=new double*[max_num_seg];
  double **new_h0_sd=new double*[max_num_seg];
  double **new_h0_max=new double*[max_num_seg];
  bool **new_lognormal_h0=new bool*[max_num_seg];
  int i,j;

  for(i=0;i<max_num_seg;i++)
    {
      new_h0_mu[i]=new double[i+1];
      new_h0_sd[i]=new double[i+1];
      new_h0_max[i]=new double[i+1];
      new_lognormal_h0[i]=new bool[i+1];
	
      for(j=0;j<(i+1);j++)
	{
	  double h0s=h0sep_h0_startf[i][j].getdouble();
	  double h0e=h0sep_h0_endf[i][j].getdouble();
	
	  if(!check_95_credibility_interval(h0e, h0s, "h0", i+1, j+1, &h0sh, 
					    true, 0.01, 
					    WHAT((char *) "en cm", 
						 (char *) "one cm"),
					    0.001, 
					    WHAT((char *) "en mm", 
						 (char *) "one mm")))
	    return;

	  if(h0sep_lognormal_tog[i][j]())
	    {
	      new_lognormal_h0[i][j]=true;
	      double max=h0sep_h0_maxf[i][j].getdouble();
	      new_h0_mu[i][j]=(log(max-h0s)+log(max-h0e))/2.0;
	      new_h0_sd[i][j]=(log(max-h0s)-log(max-h0e))/2.0/1.96;
	      new_h0_max[i][j]=max;

	      if(max<h0e)
		{
		  char errstr[1000];
		  sprintf(errstr, 
			  WHAT((char *) "For modell med %d segmenter, "
			       "segment %d: maksimum=%f er mindre enn "
			       "�vre 95%%-intervall-avgrensing=%f!", 
			       (char *) "For model with %d segments, "
			       "segment %d: maximun=%f is less than upper "
			       "95%% limit=%f!"), 
			  i+1, j+1, max, h0e);
		  err.build(h0sh, WHAT((char *) "Feil", (char *) "Error"),
			    errstr);
		  return;
		}
	      else if(max==h0e)
		{
		  char errstr[1000];
		  sprintf(errstr, 
			  WHAT((char *) "For modell med %d segmenter, "
			       "segment %d: maksimum for h0 er lik �vre "
			       "avgrensning av 95%%-intervall "
			       "for h0(=%f)!", 
			       (char *) "For model with %d segments, "
			       "segment %d: maximum for h0 is equal to "
			       "upper limit of 95%% interval(=%f)!"), 
			  i+1, j+1, max);
		  err.build(h0sh, WHAT((char *) "Feil", (char *) "Error"),
			    errstr);
		  return;
		}
	    }
	  else
	    {
	      new_lognormal_h0[i][j]=false;
	      new_h0_max[i][j]=MISSING_VALUE;
	      new_h0_mu[i][j]=(h0e+h0s)/2.0;
	      new_h0_sd[i][j]=(h0e-h0s)/2.0/1.96;
	    }
	}
    }

  set_h0_detailed(new_h0_mu, new_h0_sd, new_lognormal_h0, new_h0_max);
  
  doubledelete(new_h0_mu, max_num_seg);
  doubledelete(new_h0_sd, max_num_seg);
  doubledelete(new_h0_max, max_num_seg);
  doubledelete(new_lognormal_h0, max_num_seg);

  h0sh.Unmap();
}

void segmented_rcurve_showpriors::h0_cancel(void)
{
  if(h0sh_built)
    h0sh.Unmap();
  detailed_h0_tog.switch_off();
  set_h0_back_to_simple();
}

void segmented_rcurve_showpriors::hs_ok(void)
{
  double **new_hs_mu=new double*[max_num_seg];
  double **new_hs_sd=new double*[max_num_seg];
  int i,j;

  for(i=0;i<max_num_seg;i++)
    {
      new_hs_mu[i]=new double[i+1];
      new_hs_sd[i]=new double[i+1];

      for(j=0;j<i;j++)
	{
	  double hss=hssep_hs_startf[i][j].getdouble();
	  double hse=hssep_hs_endf[i][j].getdouble();
	  
	  if(!check_95_credibility_interval(hse, hss, "h0", i+1, j+1, &hssh, 
					    true, 0.01, 
					    WHAT((char *) "en cm", 
						 (char *) "one cm"),
					    0.001, 
					    WHAT((char *) "en mm", 
						 (char *) "one mm")))
	    return;

	  new_hs_mu[i][j]=(hse+hss)/2.0;
	  new_hs_sd[i][j]=(hse-hss)/2.0/1.96;

	  if((hss==0.0 && hse==0.0) || hss==MISSING_VALUE || hse==MISSING_VALUE)
	    {
	      char errstr[1000];
	      sprintf(errstr, 
		      WHAT((char *) "For %d segments modell, segment nr %d \n"
			   "mangler minimums/maksimums-grenser. Dette kan \n"
			   "f�re til feil i videre kj�ring. \n"
			   "Detaljert setting av segmentering m� gj�res om "
			   "igjen.", 
			   (char *) "For a %d segment model, segment number "
			   "%d the \nminimum/maximum limits are missing. "
			   "This can \ncause an error in the analysis.\n"
			   "Set the detailed segmentation once more."),
		      i+1, j+1);
	      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
			 errstr);  
	      return;
	    }
	  else
	    {
	      if(j>0 && new_hs_mu[i][j-1]>new_hs_mu[i][j])
		{
		  char warnstr[1000];
		  sprintf(warnstr,
			  WHAT((char *) "For %d segments modell, "
			       "ligger gjennomsnitts-\n"
			       "segmenteringen (av minimumsgrenser og "
			       "maksimumsgrense)\n "
			       "for segment %d over den til segment %d. "
			       "Dette kan \n"
			       "f�re til problemer i analysen. Muligens "
			       "b�r en \n"
			       "detaljert setting av segmentering gj�res "
			       "om igjen.", 
			       (char *) "For a %d segment model, the "
			       "average segmentation \n"
			       "(from minimum and maximum limit) is "
			       "higher for segment \n"
			       "%d than for segment %d. This can \n"
			       "cause problems in the analysis. It's "
			       "possible that you \n"
			       "should set the detailed segmentation "
			       "once more."),
			  i+1, j, j+1);
		  message2.build(*this, 
				 WHAT((char *) "Mulig feil", 
				      (char *) "Possible error"),
				 warnstr);
		  if(!message2.ok_or_cancel(WHAT((char *) "Fortsett", 
						 (char *) "Continue"),
					    WHAT((char *) "Avbryt", 
						 (char *) "Cancel")))
		    return;
		}
	    }
	}
    }

  set_hs_detailed(new_hs_mu, new_hs_sd);
  
  doubledelete(new_hs_mu, max_num_seg-1);
  doubledelete(new_hs_sd, max_num_seg-1);
  
  if(hssh_built)
    hssh.Unmap();
}

void segmented_rcurve_showpriors::hs_cancel(void)
{
  if(hssh_built)
    hssh.Unmap();
  detailed_hs_tog.switch_off();
  set_hs_back_to_simple();
}

void segmented_rcurve_showpriors::lin_ok(void)
{
  double **new_b_mu=new double*[max_num_seg];
  double **new_b_sd=new double*[max_num_seg];
  double *new_a_mu=new double[max_num_seg];
  double *new_a_sd=new double[max_num_seg];
  double *new_corr=new double[max_num_seg];
  int i,j;

  for(i=0;i<max_num_seg;i++)
    {
      new_b_mu[i]=new double[i+1];
      new_b_sd[i]=new double[i+1];

      if(!check_positive(linsep_a_startf[i].getdouble(),
			 WHAT((char *) "konstant, nedre 95%%-grense", 
			      (char *) "constant, lower 95%% limit"),
			 false, i+1, -1, &linsh))
	return;
      if(!check_positive(linsep_a_endf[i].getdouble(),
			 WHAT((char *) "konstant, �vre 95%%-grense", 
			      (char *) "constant, upper 95%% limit"),
			 false, i+1, -1, &linsh))
	return;

      double as=log(linsep_a_startf[i].getdouble());
      double ae=log(linsep_a_endf[i].getdouble());

      if(!check_95_credibility_interval(exp(ae), exp(as), 
					WHAT((char *) "konstant", 
					     (char *) "constant"), 
					i+1, -1, &linsh))
	return;

      new_a_mu[i]=(ae+as)/2.0;
      new_a_sd[i]=(ae-as)/2.0/1.96;
      
      new_corr[i]=linsep_corrf[i].getdouble();
      
      if(new_corr[i] <= -1.0 || new_corr[i] >= 1.0)
	{
	  char errstr[1000];
	  sprintf(errstr, 
		  WHAT((char *) "For modell med %d segmenter, segment %d: "
		       "Korrelasjon til formparametre satt til %f!\n"
		       "Men korrelasjon m� v�re et tall ekte mellom -1 og +1.", 
		       (char *) "For model with %d segments, segment %d: "
		       "Correlation of shape parameters set to %f!\n"
		       "However, correlations need to be inside the "
		       "interval -1 to +1."), 
		  i+1, -1, new_corr[i]);
	  err.build(linsh, WHAT((char *) "Feil", (char *) "Error"),
		    errstr);
	  return;
	}

      for(j=0;j<(i+1);j++)
	{
	  if(!check_positive(linsep_b_startf[i][j].getdouble(),
			     WHAT((char *) "eksponent, nedre 95%%-grense", 
				  (char *) "exponent, lower 95%% limit"),
			     false, i+1, j+1, &linsh))
	    return;
	  if(!check_positive(linsep_b_endf[i][j].getdouble(),
			     WHAT((char *) "eksponent, �vre 95%%-grense", 
				  (char *) "exponent, upper 95%% limit"),
			     false, i+1, j+1, &linsh))
	    return;

	  double bs=linsep_b_startf[i][j].getdouble();
	  double be=linsep_b_endf[i][j].getdouble();

	  if(!check_95_credibility_interval(be, bs, WHAT((char *) "eksponent", 
							 (char *) "exponent"), 
					    i+1, j+1, &linsh))
	    return;
	     
	  new_b_mu[i][j]=(be+bs)/2.0;
	  new_b_sd[i][j]=(be-bs)/2.0/1.96;
	}
    }
  
  set_linear_parameters_detailed(new_a_mu, new_b_mu, 
				 new_a_sd, new_b_sd, 
				 new_corr);
  
  doubledelete(new_b_mu, max_num_seg);
  doubledelete(new_b_sd, max_num_seg);
  delete [] new_a_mu;
  delete [] new_a_sd;
  delete [] new_corr;

  if(linsh_built)
    linsh.Unmap();
}

void segmented_rcurve_showpriors::lin_cancel(void)
{
  if(linsh_built)
    linsh.Unmap();
  detailed_lin_tog.switch_off();
}


void segmented_rcurve_showpriors::plot_sigma(void)
{
  if(!check_positive(sigma_startf.getdouble(), 
		     WHAT((char *) "sigma, nedre 95%%-grense",
			  (char *) "sigma, lower 95%% limit"),
			  false, -1, -1))
    return;
  if(!check_positive(sigma_endf.getdouble(), 
		     WHAT((char *) "sigma, �vre 95%%-grense",
			  (char *) "sigma, upper 95%% limit"),
			  false, -1, -1))
    return;
  
  double s1=sigma_startf.getdouble(),s2=sigma_endf.getdouble();

  if(!check_95_credibility_interval(s2, s1, "sigma", -1, -1, this, false))
    return;

  double a,b;
  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=s2*2.0, step=size/double(len),sigma=step,cred;
  int axis=1;

  find_invgamma_distribution(s1*s1, s2*s2, 95.0, &a, &b, &cred);
  if(cred<94.0 || cred>96.0)
    warn.build(mainwin::toplevel, "Advarsel", 
	       "Optimering feilet. Klarte ikke � finne rette invers-gamma-"
	       "parametre som gjorde at 95% av sannsynlighetsmassen var\n"
	       "ennenfor de gitte grensene! Funnet troverdighet=%7.3f%%", 
	       cred);

  sprintf(line, WHAT((char *) "Fordeling til sigma n�r sigma^2 ~ "
		     "IG(a=%7.3f, b=%7.5g)", 
		     (char *) "Distribution of sigma when sigma^2 ~ "
		     "IG(a=%7.3f, b=%7.3g)"), a, b);
  axislab[0]=new char[10];
  strcpy(axislab[0], "sigma");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(int i=0;i<len;i++, sigma+=step)
    {
      double logf=log(2.0)+a*log(b)-gamma(a)-(2.0*a+1.0)*log(sigma)-
	b/sigma/sigma;
      
      arg[i]=sigma;
      val[i]=exp(logf);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void segmented_rcurve_showpriors::plot_prob(void)
{
  int len=max_num_seg+2;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[1000], **axislab=new char*[2];
  int axis=1;
  PLOTLINE_TYPE type=PLOTLINE_BARS;

  sprintf(line, WHAT((char *) "F�rkunnskap om antall segmenter", 
		     (char *) "Prior distribution of the number of segments"));
  axislab[0]=new char[100];
  strcpy(axislab[0], WHAT((char *) "#segmenter", (char *) "#segments"));
  axislab[1]=new char[100];
  strcpy(axislab[1], WHAT((char *) "Sanns.", (char *) "Prob"));

  for(int i=0;i<len;i++)
    {
      double pr=get_probability_of_model(i);

      if(pr<0.0)
	{
	  char errstr[1000];
	  sprintf(errstr, 
		  WHAT((char *) "Pr(seg=%d) satt til %f! "
		       "Men sannsynligheter kan ikke v�re negative!", 
		       (char *) "Pr(seg=%d) set to %f! But probabilities "
		       "cannot be negative!"), 
		  i+1,pr);
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		    errstr);
	  delete [] arg;
	  delete [] val;
	  delete [] line;
	  doubledelete(axislab,2);
	  return;
	}

      arg[i]=double(i);
      val[i]=pr;
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2, NULL, &type);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void segmented_rcurve_showpriors::plot_a(void)
{
  if(!check_positive(a_startf.getdouble(), 
		     WHAT((char *) "konstant, nedre 95%%-grense",
			  (char *) "constant, lower 95%% limit"),
			  false, -1, -1))
    return;
  if(!check_positive(a_endf.getdouble(), 
		     WHAT((char *) "konstant, �vre 95%%-grense",
			  (char *) "constant, upper 95%% limit"),
			  false, -1, -1))
    return;
  
  double a1=log(a_startf.getdouble()),a2=log(a_endf.getdouble());
  if(!check_95_credibility_interval(exp(a2), exp(a1), 
				    WHAT((char *) "konstant", 
					 (char *) "constant"), -1, -1,
				    (shell *) this, false))
    return;
  
  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=exp(a2)*2.0, step=size/double(len),C=step;
  int axis=1;

  double mu=(a1+a2)/2.0;
  double sd=(a2-a1)/2.0/1.96;

  sprintf(line, WHAT((char *) "Fordeling til konstant (til f�rste "
		     "segment) C = e^a ~ lognormal(mu=%7.3f, sd=%7.5g)", 
		     (char *) "Distribution of the constant (of the "
		     "first segment) , C=e^a ~ lognormal"
		     "(mu=%7.3f, sd=%7.3g)"), mu, sd);
  axislab[0]=new char[10];
  strcpy(axislab[0], "a");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(int i=0;i<len;i++, C+=step)
    {
      double logf=-0.5*log(2.0*M_PI)-log(sd)-log(C)-
	0.5*(log(C)-mu)*(log(C)-mu)/sd/sd;
      
      arg[i]=C;
      val[i]=exp(logf);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void segmented_rcurve_showpriors::plot_b(void)
{
  if(!check_positive(b_startf.getdouble(), 
		     WHAT((char *) "eksponent, nedre 95%%-grense",
			  (char *) "exponent, lower 95%% limit"),
			  false, -1, -1))
    return;
  if(!check_positive(b_endf.getdouble(), 
		     WHAT((char *) "eksponent, �vre 95%%-grense",
			  (char *) "exponent, upper 95%% limit"),
			  false, -1, -1))
    return;
  
  double b1=b_startf.getdouble(),b2=b_endf.getdouble();
  if(!check_95_credibility_interval(b2, b1, 
				    WHAT((char *) "eksponent", 
					 (char *) "exponent"), -1, -1,
				    this, false))
    return;
  
  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=(b2-b1)*2.0, step=size/double(len),b=b1-size/4.0;
  int axis=1;

  double mu=(b1+b2)/2.0;
  double sd=(b2-b1)/2.0/1.96;

  sprintf(line, WHAT((char *) "Fordeling til eksponent, b ~ "
		     "normal(mu=%7.3f, sd=%7.5g)", 
		     (char *) "Distribution of the exponent, b ~ "
		     "normal(mu=%7.3f, sd=%7.3g)"), mu, sd);
  axislab[0]=new char[10];
  strcpy(axislab[0], "b");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(int i=0;i<len;i++, b+=step)
    {
      double logf=-0.5*log(2.0*M_PI)-log(sd)-
	0.5*(b-mu)*(b-mu)/sd/sd;
      
      arg[i]=b;
      val[i]=exp(logf);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void segmented_rcurve_showpriors::plot_h01(void)
{
  double h011=h01_startf.getdouble(),h012=h01_endf.getdouble();
  if(!check_95_credibility_interval(h012, h011, 
				    WHAT((char *) "bunnvannstand", 
					 (char *) "zero stage"),
				    -1, -1, this, false, 
				    0.01, 
				    WHAT((char *) "en cm", (char *) "one cm"),
				    0.001, 
				    WHAT((char *) "en mm", (char *) "one mm")))
    return;


  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=(h012-h011)*2.0, step=size/double(len),h01=h011-size/4.0;
  int axis=1;

  double mu=(h011+h012)/2.0;
  double sd=(h012-h011)/2.0/1.96;

  sprintf(line, WHAT((char *) "Fordeling til laveste segment h0 ~ "
		     "normal(mu=%7.3f, sd=%7.5g)", 
		     (char *) "Distribution of the lowest segment h0 ~ "
		     "normal(mu=%7.3f, sd=%7.3g)"), mu, sd);
  axislab[0]=new char[10];
  strcpy(axislab[0], "h01");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  double maxh01=MISSING_VALUE;
  if(lognormal_h01_tog())
    {
      maxh01=h01_maxf.getdouble();

      if(maxh01==MISSING_VALUE)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Maksimalverdien ikke satt!", 
			 (char *) "Maximal value not set!"));
	  return;
	}
      
      if(maxh01<h012)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "�vre troverdighet for h01 st�rre "
			 "enn maksimalverdien!", 
			 (char *) "Upper credibility for h01 greater "
			 "than the maximal value!"));
	  return;
	}
      else if(maxh01==h012)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "�vre troverdighet for h01 er lik "
			 "maksimalverdien!", 
			 (char *) "Upper credibility for h01 is equal to "
			 "the maximal value!"));
	  return;
	}

      mu=(log(maxh01-h011)+log(maxh01-h012))/2.0;
      sd=(log(maxh01-h011)-log(maxh01-h012))/2.0/1.96;
    }

  for(int i=0;i<len;i++, h01+=step)
    {
      double f;
      if(!lognormal_h01_tog())
	{
	  double logf=-0.5*log(2.0*M_PI)-log(sd)-
	    0.5*(h01-mu)*(h01-mu)/sd/sd;
	  f=exp(logf);
	}
      else
	{
	  if(h01>maxh01)
	    f=0.0;
	  else
	    {
	      double logf=-0.5*log(2.0*M_PI)-log(sd)-log(maxh01-h01)-
		0.5*(log(maxh01-h01)-mu)*(log(maxh01-h01)-mu)/sd/sd;
	      f=exp(logf);
	    }
	}
      
      arg[i]=h01;
      val[i]=f;
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void segmented_rcurve_showpriors::plot_h02(void)
{
  double h021=h02_startf.getdouble(),h022=h02_endf.getdouble();
  if(!check_95_credibility_interval(h022, h021, 
				    WHAT((char *) "bunnvannstand-differans "
					 "mellom segmenter", 
					 (char *) "zero stage difference "
					 "between segments"),
				    -1, -1, this, false, 
				    0.01, 
				    WHAT((char *) "en cm", (char *) "one cm"),
				    0.001, 
				    WHAT((char *) "en mm", (char *) "one mm")))
    return;

  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=(h022-h021)*2.0, step=size/double(len),h02=h021-size/4.0;
  int axis=1;

  double mu=(h021+h022)/2.0;
  double sd=(h022-h021)/2.0/1.96;

  sprintf(line, WHAT((char *) "Fordeling til �vre segmenter h0 ~ "
		     "normal(mu=%7.3f, sd=%7.5g)", 
		     (char *) "Distribution of the upper segments h0 ~ "
		     "normal(mu=%7.3f, sd=%7.3g)"), mu, sd);
  axislab[0]=new char[10];
  strcpy(axislab[0], "h02");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(int i=0;i<len;i++, h02+=step)
    {
      double logf=-0.5*log(2.0*M_PI)-log(sd)-
	0.5*(h02-mu)*(h02-mu)/sd/sd;
      
      arg[i]=h02;
      val[i]=exp(logf);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void segmented_rcurve_showpriors::plot_q(void)
{
  if(!check_positive(q_startf.getdouble(), 
		     WHAT((char *) "vannf�ring, nedre 95%%-grense",
			  (char *) "discharge, lower 95%% limit"),
			  false, -1, -1))
    return;
  if(!check_positive(q_endf.getdouble(), 
		     WHAT((char *) "vannf�ring, �vre 95%%-grense",
			  (char *) "discharge, upper 95%% limit"),
			  false, -1, -1))
    return;
  
  double q1=log(q_startf.getdouble()),q2=log(q_endf.getdouble());
  if(!check_95_credibility_interval(exp(q2), exp(q1), 
				    WHAT((char *) "bunnvannstand-differans "
					 "mellom segmenter", 
					 (char *) "zero stage difference "
					 "between segments"),
				    -1, -1, this, false))
    return;

  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=exp(q2)*2.0, step=size/double(len),Q=step;
  int axis=1;

  double mu=(q1+q2)/2.0;
  double sd=(q2-q1)/2.0/1.96;

  sprintf(line, WHAT((char *) "Fordeling til vannf�ring, Q~ "
		     "lognormal(mu=%7.3f, sd=%7.5g)", 
		     (char *) "Distribution of discharge, Q ~ "
		     "lognormal(mu=%7.3f, sd=%7.3g)"), mu, sd);
  axislab[0]=new char[10];
  strcpy(axislab[0], "Q");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(int i=0;i<len;i++, Q+=step)
    {
      double logf=-0.5*log(2.0*M_PI)-log(sd)-log(Q)-
	0.5*(log(Q)-mu)*(log(Q)-mu)/sd/sd;
      
      arg[i]=Q;
      val[i]=exp(logf);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void segmented_rcurve_showpriors::ok(void)
{
  if(!check_positive(sigma_startf.getdouble(), 
		     WHAT((char *) "sigma, nedre 95%%-grense",
			  (char *) "sigma, lower 95%% limit"),
			  false, -1, -1))
    return;
  if(!check_positive(sigma_endf.getdouble(), 
		     WHAT((char *) "sigma, �vre 95%%-grense",
			  (char *) "sigma, upper 95%% limit"),
			  false, -1, -1))
    return;
  
  double s1=sigma_startf.getdouble(), s2=sigma_endf.getdouble();
  
  if(!check_95_credibility_interval(s2, s1, "sigma"))
    return;

  double a,b,cred;
  find_invgamma_distribution(s1*s1, s2*s2, 95.0, &a, &b, &cred);
  if(cred<94.0 || cred>96.0)
    warn.build(mainwin::toplevel, "Advarsel", 
	       WHAT((char *) "Optimering feilet. Klarte ikke � finne rette "
		    "invers-gamma-parametre til sigma som gjorde at 95%% av "
		    "sannsynlighetsmassen var\n"
		    "innenfor de gitte grensene! Funnet troverdighet=%7.3f%%",
		    (char *) "Optimization failed. Could not find the inverse "
		    "gamma parameters for sigma that had 95%% probability "
		    "mass inside\n"
		    "the given limits! Found credibility=%7.3f%%"), 
	       cred);
  
  set_sigma_parameters(s1,s2, 0.95);
  
  if(!check_positive(a_startf.getdouble(), 
		     WHAT((char *) "konstant, nedre 95%%-grense",
			  (char *) "constant, lower 95%% limit"),
			  false, -1, -1))
    return;
  if(!check_positive(a_endf.getdouble(), 
		     WHAT((char *) "konstant, �vre 95%%-grense",
			  (char *) "constant, upper 95%% limit"),
			  false, -1, -1))
    return;
  
  double a1=log(a_startf.getdouble()), a2=log(a_endf.getdouble());
  if(!check_95_credibility_interval(exp(a2), exp(a1), 
				    WHAT((char *) "konstant", 
					 (char *) "constant")))
    return;

  if(!check_positive(b_startf.getdouble(), 
		     WHAT((char *) "eksponent, nedre 95%%-grense",
			  (char *) "exponent, lower 95%% limit"),
		     false, -1, -1))
    return;
  if(!check_positive(b_endf.getdouble(), 
		     WHAT((char *) "eksponent, �vre 95%%-grense",
			  (char *) "exponent, upper 95%% limit"),
			  false, -1, -1))
    return;
  
  double b1=b_startf.getdouble(), b2=b_endf.getdouble();
  if(!check_95_credibility_interval(b2, b1,
				    WHAT((char *) "eksponent", 
					 (char *) "exponent")))
    return;

  double cor=corrf.getdouble();
  if(cor <= -1.0 || cor >= 1.0)
    {
      char errstr[1000];
      sprintf(errstr, 
	      WHAT((char *) "Korrelasjon til formparametre satt til %f!\n"
		   "Men korrelasjon m� v�re et tall ekte mellom -1 og +1.", 
		   (char *) "Correlation of shape parameters set to %f!\n"
		   "However, correlations need to be inside the "
		   "interval -1 to +1."), cor);
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		errstr);
      return;
    }


  set_linear_parameters_simple((a1+a2)/2.0, (b1+b2)/2.0, 
			       (a2-a1)/2.0/1.96, (b2-b1)/2.0/1.96, cor,
			       detailed_lin_tog(),false);
  
  if(!detailed_h0_tog())
    {
      double h011=h01_startf.getdouble(), h012=h01_endf.getdouble();
      if(!check_95_credibility_interval(h012, h011, 
					WHAT((char *) "bunnvannstand", 
					     (char *) "zero stage"),
					-1, -1, this, true, 
					0.01, 
					WHAT((char *) "en cm", 
					     (char *) "one cm"),
					0.001, 
					WHAT((char *) "en mm", 
					     (char *) "one mm")))
	return;

      double h021=h02_startf.getdouble(), h022=h02_endf.getdouble();
      if(!check_95_credibility_interval(h022, h021, 
					WHAT((char *) "bunnvannstand-differans "
					     "mellom segmenter", 
					     (char *) "zero stage difference "
					     "between segments"),
					-1, -1, this, true, 
					0.01, 
					WHAT((char *) "en cm", 
					     (char *) "one cm"),
					0.001, 
					WHAT((char *) "en mm", 
					     (char *) "one mm")))
	return;
      
      
      
      double mu, sd, max;
      bool is_lognormal=lognormal_h01_tog()==True ? true : false;
      
      if(is_lognormal)
	{
	  max=h01_maxf.getdouble();
	  
	  if(max==MISSING_VALUE)
	    {
	      err.build(mainwin::toplevel, WHAT((char *) "Feil", 
						(char *) "Error"),
			WHAT((char *) "Maksimalverdien ikke satt!", 
			     (char *) "Maximal value not set!"));
	      return;
	    }
	  
	  if(max<h012)
	    {
	      err.build(mainwin::toplevel, WHAT((char *) "Feil", 
						(char *) "Error"),
			WHAT((char *) "�vre troverdighet for h01 st�rre "
			     "enn maksimalverdien!", 
			     (char *) "Upper credibility for h01 greater "
			     "than the maximal value!"));
	      return;
	    }
	  
	  mu=(log(max-h011)+log(max-h012))/2.0;
	  sd=(log(max-h011)-log(max-h012))/2.0/1.96;
	}
      else
	{
	  mu=(h011+h012)/2.0;
	  sd=(h012-h011)/2.0/1.96;
	  max=MISSING_VALUE;
	}
      
      set_h0_simple(mu, sd, is_lognormal, max, 
		    (h021+h022)/2.0, (h022-h021)/2.0/1.96);
    }

  if(!detailed_hs_tog())
    {
      if(!check_positive(q_startf.getdouble(), 
			 WHAT((char *) "vannf�ring, nedre 95%%-grense",
			      (char *) "discharge, lower 95%% limit"),
			 false, -1, -1))
	return;
      if(!check_positive(q_endf.getdouble(), 
			 WHAT((char *) "vannf�ring, �vre 95%%-grense",
			      (char *) "discharge, upper 95%% limit"),
			 false, -1, -1))
	return;
     
      double q1=log(q_startf.getdouble()), q2=log(q_endf.getdouble());
      if(!check_95_credibility_interval(exp(q2), exp(q1), 
					WHAT((char *) "vannf�ring", 
					     (char *) "discharge")))
	return;

      set_hs_simple((q2+q1)/2.0, (q2-q1)/2.0/1.96);
    }
  
  Unmap();
  //prewindow.Map();
}

void segmented_rcurve_showpriors::prior_set(void)
{
  // NOP
}

void segmented_rcurve_showpriors::cancel(void)
{
  set_default(min_segf.getdigit(),max_segf.getdigit());
  Unmap();
  prewindow.Map();
}

void segmented_rcurve_showpriors::pre_ok(void)
{
  int new_min_seg=min_segf.getdigit(), new_max_seg=max_segf.getdigit();

  if(more_minseg!=new_min_seg || more_maxseg!=new_max_seg)
    {
      mess.build(*this, WHAT((char *) "Sp�rsm�l", 
			     (char *) "Question"), 
		 WHAT((char *) "Antall mulige segmenter er forandret "
		      "etter egenspesifisering av kurve-f�rkunnskap.\n"
		      "Skal dette benyttes, m� egenspesifiseringen "
		      "forkastes for regional default-kunnskap.\n"
		      "�nsker du � gj�re dette?", 
		      (char *) "The number of possible segments has "
		      "been changed after specifying the curve prior.\n"
		      "If this change in possible number of segments "
		      "is to be used, the specified prior must be\n"
		      "rejected and replaced with a regional prior. "
		      "Do you wish to do this?"));
      if(mess.ok_or_cancel(WHAT((char *) "Ja", (char *) "Yes"),
			   WHAT((char *) "Nei", (char *) "No")))
	{
	  set_default(new_min_seg,new_max_seg);
	}
      else
	{
	  min_segf.SetDigit(more_minseg);
	  max_segf.SetDigit(more_maxseg);
	}
    }
  
  prev_minseg=more_minseg=new_min_seg;
  prev_maxseg=more_maxseg=new_max_seg;
  
  prewindow.Unmap();
  print();
  
  prior_set();
}



void segmented_rcurve_showpriors::pre_more(void)
{
  if(min_segf.getdigit()<1)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Minimalt antall segmenter m� v�re "
		     "st�rre enn null.", 
		     (char *) "Minimal number of segments must be larger "
		     "than zero."));
      return;
    }

  if(max_segf.getdigit()<min_segf.getdigit())
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Maksimalt antall segmenter kan ikke v�re "
		     "mindre enn minimalt antall segmenter.", 
		     (char *) "Maximal number of segments cannot be less "
		     "than minimal number of segments."));
      return;
    }

  prev_minseg=more_minseg;
  prev_maxseg=more_maxseg;
  more_minseg=min_segf.getdigit();
  more_maxseg=max_segf.getdigit();
  if(!(prev_minseg==more_minseg && more_maxseg==prev_maxseg))
    set_default(more_minseg,more_maxseg);
  show_again();
  prev_minseg=more_minseg;
  prev_maxseg=more_maxseg;
  prewindow.Unmap();
}

void segmented_rcurve_showpriors::pre_extra_start(void)
{
  preextrawindow.Map();
  pre_extra_set();
}

void segmented_rcurve_showpriors::pre_extra_set(void)
{
  int i, num=numextraf.getdigit();

  if(num<0)
    {
      err.build(preextrawindow,
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Antall intervall kan ikke v�re negativ!", 
		     (char *) "Number of intervals can't be negative!"));
      return;
    }
  if(num>10)
    {
      err.build( preextrawindow,
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Antall intervall kan ikke v�re st�rre enn 10!", 
		     (char *) "Number of intervals can't be greater than 10!")
		);
      return;
    }

  for(i=0;i<10;i++)
    if(i<num)
      eh2[i].Map();
    else
      eh2[i].Unmap();
}

void segmented_rcurve_showpriors::pre_extra_accept(void)
{
  int i, num=numextraf.getdigit();

  if(num<0)
    {
      err.build(preextrawindow,
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Antall intervall kan ikke v�re negativ!", 
		     (char *) "Number of intervals can't be negative!"));
      return;
    }
  if(num>10)
    {
      err.build(preextrawindow,
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Antall intervall kan ikke v�re st�rre enn 10!", 
		     (char *) "Number of intervals can't be greater than 10!")
		);
      return;
    }
  
  if(num==0)
    set_extrapolation_restrictions(0,NULL, NULL, NULL,NULL);
  else
    {
      double *stage=new double[num],*Q1=new double[num], *Q2=new double[num];
      char **comment=new char*[num];
      char errstr[1000];
      
      for(i=0;i<num;i++)
	{
	  if(strlen(estagef[i]())<=0 || 
	     (!isdigit(estagef[i]()[0]) && !isdigit(estagef[i]()[1])))
	    {
	      sprintf(errstr, 
		      WHAT((char *) "Vannstand nr %d ikke oppgitt!", 
			   (char *) "Stage nr %d not given!"), i+1);
	      err.build(preextrawindow,
			WHAT((char *) "Feil", (char *) "Error"),
			errstr);
	      return;
	    }
	  stage[i]=estagef[i].getdouble();

	  if(strlen(eQ1f[i]())<=0 || 
	     (!isdigit(eQ1f[i]()[0]) && !isdigit(eQ1f[i]()[1])))
	    Q1[i]=MISSING_VALUE;
	  else
	    {
	      if(!check_positive(eQ1f[i].getdouble(), 
				 WHAT((char *) "vannf�ring, nedre 95%%-grense",
				      (char *) "discharge, lower 95%% limit"),
				 false, -1, -1, &preextrawindow))
		return;
	      Q1[i]=eQ1f[i].getdouble();
	    }
	  
	  if(strlen(eQ2f[i]())<=0 || 
	     (!isdigit(eQ2f[i]()[0]) && !isdigit(eQ2f[i]()[1])))
	    Q2[i]=MISSING_VALUE;
	  else
	    {
	      if(!check_positive(eQ2f[i].getdouble(), 
				 WHAT((char *) "vannf�ring, �vre 95%%-grense",
				      (char *) "discharge, upper 95%% limit"),
				 false, -1, -1, &preextrawindow))
		return;
	      Q2[i]=eQ2f[i].getdouble();
	    }
	  
	  if(Q1[i]==MISSING_VALUE && Q2[i]==MISSING_VALUE)
	    {
	      sprintf(errstr, 
		      WHAT((char *) "Spesifikasjon nr. %d: Minst en av "
			   "�vre og nedre vannf�rings-grense m� oppgis!", 
			   (char *) "Specification nr %d: At least one "
			   "of the lower and upper discharge limits has to "
			   "be given!"), i+1);
	      err.build(preextrawindow,
			WHAT((char *) "Feil", (char *) "Error"),
			errstr);
	      return;
	    }
  
	  if(Q1[i]>=Q2[i])
	    {
	      sprintf(errstr, 
		      WHAT((char *) "Spesifikasjon nr. %d: Nedre vannf�rings-"
			   "grense>=�vre vannf�rings-grense!", 
			   (char *) "Specification nr %d: Lower discharge "
			   "limit>=Upper discharge limit!"), i+1);
	      err.build(preextrawindow,
			WHAT((char *) "Feil", (char *) "Error"),
			errstr);
	      return;
	    }
	  
	  if(strlen(ecommentf[i].GetText())<=0)
	    {
	      sprintf(errstr, 
		      WHAT((char *) "Spesifikasjon nr. %d: "
			   "Kommentar ikke gitt!", 
			   (char *) "Specification nr %d: Comment not given!"),
		      i+1);
	      err.build(preextrawindow,
			WHAT((char *) "Feil", (char *) "Error"),
			errstr);
	      return;
	    }
	  
	  for(int j=0;j<i;j++)
	    if(almost_equal(stage[i],stage[j]))
	      {
		sprintf(errstr, 
			WHAT((char *) "Vannstand nr %d og nr %d er lik "
			     "(%7.3f)!", 
			     (char *) "Stage nr %d and nr %d are equal "
			     "(%7.3f)!"), i+1, j+1, stage[i]);
		err.build(preextrawindow,
			  WHAT((char *) "Feil", (char *) "Error"),
			  errstr);
		return;
	    }
	  
	  comment[i]=new char[strlen(ecommentf[i].GetText())+10];
	  strcpy(comment[i],ecommentf[i].GetText());
	}
      
      set_extrapolation_restrictions(num, stage, Q1, Q2, comment);
      
      doubledelete(comment,num);
      delete [] stage;
      delete [] Q1;
      delete [] Q2;
    }
  
  preextrawindow.Unmap();
}

void segmented_rcurve_showpriors::pre_extra_reject(void)
{
  preextrawindow.Unmap();
}

void segmented_rcurve_showpriors::set_h01_prior_from_data(double *stage, 
							  double *discharge, 
							  int len)
{
  double h0_m=0.0, h0_var=0.0, h0_sd;
  int num_h0=0;

  for(int i=0;i<len;i++)
    {
      if(discharge[i]<MIN_Q)
	{
	  h0_m += stage[i];
	  h0_var+=stage[i]*stage[i];
	  num_h0++;
	}
    }

  if(num_h0<=0)
    return;

  mess_sh.build(mainwin::toplevel, 
		WHAT((char * ) "Meldingsvindu - nivellering" , 
		     (char *) "Message window - zero-plane "
		     "displacement"));
  mess_v1.build(mess_sh);
  if(num_h0==1)
    {
      mess1.build(mess_v1, 
		  WHAT((char *) "En nivellering funnet p� vannstand=%7.2f",
		       (char *) "One zero-plane displ. found at stage=%7.2f"),
		  h0_m);
      mess2.build(mess_v1,
		  WHAT((char *) "F�rkunnskap om nullvannstand, "
		       "h0 satt til intervallet",
		       (char *) "Prior knowledge about h0 set to "
		       "the interval"));
      mess3.build(mess_v1, "%7.2f-%7.2f", 
		  h0_m-1.96*0.1, h0_m+1.96*0.1);
      standard_h01_mu=h0_m;
      standard_h01_sd=0.1;
      mu_h01=h0_m;
      sd_h01=0.2/1.96;
    }
  else
    {
      h0_m/=double(num_h0);
      h0_var/=double(num_h0);
      h0_var-=h0_m*h0_m;
      h0_var+=0.1*0.1;
      h0_sd=sqrt(h0_var);
      
      mess1.build(mess_v1,
		  WHAT((char *) "%d nivelleringer funnet, gj.snitt=%7.2f, "
		       "st.avvik=%7.2f",
		       (char *) "%d zero-plane measurements found with "
		       "mean=%7.2f and st.dev=%7.2f"),
		  num_h0, h0_m, h0_sd);
      mess2.build(mess_v1, 
		  WHAT((char *) "F�rkunnskap om nullvannstand, "
		       "h0 satt til intervallet", 
		       (char *) "Prior knowledge about h0 set to the "
		       "interval"));
      h0_sd=MAXIM(0.1, h0_sd);
      mess3.build(mess_v1, "%7.2f-%7.2f", 
		  h0_m-1.96*h0_sd, h0_m+1.96*h0_sd);
      standard_h01_mu=h0_m;
      standard_h01_sd=h0_sd;
      mu_h01=h0_m;
      sd_h01=h0_sd;
    }

  lognormal_h01=false;
  max_h01=MISSING_VALUE;

  mess_sep1.build(mess_v1);
  mess_h1.build(mess_v1);
  mess_closeb.build(mess_h1, &mess_sh, WHAT((char *) "Lukk meldingsvindu",
					   (char *) "Close message window"));
  mess_sh.Map();
}


void segmented_rcurve_showpriors::take_action(SEG_INT_TYPE action)
{
  switch(action)
    {
    case SEG_INT_DETAILED_H0:
      warn.build(*this, WHAT((char *) "Advarsel", (char *) "Warning"), 
		 WHAT((char *) "Bunnvannstander (h0) for alt unntatt nedre "
		      "segment er rent teoretiske konstruksjoner\n(til "
		      "forskjell fra segmentskille, hs). Er du sikker p� at "
		      "du vil sette f�rkunnskap om disse?", 
		      (char *) "Zero planes (h0) for all except the lowest "
		      "segment are purely tehoretical contructs\n(as opposed "
		      "to segment limits, hs). Are you sure you want to set "
		      "prior distributions for these?"));
      if(warn.ok_or_cancel(WHAT((char *) "Ja", (char *) "Yes"),
			   WHAT((char *) "Nei", (char *) "No")))
	start_detailed_h0();
      else
	{
	  detailed_h0_tog.switch_off();
	  set_h0_back_to_simple();
	}
      return;
    case SEG_INT_DETAILED_PROB:
      start_detailed_prob();
      return;
    case SEG_INT_DETAILED_HS:
      start_detailed_hs();
      return;
    case SEG_INT_DETAILED_LIN: 
      start_detailed_lin();
      return;
    case SEG_INT_PROB_OK:
      prob_ok();
      return;
    case SEG_INT_PROB_CANCEL:
      prob_cancel();
      return;
    case SEG_INT_LIN_OK: 
      lin_ok();
      return;
    case SEG_INT_LIN_CANCEL:
      lin_cancel();
      return;
    case SEG_INT_H0_OK:
      h0_ok();
      return;
    case SEG_INT_H0_CANCEL:
      h0_cancel();
      return;
    case SEG_INT_HS_OK:
      hs_ok();
      return;
    case SEG_INT_HS_CANCEL:
      hs_cancel();
      return;
    case SEG_INT_PLOT_PROB:
      plot_prob();
      return;
    case SEG_INT_PLOT_SIGMA:
      plot_sigma();
      return; 
    case SEG_INT_PLOT_A:
      plot_a();
      return;
    case SEG_INT_PLOT_B:
      plot_b();
      return;
    case SEG_INT_PLOT_H01: 
      plot_h01();
      return;
    case SEG_INT_PLOT_Q:
      plot_q();
      return;
    case SEG_INT_PLOT_H02:
      plot_h02();
      return; 
    case SEG_INT_OK:
      ok();
      return;
    case SEG_INT_CANCEL:
      cancel();
      return;
    case SEG_INT_MORE:
      pre_more();
      return;
    case SEG_INT_EXTRA:
      pre_extra_start();
      break;
    case SEG_EXTRA_SET:
      pre_extra_set();
      break;
    case SEG_EXTRA_ACCEPT:
      pre_extra_accept();
      break;
    case SEG_EXTRA_REJECT:
      pre_extra_reject();
      break;
    case SEG_INT_ACCEPT_DEFAULT:
      pre_ok();
      return;
    case SEG_LIN_ADVANCED:
      const_exp_sh.Map();
      break;
    case SEG_H0_ADV:
      h0_adv_sh.Map();
      break;
    case SEG_HS_ADV:
      hs_adv_sh.Map();
      break;
    default:
      err.build(*this, WHAT((char *) "Programfeil", (char *) "Program error"),
		WHAT((char *) "Ukjent handling", (char *) "Unknown action"));
      return;
    }
}

segmented_rcurve_showpriors::segmented_rcurve_showpriors(void) : 
  shell(), segmented_priors()
{
  init_windows();
}

segmented_rcurve_showpriors::
segmented_rcurve_showpriors(segmented_priors *orig) : 
  shell(), segmented_priors(orig)
{
  init_windows();
}

segmented_rcurve_showpriors::~segmented_rcurve_showpriors()
{
  cleanup_windows();
}


void segmented_rcurve_showpriors::create(widget &parent, bool doshow_prewindow, 
					 bool doshow_mainwindow)
{
  parentpt=&parent;
  
  // Make the default window:

  prewindow.build(parent, WHAT((char *) "F�rskunnskap", 
			       (char *) "Prior knowledge"));
  prev1.build(prewindow);
  prequestlab.build(prev1, 
		    WHAT((char *) "Setting av f�rkunnskap. Hvis ikke "
			 "detaljert f�rkunnskap blir satt, \n vil "
			 "default f�rkunnskap fra NVEs database bli brukt", 
			 (char *) "Specification of the prior knowledge. "
			 "If detailed prior knowledge isn't set, \nthe "
			 "default knowledge gained from the database at "
			 "NVE will be used"));
  preh1.build(prev1);
  min_segf.build(preh1, 3, WHAT((char *) "Minimum antall segmenter:", 
			       (char *) "Minimum number of segments:"));
  min_segf.SetDigit(get_min_seg());
  max_segf.build(preh1, 3, WHAT((char *) "Maksimum antall segmenter:", 
			       (char *) "Maximum number of segments:"));
  max_segf.SetDigit(get_max_seg());

  prev_minseg=get_min_seg();
  prev_maxseg=get_max_seg();
  make_mainwindow(get_min_seg(), get_max_seg());
  more_minseg=prev_minseg;
  more_maxseg=prev_maxseg;
  
  presep.build(prev1);
  preh2.build(prev1);
  vok.build(preh2);
  pre_acceptb.Create(vok, WHAT((char *) "OK", (char *) "OK"), 
		     SEG_INT_ACCEPT_DEFAULT, this);
  pre_acceptb.Background("green");
  pre_acceptb.Foreground("black");
  
  vmore.build(preh2);
  pre_moreb.Create(vmore, 
		   WHAT((char *) "Vis/rediger f�rkunnskap", 
			(char *) "Show/specify prior knowledge"), 
		   SEG_INT_MORE, this);
  //pre_moreb.Background("yellow");
  //pre_moreb.Foreground("black");
  parlab.build(vmore, WHAT((char *) "ang�ende", (char *) "cocerning"));
  //curvepar.Build(vmore, WHAT((char *) "kurve-parametre",
  //(char *) "curve parameters"));
  curvepar.Create(vmore, SRSH_PARAM);
  
  vextra.build(preh2);
  pre_extrab.Create(vextra, 
		    WHAT((char *) "Spesifiser vannf�ringsintervall (hjelpepunkt)", 
			 (char *) "Specify discharge intervals (help points)"),
		    SEG_INT_EXTRA, this);
  //pre_extrab.Background("yellow");
  //pre_extrab.Foreground("black");
  extralab.build(vextra, 
		 WHAT((char *) "for spesifikke vannstander i "
		      "ekstrapolert omr�de", 
		      (char *) "for specific stage values in the "
		      "extrapolated area"));
  intervallab.Create(vextra, SRSH_INTERVAL);
  //intervallab.Build(vextra, WHAT((char *) "Om vannf�ringsintervaller", 
  //(char *) "About discharge inttervals"));

  if(doshow_prewindow)
    prewindow.Map();
  
  preextrawindow.build(mainwin::toplevel, 
		       WHAT((char *) "Spesifisering av vannf�ringsintervall "
			    "for spesifikke vannstander i ekstrapolert omr�de",
			    (char *) "Specification of discharge intervals "
			    "for specific stage values in the extrapolated "
			    "area"));
  ev1.build(preextrawindow);
  estartlab.build(ev1, WHAT((char *) 
   "Angi antall vannf�ringsintervaller og "
   "for hver, vannstand, vannf�ringsintervall og kommentarfelt.\n"
   "Oppgis b�de �vre og nedre vannf�rings-grense, anses dette for"
   "� v�re et 95%% troverdighetsintervall. Hvis bare �vre eller bare\n"
   "nedre grense er oppgitt, er dette en hard grense.", 
   (char *) 
   "Specify the number of discharge intervals and for each, "
   "specify the stage, the discharge interval and a comment field.\n"
   "if both lower and upper discharge limit is given, this is taken as "
   "a 95%% credibility interval. If only upper or only lower limit is\n"
   "given, this is taken as a hard limit."));
  eh1.build(ev1);
  numextraf.build(eh1, 3, WHAT((char *) "Antall vannf�ringsintervall:", 
			       (char *) "Number of discharge intervals"));
  numextraf.SetDigit(num_extra);
  set_numextrab.Create(eh1, WHAT((char *) "Sett", (char *) "Set"),
		       SEG_EXTRA_SET, this);
  set_numextrab.Background("yellow");
  set_numextrab.Foreground("black");
  
  efr.build(ev1);
  esc.build(efr);
  esc.Width(900);
  esc.Height(500);
  ev2.build(esc);
  for(int i=0;i<10;i++)
    {
      eh2[i].build(ev2);
      ev3[i+40].build(eh2[i]);
      enrlab[i].build(ev3[i+40],"\n\nNr. %d:", i+1);
      ev3[i].build(eh2[i]);
      estagef[i].build(ev3[i], 7, "Vannstand:");
      ev3[i+10].build(eh2[i]);
      eQ1f[i].build(ev3[i+10],7,"Nedre vannf 0�ring");
      ev3[i+20].build(eh2[i]);
      eQ2f[i].build(ev3[i+20],7,"�vre vannf�ring");
      ev3[i+30].build(eh2[i]);
      ecommentlab[i].build(ev3[i+30],WHAT((char *) "Kommentar:",
					(char *) "Comment:"));
      ecommentf[i].build(ev3[i+30],50,5,True);
      
      if(i<num_extra)
	{
	  estagef[i].SetDouble(extra_stage[i],4);
	  eQ1f[i].SetDouble(extra_q_lower[i]!=MISSING_VALUE ? 
			    exp(extra_q_lower[i]) : MISSING_VALUE, 4);
	  eQ2f[i].SetDouble(extra_q_upper[i]!=MISSING_VALUE ? 
			    exp(extra_q_upper[i]) : MISSING_VALUE, 4);
	  ecommentf[i].SetText(extra_comment[i]);
	}
    }
  esep1.build(ev1);
  eh3.build(ev1);
  extra_acceptb.Create(eh3, WHAT((char *) "OK", (char *) "OK"),
		       SEG_EXTRA_ACCEPT, this);
  extra_acceptb.Background("green");
  extra_acceptb.Foreground("black");
  extra_rejectb.Create(eh3, WHAT((char *) "Avbryt", (char *) "Cancel"),
		       SEG_EXTRA_REJECT, this);
  extra_rejectb.Background("red");
  extra_rejectb.Foreground("white");

  if(doshow_mainwindow)
    Map();
}

void segmented_rcurve_showpriors::create(widget &parent, double *stage, 
					 double *discharge, int len)
{
  create(parent);
  set_h01_prior_from_data(stage,discharge,len);
}

char *get_padded_string(char *txt, int maxlen)
{
  char formstr[1000];
  int stlen=strlen(txt);
  sprintf(formstr, "%%%ds%%s%%%ds",
	  (int) ceil(double(maxlen-stlen)/2.0),
	  (int) floor(double(maxlen-stlen)/2.0));
  char *ret=new char[maxlen+3];
  sprintf(ret, formstr, " ", txt, " ");
  return ret;
}

void segmented_rcurve_showpriors::make_mainwindow(int minseg, int maxseg)
{
  // Make the main prior window:
  
  if(prev_minseg==minseg && prev_maxseg==maxseg)
    cleanup_windows();
  else
    {
      cleanup_windows();
      set_default(minseg, maxseg);
      more_minseg=minseg;
      more_maxseg=maxseg;
      std::cout << "default set" << std::endl;
    }
  
  

  ////{
  build(*parentpt, WHAT((char *) "Spesifisering av f�rkunnskap", 
			(char *) "Specification of prior knowledge"));
  v1.build(*this);
  
  

  // Linear (profile shape) parameters:
  fr_lin.build(v1);
  v_lin.build(fr_lin);
  h_lin5.build(v_lin);

  lin_label1.build(h_lin5,  WHAT((char *) "Profilens form-parametre:", 
				(char *) "Profile's shape parameters:"));

  h_lin6.build(v_lin);
  lin_label2.build(h_lin6,"(");
  if(exp_label!=NULL)
    delete exp_label;
  exp_label=new srs_hypertext_label();
  exp_label->Create(h_lin6, SRSH_EXPONENT);
  lin_label2.build(h_lin6, WHAT((char *) " og ", (char *) " and "));
  if(const_lab2!=NULL)
    delete const_lab2;
  const_lab2=new srs_hypertext_label();	      
  const_lab2->Create(h_lin6, SRSH_CONSTANT);
  lin_label3.build(h_lin6, ")");

  h_lin1.build(v_lin);
  lin_v2.build(h_lin1);
  empty1.build(lin_v2,"");
  
  b_startf.build(h_lin1, 8, 
		 WHAT((char *) "95 %% sannsynlighet for at "
		      "eksponenten, b, ligger mellom ",
		      (char *) "95%% probability that the "
		      "exponent, b, lies between "));
  b_endf.build(h_lin1,8,WHAT((char *) " og ", (char *) " and "));
  b_startf.SetDouble(get_overall_b_mu()-1.96*get_overall_b_sd(),4);
  b_endf.SetDouble(get_overall_b_mu()+1.96*get_overall_b_sd(),4);
  h_lin4.build(v_lin);
  char *plottext1=
    get_padded_string(WHAT((char *) "Plott b-f�rskunnskap", 
			   (char *) "Plot b prior"), 30);
  show_b_prior.Create(h_lin4, plottext1, 
		      SEG_INT_PLOT_B, this);
  delete [] plottext1;
  exp_extra.build(h_lin1, WHAT((char *) "(Typiske verdier vil ligge mellom 1.3 og 4.0)", 
			       (char *) "(Typical values will lie between 1.3 and 4.0)"));
  h_lin2.build(v_lin);

  char *detailed_text1=
    get_padded_string(WHAT((char *) "Avanserte spesifiseringer av konstant "
			   "og eksponenter.", 
			   (char *) "Advanced specifications of constant "
			   "and exponents."), 60);
  detailed_const_exp.Create(h_lin2, detailed_text1,
			    SEG_LIN_ADVANCED, this);
  detailed_const_exp.Background("yellow");
  delete [] detailed_text1;


  const_exp_sh.build(*this, WHAT((char *) "Avansert f�rkunnskap om profilens "
			   "form-parametre", 
			   (char *) "Advanced prior knowledge of the profiles "
				 "shape parameters"));
  const_exp_v1.build(const_exp_sh);
  const_exp_lab1.build(const_exp_v1, 
		      WHAT((char *) "Setting av konstant, "
			   "korrelasjon og evt. detaljert segmentvis "
			   "f�rkunnskap om eksponenter og konstant", 
			   (char *) "Specification of constant, "
			   "correlation and possibility for setting "
			   "detailed prior knowledge of constant and exponent "
			   "for each number of segments."
			   "and "));
  const_exp_h1.build(const_exp_v1);
  const_exp_v2.build(const_exp_h1);
  empty2.build(const_exp_v2,"");
  if(const_lab!=NULL)
    delete const_lab;
  const_lab=new srs_hypertext_label();	      
  const_lab->Create(const_exp_v2, SRSH_CONSTANT);
  a_startf.build(const_exp_h1, 8, 
		     WHAT((char *) "95 %% sannsynlighet for at "
			  "konstanten, C, (for det f�rste segmentet) "
			  "ligger mellom ",
			  (char *) "95%% probability that the "
			  "constant, C, (for the first segment) "
			  "lies between "));
  a_endf.build(const_exp_h1,8,WHAT((char *) " og ", (char *) " and "));
  a_startf.SetDouble(exp(get_overall_a_mu()-1.96*get_overall_a_sd()),4);
  a_endf.SetDouble(exp(get_overall_a_mu()+1.96*get_overall_a_sd()),4);
  show_a_prior.Create(const_exp_h1, WHAT((char *) "Plott C-f�rskunnskap", 
				   (char *) "Plot C prior"), 
		      SEG_INT_PLOT_A, this);
  
  const_exp_h2.build(const_exp_v1);
  const_exp_v3.build(const_exp_h2);
  empty3.build(const_exp_v3,"");
  if(corr_lab!=NULL)
    delete corr_lab;
  corr_lab=new srs_hypertext_label();	     
  corr_lab->Create(const_exp_v3, SRSH_CORR);
  corrf.build(const_exp_h2, 8, WHAT((char *) ":", 
			      (char *) ":"));
  corrf.SetDouble(get_overall_corr(),4);
  
  const_exp_h3.build(const_exp_v1);
  detailed_lin_tog.Create(const_exp_h3, WHAT((char *) "Detaljert spesifikasjon "
					     "av konstant og eksponent", 
					     (char *) "Detailed specification "
					     "of constant and exponent"),
			  SEG_INT_DETAILED_LIN, this);
  if(is_lin_detailed())
    detailed_lin_tog.switch_on();
  
  const_exp_sep.build(const_exp_v1);
  const_exp_h4.build(const_exp_v1);
  const_exp_closeb.build(const_exp_h4, &const_exp_sh,			 
			 WHAT((char *) "Lukk vindu", (char *) "Close vindow"));
  
  // WHAT((char *) "", (char *) "")


  fr_h0.build(v1);
  v_h0.build(fr_h0);
  h_h04.build(v_h0);
  //v_h01.build(h_h04);
  //empty10.build(v_h01,"");
  h0_label1.Create(h_h04, SRSH_ZEROSTAGE);
  h0_lab3.build(h_h04, WHAT((char *) "Har du en bunnvannstands-m�ling, kan "
			    "du sette f�rkunnskapen med 0.1m presisjon,\n"
			    "hvis ikke men du kjenner h�ydegrunnlaget, "
			    "kanskje 1-2m presisjon.", 
			    (char *) "If you have a zero stage measurement, "
			    "you can set the prior knowledge with 0.1m "
			    "precision,\nif not but you know the height "
			    "system, perhaps 1-2m precision."));
  //h0_lab.build(h_h04, WHAT((char *) "-f�rkunnskap:", 
  //(char *) " prior knowledge:"));
  h_h01.build(v_h0);
  //empty4.build(h0_v2,"");
  h01_startf.build(h_h01, 8, 
		   WHAT((char *) "95 %% sannsynlighet for at "
			"bunnvannstanden (for nedre segment), h01, "
			"ligger mellom ",
			(char *) "95%% probability that the zero-"
			    "stage (for the lowest segment), h01, "
			"lies between "));
  h01_endf.build(h_h01,8,WHAT((char *) " og ", (char *) " and "));
  if(!get_lognormal_h01())
    {
      h01_startf.SetDouble(get_h01_mu()-1.96*get_h01_sd(),4);
      h01_endf.SetDouble(get_h01_mu()+1.96*get_h01_sd(),4);
    }
  
  h_h04.build(v_h0);
  char *plottext2=get_padded_string(WHAT((char *) "Plott h01-f�rskunnskap", 
				       (char *) "Plot h01 prior"), 30);
  show_h01_prior.Create(h_h04, plottext2,
			SEG_INT_PLOT_H01, this);
  delete [] plottext2;
  h_h05.build(v_h0);
  char *detailed_text2=
    get_padded_string(WHAT((char *) "Avanserte bunnvannstands-spesifiseringer", 
			   (char *) "Advanced zero stage specifications"), 60);
  show_h0_adv.Create(h_h05, detailed_text2, 
		     SEG_H0_ADV, this);
  show_h0_adv.Background("yellow");
  delete [] detailed_text2;
  h0_adv_sh.build(*this, WHAT((char *) "Avanserte bunnvannstands-spesifiseringer", 
			      (char *) "Advanced zero stage specifications"));
  h0_adv_v1.build(h0_adv_sh);
  h0_adv_lab.build(h0_adv_v1, WHAT((char *) "Avanserte bunnvannstands-spesifiseringer, "
				   "inkludert absolutt maksimal bunnvannstand og segmentert "
				   "f�rkunnskap", 
			      (char *) "Advanced zero stage specifications, including absolute "
				   "maximal zero stage and segmented prior knowledge"));
  h0_adv_h1.build(h0_adv_v1);
  h0_adv_v2.build(h0_adv_h1);
  empty5.build(h0_adv_v2,"");
  h0_label3.Create(h0_adv_v2, SRSH_ZEROSTAGE3);
  lognormal_h01_tog.Create(h0_adv_h1, this, (bool) get_lognormal_h01());
  h01_maxf.build(h0_adv_h1, 8, "Max h01:");
  if(!get_lognormal_h01())
    h01_maxf.Unmap();
  else
    {
      h01_maxf.SetDouble(get_h01_max(),4);
      h01_startf.SetDouble(get_h01_max()-exp(get_h01_mu()+1.96*get_h01_sd()),4);
      h01_endf.SetDouble(get_h01_max()-exp(get_h01_mu()-1.96*get_h01_sd()),4);
    }
  
  h0_adv_h2.build(h0_adv_v1);
  h0_adv_v3.build(h0_adv_h2);
  empty6.build(h0_adv_v3,"");
  h0_label4.Create(h0_adv_v3, SRSH_ZEROSTAGE4);
  h02_startf.build(h0_adv_h2, 8, 
		   WHAT((char *) "95 %% sannsynlighet for at "
			"relativ teoretisk bunnvannstand "
			"for �vrige segmenter, h0, ligger mellom ",
			(char *) "95%% probability that the "
			"relative theoretical zero-stages "
			"for the upper segments, h0, lies between "));
  h02_endf.build(h0_adv_h2,8,WHAT((char *) " og ", (char *) " and "));
  h02_startf.SetDouble(get_h02_mu()-1.96*get_h02_sd(),4);
  h02_endf.SetDouble(get_h02_mu()+1.96*get_h02_sd(),4);
  show_h02_prior.Create(h0_adv_h2, WHAT((char *) "Plott relativ h0-f�rskunnskap", 
				    (char *) "Plot relative h0 prior"), 
			SEG_INT_PLOT_H02, this);
  detailed_h0_tog.Create(h0_adv_v1, WHAT((char *) "Detaljert spesifikasjon av h0", 
					 (char *) "Detailed specification of h0"),
			 SEG_INT_DETAILED_H0, this);
  if(is_h0_detailed())
    detailed_h0_tog.switch_on();
  h0_adv_sep.build(h0_adv_v1);
  h0_adv_h3.build(h0_adv_v1);
  h0_adv_closeb.build(h0_adv_h3, &h0_adv_sh,			 
		      WHAT((char *) "Lukk vindu", (char *) "Close vindow"));



  fr_hs.build(v1);
  v_hs.build(fr_hs);
  h_hs4.build(v_hs);
  hs_label1.Create(h_hs4, SRSH_SEG);
  hs_lab.build(h_hs4, 
	       WHAT((char *) "F�rkunnskap om segmenterings"
		    "vannstandene benytter "
		    "f�rkunnskap om vannf�ringene hvis "
		    "ikke detaljert spesifisering "
		    "blir gjort.", 
		    (char *) "Prior knowledge on the "
		    "segmentation stages uses "
		    "prio knowledge about the discharge "
		    "if no detailed specification "
		    "is performed."));
  h_hs1.build(v_hs);
  q_startf.build(h_hs1, 8, 
		 WHAT((char *) "95 %% sannsynlighet for at "
		      "vannf�ring, Q, ligger mellom ",
		      (char *) "95%% probability that the "
		      "discharge, Q, lies between "));
  q_endf.build(h_hs1,8,WHAT((char *) " og ", (char *) " and "));
  double minq=exp(get_mu_q()-1.96*get_sd_q()), 
    maxq=exp(get_mu_q()+1.96*get_sd_q());
  if(minq>0 && minq<1e+9)
    q_startf.SetDouble(exp(get_mu_q()-1.96*get_sd_q()),4);
  if(maxq>0 && maxq<1e+9)
    q_endf.SetDouble(exp(get_mu_q()+1.96*get_sd_q()),4);
  h_hs2.build(v_hs);
  show_q_prior.Create(h_hs2, WHAT((char *) "Plott vannf�rings-"
    "f�rskunnskap", 
    (char *) "Plot discharge prior"), 
    SEG_INT_PLOT_Q, this);
  char *detailed_text3=
    get_padded_string(WHAT((char *) "Avanserte segmenterings-"
			   "spesifiseringer", 
			   (char *) "Advanced segmentation "
			   "specifications"), 60);
  h_hs3.build(v_hs);
  start_hs_advb.Create(h_hs3, detailed_text3, 
		       SEG_HS_ADV, this);
  start_hs_advb.Background("yellow");
  delete [] detailed_text3;
  
  hs_adv_sh.build(*this, WHAT((char *) "Avanserte segmenterings-"
			      "spesifiseringer", 
			      (char *) "Advanced segmentation specifications"));
  hs_adv_v1.build(hs_adv_sh);
  hs_adv_lab.build(hs_adv_v1, WHAT((char *) "Avanserte segmenterings-"
				   "spesifiseringer.", 
				   (char *) "Advanced segmentation "
				   "specifications"));
  hs_adv_h1.build(hs_adv_v1);
  detailed_hs_tog.Create(hs_adv_h1, WHAT((char *) "Detaljert spesifikasjon "
					 "av segmenteringsvannstand", 
					 (char *) "Detailed specification "
					 "of segmentation stages"),
			 SEG_INT_DETAILED_HS, this);
  if(is_hs_detailed())
    detailed_hs_tog.switch_on();
  hs_adv_sep.build(hs_adv_v1);
  hs_adv_h2.build(hs_adv_v1);
  hs_adv_closeb.build(hs_adv_h2, &hs_adv_sh,			 
		      WHAT((char *) "Lukk vindu", (char *) "Close vindow"));

  prob_fr.build(v1);
  prob_v1.build(prob_fr);
  prob_label1.Create(prob_v1, SRSH_PROB_SEG);

  h1_prob.build(prob_v1);
  show_seg_prior1.Create(h1_prob, WHAT((char *) "Plott sannsynligheter "
				      "for antall segmenter", 
				      (char * ) "Plot the probabilities "
				      "for the number of segments"),
			 SEG_INT_PLOT_PROB, this);
  h2_prob.build(prob_v1);
  char *changeprobtext=
    get_padded_string(WHAT((char *) "Forandre sannsynligheter for "
			   "antall segmenter", 
			   (char *) "Change the probabilities for "
			   "the number of segments"), 60);
  detailed_prob.Create(h2_prob, changeprobtext,
		       SEG_INT_DETAILED_PROB, this);
  detailed_prob.Background("yellow");
  delete [] changeprobtext;
  //show_seg_prior1.Background("yellow");
  //show_seg_prior1.Foreground("black");

  sigmafr.build(v1);
  sigma_v1.build(sigmafr);
  h_s1.build(sigma_v1);
  sigma_label1.Create(h_s1, SRSH_SIGMA);
  h_s2.build(sigma_v1);
  sigma_startf.build(h_s2, 8, 
		     WHAT((char *) "95%% sannsynlighet for at st�yens "
			  "standardavvik (sigma) ligger mellom ",
			  (char *) "95%% probability that the standard "
			  "deviation (sigma) of the noise lies "
			  "between "));
  sigma_endf.build(h_s2, 8, WHAT((char *) " og ", (char *) " and "));
  sigma_startf.SetDouble(get_sigma_lower_cred(),3);
  sigma_endf.SetDouble(get_sigma_upper_cred(),3);
  h_s3.build(sigma_v1);
  show_sigma_prior.Create(h_s3, WHAT((char *) "Plott sigma-f�rkunnskap",
				     (char *) "Plott sigma prior"),
			  SEG_INT_PLOT_SIGMA, this);
  

  // Separator:
  sep1.build(v1);
  h_buttons.build(v1);

  acceptb.Create(h_buttons, WHAT((char *) "OK", (char *) "OK"), 
		 SEG_INT_OK, this);
  acceptb.Background("green");
  acceptb.Foreground("black");
  
  cancelb.Create(h_buttons, WHAT((char *) "Avbryt", 
				 (char *) "Cancel"), 
		 SEG_INT_CANCEL, this);
  cancelb.Background("red");
  cancelb.Foreground("white");
    //}
}
 
void segmented_rcurve_showpriors::show_pre_window_again(widget &parent_widget)
{
  parentpt=&parent_widget;
  make_mainwindow(get_min_seg(), get_max_seg());
  min_segf.SetDigit(get_min_seg());
  max_segf.SetDigit(get_max_seg());
  prewindow.Map();
}

void segmented_rcurve_showpriors::show_again(widget &parent_widget)
{
  parentpt=&parent_widget;
  make_mainwindow(get_min_seg(), get_max_seg());
  min_segf.SetDigit(get_min_seg());
  max_segf.SetDigit(get_max_seg());
  Map();
}

void segmented_rcurve_showpriors::show_again(void)
{
  make_mainwindow(get_min_seg(), get_max_seg());
  Map();
}

void segmented_rcurve_showpriors::show_again(double *stage, 
					     double *discharge, int len)
{
  //make_mainwindow(min_segf.getdigit(), max_segf.getdigit());
  make_mainwindow(get_min_seg(), get_max_seg());
  Map();
  set_h01_prior_from_data(stage,discharge,len);
}

void segmented_rcurve_showpriors::re_initialize(void)
{
  initialize();
  init_windows();
}
