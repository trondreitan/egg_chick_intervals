/*
 * $Id: workcursor.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/workcursor.C $
 */

#include <hydrasub/hydragui/widget.H>
#include <X11/cursorfont.h>

// remember previous cursor.
static Cursor work = 0;

// ######################################################################
// Return    : void
// Parameters: top_level - where to show the cursor
// Purpose   : this routine remember current cursor and change it to a
//             work cursor.
// ######################################################################
void AddWorkCursor(Widget top_level) {
    if(!work)
	work = XCreateFontCursor(XtDisplay(top_level), XC_watch);
    XDefineCursor (XtDisplay(top_level), XtWindow(top_level), work);
    XFlush (XtDisplay(top_level));
}

// ######################################################################
// Return    : void
// Parameters: top_level - where to show the cursor
// Purpose   : this routine switch back to original cursor, changed by
//             AddWorkCursor()
// ######################################################################
void RmWorkCursor(Widget top_level) {
    XUndefineCursor (XtDisplay(top_level), XtWindow(top_level));
    XFlush (XtDisplay(top_level));
}
