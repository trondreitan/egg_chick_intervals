/*
 * $Id: lineage.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/lineage.C $
 */

#include <hydrasub/hydragui/lineage.H>
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydrabase/divfunc.H>

// *******************************************
//                
//             LINEAGE
//
// This is a module meant for showing the
// properties of several entities that
// are related to one another (as in B is
// a child object of A). Used in evolution
// programs.
//
//            -Trond Reitan
//               5/8-2000
//
// *******************************************



void lineagebutton::Create(widget parent, char *txt,
                                 lineage *ipt, LINEAGE_TYPE type)
{
  pt=ipt;
  typ=type;
  build(parent, txt);
}

void lineagebutton::pushed(void)
{
  pt->button_pushed(typ);
}


lineage_entity::lineage_entity()
{
  val=NULL;
  time0=0;
  age=0;
  code='\0';
  parent1=parent2=NULL;
}


lineage_entity::~lineage_entity()
{
  if(val)
    delete [] val;
  val=NULL;
}


void lineage_entity::Create(int num_properties, double *property_values, 
			    double time_of_birth, double age_,
			    lineage_entity *parent_1,
			    lineage_entity *parent_2)
{
  val=new double[num_properties];
  for(int i=0;i<num_properties;i++)
    val[i]=property_values[i];

  parent1=parent_1;
  parent2=parent_2;
  time0=time_of_birth;
  age=age_;
}



// time of birth is property number -1
double lineage_entity::get_property(int num)
{
  if(num<0)
    return (double) time0;
  else
    return val[num];
}


double lineage_entity::get_time_of_birth(void) 
{
  return time0;
}


double lineage_entity::get_age(void)
{
  return age;
}


lineage_entity *lineage_entity::get_parent1(void)
{
  return parent1;
}


lineage_entity *lineage_entity::get_parent2(void)
{
  return parent2;
}



void lineage_entity::set_code(char newcode)
{
  code=newcode;
}


char lineage_entity::get_code(void)
{
  return code;
}



void lineage_plottoggle::Create(widget parent, char *txt, lineage *ipt)
{
  pt=ipt;
  build(parent, txt);
}


void lineage_plottoggle::pushed(bool)
{
  pt->toggle_pushed();
}

void lineage_plot::plot_ended(void)
{
  pt->plot_ended();
}


void lineage::toggle_pushed(void)
{
  if(plottog())
    {
      plotselfocus.Sensitive();
      plotlimitf.Sensitive();
    }
  else
    {
      plotselfocus.InSensitive();
      plotlimitf.InSensitive();
    }
}

void lineage::plot_ended(void)
{
  RmWorkCursor(plotsh);
}

void lineage::addpoint(double x, double y, double z)
{
  int xx=(int) (500.0*(x-x0)/(x1-x0)),
    yy=(int) (500.0*(y-y0)/(y1-y0));
  double  zz=((z-z0)/(z1-z0));
  double r,g,b;

  if(xx<0 || xx>500 || yy<0 || yy>500)
    return;

  if(zz<0.25)
    {
      r=255.0;
      g=255.0*(4.0*zz);
      b=0.0;
    }
  else if(zz<0.5)
    {
      r=255-255.0*(4.0*(zz-0.25));
      g=255.0;
      b=0.0;
    }
  else if(zz<0.75)
    {
      r=0.0;
      g=255.0;
      b=255.0*(4.0*(zz-0.5));
    }
  else
    {
      r=0.0;
      g=255-255.0*(4.0*(zz-0.75));
      b=255.0;
    }

  if(num[xx][yy]==0)
    {
      red[xx][yy]=r;
      green[xx][yy]=g;
      blue[xx][yy]=b;
    }
  else
    {
      red[xx][yy] = (num[xx][yy]*red[xx][yy] + r) / (num[xx][yy]+1.0);
      green[xx][yy] = (num[xx][yy]*green[xx][yy] + g) / (num[xx][yy]+1.0);
      blue[xx][yy] = (num[xx][yy]*blue[xx][yy] + b) / (num[xx][yy]+1.0);
    }

  num[xx][yy]++;
}

void lineage::addline(double xstart, double ystart, double zstart,
		      double xend, double yend, double zend)
{
  if((xstart<x0 && xend<x0) || (xstart>x1 && xend>xend) ||
     (ystart<y0 && yend<y0) || (ystart>y1 && yend>yend))
    return;

  double steps1=500.0*(xstart-xend)/(x1-x0);
  double steps2=500.0*(ystart-yend)/(y1-y0);

  if(steps1<0.0)
    steps1=-steps1;
  if(steps2<0.0)
    steps2=-steps2;

  int steps = 2*MAXIM((int) steps1, (int) steps2);

  for(int i=0;i<=steps;i++)
    {
      addpoint(xstart+i*(xend-xstart)/steps, ystart+i*(yend-ystart)/steps,
               zstart+i*(zend-zstart)/steps);
    }
}

double lineage::getvalue(lineage_entity *ptr, int selected)
{
  double val=ptr->get_property(selected);

  return val;
}

void lineage::set_show(lineage_entity *ptr)
{
  lineage_entity *par=(lineage_entity *) ptr->get_parent1();
  lineage_entity *par2=(lineage_entity *) ptr->get_parent2();

  if(par && par->get_time_of_birth()<10.0)
    {
      //cout << "debug" << endl;
    }

  ptr->set_code('y');

  if(par && par->get_code()=='n')
    set_show(par);

  if(par2 && par2->get_code()=='n')
    set_show(par2);
}

void lineage::do_draw(void)
{
  register int i;

  AddWorkCursor(*this);

  clear();

  if(show_who()==2)
    {
      for(i=0;i<numalive;i++)
        (aliveptr+i)->set_code('n');

      for(i=0;i<numdead;i++)
        (deadptr+i)->set_code('n');

      for(i=0;i<numalive;i++)
        set_show(aliveptr+i);
    }

  if(show_who()!=1)
    for(i=0;i<numdead;i++)
      if(show_who()==0 || (show_who()==2 && (deadptr+i)->get_code()=='y'))
        {
          double x_0, y_0, z_0, x_1, y_1, z_1, x_2, y_2, z_2;
	  lineage_entity *ptr=deadptr+i;

          x_1=ptr->get_property(xaxis);
          y_1=ptr->get_property(yaxis);
          z_1=ptr->get_property(zaxis);

          if(ptr->get_parent1())
            {
              x_0=ptr->get_parent1()->get_property(xaxis);
              y_0=ptr->get_parent1()->get_property(yaxis);
              z_0=ptr->get_parent1()->get_property(zaxis);
            }

	  if(ptr->get_parent2())
            {
              x_2=ptr->get_parent2()->get_property(xaxis);
              y_2=ptr->get_parent2()->get_property(yaxis);
              z_2=ptr->get_parent2()->get_property(zaxis);
            }

          if(plotpoints())
            addpoint(x_1, y_1, z_1);
          else if(yaxis==-1) // time plot
            {
              if(ptr->get_parent1())
                addline(x_0, y_1, z_0, x_1, y_1, z_1);
	      if(ptr->get_parent2())
		addline(x_2, y_1, z_2, x_1, y_1, z_1);
              addline(x_1, y_1, z_1, x_1, y_1 + (double) ptr->get_age(), z_1);
            }
	  else if(xaxis==-1) // time plot
            {
              if(ptr->get_parent1())
                addline(x_0, y_1, z_0, x_1, y_1, z_1);
	      if(ptr->get_parent2())
		addline(x_2, y_1, z_2, x_1, y_1, z_1);
              addline(x_1, y_1, z_1, x_1 + (double) ptr->get_age(), y_1, z_1);
            }
          else 
	    {
	      if(ptr->get_parent1())
		addline(x_0, y_0, z_0, x_1, y_1, z_1);
	      if(ptr->get_parent2())
		addline(x_2, y_2, z_2, x_1, y_1, z_1);
	    }
        }

  for(i=0;i<numalive;i++)
    {
      double x_0, y_0, z_0, x_1, y_1, z_1, x_2, y_2, z_2;
      lineage_entity *ptr=aliveptr+i;

      x_1=getvalue(ptr, xaxis);
      y_1=getvalue(ptr, yaxis);
      z_1=getvalue(ptr, zaxis);

      if(ptr->get_parent1())
        {
          x_0=getvalue((lineage_entity *) ptr->get_parent1(), xaxis);
          y_0=getvalue((lineage_entity *) ptr->get_parent1(), yaxis);
          z_0=getvalue((lineage_entity *) ptr->get_parent1(), zaxis);
        }

      if(ptr->get_parent2())
	{
	  x_2=ptr->get_parent2()->get_property(xaxis);
	  y_2=ptr->get_parent2()->get_property(yaxis);
	  z_2=ptr->get_parent2()->get_property(zaxis);
	}

      if(plotpoints())
	addpoint(x_1, y_1, z_1);
      else if(yaxis==-1) // time plot
	{
	  if(ptr->get_parent1())
	    addline(x_0, y_1, z_0, x_1, y_1, z_1);
	  if(ptr->get_parent2())
	    addline(x_2, y_1, z_2, x_1, y_1, z_1);
	  addline(x_1, y_1, z_1, x_1, y_1 + (double) ptr->get_age(), z_1);
	}
      else if(xaxis==-1) // time plot
	{
	  if(ptr->get_parent1())
	    addline(x_0, y_1, z_0, x_1, y_1, z_1);
	  if(ptr->get_parent2())
	    addline(x_2, y_1, z_2, x_1, y_1, z_1);
	  addline(x_1, y_1, z_1, x_1 + (double) ptr->get_age(), y_1, z_1);
	}
      else 
	{
	  if(ptr->get_parent1())
	    addline(x_0, y_0, z_0, x_1, y_1, z_1);
	  if(ptr->get_parent2())
	    addline(x_2, y_2, z_2, x_1, y_1, z_1);
	}
    }

  x0f.SetDouble(x0, 7);
  x1f.SetDouble(x1, 7);
  y0f.SetDouble(y0, 7);
  y1f.SetDouble(y1, 7);
  z0f.SetDouble(z0, 7);
  z1f.SetDouble(z1, 7);

  RmWorkCursor(*this);
}

void lineage::clear(void)
{
  int i,j;

  Clear("black");

  for(i=0; i<=500;i++)
    for(j=0; j<=500;j++)
      {
        red[i][j]=0.0;
        green[i][j]=0.0;
        blue[i][j]=0.0;
        num[i][j]=0;
      }
}

void lineage::DoButton1(int x , int y )
{
  if(!ready)
    {
      Beep(1);
      return;
    }

  double xx=x0 + (x1-x0) * ((double) (x-50)) / 500.0;
  double yy=y0 + (y1-y0) * ((double) (550-y)) / 500.0;
  double sizex=x1-x0, sizey=y1-y0;

  re_size *= 2.0;

  x0=xx-sizex/4.0;
  y0=yy-sizey/4.0;
  x1=xx+sizex/4.0;
  y1=yy+sizey/4.0;

  do_draw();
  expose();
}


void lineage::DoButton2(int x , int y )
{
  if(!ready)
    {
      Beep(1);
      return;
    }

  double xx=x0 + (x1-x0) * ((double) (x-50)) / 500.0;
  double yy=y0 + (y1-y0) * ((double) (550-y)) / 500.0;
  double sizex=x1-x0, sizey=y1-y0;

  re_size /= 2.0;

  if(re_size>1.0)
    {
      x0=xx-sizex;
      y0=yy-sizey;
      x1=xx+sizex;
      y1=yy+sizey;
      do_draw();
      expose();
    }
  else if(re_size==1.0)
    {
      find_default_limits();
      do_draw();
      expose();
    }
  else
    Beep(1);
}

void lineage::Boxed(int x_1, int y_1, int x_2, int y_2)
{
  double xx1=x0 + (x1-x0) * ((double) (x_1-50.0)) / 500.0;
  double yy1=y0 + (y1-y0) * ((double) (550.0-y_1)) / 500.0;
  double xx2=x0 + (x1-x0) * ((double) (x_2-50.0)) / 500.0;
  double yy2=y0 + (y1-y0) * ((double) (550.0-y_2)) / 500.0;

  x0=MINIM(xx1,xx2);
  x1=MAXIM(xx2,xx1);
  y0=MINIM(yy1,yy2);
  y1=MAXIM(yy1,yy2);
  
  do_draw();
  expose();
}

void lineage::DoButton3(int x , int y )
{
  if(!ready)
    {
      Beep(1);
      return;
    }

  double xx=x0 + (x1-x0) * ((double) (x-50)) / 500.0;
  double yy=y0 + (y1-y0) * ((double) (550-y)) / 500.0;
  char msg[1000];

  sprintf(msg, "x=%9.7f y=%9.7f", xx, yy);
  
  mess.build(mainwin::toplevel, "Message:", msg);
}


void lineage::DoUp()
{
  if(!ready)
    {
      Beep(1);
      return;
    }

  if(re_size==1.0)
    {
      Beep(1);
      return;
    }

  double sizey=y1-y0;
  y0 += 0.3*sizey;
  y1 += 0.3*sizey;

  do_draw();
  expose();
}


void lineage::DoDown()
{
  if(!ready)
    {
      Beep(1);
      return;
    }

  if(re_size==1.0)
    {
      Beep(1);
      return;
    }

  double sizey=y1-y0;
  y0 -= 0.3*sizey;
  y1 -= 0.3*sizey;

  do_draw();
  expose();
}


void lineage::DoLeft()
{
  if(!ready)
    {
      Beep(1);
      return;
    }

  if(re_size==1.0)
    {
      Beep(1);
      return;
    }

  double sizex=x1-x0;
  x0 -= 0.3*sizex;
  x1 -= 0.3*sizex;

  do_draw();
  expose();
}


void lineage::DoRight()
{
  if(!ready)
    {
      Beep(1);
      return;
    }

  if(re_size==1.0)
    {
      Beep(1);
      return;
    }

  double sizex=x1-x0;
  x0 += 0.3*sizex;
  x1 += 0.3*sizex;

  do_draw();
  expose();
}


void lineage::find_default_limits(void)
{
  lineage_entity *ptr;
  register int i;

  if(aliveptr)
    {
      x0=x1=aliveptr->get_property(xaxis);
      y0=y1=aliveptr->get_property(yaxis);
      z0=z1=aliveptr->get_property(zaxis);
    }
  else
    {
      x0=x1=deadptr->get_property(xaxis);
      y0=y1=deadptr->get_property(yaxis);
      z0=z1=deadptr->get_property(zaxis);
    }

  for(i=0;i<numdead;i++)
    {
      ptr=deadptr+i;
      x0=MINIM(x0, ptr->get_property(xaxis));
      y0=MINIM(y0, ptr->get_property(yaxis));
      z0=MINIM(z0, ptr->get_property(zaxis));
      x1=MAXIM(x1, ptr->get_property(xaxis));
      y1=MAXIM(y1, ptr->get_property(yaxis));
      z1=MAXIM(z1, ptr->get_property(zaxis));
    }

  for(i=0;i<numalive;i++)
    {
      ptr=aliveptr+i;
      x0=MINIM(x0, ptr->get_property(xaxis));
      y0=MINIM(y0, ptr->get_property(yaxis));
      z0=MINIM(z0, ptr->get_property(zaxis));
      x1=MAXIM(x1, ptr->get_property(xaxis));
      y1=MAXIM(y1, ptr->get_property(yaxis));
      z1=MAXIM(z1, ptr->get_property(zaxis));
    }

  if(yaxis==-1)
    {
      y0=0.0;
      y1=(double) run_len;
    }

  if(xaxis==-1)
    {
      x0=0.0;
      x1=(double) run_len;
    }

  if(zaxis==-1)
    {
      z0=0.0;
      z1=(double) run_len;
    }

  if(x1==x0)
    {
      x0-=0.01;
      x1+=0.01;
    }

  if(y1==y0)
    {
      y0-=0.01;
      y1+=0.01;
    }

  if(z1==z0)
    {
      z0-=0.01;
      z1+=0.01;
    }

  /*
  x0=x0-(x1-x0)*0.01;
  x1=x1+(x1-x0)*0.01;

  y0=y0-(y1-y0)*0.01;
  y1=y1+(y1-y0)*0.01;

  z0=z0-(z1-z0)*0.01;
  z1=z1+(z1-z0)*0.01;
  */
}


void lineage::button_pushed(LINEAGE_TYPE type)
{
  switch(type)
    {
    case LINEAGE_CLOSE:
      sh.Unmap();
      ended();
      break;
    case LINEAGE_PERFORM:
      showtree();
      break;
    case LINEAGE_STARTPLOT:
      plotsh.Map();
      toggle_pushed();
      break;
    case LINEAGE_PLOT:
      showgraph();
      break;
    }
}

void lineage::showgraph(void)
{
  bool dosplit=plottog();
  int numseries=dosplit ? 2 : 1;
  
  if(credband())
    numseries*=3;

  char **linetitles=new char*[numseries];
  int step=plotstepf.getdigit();
  int len=(int)(run_len/step+2);
  int *length=new int[numseries], *axis=new int[numseries];
  double **arg=new double*[numseries], **val=new double*[numseries];
  char **axistitles=new char*[2];
  int numax=2, k, focus=plotfocus.GetNumber(), stat=plotfocus_stat.GetNumber();
  int selfocus = dosplit ? plotselfocus.GetNumber() : 0; 
  double sellimit = dosplit ? plotlimitf.getdouble() : 0.0;
  register int i, j, t;

  if(stat==1 && focus==0)
    {
      err.build(mainwin::toplevel,
		WHAT((char *)"Feil", (char *) "Error"),
		WHAT((char *)"Kan ikke plotte variasjonen til antall dyr", 
		     (char *) "Can't plot the standard deviation of "
		     "the number of animals"));
      delete [] linetitles;
      delete [] length;
      delete [] arg;
      delete [] axis;
      delete [] axistitles;
      return;
    }

  for(i=0;i<numseries;i++)
    {
       linetitles[i]=new char[200];
       axis[i]=1;
       arg[i]=new double[len];
       val[i]=new double[len];
       length[i]=len;
    }

  if(!dosplit)
    {
      if(focus==0)
	sprintf(linetitles[0], "Number of entities");
      else
	sprintf(linetitles[0], "Mean %s", focusstr[focus]);

      if(credband())
	{
	  sprintf(linetitles[1], "Lower 95%% credibility band");
	  sprintf(linetitles[2], "Upper 95%% credibility band");
	}
    }
  else
    {
      if(focus==0)
	{
	  sprintf(linetitles[0], 
		  "Number of entities with property \"%s\" at or "
		  "below %9.7f", focusstr[selfocus+1], sellimit);
	  sprintf(linetitles[1], 
		  "Number of entities with property \"%s\" above "
		  "%9.7f", focusstr[selfocus+1], sellimit);
	}
      else
	{
	  sprintf(linetitles[0], 
		  "Mean %s for entities with property \"%s\" at or "
		  "below %9.7f", focusstr[focus], focusstr[selfocus+1], 
		  sellimit);
	  sprintf(linetitles[1], 
		  "Mean %s for entities with property \"%s\" above "
		  "%9.7f", focusstr[focus], focusstr[selfocus+1], 
		  sellimit);
	}

      if(credband())
	{
	  sprintf(linetitles[2], "Lower 95%% credibility band with "
		  "property \"%s\" at or below %9.7f", focusstr[selfocus+1], 
		  sellimit);
	  sprintf(linetitles[3], "Upper 95%% credibility band with "
		  "property \"%s\" at or below %9.7f", focusstr[selfocus+1], 
		  sellimit);
	  sprintf(linetitles[4], "Lower 95%% credibility band with "
		  "property \"%s\" above %9.7f", focusstr[selfocus+1], 
		  sellimit);
	  sprintf(linetitles[5], "Upper 95%% credibility band with "
		  "property \"%s\" above %9.7f", focusstr[selfocus+1], 
		  sellimit);
	}
    }

  axistitles[0]=new char[10];
  axistitles[1]=new char[30];
  strcpy(axistitles[0], "Time");
  strcpy(axistitles[1], focus==0 ? "#" : focusstr[focus]);
  
  
  double *vbuffer1=new double[100000]; // max number of beings possible to parse
  double *vbuffer2=new double[100000]; // max number of beings possible to parse

  for(t=0; t<=run_len; t+=step)
    {
      k=t/step;

      int vlen1=0, vlen2=0;

      for(i=0;i<numseries;i++)
	arg[i][k]=t;

      for(j=0;j<numalive+numdead;j++)
	{
	  lineage_entity *ptr = (j<numalive) ? aliveptr+j :
	    deadptr+(j-numalive);

	  double t0=ptr->get_time_of_birth(),
	    t1=t0+ptr->get_age();

	  if(t<t0 || t>t1)
	    continue; // the entity is of no concern right now

	  double thisval=ptr->get_property(focus-1);
	  double thisselval = dosplit ? ptr->get_property(selfocus) : 0.0;

	  if(dosplit)
	    {
	      if(thisselval<=sellimit)
		vbuffer1[vlen1++]=thisval;
	      else
		vbuffer2[vlen2++]=thisval;
	    }
	  else
	    vbuffer1[vlen1++]=thisval;
	}

      if(focus==0)
	{
	  val[0][k]=vlen1;
	  if(dosplit)
	    val[1][k]=vlen2;
	}
      else
	{
	  j=0;
	  if(stat==0)
	    val[j][k]=find_statistics(vbuffer1,vlen1,MEAN);
	  else
	    val[j][k]=find_statistics(vbuffer1,vlen1,STANDARD_DEVIATION);
	  j++;
	  if(dosplit)
	    {
	      if(stat==0)
		val[j][k]=find_statistics(vbuffer2,vlen2,MEAN);
	      else
		val[j][k]=find_statistics(vbuffer2,vlen2,STANDARD_DEVIATION);
	      j++;
	    }
	  if(credband())
	    {
	      val[j][k]=find_statistics(vbuffer1,vlen1,PERCENTILE_2_5);
	      j++;
	      val[j][k]=find_statistics(vbuffer1,vlen1,PERCENTILE_97_5);
	      j++;
	      if(dosplit)
		{
		  val[j][k]=find_statistics(vbuffer2,vlen2,PERCENTILE_2_5);
		  j++;
		  val[j][k]=find_statistics(vbuffer2,vlen2,PERCENTILE_97_5);
		  j++;
		}
	    }
	}
    }

  delete [] vbuffer1;
  delete [] vbuffer2;
  
  
  len=k;
  for(i=0;i<numseries;i++)
    length[i]=len;
  
  AddWorkCursor(plotsh);
  
  if(plot)
    delete plot;

  plot=new lineage_plot();
  plot->pt=this;
  plot->Create(arg, val, length, axis, linetitles, numseries, axistitles, 
	       numax);
  
  doubledelete(arg, numseries);
  doubledelete(val, numseries);
  doubledelete(linetitles, numseries);
  doubledelete(axistitles, 2);
  delete [] axis;
  delete [] length;
}

void lineage::showtree(void)
{
  xaxis=focus1()-1;
  yaxis=focus2()-1;
  zaxis=focus3()-1;

  if(xaxis == yaxis)
    {
      ready=False;
      err.build(mainwin::toplevel, "Error", 
		"Same focus on the first and second axis!");
      return;
    }

  if(xaxis==zaxis)
    {
      ready=False;
      err.build(mainwin::toplevel, "Error", 
		"Same focus on the first and third axis!");
      return;
    }

  if(yaxis == zaxis)
    {
      ready=False;
      err.build(mainwin::toplevel, "Error", 
		"Same focus on the second and third axis!");
      return;
    }
  
  ready=True;
  
  find_default_limits();

  do_draw();
  expose();
}


lineage::lineage() : draw()
{
  aliveptr=NULL;
  deadptr=NULL;
  ready=False;
  visited=False;
  made=False;
  numdead=numalive=numprop=0;
  focusstr=NULL;
  maxval=minval=NULL;
  plot=NULL;
}


lineage::~lineage()
{
  cleanup();
}


void lineage::cleanup(void)
{
  if(maxval)
    delete [] maxval;
  maxval=NULL;
  
  if(plot)
    delete plot;
  plot=NULL;

  if(minval)
    delete [] minval;
  minval=NULL;

  if(focusstr)
    doubledelete(focusstr, numprop);
  focusstr=NULL;

  numprop=0;

  if(aliveptr)
    delete [] aliveptr;
  aliveptr=NULL;
  numalive=0;

  if(deadptr)
    delete [] deadptr;
  deadptr=NULL;
  numdead=0;
  
}

void lineage::init(lineage_entity *alive_head, int num_alive, 
		   lineage_entity *dead_head, int num_dead, 
		   int num_properties, 
		   char **property_names, double run_length)
{
  int i,j;

  aliveptr=alive_head;
  numalive=num_alive;
  deadptr=dead_head;
  numdead=num_dead;
  numprop=num_properties+1;
  run_len=run_length;

  focusstr=new char*[numprop];
  focusstr[0]=new char[30];
  strcpy(focusstr[0], "Time");
  for(i=1;i<numprop;i++)
    {
      focusstr[i]=new char[30];
      strcpy(focusstr[i], property_names[i-1]);
    }

  re_size=1.0;
  for(i=0; i<=500;i++)
    for(j=0; j<=500;j++)
      {
        red[i][j]=0.0;
        green[i][j]=0.0;
        blue[i][j]=0.0;
        num[i][j]=0;
      }
}

// Creates the lineage window,s ending along alive and dead
// entities and the property names. The number of properties
// should be set in each individual entity.
// The entities will be deleted when this object is deleted or
// this method is called again.  Time is added to the list of properties
// automatically, and need not be listed.
void lineage::Create(lineage_entity *alive_head, int num_alive, 
		     lineage_entity *dead_head, int num_dead, 
		     int num_properties, 
		     char **property_names, double run_length)
{
  cleanup();
  init(alive_head, num_alive, dead_head, num_dead, num_properties, 
       property_names, run_length);
  
  ready=False;

  if(!visited)
    {
      sh.build(mainwin::toplevel, "Lineage tree");
      v1.build(sh);
      dobuild(True);
    }

  visited=True;

  sh.Map();
}

// Creates the lineage window,s ending along alive and dead
// entities and the property names. The number of properties
// should be set in each individual entity.
// The entities will be deleted when this object is deleted or
// this method is called again.  Time is added to the list of properties
// automatically, and need not be listed.
void lineage::Create(widget parent, 
		     lineage_entity *alive_head, int num_alive, 
		     lineage_entity *dead_head, int num_dead, 
		     int num_properties, 
		     char **property_names, double run_length)
{
  cleanup();
  init(alive_head, num_alive, dead_head, num_dead, num_properties, 
       property_names, run_length);
  
  ready=False;

  if(!visited)
    {
      fr.build(parent);
      v1.build(fr);
      dobuild(False);
    }

  visited=True;
}


void lineage::dobuild(bool shellwindow)
{
  char *strateg[]={"Show all","Show living",
		   "Show living and parents"};
     
  h1.build(v1);
  build(h1, 600, 600, True);
  
  v2.build(h1);
  h3.build(v2);
  if(numprop>15)
    {
      scr1.build(h3);
      scr2.build(h3);
      scr3.build(h3);
      scr1.Width(120);
      scr1.Height(450);
      scr2.Width(120);
      scr2.Height(450);
      scr3.Width(120);
      scr3.Height(450);
      focus1.vbuild(scr1, focusstr, numprop, 1);
      focus2.vbuild(scr2, focusstr, numprop, 0);
      focus3.vbuild(scr3, focusstr, numprop, 2);
    }
  else
    {
      focus1.vbuild(h3, focusstr, numprop, 1);
      focus2.vbuild(h3, focusstr, numprop, 0);
      focus3.vbuild(h3, focusstr, numprop, 2);
    }
    
  h4.build(v2);
  x0f.build(h4, 12, "x0:");
  x1f.build(h4, 12, "x1:");
  
  h5.build(v2);
  y0f.build(h5, 12, "y0:");
  y1f.build(h5, 12, "y1:");
  
  h6.build(v2);
  z0f.build(h6, 12, "z0:");
  z1f.build(h6, 12, "z1:");
  
  h2.build(v1);
  if(shellwindow)
    {
      closeb.Create(h2, "Close the window", this, LINEAGE_CLOSE);
      closeb.Background("red");
      closeb.Foreground("white");
    }
  performb.Create(h2, "Plot", this, LINEAGE_PERFORM);
  performb.Background("yellow");
  performb.Foreground("black");
  startplotb.Create(h2, "Graph", this, LINEAGE_STARTPLOT);
  show_who.hbuild(h2, strateg, 3, 0);
  plotpoints.build(h2, "Plot points");
  
  plotsh.build(mainwin::toplevel, "Plotting options");
  plotv1.build(plotsh);
  ploth1.build(plotv1);
  plottog.Create(ploth1, "Split the plot", this);
  plotlimitf.build(ploth1, 15, "Border value:");
  plotlimitf.SetDouble(0.5);
  plotselfocus.Create(ploth1, 
		      "Split above and below the given value for:");
  plotselfocus.Insert(focusstr+1, numprop-1);
  ploth2.build(plotv1);
  plotfocus_stat.Create(ploth2, "Plot ");
  char *stats[]={"mean","std. dev."};
  plotfocus_stat.Insert(stats,2);
  plotfocus.Create(ploth2, "value of this property:");
  strcpy(focusstr[0], "Number of beings");
  plotfocus.Insert(focusstr, numprop);
  strcpy(focusstr[0], "Time");
  plotstepf.build(ploth2, 15, "Sampling time step");
  plotstepf.SetDigit(4000);
  plotsep1.build(plotv1);
  ploth3.build(plotv1);
  credband.build(ploth3, "Show 95% credibility band?");
  plotokb.Create(ploth3, "OK", this, LINEAGE_PLOT);
  plotokb.Background("green");
  plotokb.Foreground("black");
  plotclose.build(ploth3, &plotsh, "Close the window");
  plotclose.Background("red");
  plotclose.Foreground("white");
}    

void lineage::expose(void)
{
  int x,y;
  char colstr[20], str[100];

  if(!ready)
    return;

  AddWorkCursor(*this);

  SetFg("white");
  for(x=50;x<=550; x++)
    Point(x, 550);

  for(y=50;y<550; y++)
    Point(49, y);

  if(!SetFont("-*-*-*-*-*-*-10-*-*-*-*-*-*-*"));
    //err.build(sh, WHAT("Feil", "Error"), "Klarte ikke � lage fonter!");
  else
    {
      sprintf(str, "%7.5g", x0);
      Text(str, 25, 560);
      sprintf(str, "%7.5g", x1);
      Text(str, 500, 560);
      sprintf(str, "%7.5g", y0);
      Text(str, 0, 530);
      sprintf(str, "%7.5g", y1);
      Text(str, 0, 50);
      Text(focusstr[xaxis+1], 250, 570);
      Text(focusstr[yaxis+1], 40, 40);
      sprintf(str, "(Color=%s)", focusstr[zaxis+1]);
      SetFg("red");
      Text(str, 350, 575);
    }

  for(x=0; x<=500; x++)
    for(y=0; y<=500; y++)
      if(num[x][y]>0)
        {
          sprintf(colstr, "#%02x%02x%02x",
                  (int) red[x][y], (int) green[x][y],( int) blue[x][y]);
          SetFg(colstr);
          Point(x+50,550-y);
        }

  RmWorkCursor(*this);
}


void lineage::ended(void)
{

}




