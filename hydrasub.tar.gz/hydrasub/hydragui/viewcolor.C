/*
 * $Id: viewcolor.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/viewcolor.C $
 */

#include <hydrasub/hydragui/viewcolor.H>

void viewcolor_button::Create(widget parent, const char *title, viewcolor *ipt, 
	    VIEWCOLOR_BTYPE type)
{
  pt=ipt;
  typ=type;
  build(parent, title);
}

void viewcolor_button::pushed(void)
{
  pt->button_pushed(typ);
}

void viewcolor_colorscale::Create(widget parent, const char *title, viewcolor *ipt, 
				  VIEWCOLOR_COLOR color)
{
  col=color;
  pt=ipt;
  build(parent, title, 0, 255, 0, 1);
}

void viewcolor_colorscale::changed(void)
{
  pt->scale_used(col, (*this)()); 
}

void viewcolor::button_pushed(VIEWCOLOR_BTYPE type)
{
  switch(type)
    {
    case VIEWCOLOR_EXIT:
      cancelled();
      break;
    case VIEWCOLOR_OK:
      ok(colorname, red, green, blue); 
      break;
    }
}

void viewcolor::scale_used(VIEWCOLOR_COLOR color, int newvalue)
{
  switch(color)
    {
    case VIEWCOLOR_RED:
      red=newvalue;
      break;
    case VIEWCOLOR_GREEN:
      green=newvalue;
      break;
    case VIEWCOLOR_BLUE:
      blue=newvalue;
      break;
    }

  sprintf(colorname, "#%02x%02x%02x", red, green, blue);
  colornamef.SetText(colorname);
  
  canvas.Background(colorname);
}

void viewcolor::domake(Widget parent)
{
  build(parent);
  h1.build(*this);
  
  redscale.Create(h1, "R�d", this, VIEWCOLOR_RED);
  greenscale.Create(h1, "Gr�nn", this, VIEWCOLOR_GREEN);
  bluescale.Create(h1, "Bl�", this, VIEWCOLOR_BLUE);
  canvas.build(h1, 200, 200);
  
  colornamef.build(*this, 7, "Farge-kode:");
  colornamef.EditAble(False);
  sep1.build(*this);
  h2.build(*this);
  
  okb.Create(h2, "OK", this, VIEWCOLOR_OK);
  okb.Background("green");
  okb.Foreground("black");

  exitb.Create(h2, "Avslutt", this, VIEWCOLOR_EXIT);
  exitb.Background("red");
  exitb.Foreground("white");

  red=green=blue=0;
}

void viewcolor::Create(Widget parent, const char *initcolor)
{
  domake(parent);
  setcolor(initcolor);
}

void viewcolor::Create(Widget parent, int initred, int initgreen, int initblue)
{
  domake(parent);
  setcolor(initred, initgreen, initblue);
}

void viewcolor::setcolor(int newred, int newgreen, int newblue)
{
  red=newred;
  green=newgreen;
  blue=newblue;
  sprintf(colorname, "#%02x%02x%02x", red, green, blue);

  redscale.SetValue(red);
  greenscale.SetValue(green);
  bluescale.SetValue(blue); 

  colornamef.SetText(colorname);
  
  canvas.Background(colorname);
}

void viewcolor::setcolor(const char *newcolor)
{
  unsigned int red_, green_, blue_;

  sscanf(newcolor+1, "%02x", &red_);
  sscanf(newcolor+3, "%02x", &green_);
  sscanf(newcolor+5, "%02x", &blue_);
  strcpy(colorname, newcolor);

  setcolor(red_, green_, blue_);
}


void viewcolor::ok(const char *, int , int , int )
{
}

void viewcolor::cancelled(void)
{
}

#ifdef MAIN

class viewcolor_main : public viewcolor
{
public:
  void ok(const char *color, int , int , int );
  void cancelled(void);
};

void viewcolor_main::ok(const char *color, int , int , int )
{
  cout << color << endl;
  exit(0);
}

void viewcolor_main::cancelled(void)
{
  exit(0);
}

int main(int argc, char **argv)
{
  mainwin mn("ViewColor 1.0",argc,argv);
  viewcolor_main vc;

  vc.Create(mn, "#ff00ff");
  mn.Run();
}

#endif // MAIN
