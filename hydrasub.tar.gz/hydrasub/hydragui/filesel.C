/*
 * $Id: filesel.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/filesel.C $
 */


#include <hydrasub/hydragui/filesel.H>
#include <hydrasub/hydragui/color.H>
#include <Xm/TextF.h>
#include <hydrasub/hydragui/mainwin.H>
#include <unistd.h>
#include <fstream>


const char *image_ext_name[]=
{ "eps","png","gif","jpg", /* "bmp","pcx", */
  "pict","pnm","rgb",
  "sun","tiff","xbm", "iris"
#ifdef PSTOPDF
  ,"pdf"
#endif
#ifdef PSTOEDIT
  , "svg", "tk", "pic", "xfig"
#endif
};

const char *image_name[]=
{"PostScript", "PNG", "Gif", "JPEG",
 //"BMP (Microsoft Bitmap)",
 //"PCX (ZSoft IBMPaintbrush fil",
 "PICT-file","PNM (Portabel bitmap)",
 "RGB (Raw red,green,blue file)","SUN rasterfile",
 "Tiff","XBM (X11 bitmap file, 2 colors)",
 "IRIS RGB-file"
#ifdef PSTOPDF
  ,"PDF"
#endif
#ifdef PSTOEDIT
  , "SVG", "TK (standalone program)", "PIC (troff format)", "XFIG"
#endif
};


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void filesel::build(const Widget parent, const char *dir) 
{
  //XmInitSetArg(XmNdirectory, dir);

  chdir(dir);
  //w=XmCreateFileSelectionDialog ( parent, "Fil-seleksjon", NULL,0);
  init("Fil-seleksjon", xmFileSelectionBoxWidgetClass, parent);
  
  XtVaSetValues(XmFileSelectionBoxGetChild(w, XmDIALOG_FILTER_TEXT),
		XmNbackground, motifsubcolors[BISQUE1], NULL);
  XtVaSetValues(XmFileSelectionBoxGetChild(w, XmDIALOG_DIR_LIST),
		XmNbackground, motifsubcolors[BISQUE1], NULL);
  XtVaSetValues(XmFileSelectionBoxGetChild(w, XmDIALOG_LIST),
		XmNbackground, motifsubcolors[BISQUE1], NULL);
  XtVaSetValues(XmFileSelectionBoxGetChild(w, XmDIALOG_TEXT),
		XmNbackground, motifsubcolors[BISQUE1], NULL);
  XtVaSetValues(XmFileSelectionBoxGetChild(w, XmDIALOG_OK_BUTTON),
		XmNbackground, motifsubcolors[BISQUE1], NULL);
  XtVaSetValues(XmFileSelectionBoxGetChild(w, XmDIALOG_APPLY_BUTTON),
		XmNbackground, motifsubcolors[BISQUE1], NULL);
  XtVaSetValues(XmFileSelectionBoxGetChild(w, XmDIALOG_CANCEL_BUTTON),
		XmNbackground, motifsubcolors[BISQUE1], NULL);


  XtAddCallback(w, XmNokCallback, (XtCallbackProc)okCB, (XtPointer)this);
  XtAddCallback(w, XmNcancelCallback, (XtCallbackProc)cancelCB, 
		(XtPointer)this);
  XtUnmanageChild(XmFileSelectionBoxGetChild(w, XmDIALOG_HELP_BUTTON));
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void filesel::okCB(Widget, filesel *pt, XmFileSelectionBoxCallbackStruct *p)
{
  char *filename;
  if(!XmStringGetLtoR(p->value, XmSTRING_DEFAULT_CHARSET, &filename))
    return;
  pt->ok(filename);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void filesel::cancelCB(Widget, filesel *pt, XtPointer) 
{
  pt->cancel();
}


const char *filesel::get_filename(void)
{
  Widget wtext=XmFileSelectionBoxGetChild(w, XmDIALOG_TEXT);

  return XmTextFieldGetString(wtext);
}

void filesel::set_filename(const char *filename)
{
  Widget wtext=XmFileSelectionBoxGetChild(w, XmDIALOG_TEXT);


  XtVaSetValues(wtext,XmNvalue,filename,NULL);
  //XmTextFieldSetString(w, filename);
}

const char *filesel::get_extension(void)
{
  char *ext=new char[100];
  const char *filename=get_filename();
  const char *ptr=filename+strlen(filename)-1;
  strcpy(ext,"");

  while((ptr>=filename) && *ptr!='/' && *ptr!='.')
    ptr--;

  if(*ptr=='.')
    strcpy(ext,ptr+1);

  delete[] filename;

  return ext;
}

void filesel::set_extension(const char *ext_name)
{
  const char *ext=get_extension();
  const char *filename=get_filename();
  char newfilename[1000];
 
  strcpy(newfilename, filename);

  if(*ext) // remove the prvious extension:
    newfilename[strlen(filename)-strlen(ext)-1]='\0';

  strcat(newfilename, ".");
  strcat(newfilename, ext_name);

  set_filename(newfilename);
}

IMAGE_TYPE image_selmenu::get_filetype_from_str(const char *str)
{
  for(int i=0;i<(int) NO_IMAGE_TYPE;i++)
    if(!strcmp(image_name[i],str))
      return (IMAGE_TYPE) i;
  return NO_IMAGE_TYPE;
}

void image_selmenu::create(widget parent, const char *title,image_filesel *ipt)
{
  pt=ipt;
  Create(parent,title);
  Insert(image_name,(int) NO_IMAGE_TYPE);
}

IMAGE_TYPE image_selmenu::get_filetype(void)
{
  return (IMAGE_TYPE) GetNumber();
}

void image_selmenu::pushed(const char *itemname)
{
  if(pt)
    pt->menu_pushed(get_filetype_from_str(itemname));
}



void image_filesel::menu_pushed(IMAGE_TYPE type)
{
  set_extension(image_ext_name[(int) type]);
}

void image_filesel::Create(const char *tempfilename,IMAGE_TYPE orig_type)
{
  sh.build(mainwin::toplevel,"Bilde-lagring");
  v1.build(sh);
  menu.create(v1,"Bilde-type:",this);
  build(v1);

  strcpy(tempfile,tempfilename);
  origtype=orig_type;
  sh.Map();
  
  menu.SetFocus((int) orig_type);
  set_extension(image_ext_name[(int) orig_type]);
}

void image_filesel::ok(const char *filename)
{
  char cmd[1000];
  IMAGE_TYPE type=menu.get_filetype();

  AddWorkCursor(sh);

  if(origtype==type)
    {
      sprintf(cmd,"mv %s %s",tempfile,filename);
      system(cmd);
    }
#ifdef PSTOPDF
  else if(origtype==EPS && type==PDF)
    {
      sprintf(cmd,"ps2pdf %s %s",tempfile,filename);
      system(cmd);
      sprintf(cmd,"rm %s",tempfile);
    }
#endif // PSTOPDF
#ifdef PSTOEDIT
  else if(is_vector_type(origtype) && is_vector_type(type))
    {
      DateTime now; now.now();
      char buffer2[1000],*ptr=now.syCh(2);

      sprintf(buffer2, "/tmp/fileselbuffer_%s_%ld.%s", ptr, random(),
	      image_ext_name[(int) type]);
      sprintf(cmd,"pstoedit -f %s %s %s",image_ext_name[(int) type],
	      tempfile,buffer2);
      system(cmd);

      if(type==SVG)
	{
	  sprintf(cmd, "sed s/\\&\\#36\\;/e/g %s > %s",
		  buffer2,filename);
	  system(cmd);
	  unlink(buffer2);
	}
      else
	{
	  sprintf(cmd, "mv %s %s", buffer2, filename);
	  system(cmd);
	}

      sprintf(cmd,"rm %s",tempfile);
      system(cmd);

      delete [] ptr;
    }
#endif // PSTOEDIT
  else if(!is_vector_type(origtype) && is_vector_type(type))
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kan ikke oversette bitmap til vektorgrafikk!", 
		     (char *) "Can't convert bitmap to vector graphics!"));
      return;
    }
  else
    {
      sprintf(cmd,"convert %s %s",tempfile,filename);
      system(cmd);
      sprintf(cmd,"rm %s",tempfile);
      system(cmd);
    }

  RmWorkCursor(sh);

  sh.Unmap();
}

void image_filesel::cancel(void)
{
  char cmd[1000];

  sprintf(cmd,"rm %s",tempfile);
  system(cmd);
  sh.Unmap();
}


bool is_vector_type(IMAGE_TYPE type)
{
  if(type==GIF || type==JPEG || type==PICT || type==PNM || type==RGB ||
     type==SUN || type==TIFF || type==XBM || type==IRIS || type==PNG)
    return False;
  else
    return True;
}



text_filesave::text_filesave()
{
  content=NULL;
}

text_filesave::~text_filesave()
{
  if(content)
    delete [] content;
  content=NULL;
}

void text_filesave::create(const char *content_)
{
  if(content)
    delete [] content;

  if(content_)
    {
      content=new char[strlen(content_)+2];
      strcpy(content, content_);
    }
  else
    content=NULL;

  sh.build(mainwin::toplevel, WHAT((char *) "Lagring av tekst", 
				   (char *) "Saving text"));
  v1.build(sh);
  build(v1);

  sh.Map();
}

void text_filesave::ok(const char *filename)
{
  if(!content)
    err.build(sh, WHAT((char *) "Feil", (char *) "Error"),
	      WHAT((char *) "Ingen tekst � lagre!", 
		   (char *) "No text to save!"));
  else
    {
	std::ofstream out;

	out.open(filename, std::ios::out);
      if(out.fail())
	{
	  err.build(sh, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Klarte ikke � lagre p� fila!", 
			 (char *) "Couldn't save the given file!"));
	  return;
	}

      out << content;

      out.close();

      sh.Unmap();
    }
}

void text_filesave::cancel(void)
{
  sh.Unmap();
}


