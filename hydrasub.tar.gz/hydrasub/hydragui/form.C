/*
 * $Id: form.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/form.C $
 */

#include <hydrasub/hydragui/form.H>

#include <Xm/Form.h>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void forms::build(const Widget parent) {
    XmNoArg;
    init("forms", xmFormWidgetClass, parent);
}
