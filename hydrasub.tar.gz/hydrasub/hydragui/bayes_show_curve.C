/*
 * $Id: bayes_show_curve.C 2692 2016-04-05 16:28:38Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/bayes_show_curve.C $
 */

#include <hydrasub/hydragui/bayes_show_curve.H>
#include <cmath>
#include <gsl/gsl_randist.h>
#include <hydrasub/hydrabase/linalg.H>
#include <hydrasub/hydrabase/bayesian_homogeneity.H>
#include <hydrasub/hydrabase/function_timer.H>


// *********************************************************
// 
//              GUI FOR SINGLE SEGMENT ANALYSIS
//
// *********************************************************

void bayes_mcmc_button::Create(widget parent, const char *txt, 
			       BAYES_MCMC_ACTION button_type,
			       bayes_mcmc_curve *ipt)
{
  type = button_type;
  pt = ipt;
  build(parent, txt);
}

void bayes_mcmc_button::pushed(void)
{
  pt->take_action(type);
}



void bayes_mcmc_curve::init(void)
{
  mtimes = NULL;
  extraplot = NULL;
  extrahist = NULL;
  param_names = NULL;
  num_times = 0;
}

void bayes_mcmc_curve::cleanup(void)
{
  if(mtimes)
    delete [] mtimes;
  if(extraplot)
    delete extraplot;
  if(extrahist)
    delete extrahist;
  if(param_names)
    doubledelete(param_names,5);
  init();
}

void bayes_mcmc_curve::estimate_discharge(void)
{
  double stage=stagef.getdouble();

  estsh.build(*this, WHAT((char *) "Estimert vannf�ring", 
			  (char *) "Estimated discharge"));
  estv1.build(estsh);
  estl1.build(estv1, WHAT((char *) "Vannstand: %7.3f", 
			  (char *) "Stage:     %7.3f"), stage);
  estl1.Background("white");

  if(show_mean)
    estl2.build(estv1, WHAT((char *) "Forventet vannf�ring:           %9.3f", 
			    (char *) "Expected  discharge:            %9.3f"), 
		rc.get_mean_discharge(stage));
  
  if(show_med)
    estl3.build(estv1, WHAT((char *) "Median vannf�ring:              %9.3f", 
			    (char *) "Median discharge:               %9.3f"),
		rc.get_discharge_percentile(stage, 0.5));
  
  if(show_p_mean)
    estl4.build(estv1, WHAT((char *) "Vannf�ring for forventet kurve: %9.3f", 
			    (char *) "Discharge for expected curve:   %9.3f"),
		rc.get_mean_coefficient_discharge(stage));
  
  if(show_p_med)
    estl5.build(estv1, WHAT((char *) "Vannf�ring for median kurve:    %9.3f", 
			    (char *) "Discharge for median curve:     %9.3f"),
		rc. get_median_coefficient_discharge(stage));
  
  if(show_cred)
    {
      estl6.build(estv1, 
		    WHAT((char *) "95%% troverdighetsintervall: "
			 "%9.3f - %9.3f", 
			 (char *) "95%% credibility interval:   "
			 "%9.3f - %9.3f"),
		    rc.get_discharge_percentile(stage, 0.025),
		    rc.get_discharge_percentile(stage, 0.975));
    }
  

  if(show_f)
    estl2.build(estv1, WHAT((char *) "Forventet vannf�ring:           %9.3f", 
			    (char *) "Expected discharge:             %9.3f"),
		fr.get_discharge(stage));

  estsep.build(estv1);
  esth1.build(estv1);
  estcloseb.build(esth1, &estsh, WHAT((char *) "Lukk vindu", 
				     (char *) "Close window")); 
  estcloseb.Background("red");
  estcloseb.Foreground("white");
  estsh.Map();
}

void bayes_mcmc_curve::estimate_stage(void)
{
  double discharge=dischargef.getdouble();

  estsh.build(*this, WHAT((char *) "Estimert vannstand", 
			  (char *) "Estimated stage"));
  estv1.build(estsh);
  estl1.build(estv1, WHAT((char *) "Vannf�ring: %7.3f", 
			  (char *) "Discharge:  %7.3f"), discharge);
  estl1.Background("white");
  
  if(show_mean)
    estl2.build(estv1, WHAT((char *) "Forventet vannstand:           %9.3f", 
			    (char *) "Expected stage:                %9.3f"), 
		rc.get_mean_stage(discharge));
  
  if(show_med)
    estl3.build(estv1, WHAT((char *) "Median vannstand:              %9.3f", 
			    (char *) "Median stage:                  %9.3f"),
		rc.get_stage_percentile(discharge, 0.5));
  
  if(show_p_mean)
    estl4.build(estv1, WHAT((char *) "Vannstand for forventet kurve: %9.3f", 
			    (char *) "Stage for expected curve:      %9.3f"),
		rc.get_mean_coefficient_stage(discharge));
  
  if(show_p_med)
    estl5.build(estv1, WHAT((char *) "Vannstand for median kurve:    %9.3f", 
			    (char *) "Stage for median curve:        %9.3f"),
		rc. get_median_coefficient_stage(discharge));
  
  if(show_cred)
    {
      estl6.build(estv1, 
		    WHAT((char *) "95%% troverdighetsintervall: "
			 "%9.3f - %9.3f", 
			 (char *) "95%% credibility interval:   "
			 "%9.3f - %9.3f"),
		    rc.get_stage_percentile(discharge, 0.025),
		    rc.get_stage_percentile(discharge, 0.975));

  
    }

  if(show_f)
    estl2.build(estv1, WHAT((char *) "Forventet vannstand:           %9.3f", 
			    (char *) "Expected stage:                %9.3f"),
		fr.get_stage(discharge));

  estsep.build(estv1);
  esth1.build(estv1);
  estcloseb.build(esth1, &estsh, WHAT((char *) "Lukk vindu", 
				     (char *) "Close window")); 
  estcloseb.Background("red");
  estcloseb.Foreground("white");
  estsh.Map();
}

void bayes_mcmc_curve::show_histogram(void)
{
  int histtype=histmenu.GetNumber(); // 0=a, 1=b, 2=c, 3=s^2
  double **val=new double*[1];
  char **linetitles=new char*[1];
  int *len=new int[1], i;

  if(extrahist)
    delete extrahist;
  extrahist=new histogram();
  
  linetitles[0]=new char[100];
  strcpy(linetitles[0], param_names[histtype]);
  len[0]=rc.get_number_of_drawings();

  val[0]=new double[len[0]];
  for(i=0;i<len[0];i++)
    {
      switch(histtype)
	{
	case 0:
	  val[0][i]=exp(rc.get_sampled_a()[i]);
	  break;
	case 1:
	  val[0][i]=rc.get_sampled_a()[i];
	  break;
	case 2:
	  val[0][i]=rc.get_sampled_b()[i];
	  break;
	case 3:
	  val[0][i]=-rc.get_sampled_c()[i];
	  break;
	case 4:
	  val[0][i]=sqrt(rc.get_sampled_sigma_squared()[i]);
	  break;
	default:
	  val[0][i]=MISSING_VALUE;
	  break;
	}
    }
  
  extrahist->set_x_axis_font_size(PLOT_FONT_LARGE);
  extrahist->set_y_axis_font_size(PLOT_FONT_MEDIUM);
  extrahist->set_outer_rectangle(False);
  extrahist->set_inner_rectangle(False);
  extrahist->set_big();
  extrahist->create(val, len, 1, linetitles, linetitles[0], 
		    WHAT((char *) "Hyppighet", (char *) "Frequency"));
  doubledelete(val, 1); 
  doubledelete(linetitles,1);
  delete [] len;
}

void bayes_mcmc_curve::show_scatter(void)
{
  int type1=scattermenu1.GetNumber(),type2=scattermenu2.GetNumber();
  
  if(type1==type2)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Du m� velge ulike parametre i "
		     "et spredningsplott!",
		     (char *) "You must choose different parameters in a "
		     "scatterplot"));
      return;
    }
  
  if(extraplot)
    delete extraplot;
  extraplot=new plot_shell();
  
  int i, len=rc.get_number_of_drawings(), axis=1;
  double *arg=new double[len], *val=new double[len];
  char *linetitle=new char[100], **axistitles=new char*[2];
  PLOTLINE_TYPE ptype=PLOTLINE_DOT;
  
  axistitles[0]=new char[100];
  strcpy(axistitles[0], param_names[type1]);
  axistitles[1]=new char[100];
  strcpy(axistitles[1], param_names[type2]);
  
  sprintf(linetitle, WHAT((char *) "%s mot %s", (char *) "%s against %s"),
	  param_names[type1],param_names[type2]);
  
  for(i=0;i<len;i++)
    {
      switch(type1)
	{
	case 0:
	  arg[i]=exp(rc.get_sampled_a()[i]);
	  break;
	case 1:
	  arg[i]=rc.get_sampled_a()[i];
	  break;
	case 2:
	  arg[i]=rc.get_sampled_b()[i];
	  break;
	case 3:
	  arg[i]=-rc.get_sampled_c()[i];
	  break;
	case 4:
	  arg[i]=sqrt(rc.get_sampled_sigma_squared()[i]);
	  break;
	default:
	  arg[i]=MISSING_VALUE;
	  break;
	}

      switch(type2)
	{
	case 0:
	  val[i]=exp(rc.get_sampled_a()[i]);
	  break;
	case 1:
	  val[i]=rc.get_sampled_a()[i];
	  break;
	case 2:
	  val[i]=rc.get_sampled_b()[i];
	  break;
	case 3:
	  val[i]=-rc.get_sampled_c()[i];
	  break;
	case 4:
	  val[i]=sqrt(rc.get_sampled_sigma_squared()[i]);
	  break;
	default:
	  val[i]=MISSING_VALUE;
	  break;
	}
    }

  extraplot->make_plotting_window(1000,800,WHAT((char *) "Spredningsplott", 
						(char *) "Scatter plot"));
  extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_outer_rectangle(False);
  extraplot->set_inner_rectangle(False);
  //extraplot->set_big();
  extraplot->Create(&arg, &val, &len, &axis, &linetitle, 1,
		    axistitles, 2, NULL, &ptype);

  doubledelete(axistitles,2);
  delete [] linetitle;
}

void bayes_mcmc_curve::show_residuals(void)
{
  int restype=residualtypemenu.GetNumber();
  int againsttype=residualagainstmenu.GetNumber();

  if(extraplot)
    delete extraplot;
  extraplot=new plot_shell();
  
  int i, j, len=rc.get_number_of_measurements();
  double *h=rc.get_stage_measurements(),
    *q=rc.get_discharge_measurements();
  double *predicted=new double[len], *res=new double[len];
  double *def_predicted=new double[len], *def_res=new double[len];
  int numplots=show_def ? 2 : 1;

  for(i=0;i<len;i++)
    {
      switch(restype)
	{
	case 0:
	  predicted[i]=rc.get_mean_discharge(h[i]);
	  if(show_def)
	    def_predicted[i]=df_rc.get_mean_discharge(h[i]);
	  break;
	case 1:
	  predicted[i]=rc.get_discharge_percentile(h[i],0.5);
	  if(show_def)
	    def_predicted[i]=df_rc.get_discharge_percentile(h[i],0.5);
	  break;
	case 2:
	  predicted[i]=rc.get_mean_coefficient_discharge(h[i]);
	  if(show_def)
	    def_predicted[i]=df_rc.get_mean_coefficient_discharge(h[i]);
	  break;
	case 3:
	  predicted[i]=rc.get_median_coefficient_discharge(h[i]);
	  if(show_def)
	    def_predicted[i]=df_rc.get_median_coefficient_discharge(h[i]);
	  break;
	default:
	  predicted[i]=MISSING_VALUE;
	  break;
	}
      
      if(predicted[i]!=MISSING_VALUE)
	res[i]=log(predicted[i]/q[i]);
      
      if(show_def && def_predicted[i]!=MISSING_VALUE)
	def_res[i]=log(def_predicted[i]/q[i]);
    }  
  
  int *num=new int[numplots], *axis=new int[numplots];
  double **arg=new double*[numplots], **val=new double*[numplots];
  char **linetitles=new char*[numplots], **axistitles=new char*[2];
  PLOTLINE_TYPE *ptype=new PLOTLINE_TYPE[numplots];

  for(j=0;j<numplots;j++)
    {
      num[j]=len;
      axis[j]=1;
      arg[j]=new double[len];
      val[j]=new double[len];
      linetitles[j]=new char[100];
      ptype[j]=PLOTLINE_DOT;
      
      if(j==0)
	sprintf(linetitles[j], WHAT((char *) "Residualer=log(m�lt "
				    "vannf�ring/predikert vannf�ring)", 
				    (char *) "Residuals=log(measured "
				    "discharge/predicted discharge)"));
      else
	sprintf(linetitles[j], WHAT((char *) "Residualer for "
				    "default prior", 
				    (char *) "Residuals for "
				    "default prior"));
      
      for(i=0;i<len;i++)
	{
	  switch(againsttype)
	    {
	    case 0:
	      arg[j][i]=predicted[i];
	      break;
	    case 1:
	      arg[j][i]=h[i];
	      break;
	    case 2:
	      arg[j][i]=double(i);
	      break;
	    case 3:
	      // Special handling
	      break;
	    default:
	      arg[j][i]=MISSING_VALUE;
	      break;
	    }
	  
	  if(j==0)
	    val[j][i]=res[i];
	  else
	    val[j][i]=def_res[i];
	}

    }

  axistitles[0]=new char[100];
  switch(againsttype)
    {
    case 0:
      strcpy(axistitles[0], WHAT((char *) "Predikert vannf�ring (m^3/s)", 
				 (char *) "Predicted discharge (m^3/s)"));
      break;
    case 1:
      strcpy(axistitles[0], WHAT((char *) "Vannstand (m)", 
				 (char *) "Stage (m)"));
      break;
    case 2:
      strcpy(axistitles[0], WHAT((char *) "Indeks", (char *) "Index"));
      break;
    case 3:
      strcpy(axistitles[0], WHAT((char *) "Tid", (char *) "Time"));
      break;
    default:
      strcpy(axistitles[0], WHAT((char *) "??? Uventet feil!",
				 (char *) "??? unknown error!"));
      break;
    }

  axistitles[1]=new char[100];
  strcpy(axistitles[1], "Res.");
  
  extraplot->make_plotting_window(1000,800,WHAT((char *) "Spredningsplott", 
						(char *) "Scatter plot"));
  extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_outer_rectangle(False);
  extraplot->set_inner_rectangle(False);
  //extraplot->set_big();
  if(againsttype==3)
    {
      DateTime **dt2=new DateTime*[numplots];
      for(j=0;j<numplots;j++)
	dt2[j]=mtimes;

      extraplot->Create(dt2, val, num, axis, linetitles, numplots,
			axistitles, 2, NULL, ptype);
      delete [] dt2;
    }
  else
    extraplot->Create(arg, val, num, axis, linetitles, numplots,
		      axistitles, 2, NULL, ptype);
  
  doubledelete(arg,numplots);
  doubledelete(val,numplots);
  doubledelete(axistitles,2);
  doubledelete(linetitles,numplots);
  delete [] axis;
  delete [] num;
  delete [] ptype;
}
  

void bayes_mcmc_curve::take_action(BAYES_MCMC_ACTION action)
{
  switch(action)
    {
    case BAYES_MCMC_ACCEPT:
      accept();
      sh.Unmap();
      break;
    case BAYES_MCMC_CANCEL:
      cancel();
      sh.Unmap();
      break;
    case BAYES_MCMC_HIST:
      show_histogram();
      break;
    case BAYES_MCMC_SCATTER:
      show_scatter();
      break;
    case BAYES_MCMC_RESIDUALS:
      show_residuals();
      break;
    case BAYES_MCMC_ESTIMATE_DISCHARGE:
      estimate_discharge();
      break;
    case BAYES_MCMC_ESTIMATE_STAGE:
      estimate_stage();
      break;
    default:
      break;
    }
}

bayes_mcmc_curve::bayes_mcmc_curve() : plot_module()
{
  init();
}

bayes_mcmc_curve::~bayes_mcmc_curve()
{
  cleanup();
}

void bayes_mcmc_curve::create(double *stage, double *discharge, int nummeas, 
			      int num_samples,
			      double est_exp, double sdev_exp,//prior exponent
			      double est_logconst, double sdev_logconst,
			      // prior log const.
			      double prior_a_b_correlation,
			      // prior of sigma�~neggamma(a,b);
			      double sigma_a, double sigma_b,
			      // prior for the non-linear parameter c:
			      BAYES_RATINGCURVE_C_PRIOR cprior,
			      double c_mean, double c_sdev,
			      double upper_stage, bool x_stage, 
			      DateTime *dt,

			      bool show_curve_mean, 
			      bool show_curve_median,
			      bool show_par_mean, 
			      bool show_par_median,
			      bool show_credibility,
			      bool show_defaults,
			      bool show_freq,
			      double default_est_exp_, 
			      double default_sdev_exp_, 
			      // default prior exponent
			      double default_est_logconst_, 
			      double default_sdev_logconst_, 
			      // default prior log const.
			      // default prior of sigma�~neggamma(a,b);
			      double default_sigma_a_, 
			      double default_sigma_b_,
			      double default_est_h0_, 
			      double default_sdev_h0_,
			      double default_corr_)
{
  int i,j;
  
  cleanup();

  if(dt)
    {
      num_times=nummeas;
      mtimes=new DateTime[num_times];
      for(i=0;i<num_times;i++)
	mtimes[i]=dt[i];
    }
  
  rc.draw_parameters(stage, discharge, nummeas, 
		     num_samples, est_exp, sdev_exp,
		     est_logconst, sdev_logconst,
		     prior_a_b_correlation, sigma_a, sigma_b, 
		     cprior, c_mean, c_sdev);
  if(show_defaults)
    df_rc.draw_parameters(stage, discharge, nummeas, 
			  num_samples, default_est_exp_, default_sdev_exp_,
			  default_est_logconst_, default_sdev_logconst_,
			  default_corr_, default_sigma_a_, default_sigma_b_, 
			  BAYES_RATINGCURVE_C_NORMAL, -default_est_h0_,
			  default_sdev_h0_);
  
  show_def=show_defaults;
  show_mean=show_curve_mean;
  show_med=show_curve_median;
  show_p_mean=show_par_mean;
  show_p_med=show_par_median;
  show_cred=show_credibility;
  show_f=show_freq;
  
  
  double e_a=rc.get_mean_a(), e_b=rc.get_mean_b(), e_c=rc.get_mean_c(); 
  double m_a=rc.get_median_a(), m_b=rc.get_median_b(), m_c=rc.get_median_c(); 
  
  double d_e_a=0.0, d_e_b=0.0, d_e_c=0.0, d_m_a=0.0, d_m_b=0.0, d_m_c=0.0;
  if(show_defaults)
    {
      d_e_a=df_rc.get_mean_a();
      d_e_b=df_rc.get_mean_b();
      d_e_c=df_rc.get_mean_c(); 
      d_m_a=df_rc.get_median_a();
      d_m_b=df_rc.get_median_b();
      d_m_c=df_rc.get_median_c(); 
    }
  

  // Make the main widgets;
  sh.build(mainwin::toplevel, WHAT((char *) "Kurve-resultat",
				   (char *) "Curve result"));
  v1.build(sh);
  put_in_widget(v1, 1000, 550, PLOT_IN_WIDGET_SHOWMAINMENU);
  set_grid(True);

  int numplots=0;
  if(show_curve_mean)
    numplots++;
  if(show_curve_median)
    numplots++;
  if(show_par_mean)
    numplots++;
  if(show_par_median)
    numplots++;
  if(show_credibility)
    numplots+=2;
  if(show_defaults)
    numplots*=2;
  if(show_freq)
    numplots++;
  numplots++;

  // Plotting variables;
  double **arg=new double*[numplots], **val=new double*[numplots];
  char **linetitles=new char*[numplots];
  char **axistitles=new char*[2];
  int *yaxis=new int[numplots], *len=new int[numplots];
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[numplots];
  
  // Make the plot;
  for(i=0;i<numplots;i++)
    linetitles[i]=new char[300];
  axistitles[0]=new char[100];
  axistitles[1]=new char[100];
  if(x_stage)
    {
      strcpy(axistitles[0], "m");
      strcpy(axistitles[1], "m^3/s");
    }
  else
    {
      strcpy(axistitles[1], "m");
      strcpy(axistitles[0], "m^3/s");
    }
    
  int index=0;

  if(show_curve_mean)
    strcpy(linetitles[index++], WHAT((char *) "Forventet kurve",
				     (char *) "Expected curve"));
  if(show_curve_median)
    strcpy(linetitles[index++], 
	   WHAT((char *) "Median kurve",
		(char *) "Median curve"));
  if(show_par_mean)
    sprintf(linetitles[index++], 
	    WHAT((char *) "Kurve fra forventede"
		 "parametre: h0=%7.3f, C=e^a=%7.3f, b=%7.3f", 
		 (char *) "Curve from expected parameters: "
		 "h0=%7.3f, C=e^a=%7.3f, b=%7.3f"),  
	    -e_c, exp(e_a), e_b); 
  if(show_par_median)
    sprintf(linetitles[index++], 
	    WHAT((char *) "Kurve fra median "
		 "parametre, h0=%7.3f, C=e^a=%7.3f, b=%7.3f", 
		 (char *) "Curve from median "
		 "parameters, h0=%7.3f, C=e^a=%7.3f, b=%7.3f"), 
	    -m_c, exp(m_a), m_b);
  if(show_credibility)
    {
      strcpy(linetitles[index++], 
	     WHAT((char *) "�vre grense for 95% "
		  "troverdighetsintervall",
		  (char *) "Upper limit for 95% credibility "
		  "interval"));
      strcpy(linetitles[index++], 
	     WHAT((char *) "Nedre grense for 95% "
		  "troverdighetsintervall",
		  (char *) "Lower limit for 95% credibility "
		  "interval"));
    }

  if(show_defaults)
    {
      if(show_curve_mean)
	strcpy(linetitles[index++], 
	       WHAT((char *) "Forventet kurve basert p� default prior-"
		    "fordeling",
		    (char *) "Expected curve based on default priors"));
      if(show_curve_median)
	strcpy(linetitles[index++], 
	       WHAT((char *) "Median kurve basert p� default prior-fordeling",
		    (char *) "Median curve based on default priors"));
      if(show_par_mean)
	sprintf(linetitles[index++], 
		WHAT((char *) "Kurve fra forventede parametre "
		     "basert p� default prior-fordeling: "
		     "h0=%7.3f, C=e^a=%7.3f, b=%7.3f", 
		     (char *) "Curve from expected parameters based on "
		     "default prios: "
		     "h0=%7.3f, C=e^a=%7.3f, b=%7.3f"), 
		-d_e_c, exp(d_e_a), d_e_b);
      if(show_par_median)
	sprintf(linetitles[index++], 
		WHAT((char *) "Kurve fra median parametre basert "
		     "p� default prior-fordeling: "
		     "h0=%7.3f, C=e^a=%7.3f, b=%7.3f", 
		     (char *) "Curve from median parameters based on "
		     "default priors: h0=%7.3f, C=e^a=%7.3f, b=%7.3f"), 
		-d_m_c, exp(d_m_a), d_m_b);
      if(show_credibility)
	{
	  strcpy(linetitles[index++], 
		 WHAT((char *) "�vre grense for 95% "
		      "troverdighetsintervall for default prior-fordeling",
		      (char *) "Upper limit for 95% credibility "
		      "interval for default priors"));
	  strcpy(linetitles[index++], 
		 WHAT((char *) "Nedre grense for 95% "
		      "troverdighetsintervall for default prior-fordeling",
		      (char *) "Lower limit for 95% credibility "
		      "interval for default priors"));
	}
    }

  if(show_freq)
    {
      fr.fit_curve(stage,discharge,nummeas);

      sprintf(linetitles[index++], WHAT((char *) "Frekventistisk prediksjon, "
					"h0=%f, C=e^a=%f, b=%f",
					(char *) "Frequentist prediction, "
					"h0=%f, C=e^a=%f, b=%f"), 
	      -fr.get_fitted_c(), exp(fr.get_fitted_a()), fr.get_fitted_b());
    }
  
  strcpy(linetitles[index++],
	 WHAT((char *) "M�linger", (char *) "Measurements"));
  
  double minh=find_statistics(stage, nummeas, MIN);
  double maxh=find_statistics(stage, nummeas, MAX);
  double x1=minh-5.0, x2=upper_stage==MISSING_VALUE ? maxh+5.0 : upper_stage;
  double step=0.05 ,x;
  int num;
  

  for(x=minh; x>=minh-100.0; x-=0.25)
    {
      double qm=rc.get_mean_discharge(x);
      double q_low=rc.get_discharge_percentile(x,0.025);
      
      if(qm<=0.000001 && q_low<=0.000001)
	{
	  x1=x;
	  break;
	}
    }
  x1-=0.1;
  num=(int) ceil((x2-x1)/step)+1;
   
  for(i=0;i<(numplots-1);i++)
    {
      arg[i]=new double[num];
      val[i]=new double[num];
      len[i]=num;
      type[i]=PLOTLINE_LINE;
      yaxis[i]=1;
    }
  
  arg[numplots-1]   = new double[nummeas];
  val[numplots-1]   = new double[nummeas];
  type[numplots-1]  = PLOTLINE_DOT;
  len[numplots-1]   = nummeas;
  yaxis[numplots-1] = 1;
  for(i=0;i<nummeas;i++)
    {
      arg[numplots-1][i]=stage[i];
      val[numplots-1][i]=discharge[i];
    }
  
  for(j=0;j<num;j++)
    {
      x=x1+step*double(j);
      
      for(i=0;i<(numplots-1);i++)
	arg[i][j]=x;
      
      index=0;
      if(show_curve_mean)
	val[index++][j]=rc.get_mean_discharge(x);
      if(show_curve_median)
	val[index++][j]=rc.get_discharge_percentile(x,0.5);
      if(show_par_mean)
	val[index++][j]=rc.get_mean_coefficient_discharge(x);
      if(show_par_median)
	val[index++][j]=rc.get_median_coefficient_discharge(x);
      if(show_credibility)
	{
	  val[index++][j]=rc.get_discharge_percentile(x,0.975);
	  val[index++][j]=rc.get_discharge_percentile(x,0.025);
	}
      if(show_defaults)
	{
	  if(show_curve_mean)
	    val[index++][j]=df_rc.get_mean_discharge(x);
	  if(show_curve_median)
	    val[index++][j]=df_rc.get_discharge_percentile(x,0.5);
	  if(show_par_mean)
	    val[index++][j]=df_rc.get_mean_coefficient_discharge(x);
	  if(show_par_median)
	    val[index++][j]=df_rc.get_median_coefficient_discharge(x);
	  if(show_credibility)
	    {
	      val[index++][j]=df_rc.get_discharge_percentile(x,0.975);
	      val[index++][j]=df_rc.get_discharge_percentile(x,0.025);
	    }
	}
      if(show_freq)
	val[index++][j]=fr.get_discharge(x);
    }

  char title[1000];
  sprintf(title, WHAT((char *) "Vannf�ringskurve - %s", 
		      (char *) "Rating curve - %s"), 
	  "Q(h) = C (h-h0)^b");
  
  if(x_stage)
    Create(arg, val, len, yaxis, linetitles, 
	   numplots, axistitles, 2, NULL /*title*/ , type);
  else
    Create(val, arg, len, yaxis, linetitles, 
	   numplots, axistitles, 2, NULL /*title*/ , type);
  
  doubledelete(arg,numplots);
  doubledelete(val,numplots);
  doubledelete(linetitles,numplots);
  doubledelete(axistitles,2);
  delete [] len;
  delete [] yaxis;
  delete [] type;

  fh1.build(v1);
  fr1.build(fh1);
  fv1.build(fr1);
  
  h2.build(fv1);

  char *params[]={WHAT((char *) "C=e^a : konstant", 
		       (char *) "C=e^a : constant"),
		  WHAT((char *) "a=log(C) : konstant", 
		       (char *) "a=log(C) : constant"),
		  WHAT((char *) "b : eksponent", 
		       (char *) "b : exponent"),
		  WHAT((char *) "h0 : nullvannf�rings-lokasjon",
		       (char *) "h0 : cease-flow location"),
		  WHAT((char *) "sigma : st�yst�rrelse",
		       (char *) "sigma : noise size")};
  param_names=new char*[5];
  for(i=0;i<5;i++)
    {
      param_names[i]=new char[100];
      strcpy(param_names[i], params[i]); 
    }

  histmenu.Create(h2, WHAT((char *) "Parameter:", 
			   (char *) "Parameter:"));
  histmenu.Insert(param_names,5);
  histb.Create(h2, WHAT((char *) "Vis histogram", 
			(char *) "Show histogram"), 
	       BAYES_MCMC_HIST, this);  
  
  
  h3.build(fv1);
  scattermenu1.Create(h3, WHAT((char *) "Vis ", (char *) "Show"));
  scattermenu1.Insert(param_names,5);
  scattermenu2.Create(h3, WHAT((char *) " mot ", (char *) "against"));
  scattermenu2.Insert(param_names,5);
  scatterb.Create(h3, WHAT((char *) "Vis spredningsplott", 
			   (char *) "Show scatterplot"), 
		  BAYES_MCMC_SCATTER, this);
  scattermenu1.SetFocus(0);
  scattermenu2.SetFocus(1);


  h4.build(fv1);
  reslab.build(h4, WHAT((char *) "Vis residualer fra", 
			(char *) "Show residuals from"));
  residualtypemenu.Create(h4, WHAT((char *) "basert p�", (char *) "based on"));
  char *restype[]={WHAT((char *) "Forventet vannf�ring", 
			(char *) "Expected discharge"),
		   WHAT((char *) "Median vannf�ring", 
			(char *) "Median discharge"),
		   WHAT((char *) "Vannf�ring fra forv. parametre", 
			(char *) "Discharge from exp. parameters"),
		   WHAT((char *) "Vannf�ring fra median parametre", 
			(char *) "Discharge from median parameters")};
  residualtypemenu.Insert(restype,4);
  residualagainstmenu.Create(h4, WHAT((char *) "mot", (char *) "against"));
  char *against[]={WHAT((char *) "Vannf�ring", (char *) "Discharge"),
		   WHAT((char *) "Vannstand", (char *) "Stage"),
		   WHAT((char *) "Indeks", (char *) "Index"),
		   WHAT((char *) "Tid", (char *) "Time")};
  residualagainstmenu.Insert(against, dt==NULL ? 3 : 4);
  resb.Create(h4, WHAT((char *) "Vis residualer", (char *) "Show residuals"), 
	      BAYES_MCMC_RESIDUALS, this);

  v2.build(fh1);
  fr2.build(v2);
  fv2.build(fr2);
  int plen=rc.get_number_of_drawings();
  double astart=find_statistics(rc.get_sampled_a(), plen, PERCENTILE_2_5);
  double aend=find_statistics(rc.get_sampled_a(), plen, PERCENTILE_97_5);
  double bstart=find_statistics(rc.get_sampled_b(), plen, PERCENTILE_2_5);
  double bend=find_statistics(rc.get_sampled_b(), plen, PERCENTILE_97_5);
  double cstart=find_statistics(rc.get_sampled_c(), plen, PERCENTILE_2_5);
  double cend=find_statistics(rc.get_sampled_c(), plen, PERCENTILE_97_5);
  double s2start=find_statistics(rc.get_sampled_sigma_squared(), 
				 plen, PERCENTILE_2_5);
  double s2end=find_statistics(rc.get_sampled_sigma_squared(), 
			       plen, PERCENTILE_97_5);
  
  plab.build(fv2, WHAT((char *) "95%% troverdighetsintervall for parametrene:",
		       (char *) "95%% credibility intervals for the "
		       "parameters:"));
  plab.Background("white");
  alab.build(fv2, "  %5.2f<C <%-5.2f ( => %5.2f<a <%-5.2f )",
	     exp(astart), exp(aend), astart, aend);
  blab.build(fv2, "  %5.2f<b <%-5.2f", bstart, bend);
  clab.build(fv2, "%7.2f<h0<%-7.2f", -cend, -cstart);
  slab.build(fv2, "  %5.2f<s <%-5.2f", sqrt(s2start), sqrt(s2end));
  
  h5.build(v2);
  stagef.build(h5, 5, WHAT((char *) "Vannstand:", (char *) "Stage:"));
  estqb.Create(h5, WHAT((char *) "Estimer vannf�ring", 
			(char *) "Estimate discharge"), 
	       BAYES_MCMC_ESTIMATE_DISCHARGE, this);
  h6.build(v2);
  dischargef.build(h6, 5, WHAT((char *) "Vannf�ring:", (char *) "Discharge:"));
  esthb.Create(h6, WHAT((char *) "Estimer vannstand", 
			(char *) "Estimate stage"), 
	       BAYES_MCMC_ESTIMATE_STAGE, this);

  h1.build(v1);
  acceptb.Create(h1, WHAT((char *) "Godta", (char *) "Accept"),
		 BAYES_MCMC_ACCEPT, this);
  acceptb.Background("green");
  acceptb.Foreground("black");
  closeb.Create(h1, WHAT((char *) "Avbryt", (char *) "Cancel"),
		BAYES_MCMC_CANCEL, this);
  closeb.Background("red");
  closeb.Foreground("white");

  sh.Map();
}


void bayes_mcmc_curve::plot_ended(void)
{
  cancel();
  sh.Unmap();
}
  
void bayes_mcmc_curve::cancel(void)
{
  // NOP
}

void bayes_mcmc_curve::accept(void)
{
  // NOP
}

















void bayes_show_button::Create(widget parent, const char *txt, 
			       BAYES_SHOW_ACTION action,
			       bayes_show_curve *ipt)
{
  pt=ipt;
  btype=action;
  build(parent, txt);
}

void bayes_show_button::pushed(void)
{
  pt->take_action(btype);
}


void bayes_show_curve::plot_x0(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  double *post_x0=segm.get_x0_probability(true);
  double *prior_x0=segm.get_x0_probability(false);
  
  int i, *yax=new int[4], *len=new int[4];
  char **linetitle=new char*[4], **axistitle=new char*[2];
  double **arg=new double*[4], **val=new double*[4];
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[4];

  axistitle[0]=new char[100];
  strcpy(axistitle[0], "x0");
  axistitle[1]=new char[100];
  strcpy(axistitle[1], "sannsynelighet");

  linetitle[0]=new char[200];
  strcpy(linetitle[0], "Sannsynelighet for x0 etter datah�ndtering (a "
	 "posteriori)");
  linetitle[1]=new char[200];
  strcpy(linetitle[1], "Sannsynelighet for x0 f�r datah�ndtering (a "
	 "priori)");
  linetitle[2]=new char[200];
  strcpy(linetitle[2], "Sannsynelighet for x0 etter datah�ndtering, MCMC");
  linetitle[3]=new char[200];
  strcpy(linetitle[3], "Sannsynelighet for x0 etter datah�ndtering, "
	 "hybrid MCMC");

  type[0]=type[1]=type[2]=type[3]=PLOTLINE_LINEDOT;
  len[0]=len[1]=len[2]=len[3]=num_x0;
  yax[0]=yax[1]=yax[2]=yax[3]=1;

  arg[0]=arg[1]=arg[2]=arg[3]=x0;
  val[0]=post_x0;
  val[1]=prior_x0;

  val[2]=new double[num_x0];
  for(i=0;i<num_x0;i++)
    val[2][i]=0.0;
  double min=x0[0], max=2*x0[num_x0-1]-x0[num_x0-2];
  for(i=0;i<num_iter;i++)
    {
      int index=(int) floor((-c_sim[i]-min)/(max-min)*double(num_x0));
      if(index>=0 && index<num_x0)
	val[2][index]++;
    }
  for(i=0;i<num_x0;i++)
    val[2][i]/=double(num_iter);

  val[3]=new double[num_x0];
  for(i=0;i<num_x0;i++)
    val[3][i]=0.0;
  for(i=0;i<num_hiter;i++)
    {
      int index=(int) floor((-c_hsim[i]-min)/(max-min)*double(num_x0));
      if(index>=0 && index<num_x0)
	val[3][index]++;
    }
  for(i=0;i<num_x0;i++)
    val[3][i]/=double(num_hiter);

  plot.Create(arg, val, len, yax, linetitle, 4, axistitle, 2,
	      NULL, type);

  doubledelete(axistitle,2);
  doubledelete(linetitle,4);
  delete [] arg;
  delete [] val[2];
  delete [] val[3];
  delete [] val;
  delete [] yax;
  delete [] len;
  delete [] type;
}

void bayes_show_curve::plot_x0_hist(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  double *post_x0=segm.get_x0_probability(true);
  int i,j,num=10000;
  double *cumulative_x0=new double[num_x0];
  double *prob=new double[num_x0], *prob2=new double[num_x0];
  double **coef=segm.sample_coefficients(num);
  
  for(i=0;i<num_x0;i++)
    prob[i]=0;
  
  cumulative_x0=segm.get_cumulative_x0_probability();
    //;post_x0[0];
    //for(i=1;i<num_x0;i++)
    //cumulative_x0[i]=cumulative_x0[i-1]+post_x0[i];
  
  for(i=0;i<num;i++)
    {
      double dr=drand48();
      
      for(j=1;j<num_x0;j++)
	if(dr>cumulative_x0[j-1] && dr<=cumulative_x0[j])
	  break;
      
      prob[j]++;
      
      for(j=1;j<num_x0;j++)
	if(x0[j-1]<coef[2][i] && x0[j]>=coef[2][i])
	  {
	    prob2[j]++;
	    break;
	  }
    }
  
  for(i=0;i<num_x0;i++)
    {
      prob[i]/=double(num);
      prob2[i]/=double(num);
    }

  FILE *p=popen("vvgraph", "w");
  fprintf(p, "# Column 1: brute force pdf\n");
  fprintf(p, "# Column 1 - type: dot+line\n");
  fprintf(p, "# Column 2: histogramme\n");
  fprintf(p, "# Column 2 - type: dot+line\n");
  fprintf(p, "# Column 3: histogramme2\n");
  fprintf(p, "# Column 3 - type: dot+line\n");
  fprintf(p, "##################\n");
  for(i=0;i<num_x0;i++)
    fprintf(p, "%f %f %f %f\n", x0[i], post_x0[i], prob[i],prob2[i]);
  pclose(p);

  delete [] prob;
  delete [] prob2;
  doubledelete(coef,4);
  delete [] cumulative_x0;
}


void bayes_show_curve::plot_exp_hist(void)
{
  int num=10000;
  double **coef=segm.sample_coefficients(num);

  //for(int i=0;i<num;i++)
  //cout << coef[1][i] << endl;

  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num;i++)
    fprintf(p, "%f\n", coef[1][i]);
  pclose(p);

  doubledelete(coef,4);
}


/*
void bayes_show_curve::plot_exp_hist(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  double *post_x0=segm.get_x0_probability(true);
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int i,j,num=10000;
  double *cumulative_x0=new double[num_x0];
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);

  cumulative_x0[0]=post_x0[0];
  for(i=1;i<num_x0;i++)
    cumulative_x0[i]=cumulative_x0[i-1]+post_x0[i];

  FILE *p=popen("histogramme", "w");
  for(i=0;i<num;i++)
    {
      double dr=drand48();
      for(j=1;j<num_x0;j++)
	if(dr>cumulative_x0[j-1] && dr<=cumulative_x0[j])
	  break;
      
      double a=reg_x0[j]->get_sigma_a();
      double b=reg_x0[j]->get_sigma_b();
      double sigma2=1.0/gsl_ran_gamma(rptr,a,1.0/b);
      double v22=reg_x0[j]->get_V_elem(1,1);
      double m2=reg_x0[j]->get_mean_coefficient(1);

      double ee=m2+sqrt(v22*sigma2)*gauss();
      
      fprintf(p, "%f\n", ee);
    }
  pclose(p);

  delete [] cumulative_x0;
}
*/

void bayes_show_curve::plot_log_exp_hist(void)
{
  int num=10000;
  double **coef=segm.sample_coefficients(num);

  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num;i++)
    if(coef[1][i]>0.0)
      fprintf(p, "%f\n", log(coef[1][i]));
  pclose(p);

  doubledelete(coef,4);
}

void bayes_show_curve::plot_log_sigma2_hist(void)
{
  int num=10000;
  double **coef=segm.sample_coefficients(num);

  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num;i++)
    if(coef[3][i]>0.0)
      fprintf(p, "%f\n", log(coef[3][i]));
  pclose(p);

  doubledelete(coef,4);
}


void bayes_show_curve::plot_log_c_hist(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  int num=10000;
  double **coef=segm.sample_coefficients(num);

  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num;i++)
    fprintf(p, "%f\n", log(x0[num_x0-1]-coef[2][i]));
  pclose(p);

  doubledelete(coef,4);
}

void bayes_show_curve::plot_x0_exp_dep(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int j, num=1000;
  double **coef1=segm.sample_coefficients(num),
    **coef2=segm.sample_coefficients(num,true);
  double hmin=segm.get_hmin();

  double x01=h0start.getdouble();
  double x02=h0end.getdouble();

  FILE *p=popen("vvgraph -x log\\(xm-x0\\) -y log\\(b\\)", "w");
  fprintf(p, "# Column 1: Sammenheng i forventningsverdier\n");
  fprintf(p, "# Column 2: Resamplinger fra a posteriori\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "# Column 3: Resamplinger fra normaltiln�rming\n");
  fprintf(p, "# Column 3 - type: dot\n");
  fprintf(p, "############################\n");
  for(j=0;j<num_x0;j++)
    if(reg_x0[j] && x0[j]>=x01 && x0[j]<=x02)
      {
	double m2=reg_x0[j]->get_mean_coefficient(1);
	
	if(hmin>x0[j])
	  {
	    if(m2>0.0)
	      fprintf(p, "%f %f -10000000 -10000000\n", 
		      log(hmin-x0[j]), log(m2));
	    else
	      fprintf(p, "%f -10000000 -10000000 -10000000\n", 
		      log(hmin-x0[j]));
	  }
      }

  for(j=0;j<num;j++)
    {
      if(hmin>coef1[2][j] && coef1[1][j]>0.0)
	fprintf(p, "%f -10000000 %f -10000000\n", log(hmin-coef1[2][j]), 
		log(coef1[1][j]));
      if(hmin>coef2[2][j] && coef2[1][j]>0.0)
	fprintf(p, "%f -10000000 -10000000 %f\n", log(hmin-coef2[2][j]), 
		log(coef2[1][j]));
    }

  pclose(p);

  doubledelete(coef1, 4);
  doubledelete(coef2, 4);
}

void bayes_show_curve::plot_x0_logconst_dep(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int j, num=1000;
  double **coef1=segm.sample_coefficients(num),
    **coef2=segm.sample_coefficients(num,true);
  double hmin=segm.get_hmin();
  
  double x01=h0start.getdouble();
  double x02=h0end.getdouble();

  FILE *p=popen("vvgraph -x log\\(xm-x0\\) -y a", "w");
  fprintf(p, "# Column 1: Sammenheng i forventningsverdier\n");
  fprintf(p, "# Column 2: Resamplinger fra a posteriori\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "# Column 3: Resamplinger fra normaltiln�rming\n");
  fprintf(p, "# Column 3 - type: dot\n");
  fprintf(p, "############################\n");
  for(j=0;j<num_x0;j++)
    if(reg_x0[j] && x0[j]>=x01 && x0[j]<=x02)
      {
	double m2=reg_x0[j]->get_mean_coefficient(0);
	
	if(hmin>x0[j])
	  fprintf(p, "%f %f -10000000 -10000000\n", log(hmin-x0[j]), m2);
      }

  for(j=0;j<num;j++)
    {
      if(hmin>coef1[2][j])
	fprintf(p, "%f -10000000 %f -10000000\n", 
		log(hmin-coef1[2][j]), coef1[0][j]);
      if(hmin>coef2[2][j])
	fprintf(p, "%f -10000000 -10000000 %f\n", 
		log(hmin-coef2[2][j]), coef2[0][j]);
    }

  pclose(p);

  doubledelete(coef1, 4);
  doubledelete(coef2, 4);
}

void bayes_show_curve::plot_x0_sigma2_dep(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int j, num=1000;
  double **coef1=segm.sample_coefficients(num),
    **coef2=segm.sample_coefficients(num,true);
  double hmin=segm.get_hmin();
  
  double x01=h0start.getdouble();
  double x02=h0end.getdouble();
  
  FILE *p=popen("vvgraph -x log\\(xm-x0\\) -y log\\(sigma�\\)", "w");
  fprintf(p, "# Column 1: Sammenheng i forventningsverdier\n");
  fprintf(p, "# Column 2: Resamplinger fra a posteriori\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "# Column 3: Resamplinger fra normaltiln�rming\n");
  fprintf(p, "# Column 3 - type: dot\n");
  fprintf(p, "############################\n");
  for(j=0;j<num_x0;j++)
    if(reg_x0[j] && x0[j]>=x01 && x0[j]<=x02)
      {
	double m2=reg_x0[j]->get_mean_square_standard_deviation();
	
	if(hmin>x0[j] && m2>0.0)
	  fprintf(p, "%f %f -10000000 -10000000\n", log(hmin-x0[j]), 
		  log(m2));
      }

  for(j=0;j<num;j++)
    {
      if(hmin>coef1[2][j] && coef1[3][j]>0.0)
	fprintf(p, "%f -10000000 %f -10000000\n", 
		log(hmin-coef1[2][j]), log(coef1[3][j]));
      if(hmin>coef2[2][j] && coef2[3][j]>0.0)
	fprintf(p, "%f -10000000 -10000000 %f\n", 
		log(hmin-coef2[2][j]), log(coef2[3][j]));
    }

  pclose(p);

  doubledelete(coef1, 4);
  doubledelete(coef2, 4);
}

void bayes_show_curve::plot_exp_logconst_dep(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int j, num=1000;
  double **coef1=segm.sample_coefficients(num),
    **coef2=segm.sample_coefficients(num,true);
  
  double x01=h0start.getdouble();
  double x02=h0end.getdouble();

  FILE *p=popen("vvgraph -x log\\(b\\) -y a", "w");
  fprintf(p, "# Column 1: Sammenheng i forventningsverdier\n");
  fprintf(p, "# Column 2: Resamplinger fra a posteriori\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "# Column 3: Resamplinger fra normaltiln�rming\n");
  fprintf(p, "# Column 3 - type: dot\n");
  fprintf(p, "############################\n");
  for(j=0;j<num_x0;j++)
    if(reg_x0[j] && x0[j]>=x01 && x0[j]<=x02)
      {
	double m1=reg_x0[j]->get_mean_coefficient(1);
	double m2=reg_x0[j]->get_mean_coefficient(0);
	
	if(m1>0.0)
	  fprintf(p, "%f %f -10000000 -10000000\n", log(m1), m2);
      }

  for(j=0;j<num;j++)
    {
      if(coef1[1][j]>0.0)
	fprintf(p, "%f -10000000 %f -10000000\n", 
		log(coef1[1][j]), coef1[0][j]);
      if(coef2[1][j]>0.0)
	fprintf(p, "%f -10000000 -10000000 %f\n", 
		log(coef2[1][j]), coef2[0][j]);
    }

  pclose(p);

  doubledelete(coef1, 4);
  doubledelete(coef2, 4);
}

void bayes_show_curve::plot_exp_sigma2_dep(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int j, num=1000;
  double **coef1=segm.sample_coefficients(num),
    **coef2=segm.sample_coefficients(num,true);
  
  double x01=h0start.getdouble();
  double x02=h0end.getdouble();

  FILE *p=popen("vvgraph -x log\\(b\\) -y log\\(sigma�\\)", "w");
  fprintf(p, "# Column 1: Sammenheng i forventningsverdier\n");
  fprintf(p, "# Column 2: Resamplinger fra a posteriori\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "# Column 3: Resamplinger fra normaltiln�rming\n");
  fprintf(p, "# Column 3 - type: dot\n");
  fprintf(p, "############################\n");
  for(j=0;j<num_x0;j++)
    if(reg_x0[j] && x0[j]>=x01 && x0[j]<=x02)
      {
	double m1=reg_x0[j]->get_mean_coefficient(1);
	double m2=reg_x0[j]->get_mean_square_standard_deviation();
	
	if(m1>0.0 && m2>0.0)
	  fprintf(p, "%f %f -10000000 -10000000\n", log(m1),log(m2));
      }

  for(j=0;j<num;j++)
    {
      if(coef1[1][j]>0.0 && coef1[3][j]>0.0)
	fprintf(p, "%f -10000000 %f -10000000\n", 
		log(coef1[1][j]), log(coef1[3][j]));
      if(coef2[1][j]>0.0 && coef2[3][j]>0.0)
	fprintf(p, "%f -10000000 -10000000 %f\n", 
		log(coef2[1][j]), log(coef2[3][j]));
    }

  pclose(p);

  doubledelete(coef1, 4);
  doubledelete(coef2, 4);
}

void bayes_show_curve::plot_logconst_sigma2_dep(void)
{
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int j, num=1000;
  double **coef1=segm.sample_coefficients(num),
    **coef2=segm.sample_coefficients(num,true);
  
  double x01=h0start.getdouble();
  double x02=h0end.getdouble();

  FILE *p=popen("vvgraph -x a -y log\\(sigma�\\)", "w");
  fprintf(p, "# Column 1: Sammenheng i forventningsverdier\n");
  fprintf(p, "# Column 2: Resamplinger fra a posteriori\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "# Column 3: Resamplinger fra normaltiln�rming\n");
  fprintf(p, "# Column 3 - type: dot\n");
  fprintf(p, "############################\n");
  for(j=0;j<num_x0;j++)
    if(reg_x0[j] && x0[j]>=x01 && x0[j]<=x02)
      {
	double m1=reg_x0[j]->get_mean_coefficient(0);
	double m2=reg_x0[j]->get_mean_square_standard_deviation();
	
	if(m2>0.0)
	  fprintf(p, "%f %f -10000000 -10000000\n", m1,log(m2));
      }

  for(j=0;j<num;j++)
    {
      if(coef1[3][j]>0.0)
	fprintf(p, "%f -10000000 %f -10000000\n", 
		coef1[0][j], log(coef1[3][j]));
      if(coef2[3][j]>0.0)
	fprintf(p, "%f -10000000 -10000000 %f\n", 
		coef2[0][j], log(coef2[3][j]));
    }

  pclose(p);

  doubledelete(coef1, 4);
  doubledelete(coef2, 4);
}

void bayes_show_curve::plot_logconst_hist(void)
{
  int num_x0=segm.get_number_of_x0();
  double *post_x0=segm.get_x0_probability(true);
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int i,j,num=10000;
  double *cumulative_x0=new double[num_x0];
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);

  cumulative_x0[0]=post_x0[0];
  for(i=1;i<num_x0;i++)
    cumulative_x0[i]=cumulative_x0[i-1]+post_x0[i];

  FILE *p=popen("histogramme", "w");
  for(i=0;i<num;i++)
    {
      double dr=drand48();
      for(j=1;j<num_x0;j++)
	if(dr>cumulative_x0[j-1] && dr<=cumulative_x0[j])
	  break;
      
      double a=reg_x0[j]->get_sigma_a();
      double b=reg_x0[j]->get_sigma_b();
      double sigma2=1.0/gsl_ran_gamma(rptr,a,1.0/b);
      double v11=reg_x0[j]->get_V_elem(0,0);
      double m2=reg_x0[j]->get_mean_coefficient(0);

      double ee=m2+sqrt(v11*sigma2)*gauss();
      
      fprintf(p, "%f\n", ee);
    }
  pclose(p);

  delete [] cumulative_x0;
}

void bayes_show_curve::plot_sigma2_hist(void)
{
  int num_x0=segm.get_number_of_x0();
  double *post_x0=segm.get_x0_probability(true);
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int i,j,num=10000;
  double *cumulative_x0=new double[num_x0];
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);

  cumulative_x0[0]=post_x0[0];
  for(i=1;i<num_x0;i++)
    cumulative_x0[i]=cumulative_x0[i-1]+post_x0[i];

  FILE *p=popen("histogramme", "w");
  for(i=0;i<num;i++)
    {
      double dr=drand48();
      for(j=1;j<num_x0;j++)
	if(dr>cumulative_x0[j-1] && dr<=cumulative_x0[j])
	  break;
      
      double a=reg_x0[j]->get_sigma_a();
      double b=reg_x0[j]->get_sigma_b();
      double sigma2=1.0/gsl_ran_gamma(rptr,a,1.0/b);
      
      fprintf(p, "%f\n", sigma2);
    }
  pclose(p);

  delete [] cumulative_x0;
}

void bayes_show_curve::plot_exp(void)
{
  int num_x0=segm.get_number_of_x0();
  double *post_x0=segm.get_x0_probability(true);
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  int num=4000, num2=800;
  int i, *yax=new int[3], *len=new int[3];
  double **arg=new double*[3], **val=new double*[3];
  double *exponent=new double[num], *prior=new double[num], 
    *post=new double[num];
  char **linetitle=new char*[3], **axistitle=new char*[2];
  static gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);

  axistitle[0]=new char[20];
  axistitle[1]=new char[20];
  strcpy(axistitle[0], "eksponent");
  strcpy(axistitle[1], "sanns.tetthet");

  linetitle[0]=new char[300];
  linetitle[1]=new char[300];
  linetitle[2]=new char[300];
  
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[3];
  
  type[0]=type[1]=type[2]=PLOTLINE_LINE;
  len[0]=len[1]=num;
  len[2]=num2;
  yax[0]=yax[1]=yax[2]=1;
  arg[0]=arg[1]=exponent;
  val[0]=post;
  val[1]=prior;
  arg[2]=new double[num2];
  val[2]=new double[num2];
  
  double post_mean=0.0, prior_mean=0.0;
  double post_max=0, prior_max=0, post_argmax, prior_argmax;
  double m0=segm.prior_exp(), a0=segm.prior_sigma_a(), 
    b0=segm.prior_sigma_b(), 
    v0=segm.prior_sdev_exp()*pow(segm.prior_sdev_exp(),2.0)*(2.0*a0-2.0); /// b0;
  double size=10.0*segm.prior_sdev_exp(), step=2.0*size/double(num-1);
  double step2=2.0*size/double(num2-1);
  
  double exp1=1.112, exp2=3.888;
  std::cout << cdf_student_t(m0,v0,2.0*a0,exp1) << " " << 
    cdf_student_t(m0,v0,2.0*a0,exp2) << std::endl;
  
  for(i=0;i<num2;i++)
    {
      arg[2][i]=-size+m0+double(i)*step2;
      val[2][i]=0.0;
    }
  
  int outside=0;
  double start=arg[2][0], end=arg[2][num2-1];
  for(i=0;i<10000;i++)
    {
      double sigma2=1.0/gsl_ran_gamma(rptr,a0,1.0/b0);
      double m2=reg_x0[1]->get_mean_coefficient(1,false);
      double v2=reg_x0[1]->get_V_elem(1,1,false);
      double s2=sqrt(v2/2.0/b0*sigma2);
      double sample=m2+s2*gauss();
      int index=(int) floor((sample-start)/(end-start)*double(num2));

      if(sample<1.112 || sample>3.888)
	outside++;
      
      if(index>=0 && index<num2)
	val[2][index]++;
    }
  
  std::cout << "Rate p� utsiden:" << double(outside)/100.0 << "%" << std::endl;

  for(i=0;i<num2;i++)
    val[2][i]=val[2][i]/(step2*double(10000));

  for(i=0;i<num;i++)
    {
      double x=-size+m0+double(i)*step;
      exponent[i]=x;

      prior[i]=pdf_student_t(m0, v0, 2.0*a0, x); 
	//exp(gamma((a0+1.0)/2.0)-gamma(a0/2.0)-0.5*log(v0*M_PI)-
	//	   (a0+1.0)/2.0*log(1.0+(x-m0)*(x-m0)/v0));
      // student-t with mean=m, variance-parameter v and 'a' degrees of freedom

      post[i]=0;
      
      for(int j=0;j<num_x0;j++)
	if(reg_x0[j])
	  {
	    double a=reg_x0[j]->get_sigma_a();
	    double b=reg_x0[j]->get_sigma_b();
	    double m=reg_x0[j]->get_mean_coefficient(1);
	    double v=b*
	      reg_x0[j]->get_covariance_coefficient(1,1,true,false);
	    
	    post[i]+=post_x0[j]*pdf_student_t(m, v, 2.0*a,x);
	    // exp(gamma((a+1.0)/2.0)-gamma(a/2.0)-0.5*log(v*M_PI)-
	    //   (a+1.0)/2.0*log(1.0+(x-m)*(x-m)/v));
	    
	  }

      post_mean+=x*post[i]*step;
      prior_mean+=x*prior[i]*step;

      if(post[i]>post_max)
	{
	  post_max=post[i];
	  post_argmax=x;
	}

      if(prior[i]>prior_max)
	{
	  prior_max=prior[i];
	  prior_argmax=x;
	}
    }
  
  sprintf(linetitle[0], "Sannsynelighetstetthet for eksponent etter "
	  "databehandling (max=%7.5f mean=%7.5f)", post_argmax, post_mean);
  sprintf(linetitle[1], "Sannsynelighetstetthet for eksponent f�r   "
	  "databehandling (max=%7.5f mean=%7.5f)", prior_argmax, prior_mean);
  sprintf(linetitle[2], "Histogram for eksponent f�r   "
	  "databehandling (max=%7.5f mean=%7.5f)", prior_argmax, prior_mean);

  plot.Create(arg, val, len, yax, linetitle, 3,axistitle,2,NULL, type);

  delete [] exponent;
  delete [] post;
  delete [] prior;
  delete [] arg[2];
  delete [] val[2];
  delete [] arg;
  delete [] val;
  delete [] type;
  delete [] yax;
  delete [] len;
  doubledelete(axistitle,2);
  doubledelete(linetitle,3);
}

void bayes_show_curve::plot_logconst(void)
{
  int num_x0=segm.get_number_of_x0();
  double *post_x0=segm.get_x0_probability(true);
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();

  int num=4000;
  int i, *yax=new int[2], *len=new int[2];
  double **arg=new double*[2], **val=new double*[2];
  double *logconst=new double[num], *prior=new double[num], 
    *post=new double[num];
  char **linetitle=new char*[2], **axistitle=new char*[2];
  
  axistitle[0]=new char[20];
  axistitle[1]=new char[20];
  strcpy(axistitle[0], "log(konstant)");
  strcpy(axistitle[1], "sanns.tetthet");

  linetitle[0]=new char[300];
  linetitle[1]=new char[300];

  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[2];

  type[0]=type[1]=PLOTLINE_LINE;
  len[0]=len[1]=num;
  yax[0]=yax[1]=1;
  arg[0]=arg[1]=logconst;
  val[0]=post;
  val[1]=prior;

  double post_mean=0.0, prior_mean=0.0;
  double post_max=0, prior_max=0, post_argmax, prior_argmax;
  double m0=segm.prior_logconst(), a0=segm.prior_sigma_a(), 
    b0=segm.prior_sigma_b(), 
    v0=segm.prior_sdev_logconst()*segm.prior_sdev_logconst()*(a0-2.0)/b0;
  double size=10.0*segm.prior_sdev_logconst(), step=2.0*size/double(num-1);
  
  for(i=0;i<num;i++)
    {
      double x=-size+m0+double(i)*step;
      logconst[i]=x;

      prior[i]=pdf_student_t(m0, v0, 2.0*a0, x);
	//exp(gamma((a0+1.0)/2.0)-gamma(a0/2.0)-0.5*log(v0*M_PI)-
	//   (a0+1.0)/2.0*log(1.0+(x-m0)*(x-m0)/v0));
      // student-t with mean=m, variance-parameter v and 'a' degrees of freedom

      post[i]=0;

      for(int j=0;j<num_x0;j++)
	if(reg_x0[j])
	  {
	    double a=reg_x0[j]->get_sigma_a();
	    double b=reg_x0[j]->get_sigma_b();
	    double m=reg_x0[j]->get_mean_coefficient(0);
	    double v=b*
	      reg_x0[j]->get_covariance_coefficient(0,0,true,false);

	    post[i]+=post_x0[j]*pdf_student_t(m, v, 2.0*a, x);
	    //exp(gamma((a+1.0)/2.0)-gamma(a/2.0)-0.5*log(v*M_PI)-
	    //   (a+1.0)/2.0*log(1.0+(x-m)*(x-m)/v));
	    
	  }

      post_mean+=x*post[i]*step;
      prior_mean+=x*prior[i]*step;

      if(post[i]>post_max)
	{
	  post_max=post[i];
	  post_argmax=x;
	}

      if(prior[i]>prior_max)
	{
	  prior_max=prior[i];
	  prior_argmax=x;
	}
    }
  
  sprintf(linetitle[0], "Sannsynelighetstetthet for log(konstant) etter "
	  "databehandling (max=%7.5f mean=%7.5f)", post_argmax, post_mean);
  sprintf(linetitle[1], "Sannsynelighetstetthet for log(konstant) f�r   "
	  "databehandling (max=%7.5f mean=%7.5f)", prior_argmax, prior_mean);

  plot.Create(arg, val, len, yax, linetitle, 2,axistitle,2,NULL, type);

  delete [] logconst;
  delete [] post;
  delete [] prior;
  delete [] arg;
  delete [] val;
  delete [] type;
  delete [] yax;
  delete [] len;
  doubledelete(axistitle,2);
  doubledelete(linetitle,2);
}

void bayes_show_curve::plot_sigma2(void)
{
  int num_x0=segm.get_number_of_x0();
  double *post_x0=segm.get_x0_probability(true);
  bayesian_regression **reg_x0=segm.get_x0_specific_regression();
  
  int num=1000;
  int i, *yax=new int[2], *len=new int[2];
  double **arg=new double*[2], **val=new double*[2];
  double *sigma2=new double[num], *prior=new double[num], 
    *post=new double[num];
  char **linetitle=new char*[2], **axistitle=new char*[2];

  axistitle[0]=new char[20];
  axistitle[1]=new char[20];
  strcpy(axistitle[0], "sigma�");
  strcpy(axistitle[1], "Sannsynelighet");

  linetitle[0]=new char[300];
  linetitle[1]=new char[300];

  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[2];

  type[0]=type[1]=PLOTLINE_LINEDOT;
  len[0]=len[1]=num;
  yax[0]=yax[1]=1;
  arg[0]=arg[1]=sigma2;
  val[0]=post;
  val[1]=prior;

  double post_mean=0.0, prior_mean=0.0;
  double post_max=0, prior_max=0, post_argmax, prior_argmax;
  double sigma_a=segm.prior_sigma_a(), sigma_b=segm.prior_sigma_b();

  for(i=0;i<num;i++)
    {
      double x=double(i+1)*0.0001;
      sigma2[i]=x;
      prior[i]=exp(sigma_a*log(sigma_b)-(sigma_a+1.0)*log(x)-
		   sigma_b/x-gamma(sigma_a))*0.0001;
      post[i]=0;

      for(int j=0;j<num_x0;j++)
	if(reg_x0[j])
	  {
	    double a=reg_x0[j]->get_sigma_a();
	    double b=reg_x0[j]->get_sigma_b();
	    post[i]+=post_x0[j]*
	      exp(a*log(b)-(a+1.0)*log(x)-b/x-gamma(a))*0.0001;
	  }

      post_mean+=x*post[i];
      prior_mean+=x*prior[i];

      if(post[i]>post_max)
	{
	  post_max=post[i];
	  post_argmax=x;
	}

      if(prior[i]>prior_max)
	{
	  prior_max=prior[i];
	  prior_argmax=x;
	}
    }
  
  sprintf(linetitle[0], "Sannsynelighet for sigma� etter databehandling " 
	  "(max=%7.5f mean=%7.5f)", post_argmax, post_mean);
  sprintf(linetitle[1], "Sannsynelighet for sigma�~neg_gamma(%7.3f, %7.3f) "
	  "f�r databehandling (max=%7.5f mean=%7.5f)", sigma_a, sigma_b,
	  prior_argmax, prior_mean);

  plot.Create(arg, val, len, yax, linetitle, 2,axistitle,2,NULL, type);

  delete [] sigma2;
  delete [] post;
  delete [] prior;
  delete [] arg;
  delete [] val;
  delete [] type;
  delete [] yax;
  delete [] len;
  doubledelete(axistitle,2);
  doubledelete(linetitle,2);
}


void bayes_show_curve::init(void)
{
}

void bayes_show_curve::cleanup(void)
{
  init();
}


void bayes_show_curve::take_action(BAYES_SHOW_ACTION action)
{
  switch(action)
    {
    case BAYES_SHOW_ACCEPT:
      accept();
      sh.Unmap();
      break;
    case BAYES_SHOW_CANCEL:
      cancel();
      sh.Unmap();
      break;
    case BAYES_SHOW_PLOT_X0: 
      plot_x0();
      break;
    case BAYES_SHOW_PLOT_EXP:
      plot_exp();
      break;
    case BAYES_SHOW_PLOT_LOGCONST:
      plot_logconst();
      break;
    case BAYES_SHOW_PLOT_SIGMA2:
      plot_sigma2();
      break;
    case BAYES_X0_HIST:
      plot_x0_hist();
      break;
    case BAYES_EXP_HIST:
      plot_exp_hist();
      break;
    case BAYES_LOGCONST_HIST:
      plot_logconst_hist();
      break;
    case BAYES_SIGMA2_HIST:
      plot_sigma2_hist();
      break;
    case BAYES_LOG_SIGMA2_HIST:
      plot_log_sigma2_hist();
      break;
    case BAYES_LOG_EXP_HIST:
      plot_log_exp_hist();
      break;
    case BAYES_LOG_C_HIST:
      plot_log_c_hist();
      break;
    case BAYES_X0_EXP_DEP:
      plot_x0_exp_dep();
      break;
    case BAYES_X0_LOGCONST_DEP:
      plot_x0_logconst_dep();
      break;
    case BAYES_X0_SIGMA2_DEP:
      plot_x0_sigma2_dep();
      break;
    case BAYES_EXP_LOGCONST_DEP:
      plot_exp_logconst_dep();
      break;
    case BAYES_EXP_SIGMA2_DEP:
      plot_exp_sigma2_dep();
      break;
    case BAYES_LOGCONST_SIGMA2_DEP:
      plot_logconst_sigma2_dep();
      break;
    }
}


bayes_show_curve::bayes_show_curve()
{
  init();
}

bayes_show_curve::~bayes_show_curve()
{
  cleanup();
}

double bayes_show_curve::logprob(double a, double b, double c, double s, 
				 double *q, double *h, int num_meas, 
				 double ** /* var */, double **inv_var, 
				 double *m, 
double sigma_a, double sigma_b)
{
  if(s<0.0)
    return -1e+216;

  // contrubtion from (beta-m)V^(-1)(beta-m);
  double contrib_pri_beta = -
    ((a-m[0])*(a-m[0])*inv_var[0][0]+(a-m[0])*(b-m[1])*
     (inv_var[0][1]+inv_var[1][0])+(b-m[1])*(b-m[1])*inv_var[1][1])/2.0/s;

  // contribution from (sigma�)^-(a+2+n/2)*exp(-b/sigma�)
   double contrib_s2 = - (sigma_a+2.0+num_meas/2.0)*log(s) - sigma_b/s;

   double SS=0.0;
  // contribution from the exponensial data part of the likelihood function;
  for(int i=0;i<num_meas;i++)
    if(h[i]+c<0.0)
      return 0.0;
    else
      SS+=pow(log(q[i])-a-b*log(h[i]+c),2.0);
  
  double ret=contrib_pri_beta+contrib_s2 - SS/2.0/s;

  static int jj=1;
  if(jj%100==0)
    std::cout << contrib_pri_beta << " " << contrib_s2 << " " << -SS/2.0/s <<
      " " << SS << std::endl;
  jj++;

  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;

  return ret;
}


bayesian_regression *bayes_show_curve::get_regression_given_c(double c, 
							      double *q, 
							      double *h,
							      int num_meas, 
							      double /* minh */,
							      double *m, 
							      double **var,
							      double sigma_a,
							      double sigma_b)
{
  int i;
  double *y=new double[num_meas];
  double **X=new double*[2];
  
  X[0]=new double[num_meas];
  X[1]=new double[num_meas];

  for(i=0;i<num_meas;i++)
    {
      y[i]=log(q[i]);
      X[0][i]=1.0;
      X[1][i]=log(h[i]+c);
    }
  
  bayesian_regression *reg=get_bayesian_regression(X,2,y,num_meas,
						   m,var,sigma_a,sigma_b);

  doubledelete(X,2);
  delete [] y;

  return reg;
}


void bayes_show_curve::get_hybrid_mcmc(double *h, double *q, 
				       int num_meas,
				       double est_exp, double sdev_exp, 
				       double est_logconst, 
				       double sdev_logconst,
				       double sigma_a, double sigma_b,
				       int num_sim, double **lC, 
				       double **b_, double **c_, 
				       double **sigma2)
{
  int indep=10, burnin=1000;
  double *a=new double[num_sim*indep+burnin];
  double *b=new double[num_sim*indep+burnin];
  double *c=new double[num_sim*indep+burnin];
  double *s=new double[num_sim*indep+burnin];
  double *m=new double[2];
  double **var=new double*[2], **inv_var;
  int i;
  double minh=find_statistics(h,num_meas,MIN);
  bayesian_regression *reg;
  double **reg_sample;
  double prev_logprob;

  var[0]=new double[2];
  var[1]=new double[2];
  m[0]=est_logconst;
  m[1]=est_exp;
  var[0][0]=sdev_logconst*sdev_logconst*(2.0*sigma_a-2.0); ///sigma_b;
  var[1][1]=sdev_exp*sdev_exp*(2.0*sigma_a-2.0); ///sigma_b;
  var[0][1]=var[1][0]=-0.2*sqrt(var[0][0]*var[1][1]);
  inv_var=inverse_matrix(var,2);

  // First sample;
  c[0]=-find_statistics(h,num_meas,MIN)+1.0;
  reg=get_regression_given_c(c[0],q,h,num_meas,minh,m,var,sigma_a,sigma_b);
  reg_sample=reg->sample_coefficients(1);
  a[0]=reg_sample[0][0];
  b[0]=reg_sample[1][0];
  s[0]=reg_sample[2][0];
  prev_logprob=reg->probability_density_of_data(true);
  doubledelete(reg_sample,1);
  delete reg;
  
  for(i=1;i<num_sim*indep+burnin;i++)
    {
      double new_c=c[i-1]+0.05*gauss();
      if(new_c+minh>0.0)
	{
	  reg=get_regression_given_c(new_c,q,h,num_meas,minh,m,var,
				     sigma_a,sigma_b);
	  if(log(drand48())<reg->probability_density_of_data(true)-
	     prev_logprob)
	    {
	      c[i]=new_c;
	      reg_sample=reg->sample_coefficients(1);
	      a[i]=reg_sample[0][0];
	      b[i]=reg_sample[1][0];
	      s[i]=reg_sample[2][0];
	      prev_logprob=reg->probability_density_of_data(true);

	      doubledelete(reg_sample,1);
	    }
	  else
	    {
	      s[i]=s[i-1];
	      a[i]=a[i-1];
	      b[i]=b[i-1];
	      c[i]=c[i-1];
	    }

	  delete reg;
	}
      else
	{
	  s[i]=s[i-1];
	  a[i]=a[i-1];
	  b[i]=b[i-1];
	  c[i]=c[i-1];
	}

      if(i%100==0)
	std::cout << "H: " << a[i] << " " << b[i] << " " << c[i] << " " << 
	  s[i] << " " << logprob(a[i],b[i],c[i],s[i], q,h,num_meas,var,
				 inv_var,m,sigma_a, sigma_b) << std::endl;
    }

  *lC=new double[num_sim];
  *b_=new double[num_sim];
  *c_=new double[num_sim];
  *sigma2=new double[num_sim];
  
  for(i=0;i<num_sim;i++)
    {
      lC[0][i]=a[i*indep+burnin];
      b_[0][i]=b[i*indep+burnin];
      c_[0][i]=c[i*indep+burnin];
      sigma2[0][i]=s[i*indep+burnin];
    }
  
  delete [] a;
  delete [] b;
  delete [] c;
  delete [] s;
  doubledelete(var,2);
  doubledelete(inv_var,2);
  delete [] m;
}

void bayes_show_curve::get_mcmc_data(double *h, double *q, 
				     int num_meas,
				     double est_exp, double sdev_exp, 
				     double est_logconst, 
				     double sdev_logconst,
				     double sigma_a, double sigma_b,
				     int num_sim, double **lC, 
				     double **b_, double **c_, 
				     double **sigma2)
{
  int indep=10, burnin=10000;
  double *a=new double[num_sim*indep+burnin];
  double *b=new double[num_sim*indep+burnin];
  double *c=new double[num_sim*indep+burnin];
  double *s=new double[num_sim*indep+burnin];
  double *m=new double[2];
  double **var=new double*[2], **inv_var;
  int i;
  double minh=find_statistics(h,num_meas,MIN);
  bayesian_regression *reg;
  double **reg_sample;
  double prev_logprob;
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 

  var[0]=new double[2];
  var[1]=new double[2];
  m[0]=est_logconst;
  m[1]=est_exp;
  var[0][0]=sdev_logconst*sdev_logconst*(2.0*sigma_a-2.0); ///sigma_b;
  var[1][1]=sdev_exp*sdev_exp*(2.0*sigma_a-2.0); ///sigma_b;
  var[0][1]=var[1][0]=-0.2*sqrt(var[0][0]*var[1][1]);
  inv_var=inverse_matrix(var,2);
  
  // First sample;
  c[0]=-find_statistics(h,num_meas,MIN)+1.0;
  reg=get_regression_given_c(c[0],q,h,num_meas,minh,m,var,sigma_a,sigma_b);
  reg_sample=reg->sample_coefficients(1);
  //a[0]=reg_sample[0][0];
  //b[0]=reg_sample[1][0];
  //s[0]=reg_sample[2][0]; 
  a[0]=est_logconst;
  b[0]=est_exp;
  s[0]=0.01;
  prev_logprob=logprob(a[0],b[0],c[0],s[0],q,h,num_meas,var,inv_var,m,
		       sigma_a, sigma_b);
  doubledelete(reg_sample,1);
  delete reg;
  
  for(i=1;i<num_sim*indep+burnin;i++)
    {
      double new_c=c[i-1]+gsl_ran_gaussian(rptr, 0.05);
      double new_a=a[i-1]+gsl_ran_gaussian(rptr, 0.1);
      double new_b=b[i-1]+gsl_ran_gaussian(rptr, 0.1);
      double new_s=s[i-1]+gsl_ran_gaussian(rptr, 0.01);
      
      if(new_c+minh>0.0 && new_s>0.0)
	{
	  double new_logprob=logprob(new_a,new_b,new_c,new_s,q,h,num_meas,
				     var,inv_var,m,sigma_a, sigma_b);

	  if(log(drand48()) < new_logprob - prev_logprob)
	    {
	      c[i]=new_c;
	      a[i]=new_a;
	      b[i]=new_b;
	      s[i]=new_s;
	      prev_logprob=new_logprob;
	    }
	  else
	    {
	      s[i]=s[i-1];
	      a[i]=a[i-1];
	      b[i]=b[i-1];
	      c[i]=c[i-1];
	    }
	}
      else
	{
	  s[i]=s[i-1];
	  a[i]=a[i-1];
	  b[i]=b[i-1];
	  c[i]=c[i-1];
	}

      if(i%100==0)
	std::cout << "M: " << a[i] << " " << b[i] << " " << c[i] << " " << 
	  s[i] << " " << prev_logprob << std::endl ;
    }

  *lC=new double[num_sim];
  *b_=new double[num_sim];
  *c_=new double[num_sim];
  *sigma2=new double[num_sim];
  
  for(i=0;i<num_sim;i++)
    {
      lC[0][i]=a[i*indep+burnin];
      b_[0][i]=b[i*indep+burnin];
      c_[0][i]=c[i*indep+burnin];
      sigma2[0][i]=s[i*indep+burnin];
    }
  
  delete [] a;
  delete [] b;
  delete [] c;
  delete [] s;
  doubledelete(var,2);
  doubledelete(inv_var,2);
  delete [] m;
  gsl_rng_free(rptr);
}

/*
void bayes_show_curve::get_mcmc_data(double *h, double *q, 
				     int num_meas,
				     double est_exp, double sdev_exp, 
				     double est_logconst, double sdev_logconst,
				     double sigma_a, double sigma_b,
				     int num_sim, double **lC, 
				     double **b_, double **c_, 
				     double **sigma2)
{
  int indep=10, burnin=1000;
  double *a=new double[num_sim*indep+burnin];
  double *b=new double[num_sim*indep+burnin];
  double *c=new double[num_sim*indep+burnin];
  double *s=new double[num_sim*indep+burnin];
  double *m=new double[2];
  double **var=new double*[2];
  double **inv_var;
  int i,j;
  double minh=find_statistics(h,num_meas,MIN);

  var[0]=new double[2];
  var[1]=new double[2];
  m[0]=est_logconst;
  m[1]=est_exp;
  var[0][0]=sdev_logconst*sdev_logconst*(2.0*sigma_a-2.0); ///sigma_b;
  var[1][1]=sdev_exp*sdev_exp*(2.0*sigma_a-2.0); ///sigma_b;
  var[0][1]=var[1][0]=-0.2*sqrt(var[0][0]*var[1][1]);

  inv_var=inverse_matrix(var,2);

  a[0]=est_logconst;
  b[0]=est_exp;
  c[0]=-find_statistics(h,num_meas,MIN)+1.0;
  s[0]=0.1;
  
  for(i=1;i<num_sim*indep+burnin;i++)
    {
      double new_a=a[i-1]+0.1*gauss();
      if(log(drand48())<
	 logprob(new_a,b[i-1], c[i-1], s[i-1],
		 q,h,num_meas,var,inv_var,m,sigma_a,sigma_b)-
	 logprob(a[i-1],b[i-1],c[i-1],s[i-1],
		 q,h,num_meas,var,inv_var,m,sigma_a,sigma_b))
	a[i]=new_a;
      else
	a[i]=a[i-1];

      double new_b=b[i-1]+0.1*gauss();
      if(log(drand48())<
	 logprob(a[i],new_b, c[i-1], s[i-1],
		 q,h,num_meas,var,inv_var,m,sigma_a,sigma_b)-
	 logprob(a[i],b[i-1],c[i-1],s[i-1],
		 q,h,num_meas,var,inv_var,m,sigma_a,sigma_b))
	b[i]=new_b;
      else
	b[i]=b[i-1];

      double new_c=c[i-1]+0.05*gauss();
      if(log(drand48())<
	 logprob(a[i],b[i], new_c, s[i-1],
		 q,h,num_meas,var,inv_var,m,sigma_a,sigma_b)-
		 logprob(a[i],b[i],c[i-1],s[i-1],
		 q,h,num_meas,var,inv_var,m,sigma_a,sigma_b) && minh+new_c>0.0)
	c[i]=new_c;
      else
	c[i]=c[i-1];

      double new_s=s[i-1]+0.01*gauss();
      double r=log(drand48());
      
      if(r<logprob(a[i],b[i], c[i], new_s,
		   q,h,num_meas,var,inv_var,m,sigma_a,sigma_b)-
	 logprob(a[i],b[i],c[i],s[i-1],
		 q,h,num_meas,var,inv_var,m,sigma_a,sigma_b)  && new_s>0.0)
	s[i]=new_s;
      else
	s[i]=s[i-1];
      
      if(i%100==0)
	std::cout << a[i] << " " << b[i] << " " << c[i] << " " << s[i] << std::endl;
    }

  *lC=new double[num_sim];
  *b_=new double[num_sim];
  *c_=new double[num_sim];
  *sigma2=new double[num_sim];
  
  for(i=0;i<num_sim;i++)
    {
      lC[0][i]=a[i*indep+burnin];
      b_[0][i]=b[i*indep+burnin];
      c_[0][i]=c[i*indep+burnin];
      sigma2[0][i]=s[i*indep+burnin];
    }
  
  delete [] a;
  delete [] b;
  delete [] c;
  delete [] s;
  doubledelete(inv_var,2);
  doubledelete(var,2);
  delete [] m;
}
*/


void bayes_show_curve::create(double *stage_, double *discharge_, 
			      int nummeas, // measurements
			      double *prob_x0, double *x0_, 
			      int numx0, // prior x0
			      double est_exp_, 
			      double sdev_exp_, // prior exponent
			      double est_logconst_, 
			      double sdev_logconst_, // prior log const.
			      // prior of sigma�~neggamma(a,b);
			      double sigma_a_, double sigma_b_)
{
  int i,j;
  
  cleanup();
  
  // Fetch the curve
  segm.create(stage_, discharge_, nummeas, prob_x0, x0_, numx0,
	      est_exp_, sdev_exp_, est_logconst_, sdev_logconst_, 
	      sigma_a_, sigma_b_);
  
  num_iter=100000;
  get_mcmc_data(stage_, discharge_, nummeas, est_exp_, sdev_exp_, 
		est_logconst_, sdev_logconst_, sigma_a_, sigma_b_, 
		num_iter, &a_sim, &b_sim, &c_sim, &s_sim);

  num_hiter=10000;
  get_hybrid_mcmc(stage_, discharge_, nummeas, est_exp_, sdev_exp_, 
		  est_logconst_, sdev_logconst_, sigma_a_, sigma_b_, 
		  num_hiter, &a_hsim, &b_hsim, &c_hsim, &s_hsim);
  
  // Make the main widgets;
  sh.build(mainwin::toplevel, "Kurve-resultat");
  v1.build(sh);
  put_in_widget(v1, 900, 500, PLOT_IN_WIDGET_SHOWMAINMENU,false);
  set_grid(True);

  // Plotting variables;
  double **arg=new double*[10], **val=new double*[10];
  char **linetitles=new char*[10];
  char **axistitles=new char*[2];
  int *yaxis=new int[10], *len=new int[10];
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[10];
  
  // Sampling variables;
  int numsamples=10000;
  double **coef, **coef2, *qsamples;
  int num_x0=segm.get_number_of_x0();
  double *x0=segm.get_x0();
  
  // Sample coefficient using the normal approximation;
  coef=segm.sample_coefficients(numsamples, true); 
  coef2=segm.sample_coefficients(numsamples, false); 
  
  // Make the plot;
  for(i=0;i<10;i++)
    linetitles[i]=new char[100];
  axistitles[0]=new char[100];
  axistitles[1]=new char[100];
  strcpy(axistitles[0], "vannstand");
  strcpy(axistitles[1], "vannf�ring");
  
  double maxprob_x0=segm.get_maxprob_x0();
  double maxprob_logconst=segm.get_maxprob_logconst();
  double maxprob_exp=segm.get_maxprob_exp();
  
  strcpy(linetitles[0], "Beste estimat ubetinget x0");
  sprintf(linetitles[1], "Beste estimat betinget mest sannsynelige "
	  "x0=%7.3f; C=%7.3f, b=%7.3f",
	  maxprob_x0, exp(maxprob_logconst), maxprob_exp);
  strcpy(linetitles[2], "�vre grense for 95% troverdighetsintervall");
  strcpy(linetitles[3], "Nedre grense for 95% troverdighetsintervall");
  strcpy(linetitles[4], "Beste estimat ubetinget x0 fra normaltiln�rmelse");
  strcpy(linetitles[5], "�vre 95%-grense fra normaltiln�rmelse");
  strcpy(linetitles[6], "Nedre 95%-grense fra normaltiln�rmelse");
  strcpy(linetitles[7], "MCMC-estimat");
  strcpy(linetitles[8], "Hybrid MCMC-estimat");
  strcpy(linetitles[9], "M�linger");
  
  double x1=maxprob_x0-1.0, x2=find_statistics(stage_, nummeas, MAX)+1.0;
  double step=0.02;
  int num=(int) ceil((x2-x1)/step)+1;
  
  for(i=0;i<9;i++)
    {
      arg[i]=new double[num];
      val[i]=new double[num];
      len[i]=num;
      type[i]=PLOTLINE_LINE;
      yaxis[i]=1;
    }
  
  for(j=0;j<num;j++)
    {
      double x=x1+step*double(j);
      
      for(i=0;i<9;i++)
	arg[i][j]=x;
      
      val[0][j]=segm.get_estimated_discharge(x);
      val[1][j]=segm.get_maxprob_discharge(x);
      
      qsamples=segm.sample_estimates(x, numsamples, coef2);
      qsort(qsamples, size_t(numsamples), sizeof(double), compare_double);

      val[2][j]=qsamples[numsamples*975/1000];
      val[3][j]=qsamples[numsamples*25/1000];

      delete [] qsamples;
      //val[2][j]=segm.get_upper_discharge(x, 0.95, 10000);
      //val[3][j]=segm.get_lower_discharge(x, 0.95, 10000);

      qsamples=segm.sample_estimates(x, numsamples, coef);
      qsort(qsamples, size_t(numsamples), sizeof(double), compare_double);

      val[4][j]=find_statistics(qsamples,numsamples,MEAN);
      val[5][j]=qsamples[numsamples*975/1000];
      val[6][j]=qsamples[numsamples*25/1000];

      double sum=0.0;
      for(i=0;i<num_iter;i++)
	if(x+c_sim[i]>0)
	  sum+=exp(a_sim[i])*pow(x+c_sim[i],b_sim[i]);
      val[7][j]=sum/double(num_iter);

      sum=0.0;
      for(i=0;i<num_hiter;i++)
	if(x+c_hsim[i]>0)
	  sum+=exp(a_hsim[i])*pow(x+c_hsim[i],b_hsim[i]);
      val[8][j]=sum/double(num_hiter);
      //std::cout << arg[8][j] << " " << val[8][j] << std::endl;

      delete [] qsamples;
      
      std::cout << j << " " << num << std::endl;
    }
  
  arg[9]=new double[nummeas];
  val[9]=new double[nummeas];
  len[9]=nummeas;
  type[9]=PLOTLINE_DOT;
  yaxis[9]=1;
  for(j=0;j<nummeas;j++)
    {
      arg[9][j]=stage_[j];
      val[9][j]=discharge_[j];
    }
  
  Create(arg, val, len, yaxis, linetitles, 10, axistitles, 2, NULL, type);
  
  h1.build(v1);
  acceptb.Create(h1, "Godta", BAYES_SHOW_ACCEPT, this);
  acceptb.Background("green");
  acceptb.Foreground("black");
  closeb.Create(h1, "Avbryt", BAYES_SHOW_CANCEL, this);
  closeb.Background("red");
  closeb.Foreground("white");
  plotx0b.Create(h1, "Plott x0", BAYES_SHOW_PLOT_X0, this);
  plotexpb.Create(h1, "Plott eksponent", BAYES_SHOW_PLOT_EXP, this);
  plotlogconstb.Create(h1, "Plott log(konstant)", BAYES_SHOW_PLOT_LOGCONST, 
		       this);
  plotsigma2b.Create(h1, "Plott sigma�", BAYES_SHOW_PLOT_SIGMA2, this);
  
  h2.build(v1);
  plot_x0_histb.Create(h2, "Plott x0 histogram", BAYES_X0_HIST, this);
  plot_exp_histb.Create(h2, "Plott exp histogram", BAYES_EXP_HIST, this);
  plot_logconst_histb.Create(h2, "Plott log(const) histogram", 
			     BAYES_LOGCONST_HIST, this);
  plot_sigma2_histb.Create(h2, "Plott sigma� histogram", 
			   BAYES_SIGMA2_HIST, this);
  plot_log_sigma2_histb.Create(h2, "Plott log(sigma�) histogram", 
			   BAYES_LOG_SIGMA2_HIST, this);
  plot_log_exp_histb.Create(h2, "Plott log(b) histogram", 
			   BAYES_LOG_EXP_HIST, this);
  plot_log_c_histb.Create(h2, "Plott log(hm-x0) histogram", 
			  BAYES_LOG_C_HIST, this);
  
  h3.build(v1);
  plot_x0_exp_depb.Create(h3, "Plott x0-exp avh.", BAYES_X0_EXP_DEP, this);
  plot_x0_logconst_depb.Create(h3, "Plott x0-logconst avh.", 
			    BAYES_X0_LOGCONST_DEP, this);
  plot_x0_sigma2_depb.Create(h3, "Plott x0-sigma� avh.", 
			  BAYES_X0_SIGMA2_DEP, this);
  plot_exp_logconst_depb.Create(h3, "Plott exp-logconst avh.", 
				BAYES_EXP_LOGCONST_DEP, this);
  h4.build(v1);
  plot_exp_sigma2_depb.Create(h4, "Plott exp-sigma� avh.", 
				BAYES_EXP_SIGMA2_DEP, this);
  plot_logconst_sigma2_depb.Create(h4, "Plott logconst-sigma� avh.", 
				   BAYES_LOGCONST_SIGMA2_DEP, this);
  h0start.build(h4, 8,"x0-start:");
  h0start.SetDouble(x0[0],2);
  h0end.build(h4, 8,"x0-slutt:");
  h0end.SetDouble(x0[num_x0-1],2);

  sh.Map();
  
  doubledelete(coef,4);
  doubledelete(arg,10);
  doubledelete(val,10);
  doubledelete(linetitles,10);
  doubledelete(axistitles,2);
}

void bayes_show_curve::plot_ended(void)
{
  cancel();
  sh.Unmap();
}


void bayes_show_curve::cancel(void)
{
  // NOP
}
void bayes_show_curve::accept()
{
  // NOP
}









// *********************************************************
// 
//              GUI FOR MULTI-SEGMENTED ANALYSIS
//
// *********************************************************














void bayes_multiseg_button::Create(widget parent, const char *txt, 
				   BAYES_MULTISEG_ACTION button_type,
				   bayes_multiseg_showcurve *ipt, int key_)
{
  type=button_type;
  pt=ipt;
  key=key_;
  build(parent, txt);
}

void bayes_multiseg_button::pushed(void)
{
  pt->take_action(type, key);
}

void bayes_multiseg_modelmenu::create(widget parent, int num_models, 
				      double *probs, int most_probable,
				      bayes_multiseg_showcurve *ipt)
{
  char **items=new char*[num_models+1];
  int i, max_seg=0;
  double maxprob=0;
  
  pt=NULL;
  
  for(i=0;i<num_models;i++)
    {
      items[i]=new char[100];
      sprintf(items[i], "%d (P=%6.3g)", i+1, probs[i]);
      if(maxprob<probs[i])
	{
	  maxprob=probs[i];
	  max_seg=i;
	}
    }
  
  items[num_models]=new char[100];
  sprintf(items[num_models], WHAT((char *) "Alle", (char *) "All"));
  
  Create(parent, WHAT((char *) "Antall segmenter (i interpolert omr�de):", 
		      (char *) "Number of segments (in the interpolated "
		      "area):"));
  Insert(items, num_models+1, max_seg);

  SetFocus(most_probable-1);
  
  cleanup();
  nummod=num_models;
  most_prob_model=most_probable;
  modprob=new double[nummod];
  for(i=0;i<nummod;i++)
    modprob[i]=probs[i];


  pt=ipt;
}

void bayes_multiseg_modelmenu::cleanup(void)
{
  if(modprob)
    delete [] modprob;
  init();
}

void bayes_multiseg_modelmenu::init(void)
{
  modprob=NULL;
  nummod=most_prob_model=0;
}

bayes_multiseg_modelmenu::bayes_multiseg_modelmenu()
{
  init();
}

bayes_multiseg_modelmenu::~bayes_multiseg_modelmenu()
{
  cleanup();
}

void bayes_multiseg_modelmenu::pushed(const char *)
{
  if(pt)
    pt->model_chosen(get_model());
}

int bayes_multiseg_modelmenu::get_model(void)
{
  
  int num=GetNumber()+1;
  if(num<=nummod && modprob[num-1]<=0.0)
    {
      char errmsg[1000];
      sprintf(errmsg, WHAT((char *) "Modell med %d segmenter har ikke blitt "
			   "tatt med i analysen!", (char *) "Model with %d "
			   "segments has not been included in the analysis!"),
	      num);
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		errmsg);
      SetFocus(most_prob_model-1);
    }

  if(num>nummod)
    return -1;
  else
    return num;
}



void bayes_multiseg_qual_showdesc::Create(widget parent, const char *txt, 
					  bayes_multiseg_qual *ipt)
{
  build(parent, txt);
  pt=ipt;
}

void bayes_multiseg_qual_showdesc::pushed(void)
{
  pt->show_long_desc();
}


void bayes_multiseg_qual::show_long_desc(void)
{
  mess.build(mainwin::toplevel, WHAT((char *) "Beskrivelse", 
				     (char *) "Description"),
	     long_description);
}

void bayes_multiseg_qual::create(widget parent, 
				 const char *short_desc, const char *long_desc,
				 bool visual)
{
  build(parent);
  v1.build(*this);
  
  lab.build(v1, short_desc);
  lab.Background("white");
  lab.Foreground("black");

  strcpy(long_description, long_desc);

  char *qualnames[]={WHAT((char *) "1 (=ubrukelig)", (char *) "1 (=unusable)"),
		     WHAT((char *) "2 (=d�rlig)", (char *) "2 (=bad)"),
		     WHAT((char *) "3 (=middels)", (char *) "3 (=medium)"),
		     WHAT((char *) "4 (=bra)", (char *) "4 (=good)")};
  qual_menu.Create(v1, WHAT((char *) "Kvalitetsstempel:", 
			   (char *) "Quality:"));
  qual_menu.Insert(qualnames,4);
  
  char *impnames[]={WHAT((char *) "1 (=ikke viktig)", 
			 (char *) "1 (=not important)"),"2","3","4",
		    WHAT((char *) "5 (=sv�rt viktig)", 
			 (char *) "5 (=very important)")};
  imp_menu.Create(v1, WHAT((char *) "Viktighet:", (char *) "Importance"));
  imp_menu.Insert(impnames,5);

  if(visual)
    {
      vis_menu.Create(v1, WHAT((char *) "Visuell inspeksjon:", 
			      (char *) "Visual inspection"));
      vis_menu.Insert(impnames,5);
      set_visual_importance(1);
    }
  show_vis=visual;

  h1.build(v1);
  descb.Create(h1, WHAT((char *) "Beskrivelse", 
			(char *) "Description"), this);
}

int bayes_multiseg_qual::get_quality(void)
 /* 1=very good to 5=unusable */
{
  return qual_menu.GetNumber()+1;
}

void bayes_multiseg_qual::set_quality(int qual)
{
  if(qual>=1 && qual<=4)
    qual_menu.SetFocus(qual-1);
}

int bayes_multiseg_qual::get_importance(void)
 /* 1=very important to 5=not important */
{
  return imp_menu.GetNumber()+1;
}

void bayes_multiseg_qual::set_importance(int imp)
{
  if(imp>=1 && imp<=5)
    imp_menu.SetFocus(imp-1);
}

int bayes_multiseg_qual::get_visual_importance(void)
{
  if(show_vis)
    return vis_menu.GetNumber()+1;
  else
    return 1;
}

void bayes_multiseg_qual::set_visual_importance(int imp)
{
  if(show_vis && imp>=1 && imp<=5)
    vis_menu.SetFocus(imp-1);
}

void bayes_multiseg_quality_toggle::Create(widget parent, 
					   bayes_multiseg_showcurve *ipt)
{
  pt=NULL;
  build(parent, WHAT((char *) "Kvalitetsvurdering", 
		     (char *) "Quality judgment"));
  pt=ipt;
}

void bayes_multiseg_quality_toggle::pushed(bool newstate)
{
  if(pt && newstate)
    pt->quality_toggled();
}

void bayes_multiseg_table_filesel::Create(shell sh, 
					  bayes_multiseg_showcurve *ipt)
{
  pt=ipt;
  build(sh);
}

void bayes_multiseg_table_filesel::ok(const char *filename)
{
  pt->table_file_selected(filename);
}

void bayes_multiseg_table_filesel::cancel(void)
{
  pt->table_file_not_selected();
}

void bayes_multiseg_table2_infilesel::Create(shell sh, 
					     bayes_multiseg_showcurve *ipt)
{
  pt=ipt;
  build(sh);
}

void bayes_multiseg_table2_infilesel::ok(const char *filename)
{
  pt->table2_infile_selected(filename);
}

void bayes_multiseg_table2_infilesel::cancel(void)
{
  pt->table2_infile_not_selected();
}


void bayes_multiseg_table2_outfilesel::Create(shell sh, 
					  bayes_multiseg_showcurve *ipt)
{
  pt=ipt;
  build(sh);
}

void bayes_multiseg_table2_outfilesel::ok(const char *filename)
{
  pt->table2_outfile_selected(filename);
}

void bayes_multiseg_table2_outfilesel::cancel(void)
{
  pt->table2_outfile_not_selected();
}


void bayes_multiseg_showcurve::init(void)
{
  comparisoncurve=NULL;
  qual_visited=false;
  extraplot=NULL;
  extrahist=NULL;
  param_names=NULL;
  attrib_names=NULL;
  num_attrib=num_meas=num_params=0;
  q=h=NULL;
  dt=NULL;
  reshs=NULL;
  reslabs=NULL;
  resbuttons=NULL;
  show_median_curve=False;
  weights=NULL;
  prevcomment=NULL;
  strcpy(tablefile,"");
  strcpy(table2infile,"");
  strcpy(table2outfile,"");
}

void bayes_multiseg_showcurve::cleanup(void)
{
  if(comparisoncurve)
    delete comparisoncurve;
  if(dt)
    delete [] dt;
  if(q)
    delete [] q;
  if(h)
    delete [] h;
  if(extraplot)
    delete extraplot;
  if(extrahist)
    delete extrahist;
  if(param_names)
    doubledelete(param_names,num_params);
  if(attrib_names)
    doubledelete(attrib_names,num_attrib);
  if(reshs)
    delete [] reshs;
  if(reslabs)
    delete [] reslabs;
  if(resbuttons)
    delete [] resbuttons;
  if(weights)
    delete [] weights;
  if(prevcomment)
    delete [] prevcomment;
  init();
}

void bayes_multiseg_showcurve::estimate_discharge(void)
{
  double stage=stagef.getdouble();

  estsh.build(*this, WHAT((char *) "Estimert vannf�ring", 
			  (char *) "Estimated discharge"));
  estv1.build(estsh);
  estl1.build(estv1, WHAT((char *) "Vannstand: %7.3f", 
			  (char *) "Stage:     %7.3f"), stage);
  estl1.Background("white");

  estl2.build(estv1, WHAT((char *) "Median vannf�ring:              %9.3f", 
			  (char *) "Median discharge:               %9.3f"),
	      result->get_median_extrapolation_discharge(stage));
  
  int model=modelmenu.get_model();
  segmented_curve *medcurve=model>0 ? result->get_modus_curve(model,x2) :
    result->get_best_modus_curve(x2);
  estl3.build(estv1, WHAT((char *) "Vannf�ring for estimert kurve:    %9.3f", 
			  (char *) "Discharge for estimated curve:     %9.3f"),
	      medcurve->get_discharge(stage));
  
  if(show_extrapol_uncert)
    estl4.build(estv1, 
		WHAT((char *) "95%% troverdighetsintervall: "
		     "%9.3f - %9.3f", 
		     (char *) "95%% credibility interval:   "
		     "%9.3f - %9.3f"),
		result->get_discharge_extrapolation_quantile(stage, 2.5),
		result->get_discharge_extrapolation_quantile(stage, 97.5));
  else
    estl4.build(estv1, 
		WHAT((char *) "95%% troverdighetsintervall: %9.3f - %9.3f", 
		     (char *) "95%% credibility interval:   %9.3f - %9.3f"),
		result->get_discharge_quantile(stage, 2.5),
		result->get_discharge_quantile(stage, 97.5));
  
  estsep.build(estv1);
  esth1.build(estv1);
  estcloseb.build(esth1, &estsh, WHAT((char *) "Lukk vindu", 
				     (char *) "Close window")); 
  estcloseb.Background("red");
  estcloseb.Foreground("white");
  estsh.Map();

  delete medcurve;
}

void bayes_multiseg_showcurve::estimate_stage(void)
{
  double discharge=dischargef.getdouble();

  estsh.build(*this, WHAT((char *) "Estimert vannstand", 
			  (char *) "Estimated stage"));
  estv1.build(estsh);
  estl1.build(estv1, WHAT((char *) "Vannf�ring: %7.3f", 
			  (char *) "Discharge:  %7.3f"), discharge);
  estl1.Background("white");
  
  estl2.build(estv1, WHAT((char *) "Median vannstand:              %9.3f", 
			  (char *) "Median stage:                  %9.3f"),
	      result->get_median_extrapolation_stage(discharge));

  int model=modelmenu.get_model();
  segmented_curve *medcurve=model>0 ? result->get_modus_curve(model,x2):
    result->get_best_modus_curve(x2);
  estl3.build(estv1, WHAT((char *) "Vannstand for estimert kurve:    %9.3f", 
			  (char *) "Stage for estimert curve:        %9.3f"),
	      medcurve->get_stage(discharge));

  if(show_extrapol_uncert)
    estl4.build(estv1, 
		WHAT((char *) "95%% troverdighetsintervall: "
		     "%9.3f - %9.3f", 
		     (char *) "95%% credibility interval:   "
		     "%9.3f - %9.3f"),
		result->get_stage_extrapolation_quantile(discharge, 2.5),
		result->get_stage_extrapolation_quantile(discharge, 97.5));
  else
    estl4.build(estv1, 
		WHAT((char *) "95%% troverdighetsintervall: %9.3f - %9.3f", 
		     (char *) "95%% credibility interval:   %9.3f - %9.3f"),
		result->get_stage_quantile(discharge, 2.5),
		result->get_stage_quantile(discharge, 97.5));
  
  estsep.build(estv1);
  esth1.build(estv1);
  estcloseb.build(esth1, &estsh, WHAT((char *) "Lukk vindu", 
				     (char *) "Close window")); 
  estcloseb.Background("red");
  estcloseb.Foreground("white");
  estsh.Map();
  
  delete medcurve;
}

double *bayes_multiseg_showcurve::get_samples(int *len, int numseg, 
					      int type)
{
  double *ret=NULL;
  int i;

  if(numseg<0)
    {
      if(type==0)
	ret=result->get_a_samples(len, -1);
      else if(type==1)
	ret=result->get_s_samples(len,-1);
      else if(type==2)
	ret=result->get_logprob_samples(len,-1);
      else
	{
	  std::cerr << "Unknown menu option in get_samples-algorithm!" << std::endl;
	  exit(0);
	}
    }
  else
    {
      if(type==0)
	{
	  ret=result->get_a_samples(len, numseg);
	  for(i=0;i<(*len);i++)
	    ret[i]=exp(ret[i]);
	}
      else if(type>=1 && type<numseg)
	{
	  ret=result->get_higher_a_samples(len, numseg, type+1);
	  for(i=0;i<(*len);i++)
	    ret[i]=exp(ret[i]);
	}
      else if(type>=numseg && type<2*numseg)
	ret=result->get_b_samples(len,numseg, type-numseg+1);
      else if(type>=2*numseg && type<3*numseg)
	ret=result->get_h0_samples(len,numseg, type-2*numseg+1);
      else if(type>=3*numseg && type<(4*numseg-1))
	ret=result->get_hs_samples(len,numseg, type-3*numseg+1);
      else if(type==(4*numseg-1))
	ret=result->get_s_samples(len,numseg);
      else if(type==4*numseg)
	ret=result->get_logprob_samples(len,numseg);
      else
	{
	  std::cerr << "Unknown menu option in get_samples-algorithm!" << std::endl;
	  exit(0);
	}
    }

  return ret;
}

void bayes_multiseg_showcurve::start_table(void)
{
  tablesh.Map();
  if(*tablefile)
    tablefilelab.labelString(tablefile);
  else
    tablefilelab.labelString(WHAT((char *) "Ingen fil valgt", 
				  (char *) "No file chosen"));
}

void bayes_multiseg_showcurve::start_table_filesel(void)
{
  table_filesel_sh.Map();
}

void bayes_multiseg_showcurve::do_table(void)
{
  double x1=tablestartf.getdouble();
  double x2=tableendf.getdouble();
  double dx=tablestepf.getdouble();
  int steps=ceil((x2-x1)/dx);

  if(!*tablefile)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen lagringsfil valgt!", 
		     (char *) "No save file chosen!"));
      return;
    }

  if(x2<=x1)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Sluttvannstand<=startvannstand!", 
		     (char *) "End stage <=start stage!"));
      return;
    }
  
  if(dx<=0.0)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Vannstandsoppl�sning<=0!", 
		     (char *) "Stage steps<=0!"));
      return;
    }

  if(steps<2)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Antall steg<=1!", 
		     (char *) "Number of steps<=1!"));
      return;
    }
  
  AddWorkCursor(tablesh);
  AddWorkCursor(sh);

  FILE *f=fopen(tablefile,"w");
  if(!f)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � �pne fil!", 
		     (char *) "Could not open file!"));
      return;
    }

  fprintf(f,"%16s %16s %16s %16s %16s "
	  "%16s %16s %16s %16s %16s "
	  "%16s %16s %16s %16s\n",
	  "\"Stage(m)\"","\"Discharge(m^3/s)\"",
	  "\"UpperConf_97_5\"","\"LowerConf_2_5\"",
	  "\"UpperConf_95\"","\"LowerConf_5\"",
	  "\"UpperConf_84\"","\"LowerConf_16\"",
	  "\"UpperPred_97_5\"","\"LowerPred_2_5\"",
	  "\"UpperPred_95\"","\"LowerPred_5\"",
	  "\"UpperPred_84\"","\"LowerPred_16\""); 
    for(double x=x1; x<=x2;x+=dx)
    {
      double Q=result->get_median_extrapolation_discharge(x);
      double lower95=result->get_discharge_extrapolation_quantile(x,2.5);
      double upper95=result->get_discharge_extrapolation_quantile(x,97.5);
      double lower90=result->get_discharge_extrapolation_quantile(x,5.0);
      double upper90=result->get_discharge_extrapolation_quantile(x,95.0);
      double lower68=result->get_discharge_extrapolation_quantile(x,16.0);
      double upper68=result->get_discharge_extrapolation_quantile(x,84.0);
      double lowerpred95=
	result->get_discharge_prediction_extrapolation_quantile(x,2.5);
      double upperpred95=
	result->get_discharge_prediction_extrapolation_quantile(x,97.5);
      double lowerpred90=
	result->get_discharge_prediction_extrapolation_quantile(x,5.0);
      double upperpred90=
	result->get_discharge_prediction_extrapolation_quantile(x,95.0);
      double lowerpred68=
	result->get_discharge_prediction_extrapolation_quantile(x,16.0);
      double upperpred68=
	result->get_discharge_prediction_extrapolation_quantile(x,84.0);
      fprintf(f," %14.3f   %14.3f   %14.3f   %14.3f   %14.3f   %14.3f   "
	      "%14.3f   %14.3f   %14.3f   %14.3f   %14.3f   %14.3f   "
	      "%14.3f   %14.3f\n",
	      x,Q,upper95,lower95,upper90,lower90,upper68,lower68,
	      upperpred95,lowerpred95,upperpred90,lowerpred90,
	      upperpred68,lowerpred68);
    }

  fclose(f);
  
  RmWorkCursor(tablesh);
  RmWorkCursor(sh);
  
  char messtr[1000];
  sprintf(messtr,
	  WHAT((char *) "Formatert utksrift er sendt til filen \"%s\".", 
	       (char *) "Formatted output has been sent to the "
	       "file \"%s\"."),tablefile);
  mess.build(sh,WHAT((char *) "Melding", (char *) "Message"),
	     messtr);
  
  tablesh.Unmap();
}


void bayes_multiseg_showcurve::start_table2(void)
{
  table2sh.Map();
  if(*table2infile)
    table2infilelab.labelString(table2infile);
  else
    table2infilelab.labelString(WHAT((char *) "Ingen fil valgt", 
				     (char *) "No file chosen"));
  if(*table2outfile)
    table2outfilelab.labelString(table2outfile);
  else
    table2outfilelab.labelString(WHAT((char *) "Ingen fil valgt", 
				      (char *) "No file chosen"));
}

void bayes_multiseg_showcurve::start_table2_infilesel(void)
{
  table2_infilesel_sh.Map();
}

void bayes_multiseg_showcurve::start_table2_outfilesel(void)
{
  table2_outfilesel_sh.Map();
}

void bayes_multiseg_showcurve::do_table2(void)
{
  if(!*table2infile)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen tidsserie-input-fil valgt!", 
		     (char *) "No time series input file chosen!"));
      return;
    }

  if(!*table2outfile)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen lagringsfil valgt!", 
		     (char *) "No save file chosen!"));
      return;
    }
  
  AddWorkCursor(table2sh);
  AddWorkCursor(sh);
  
  FILE *in=fopen(table2infile,"r");
  if(!in || feof(in))
    {
      char errstr[1000];
      sprintf(errstr, WHAT((char *) "Klarte ikke � �pne filen \"%s\" for lesing!", 
			   (char *) "Couldn't open file \"%s\" for reading!"),
	      table2infile);
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"), errstr);
      return;
    }
  
  FILE *f=fopen(table2outfile,"w");
  if(!f)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � �pne fil!", 
		     (char *) "Could not open file!"));
      return;
    }

  fprintf(f,"%6s %6s %6s %6s %6s "
	  "%16s %16s %16s %16s %16s "
	  "%16s %16s %16s %16s %16s "
	  "%16s %16s %16s\n",
	  "Day","Month","Year","Hour", "Minute",
	  "\"Discharge(m^3/s)\"",
	  "\"UpperConf_97_5\"","\"LowerConf_2_5\"",
	  "\"UpperConf_95\"","\"LowerConf_5\"",
	  "\"UpperConf_84\"","\"LowerConf_16\"",
	  "\"UpperPred_97_5\"","\"LowerPred_2_5\"",
	  "\"UpperPred_95\"","\"LowerPred_5\"",
	  "\"UpperPred_84\"","\"LowerPred_16\""); 
  do
    {
      int day,mnt,year,hour,min;
      double x;
      if(fscanf(in, "%d/%d/%d %d:%d %lf",
		&day, &mnt, &year,&hour,&min,&x)==6)
	{
	  
      double Q=result->get_median_extrapolation_discharge(x);
      double lower95=result->get_discharge_extrapolation_quantile(x,2.5);
      double upper95=result->get_discharge_extrapolation_quantile(x,97.5);
      double lower90=result->get_discharge_extrapolation_quantile(x,5.0);
      double upper90=result->get_discharge_extrapolation_quantile(x,95.0);
      double lower68=result->get_discharge_extrapolation_quantile(x,16.0);
      double upper68=result->get_discharge_extrapolation_quantile(x,84.0);
      double lowerpred95=
	result->get_discharge_prediction_extrapolation_quantile(x,2.5);
      double upperpred95=
	result->get_discharge_prediction_extrapolation_quantile(x,97.5);
      double lowerpred90=
	result->get_discharge_prediction_extrapolation_quantile(x,5.0);
      double upperpred90=
	result->get_discharge_prediction_extrapolation_quantile(x,95.0);
      double lowerpred68=
	result->get_discharge_prediction_extrapolation_quantile(x,16.0);
      double upperpred68=
	result->get_discharge_prediction_extrapolation_quantile(x,84.0);
      fprintf(f,"%6d %6d %6d %6d %6d  "
	      "%14.3f   %14.3f   %14.3f   %14.3f   %14.3f   "
	      "%14.3f   %14.3f   %14.3f   %14.3f   %14.3f   %14.3f   "
	      "%14.3f   %14.3f\n",
	      day,mnt,year,hour,min,
	      Q,upper95,lower95,upper90,lower90,upper68,lower68,
	      upperpred95,lowerpred95,upperpred90,lowerpred90,
	      upperpred68,lowerpred68);
	}
      
    } while(!feof(in));

  fclose(f);
  fclose(in);
  
  RmWorkCursor(table2sh);
  RmWorkCursor(sh);
  
  char messtr[1000];
  sprintf(messtr,
	  WHAT((char *) "Formatert utksrift er sendt til filen \"%s\".", 
	       (char *) "Formatted output has been sent to the "
	       "file \"%s\"."),table2outfile);
  mess.build(sh,WHAT((char *) "Melding", (char *) "Message"),
	     messtr);
  
  table2sh.Unmap();
}


void bayes_multiseg_showcurve::show_histogram(void)
{
  int model=modelmenu.get_model(); // number of segments
  
  int histtype=histmenu.GetNumber(); // a={0...k-1}, b={k...2*k-1}, 
  // h0={2*k,...3k-1}, hs={3k,...,4k-1}}, sigma=4k-1 (or 1) , 
  // logprob=4k (or 2)
  double **val=new double*[1];
  char **linetitles=new char*[1];
  int *len=new int[1];
  
  if(extrahist)
    delete extrahist;
  extrahist=new histogram();
  
  linetitles[0]=new char[100];
  strcpy(linetitles[0], param_names[histtype]);

  val[0]=get_samples(len, model, histtype);
  if(!val[0])
    return;

  extrahist->set_x_axis_font_size(PLOT_FONT_LARGE);
  extrahist->set_y_axis_font_size(PLOT_FONT_MEDIUM);
  extrahist->set_outer_rectangle(False);
  extrahist->set_inner_rectangle(False);
  // extrahist->set_big();
  extrahist->create(val, len, 1, linetitles, linetitles[0], 
		    WHAT((char *) "Hyppighet", (char *) "Frequency"));
  doubledelete(val, 1); 
  doubledelete(linetitles,1);
  delete [] len;
}

void bayes_multiseg_showcurve::show_sample_series(void)
{
  int model=modelmenu.get_model(); // number of segments
  
  int histtype=histmenu.GetNumber(); // a={0...k-1}, b={k...2*k-1}, 
  // h0={2*k,...3k-1}, hs={3k,...,4k-1}}, sigma=4k-1 (or 1) , 
  // logprob=4k (or 2)
  
  //if(extraplot)
  // delete extraplot;
  extraplot=new plot_shell();
  
  char *linetitle=new char[100], **axistitles=new char*[2];
  axistitles[0]=new char[100];
  strcpy(axistitles[0], WHAT((char *) "Iter. nr.", (char *) "Iter. nr."));
  axistitles[1]=new char[100];
  strcpy(axistitles[1], param_names[histtype]);
  
  int i,len, axis=1;
  double *val=get_samples(&len, model, histtype);
  if(!val)
    return;
  double *arg=new double[len];
  for(i=0;i<len;i++)
    arg[i]=double(i+1);

  double rho=get_auto_correlation(val, len);
  //double n_indep=len/2.0/(0.5+rho/(1.0-rho));
  double spacing=2.0*(0.5+rho/(1.0-rho));
  sprintf(linetitle, WHAT((char *) "%s - avstand mellom uavh. samples: %5.1f",
			  (char *) "%s - avstand mellom uavh. samples: %5.1f"),
	  param_names[histtype], spacing);

  AddWorkCursor(sh);
  extraplot->make_plotting_window(900,700,WHAT((char *) "Sample-serie", 
					       (char *) "Sample series"));
  extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_outer_rectangle(False);
  extraplot->set_inner_rectangle(False);
  //extraplot->set_big();
  extraplot->Create(&arg, &val, &len, &axis, &linetitle, 1,
		    axistitles, 2);
  RmWorkCursor(sh);
  
  doubledelete(axistitles, 2); 
  delete [] arg;
  delete [] val;
  delete [] linetitle;
}

void bayes_multiseg_showcurve::show_scatter(void)
{
  int model=modelmenu.get_model(); // number of segments

  // a=0, b={1...k}, h0={k+1,...2k}, 
  // hs={2k+1,...,3k-1}}, sigma=3k, logprob=3k+1
  int type1=scattermenu1.GetNumber(),type2=scattermenu2.GetNumber();

  if(type1==type2)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Du m� velge ulike parametre i "
		     "et spredningsplott!",
		     (char *) "You must choose different parameters in a "
		     "scatterplot"));
      return;
    }
  
  //if(extraplot)
  //delete extraplot;
  extraplot=new plot_shell();
  
  int len, axis=1;
  double *arg=NULL, *val=NULL;

  arg=get_samples(&len, model, type1);
  val=get_samples(&len, model, type2);
  
  if(!arg || !val)
    return;

  char *linetitle=new char[100], **axistitles=new char*[2];
  PLOTLINE_TYPE ptype=PLOTLINE_DOT;
  
  axistitles[0]=new char[100];
  strcpy(axistitles[0], param_names[type1]);
  axistitles[1]=new char[100];
  strcpy(axistitles[1], param_names[type2]);
  
  sprintf(linetitle, WHAT((char *) "%s mot %s", (char *) "%s against %s"),
	  param_names[type1],param_names[type2]);
 
  extraplot->make_plotting_window(900,700,WHAT((char *) "Spredningsplott", 
						(char *) "Scatter plot"));
  extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_outer_rectangle(False);
  extraplot->set_inner_rectangle(False);
  //extraplot->set_big();
  extraplot->Create(&arg, &val, &len, &axis, &linetitle, 1,
		    axistitles, 2, NULL, &ptype);

  doubledelete(axistitles,2);
  delete [] linetitle;
}


double *bayes_multiseg_showcurve::get_predicted(int model)
{
  double *pred=new double[num_meas];
  segmented_curve *medcurve=model>=0 ? result->get_modus_curve(model,x2):
    result->get_best_modus_curve(x2);
  
  for(int i=0;i<num_meas;i++)
    pred[i]=medcurve->get_discharge(h[i]);
  
  delete medcurve;
  
  return pred;
}

double *bayes_multiseg_showcurve::get_residuals(int model)
{
  double *pred=get_predicted(model);
  double *res=new double[num_meas];
  
  for(int i=0;i<num_meas;i++)
    if(weights)
      res[i]=log(q[i]/pred[i])/weights[i];
    else
      res[i]=log(q[i]/pred[i]);

  delete [] pred;
  
  return res;
}


void bayes_multiseg_showcurve::do_accept(void)
{
  if(!qualtog())
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen kvalitetsvurdering av gjeldende modell "
		     "er blitt foretatt enda!", 
		     (char *) "No quality evalutation of the current model "
		     "has been done yet!"));
      return;
    }

  int model=modelmenu.get_model();
  if(model>prior->get_max_seg() || model<0)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen modell valgt", 
		     (char *) "No model chosen"));
    }
  
  int most_prob_mod=result->get_most_probable_model();

  if(model!=most_prob_mod)
    {
      mess.build(mainwin::toplevel, 
		 WHAT((char *) "Sp�rsm�l", (char *) "Question"),
		 WHAT((char *) "Den valgte modellen er ikke den mest "
		      "sannsynlige. Fortsette likevel?", 
		      (char *) "No chosen is "
		      "not the most probable. Continue in spite of this?"));
      if(!mess.ok_or_cancel(WHAT((char *) "Ja", (char *) "Yes"), 
			    WHAT((char *) "Nei", (char *) "No")))
	return;
    }
  
  double prob=result->get_probability_of_model(model);
  segmented_curve *modusmodel=result->get_modus_curve(model,x2);
  
  double *discharge_lower=NULL, *discharge_upper=NULL;
  int num_restr=0;
  double *restr_stage=NULL, *restr_q_lower=NULL, *restr_q_upper=NULL;
  if(prior && prior->num_internal_restrictions()>0)
    {
      num_restr=prior->num_internal_restrictions();
      restr_stage=prior->stage_internal_restrictions();
      restr_q_lower=prior->logdischarge_lower_internal_restrictions();
      restr_q_upper=prior->logdischarge_upper_internal_restrictions();
    }
  if(num_restr>0 && restr_stage && restr_q_lower && restr_q_upper)
    {
      discharge_lower=new double[num_restr];
      discharge_upper=new double[num_restr];
      for(int i=0;i<num_restr;i++)
	{
	  if(restr_q_lower[i]!=MISSING_VALUE)
	    discharge_lower[i]=exp(restr_q_lower[i]);
	  else
	    discharge_lower[i]=MISSING_VALUE;
	  if(restr_q_upper[i]!=MISSING_VALUE)
	    discharge_upper[i]=exp(restr_q_upper[i]);
	  else
	    discharge_upper[i]=MISSING_VALUE;
	}
    }
  
  double *extra_lower=NULL, *extra_upper=NULL;
  int num_extra=0;
  double *extra_stage=NULL, *extra_q_lower=NULL, *extra_q_upper=NULL;
  if(prior && prior->num_extrapolation_restrictions()>0)
    {
      num_extra=prior->num_extrapolation_restrictions();
      extra_stage=prior->stage_extrapolation_restrictions();
      extra_q_lower=prior->logdischarge_lower_extrapolation_restrictions();
      extra_q_upper=prior->logdischarge_upper_extrapolation_restrictions();
    }
  if(num_extra>0 && extra_stage && extra_q_lower && extra_q_upper)
    {
      extra_lower=new double[num_extra];
      extra_upper=new double[num_extra];
      for(int i=0;i<num_extra;i++)
	{
	  if(extra_q_lower[i]!=MISSING_VALUE)
	    extra_lower[i]=exp(extra_q_lower[i]);
	  else
	    extra_lower[i]=MISSING_VALUE;
	  if(extra_q_upper[i]!=MISSING_VALUE)
	    extra_upper[i]=exp(extra_q_upper[i]);
	  else
	    extra_upper[i]=MISSING_VALUE;
	}
    }
  

  accept(modusmodel, prob, result,
	 
	 prior,
	 
	 measurements, q, h, dt, num_meas,
	 
	 totalqual.GetNumber(), qualcomment.GetText(),
	 qual_trend.get_quality(), qual_trend.get_importance(),
	 qual_trend.get_visual_importance(),
	 qual_uncert.get_quality(), qual_uncert.get_importance(),
	 qual_uncert.get_visual_importance(),
	 qual_outliers.get_quality(), qual_outliers.get_importance(),
	 qual_outliers.get_visual_importance(),
	 qual_fit.get_quality(), qual_fit.get_importance(),
	 
	 qualtext.GetText(), p_outlier, p_trend_time, p_abstrend_time, 
	 p_trend_stage, p_abstrend_stage, max_rel_uncert, 
	 min_rel_uncert, norm_rel_uncert, h0_uncert, b_uncert, 
	 sigma_estimated);

  if(discharge_lower)
    delete [] discharge_lower;
  if(discharge_upper)
    delete [] discharge_upper;

  if(extra_lower)
    delete [] extra_lower;
  if(extra_upper)
    delete [] extra_upper;
  
  delete modusmodel;
  
  sh.Unmap();
}


void bayes_multiseg_showcurve::do_save_pre_analysis(void)
{
  int model=modelmenu.get_model();
  if(model>prior->get_max_seg() || model<0)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen modell valgt", 
		     (char *) "No model chosen"));
    }
  
  int most_prob_mod=result->get_most_probable_model();

  if(model!=most_prob_mod)
    {
      mess.build(mainwin::toplevel, 
		 WHAT((char *) "Sp�rsm�l", (char *) "Question"),
		 WHAT((char *) "Den valgte modellen er ikke den mest "
		      "sannsynlige. Fortsette likevel?", 
		      (char *) "No chosen is "
		      "not the most probable. Continue in spite of this?"));
      if(!mess.ok_or_cancel(WHAT((char *) "Ja", (char *) "Yes"), 
			    WHAT((char *) "Nei", (char *) "No")))
	return;
    }
  
  double prob=result->get_probability_of_model(model);
  segmented_curve *modusmodel=result->get_modus_curve(model,x2);
  
  double *discharge_lower=NULL, *discharge_upper=NULL;
  int num_restr=0;
  double *restr_stage=NULL, *restr_q_lower=NULL, *restr_q_upper=NULL;
  if(prior && prior->num_internal_restrictions()>0)
    {
      num_restr=prior->num_internal_restrictions();
      restr_stage=prior->stage_internal_restrictions();
      restr_q_lower=prior->logdischarge_lower_internal_restrictions();
      restr_q_upper=prior->logdischarge_upper_internal_restrictions();
    }
  if(num_restr>0 && restr_stage && restr_q_lower && restr_q_upper)
    {
      discharge_lower=new double[num_restr];
      discharge_upper=new double[num_restr];
      for(int i=0;i<num_restr;i++)
	{
	  if(restr_q_lower[i]!=MISSING_VALUE)
	    discharge_lower[i]=exp(restr_q_lower[i]);
	  else
	    discharge_lower[i]=MISSING_VALUE;
	  if(restr_q_upper[i]!=MISSING_VALUE)
	    discharge_upper[i]=exp(restr_q_upper[i]);
	  else
	    discharge_upper[i]=MISSING_VALUE;
	}
    }
  
  double *extra_lower=NULL, *extra_upper=NULL;
  int num_extra=0;
  double *extra_stage=NULL, *extra_q_lower=NULL, *extra_q_upper=NULL;
  if(prior && prior->num_extrapolation_restrictions()>0)
    {
      num_extra=prior->num_extrapolation_restrictions();
      extra_stage=prior->stage_extrapolation_restrictions();
      extra_q_lower=prior->logdischarge_lower_extrapolation_restrictions();
      extra_q_upper=prior->logdischarge_upper_extrapolation_restrictions();
    }
  if(num_extra>0 && extra_stage && extra_q_lower && extra_q_upper)
    {
      extra_lower=new double[num_extra];
      extra_upper=new double[num_extra];
      for(int i=0;i<num_extra;i++)
	{
	  if(extra_q_lower[i]!=MISSING_VALUE)
	    extra_lower[i]=exp(extra_q_lower[i]);
	  else
	    extra_lower[i]=MISSING_VALUE;
	  if(extra_q_upper[i]!=MISSING_VALUE)
	    extra_upper[i]=exp(extra_q_upper[i]);
	  else
	    extra_upper[i]=MISSING_VALUE;
	}
    }
  

  save_pre_analysis(modusmodel, prob, result,
		    
		    prior,
		    
		    measurements, q, h, dt, num_meas);
  
  if(discharge_lower)
    delete [] discharge_lower;
  if(discharge_upper)
    delete [] discharge_upper;

  if(extra_lower)
    delete [] extra_lower;
  if(extra_upper)
    delete [] extra_upper;
  
  delete modusmodel;
  
  sh.Unmap();
}


void bayes_multiseg_showcurve::recommend_spacing(void)
{
  int model=modelmenu.get_model();
  if(model>prior->get_max_seg() || model<0)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Modell m� v�re valgt for � sette "
		     "effektivitetsparametre for full analyse!", 
		     (char *) "A model must be chosen in order to set"
		     " efficiency parameters for the full analysis!"));
      return;
    }

  double max_spacing=0.0, // maximal spacing over all parameters
    max_spacing2=0.0; // maximal spacing for parameter 0 (constant)
  int l;

  for(l=0;l<(4*model+1);l++) // traverse the parameters (plus log-prob)
    // fetch the maximal spacing overall and for parameter 0
    {
      int len;
      double *val=get_samples(&len, model, l);
      if(!val)
	{
	  err.build(mainwin::toplevel, 
		    WHAT((char *) "Programfeil", (char *) "Program error"),
		    WHAT((char *) "Noe gikk galt med sample-effektivitets-"
			 "settingen!", 
			 (char *) "Something went wrong in the setting of "
			 "the sample efficiency!"));
	  return;
	}
      
      double rho=get_auto_correlation(val, len);
      double spacing=2.0*(0.5+rho/(1.0-rho));

      if(spacing>max_spacing)
	{
	  max_spacing=spacing;
	  
	  //std::cout << l << " " << param_names[l] << " " << max_spacing << std::endl;

	  if(l==0)
	    max_spacing2=spacing;
	}

      delete [] val;
    }

  // re-traverse ... (s and log-prob?). Reset max_spacing2 if
  // any psacing here are larger.
  for(l=(4*model-1);l<(4*model+1);l++)
    {
      int len;
      double *val=get_samples(&len, model, l);
      if(!val)
	{
	  err.build(mainwin::toplevel, 
		WHAT((char *) "Programfeil", (char *) "Program error"),
		WHAT((char *) "Noe gikk galt med sample-effektivitets-"
		     "settingen!", 
		     (char *) "Something went wrong in the setting of "
		     "the sample efficiency!"));
	  return;
	}
      
      double rho=get_auto_correlation(val, len);
      double spacing=2.0*(0.5+rho/(1.0-rho));

      if(spacing>max_spacing2)
	max_spacing2=spacing;

      delete [] val;
    }
  
  bool recommend_increased_burnin_and_tempering=false;
  if(max_spacing>5*max_spacing2 || max_spacing>50)
    {
      recommend_increased_burnin_and_tempering=true;
      std::cout << max_spacing << " " << max_spacing2 << std::endl;
    }
  
  max_spacing *= double(result->get_spacing());
  max_spacing2 *= double(result->get_spacing());
  
  sh.Unmap();
  preview_done((int) ceil(max_spacing), workload, 
	       analysis_time, showcurve_time, 
	       recommend_increased_burnin_and_tempering);
}


// returns the probability for trend in the residuals:
double bayes_multiseg_showcurve::
residual_analysis_categorical(BMS_COV_TYPE against_type,
			      int doabs)
{
  int i;
  int colnum=-1;

  switch(against_type)
    {
    case BMS_COV_TIME:
    case BMS_COV_STAGE:
      err.build(*this, WHAT((char *) "Programfeil", (char * ) "Program error"),
		WHAT((char *) "", (char * ) ""));
      break;
    case BMS_COV_LOCATION:
      colnum=measurements->get_column_number("location");
      if(colnum<0)
	colnum=measurements->get_column_number("place");
      if(colnum<0)
	colnum=measurements->get_column_number("placement");
      break;
    case BMS_COV_PERSON:
      colnum=measurements->get_column_number("person");
      if(colnum<0)
	colnum=measurements->get_column_number("responsible");
      if(colnum<0)
	colnum=measurements->get_column_number("observer");
      break;
    case BMS_COV_METHOD:
      colnum=measurements->get_column_number("method");
      if(colnum<0)
	colnum=measurements->get_column_number("method type");
      if(colnum<0)
	colnum=measurements->get_column_number("calibration");
      break;
    default:
      err.build(*this, WHAT((char *) "Programfeil", (char * ) "Program error"),
		WHAT((char *) "Ukjent kovariat-type!", 
		     (char * ) "Unknown covariate type!"));
      break;
    }

  if(colnum<0)
    return MISSING_VALUE;
  
  int len=num_meas;
  char **catnames=new char*[len];
  for(i=0;i<len;i++)
    {
      catnames[i]=new char[1000];
      strcpy(catnames[i],measurements->get_cell_string(colnum, i));
    }
  
  double *resids=NULL;
  char **unames=NULL;
  int ulen=0;
  bayesian_regression *nullmodel=NULL;
  double p_cat=0.0, p_null=0.0;
  
  bayesian_regression *catmodel=
    categorical_residuals_analysis(catnames,len,doabs,
				   &resids,&unames, &ulen, &nullmodel,
				   &p_cat, &p_null);

  if(ulen<2 || catmodel==NULL)
    return MISSING_VALUE;

  delete catmodel;
  if(nullmodel)
    delete nullmodel;
  if(resids)
    delete [] resids;
  doubledelete(catnames,len);

  return p_cat;
}

// returns the probability for trend in the residuals:
double bayes_multiseg_showcurve::residual_analysis(BMS_COV_TYPE against_type
						   /* 0=time */
						   /* 1=stage */,
						   int doabs)
{
  if(against_type!=BMS_COV_TIME && against_type!=BMS_COV_STAGE)
    return residual_analysis_categorical(against_type, doabs);
  
  bayesian_homogeneity_general bhg;
  int i, len=num_meas;
  int model=modelmenu.get_model();
  
  double *res=get_residuals(model);
  double *x=new double[len];
  TABLE_CONTENT coltype=
    against_type==BMS_COV_TIME ? TABLE_DATETIME : TABLE_DOUBLE;
  int colnum = 
    against_type== BMS_COV_TIME? measurements->get_column_number("time") : 
    measurements->get_column_number("stage");
  int disnum=measurements->get_column_number("discharge");
  DateTime start;

  for(i=0;i<len;i++)
    if(i==0 || measurements->get_cell_datetime(colnum, i)<start)
      start=measurements->get_cell_datetime(colnum, i);
  
  int kk=0;
  for(i=0;i<ret_num_meas;i++)
    {
      double Q_buff=measurements->get_cell_double(disnum, i);
      if(Q_buff>MIN_Q)
	{
	  if(coltype==TABLE_DOUBLE)
	    x[kk]=measurements->get_cell_double(colnum, i);
	  else
	    {
	      DateTime dt=measurements->get_cell_datetime(colnum, i);
	      x[kk]=(double) dt.difference_minutes(start);
	    }
	  
	  kk++;
	}
    }    
  
  for(i=0;i<len;i++)
    {
      if(doabs && res[i]!=MISSING_VALUE)
	res[i]=ABSVAL((res[i]));
      
      //if(against_type==BMS_COV_TIME)
      //printf("%d %f %f %f\n", i, x[i], res[i], q[i]);
    }
  
  double sd_const=1e-6, sd_slope=MISSING_VALUE;
  double sigma_a=prior->get_sigma_a(),
    sigma_b=prior->get_sigma_b();
  sd_const=sqrt(sigma_b/(sigma_a-1.0));
  if(against_type!=BMS_COV_TIME)
    sd_slope=0.1;
  else
    sd_slope=0.01;
  //bool do_trend=True;
  
  double *argbuff=new double[len];
  for(i=0;i<len;i++)
    argbuff[i]=x[i];
  qsort(argbuff, size_t(len), sizeof(double), compare_double);
  int numsep=1;
  for(i=1;i<len;i++)
    if(argbuff[i]!=argbuff[i-1])
      numsep++;
  delete [] argbuff;
  //if(numsep<3)
  //do_trend=False;
  
  double p_hom; // , p_onestep, p_twostep, p_lin, p_quad;
  //BAYESIAN_TIMESERIE_MODEL mostprob;
  
  bhg.set_data(x, res, len);
  bhg.set_priors(sigma_a, sigma_b, 0.0, sd_const, sd_slope);
  //if(against_type==BMS_COV_TIME)
  //bhg.show_priors_general();
  bhg.calculate_aposteriori();
  p_hom=bhg.homogeneity_probability();
  //p_onestep=bhg.full_step_model_probability();
  //p_twostep=bhg.full_twostep_probability();
  //p_lin=bhg.linear_probability();
  //p_quad=bhg.quadratic_probability();
  //mostprob=bhg.get_most_probable_model();
  
  double p_trend=1.0-p_hom;
  
  delete [] res;
  delete [] x;
  
  return p_trend;
}




bayesian_regression *bayes_multiseg_showcurve::
residuals_vs_categorical(// input:
			   double *resids, int len, char **category_names,

			   // extra output:
			   char ***unique_categories, 
			   int *num_unique_categories
			 )
{
  // Find number of unique categories:
  int i,j,ulen;
  char **unames=unique_strings_caseinsensitive(category_names, len, &ulen);

  *num_unique_categories=ulen;
  *unique_categories=unames;

  if(ulen<2)
    return NULL;
  
  int numpred=ulen;

  double *m=new double[numpred], **v=new double*[numpred];
  double **predictor=new double*[numpred];
  
  for(i=0;i<numpred;i++)
    {
      m[i]=0.0;
      v[i]=new double[numpred];
      for(j=0;j<numpred;j++)
	if(i==j)
	  v[i][j]=1.0;
	else
	  v[i][j]=0.0;
    }
  
  for(i=0;i<numpred;i++)
    {
      predictor[i]=new double[len];
      
      for(j=0;j<len;j++)
	predictor[i][j]=0.0;
      
      for(j=0;j<len;j++)
	if(!strcasecmp(unames[i],category_names[j]))
	  predictor[i][j]=1.0;
    }
  
  bayesian_regression *catmodel=get_bayesian_regression(predictor, numpred,
							resids, len,
							m, v, 4.0, 0.03);
  delete [] m;
  doubledelete(v,numpred);
  doubledelete(predictor,numpred);
  
  return catmodel;
}


bayesian_regression *bayes_multiseg_showcurve::
categorical_residuals_analysis(char **category_names, int len, bool doabs,
				
			       // extra output:
			       double **resids,
			       char ***unique_categories, 
			       int *num_unique_categories,
			       bayesian_regression **nullmodel,
			       double *prob_cat, double *prob_null
			       )	 
{
  int i;
  int model=modelmenu.get_model();
  double *res=get_residuals(model);
  if(doabs)
    for(i=0;i<len;i++)
      res[i]=ABSVAL((res[i]));
  
  double *singlepred=new double[len];
  double *m=new double[1], **v=new double*[1];
  bayesian_regression *singleconst=NULL;
  
  double prior_null=0.5;
  
  m[0]=0.0;
  v[0]=new double[1];
  v[0][0]=0.5*0.5;
  
  for(i=0;i<len;i++)
    singlepred[i]=1.0;
  singleconst=get_bayesian_regression(&singlepred, 1, res, len,
				      m, v, 4.0, 0.03);
  delete [] m;
  doubledelete(v,1);
  
  *nullmodel=singleconst;
  
  bayesian_regression *ret=
    residuals_vs_categorical(res,len,category_names,
			     unique_categories, num_unique_categories);
  if(*num_unique_categories<2 || ret==NULL)
    return NULL;
  
  double loglik=singleconst->probability_density_of_data(true);
  double lik_null=singleconst->probability_density_of_data(false,loglik);
  double lik_cat=ret->probability_density_of_data(false, loglik);
  double p_null=prior_null*lik_null, p_cat=(1.0-prior_null)*lik_cat;
  double scale=p_cat+p_null;
  
  p_null/=scale;
  p_cat/=scale;

  *prob_cat=p_cat;
  *prob_null=p_null;
  *resids=res;
  
  return ret;
}

void bayes_multiseg_showcurve::show_residuals_categorical(void)
{
  int i, len=num_meas;
  int againsttype=resmenu.GetNumber();
  bool doabs=resabstog();
  char *mtype=measurements->get_attributes()->get_name(againsttype);
  
  char **catnames=new char*[len];
  for(i=0;i<len;i++)
    {
      catnames[i]=new char[1000];
      strcpy(catnames[i],measurements->get_cell_string(againsttype, i));
    }

  bayesian_regression *nullmodel=NULL;
  char **unames=NULL;
  int ulen;
  double p_null, p_cat, *resids=NULL;
  
  bayesian_regression *catmodel=
    categorical_residuals_analysis(catnames,len,doabs,
				   &resids,&unames, &ulen, &nullmodel,
				   &p_cat, &p_null);
  
  if(ulen<2 || !catmodel || !nullmodel || !resids)
    {
      char errstr[1000];
      sprintf(errstr, WHAT((char *) "Ingen variasjon i kategori for %s", 
			   (char *) "No variation in category for %s"), mtype);
      
      err.build(mainwin::toplevel, 
		WHAT((char *) "Feil", (char *) "Error"),
		errstr);
      
      doubledelete(unames,ulen);
      doubledelete(catnames,len);
      if(nullmodel)
	delete nullmodel;
      if(catmodel) 
	delete catmodel;
      if(resids)
	delete [] resids;
      
      return;
    }

  extraplot=new plot_shell();
  
  int **arg=new int*[2];
  double **val=new double*[2];
  char **linetitles=new char*[2];
  char **axistitles=new char*[2];
  int plotlen[2], axis[2];
  PLOTLINE_TYPE type[2];
  double *pred=new double[ulen];
  
  linetitles[0]=new char[100];
  if(doabs)
    strcpy(linetitles[0], "Absolutt-avvik (residualer)");
  else
    strcpy(linetitles[0], "Avvik (residualer)");
  linetitles[1]=new char[100];
  sprintf(linetitles[1], "Troverdighetsintervall for avvik gitt %s, "
	  "sannsynlighet for trend=%7.3f%%", mtype, p_cat*100.0);
  
  axistitles[0]=new char[30];
  strcpy(axistitles[0], mtype);
  axistitles[1]=new char[30];
  if(doabs)
    strcpy(axistitles[1], "Absolutt-avvik");
  else
    strcpy(axistitles[1], "Avvik");
  
  val[0]=new double[len];
  arg[0]=new int[len];
  for(i=0;i<len;i++)
    {
      val[0][i]=resids[i];
      
      int j=0;
      while(j<ulen && strcasecmp(catnames[i],unames[j]))
	j++;
      if(j<ulen)
	arg[0][i]=j+1;
      else
	{
	  arg[0][i]=1;
	  val[0][i]=MISSING_VALUE;
	}
    }
  plotlen[0]=len;
  axis[0]=1;
  type[0]=PLOTLINE_DOT;

  plotlen[1]=3*ulen;
  arg[1]=new int[plotlen[1]];
  val[1]=new double[plotlen[1]];
  axis[1]=1;
  type[1]=PLOTLINE_LINE;
  
  for(i=0;i<ulen;i++)
    {
      for(int j=0;j<ulen;j++)
	if(i==j)
	  pred[j]=1.0;
        else
	  pred[j]=0.0;
      
      arg[1][3*i]=i+1;
      val[1][3*i]=catmodel->lower_estimate_credibility(pred, 0.95);
      arg[1][3*i+1]=i+1;
      val[1][3*i+1]=catmodel->upper_estimate_credibility(pred, 0.95);
      arg[1][3*i+2]=i+1;
      val[1][3*i+2]=MISSING_VALUE;
    }
  
  extraplot->make_plotting_window(900,700,WHAT((char *) "Residualplott", 
						(char *) "Residual plot"));
  extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_outer_rectangle(False);
  extraplot->set_inner_rectangle(False);
  extraplot->Create(arg,ulen,unames,
		    val,plotlen,axis,linetitles,2,axistitles,2,
		    NULL,type);
  
  doubledelete(arg,2);
  doubledelete(val,2);
  doubledelete(linetitles,2);
  doubledelete(axistitles,2);
  delete [] pred;

  delete nullmodel;
  delete catmodel;
  doubledelete(unames,ulen);
  delete [] resids;
}



void bayes_multiseg_showcurve::show_residual_histogram(void)
{
  int i, len=num_meas;
  int model=modelmenu.get_model(); // number of segments
  double *res=get_residuals(model);
  if(!res)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen residualer funnet!", 
		     (char *) "No residuals found!"));
      return;
    }

  double **val=new double*[1];
  val[0]=new double[len];
  for(i=0;i<len;i++)
    val[0][i]=res[i];

  char **linetitles=new char*[1];
  int *linelen=new int[1];
  linelen[0]=len;
  
  if(extrahist)
    delete extrahist;
  extrahist=new histogram();
  
  linetitles[0]=new char[100];
  strcpy(linetitles[0], WHAT((char *) "Residualer", (char *) "Residuals"));

  extrahist->set_x_axis_font_size(PLOT_FONT_LARGE);
  extrahist->set_y_axis_font_size(PLOT_FONT_MEDIUM);
  extrahist->set_outer_rectangle(False);
  extrahist->set_inner_rectangle(False);
  // extrahist->set_big();
  extrahist->create(val, linelen, 1, linetitles, linetitles[0], 
		    WHAT((char *) "Hyppighet", (char *) "Frequency"));
  doubledelete(val, 1); 
  doubledelete(linetitles,1);
  delete [] linelen;
  delete [] res;
}


void bayes_multiseg_showcurve::show_residual_qqplot(void)
{
  int i, len=num_meas;
  int model=modelmenu.get_model(); // number of segments
  double *res=get_residuals(model);
  if(!res)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen residualer funnet!", 
		     (char *) "No residuals found!"));
      return;
    }

  qsort(res, size_t(len), sizeof(double), compare_double);

  double mu=find_statistics(res, len, MEAN);
  double sd=find_statistics(res, len, STANDARD_DEVIATION);

  double **arg=new double*[2];
  double **val=new double*[2];
  arg[0]=new double[len];
  val[0]=new double[len];
  for(i=0;i<len;i++)
    {
      arg[0][i]=mu+sd*gsl_cdf_ugaussian_Pinv(double(i+1)/double(len+1));
      val[0][i]=res[i];
    }

  double min=find_statistics(arg[0], len, MIN);
  double max=find_statistics(arg[0], len, MAX);
  arg[1]=new double[2];
  val[1]=new double[2];
  arg[1][0]=val[1][0]=min;
  arg[1][1]=val[1][1]=max;


  char **axistitles=new char*[2];
  axistitles[0]=new char[200];
  sprintf(axistitles[0], WHAT((char *) "Teoretiske kvantiler", 
			      (char *) "Theoretical quantiles"));
  axistitles[1]=new char[200];
  sprintf(axistitles[1], WHAT((char *) "Residualer", 
			      (char *) "Residuals"));

  char **linetitles=new char*[2];
  linetitles[0]=new char[100];
  strcpy(linetitles[0], WHAT((char *) "Residualer vs normalfordelings-"
			     "kvantiler (QQ-plott)", 
			     (char *) "Residuals vs normal distribution "
			     "quantiles (QQ plot)"));
  linetitles[1]=new char[100];
  strcpy(linetitles[1], "");
  
  int *linelen=new int[2];
  linelen[0]=len;
  linelen[1]=2;
  
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[2];
  type[0]=PLOTLINE_DOT;
  type[1]=PLOTLINE_LINE;

  int *axis=new int[2];
  axis[0]=axis[1]=1;

  //if(extraplot)
  //delete extraplot;
  extraplot=new plot_shell();
  
  extraplot->make_plotting_window(1000,800,WHAT((char *) "QQ-plott", 
						(char *) "QQ plot"));
  extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_outer_rectangle(False);
  extraplot->set_inner_rectangle(False);
  extraplot->Create(arg, val, linelen, axis, linetitles, 2,
		    axistitles, 2, NULL, type);

  doubledelete(val, 2); 
  doubledelete(arg, 2); 
  doubledelete(linetitles,2);
  doubledelete(axistitles,2);
  delete [] linelen;
  delete [] res;
  delete [] axis;
  delete [] type;
}


void bayes_multiseg_showcurve::show_residual_trend(void)
{
  int againsttype=resmenu.GetNumber();
  bool doabs=resabstog();
  char *mtype=measurements->get_attributes()->get_name(againsttype);
  TABLE_CONTENT coltype=measurements->get_column_type(againsttype);

  if(coltype==TABLE_CHAR || coltype==TABLE_STRING)
    {
      show_residuals_categorical();
      return;
    }

  bayesian_homogeneity_general bhg;

  //if(extraplot)
  //delete extraplot;
  extraplot=new plot_shell();
  
  int i, j, len=num_meas;
  int model=modelmenu.get_model();
  int numseg=model;

  double *predicted=get_predicted(model);
  double *res=get_residuals(model);
  
  int numplots=2, orig_numplots=numplots;

  int *num=new int[numplots], *axis=new int[numplots];
  double **arg=new double*[numplots], **val=new double*[numplots];
  DateTime **dtarg=new DateTime*[numplots];
  char **linetitles=new char*[numplots], **axistitles=new char*[2];
  PLOTLINE_TYPE *ptype=new PLOTLINE_TYPE[numplots];
  
  int dtcolnum = measurements->get_column_number("time");
  DateTime start;
  
  for(i=0;i<len;i++)
    if(i==0 || measurements->get_cell_datetime(dtcolnum, i)<start)
      start=measurements->get_cell_datetime(dtcolnum, i);
  
  for(j=0;j<numplots;j++)
    {
      if(j==0)
	num[j]=len;
      else
	num[j]=1000;
      axis[j]=1;
      arg[j]=new double[num[j]];
      dtarg[j]=new DateTime[num[j]];
      val[j]=new double[num[j]];
      linetitles[j]=new char[100];
      if(j==0)
	ptype[j]=PLOTLINE_DOT;
      else
	ptype[j]=PLOTLINE_LINE;
    }
  
  if(!doabs)
    sprintf(linetitles[0], WHAT((char *) "Residualer=log(m�lt vannf�ring/"
				"estimert vannf�ring)", 
				(char *) "Residuals=log(measured "
				"discharge/estimated discharge)"));
  else
    sprintf(linetitles[0], WHAT((char *) "Residualer=abs(log(m�lt vannf�ring/"
				"estimert vannf�ring))", 
				(char *) "Residuals=abs(log(measured "
				"discharge/estimated discharge))"));
  
  if(model>0)
    sprintf(linetitles[0]+strlen(linetitles[0]), 
	    WHAT((char *) " for %d segmentert modell", 
		 (char *) " for %d segment model"), numseg);
  else
    sprintf(linetitles[0]+strlen(linetitles[0]), 
	    WHAT((char *) " for total-modell", 
		 (char *) " for total model"));

  int kk=0;
  int disnum=measurements->get_column_number("discharge");
  for(i=0;i<ret_num_meas;i++)
    {
      double Q_buff=measurements->get_cell_double(disnum,i);
      if(Q_buff>=MIN_Q)
	{
	  switch(coltype)
	    {
	    case TABLE_DOUBLE:
	      if(!strcmp(mtype, "discharge"))
		arg[0][kk]=predicted[kk];
	      else
		arg[0][kk]=measurements->get_cell_double(againsttype, i);
	      break;
	    case TABLE_INT:
	      arg[0][kk]=(double) measurements->get_cell_int(againsttype, i);
	      break;
	    case TABLE_DATETIME:
	      dtarg[0][kk]=measurements->get_cell_datetime(againsttype, i);
	      arg[0][kk]=(double) dtarg[0][kk].difference_minutes(start);
	      //if(k==len-1)
	      //std::cout << dtarg[0][k] << " " << arg[0][k] << " " << 
	      //  start << std::endl;
	      break;
	    case TABLE_CHAR:
	      arg[0][kk]=(double) measurements->get_cell_char(againsttype, i);
	      break;
	    case TABLE_STRING:
	      {
		int dbuffer;
		char *strptr=measurements->get_cell_string(againsttype, i),
		  *strptr2=strptr;
		while(*strptr!='\0' && *strptr!='(')
		  strptr++;
		
		if(*strptr && sscanf(strptr, "%d", &dbuffer))
		  arg[0][kk]=(double) dbuffer;
		else if(sscanf(strptr2, "%d", &dbuffer))
		  arg[0][kk]=(double) dbuffer;
		else
		  {
		    arg[0][kk]=256.0*256.0*double(strptr2[0]);
		    if(strptr2[1])
		      {
			arg[0][kk]+=256.0*double(strptr2[1]);	
			if(strptr2[2])
			  arg[0][kk]+=double(strptr2[2]);
		      }
		  }
		
		break;
	      }
	    default:
	      arg[0][kk]=-1.0;
	      break;
	    }
	  
	  kk++;
	}
    }    

  for(i=0;i<len;i++)
    {
      val[0][i]=res[i];
      if(doabs && val[0][i]!=MISSING_VALUE)
	val[0][i]=ABSVAL((val[0][i]));
      //printf("%d %f %f %f\n", i, arg[0][i], val[0][i], q[i]); 
    }
  
  double sd_const=1e-6, sd_slope=MISSING_VALUE;
  double sigma_a=prior->get_sigma_a(),
    sigma_b=prior->get_sigma_b();
  sd_const=sqrt(sigma_b/(sigma_a-1.0));
  sd_slope=find_statistics(arg[0], len, MEAN);
  if(coltype==TABLE_DOUBLE && !strcmp(mtype, "stage"))
    sd_slope=0.1;
  if(coltype==TABLE_DATETIME)
    sd_slope=0.01;
  bool do_trend=True;
  
  // Sort the combined covariates and residuals according to the covariate:
  double_3d *cov_res=new double_3d[len];
  for(i=0;i<len;i++)
    {
      cov_res[i].x=arg[0][i];
      cov_res[i].y=val[0][i];
      cov_res[i].z=q[i]; // added for debug reasons
    }
  qsort(cov_res, size_t(len), sizeof(double_3d), compare_double_3d_x);
  //for(i=0;i<len;i++)
  //printf("s%d %f %f %f\n", i, cov_res[i].x, cov_res[i].y, cov_res[i].z);
  if(coltype==TABLE_DATETIME)
    {
      // re-order the date-time-array of the measurements:
      DateTime *dtbuff=new DateTime[len];
      for(i=0;i<len;i++)
	for(j=0;j<len;j++)
	  if(cov_res[i].x==arg[0][j] && cov_res[i].y==val[0][j] &&
	     cov_res[i].z==q[j])
	    dtbuff[i]=dtarg[0][j];
      delete [] dtarg[0];
      dtarg[0]=dtbuff;
    }

  // Put the sorted data back into the arg,val-arrays. Count the number
  // of separate arguments:
  int numsep=1;
  for(i=0;i<len;i++)
    {
      arg[0][i]=cov_res[i].x;
      val[0][i]=cov_res[i].y;
      if(i>0)
	if(val[0][i]!=val[0][i-1])
	  numsep++;
    }
  
  // No trend analysis if the number of separate arguments (covariates) are
  // less than 3:
  if(numsep<3)
    do_trend=False;
  delete [] cov_res;
  
  // Do trend analysis:
  double p_hom=0.0, p_onestep=0.0, p_twostep=0.0, p_lin=0.0, p_quad=0.0;
  BAYESIAN_TIMESERIE_MODEL mostprob=BAYESIAN_HOMOGENEITY;
  if(do_trend)
    {
      bhg.set_data(arg[0], val[0], len);
      bhg.set_priors(sigma_a, sigma_b, 0.0, sd_const, sd_slope);
      //bhg.show_priors_general();
      bhg.calculate_aposteriori();
      p_hom=bhg.homogeneity_probability();
      p_onestep=bhg.full_step_model_probability();
      p_twostep=bhg.full_twostep_probability();
      p_lin=bhg.linear_probability();
      p_quad=bhg.quadratic_probability();

      //mostprob=bhg.get_most_probable_model();
      
      if(p_hom<p_onestep+p_twostep+p_lin+p_quad)
	{
	  if(p_onestep>=p_twostep && p_onestep>=p_lin && 
	     p_onestep>=p_quad)
	    mostprob=BAYESIAN_ONESTEP;
	  else if(p_twostep>=p_lin && p_twostep>=p_quad)
	    mostprob=BAYESIAN_TWOSTEP;
	  else if(p_lin>=p_quad)
	    mostprob=BAYESIAN_LINEAR;
	  else
	    mostprob=BAYESIAN_QUADRATIC;
	}
      else
	{
	  mostprob=BAYESIAN_HOMOGENEITY;
	  do_trend=False;
	}
    }

  // If a trend was found, show that trend:
  if(do_trend)
    {
      double min_x=find_statistics(arg[0], len, MIN),
	max_x=find_statistics(arg[0], len, MAX),
	mean_x=find_statistics(arg[0], len, MEAN);
      double dx=(max_x-min_x)/double(num[1]-1);      

      for(i=0;i<num[1];i++)
	{
	  arg[1][i]=min_x+double(i)*dx;
	  dtarg[1][i]=start;
	  dtarg[1][i].add_minutes((int) arg[1][i]);
	}

      switch(mostprob)
	{
	case BAYESIAN_LINEAR:
	  sprintf(linetitles[1], 
		  WHAT((char *) "Line�r trend med %6.2f%% sanns. "
		       "(homogen=%6.2f%%)",
		       (char *) "Linear trend with %6.2f%% prob. "
		       "(homogen=%6.2f%%)"),
		  p_lin*100.0, p_hom*100.0);
	  for(i=0;i<num[1];i++)
	    val[1][i]=bhg.linear_mean_intercept()+bhg.linear_mean_slope()*
	      (arg[1][i]-mean_x);
	  break;
	case BAYESIAN_QUADRATIC:
	  sprintf(linetitles[1], 
		  WHAT((char *) "Kvadratisk trend med %6.2f%% sanns. "
		       "(homogen=%6.2f%%)",
		       (char *) "Quadratic trend with %6.2f%% prob. "
		       "(homogen=%6.2f%%)"),
		  p_quad*100.0, p_hom*100.0);
	  for(i=0;i<num[1];i++)
	    val[1][i]=bhg.linear_mean_intercept()+bhg.quadratic_mean_slope()*
	      (arg[1][i]-mean_x)+bhg.quadratic_mean_curvature()*
	      (arg[1][i]-mean_x)*(arg[1][i]-mean_x);
	  break;
	case BAYESIAN_ONESTEP:
	  sprintf(linetitles[1], 
		  WHAT((char *) "Ett-sprangs trend med %6.2f%% sanns. "
		       "(homogen=%6.2f%%)",
		       (char *) "One step trend with %6.2f%% prob. "
		       "(homogen=%6.2f%%)"),
		  p_onestep*100.0, p_hom*100.0);
	  for(i=0;i<num[1];i++)
	    if(arg[1][i]<=bhg.x_maxprob_before_step())
	      val[1][i]=bhg.maxprob_step_mean_before();
	    else
	      val[1][i]=bhg.maxprob_step_mean_after();
	  break;
	case BAYESIAN_TWOSTEP:
	  sprintf(linetitles[1], 
		  WHAT((char *) "To-sprangs trend med %6.2f%% sanns. "
		       "(homogen=%6.2f%%)",
		       (char *) "Two step trend with %6.2f%% prob. "
		       "(homogen=%6.2f%%)"),
		  p_twostep*100.0, p_hom*100.0);
	  for(i=0;i<num[1];i++)
	    if(arg[1][i]<=bhg.x_maxprob_twostep_before_step1())
	      val[1][i]=bhg.maxprob_twostep_mean_before1();
	    else if(arg[1][i]<=bhg.x_maxprob_twostep_before_step2())
	      val[1][i]=bhg.maxprob_twostep_mean_after1();
	    else
	      val[1][i]=bhg.maxprob_twostep_mean_after2();
	  break;
	default:
	  break;
	}
      
      sprintf(linetitles[1]+strlen(linetitles[1]),
	      WHAT((char *) " Total trendsanns. "
		   "%6.2f%%)", 
		   (char *) " Total trend prob. "
		   "%6.2f%%)"), 100.0*(1.0-p_hom));
    }
  else
    numplots=1;
  
  axistitles[0]=new char[100];
  
  if(!strcmp(mtype, "stage"))
    strcpy(axistitles[0], WHAT((char *) "Vannstand (m)", 
			       (char *) "Stage (m)"));
  else if(!strcmp(mtype, "discharge"))
    strcpy(axistitles[0], WHAT((char *) "Predikert vannf�ring (m^3/s)", 
			       (char *) "Predicted discharge (m^3/s)"));
  else if(!strcmp(mtype, "time"))
    strcpy(axistitles[0], WHAT((char *) "Tid", (char *) "Time"));
  else 
    strcpy(axistitles[0], 
	   measurements->get_attributes()->get_name(againsttype));

  axistitles[1]=new char[100];
  strcpy(axistitles[1], "Res.");
  
  extraplot->make_plotting_window(900,700,WHAT((char *) "Spredningsplott", 
						(char *) "Scatter plot"));
  extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
  extraplot->set_outer_rectangle(False);
  extraplot->set_inner_rectangle(False);
  //extraplot->set_big();
  if(coltype==TABLE_DATETIME)
    extraplot->Create(dtarg, val, num, axis, linetitles, numplots,
		      axistitles, 2, meas_text, ptype);
  else
    extraplot->Create(arg, val, num, axis, linetitles, numplots,
		      axistitles, 2, meas_text, ptype);
  
  doubledelete(arg,orig_numplots);
  doubledelete(dtarg,orig_numplots);
  doubledelete(val,orig_numplots);
  doubledelete(axistitles,2);
  doubledelete(linetitles,orig_numplots);
  delete [] axis;
  delete [] num;
  delete [] ptype;
  delete [] res;
  delete [] predicted;
}
  
double bayes_multiseg_showcurve::get_rel_uncertainty(double stage)
{
  int model=modelmenu.get_model();
  if(model>prior->get_max_seg() || model<0)
    model=-1;

  double med=result->get_discharge_quantile(stage,50.0, model);
  double upper=result->get_discharge_quantile(stage,97.5, model);
  double lower=result->get_discharge_quantile(stage,2.5, model);
  
  return (upper-lower)/med;
}

void bayes_multiseg_showcurve::show_model_params(void)
{
  segmented_curve *modcurve;
  int i,j,model=modelmenu.get_model();
  if(model>prior->get_max_seg() || model<0)
    modcurve=result->get_best_modus_curve(x2);
  else
    modcurve=result->get_modus_curve(model,x2);
  
  int numseg=model;
  
  char buffer[1000];

  modelparams.Clear();

  bool extrapolated=false;
  if(model>prior->get_max_seg() || model<0)
    {
      sprintf(buffer, WHAT((char *) "Ingen modell valgt\n\n", 
			   (char *) "No model chosen\n\n"));
      modelparams+=buffer;
      sprintf(buffer, WHAT((char *) "Estimat:\n", (char *) "Estimates:\n"));
      modelparams+=buffer;
    }
  else
    {
      if(!extrapolated)
	sprintf(buffer, WHAT((char *) "Modell med %d segmenter valgt.\n", 
			     (char *) "Model with %d segments chosen.\n"),
		numseg);
      else
	sprintf(buffer, WHAT((char *) "Modell med %d segmenter i interpolert "
			     "omr�de  valgt.\n", 
			     (char *) "Model with %d segments in interpolated "
			     "area chosen.\n"),
		numseg);
      modelparams+=buffer;
      sprintf(buffer, WHAT((char *) "Sannsynlighet=%7.3g%%\n\n", 
			   (char *) "Probability=%7.3g%%\n\n"),
	      result->get_probability_of_model(numseg)*100.0);
      modelparams+=buffer;

      if(modcurve && modcurve->is_extrapoled_array())
	{
	  for(i=1;i<=modcurve->get_numseg();i++)
	    if(modcurve->is_extrapoled(i))
	      extrapolated=true;
	}

      if(!extrapolated)
	{
	  sprintf(buffer, WHAT((char *) "Estimat:\n", (char *) "Estimates:\n"));
	  modelparams+=buffer;
	}
      else
	{
	  sprintf(buffer, WHAT((char *) "Det finnes ekstrapolerte segmenter"
			       " i kurve for estimerte parametre.\n"
			       "Estimat for interpolerte deler:\n", 
			       (char *) "There are extrapolated segments for "
			       "the curve for estimated parameters.\n"
			       "Estimates for interpolated parts:\n"));
	  modelparams+=buffer;
	  mess.build(mainwin::toplevel, 
		     WHAT((char *) "Merk:", (char *) "Note:"),
		     WHAT((char *) "Det finnes segmenter i ekstrapolert "
			  "omr�de (p.g.a. f�rkunnskap p� spesifikke "
			  "vannstander).",
			  (char *) "There are segments in the extrapolated "
			  "area (because of prior knowledge for specific "
			  "stage values)."));
	}
    }
  
  int parlen;
  double *par=result->get_a_samples(&parlen, model);
  sprintf(buffer, "C1=%7.3f     95%% cred=(%7.3f,%7.3f)\n", 
	  modcurve ? exp(modcurve->get_a_interpolated()) : MISSING_VALUE,
	  exp(find_percentile(par, parlen, 0.025)),
	  exp(find_percentile(par, parlen, 0.975)));
  modelparams+=buffer;
  delete [] par;
  
  if(model>0)
    {
      for(j=1;j<numseg;j++)
	{
	  par=result->get_higher_a_samples(&parlen, numseg, j+1);
	  sprintf(buffer, "C%d=%7.3f     95%% cred=(%7.3f,%7.3f)\n",  j+1,
		  modcurve ? exp(modcurve->get_a(j+1)) : MISSING_VALUE,
		  exp(find_percentile(par, parlen, 0.025)),
		  exp(find_percentile(par, parlen, 0.975)));
	  modelparams+=buffer;
	  
	  delete [] par;
	}
      
      double *b=modcurve ? modcurve->get_b_array_interpolated() : NULL;
      for(j=0;j<numseg;j++)
	{
	  par=result->get_b_samples(&parlen, numseg, j+1);
	  sprintf(buffer, "b%d=%7.3f     95%% cred=(%7.3f,%7.3f)\n",  j+1,
		  b ? b[j] : MISSING_VALUE,
		  find_percentile(par, parlen, 0.025),
		  find_percentile(par, parlen, 0.975));
	  modelparams+=buffer;
	  
	  if(j==(numseg-1))
	    b_uncert=find_percentile(par, parlen, 0.975)-
	      find_percentile(par, parlen, 0.025);
	  
	  delete [] par;
	}
      if(b)
	delete [] b;

      double *h0=modcurve ? modcurve->get_h0_array_interpolated() : NULL;
      for(j=0;j<numseg;j++)
	{
	  par=result->get_h0_samples(&parlen, numseg, j+1);
	  sprintf(buffer, "h0%d=%7.3f    95%% cred=(%7.3f,%7.3f)\n", j+1,
		  h0 ? h0[j] : MISSING_VALUE,
		  find_percentile(par, parlen, 0.025),
		  find_percentile(par, parlen, 0.975));
	  modelparams+=buffer;
	  
	  if(j==0)
	    h0_uncert=find_percentile(par, parlen, 0.975)-
	      find_percentile(par, parlen, 0.025);
	  
	  delete [] par;
	}
      if(h0)
	delete [] h0;
      
      double *hs=modcurve ? modcurve->get_hs_array_interpolated() : NULL;
      for(j=0;j<(numseg-1);j++)
	{
	  par=result->get_hs_samples(&parlen, numseg, j+1);
	  sprintf(buffer, "hs%d=%7.3f    95%% cred=(%7.3f,%7.3f)\n", j+1,
		  hs ? hs[j] : MISSING_VALUE,
		  find_percentile(par, parlen, 0.025),
		  find_percentile(par, parlen, 0.975));
	  modelparams+=buffer;
	  delete [] par;
	}
      if(hs)
	delete [] hs;
    }
  
  par=result->get_s_samples(&parlen, model);
  sprintf(buffer, "sigma=%7.3f  95%% cred=(%7.3f,%7.3f)\n",
	  modcurve ? modcurve->get_sigma() : MISSING_VALUE,
	  find_percentile(par, parlen, 0.025),
	  find_percentile(par, parlen, 0.975));
  modelparams+=buffer;
  sigma_estimated=modcurve ? modcurve->get_sigma() : MISSING_VALUE;
  delete [] par;

  if(modcurve)
    {
      double *r=get_residuals(model);
      double B=bayes_outlier_detection(r, num_meas);
      p_outlier=1.0/(1.0+1.0/B); // Bayes formula
      sprintf(buffer, WHAT((char *) "\nSanns. for feilm�linger: %7.4f%%\n",
			   (char *) "\nProbability for outliers: %7.4f%%\n"), 
	      100.0*p_outlier);
      modelparams+=buffer;
      delete [] r;

      p_trend_time=residual_analysis(BMS_COV_TIME,0);
      sprintf(buffer, WHAT((char *) "Tidstrend i st�yleddene: %7.4f%% sanns.\n",
			   (char *) "Time trend in the noise: %7.4f%% prob.\n"), 
	      100.0*p_trend_time);
      modelparams+=buffer;
      
      p_abstrend_time=residual_analysis(BMS_COV_TIME,1);
      sprintf(buffer, WHAT((char *) "Tidstrend i st�yst�rrelse: %7.4f%% sanns.\n",
			   (char *) "Time trend in the noise size: %7.4f%% "
		       "prob.\n"), 
	      100.0*p_abstrend_time);
      modelparams+=buffer;
      
      p_trend_stage=residual_analysis(BMS_COV_STAGE,0);
      sprintf(buffer, WHAT((char *) "Vst-trend i st�yledd: %7.4f%% sanns.\n",
			   (char *) "Stage trend in the noise: %7.4f%% prob\n"), 
	      100.0*p_trend_stage);
      modelparams+=buffer;
      
      p_abstrend_stage=residual_analysis(BMS_COV_STAGE,1);
      sprintf(buffer, WHAT((char *) "Vst-trend i st�yst�rrelse: %7.4f%% sanns.\n",
			   (char *) "Stage trend in the noise size: %7.4f%% "
			   "prob.\n"), 
	      100.0*p_abstrend_stage);
      modelparams+=buffer;

      p_trend_location=residual_analysis(BMS_COV_LOCATION,0);
      if(p_trend_location!=MISSING_VALUE)
	{
	  sprintf(buffer, WHAT((char *) "Lokasjons-trend i st�yledd: "
			       "%7.4f%% sanns.\n",
			       (char *) "Location trend in the noise: "
			       "%7.4f%% prob\n"), 
		  100.0*p_trend_location);
	  modelparams+=buffer;
	}
      
      p_abstrend_location=residual_analysis(BMS_COV_LOCATION,1);
      if(p_abstrend_location!=MISSING_VALUE)
	{
	  sprintf(buffer, WHAT((char *) "Lokasjons-trend i st�yst�rrelse: "
			       "%7.4f%% sanns.\n",
			       (char *) "Location trend in the noise size: "
			       "%7.4f%% prob.\n"), 
		  100.0*p_abstrend_location);
	  modelparams+=buffer;
	}

      p_trend_person=residual_analysis(BMS_COV_PERSON,0);
      if(p_trend_person!=MISSING_VALUE)
	{
	  sprintf(buffer, WHAT((char *) "Person-trend i st�yledd: "
			       "%7.4f%% sanns.\n",
			       (char *) "Person trend in the noise: "
			       "%7.4f%% prob\n"), 
		  100.0*p_trend_person);
	  modelparams+=buffer;
	}
      
      p_abstrend_person=residual_analysis(BMS_COV_PERSON,1);
      if(p_abstrend_person!=MISSING_VALUE)
	{
	  sprintf(buffer, WHAT((char *) "Person-trend i st�yst�rrelse: "
			       "%7.4f%% sanns.\n",
			       (char *) "Person trend in the noise size: "
			       "%7.4f%% prob.\n"), 
		  100.0*p_abstrend_person);
	  modelparams+=buffer;
	}

      p_trend_method=residual_analysis(BMS_COV_METHOD,0);
      if(p_trend_method!=MISSING_VALUE)
	{
	  sprintf(buffer, WHAT((char *) "Metode-trend i st�yledd: "
			       "%7.4f%% sanns.\n",
			       (char *) "Method trend in the noise: "
			       "%7.4f%% prob\n"), 
		  100.0*p_trend_method);
	  modelparams+=buffer;
	}
      
      p_abstrend_method=residual_analysis(BMS_COV_METHOD,1);
      if(p_abstrend_method!=MISSING_VALUE)
	{
	  sprintf(buffer, WHAT((char *) "Metode-trend i st�yst�rrelse: "
			       "%7.4f%% sanns.\n",
			       (char *) "Method trend in the noise size: "
			       "%7.4f%% prob.\n"), 
		  100.0*p_abstrend_method);
	  modelparams+=buffer;
	}
    }
  
  double *hsort=new double[num_meas];
  for(i=0;i<num_meas;i++)
    hsort[i]=h[i];
  qsort(hsort, size_t(num_meas), sizeof(double), compare_double);
  double h_max=find_statistics(h, num_meas, MAX);
  double h_min=find_statistics(h, num_meas, MIN);
  
  max_rel_uncert=get_rel_uncertainty(h_max);
  min_rel_uncert=get_rel_uncertainty(h_min);
  norm_rel_uncert=0;
  int num_norm=0;
  for(double x=hsort[num_meas/4];x<hsort[3*num_meas/4];x+=0.02)
    {
      norm_rel_uncert+=get_rel_uncertainty(x);
      num_norm++;
    }
  norm_rel_uncert/=double(num_norm);
  
  modelparams+="\n";
  sprintf(buffer, 
	  WHAT((char *) 
	       "Rel. usikk. for maks-vannstand (%7.2f): %7.4f%%\n",
	       (char *) 
	       "Rel. uncert. for max. stage (%7.2f): %7.4f%%\n"), 
	  h_max,max_rel_uncert*100.0);
  modelparams+=buffer;
  
  sprintf(buffer, 
	  WHAT((char *) 
	       "Rel. usikk. for normalomr�de(%7.2f-%7.2f): %7.4f%%\n",
	       (char *) 
	       "Rel. uncert. for normal stage area (%7.2f-%7.2f): "
	       "%7.4f%%\n"), 
	  hsort[num_meas/4],hsort[3*num_meas/4],norm_rel_uncert*100.0);
  modelparams+=buffer;
  
  sprintf(buffer, 
	  WHAT((char *) 
	       "Rel. usikk. for min-vannstand (%7.2f): %7.4f%%\n",
	       (char *) 
	       "Rel. uncert. for min. stage (%7.2f): %7.4f%%\n"), 
	  h_min,min_rel_uncert*100.0);
  modelparams+=buffer;
  
  double SS_e=0.0,SS_Q=0.0, mean_Q=0.0;
  for(j=0;j<num_meas;j++)
    mean_Q+=q[j];
  mean_Q/=double(num_meas);

  if(modcurve)
    {
      for(j=0;j<num_meas;j++)
	{
	  SS_e+=(q[j]-modcurve->get_discharge(h[j]))*
	    (q[j]-modcurve->get_discharge(h[j]));
	  SS_Q+=(q[j]-mean_Q)*(q[j]-mean_Q);
	}
      double RR=1.0-SS_e/SS_Q;
      sprintf(buffer, "\nR�=%7.3f%%\n", RR*100.0);
      modelparams+=buffer;
    }
  else
    {
      SS_e=MISSING_VALUE;
      SS_Q=MISSING_VALUE;
    }

  // Check if the curve for estimated parameters adheres to the 
  // extrapolation restrictions:
  if(model>0 && modcurve && !prior->curve_adheres_to_extrapolation_restrictions(modcurve))
    {
      strcpy(buffer, WHAT((char *) "Kurve for estimerte parametre g�r utenfor"
			   " f�rkunnskap for vannf�ring for bestemte "
			   "vannstander!", 
			   (char *) "Curve for estimated parameters goes "
			   "outside of the prior knowledge of discharges "
			   "for given stage values!"));
      if(prior->get_max_seg()==modcurve->get_numseg_interpolated())
	strcpy(buffer+strlen(buffer), 
	       WHAT((char *) "\nAntall segmenter i interpolert del av kurven "
		    "er lik maksimalt antall segmenter. Dermed klarer finnes\n"
		    "det ikke frihet til � segmentere utenfor interpolert "
		    "omr�de.",
		    (char *) "\nThe number of segments in the interpolated "
		    "part of the curve is equal to the maximum number of\n"
		    "segments. Thus there is no freedom to segment outside "
		    "the interpolated area."));
      err.build(mainwin::toplevel, "Problem", buffer);
    }
  
  if(extrapolated && modcurve)
    {
      sprintf(buffer, 
	      WHAT((char *) "\nFull kurve for estimerte parametre "
		   "(ekstrapolert og interpolert):\n",
		   (char *) "\nFull curve for estimated parameters "
		   "(extrapolated and interpolated):\n"));
      modelparams+=buffer;
      
      for(i=0;i<modcurve->get_numseg();i++)
	{
	  if(i<(modcurve->get_numseg()-1))
	    sprintf(buffer, "Segment %d: C%d=%7.3f b%d=%7.3f h0%d=%7.3f "
		    "hs%d=%7.3f (%s)\n",
		    i+1,i+1,exp(modcurve->get_a(i+1)), 
		    i+1,modcurve->get_b(i+1),
		    i+1,modcurve->get_h0(i+1), 
		    i+1,modcurve->get_hs(i+1),
		    (modcurve->is_extrapoled(i+1) ? 
		     WHAT((char *) "extrapolert", (char *) "extrapolated") :
		     WHAT((char *) "interpolert", (char *) "interpolated")));
	  else
	    sprintf(buffer, "Segment %d: C%d=%7.3f b%d=%7.3f h0%d=%7.3f (%s)\n",
		    i+1,i+1,exp(modcurve->get_a(i+1)), 
		    i+1,modcurve->get_b(i+1),
		    i+1,modcurve->get_h0(i+1),
		    (modcurve->is_extrapoled(i+1) ? 
		     WHAT((char *) "extrapolert", (char *) "extrapolated") :
		     WHAT((char *) "interpolert", (char *) "interpolated")));
	  modelparams+=buffer;
	}
    }

  if(modcurve)
    delete modcurve;
}

void bayes_multiseg_showcurve::quality_toggled(void)
{
  int model=modelmenu.get_model(); 
  if(model>prior->get_max_seg() || model<0)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Modell m� velges f�r kvalitetet p� "
		     "tilpasningen kan vurderes!", 
		     (char *) "The model (num. of segments) must be chosen "
		     "before the fit can be judged!"));
      qualtog.ToggleButtonOff();
      return;
    }
  
  if(!qual_visited)
    {
      qualsh.build(mainwin::toplevel, 
		   WHAT((char *) "Kvalitetskontroll-vindu", 
			(char *) "Quality judgment window"));
      qualv1.build(qualsh);
      qualh1.build(qualv1);
      qualtext.build(qualh1, 70, 36);

      prev_qual_sh.build(mainwin::toplevel,
			 WHAT((char *) "Tidligere satt totalvurdering", 
			      (char *) "Formerly set total judgement"));
      prev_qual_v1.build(prev_qual_sh);
      prev_qual_textf.build(prev_qual_v1, 100,30);
      prev_qual_h1.build(prev_qual_v1);
      prev_qual_closeb.build(prev_qual_h1, &prev_qual_sh,
			     WHAT((char *) "Lukk vindu", 
				  (char *) "Close window"));
      prev_qual_closeb.Background("red");
      prev_qual_closeb.Foreground("white");
    }
  
  qualtext.SetText(modelparams.GetText());
  if(!qual_visited)
    {
      qualv2.build(qualh1);
      qualv3.build(qualh1);
      
      qual_trend.
	create(qualv2, WHAT((char *) "Trender i st�yen", 
			    (char *) "Trends in the noise"),
	       WHAT((char *) "Det er �nskelig at det ikke er noen merkbare "
		    "signaler i st�yleddene (avvikene/residualene).\n"
		    "Hvis s� er tilfelle, er modelltilpasningen eller "
		    "inferensen suspekt.\n\nAutomatiske grenser:\n"
		    "Sanns. for forandringer i st�yen selv (tid "
		    "og vst.)<50%% og for forandring i "
		    "st�yst�rrelse<50%%: Bra\n"
		    "Sanns. for forandringer i st�yen selv (tid og "
		    "vst.)<75%% og for forandring i "
		    "st�yst�rrelse<90%%: Middels\n"
		    "Sanns. for forandringer i st�yen selv (tid og "
		    "vst.)<90%%: D�rlig\n"
		    "Sanns. for forandringer i st�yen selv (tid og "
		    "vst.)>=90%%: Ubrukelig\n",
		    (char *) "There should be no noticable signals in the "
		    "noise terms (residuals).\n"
		    "If such signals are found, the "
		    "model fit or the inference "
		    "is suspect.\n\nAutomatic limits:\n"
		    "Prob for change in the noise itself (time "
		    "and stage)<50%%, and for change "
		    "in noise size<50%%: Good\n"
		    "Prob for change in the noise itself (time "
		    "and stage)<75%%, and for change "
		    "in noise size<90%%: Medium\n"
		    "Prob for change in the noise itself (time "
		    "and stage)<90%%: Bad\n"
		    "Prob for change in the noise itself (time "
		    "and stage)>=90%%: Unusable\n"),
	       True);
    }

  if(MAXIM(p_trend_time, p_trend_stage)<0.5 &&
     MAXIM(p_abstrend_time, p_abstrend_stage)<0.50 &&
     (p_trend_location==MISSING_VALUE || p_trend_location<0.5) &&
     (p_abstrend_location==MISSING_VALUE || p_abstrend_location<0.5) &&
     (p_trend_person==MISSING_VALUE || p_trend_person<0.5) &&
     (p_abstrend_person==MISSING_VALUE || p_abstrend_person<0.5) &&
     (p_trend_method==MISSING_VALUE || p_trend_method<0.5) &&
     (p_abstrend_method==MISSING_VALUE || p_abstrend_method<0.5))
    qual_trend.set_quality(4);
  else if(MAXIM(p_trend_time, p_trend_stage)<0.75 &&
	  MAXIM(p_abstrend_time, p_abstrend_stage)<0.90 &&
	  (p_trend_location==MISSING_VALUE || p_trend_location<0.75) &&
	  (p_abstrend_location==MISSING_VALUE || p_abstrend_location<0.9) &&
	  (p_trend_person==MISSING_VALUE || p_trend_person<0.75) &&
	  (p_abstrend_person==MISSING_VALUE || p_abstrend_person<0.9) &&
	  (p_trend_method==MISSING_VALUE || p_trend_method<0.75) &&
	  (p_abstrend_method==MISSING_VALUE || p_abstrend_method<0.9))
    qual_trend.set_quality(3);
  else if(MAXIM(p_trend_time, p_trend_stage)<0.90 &&
	  (p_trend_location==MISSING_VALUE || p_trend_location<0.90) &&
	  (p_trend_person==MISSING_VALUE || p_trend_person<0.90) &&
	  (p_trend_method==MISSING_VALUE || p_trend_method<0.90))
    qual_trend.set_quality(2);
  else
    qual_trend.set_quality(1);
  qual_trend.set_importance(5);
  
  if(!qual_visited)
    qual_uncert.
      create(qualv2, WHAT((char *) "Kurve-usikkerhet", 
			  (char *) "Curve uncertainty"),
	     WHAT((char *) "Man �nsker minst mulig usikkerhet i vannf�rings-"
		  "kurven, det vil si estimert vannf�ring "
		  "for hver vannstand.\n"
		  "I s� forbindelse kan det v�re �nskelig "
		  "med minst mulig usikkerhet i "
		  "eksponenten, b, for �vre segment for ekstrapolasjon over\n"
		  "m�legrunnlaget og i h0 for nedre segment for den motsatte "
		  "ekstrapolasjonen. Alle usikkerhetsm�l "
		  "er basert p� usikkerthet (U),\n"
		  "st�rrelsen p� 95%% troverdighetsintervall samt relativ\n"
		  "usikkerhet (RU), usikkerhet delt p� estimert verdi. Dette "
		  "blir gjort for fem omr�der:\n"
		  "1. �VG: �vre vannstandsgrense (vannstand "
		  "for h�yeste m�ling)\n"
		  "2. NO:  Normalomr�de (25%%-75%% persentil "
		  "til vannstandsm�lingene)\n"
		  "3. NVG: Nedre vannstandsgrense\n"
		  "4. B:   Eksponent, b, for �verste segment\n"
		  "5. H0:  h0 for nederste segment\n\n"
		  "Automatiske grenser:\n"
		  "RU(�VG),RU(NO),RU(NVG)<0.1, U(B)<0.5, U(H0)<0.1  : Bra\n"
		  "RU(�VG),RU(NO),RU(NVG)<0.4, "
		  "U(B)<1.0, U(H0)<0.25 : Middels\n"
		  "RU(�VG),RU(NO),RU(NVG)<1.0 : D�rlig\n"
		  "RU(�VG),RU(NO),RU(NVG)>1.0 : Ubrukelig\n",
		  (char *) "One wants a curve uncertainty that is as small as "
		  "possible, that is the uncertainty in "
		  "the estimated discharge\n"
		  "should be small for every conceivable "
		  "stage value. In order "
		  "for this to be the case, the "
		  "uncertainty in the exponent, b,\n"
		  "for the uppermost segment should "
		  "be as small as possible, in "
		  "order to reduce extrapolation uncertainty upwards. Also a\n"
		  "small uncertainty in the h0 of the "
		  "lowest segment will reduce "
		  "extrapolation uncertainty downwards. "
		  "All uncertainty measures\n"
		  "are based on the uncertainty (U), "
		  "the size of a 95%% credibility "
		  "interval and on relative uncertainty, "
		  "the uncertainty divided\n"
		  "by the estimated value. This is performed on 5 key areas:\n"
		  "1. USL: Upper stage limit (the highest stage measurement)\n"
		  "2. NA:  Normal area (25%%-75%% percentile "
		  "for the stage measurements\n"
		  "3. LSL: Lower stage limit\n"
		  "4. B:   Exponent, b, for the upper segment\n"
		  "5. H0:  h0 for the lowest segment\n\n"
		  "Automatic limits:\n" 
		  "RU(USL),RU(NA),RU(LSL)<0.1, U(B)<0.5, U(H0)<0.1  : Good\n" 
		  "RU(USL),RU(NA),RU(LSL)<0.4, U(B)<1.0, "
		  "U(H0)<0.25 : Medium\n" 
		  "RU(USL),RU(NA),RU(LSL)<1.0 : Bad\n" 
		  "RU(USL),RU(NA),RU(LSL)>1.0 : Unusable\n"), True);
  if(max_rel_uncert<0.1 && min_rel_uncert<0.1 && norm_rel_uncert<0.1 &&
     h0_uncert<0.1 && b_uncert<0.5)
    qual_uncert.set_quality(4);
  else if(max_rel_uncert<0.4 && min_rel_uncert<0.4 && norm_rel_uncert<0.4 &&
     h0_uncert<0.25 && b_uncert<1.0)
     qual_uncert.set_quality(3);
  else if(max_rel_uncert<1.0 && min_rel_uncert<1.0 && norm_rel_uncert<1.0)
    qual_uncert.set_quality(2);
  else
    qual_uncert.set_quality(1);
  qual_uncert.set_importance(5);
  
  if(!qual_visited)
    qual_outliers.
      create(qualv3, WHAT((char *) "Avvik/ikke-normalitet", 
			  (char *) "Outliers/non-normality"),
	     WHAT((char *) "Modellen antar normalfordelt m�lest�y med "
		  "et standardavvik p� mellom 2%% og 15%% av st�rrelsen\n"
		  "p� vannf�ringen. Dette blir testet via en sammenligning "
		  "mellom en modell der st�yleddene er normalfordelt med\n"
		  "standardavvik 0.02-0.15 og en modell som er en blanding "
		  "av dette (med 90%% vekt) og en "
		  "normalfordeling med 10-1000\n"
		  "ganger s� stort standardavvik. Residualplott eller "
		  "sannsynlighet for mikstur-modell kan benyttes til � angi\n"
		  "om det er noe galt med st�yleddene.\n\n"
		  "Automatiske grenser:\n"
		  "p(mix)<50%% : Bra\n"
		  "p(mix)<90%% : Middels\n"
		  "p(mix)<99%% : D�rlig\n"
		  "p(mix)>=99%%: Ubrukelig\n",
		  (char *) "The model assumption is normally distributed "
		  "measurement noise with a standard deviation of between \n"
		  "2%% and 15%% standard deviation compared to the discharge "
		  "itself. This is tested with a comparison between a model\n"
		  "with normally distributed residuals "
		  "with standard deviation "
		  "between 0.02 and 0.15, and a model "
		  "which is a mixture of \n"
		  "that (with 90 %% weight) and a "
		  "normal distribution with "
		  "10-1000 time larger standard deviation. "
		  "A residual plot or\n"
		  "the probability of a mixture "
		  "model can be used to determine "
		  "if outliers or non-normality is "
		  "present in the noise terms.\n\n"
		  "Automatic limits:\n"
		  "p(mix)<50%% : Good\n"
		  "p(mix)<90%% : Medium\n"
		  "p(mix)<99%% : Bad\n"
		  "p(mix)>=99%%: Unusable\n"), True);
  if(p_outlier<0.50)
    qual_outliers.set_quality(4);
  else if(p_outlier<0.9)
    qual_outliers.set_quality(3);
  else if(p_outlier<0.99)
    qual_outliers.set_quality(2);
  else
    qual_outliers.set_quality(1);
  qual_outliers.set_importance(3);

  if(!qual_visited)
    qual_fit.
      create(qualv3, WHAT((char *) "Tilpasningsgrad", 
			  (char *) "Assessment of fit"),
	     WHAT((char *) "Hvor god en kurve tilpasser seg data kan "
		  "angis ut ifra estimatet p� st�yens st�rrelse, sigma.\n"
		  "Denne parameteren angir standardavviket til st�yen. "
		  "F�r data er et default 95% troverdighetsintervall p�\n"
		  "0.02 til 0.15. Tilpasningsgraden kan ses i forhold til "
		  "dette.\n\n"
		  "Automatiske grenser:\n"
		  "sigma<5%  : Bra\n"
		  "sigma<10% : Middels\n"
		  "sigma<15% : D�rlig\n"
		  "sigma>=15%: Ubrukelig\n",
		  (char *) "How well a curve fits the data can be assessed "
		  "with the estimate of the noise size, "
		  "sigma. This parameter \n"
		  "is defined as the standard deviation of the noise. "
		  "Before the data, a default 95% credibility interval is\n"
		  "defined as ranging from 0.02 to 0.15. "
		  "The degree of the fit "
		  "can be seen in comparison to this.\n\n"
		  "Automatic limits:\n"
		  "sigma<5%  : Good\n"
		  "sigma<10% : Medium\n"
		  "sigma<15% : Bad\n"
		  "sigma>=15%: Unusable\n"), False);
  if(sigma_estimated<0.05)
    qual_fit.set_quality(4);
  else if(sigma_estimated<0.1)
    qual_fit.set_quality(3);
  else if(sigma_estimated<0.15)
    qual_fit.set_quality(2);
  else
    qual_fit.set_quality(1);
  qual_fit.set_importance(2);

  if(!qual_visited)
    {
      qualsep1.build(qualv1);
      qualh3.build(qualv1);
      qualcomment.build(qualh3, 90, 10);
      char *qualnames[]={WHAT((char *) "Ikke satt", (char *) "Not set"),
			 WHAT((char *) "1 (=ubrukelig)", (char *) "1 (=unusable)"),
			 WHAT((char *) "2 (=d�rlig)", (char *) "2 (=bad)"),
			 WHAT((char *) "3 (=middels)", (char *) "3 (=medium)"),
			 WHAT((char *) "4 (=bra)", (char *) "4 (=good)")};
      totalqual.Create(qualh3, WHAT((char *) "Total kvalitetsstempel:", 
				    (char *) "Total quality:"));
      totalqual.Insert(qualnames,5);
    }
  totalqual.SetFocus(0);
  qualcomment.SetText(WHAT((char *) "Kommentar ikke satt...", 
			   (char *) "Comment not set..."));
  
  if(!qual_visited)
    {
      qualsep2.build(qualv1);
      qualh2.build(qualv1);
      qualokb.Create(qualh2, WHAT((char *) "OK", (char *) "OK"),
		     BAYES_MULTISEG_QUAL_OK, this);
      qualokb.Background("green");
      qualokb.Foreground("black");
      qualcancelb.Create(qualh2, WHAT((char *) "Avbryt", (char *) "Cancel"),
			 BAYES_MULTISEG_QUAL_CANCEL, this);
      qualcancelb.Background("red");
      qualcancelb.Foreground("white");
      qual_lookat_measurementsb.Create(qualh2,  
				       WHAT((char *) "Liste over brukte m�linger", 
					    (char *) "List of used measurements"),
				       BAYES_MULTISEG_QUAL_LOOKAT_MEASUREMENTS, this);
    }
  
  qual_visited=true;
  qualsh.Map();
  
  prev_qual_textf.Clear();
  if(prevcomment)
    {
      prev_qual_textf+=prevcomment;
      prev_qual_sh.Map();
    }
}


void bayes_multiseg_showcurve::table_file_selected(const char *filename)
{
  strcpy(tablefile,filename);
  tablefilelab.labelString(filename);
  table_filesel_sh.Unmap();
}

void bayes_multiseg_showcurve::table_file_not_selected(void)
{
  strcpy(tablefile,"");
  tablefilelab.labelString(WHAT((char *) "Ingen fil valgt", 
				(char *) "No file chosen"));
  table_filesel_sh.Unmap();
}

void bayes_multiseg_showcurve::table2_infile_selected(const char *filename)
{
  strcpy(table2infile,filename);
  table2infilelab.labelString(filename);
  table2_infilesel_sh.Unmap();
}

void bayes_multiseg_showcurve::table2_infile_not_selected(void)
{
  strcpy(table2infile,"");
  table2infilelab.labelString(WHAT((char *) "Ingen fil valgt", 
				   (char *) "No file chosen"));
  table2_infilesel_sh.Unmap();
}

void bayes_multiseg_showcurve::table2_outfile_selected(const char *filename)
{
  strcpy(table2outfile,filename);
  table2outfilelab.labelString(filename);
  table2_outfilesel_sh.Unmap();
}

void bayes_multiseg_showcurve::table2_outfile_not_selected(void)
{
  strcpy(table2outfile,"");
  table2outfilelab.labelString(WHAT((char *) "Ingen fil valgt", 
				    (char *) "No file chosen"));
  table2_outfilesel_sh.Unmap();
}

void bayes_multiseg_showcurve::model_chosen(int model_number)
{
  int i,model=model_number;
  
  if(!is_pre_analysis)
    qualtog.ToggleButtonOff();

  if(param_names)
    doubledelete(param_names, num_params);
  
  int numseg=model;
  num_params=(model>0) ? 4*numseg+1 : 3;
  
  if(model>0)
    result->set_chosen_model(model);
  
  char **items=new char*[num_params];
  for(i=0;i<num_params;i++)
    items[i]=new char[100];
  
  if(model<0)
    {
      sprintf(items[0], "C (constant)");
      sprintf(items[1], "sigma");
      sprintf(items[2], "log(prob)");
    }
  else
    {     
      for(i=0;i<numseg;i++)
	sprintf(items[i], "C%d (constant)", i+1);
      for(i=0;i<numseg;i++)
	sprintf(items[numseg+i], "b%d (exponent)", i+1);
      for(i=0;i<numseg;i++)
	sprintf(items[2*numseg+i], "h0%d (zero stage)", i+1);
      for(i=0;i<(numseg-1);i++)
	sprintf(items[3*numseg+i], "hs%d (seg. stage)", i+1);
      sprintf(items[4*numseg-1], "sigma");
      sprintf(items[4*numseg], "log(prob)");
    }

  param_names=items;
  
  histmenu.Insert(items, num_params, 0);
  scattermenu1.Insert(items, num_params, 0);
  scattermenu2.Insert(items, num_params, 1);
  
  show_model_params();
}

void bayes_multiseg_showcurve::take_action(BAYES_MULTISEG_ACTION action,
					   int)
{
  switch(action)
    {
    case BAYES_MULTISEG_ACCEPT:
      do_accept();
      break;
    case BAYES_MULTISEG_SAVE_PREANALYSIS:
      do_save_pre_analysis();
      break;
    case BAYES_MULTISEG_CANCEL:
      if(is_pre_analysis)
	recommend_spacing();
      else
	{
	  cancel();
	  sh.Unmap();
	}
      break;
    case BAYES_MULTISEG_HIST:
      show_histogram();
      break;
    case BAYES_MULTISEG_ITER:
      show_sample_series();
      break;
    case BAYES_MULTISEG_SCATTER:
      show_scatter();
      break;
    case BAYES_MULTISEG_MODELPLOT:
      {
	int model=modelmenu.get_model(); // number of segments
	AddWorkCursor(sh);
	make_plot(model, 1);
	RmWorkCursor(sh);
	break;
      }
    case BAYES_MULTISEG_RESIDUAL_TREND:
      show_residual_trend();
      break;
    case BAYES_MULTISEG_RESIDUAL_HISTOGRAM:
      show_residual_histogram();
      break;
    case BAYES_MULTISEG_RESIDUAL_QQPLOT:
      show_residual_qqplot();
      break;
    case BAYES_MULTISEG_ESTIMATE_DISCHARGE:
      estimate_discharge();
      break;
    case BAYES_MULTISEG_ESTIMATE_STAGE:
      estimate_stage();
      break;
    case BAYES_MULTISEG_START_TABLE:
      start_table();
      break;
    case BAYES_MULTISEG_TABLE_FILE:
      start_table_filesel();
      break;
    case BAYES_MULTISEG_DO_TABLE:
      do_table();
      break;
    case BAYES_MULTISEG_START_TABLE2:
      start_table2();
      break;
    case BAYES_MULTISEG_TABLE2_INFILE:
      start_table2_infilesel();
      break;
    case BAYES_MULTISEG_TABLE2_OUTFILE:
      start_table2_outfilesel();
      break;
    case BAYES_MULTISEG_DO_TABLE2:
      do_table2();
      break;
    case BAYES_MULTISEG_QUAL_OK:
      quality_checked();
      break;
    case BAYES_MULTISEG_QUAL_CANCEL:
      quality_cancelled();
      break;
    case BAYES_MULTISEG_QUAL_LOOKAT_MEASUREMENTS:
      lookat_measurements();
      break;
    default:
      break;
    }
}

void bayes_multiseg_showcurve::lookat_measurements(void)
{
  if(!measurements)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", 
					(char *) "Error"),
		WHAT((char *) "Ingen m�linger � vise", 
		     (char *) "No measurements to show"));
      return;
    }

  lookat_meas_sh.build(mainwin::toplevel, 
		       WHAT((char *) "M�legrunnlag", 
			    (char *) "Measurement basis"));
  lookat_meas_v1.build(lookat_meas_sh);

  int numcol=0;
  char **colnames=NULL;
  int i;
  
  numcol=measurements->get_rows();
  colnames=new char *[numcol];
  for(i=0;i<numcol;i++)
    {
      colnames[i]=new char[100];
      if(measurements->get_column_name(i))
	strcpy(colnames[i], measurements->get_column_name(i));
      else
	strcpy(colnames[i], "");
      if(language == Norwegian)
	{
	  if(!strcasecmp(colnames[i],"stage"))
	    strcpy(colnames[i],"Vannstand");
	  if(!strcasecmp(colnames[i],"discharge"))
	    strcpy(colnames[i],"Vannf�ring");
	  if(!strcasecmp(colnames[i],"time"))
	    strcpy(colnames[i],"       Tid      ");
	  if(!strcasecmp(colnames[i],"quality"))
	    strcpy(colnames[i],"Kvalit.");
	  if(!strcasecmp(colnames[i],"method"))
	    strcpy(colnames[i],"Metode ");
	  if(!strcasecmp(colnames[i],"ice"))
	    strcpy(colnames[i],"   Is  ");
	  if(!strcasecmp(colnames[i],"location"))
	    strcpy(colnames[i]," Sted  ");
	  if(!strcasecmp(colnames[i],"distance"))
	    strcpy(colnames[i],"Distanse");
	  if(!strcasecmp(colnames[i],"responsible"))
	    strcpy(colnames[i],"Ansvarlig   ");
	  if(!strcasecmp(colnames[i],"derivative"))
	    strcpy(colnames[i]," Derivert ");
	}
    }
  
  lookat_meas.Create(lookat_meas_v1, measurements,NULL,NULL,colnames);
  lookat_meas_h1.build(lookat_meas_v1);
  lookat_meas_closeb.build(lookat_meas_h1, &lookat_meas_sh, 
			   WHAT((char *) "Lukk vindu", (char *) "Close window"));
  lookat_meas_closeb.Background("red");
  lookat_meas_closeb.Foreground("white");
  lookat_meas_sh.Map();

  doubledelete(colnames, numcol);
}

void bayes_multiseg_showcurve::quality_checked(void)
{
  if(totalqual.GetNumber()==0)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Total-kvalitet ikke satt", 
		     (char *) "Total quality not set"));
      return;
    }
  qualsh.Unmap();
}

void bayes_multiseg_showcurve::quality_cancelled(void)
{
  qualsh.Unmap();
  qualtog.ToggleButtonOff();
}

bayes_multiseg_showcurve::bayes_multiseg_showcurve() : plot_module()
{
  init();
}

bayes_multiseg_showcurve::~bayes_multiseg_showcurve()
{
  cleanup();
}

// perform a new analysis:
void bayes_multiseg_showcurve::create(tablelist *measurements_, 
				      segmented_priors *prior_,
				      char const* const *alt_attrib_names,
				      int num_attrib_,
				      bool pre_analysis,
				      int num_samples,
				      // default for pre_analysis=1000
				      int spacing,
				      int burnin,
				      int num_temp,
				      bool x_stage,
				      /* stage on x-axis ? */
				      const char *measurement_text,
				      bool show_median_curve_,
				      segmented_curve *comparison_curve,
				      const char *comparison_text,
				      double *measurement_weights,
				      
				      const char *prev_comment,
				      bool show_extrapolation_uncert,
				      bool show_interpolated_uncert)
{
  int i,j,k,l;

  cleanup();
  is_pre_analysis=pre_analysis;
  show_median_curve=show_median_curve_;
  workload=burnin*num_temp+num_samples*spacing*num_temp+20*num_samples;
  show_extrapol_uncert=show_extrapolation_uncert;
  show_interpol_uncert=show_interpolated_uncert;

  if(measurement_text && *measurement_text)
    strcpy(meas_text, measurement_text);
  else
    strcpy(meas_text, WHAT((char *) "M�linger", (char *) "Measurements"));

  if(comparison_text && *comparison_text)
    strcpy(comp_text, comparison_text);
  else
    strcpy(comp_text, WHAT((char *) "Sammenligningskurve", 
			   (char *) "Comparison curve"));
  
  if(prevcomment)
    delete [] prevcomment;
  prevcomment=NULL;
  if(prev_comment)
    {
      prevcomment=new char[strlen(prev_comment)+5];
      strcpy(prevcomment, prev_comment);
    }
  
  xstage=x_stage;
  if(comparisoncurve)
    delete comparisoncurve;
  comparisoncurve=NULL;
  if(comparison_curve)
    comparisoncurve=new segmented_curve(comparison_curve);
  measurements=measurements_;
  prior=prior_;
  
  num_attrib = measurements->get_columns();
  num_meas   = measurements->get_rows();
  ret_num_meas=num_meas;
  
  if(prior->get_max_seg()>num_meas)
    {
      char errmsg[1000];
      sprintf(errmsg,
	      WHAT((char *) "Ulovlig � ha maksimalt antall segmenter (%d) "
		   "st�rre enn antall m�linger (%d)!", 
		   (char *) "Illegal to have maximum number of segments "
		   "(%d) larger than the number of measurements (%d)!"),
	      prior->get_max_seg(),num_meas);
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		errmsg);
      return;
    }

  double *q_buff=new double[num_meas];
  double *h_buff=new double[num_meas];
  double *w_buff=new double[num_meas];
  DateTime *dt_buff=new DateTime[num_meas];

  if(measurement_weights)
    for(i=0;i<num_meas;i++)
      w_buff[i]=measurement_weights[i];

  int active=measurements->get_column_number("active");
  if(num_attrib_>0)
    num_attrib=num_attrib_;
  if(active>=0 && alt_attrib_names)
    {
      for(i=0;i<num_attrib;i++)
	if(alt_attrib_names[i] &&
	   (!strcasecmp(alt_attrib_names[i], "active") ||
	    !strcasecmp(alt_attrib_names[i], "aktiv")))
	  num_attrib--;
    }

  char **attrib_names=new char*[num_attrib];
  
  j=0;
  for(i=0;i<measurements->get_columns();i++)
    if(i!=active && j<num_attrib)
      {
	attrib_names[j]=new char[100];
	strcpy(attrib_names[j], measurements->get_column_name(i));

	if(!strcasecmp(attrib_names[j], "stage"))
	  {
	    for(k=0;k<num_meas;k++)
	      h_buff[k]=measurements->get_cell_double(i, k);
	  }
	else if(!strcasecmp(attrib_names[j], "discharge"))
	  {
	    for(k=0;k<num_meas;k++)
	      q_buff[k]=measurements->get_cell_double(i, k);
	  }
	else if(!strcasecmp(attrib_names[j], "time"))
	  {
	    for(k=0;k<num_meas;k++)
	      dt_buff[k]=measurements->get_cell_datetime(i, k);
	  }
	
	if(alt_attrib_names)
	  strcpy(attrib_names[j], alt_attrib_names[j]);
	
	j++;
      }

  // remove zero discharge measurements:
  j=0;
  for(i=0;i<num_meas;i++)
    if(q_buff[i]>=MIN_Q)
      j++;

  q=new double[j];
  h=new double[j];
  dt=new DateTime[j];
  
  if(measurement_weights)
    weights=new double[j];
  else
    weights=NULL;
  
  k=0;
  for(i=0;i<num_meas;i++)
    if(q_buff[i]>=MIN_Q)
      {
	q[k]=q_buff[i];
	h[k]=h_buff[i];
	dt[k]=dt_buff[i];
	
	if(measurement_weights)
	  weights[k]=w_buff[i];
	
	//printf("%d %s %f %f\n", k,dt[k].syCh(1),h[k], q[k]);
	
	k++;
      }
  num_meas=k;
  delete [] q_buff;
  delete [] h_buff;
  delete [] dt_buff;
  delete [] w_buff;
    
  function_timer::start_total_timer(2);
  function_timer::start_timer(0);
  // Perform the analysis:
  result=new segmented_curve_analysis();
  result->do_analysis(num_meas, h, q, num_samples, 20*num_samples, prior,
		      burnin, spacing, num_temp, 
		      prior->get_max_seg(), 
		      prior->get_min_seg(),
		      weights);
  function_timer::stop_timer(0);
  analysis_time=function_timer::get_timer(0);
  

  function_timer::start_timer(1);
  
  // Make the main widgets;
  sh.build(mainwin::toplevel, WHAT((char *) "Kurve-resultat",
				   (char *) "Curve result"));
  v1.build(sh);
  put_in_widget(v1, 900, 450, PLOT_IN_WIDGET_SHOWMAINMENU,false);
  set_grid(True);

  int nummod=prior->get_max_seg(); 
    //mostprob=result->get_most_probable_model()-1;
  double *probs=new double[nummod];
  for(i=0;i<nummod;i++)
    probs[i]=result->get_probability_of_model(i+1);
  
  h8.build(v1);
  v3.build(h8);
  h9.build(v3);
  modelmenu.create(h9, nummod, probs, result->get_most_probable_model(), this);
  modelplotb.Create(h9, WHAT((char *) "Plott kurve for modell", 
			     (char *) "Plot curve for model"),
		    BAYES_MULTISEG_MODELPLOT, this); 

  h1.build(v3);
  fr1.build(h1);
  fv1.build(fr1);

  residlab.Create(fv1, "", WHAT((char *) "Residual-analyse", 
				(char *) "Residual analysis"), "",
		  WHAT((char *) "Residualer er forskjellene mellom m�le- og "
		       "kurve-vannf�ring p� logaritmisk skala.\n"
		       "Dette er ca. lik relativt vannf�rings-avvik mellom "
		       "m�ling og kurve for sm� avvik.\n"
		       "\n"
		       "De statistiske modellene som brukes, antar at"
		       "avvikene (m�lest�yen) er helt tilfeldige, med andre\n"
		       "ord at de ikke avhenger av andre ting, som tid, "
		       "vannstand, m�lemetode, ansvarling m�leperson etc. \n"
		       "Hvis denne forutsetningen er brutt, er ikke "
		       "tilpasningen gjort under de forutsetninger som\n"
		       "b�r v�re til stede. Tidstrend tyder p� at multiple "
		       "perioder burde v�rt brukt. Trend i vannstand tyder p�\n"
		       "at segmenteringen har g�tt galt. Trend i m�lested, "
		       "m�leperson, m�lemetode betyr at usikkerheten i\n"
		       "kurven blir undervurdert. Trend i derivert betyr "
		       "hysterese-effekt, trend i kvalitet betyr at \n"
		       "kvalitetsvektene antageligvis er satt feil og "
		       "trend i distanse kan bety at det er tilsig\n"
		       "underveis.\n"
		       "\n"
		       "Modellene antar ogs� at m�lest�yen (i forhold til "
		       "kvalitetsvektene) er lik i alle tilfeller.\n"
		       "Ser man p� trender i absoluttverdien av residualene,"
		       "kan man sjekke om dette er tilfelle. En trend i\n"
		       "absolutt-residualene mot vannstand er ganske vanlig "
		       "� finne (heteroskedastisitet), typisk at de\n"
		       "relative avvikene er st�rre for sm� enn for store "
		       "vannstander. Dette er ofte ikke ansett som en \n"
		       "alvorlig feil, men betyr at kurvens usikkerhet nok "
		       "blir under-estimert for sm� vannstander.\n"
		       "Heteroskedastisitet i m�lested, m�leperson, "
		       "m�lemetode er et mindre problem. Har man en\n"
		       "forklaring p� hvorfor residualene varierer i "
		       "st�rrelse for f.eks. ulike m�lemetoder, g�r det an\n"
		       "� revurdere kvaliteten p� de ulike m�lemetodene.\n"
		       "\n"
		       "I tillegg til at avvikene skal v�re helt tilfeldige, "
		       "skal de ogs� v�re normalfordelt. Dette kan sjekkes \n"
		       "visuelt med histogram og QQ-plott. QQ-plott best�r "
		       "av at de storterte residualene plottes opp mot \n"
		       "kvantilene til normalfordelingen. Er residualene "
		       "normaltfordelt, skal de plassere seg noenlunde p� \n"
		       "en rett linje. Ikke-normalitet kan bety at kurve-"
		       "usikkerheten blir feil-estimert, men det kan ogs�\n"
		       "bety at selve kurven blir det.",
		       (char *) "Residuals are the log scale difference "
		       "between discharge from measurements and curve,\n"
		       "represetning measurement noise. They are about the "
		       "same as relative difference between measurement\n"
		       "and curve when this is small.\n"
		       "\n"
		       "The statistical model used assumes that the the "
		       "measurement noise is completely random, i.e. that \n"
		       "it does not depend on any other factors, such as "
		       "time, stage value, measurement method, person etc.\n"
		       "If this assumption is broken, the curve estimate "
		       "has not been performed under valid circumstances.\n"
		       "A trend in time, suggest that multiple curve periods "
		       "should be used. A trend in stage means that something\n"
		       "has gone wrong with the segmentation. A trend in "
		       "measurement method, place or person means that the \n"
		       "curve uncertainty will most likely be underestimated. "
		       "A trend in the derivative means hysteresis. A trend\n"
		       "in quality means that the quality weights are most "
		       "likely wrong. A trend in distance can mean that there\n"
		       "is water coming from the sides.\n"
		       "\n"
		       "The models also assume that the size measurement noise "
		       "is the same under all circumstances. If one looks at\n"
		       "trends in the absolute value of the residuals, one can "
		       "check this assumption. A trend in the absolute value\n"
		       "of the residuals against stage is quite common to find "
		       "(heteroscedasticity), typically the relative\n"
		       "differences are greater for small stage values than "
		       "for large ones. This is a moderate problem, but it\n"
		       "mean that the curve uncertainty for small stage values "
		       "is most likely underestimated. Heteroscedasticity in\n"
		       "measurement method, place or person is perhaps a minor "
		       "problem. If one finds an explanation for the\n"
		       "patterns, one can perhaps adjust the measurement "
		       "quality for the different methods, places or persons.\n"
		       "\n"
		       "In addition to the residuals being random, they should "
		       "also be normally distributed according to the model\n"
		       "assumptions. This can be checked visually with a "
		       "histogram or a QQ-plot. A QQ-plot shows the residuals\n"
		       "in sorted order against the quantiles of the normal "
		       "distribution. If the residuals are normally\n"
		       "distributed, the points should approximately form a "
		       "straight line. Non-normality typically means the\n"
		       "curve uncertainty is mis-estimated, but can also mean "
		       "the same for the curve itself."));
	       
  h4.build(fv1);
  lab1.build(h4, WHAT((char *) "Vis residualer ", 
		      (char *) "Show residuals "));
  resmenu.Create(h4, WHAT((char *) "mot", (char *) "against"));
  resmenu.Insert(attrib_names, num_attrib);
  resb.Create(h4, WHAT((char *) "Vis residualer", (char *) "Show residuals"), 
	      BAYES_MULTISEG_RESIDUAL_TREND, this);
  resabstog.build(fv1, WHAT((char *) "Absolutt-verdier (for sjekking av "
			    "om det er trender i st�y-st�rrelsen)", 
			    (char *) "Absolute values (for checking "
			    "if there's trends in the noise size)"));
  
  h5.build(fv1);
  histresb.Create(h5, WHAT((char *) "Histogram", (char *) "Histogram"),  
		  BAYES_MULTISEG_RESIDUAL_HISTOGRAM, this);
  qqplotb.Create(h5, WHAT((char *) "QQ-plott", (char *) "QQ plot"),  
		     BAYES_MULTISEG_RESIDUAL_QQPLOT, this);


  fr5.build(v3);
  fv5.build(fr5);

  mcmclab.Create(fv5, WHAT((char *) "Visning av ",
		      (char *) "Options for showing "),
		 WHAT((char *) "parameter-trekninger (MCMC)",
		      (char *) "parameter samples (MCMC)"),
		 "",
		 WHAT((char *) "Modellene som brukes kan ikke l�ses "
		      "analytisk (ikke-line�r regresjon). I Bayesiansk\n"
		      "statistikk s�ker man fordelingen for modell-parametre "
		      "gitt data og f�rkunnskap. Denne fordelingen kan man\n"
		      "ikke finne analytisk (ikke-line�r regresjon), men "
		      "man kan trekke (sample) fra fordelingen med en\n"
		      "metode kalt Markov chain Monte Carlo (MCMC). "
		      "Trekningene fra analysen kan vises som histogram\n"
		      "for hver parameter.\n"
		      "\n"
		      "Siden man kun har tid til � trekke s� mange ganger og "
		      "siden trekningene er tilfeldige, vil det v�re et\n"
		      "anslag av numerisk usikkerhet i settet med trekninger "
		      "man f�r, og som benyttes til � estimere parametre og\n"
		      "dermed kurve og usikkerheten til begge. Det er "
		      "selvf�lgelig hensikten � minske denne usikkerheten\n"
		      "s� mye som mulig. Dette oppn�s ved � f� tak i mest "
		      "mulig *uavhengige* trekninger. MCMC er en m�te �\n"
		      "trekke p� der forrige trekning p�virker neste. Man "
		      "kan jobbe med m�ten man trekker p� for �\n"
		      "minske denne effekten, men noe avhengighet vil det "
		      "alltid v�re. Derfor benyttes trekninger som ikke\n"
		      "beholdes mellom hver trekning som beholdes, da "
		      "dette vil redusere avhengigheten mellom de trekninger\n"
		      "som beholdes. (Settes med \"avstand mellom uavhengige "
		      "trekninger i opsjonene hovedvinduet i tilleg til at\n"
		      "f�ranalysen til dels fors�ker � styre dette. "
		      "ved � se p� trekningene i den rekkef�lge de ble\n"
		      "trekt, kan man visuelt sjekke hvor mye avhengighet "
		      "(auto-korrelasjon) det er i trekningene for hver "
		      "parameter.\n"
		      "\n"
		      "Et annet problem med MCMC er at metoden ikke "
		      "umiddelbart vil lande p� fordelingen for parametre\n"
		      "gitt data og f�rkunnskap, men trenger tid for � "
		      "konvergere mot denne fordelingen. Derfor blir en\n"
		      "s�kalt burn-in-periode benyttet, der treknings-"
		      "algoritmen kj�rer men der ingen av trekningene\n"
		      "beholdes. Hvis burn-in perioden er satt for liten "
		      "(dette kan ogs� styres fra opsjonene i hovedvinduet)\n"
		      "kan man se p� treknings-serien at den jobber seg mot "
		      "noe i stedet for � allerede ha landet p� en stabil\n"
		      "fordeling.\n"
		      "\n"
		      "En ting som kan utsette konvergensen ganske mye er "
		      "multi-modalitet, det at parameter-fordelingen gitt\n"
		      "data og f�rkunnskap har multiple topper. Dette kan "
		      "sees i histogrammet, hvis treknings-algoritmen har\n"
		      "klart � trekke fra alle toppene. men i ytterste "
		      "konsekvens vil en MCMC-trekning bare holde seg p� en\n"
		      "av toppene. Ellers kan det hende at treknings-"
		      "algoritmen klarer � hoppe mellom toppene, men bare\n"
		      "en sjelden gang. Dette kan ogs� sees i treknings-"
		      "serien. Parallel tempering (opsjoner for dette kan\n"
		      "settes i hovedvinduet) kan gj�re hoppene mellom topper "
		      "mer effektiv, men er ganske ressurs-krevende.\n"
		      "\n"
		      "Til sist kan ogs� trekningene for to parametre sees "
		      "i sammenheng, med 'vis spredningsplott'. Det vil\n"
		      "ofte v�re avhengighet mellom parametre, dette er ikke "
		      "en feilsituasjon. Men sterk avhengighet mellom\n"
		      "parametrene kan gi sterk avhengighet mellom "
		      "trekningene ogs�. I tillegg kan litt s�re\n"
		      "avhengigheter avsl�re multi-modalitet som ikke kan "
		      "sees fra histogram samt gi en pekepinn p� hvorfor\n"
		      "det eventuelt er stor foskjell p� estimert kurve og "
		      "kurve for estimerte parametre.",
		      (char *) "In Bayesian statistics, one seeks the "
		      "distribution of the model parameters given data and\n"
		      "the prior knowledge (the posterior distribution). "
		      "This cannot be solved analytically (non-linear\n"
		      "regression), but one can sample from the distribution "
		      "using a method called Markov chain Monte Carlo\n"
		      "(MCMC). The samples from the analysis can be shown "
		      "as histograms for each parameter.\n"
		      "\n"
		      "Since one can only do so many samplings and the "
		      "samples are random, this will give an estimate of\n"
		      "the posterior distribution but there will be an "
		      "element of uncertainty. One of course wants to\n"
		      "minimize this numerical uncertainty as much as "
		      "possible. This can be achieved by getting as many\n"
		      "*independent* samples as possible. MCMC is a way of "
		      "sampling where the next sample depends on the\n"
		      "previous one. One can chose ways of sampling using "
		      "MCMC that reduces this dependency, but it cannot be\n"
		      "altogether eliminated. Therefore, the algorithm "
		      "fetches samples that are not kept in between each\n"
		      "sample that is kept, which is set by 'spacing' in the "
		      "options of the main window, plus that the pre-\n"
		      "analysis seeks to find an optimal spacing "
		      "automatically. by looking at the samples in the\n"
		      "order they were sampled, one can check visually "
		      "how much depdnency (auto-correlation) there is for\n"
		      "each parameter.\n"
		      "\n"
		      "Another problem with MCMC is that the method does "
		      "not immediately land on the posterior distribution\n"
		      "but needs time to converge. therefore, a so-called "
		      "burn-in period is used, where in the start many \n"
		      "samples are fetched without keeping any one of them. "
		      "if the burn-in period is too small (this can be\n"
		      "set in the options in the main window), one can see "
		      "in the sample series that the samples are working\n"
		      "their way towards something instead of having landed "
		      "on a stable distribution.\n"
		      "\n"
		      "Another thing that can postpone convergence is "
		      "multi-modality, where the posterior parameter\n"
		      "distribution has multiple peaks. This can be seen "
		      "in the histogram, if the MCMC algorithm has\n"
		      "converged. However, the worst case scenario is that "
		      "the MCMC sampling algorithm gets stuck in one peak.\n"
		      "More frequently, the multiple peaks are found, but "
		      "the algorithm jumps very seldomly between them,\n"
		      "thus making for much dependency (auto-correlation) "
		      "in the samples. This can be seen in the sample\n"
		      "series. Parallel tempering (set in the options of "
		      "the main window) can alleviate this problem, but is\n"
		      "resource costly.\n"
		      "\n"
		      "Lastly, it is also possible to look at the samples of "
		      "two parameters at the same time, using scatter plot.\n"
		      "There will often be dependency between the parameters "
		      "and this is not an error situation. However, strong\n"
		      "dependecy between parameters will typically cause "
		      "strong auto-correlation in the samples also. In \n"
		      "addition, strange dependencies can reveal multi-"
		      "modality that was not revealed by histograms, plus\n"
		      "give a hint for why the estimated curve is different "
		      "from the curve for estimated parameters, if that is\n"
		      "the case."
		      ));


  h2.build(fv5);
  histmenu.Create(h2, WHAT((char *) "Parameter:", 
			   (char *) "Parameter:"));
  histb.Create(h2, WHAT((char *) "Vis histogram", 
			(char *) "Show histogram"), 
	       BAYES_MULTISEG_HIST, this);  
  iterb.Create(h2, WHAT((char *) "Vis treknings-serie", 
			(char *) "Show sample series"), 
	       BAYES_MULTISEG_ITER, this);

  h3.build(fv5);
  scattermenu1.Create(h3, WHAT((char *) "Vis ", (char *) "Show"));
  scattermenu2.Create(h3, WHAT((char *) " mot ", (char *) "against"));
  scatterb.Create(h3, WHAT((char *) "Vis spredningsplott", 
			   (char *) "Show scatterplot"), 
		  BAYES_MULTISEG_SCATTER, this);
  
  v2.build(h8);
  fr2.build(v2);
  fv2.build(fr2);
  lab2.build(fv2, WHAT((char *) "Modell-parametre:", 
		       (char *) "Model parameters:"));
  modelparams.build(fv2, 50, 10, False);
  
  //h5.build(v2);
  fr3.build(h8);
  fv3.build(fr3);
  stagef.build(fv3, 5, WHAT((char *) "Vannstand:", (char *) "Stage:"));
  estqb.Create(fv3, WHAT((char *) "Estimer vannf�ring", 
			 (char *) "Estimate discharge"), 
	       BAYES_MULTISEG_ESTIMATE_DISCHARGE, this);
  //h6.build(v2);
  //fr4.build(h1);
  //fv4.build(fr4);
  sep1.build(fv3);
  dischargef.build(fv3,5, WHAT((char *) "Vannf�ring:", (char *) "Discharge:"));
  esthb.Create(fv3, WHAT((char *) "Estimer vannstand", 
			(char *) "Estimate stage"), 
	       BAYES_MULTISEG_ESTIMATE_STAGE, this);
  
  tablestartb.Create(fv3,WHAT((char *) "Vannf�ringstabell", 
			      (char *) "Stage/discharge table"),
		     BAYES_MULTISEG_START_TABLE,this);
  tablesh.build(sh,WHAT((char *) "Utskrift av vannf�ringstabell til fil", 
			(char *) "Output of stage-discharge table to file"));
  tablev1.build(tablesh);
  tableh1.build(tablev1);
  tablestartf.build(tableh1,5,WHAT((char *) "Vannstand start:",
				   (char *) "Stage start:"));
  tableendf.build(tableh1,5,WHAT((char *) "Vannstand slutt:",
				 (char *) "Stage end:"));
  tablestepf.build(tableh1,5,WHAT((char *) "Vannstandsoppl�sning:",
				  (char *) "Stage steps:"));
  tablestepf.SetDouble(0.01,3);
  tablefilexplain.build(tablev1,
			WHAT((char *) "Utskrift av tabell vil bli sendt "
			     "til en fil, spesifisert her:", 
			     (char *) "The table will be sent to a "
			     "file, specified here:"));
  tableh2.build(tablev1);
  tablefileb.Create(tableh2,WHAT((char *) "Velg lagringsfil", 
				 (char *) "Choose save file"),
		    BAYES_MULTISEG_TABLE_FILE, this);
  tablefileb.Background("green");
  tablefileb.Foreground("black");
  tablefilelab.build(tableh2,WHAT((char *) "Ingen fil valgt", 
				  (char *) "No file chosen"));
  tablefilelab.Background("white");
  table_filesel_sh.build(sh,WHAT((char *) "Valg av utskrifts-fil", 
				 (char *) "Choose output file"));
  table_filesel.Create(table_filesel_sh,this);
  tablesep.build(tablev1);
  tableh3.build(tablev1);
  tableokb.Create(tableh3, "OK", BAYES_MULTISEG_DO_TABLE, this);
  tableokb.Background("green");
  tableokb.Foreground("black");
  tablecloseb.build(tableh3, &tablesh);
  tablecloseb.Background("red");
  tablecloseb.Foreground("white");
  
  table2startb.Create(fv3,WHAT((char *) "Vannstandsserie->vannf�ringsserie", 
			      (char *) "Stage time series -> "
			       "discharge time series"),
		      BAYES_MULTISEG_START_TABLE2,this);
  table2sh.build(sh,WHAT((char *) "Fra vannstandsserie til vannf�ringsserie", 
			(char *) "From stage time series to "
			 "discharge time series"));
  table2v1.build(table2sh);
  table2filexplain.build(table2v1,
			 WHAT((char *) "Vannstandsserie hentes fra fil og "
			      "vannf�ringsserie skrives til fil, "
			      "spesifisert her:", 
			      (char *) "The input stage time series file and "
			      "the output discharge time series file is "
			      "specified here:"));
  table2h1.build(table2v1);
  table2infileb.Create(table2h1,WHAT((char *) "Velg input-fil for vannstand", 
				     (char *) "Choose input file for stage"),
			BAYES_MULTISEG_TABLE2_INFILE, this);
  table2infileb.Background("green");
  table2infileb.Foreground("black");
  table2infilelab.build(table2h1,WHAT((char *) "Ingen fil valgt", 
				      (char *) "No file chosen"));
  table2infilelab.Background("white");
  table2_infilesel_sh.build(sh,WHAT((char *) "Valg av utskrifts-fil", 
				     (char *) "Choose output file"));
  table2_infilesel.Create(table2_infilesel_sh,this);
  table2h2.build(table2v1);
  table2outfileb.Create(table2h2,WHAT((char *) "Velg lagringsfil for "
				      "vannf�ring", 
				     (char *) "Choose save file for discharge"),
			BAYES_MULTISEG_TABLE2_OUTFILE, this);
  table2outfileb.Background("green");
  table2outfileb.Foreground("black");
  table2outfilelab.build(table2h2,WHAT((char *) "Ingen fil valgt", 
				      (char *) "No file chosen"));
  table2outfilelab.Background("white");
  table2_outfilesel_sh.build(sh,WHAT((char *) "Valg av utskrifts-fil", 
				     (char *) "Choose output file"));
  table2_outfilesel.Create(table2_outfilesel_sh,this);
  table2sep.build(table2v1);
  table2h3.build(table2v1);
  table2okb.Create(table2h3, "OK", BAYES_MULTISEG_DO_TABLE2, this);
  table2okb.Background("green");
  table2okb.Foreground("black");
  table2closeb.build(table2h3, &table2sh);
  table2closeb.Background("red");
  table2closeb.Foreground("white");
  

  h7.build(v1);

  if(!pre_analysis)
    {
      closeb.Create(h7, WHAT((char *) "Avbryt", (char *) "Cancel"),
		    BAYES_MULTISEG_CANCEL, this);
      closeb.Background("red");
      closeb.Foreground("white");
      qualtog.Create(h7, this);
      acceptb.Create(h7, WHAT((char *) "Godta", (char *) "Accept"),
		     BAYES_MULTISEG_ACCEPT, this);
      acceptb.Background("green");
      acceptb.Foreground("black");
    }
  else
    {
      closeb.Create(h7, WHAT((char *) "Lukk vindu", (char *) "Close window"),
		    BAYES_MULTISEG_CANCEL, this);
      closeb.Background("red");
      closeb.Foreground("white");
      
      if(allow_save_pre_analysis)
	{
	  spaclab.build(h7, "            ");
	  preanalysis_saveb.Create(h7, 
				   WHAT((char *)"Lagre f�rkunnskap og "
					"pre-analyse", 
					(char *) "Save prior and pre-analysis"),
				   BAYES_MULTISEG_SAVE_PREANALYSIS, this);
	}
    }

  sh.Map();
  make_plot(-1);
  model_chosen(modelmenu.get_model());
  
  if(!is_pre_analysis)
    {
      int model=modelmenu.get_model();
      char most_problematic_parameter[1000];
      double max_spacing=0.0;
      for(l=0;l<(4*model+1);l++) // traverse the parameters (plus log-prob)
	// fetch the maximal spacing overall and for parameter 0
	{
	  int len;
	  double *val=get_samples(&len, model, l);
	  if(!val)
	    {
	      err.build(mainwin::toplevel, 
			WHAT((char *) "Programfeil", (char *) "Program error"),
			WHAT((char *) "Noe gikk galt med sample-effektivitets-"
			     "settingen!", 
			     (char *) "Something went wrong in the setting of "
			     "the sample efficiency!"));
	      return;
	    }
	  
	  double rho=get_auto_correlation(val, len);
	  double spacing=2.0*(0.5+rho/(1.0-rho));
	  
	  if(spacing>max_spacing)
	    {
	      max_spacing=spacing;
	      strcpy(most_problematic_parameter, param_names[l]);
	    }
	  
	  delete [] val;
	}
      if(max_spacing>10)
	{
	  char messtr[1000];
	  sprintf(messtr, 
		  WHAT((char *) "Avstand mellom uavhengige trekninger er "
		       "%5.0f etter at kun hver %5d trekning blir brukt, "
		       "for parameter %s.\n"
		       "Det anbefales � sette avstand mellom uavhengige "
		       "trekninger st�rre eller lik %5d i opsjonsmenyen "
		       "og kj�re\n"
		       "igjen. (�kning av burning og tempering kan ogs� "
		       "hjelpe. Se \"Vis sample-serie\" for � eventuelt "
		       "isolere problemet.)",
		       (char *) "The distance between independent samples "
		       "is %5.0f after only keeping each %5.0d sample for "
		       "parameter %s.\n"
		       "It is recommended that you set the number of "
		       "independent samples to at least %5d and rerun the "
		       "analysis again.\n"
		       "(Increasing the burnin and number of tempering chains"
		       " might also help. See \"show sample series\" to "
		       "isolate the problem better.)"),
		  max_spacing,result->get_spacing(),
		  most_problematic_parameter, 
		  (int) ceil(max_spacing*double(result->get_spacing())));
	  
	  mess.build(mainwin::toplevel, WHAT((char *) "Melding", 
					     (char *) "Message"),
		     messtr);
	}
    }

  function_timer::stop_timer(1);
  showcurve_time=function_timer::get_timer(1);
  function_timer::stop_total_timer();
}

// recreate an already performed analysis:
void bayes_multiseg_showcurve::create(tablelist *measurements_, 
				      segmented_priors *prior_,
				      segmented_curve_analysis *result_,
				      char const* const* alt_attrib_names,
				      int num_attrib_,
				      bool x_stage,
				      /* stage on x-axis ? */
				      const char *measurement_text,
				      bool show_median_curve_,
				      segmented_curve *comparison_curve,
				      const char *comparison_text,
				      double *measurement_weights,
				      
				      const char *prev_comment,
				      bool show_extrapolation_uncert,
				      bool show_interpolated_uncert,
				      bool pre_analysis)
{
  int i,j,k;
  
  cleanup();
  is_pre_analysis=pre_analysis;
  
  show_median_curve=show_median_curve_;
  show_extrapol_uncert=show_extrapolation_uncert;
  show_interpol_uncert=show_interpolated_uncert;
  
  if(measurement_text && *measurement_text)
    strcpy(meas_text, measurement_text);
  else
    strcpy(meas_text, WHAT((char *) "M�linger", (char *) "Measurements"));
  
  if(comparison_text && *comparison_text)
    strcpy(comp_text, comparison_text);
  else
    strcpy(comp_text, WHAT((char *) "Sammenligningskurve", 
			   (char *) "Comparison curve"));

  if(prevcomment)
    delete [] prevcomment;
  prevcomment=NULL;
  if(prev_comment)
    {
      prevcomment=new char[strlen(prev_comment)+5];
      strcpy(prevcomment, prev_comment);
    }

  if(comparisoncurve)
    delete comparisoncurve;
  comparisoncurve=NULL;
  if(comparison_curve)
    comparisoncurve=new segmented_curve(comparison_curve);

  xstage=x_stage;
  measurements=measurements_;
  prior=prior_;
  
  num_attrib = measurements->get_columns();
  num_meas   = measurements->get_rows();
  ret_num_meas=num_meas;
  
  double *q_buff=new double[num_meas];
  double *h_buff=new double[num_meas];
  double *w_buff=new double[num_meas];
  DateTime *dt_buff=new DateTime[num_meas];

  if(measurement_weights)
    for(i=0;i<num_meas;i++)
      w_buff[i]=measurement_weights[i];

  int active=measurements->get_column_number("active");
  if(num_attrib_>0)
    num_attrib=num_attrib_;
  if(active>=0 && alt_attrib_names && alt_attrib_names[0])
    {
      for(i=0;i<num_attrib;i++)
	if(!strcasecmp(alt_attrib_names[i], "active") ||
	   !strcasecmp(alt_attrib_names[i], "aktiv"))
	  num_attrib--;
    }

  char **attrib_names=new char*[num_attrib];
  
  j=0;
  for(i=0;i<measurements->get_columns();i++)
    if(i!=active && j<num_attrib)
      {
	attrib_names[j]=new char[100];
	strcpy(attrib_names[j], measurements->get_column_name(i));

	if(!strcasecmp(attrib_names[j], "stage"))
	  {
	    for(k=0;k<num_meas;k++)
	      h_buff[k]=measurements->get_cell_double(i, k);
	  }
	else if(!strcasecmp(attrib_names[j], "discharge"))
	  {
	    for(k=0;k<num_meas;k++)
	      q_buff[k]=measurements->get_cell_double(i, k);
	  }
	else if(!strcasecmp(attrib_names[j], "time"))
	  {
	    for(k=0;k<num_meas;k++)
	      dt_buff[k]=measurements->get_cell_datetime(i, k);
	  }
	
	if(alt_attrib_names)
	  strcpy(attrib_names[j], alt_attrib_names[j]);
	
	j++;
      }

  // remove zero discharge measurements:
  j=0;
  for(i=0;i<num_meas;i++)
    if(q_buff[i]>=MIN_Q)
      j++;

  q=new double[j];
  h=new double[j];
  dt=new DateTime[j];
  
  if(measurement_weights)
    weights=new double[j];
  else
    weights=NULL;
  
  k=0;
  for(i=0;i<num_meas;i++)
    if(q_buff[i]>=MIN_Q)
      {
	q[k]=q_buff[i];
	h[k]=h_buff[i];
	dt[k]=dt_buff[i];
	if(measurement_weights)
	  weights[k]=w_buff[i];
	k++;
      }
  num_meas=k;
  delete [] q_buff;
  delete [] h_buff;
  delete [] dt_buff;
  delete [] w_buff;
  
  // copy a pointer to the results:
  result=result_;

  // Make the main widgets;
  sh.build(mainwin::toplevel, WHAT((char *) "Kurve-resultat",
				   (char *) "Curve result"));
  v1.build(sh);
  put_in_widget(v1, 900, 450, PLOT_IN_WIDGET_SHOWMAINMENU,false);
  set_grid(True);

  int nummod=prior->get_max_seg(); 
    //mostprob=result->get_most_probable_model()-1;
  double *probs=new double[nummod];
  for(i=0;i<nummod;i++)
    probs[i]=result->get_probability_of_model(i+1);
  
  h8.build(v1);
  v3.build(h8);
  h9.build(v3);
  modelmenu.create(h9, nummod, probs, result->get_chosen_model(), this);
  modelplotb.Create(h9, WHAT((char *) "Plott kurve for modell", 
			     (char *) "Plot curve for model"),
		    BAYES_MULTISEG_MODELPLOT, this); 

  h1.build(v3);
  fr1.build(h1);
  fv1.build(fr1);
  h2.build(fv1);

  histmenu.Create(h2, WHAT((char *) "Parameter:", 
			   (char *) "Parameter:"));
  histb.Create(h2, WHAT((char *) "Vis histogram", 
			(char *) "Show histogram"), 
	       BAYES_MULTISEG_HIST, this);  
  iterb.Create(h2, WHAT((char *) "Vis sample serie", 
			(char *) "Show sample series"), 
	       BAYES_MULTISEG_ITER, this);
  
  h3.build(fv1);
  scattermenu1.Create(h3, WHAT((char *) "Vis ", (char *) "Show"));
  scattermenu2.Create(h3, WHAT((char *) " mot ", (char *) "against"));
  scatterb.Create(h3, WHAT((char *) "Vis spredningsplott", 
			   (char *) "Show scatterplot"), 
		  BAYES_MULTISEG_SCATTER, this);
  
  h4.build(fv1);
  lab1.build(h4, WHAT((char *) "Vis residualer ", 
		      (char *) "Show residuals "));
  resmenu.Create(h4, WHAT((char *) "mot", (char *) "against"));
  resmenu.Insert(attrib_names, num_attrib);
  resb.Create(h4, WHAT((char *) "Plott", (char *) "Plot"), 
	      BAYES_MULTISEG_RESIDUAL_TREND, this);
  resabstog.build(fv1, WHAT((char *) "Absolutt-verdier (for sjekking av "
			    "om det er trender i st�y-st�rrelsen)", 
			    (char *) "Absolute values (for checking "
			    "if there's trends in the noise size)"));

  v2.build(h8);
  fr2.build(v2);
  fv2.build(fr2);
  lab2.build(fv2, WHAT((char *) "Modell-parametre:", 
		       (char *) "Model parameters:"));
  modelparams.build(fv2, 50, 10, False);
  
  //h5.build(v2);
  fr3.build(h8);
  fv3.build(fr3);
  stagef.build(fv3, 5, WHAT((char *) "Vannstand:", (char *) "Stage:"));
  estqb.Create(fv3, WHAT((char *) "Estimer vannf�ring", 
			 (char *) "Estimate discharge"), 
	       BAYES_MULTISEG_ESTIMATE_DISCHARGE, this);
  //h6.build(v2);
  //fr4.build(h1);
  //fv4.build(fr4);
  sep1.build(fv3);
  dischargef.build(fv3,5, WHAT((char *) "Vannf�ring:", (char *) "Discharge:"));
  esthb.Create(fv3, WHAT((char *) "Estimer vannstand", 
			(char *) "Estimate stage"), 
	       BAYES_MULTISEG_ESTIMATE_STAGE, this);
  
  tablestartb.Create(fv3,WHAT((char *) "Vannf�ringstabell", 
			      (char *) "Stage/discharge table"),
		     BAYES_MULTISEG_START_TABLE,this);
  tablesh.build(sh,WHAT((char *) "Utskrift av vannf�ringstabell til fil", 
			(char *) "Output of stage-discharge table to file"));
  tablev1.build(tablesh);
  tableh1.build(tablev1);
  tablestartf.build(tableh1,5,WHAT((char *) "Vannstand start:",
				   (char *) "Stage start:"));
  tableendf.build(tableh1,5,WHAT((char *) "Vannstand slutt:",
				 (char *) "Stage end:"));
  tablestepf.build(tableh1,5,WHAT((char *) "Vannstandsoppl�sning:",
				  (char *) "Stage steps:"));
  tablestepf.SetDouble(0.01,3);
  tablefilexplain.build(tablev1,
			WHAT((char *) "Utskrift av tabell vil bli sendt "
			     "til en CSV-fil, spesifisert her:", 
			     (char *) "The table will be sent to a "
			     "CSV file, specified here:"));
  tableh2.build(tablev1);
  tablefileb.Create(tableh2,WHAT((char *) "Velg lagringsfil", 
				 (char *) "Choose save file"),
		    BAYES_MULTISEG_TABLE_FILE, this);
  tablefileb.Background("green");
  tablefileb.Foreground("black");
  tablefilelab.build(tableh2,WHAT((char *) "Ingen fil valgt", 
				  (char *) "No file chosen"));
  tablefilelab.Background("white");
  table_filesel_sh.build(sh,WHAT((char *) "Valg av utskrifts-fil", 
				 (char *) "Choose output file"));
  table_filesel.Create(table_filesel_sh,this);
  tablesep.build(tablev1);
  tableh3.build(tablev1);
  tableokb.Create(tableh3, "OK", BAYES_MULTISEG_DO_TABLE, this);
  tableokb.Background("green");
  tableokb.Foreground("black");
  tablecloseb.build(tableh3, &tablesh);
  tablecloseb.Background("red");
  tablecloseb.Foreground("white");
  
  table2startb.Create(fv3,WHAT((char *) "Vannstandsserie->vannf�ringsserie", 
			      (char *) "Stage time series -> "
			       "discharge time series"),
		      BAYES_MULTISEG_START_TABLE2,this);
  table2sh.build(sh,WHAT((char *) "Fra vannstandsserie til vannf�ringsserie", 
			(char *) "From stage time series to "
			 "discharge time series"));
  table2v1.build(table2sh);
  table2filexplain.build(table2v1,
			 WHAT((char *) "Vannstandsserie hentes fra fil og "
			      "vannf�ringsserie skrives til fil, "
			      "spesifisert her:", 
			      (char *) "The input stage time series file and "
			      "the output discharge time series file is "
			      "specified here:"));
  table2h1.build(table2v1);
  table2infileb.Create(table2h1,WHAT((char *) "Velg input-fil for vannstand", 
				     (char *) "Choose input file for stage"),
			BAYES_MULTISEG_TABLE2_INFILE, this);
  table2infileb.Background("green");
  table2infileb.Foreground("black");
  table2infilelab.build(table2h1,WHAT((char *) "Ingen fil valgt", 
				      (char *) "No file chosen"));
  table2infilelab.Background("white");
  table2_infilesel_sh.build(sh,WHAT((char *) "Valg av utskrifts-fil", 
				     (char *) "Choose output file"));
  table2_infilesel.Create(table2_infilesel_sh,this);
  table2h2.build(table2v1);
  table2outfileb.Create(table2h2,WHAT((char *) "Velg lagringsfil for "
				      "vannf�ring", 
				     (char *) "Choose save file for discharge"),
			BAYES_MULTISEG_TABLE2_OUTFILE, this);
  table2outfileb.Background("green");
  table2outfileb.Foreground("black");
  table2outfilelab.build(table2h2,WHAT((char *) "Ingen fil valgt", 
				      (char *) "No file chosen"));
  table2outfilelab.Background("white");
  table2_outfilesel_sh.build(sh,WHAT((char *) "Valg av utskrifts-fil", 
				     (char *) "Choose output file"));
  table2_outfilesel.Create(table2_outfilesel_sh,this);
  table2sep.build(table2v1);
  table2h3.build(table2v1);
  table2okb.Create(table2h3, "OK", BAYES_MULTISEG_DO_TABLE2, this);
  table2okb.Background("green");
  table2okb.Foreground("black");
  table2closeb.build(table2h3, &table2sh);
  table2closeb.Background("red");
  table2closeb.Foreground("white");
  
  
  h7.build(v1);

  if(!is_pre_analysis)
    {
      closeb.Create(h7, WHAT((char *) "Avbryt", (char *) "Cancel"),
		    BAYES_MULTISEG_CANCEL, this);
      closeb.Background("red");
      closeb.Foreground("white");
      
      qualtog.Create(h7, this);
      acceptb.Create(h7, WHAT((char *) "Godta", (char *) "Accept"),
		     BAYES_MULTISEG_ACCEPT, this);
      acceptb.Background("green");
      acceptb.Foreground("black");
    }
  else
    {
      closeb.Create(h7, WHAT((char *) "Lukk vindu", (char *) "Close window"),
		    BAYES_MULTISEG_CANCEL, this);
      closeb.Background("red");
      closeb.Foreground("white");
      
      if(allow_save_pre_analysis)
	{
	  spaclab.build(h7, "            ");
	  preanalysis_saveb.Create(h7, 
				   WHAT((char *)"Lagre f�rkunnskap og "
					"pre-analyse", 
					(char *) "Save prior and pre-analysis"),
				   BAYES_MULTISEG_SAVE_PREANALYSIS, this);
	}
    }

  sh.Map();
  make_plot(-1);
  model_chosen(modelmenu.get_model());

  
  if(!is_pre_analysis)
    {
      int model=modelmenu.get_model();
      int l;
      char most_problematic_parameter[1000];
      double max_spacing=0.0;
      for(l=0;l<(4*model+1);l++) // traverse the parameters (plus log-prob)
	// fetch the maximal spacing overall and for parameter 0
	{
	  int len;
	  double *val=get_samples(&len, model, l);
	  if(!val)
	    {
	      err.build(mainwin::toplevel, 
			WHAT((char *) "Programfeil", (char *) "Program error"),
			WHAT((char *) "Noe gikk galt med sample-effektivitets-"
			     "settingen!", 
			     (char *) "Something went wrong in the setting of "
			     "the sample efficiency!"));
	      return;
	    }
	  
	  double rho=get_auto_correlation(val, len);
	  double spacing=2.0*(0.5+rho/(1.0-rho));
	  
	  if(spacing>max_spacing)
	    {
	      max_spacing=spacing;
	      strcpy(most_problematic_parameter, param_names[l]);
	    }
	  
	  delete [] val;
	}
      if(max_spacing>10)
	{
	  char messtr[1000];
	  sprintf(messtr, 
		  WHAT((char *) "Avstand mellom uavhengige trekninger er "
		       "%5.0f etter at kun hver %5d trekning blir brukt, "
		       "for parameter %s.\n"
		       "Det anbefales � sette avstand mellom uavhengige "
		       "trekninger st�rre eller lik %5d i opsjonsmenyen "
		       "og kj�re\n"
		       "igjen. (�kning av burning og tempering kan ogs� "
		       "hjelpe. Se \"Vis sample-serie\" for � eventuelt "
		       "isolere problemet.)",
		       (char *) "The distance between independent samples "
		       "is %5.0f after only keeping each %5.0d sample for "
		       "parameter %s.\n"
		       "It is recommended that you set the number of "
		       "independent samples to at least %5d and rerun the "
		       "analysis again.\n"
		       "(Increasing the burnin and number of tempering chains"
		       " might also help. See \"show sample series\" to "
		       "isolate the problem better.)"),
		  max_spacing,result->get_spacing(),
		  most_problematic_parameter, 
		  (int) ceil(max_spacing*double(result->get_spacing())));
	  
	  mess.build(mainwin::toplevel, WHAT((char *) "Melding", 
					     (char *) "Message"),
		     messtr);
	}
    }
}

void bayes_multiseg_showcurve::make_plot(int model, int separate_plot)
{
  int i, j, numplots=2, num_meas_like=1;
  if(comparisoncurve)
    numplots++;
  if(show_median_curve)
    numplots++;
  if(show_extrapol_uncert)
    numplots++;
  if(show_interpol_uncert)
    numplots+=2;
  int num_restr=0;
  double *restr_stage=NULL, *restr_q_lower=NULL, *restr_q_upper=NULL;
  if(prior && prior->num_internal_restrictions()>0)
    {
      num_restr=prior->num_internal_restrictions();
      restr_stage=prior->stage_internal_restrictions();
      restr_q_lower=prior->logdischarge_lower_internal_restrictions();
      restr_q_upper=prior->logdischarge_upper_internal_restrictions();
    }
  if(num_restr>0 && restr_stage && restr_q_lower && restr_q_upper)
    {
      numplots++;
      num_meas_like++;
    }
  int num_extra=0;
  double *extra_stage=NULL, *extra_q_lower=NULL, *extra_q_upper=NULL;
  if(prior && prior->num_extrapolation_restrictions()>0)
    {
      num_extra=prior->num_extrapolation_restrictions();
      extra_stage=prior->stage_extrapolation_restrictions();
      extra_q_lower=prior->logdischarge_lower_extrapolation_restrictions();
      extra_q_upper=prior->logdischarge_upper_extrapolation_restrictions();
    }
  if(num_extra>0 && extra_stage && extra_q_lower && extra_q_upper)
    {
      numplots++;
      num_meas_like++;
    }
  
  // Plotting variables;
  double **arg=new double*[numplots], **val=new double*[numplots];
  char **linetitles=new char*[numplots];
  char **axistitles=new char*[2];
  int *yaxis=new int[numplots], *len=new int[numplots];
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[numplots];
  PLOTLINE_STYLE *style=new PLOTLINE_STYLE[numplots];
  char **colnames=new char*[numplots];
  int *plotwidth=new int[numplots];
  double minh=find_statistics(h, num_meas, MIN);
  double maxh=find_statistics(h, num_meas, MAX);
  double step=0.05,x;
  int num;
  
  x1=minh-5.0;
  x2=maxh+5.0;
  if((maxh-minh)<1.0)
    {
      x1=minh-1.0;
      x2=maxh+1.0;
      step=0.01;
    }
  else if(maxh-minh<2.0)
    {
      x1=minh-2.0;
      x2=maxh+2.0;
      step=0.02;
    }

  for(x=minh; x>=minh-100.0; x-=0.25)
    {
      double qm=result->get_median_discharge(x);
      double q_low=result->get_discharge_quantile(x,2.5);
      
      if(qm<=0.000001 && q_low<=0.000001)
	{
	  x1=x;
	  break;
	}
    }
  x1-=0.1;
  num=(int) ceil((x2-x1)/step)+1;

  tablestartf.SetDouble(x1,3);
  tableendf.SetDouble(x2,3);
  
  if(show_extrapol_uncert)
    result->set_extrapolation_samples(x2, 10*
				      result->number_of_mcmc_simulations());
  
  // Make the plot;
  for(i=0;i<numplots;i++)
    {
      linetitles[i]=new char[100];
      colnames[i]=new char[100];
    }
  axistitles[0]=new char[100];
  axistitles[1]=new char[100];
  
  if(xstage)
    {
      strcpy(axistitles[0], "m");
      strcpy(axistitles[1], "m^3/s");
    }
  else
    {
      strcpy(axistitles[1], "m");
      strcpy(axistitles[0], "m^3/s");
    }
  
  i=0;
  if(show_median_curve)
    {
      strcpy(linetitles[i], 
	     WHAT((char *) "Estimert (median) kurve",
		  (char *) "Estimated (median) curve"));
      if(model>0)
	sprintf(linetitles[i]+strlen(linetitles[i]),
		WHAT((char *) " for %d segmenter",
		     (char *) " for %d segments"),
		model);
      arg[i]=new double[num];
      val[i]=new double[num];
      len[i]=num;
      type[i]=PLOTLINE_LINE;
      style[i]=PLOTLINE_SOLID;
      strcpy(colnames[i], "red");
      yaxis[i]=1;
      plotwidth[i]=1;
      i++;
    }

  if(show_extrapol_uncert)
    {
      strcpy(linetitles[i], WHAT((char *) "95% troverdighetsintervall " 
				 "med ekstrapoleringsusikkerhet",
				 (char *) "95% credibility interval "
				 "with extrapolation uncertainty"));
      arg[i]=new double[2*num+1];
      val[i]=new double[2*num+1];
      len[i]=2*num+1;
      type[i]=PLOTLINE_LINE;
      style[i]=PLOTLINE_SOLID;
      strcpy(colnames[i], "#00aa00");
      yaxis[i]=1;
      plotwidth[i]=2;
      i++;
    }

  sprintf(linetitles[i], 
	  WHAT((char *) "Kurve fra estimerte parametre", 
	       (char *) "Curve from estimated parameters"));
  if(model<=0)
    sprintf(linetitles[i]+strlen(linetitles[i]),
	    WHAT((char *) " for den initielt valgte modellen: %d",
		 (char *) " for the initially chosen model: %d"),
	    result->get_chosen_model());
  else
    sprintf(linetitles[i]+strlen(linetitles[i]), 
	    WHAT((char *) " for modell %d", (char * ) "for model %d"),
	    model);
  
  arg[i]=new double[num];
  val[i]=new double[num];
  len[i]=num;
  type[i]=PLOTLINE_LINE;
  style[i]=PLOTLINE_SOLID;
  strcpy(colnames[i], "black");
  yaxis[i]=1;
  plotwidth[i]=2;
  i++;

  if(show_interpol_uncert)
    {
      strcpy(linetitles[i], 
	     WHAT((char *) "95% "
		  "troverdighetsintervall uten ekstrapolasjonsusikkerhet",
		  (char *) "95% credibility "
		  "interval without extrapolation uncertainty"));
      arg[i]=new double[num];
      val[i]=new double[num];
      len[i]=num;
      type[i]=PLOTLINE_LINE;
      style[i]=PLOTLINE_LARGE_DASH;
      strcpy(colnames[i], "#0000bb");
      yaxis[i]=1;
      plotwidth[i]=1;
      i++;
      
      strcpy(linetitles[i], "");
      arg[i]=new double[num];
      val[i]=new double[num];
      len[i]=num;
      type[i]=PLOTLINE_LINE;
      style[i]=PLOTLINE_LARGE_DASH;
      strcpy(colnames[i], "#0000bb");
      yaxis[i]=1;
      plotwidth[i]=1;
      i++;
    }
  
  if(comparisoncurve)
    {
      strcpy(linetitles[i], comp_text);
      arg[i]=new double[num];
      val[i]=new double[num];
      len[i]=num;
      type[i]=PLOTLINE_LINE;
      style[i]=PLOTLINE_SOLID;
      strcpy(colnames[i], "#aa00aa");
      yaxis[i]=1;
      plotwidth[i]=1;
      i++;
    }
  
  if(num_restr>0 && restr_stage && restr_q_lower && restr_q_upper)
    {
      strcpy(linetitles[i], "Interpolerings-restriksjoner p� "
	     "spesifikke vannstander");
      arg[i]=new double[9*num_restr];
      val[i]=new double[9*num_restr];
      len[i]=9*num_restr;
      type[i]=PLOTLINE_LINE;
      style[i]=PLOTLINE_SOLID;
      strcpy(colnames[i], "#00aa55");
      yaxis[i]=1;
      plotwidth[i]=3;
      
      for(j=0;j<9*num_restr;j++)
	{
	  arg[i][j]=restr_stage[i/9];
	  val[i][j]=MISSING_VALUE;
	}
      
      int j2=0;
      for(j=0;j<num_restr;j++)
	{
	  if(restr_q_lower[j]!=MISSING_VALUE && 
	     restr_q_upper[j]!=MISSING_VALUE)
	    {
	      // Show lower boundry:
	      arg[i][j2]=restr_stage[j]-0.05;
	      val[i][j2]=exp(restr_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j]+0.05;
	      val[i][j2]=exp(restr_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show upper  boundry:
	      arg[i][j2]=restr_stage[j]-0.05;
	      val[i][j2]=exp(restr_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j]+0.05;
	      val[i][j2]=exp(restr_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show line between lower and upper boundry:
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=exp(restr_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=exp(restr_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;
	    }
	  else if(restr_q_lower[j]!=MISSING_VALUE)
	    {
	      // Show lower boundry:
	      arg[i][j2]=restr_stage[j]-0.05;
	      val[i][j2]=exp(restr_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j]+0.05;
	      val[i][j2]=exp(restr_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show line going from lower boundry and up:
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=exp(restr_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=exp(restr_q_lower[j])*2.0;
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;
	    }
	  else if(restr_q_upper[j]!=MISSING_VALUE)
	    {
	      // Show upper boundry:
	      arg[i][j2]=restr_stage[j]-0.05;
	      val[i][j2]=exp(restr_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j]+0.05;
	      val[i][j2]=exp(restr_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show line going from upper boundry and down:
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=exp(restr_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=exp(restr_q_lower[j])/2.0;
	      j2++;
	      
	      arg[i][j2]=restr_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;
	    }
	}
      len[i]=j2;
      i++;
    }

  if(num_extra>0 && extra_stage && extra_q_lower && extra_q_upper)
    {
      strcpy(linetitles[i], "Ekstrapolerings-restriksjoner p� "
	     "spesifikke vannstander");
      arg[i]=new double[9*num_extra];
      val[i]=new double[9*num_extra];
      len[i]=9*num_extra;
      type[i]=PLOTLINE_LINE;
      style[i]=PLOTLINE_SOLID;
      strcpy(colnames[i], "#000099");
      yaxis[i]=1;
      plotwidth[i]=3;
      
      for(j=0;j<9*num_extra;j++)
	{
	  arg[i][j]=extra_stage[i/9];
	  val[i][j]=MISSING_VALUE;
	}
      
      int j2=0;
      for(j=0;j<num_extra;j++)
	{
	  if(extra_q_lower[j]!=MISSING_VALUE && 
	     extra_q_upper[j]!=MISSING_VALUE)
	    {
	      // Show lower boundry:
	      arg[i][j2]=extra_stage[j]-0.05;
	      val[i][j2]=exp(extra_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j]+0.05;
	      val[i][j2]=exp(extra_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show upper  boundry:
	      arg[i][j2]=extra_stage[j]-0.05;
	      val[i][j2]=exp(extra_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j]+0.05;
	      val[i][j2]=exp(extra_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show line between lower and upper boundry:
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=exp(extra_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=exp(extra_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;
	    }
	  else if(extra_q_lower[j]!=MISSING_VALUE)
	    {
	      // Show lower boundry:
	      arg[i][j2]=extra_stage[j]-0.05;
	      val[i][j2]=exp(extra_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j]+0.05;
	      val[i][j2]=exp(extra_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show line going from lower boundry and up:
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=exp(extra_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=exp(extra_q_lower[j])*2.0;
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;
	    }
	  else if(extra_q_upper[j]!=MISSING_VALUE)
	    {
	      // Show upper boundry:
	      arg[i][j2]=extra_stage[j]-0.05;
	      val[i][j2]=exp(extra_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j]+0.05;
	      val[i][j2]=exp(extra_q_upper[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;

	      // Show line going from upper boundry and down:
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=exp(extra_q_lower[j]);
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=exp(extra_q_lower[j])/2.0;
	      j2++;
	      
	      arg[i][j2]=extra_stage[j];
	      val[i][j2]=MISSING_VALUE;
	      j2++;
	    }
	}
      len[i]=j2;
      i++;
    }

  strcpy(linetitles[i], meas_text);
  arg[i]   = new double[num_meas];
  val[i]   = new double[num_meas];
  type[i]  = PLOTLINE_DOT;
  len[i]   = num_meas;
  style[i] = PLOTLINE_SOLID;
  strcpy(colnames[i], "black");
  yaxis[i] = 1;
  plotwidth[i]=2;
  for(j=0;j<num_meas;j++)
    {
      arg[i][j]=h[j];
      val[i][j]=q[j];
    }
  
  segmented_curve *medcurve;
  if(model>0)
    medcurve=result->get_modus_curve(model,x2);
  else
    medcurve=result->get_best_modus_curve(x2);
  
  for(j=0;j<num;j++)
    {
      x=x1+step*double(j);
      
      for(i=0;i<(numplots-num_meas_like);i++)
	arg[i][j]=x;
      
      i=0;
      if(show_median_curve)
	{
	  if(show_extrapol_uncert)
	    val[i++][j]=result->get_median_extrapolation_discharge(x);
	  else
	    val[i++][j]=result->get_median_discharge(x, model);
	}
      if(show_extrapol_uncert)
	i++;
      val[i++][j]=medcurve->get_discharge(x);
      if(show_interpol_uncert)
	{
	  val[i++][j]=result->get_discharge_quantile(x,97.5, model);
	  val[i++][j]=result->get_discharge_quantile(x,2.5, model);
	}
      if(comparisoncurve)
	val[i++][j]=comparisoncurve->get_discharge(x);
    }

  if(show_extrapol_uncert)
    {	  
      i=0;
      if(show_median_curve)
	i++;
      
      for(j=0;j<num;j++)
	{
	  x=x1+step*double(j);
	  arg[i][j]=arg[i][num+1+j]=x;
	  val[i][j]=result->get_discharge_extrapolation_quantile(x, 2.5);
	  val[i][j+num+1]=
	    result->get_discharge_extrapolation_quantile(x, 97.5);
	}
      arg[i][num]=x1+step*double(num);
      val[i][num]=MISSING_VALUE;
    }

  char title[1000];
  sprintf(title, WHAT((char *) "Vannf�ringskurve - %s", 
		      (char *) "Rating curve - %s"), 
	  "Q(h) = C (h-h0)^b");
  
  if(!separate_plot)
    {
      if(black_and_white_inverted())
	do_invert_black_and_white();
      set_x_axis_font_size(PLOT_FONT_LARGE);
      set_y_axis_font_size(PLOT_FONT_LARGE);
      set_outer_rectangle(False);
      set_inner_rectangle(False);
      if(xstage)
	Create(arg, val, len, yaxis, linetitles, 
	       numplots, axistitles, 2, NULL /*title*/ , type, NULL,
	       style, colnames,plotwidth);
      else
	Create(val, arg, len, yaxis, linetitles, 
	       numplots, axistitles, 2, NULL /*title*/ , type, NULL,
	       style, colnames,plotwidth);
    }
  else
    {
      //if(extraplot)
      //delete extraplot;
      extraplot=new plot_shell();
      
      extraplot->make_plotting_window(1000,800,
				      WHAT((char *) "Modell-plott", 
					   (char *) "Model plot"));
      extraplot->set_x_axis_font_size(PLOT_FONT_LARGE);
      extraplot->set_y_axis_font_size(PLOT_FONT_LARGE);
      extraplot->set_outer_rectangle(False);
      extraplot->set_inner_rectangle(False);
      if(extraplot->black_and_white_inverted())
	extraplot->do_invert_black_and_white();
      //extraplot->set_big();
      if(xstage)
	extraplot->Create(arg, val, len, yaxis, linetitles, numplots,
			  axistitles, 2, NULL, type, NULL,
			  style, colnames,plotwidth);
      else
	extraplot->Create(val, arg, len, yaxis, linetitles, numplots,
			  axistitles, 2, NULL, type, NULL,
			  style, colnames,plotwidth);
      
    }

  delete medcurve;
  doubledelete(arg,numplots);
  doubledelete(val,numplots);
  doubledelete(linetitles,numplots);
  doubledelete(colnames,numplots);
  doubledelete(axistitles,2);
  delete [] len;
  delete [] style;
  delete [] yaxis;
  delete [] type;
  delete [] plotwidth;;
}

void bayes_multiseg_showcurve::plot_ended(void)
{
  cancel();
  sh.Unmap();
}

void bayes_multiseg_showcurve::preview_done(int , int , double , double , bool )
{
  // NOP
}

void bayes_multiseg_showcurve::cancel(void)
{
  // NOP
}

void bayes_multiseg_showcurve::accept( // analysis results:
		      segmented_curve *, double ,
		      segmented_curve_analysis *,
		      
		      // prior:
		      segmented_priors *,
		      
		      // background data:
		      tablelist *,
		      double *, double *, 
		      DateTime *, int ,
		      
		      // quality judgement:
		      int, const char *, int, int, int, int, int, int, int, int, int, int, int, 
		      
		      // quality measures:
		      const char *, double, double, double, double, double, double, 
		      double, double, double, double, double)
{
  // NOP
}

void bayes_multiseg_showcurve::save_pre_analysis( // analysis results:
						 segmented_curve *, double ,
						 segmented_curve_analysis *,
						 
						 // prior:
						 segmented_priors *,
						 
						 // background data:
						 tablelist *,
						 double *, double *, 
						 DateTime *, int )
{
  // NOP
}

void bayes_multiseg_showcurve::set_allow_save_pre_analysis(bool do_allow)
{
  allow_save_pre_analysis=do_allow;
}
	
segmented_curve_analysis *bayes_multiseg_showcurve::get_result(void)
{
  return result;
}
