/*
 * $Id: color.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/color.C $
 */

#include <hydrasub/hydragui/color.H>
#include <hydrasub/hydragui/mainwin.H>

static const char *color_name[] = {
    "background", "foreground", 
    "red", "green", "blue", "cyan", "magenta", "yellow","white"
  };

Pixel gpgscolors[CYELLOW + 1];

static const char *motifsubcolname[] = {
    "bisque1", "bisque2", "bisque3", "black", "coral1"
  };
Pixel motifsubcolors[CORAL1+1];


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void SetGPGSColors(Widget w) {
    XrmValue fromVal, toVal;
    
    XtVaGetValues(w,
		  XmNbackground, &gpgscolors[0],
		  XmNforeground, &gpgscolors[1],
		  NULL);
    
    for(register int i = 2; i < CYELLOW + 1; i++) {
	fromVal.size = strlen(color_name[i]) + 1;
	fromVal.addr = (char*)color_name[i];
	toVal.size = sizeof(Pixel);
	toVal.addr = (caddr_t) &gpgscolors[i];
	if (!XtConvertAndStore(w, XtRString, &fromVal, XtRPixel, &toVal))
	    return;
    };
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
Pixel GetColor(Widget w, const char *colorname) {
    Pixel p;
    XrmValue fromVal, toVal;
    fromVal.size = strlen(colorname) + 1;
    fromVal.addr = (char*)colorname;
    toVal.size = sizeof(Pixel);
    toVal.addr = (caddr_t) &p;
    if (!XtConvertAndStore(w, XtRString, &fromVal, XtRPixel, &toVal))
      {
	Display *display = XtDisplay(w);
	Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
	XColor col;
	
	XParseColor(display, cmap, colorname, &col);
	XAllocColor(display, cmap, &col);
	p=col.pixel;
	return p;
      }
    return (p);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
Pixel GetColor(const char *colorname) 
{
  Widget w=mainwin::toplevel;
  Pixel p;
  XrmValue fromVal, toVal;
  fromVal.size = strlen(colorname) + 1;
  fromVal.addr = (char*)colorname;
  toVal.size = sizeof(Pixel);
  toVal.addr = (caddr_t) &p;
  if (!XtConvertAndStore(w, XtRString, &fromVal, XtRPixel, &toVal))
    {
      Display *display = XtDisplay(w);
      Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
      XColor col;
      
      XParseColor(display, cmap, colorname, &col);
      XAllocColor(display, cmap, &col);
      p=col.pixel;
      return p;
    }
  return (p);
}


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void InitColor(Widget w) {
    Display *display = XtDisplay(w);
    Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
    XColor col;

    for(int i = 0; i < CORAL1 + 1; i++) {
	XParseColor(display, cmap, motifsubcolname[i], &col);
	XAllocColor(display, cmap, &col);
	motifsubcolors[i] = col.pixel;
    };
}
