/*
 * $Id: widget.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/widget.C $
 */

#include <hydrasub/hydragui/widget.H>
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/color.H>
#include <fstream>

#ifdef NVE /* NVE specific code */
#include <envirsub/path.H>
#endif // NVE


// ######################################################################
// Purpose   : holds information for all type Widget
// ######################################################################
widget::widget() : w(NULL)
{
  no_args = 0;
} /* widget */

// ######################################################################
// Purpose   : 
// ######################################################################
widget::~widget()
{
 
} /* ~widget */

// ######################################################################
// Return    : void
// Parameters: name - widget resource name
//             iclass - WidgetClass type
//             parent - my parent Widget
// Purpose   : create a widget specified by iclass and use resources
//             set by XmInitSetArg() and XmSetArg()
// ######################################################################
void widget::init(const char *name, const WidgetClass iclass,
		  const Widget parent)
{
    // Check that we don't exceed MAX_NO_ARGS
  int noargs = MAX_NO_ARGS < no_args ? MAX_NO_ARGS : no_args;
   
  strcpy(wname, name);
  
  w = XtCreateManagedWidget(wname, iclass, parent, widget::args, noargs);
  
} /* init */


// ######################################################################
// Return    : int   1 is mapped, 0 not mapped
// Parameters: void
// Purpose   : tell if this widget is mapped
// ######################################################################
int widget::IsMapped()
{
  return XtIsManaged(w);
} /* IsMapped */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : map this widget
// ######################################################################
void widget::Map()
{
  XtManageChild(w);
} /* Map */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : unmap this widget
// ######################################################################
void widget::Unmap()
{
  XtUnmanageChild(w);
} /* Unmap */

// ######################################################################
// Return    : int   1 is sensitive, 0 is not sensitive
// Parameters: void
// Purpose   : tell if if this widget is semsitive (grayed out)
// ######################################################################
int widget::IsSensitive()
{
  return XtIsSensitive(w);
} /* IsSensitive */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget sensitive
// ######################################################################
void widget::Sensitive()
{
  XtSetSensitive(w, True);
} /* Sensitive */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget insensitive (grayed out)
// ######################################################################
void widget::InSensitive()
{
  XtSetSensitive(w, False);
} /* InSensitive */

// ######################################################################
// Return    : void
// Parameters: width
// Purpose   : change width for this widget
// ######################################################################
void widget::Width(Dimension width)
{
  XtVaSetValues(w, XmNwidth, width, NULL);
} /* Width */

// ######################################################################
// Return    : void
// Parameters: height
// Purpose   : change height for this widget
// ######################################################################
void widget::Height(Dimension height)
{
  XtVaSetValues(w, XmNheight, height, NULL);
} /* Height */

// ######################################################################
// Return    : Dimension
// Parameters: void
// Purpose   : return the widgets width
// ######################################################################
Dimension widget::Width()
{
  Dimension width;
  XtVaGetValues(w, XmNwidth, &width, NULL);
  return width;
} /* Width */

// ######################################################################
// Return    : Dimension
// Parameters: void
// Purpose   : return the widgets height
// ######################################################################
Dimension widget::Height()
{
  Dimension height;
  XtVaGetValues(w, XmNheight, &height, NULL);
  return height;
} /* Height */

// ######################################################################
// Return    : void
// Parameters: p - a pixel value
// Purpose   : change background for this widget
// ######################################################################
void widget::Background(Pixel p)
{
  XtVaSetValues(w, XmNbackground, p, NULL);
} /* Background */

// ######################################################################
// Return    : void
// Parameters: sec - seconds
// Purpose   : make a beep in sec seconds
// ######################################################################
void widget::Beep(int sec)
{
  XBell(XtDisplay(w),sec);
} /* Beep */

// ######################################################################
// Return    : void
// Parameters: color_name - a color name
// Purpose   : change background for this widget
// ######################################################################
void widget::Background(const char *color_name)
{
  /*
    Display *display = XtDisplay(w);
    Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
    XColor col;
    Pixel p;

    XParseColor(display, cmap, color_name, &col);
    XAllocColor(display, cmap, &col);
    p=col.pixel;

    XtVaSetValues(w, XmNbackground, p, NULL);
    */
  Pixel p=GetColor(color_name);
  //if(p)
  Background(p);
} /* Background */

// ######################################################################
// Return    : void
// Parameters: p - a pixel value
// Purpose   : change foreground for this widget
// ######################################################################
void widget::Foreground(Pixel p)
{
  XtVaSetValues(w, XmNforeground, p, NULL);
} /* Foreground */

// ######################################################################
// Return    : void
// Parameters: color_name - a color name
// Purpose   : change foreground for this widget
// ######################################################################
void widget::Foreground(const char *color_name)
{ 
  /*
    Display *display = XtDisplay(w);
    Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
    XColor col;
    Pixel p;

    XParseColor(display, cmap, color_name, &col);
    XAllocColor(display, cmap, &col);
    p=col.pixel;

    XtVaSetValues(w, XmNforeground, p, NULL);
    */
  Pixel p=GetColor(color_name);
  //if(p)
  Foreground(p);
} /* Foreground */

// read from the Xdefault file for setting the standard colours
void widget::standard_colours(void)
{
    std::ifstream in;
  char line[1000], *ptr,background[100]="", foreground[100]="";
  const char* filename;
#ifdef NVE /* NVE specific code */
  filename= hydraenvir::path::etc("Xdefaults").c_str();
#else
#ifdef XDEFAULTFILE
  filename=XDEFAULTFILE;
#endif // LIBDIR
#endif // NVE  

  in.open(filename, std::ios::in);
  if(in.fail())
    return;
  
  while(!in.eof())
    {
      in.getline(line,999);
      if(line[0]=='\0' || line[0]=='#')
	continue;

      if((ptr=strstr(line, "Background:")) != NULL)
	sscanf(ptr+11,"%s", background);

      if((ptr=strstr(line, "Foreground:")) != NULL)
	sscanf(ptr+11,"%s", foreground);
    }

  if(*background)
    Background(background);

  if(*foreground)
    Foreground(foreground);

  in.close();
}

// ######################################################################
// Return    : Widget
// Parameters: void
// Purpose   : type cast for Widget
// ######################################################################
widget::operator Widget()
{
  return w;
} /* operator Widget */

// **********************************************************************
// Gives the width of the screen
// **********************************************************************

int widget::screenwidth(void)
{
    return WidthOfScreen(XtScreen(mainwin::toplevel)) > 1280 ? 1280 : WidthOfScreen(XtScreen(mainwin::toplevel));
}

// **********************************************************************
// Gives the height of the screen
// **********************************************************************

int widget::screenheight(void)
{
    return HeightOfScreen(XtScreen(mainwin::toplevel)) > 1024 ? 1024 : HeightOfScreen(XtScreen(mainwin::toplevel));
}


void widget::Print(std::ostream &out)
{
    out << w << std::endl;
}

// ######################################################################
// Parameters: str - a char * string
// Purpose   : 
// ######################################################################
xmstring::xmstring(const char *str)
{
  if (1) {
      xmstr = XmStringCreateLtoR((char*)str, XmSTRING_DEFAULT_CHARSET);
  } else {
    XmString xms2;
    XmString line;
    XmString separator;
    char     *p;
    char     *t = XtNewString(str);   /* Make a copy for strtok not to */
    /* damage the original string    */
    
    separator = XmStringSeparatorCreate();
    p         = strtok(t,"\n");
    xmstr      = XmStringCreateLocalized(p);
    
    while ((p = strtok(NULL,"\n")) != NULL) {
      line = XmStringCreateLocalized(p);
      xms2 = XmStringConcat(xmstr,separator);
      XmStringFree(xmstr);
      xmstr = XmStringConcat(xms2,line);
      XmStringFree(xms2);
      XmStringFree(line);
    }
    
    XmStringFree(separator);
    XtFree(t);
  }
} /* xmstring */

// ######################################################################
// Purpose   : automaticly destroy local copy
// ######################################################################
xmstring::~xmstring()
{
  XmStringFree(xmstr);
} /* ~xmstring */
 
// ######################################################################
// Return    : XmString & - reference to a XmString
// Parameters: void
// Purpose   : type cast to XmString
// ######################################################################
xmstring::operator XmString &()
{
  return xmstr;
} /* operator XmString & */


// ######################################################################
// Parameters: is - const char * pointer to a string
// Purpose   : creates a local copy of is
// ######################################################################
xchar::xchar(const char *is)
{
  s = new char[strlen(is) + 1];
  strcpy(s, is);
} /* xchar */

// ######################################################################
// Purpose   : automaticly destroy local copy
// ######################################################################
xchar::~xchar()
{
  delete [] s; s = NULL;
} /* ~xchar */
 
// ######################################################################
// Return    : char * 
// Parameters: void
// Purpose   : type cast to char *
// ######################################################################
xchar::operator char *()
{
  return s;
} /* operator char * */
