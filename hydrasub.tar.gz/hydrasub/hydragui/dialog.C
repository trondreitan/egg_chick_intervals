/*
 * $Id: dialog.C 1518 2009-01-13 14:54:35Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/dialog.C $
 */

#include <hydrasub/hydragui/dialog.H>
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/color.H>
#include <Xm/MessageB.h>
#include <hydrasub/hydrabase/types.H>
#include <hydrasub/hydrabase/divfunc.H>

static ErrorDialog err;
static MessageDialog mess;

// ######################################################################
// Return    : void
// Parameters: parent - widget to put this dialog over
//             title  - the title that will appear on titlline
//             format, ... - same input as printf() can handle
// Purpose   : Compose a dialog and put it onto screen
// ######################################################################
void dialog::build(const Widget parent, const char *title, const char *format, ...)
{
    char message[4000];
    va_list args;
    va_start(args, format);
    vsprintf(message, format, args);
    va_end(args);
    xmstring xtitle(title), xmsg(message);


    if(!done) {
	XmInitSetArg(XmNdialogStyle,   XmDIALOG_FULL_APPLICATION_MODAL);
	
	init(title, NULL, parent);
	done = 1;

	XtUnmanageChild(XmMessageBoxGetChild(w, XmDIALOG_HELP_BUTTON));
	
	XtAddCallback(w, XmNokCallback, (XtCallbackProc)&dialog::CB, 
	(XtPointer)this);
	XtAddCallback(w, XmNcancelCallback, (XtCallbackProc)&dialog::CB, 
	(XtPointer)this);
    };
    if(language == Norwegian) {
	xmstring okstr("Lukk vindu"), cancelstr("Angre");
	XtVaSetValues(w, 
		      XmNokLabelString, (XmString &)okstr,
		      XmNcancelLabelString, (XmString &)cancelstr,
		      NULL);
    } else {
	xmstring okstr("Close"), cancelstr("Cancel");
	XtVaSetValues(w, 
		      XmNokLabelString, (XmString &)okstr,
		      XmNcancelLabelString, (XmString &)cancelstr,
		      NULL);
    };

    XtVaSetValues(w, 
		  XmNdialogTitle,   (XmString &)xtitle,
		  XmNmessageString, (XmString &)xmsg, 
		  NULL);
    XtSetSensitive(XmMessageBoxGetChild(w, XmDIALOG_CANCEL_BUTTON), False);

    Map();
    XtPopup(XtParent(w), XtGrabNone);

} /* build */

// ######################################################################
// Return    : int - 1 OK, 0 CANCEL
// Parameters: void
// Purpose   : build() must be called first. This routine waits for user
//             to press OK or CANCEL. Depending on which button was
//             pressed, it returns 0 or 1
// ######################################################################
int dialog::ok_or_cancel(const char *okstr, const char *cancelstr)
{
    xmstring xokstr(okstr), xcancelstr(cancelstr);
    XtVaSetValues(w, 
		  XmNokLabelString, (XmString &)xokstr,
		  XmNcancelLabelString, (XmString &)xcancelstr,
		  NULL);
    
    XtSetSensitive(XmMessageBoxGetChild(w, XmDIALOG_CANCEL_BUTTON), True);
    answer = 42;
    while(answer == 42)
	XtAppProcessEvent(mainwin::app, XtIMAll);
    return answer;
} /* ok_or_cancel */

// ######################################################################
// Return    : int - 1 OK, 0 CANCEL
// Parameters: void
// Purpose   : build() must be called first. This routine waits for user
//             to press OK.
// ######################################################################
void  dialog::wait(void)
{
  answer = 42;
  while(answer == 42)
    XtAppProcessEvent(mainwin::app, XtIMAll);
} /* ok_or_cancel */



// ######################################################################
// Return    : void
// Parameters: pt - pointer a dialog instance
//             call_data - information from Motif
// Purpose   : 
// ######################################################################
void dialog::CB(Widget, dialog *pt, XtPointer call_data)
{
    XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *)call_data;
    
    switch(cbs->reason) {
    case XmCR_OK:
	pt->answer = 1;
	pt->ok();
	break;
    case XmCR_CANCEL:
	pt->answer = 0;
	pt->cancel();
	break;
    };
} /* CB */

// ######################################################################
// Return    : void
// Parameters: name - name of this instance
//             parent - my parent
// Purpose   : Builds a MessageDialog
// ######################################################################
void MessageDialog::init(const char *name, const WidgetClass, 
			 const Widget parent)
{
    xchar x(name);
    w = XmCreateMessageDialog(parent, x, args, no_args);
} /* init */

// ######################################################################
// Return    : void
// Parameters: name - name of this instance
//             parent - my parent
// Purpose   : Builds a ErrorDialog
// ######################################################################
void ErrorDialog::init(const char *name, const WidgetClass, 
		       const Widget parent)
{
    xchar x(name);
    w = XmCreateErrorDialog(parent, x, args, no_args);
} /* init */

// ######################################################################
// Return    : void
// Parameters: name - name of this instance
//             parent - my parent
// Purpose   : Builds a InformationDialog
// ######################################################################
void InformationDialog::init(const char *name, const WidgetClass, 
			     const Widget parent)
{
    xchar x(name);
    w = XmCreateInformationDialog(parent, x, args, no_args);
} /* init */


// ######################################################################
// Return    : void
// Parameters: name - name of this instance
//             parent - my parent
// Purpose   : Builds a QuestionDialog
// ######################################################################
void QuestionDialog::init(const char *name, const WidgetClass, 
			  const Widget parent)
{
    xchar x(name);
    w = XmCreateQuestionDialog(parent, x, args, no_args);
} /* init */

// ######################################################################
// Return    : void
// Parameters: name - name of this instance
//             parent - my parent
// Purpose   : Builds a WarningDialog
// ######################################################################
void WarningDialog::init(const char *name, const WidgetClass, 
			 const Widget parent)
{
    xchar x(name);
    w = XmCreateWarningDialog(parent, x, args, no_args);
} /* init */

// ######################################################################
// Return    : void
// Parameters: name - name of this instance
//             parent - my parent
// Purpose   : Builds a WorkingDialog
// ######################################################################
void WorkingDialog::init(const char *name, const WidgetClass, 
			 const Widget parent)
{
    xchar x(name);
    w = XmCreateWorkingDialog(parent, x, args, no_args);
} /* init */


#ifdef MAIN
main(int argc, char **argv) 
{
  mainwin m(argv[0], argc, argv);
  err.build(m, "hepp", "hepp");
  if(err.ok_or_cancel("Slett alt", "Angre")) 
    cout << "ok" << endl;
  else 
    cout << "cancel" << endl;
  exit(0);
    m.Run();
}
#endif
