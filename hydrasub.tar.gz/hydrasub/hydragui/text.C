/*
 * $Id: text.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/text.C $
 */


#include <hydrasub/hydragui/text.H>
#include <hydrasub/hydragui/color.H>
#include <hydrasub/hydragui/email.H>
#include <sys/types.h>
#include <time.h>
#include <fstream>

#include <Xm/ScrolledW.h>

// ######################################################################
// Return    : void
// Parameters: name - textarea resource name
//             parent - my parent Widget
// Purpose   : builds a textarea
// ######################################################################
void text::init(const char *name, const WidgetClass, const Widget parent)
{
  char *na = new char[strlen(name) + 1];
  strcpy(na, name);
  w = XmCreateScrolledText(parent, na, args, no_args);
  delete [] na;
}


// ######################################################################
// Return    : void
// Parameters: parent - my Widget parent
//             col, row - dimension on textarea
//             edit - allow to edit
// Purpose   : builds a textarea with dimension col and row and 
//             make editable ot not depending on edit.
// ######################################################################
void text::build(const Widget parent, int col, int row, bool edit) 
{
  if(!done) 
    {
      XmInitSetArg(XmNrows, row);
      XmSetArg(XmNcolumns, col);
      XmSetArg(XmNeditable, edit);
      XmSetArg(XmNeditMode, XmMULTI_LINE_EDIT);
      XmSetArg(XmNwordWrap, True);
      XmSetArg(XmNblinkRate, 0);
      XmSetArg(XmNautoShowCursorPosition, True);
      XmSetArg(XmNcursorPositionVisible, edit);
      XmSetArg(XmNbackground, motifsubcolors[BISQUE1]);
      XmSetArg(XmNforeground, motifsubcolors[BLACK]);
      XmSetArg(XmNallowResize, True);
      init("text", NULL, parent);
      done = 1;
    }
  Map();
}

// ######################################################################
// Return    : void
// Parameters: s - pointer to text
// Purpose   : replace the content of textarea with new text s
// ######################################################################
text &text::operator=(const char *s) 
{
    XmTextSetString(w, (char*)s);
  return *this;
}

// ######################################################################
// Return    : void
// Parameters: s - pointer to text
// Purpose   : insert text s at the beginning of the textarea
// ######################################################################
void text::Prepend(const char *s)
{
  if(XmTextGetLastPosition(w)>0)
      XmTextInsert(w, 0, (char*)s);
  else
    SetText(s);
} /* Prepend */

// ######################################################################
// Return    : void
// Parameters: s - pointer to text
// Purpose   : replace the content of textarea with new text s
// ######################################################################
void text::SetText(const char *s)
{
  if(!s || !*s)
    Clear();
  else
      XmTextSetString(w, (char*)s);
}

// ######################################################################
// Return    : void
// Parameters: s - pointer to text
// Purpose   : add text at the end of textarea
// ######################################################################
text &text::operator+=(const char *s) 
{
  if(XmTextGetLastPosition(w)>0)
      XmTextInsert(w, XmTextGetLastPosition(w), (char*)s);
  else
    SetText(s);

  return *this;
}

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : clear textarea
// ######################################################################
void text::Clear(void) 
{
  XmTextSetString(w, "");
}

// ######################################################################
// Return    : char * - pointer to textarea
// Parameters: void
// Purpose   : return the content of the textarea
// ######################################################################
const char *text::GetText()
{
  return XmTextGetString(w);
}

// ######################################################################
// Return    : void
// Parameters: pos - the position to show the text from
// Purpose   : show the text starting from a given position
// ######################################################################
void text::Show_Position(int pos)
{
  XmTextShowPosition(w, pos);
}

// constructor
text::text()
{
  done=0;
  prevsearch[0]='\0';
  prevpos=-1;
}

// Search and mark text matching the search string
int text::Search_and_show(const char *searchstr, bool case_sensitive)
{
  XmTextPosition oldpos=0, newpos;
  int pos=0, len=strlen(searchstr);
  const char *txt=GetText();
  bool posfound=False, nextfound=False;
  int numfound=0;
  int totallength=strlen(GetText());

  if((case_sensitive && strcmp(prevsearch, searchstr)) ||
     (!case_sensitive && strcasecmp(prevsearch, searchstr)))
    {
      XmTextSetHighlight(w, 0, totallength, XmHIGHLIGHT_NORMAL);
      prevpos=-1;
    }

  strcpy(prevsearch, searchstr);

  if(case_sensitive)
      while(XmTextFindString(w, oldpos, (char*)searchstr, XmTEXT_FORWARD, &newpos))
      {
	XmTextSetHighlight(w, newpos, newpos+len, 
			   XmHIGHLIGHT_SELECTED);
	oldpos=newpos+1;
	numfound++;

	if(prevpos<0 || (posfound && !nextfound))
	  {
	    Show_Position(newpos);
	    prevpos=newpos;
	    nextfound=True;
	  }
	else if(!posfound && prevpos>=0 && prevpos==newpos)
	  posfound=True;
      }
  else
    while(txt[pos])
      {
	if(!strncasecmp(txt+pos, searchstr, len))
	  {
	    XmTextSetHighlight(w, (XmTextPosition) pos, 
			       (XmTextPosition) (pos+len), 
			       XmHIGHLIGHT_SELECTED);
	    
	    numfound++;
	
	    if(prevpos<0 || (posfound && !nextfound))
	      {
		Show_Position(pos);
		prevpos=pos;
		nextfound=True;
	      }
	    else if(!posfound && ((prevpos>=0 && prevpos==pos) ||
				  prevpos<0))
	      posfound=True;
	  }
	pos++;
      }

  if(!nextfound)
    {
      Beep(1);
      prevpos=-1;
    }

  return numfound;
}



// ********************************************
// 
//          FUNCTIONAL_TEXT
//
// Methods surrounding a text filed, for 
// printing, changing printer, emailing and
// writing to file.
//
// ********************************************

void text_printb::Create(widget parent, const char *txt, functional_text *ipt)
{
  build(parent,txt);
  pt=ipt;
}

void text_printb::pushed(void)
{
  pt->doprint();
}

 
void text_chprinterb::Create(widget parent, const char *txt, functional_text *ipt)
{
  build(parent,txt);
  pt=ipt;
}

void text_chprinterb::pushed(void)
{
  pt->start_chprinter();
}

void text_emailb::Create(widget parent, const char *txt, functional_text *ipt)
{
  build(parent,txt);
  pt=ipt;
}

void text_emailb::pushed(void)
{
  pt->startemail();
}

void text_saveb::Create(widget parent, const char *txt, functional_text *ipt)
{
  build(parent,txt);
  pt=ipt;
}

void text_saveb::pushed(void)
{
  pt->startsavefile();
}

void text_printershell::create(functional_text *ipt)
{
  Create();
  pt=ipt;
}

void text_printershell::ok_pushed(const char *newprinter)
{
  pt->changeprinter(newprinter);
}




void functional_text::start_chprinter(void)
{
  prsh.create(this);
}

void functional_text::changeprinter(const char *newprinter)
{
  printlab.labelString(newprinter);
  setenv("PRINTER", newprinter, 1);
}

functional_text::functional_text()
{
  printb_built = chprintb_built = printlab_built = saveb_built = 
    emailb_built = False;
  email_window=new email();
}

functional_text::~functional_text()
{
  delete email_window;
}

void functional_text::build_printb(widget parent, const char *txt)
{
  printb.Create(parent, txt ? txt : 
		WHAT((char *) "Skriv ut tekst", (char *) "Print text"), this);
  printb.Background("blue");
  printb.Foreground("white");
}

void functional_text::build_chprintb(widget parent, const char *txt)
{
  chprinterb.Create(parent, txt ? txt : 
		    WHAT((char *) "Forandre skriver", 
			 (char *) "Change printer"), this);
}

void functional_text::build_printlab(widget parent)
{
  printlab.build(parent, getenv("PRINTER"));
  printlab.Background("white");
  printlab.Foreground("black");
}

void functional_text::build_emailb(widget parent, const char *txt)
{
  emailb.Create(parent, txt ? txt : 
		WHAT((char *) "Send som epost", (char *) "Send as email"), 
		this);
  emailb.Background("green");
  emailb.Foreground("black");
}

void functional_text::build_saveb(widget parent, const char *txt)
{
  saveb.Create(parent, txt ? txt : 
	       WHAT((char *) "Lagre p� fil", (char *) "Sav on file"), this);
  saveb.Background("green");
  saveb.Foreground("black");
}


void functional_text::doprint(void)
{
  FILE *p=popen("lpr", "w");
  if(!p)
    {
      err.build(*this, WHAT((char *) "Eksekveringsfeil", 
			    (char *) "Execution error"),
		WHAT((char *) "Klarte ikke � �pne pipe til lpr",
		     (char *) "Couldn't open pipe to lpr"));
      return;
    }

  fprintf(p, "%s\n", GetText());
  
  pclose(p);
  
  char mess_str[1000];
  sprintf(mess_str, WHAT((char *) "Teksten er blitt sendt til skriveren "
			 "\"%s\"", 
			 (char *) "The text has been sent to the printer "
			 "\"%s\""), getenv("PRINTER"));
  mess.build(mainwin::toplevel, 
	     WHAT((char *) "Melding", (char *) "Message"), mess_str);
}

void functional_text::startemail(void)
{
  email_window->Create("", "", GetText());
}

void functional_text::startsavefile(void)
{
  fsel.create(GetText());
}



#ifdef MAIN

void main(int argc, char **argv)
{
  mainwin mn("functional_text-test", argc, argv);
  vrow v1;
  hrow h1;
  functional_text ft;
  exitbutton exitb;
  
  v1.build(mn);
  ft.build(v1);
  
  char buf[1000];
  while(fgets(buf, 1000-1, stdin))
    ft += buf;
    
  h1.build(v1);
  exitb.Create(h1);
  ft.build_printb(h1);
  ft.build_chprintb(h1);
  ft.build_printlab(h1);
  ft.build_emailb(h1);
  ft.build_saveb(h1);
  
  mn.Run();
}

#endif // MAIN
