#include <hydrasub/hydragui/show_tables.H>

void show_table_sortbutton::Create(widget parent, const char *txt, 
				   int number_, show_table *ipt)
{
  pt=ipt;
  number=number_;
  build(parent,txt);
}

void show_table_sortbutton::pushed(void)
{
  pt->sort_column(number);
}

void show_table_button::Create(widget parent, const char *txt, 
			       SHOW_TABLE_ACTION type_, show_table *ipt)
{
  pt=ipt;
  type=type_;
  build(parent,txt);
}

void show_table_button::pushed(void)
{
  pt->take_action(type);
}


void show_table::update_table(void)
{
  if(!tab)
    return;

  working=1;
  Clear();

  if(tab->get_columns()==0)
    {
      working=0;
      return;
    }
  
  int active=tab->get_column_number("active");

  for(int i=0;i<tab->get_rows();i++)
    {
      char str[1000]="";

      sprintf(str,"%3d", i+1);
      
      for(int j=0;j<tab->get_columns();j++)
	if(j!=active)
	  {
	    strcpy(str+strlen(str), " ");
	    
	    switch(tab->get_column_type(j))
	      {
	      case TABLE_DATETIME:
		{
		  DateTime dt=tab->get_cell_datetime(j,i);
		  if(dt!=NoDateTime)
		    sprintf(str+strlen(str), "%02d/%02d-%04d %02d:%02d",
			    dt.getDay(), dt.getMonth(), dt.getYear(),
			    dt.getHour(), dt.getMinute());
		  else
		    sprintf(str+strlen(str), "%16s","---");
		  break;
		}
	      case TABLE_INT: 
		if(tab->get_cell_int(j,i)!=(int) MISSING_VALUE)
		  sprintf(str+strlen(str), "%8d", tab->get_cell_int(j,i));
		else
		  sprintf(str+strlen(str), "%8s","---");
		break;
	      case TABLE_DOUBLE:
		if(tab->get_cell_double(j,i)!=MISSING_VALUE &&
		   tab->get_cell_double(j,i)!=-9999.0)
		  sprintf(str+strlen(str), "%12.4g", 
			  tab->get_cell_double(j,i));
		else
		  sprintf(str+strlen(str), "%12s","---");
		break;
	      case TABLE_CHAR:
		if(tab->get_cell_char(j,i)!='\0')
		  sprintf(str+strlen(str), "%c", 
			  tab->get_cell_char(j,i));
		else
		  sprintf(str+strlen(str), "%c",'-');
		break;
	      case TABLE_STRING:
		if(*tab->get_cell_string(j,i)!='\0')
		  {
		    char buff[30];
		    shorten_name(buff, tab->get_cell_string(j,i), 25);
		    sprintf(str+strlen(str), "%25s", buff);
		  }
		else
		  sprintf(str+strlen(str), "%25s","---");
		break;
	      default:
		break;
	      }
	  }
	    
      Insert(str);
      if(active>=0)
	{
	  if(tab->get_cell_int(active,i))
	    Mark(NoInList());	    
	} 
    }

  working=0;
  updated();
}

void show_table::remove_selected(void)
{
  working=1;

  int active=tab->get_column_number("active");
  if(active<0)
    {
	std::cerr << "Program error - "
	"no active column in show_tabl::remove_selected" << std::endl;
      working=0;
      return;
    }
  
  for(int i=tab->get_rows()-1;i>=0;i--)
    if(tab->get_cell_int(active,i))
      tab->remove_row(i);

  update_table();
}

void show_table::select_all(void)
{
  working=1;

  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::select_all" << std::endl;
      working=0;
      return;
    }

  MarkAll();
  for(int i=0;i<tab->get_rows();i++)
    tab->set_cell(active,i,1);

  working=0;

  updated();
}

void show_table::select_none(void)
{
  working=1;
  
  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::select_none" << std::endl;
      working=0;
      return;
    }

  RemoveMarks();
  for(int i=0;i<tab->get_rows();i++)
    tab->set_cell(active,i,0);

  working=0;

  updated();
}

void show_table::select_from_to(void)
{
  int startrow=startf.getdigit(), endrow=endf.getdigit();

  if(startrow<1)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Startrad < 1", (char *) "Start row < 1"));
      return;
    }

  if(endrow>NoInList())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Sluttrad > antall rader i listen", 
		     (char *) "End row > number of elements in the list"));
      return;
    }

  if(startrow>=endrow)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Startrad >= sluttrad", 
		     (char *) "Start row >= end row"));
      return;
    }

  select_none();

  working=1;
  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::select_from_to" << std::endl;
      working=0;
      return;
    }

  for(int i=startrow;i<=endrow;i++)
    {
      tab->set_cell(active,i-1,1);
      Mark(i);
    }
  working=0;

  updated();
}


void show_table::take_action(SHOW_TABLE_ACTION action)
{
  switch(action)
    {
    case SHOW_TABLE_MAKE_NEW_ROW:
      start_edit(NULL,NULL,0);
      break;
    case SHOW_TABLE_SELECT_ALL:
      select_all();
      break;
    case SHOW_TABLE_SELECT_NONE:
      select_none();
      break;
    case SHOW_TABLE_SELECT_FROMTO:
      select_from_to();
      break;
    case SHOW_TABLE_REM_SEL:
      remove_selected();
      break;
    case SHOW_TABLE_EDIT:
      {
	int firstsel=Selected();
	
	if(firstsel<0)
	  {
	    err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		      WHAT((char *) "Ingen rader valgt!", 
			   (char *) "No rows selected!"));
	    return;
	  }

	int rows=tab->get_rows(), *edit_pos=new int[rows];
	int active=tab->get_column_number("active");
	if(active<0)
	  {
	    std::cerr << "Program error - "
	      "no active column in show_table::take_action" << std::endl;
	    return;
	  }

	int k=0;
	for(int i=0;i<rows;i++)
	  if(tab->get_cell_int(active,i))
	    edit_pos[k++]=i;

	tablelist *selected=get_selected();
	start_edit(selected, edit_pos, rows);
	delete selected;
	break;
      }
    case SHOW_TABLE_CHANGE_MARKED:
      {
	int firstsel=Selected();
	
	if(firstsel<0)
	  {
	    err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		      WHAT((char *) "Ingen rader valgt!", 
			   (char *) "No rows selected!"));
	    return;
	  }
	
	int rows=tab->get_rows(), *change_pos=new int[rows];
	int active=tab->get_column_number("active");
	if(active<0)
	  {
	    std::cerr << "Program error - "
	      "no active column in show_table::take_action" << std::endl;
	    return;
	  }
	
	int k=0;
	for(int i=0;i<rows;i++)
	  if(tab->get_cell_int(active,i))
	    change_pos[k++]=i;
	
	tablelist *selected=get_selected();
	start_change_marked(selected, change_pos, rows);
	delete selected;
	break;
      }
    case SHOW_TABLE_EXTRA_1:
      extra_1_pushed();
      break;
    case SHOW_TABLE_EXTRA_2:
      extra_2_pushed();
      break;
    case SHOW_TABLE_MAKE_NEW_DONE:
      get_edit_window(true);
      editsh.Unmap();
      break;
    case SHOW_TABLE_EDIT_DONE:
      get_edit_window(false);
      editsh.Unmap();
      break;
    case SHOW_TABLE_CHANGE_MARKED_DONE:
      get_change_window();
      changesh.Unmap();
      break;
    case SHOW_TABLE_EDIT_CANCELLED:
      editsh.Unmap();
      break;
    case SHOW_TABLE_CHANGE_MARKED_CANCELLED:
      changesh.Unmap();
      break;
    default:
      err.build(*this, WHAT((char *) "Programfeil", (char *) "Program error"),
		WHAT((char *) "Ukjent handling", (char *) "Unknown action"));
      break;
    }
}

void show_table::sort_column(int number)
{
  tab->sort_by_column(number);
  update_table();
}

show_table::show_table()
{
  tab=NULL;
  sortbuttons=NULL;
  
  editv=NULL;
  editdig=NULL;
  editchar=NULL;
  editlab=NULL;
  editdt=NULL;
  ed_pos=NULL;
  num_ed=0;
  
  changeh=NULL;
  changetog=NULL;
  changelab=NULL;
  changedig=NULL;
  changechar=NULL;
  changedt=NULL;
  ch_pos=NULL;
  num_ch=0;
  
  working=0;
}

show_table::~show_table()
{
  if(tab)
    delete tab;
  tab=NULL;
  if(sortbuttons)
    delete [] sortbuttons;
  sortbuttons=NULL;
  
  if(editv)
    delete [] editv;
  editv=NULL;
  if(editlab)
    delete [] editlab;
  editlab=NULL;
  doubledelete(editdig, num_ed);
  editdig=NULL;
  doubledelete(editchar, num_ed);
  editchar=NULL;
  doubledelete(editdt, num_ed);
  editdt=NULL;  
  num_ed=0;

  if(changeh)
    delete [] changeh;
  changeh=NULL;
  if(changetog)
    delete [] changetog;
  changetog=NULL;
  if(changelab)
    delete [] changelab;
  changelab=NULL;
  if(changedt)
    delete [] changedt;
  changedt=NULL;
  if(changechar)
    delete [] changechar;
  changechar=NULL;
  if(changedig)
    delete [] changedig;
  changedig=NULL;
  num_ch=0;
  
  working=0;
}

void show_table::Create(widget parent, tablelist *table_, 
			const char *extra1, const char *extra2, 
			char const* const* alternate_buttontext)
{
  if(tab)
    delete tab;
  tab=new tablelist(table_);

  int i,k,active=tab->get_column_number("active");
  if(active<0)
    {
      tab->append_column(TABLE_INT, "active");
      active=tab->get_column_number("active");
    }

  if(active<0)
    {
      std::cerr << "Program error -  append failed in "
	"show_table::Create!" << std::endl;
      return;
    }
  for(i=0;i<tab->get_rows();i++)
    tab->set_cell(active,i,1);

  int ncol=tab->get_columns();

  sortbuttons=new show_table_sortbutton[ncol];

  h1.build(parent);
  v1.build(h1);
  h2.build(v1);

  char namebuff[50], namebuff2[50];

  lab2.build(h2,"   ");
  k=0;
  for(i=0;i<ncol;i++)
    if(i!=active)
      {
	switch(tab->get_column_type(i))
	  {
	  case TABLE_DATETIME:
	    shorten_name(namebuff,tab->get_column_name(i), 15, 1);
	    sprintf(namebuff2, "%15s", namebuff);
	    break;
	  case TABLE_INT:
	    shorten_name(namebuff,tab->get_column_name(i), 7 ,1);
	    sprintf(namebuff2, "%7s", namebuff);
	    break;
	  case TABLE_DOUBLE:
	    shorten_name(namebuff,tab->get_column_name(i), 11 ,1 );
	    sprintf(namebuff2, "%11s", namebuff);
	    break;
	  case TABLE_CHAR:
	    shorten_name(namebuff,tab->get_column_name(i), 2,1);
	    sprintf(namebuff2, "%2s", namebuff);
	    break;
	  case TABLE_STRING:
	    shorten_name(namebuff,tab->get_column_name(i), 25,1);
	    sprintf(namebuff2, "%25s", namebuff);
	    break;
	  default:
	    break;
	  }
	
	if(alternate_buttontext)
	  sortbuttons[k].Create(h2, alternate_buttontext[k], k, this);
	else
	  sortbuttons[k].Create(h2, namebuff2, k, this);

	k++;
      }
  lab3.build(h2, "  ");

  build(v1, 12, 1);
  update_table();

  v2.build(h1);
  selallb.Create(v2,WHAT((char *) "Velg alle", 
			 (char *) "Select all"), 
		 SHOW_TABLE_SELECT_ALL,this);
  selnoneb.Create(v2,WHAT((char *) "Velg ingen", 
			  (char *) "Select none"), 
		  SHOW_TABLE_SELECT_NONE,this);
  selfromtob.Create(v2,WHAT((char *) "Velg fra/til", 
			    (char *) "Select from/to"),
		    SHOW_TABLE_SELECT_FROMTO ,this);
  h3.build(v2);
  startf.build(h3,3,NULL);
  lab1.build(h3, "-");
  endf.build(h3,3,NULL);
  remselb.Create(v2,WHAT((char *) "Fjern", 
			 (char *) "Remove"),
		 SHOW_TABLE_REM_SEL ,this);
  make_newb.Create(v2, WHAT((char *) "Lag ny rad", 
			 (char *) "Make new row"),
		   SHOW_TABLE_MAKE_NEW_ROW, this);
  editb.Create(v2,WHAT((char *) "Editer", 
		       (char *) "Edit"), SHOW_TABLE_EDIT,this);
  changeb.Create(v2,WHAT((char *) "Forandre felt", 
		       (char *) "Change fields"), 
		 SHOW_TABLE_CHANGE_MARKED,this);
  if(extra1)
    extra1b.Create(v2,extra1, SHOW_TABLE_EXTRA_1,this);
  if(extra2)
    extra2b.Create(v2,extra2, SHOW_TABLE_EXTRA_2,this);

}

void show_table::Create(widget parent, attributes *att, 
			const char *extra1, const char *extra2, 
			char const* const* alternate_buttontext)
{
  tablelist listbuffer(att,NULL,0);
  Create(parent, &listbuffer, extra1, extra2, alternate_buttontext);
}

void show_table::insert_rows(int num_rows, table_row **new_rows)
{
  int i;
  for(i=0;i<num_rows;i++)
    {
      if(new_rows[i]->get_size()==(tab->get_columns()-1))
	{
	  new_rows[i]->append(TABLE_INT);
	  new_rows[i]->set(new_rows[i]->get_size()-1,1);
	}
      if(new_rows[i]->get_size()!=tab->get_columns())
	{
	  std::cerr << "Program error in show_table::insert_rows" << std::endl;
	  std::cerr << "columns in new_rows=" << 
	    new_rows[i]->get_size() << std::endl;
	  std::cerr << "columns in table=" << tab->get_columns() << std::endl;
	  exit(0);
	}

      tab->insert_row(tab->get_rows(), new_rows[i]);
    }

  update_table();
}

void show_table::insert_rows(tablelist *new_rows)
{
  int num_rows=new_rows->get_rows();
  insert_rows(num_rows,new_rows->get_all_rows());
}

void show_table::clear_rows(void)
{
  tab->clear();
  update_table();
}

void show_table::extra_1_pushed(void)
{
}

void show_table::extra_2_pushed(void)
{
}

void show_table::start_edit(tablelist *selected_elements, 
			    int *editing_positions, int total_rows)
{
  int i,j, newpoint=1;
  int active=tab->get_column_number("active");
  int nrow, ncol=tab->get_columns()-1;
  
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::start_edit" << std::endl;
      return;
    }
  
  
  doubledelete(editdig,num_ed);
  editdig=NULL;
  doubledelete(editchar,num_ed);
  editchar=NULL;
  doubledelete(editdt,num_ed);
  editdt=NULL;

  if(selected_elements && editing_positions && total_rows)
    {
      if(ed_pos)
	delete [] ed_pos;
      ed_pos=new int[total_rows];
      for(i=0;i<total_rows;i++)
	ed_pos[i]=editing_positions[i];
      num_ed=selected_elements->get_rows();
  
      newpoint=0;
    } 
  else
    num_ed=1;
  nrow=num_ed;
  
  if(editv)
    delete [] editv;
  editv=new vrow[ncol];
  if(editlab)
    delete [] editlab;
  editlab=new label[ncol];
  editdig=new honlydigit*[nrow];
  editchar=new hsensitive_textf*[nrow];
  editdt=new honlydatetime*[nrow];
  for(i=0;i<nrow;i++)
    {
      editdig[i]=new honlydigit[ncol];
      editchar[i]=new hsensitive_textf[ncol];
      editdt[i]=new honlydatetime[ncol];
    }
  
  editsh.build(*this, WHAT((char *) "Editering av m�linger", 
			   (char *) "Measurement editor"));
      
  editv1.build(editsh);
  editsc.build(editv1);
  editsc.Height(MINIM(800, (50+65*num_ed)));
  editsc.Width(800);
  editv2.build(editsc);
  edith1.build(editv2);
  
  int k=0;
  for(i=0;i<ncol;i++)
    if(i!=active)
      {
	editv[k].build(edith1);
	editlab[k].build(editv[k], 
			 tab->get_column_name(i));
	
	for(j=0;j<nrow;j++)
	  {
	    switch(tab->get_column_type(i))
	      {
	      case TABLE_DATETIME:
		editdt[j][k].build(editv[k], 16, "");
		if(selected_elements)
		  editdt[j][k].SetDateTime(selected_elements->
					   get_cell_datetime(i,j));
		else
		  editdt[j][k].SetDateTime(NoDateTime);
		break;
	      case TABLE_INT:
		editdig[j][k].build(editv[k], 8, "");
		if(selected_elements)
		  editdig[j][k].SetDigit(selected_elements->
					 get_cell_int(i,j));
		else
		  editdig[j][k].SetDigit(0);
		break;
	      case TABLE_DOUBLE:
		editdig[j][k].build(editv[k], 12, "");
		if(selected_elements)
		  editdig[j][k].SetDouble(selected_elements->
					  get_cell_double(i,j));
		else
		  editdig[j][k].SetDouble(0.0);
		break;
	      case TABLE_CHAR:
		{
		  char str[5];
		  editchar[j][k].build(editv[k], 2, "");
		  if(selected_elements)
		    {
		      str[0]= selected_elements->get_cell_char(i,j);
		      str[1]='\0';
		      editchar[j][k].SetText(str);
		    }
		  else
		    editchar[j][k].SetText("");
		  break;
		}
	      case TABLE_STRING:
		{
		  char str[30];
		  editchar[j][k].build(editv[k], 25, "");
		  if(selected_elements)
		    {
		      shorten_name(str,selected_elements->
				   get_cell_string(i,j),25);
		      editchar[j][k].SetText(str);
		    }
		  else
		    editchar[j][k].SetText("");
		  break;
		}
	      default:
		break;
	      }
	  }
	
	k++;
      }

  editpad.build(editv2,"  ");

  editsep1.build(editv1);
  edith1.build(editv1);
  if(!newpoint)
    edit_okb.Create(edith1,WHAT((char *) "OK", (char *) "OK"), 
		    SHOW_TABLE_EDIT_DONE, this);
  else
    edit_okb.Create(edith1,WHAT((char *) "OK", (char *) "OK"), 
		    SHOW_TABLE_MAKE_NEW_DONE, this);
  edit_okb.Background("green");
  edit_okb.Foreground("black");
  edit_cancelb.Create(edith1,WHAT((char *) "Avbryt", (char *) "Cancel"), 
		 SHOW_TABLE_EDIT_CANCELLED, this);
  edit_cancelb.Background("red");
  edit_cancelb.Foreground("white");

  editsh.Map();
}

void show_table::start_change_marked(tablelist *selected_elements, 
				     int *editing_positions, int total_rows)
{
  int i;
  int active=tab->get_column_number("active");
  int nrow, ncol=tab->get_columns()-1;
  
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::start_edit" << std::endl;
      return;
    }
  
  if(!(selected_elements && editing_positions && total_rows))
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen rader markert", 
		     (char *) "No rows marked"));
      return;
    }
  
  nrow=num_ch;
  
  if(ch_pos)
    delete [] ch_pos;
  ch_pos=new int[total_rows];
  for(i=0;i<total_rows;i++)
    ch_pos[i]=editing_positions[i];
  num_ch=selected_elements->get_rows();
  
  if(changeh)
    delete [] changeh;
  changeh=new hrow[ncol];
  if(changelab)
    delete [] changelab;
  changelab=new label[ncol];
  if(changetog)
    delete [] changetog;
  changetog=new toggle[ncol];
  if(changechar)
    delete [] changechar;
  changechar=new hsensitive_textf[ncol];
  if(changedig)
    delete [] changedig;
  changedig=new honlydigit[ncol];
  if(changedt)
    delete [] changedt;
  changedt=new honlydatetime[ncol];
  
  changesh.build(*this, WHAT((char *) "Forandring av markerte rader", 
			     (char *) "Changing of marked rows"));
      
  changev1.build(changesh);
  changesc.build(changev1);
  changesc.Height(700);
  changesc.Width(800);
  changev2.build(changesc);
  
  int k=0;
  for(i=0;i<ncol;i++)
    if(i!=active)
      {
	changeh[k].build(changev2);
	changetog[k].build(changeh[k],WHAT((char *) "Forandre:",
					   (char *) "Change:"));
	changelab[k].build(changeh[k], 
			   tab->get_column_name(i));
	
	switch(tab->get_column_type(i))
	  {
	  case TABLE_DATETIME:
	    changedt[k].build(changeh[k], 16, "");
	    changedt[k].SetDateTime(NoDateTime);
	    break;
	  case TABLE_INT:
	    changedig[k].build(changeh[k], 8, "");
	    changedig[k].SetDigit(0);
	    break;
	  case TABLE_DOUBLE:
	    changedig[k].build(changeh[k], 12, "");
	    changedig[k].SetDouble(0.0);
	    break;
	  case TABLE_CHAR:
	  case TABLE_STRING:
	    {
	      changechar[k].build(changeh[k], 2, "");
	      changechar[k].SetText("");
	      break;
	    }
	  default:
	    break;
	  }
	
	k++;
      }
  
  changepad.build(changev2,"  ");
  
  changesep1.build(changev1);
  changeh1.build(changev1);
  change_okb.Create(changeh1,WHAT((char *) "OK", (char *) "OK"), 
		    SHOW_TABLE_CHANGE_MARKED_DONE, this);
  change_okb.Background("green");
  change_okb.Foreground("black");
  change_cancelb.Create(changeh1,WHAT((char *) "Avbryt", (char *) "Cancel"), 
		 SHOW_TABLE_CHANGE_MARKED_CANCELLED, this);
  change_cancelb.Background("red");
  change_cancelb.Foreground("white");
  
  changesh.Map();
}

tablelist *show_table::get_selected(void)
{
  if(!tab)
    return NULL;

  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::start_edit" << std::endl;
      return NULL;
    }

  int *activated=tab->get_column_int(active);
  tablelist *selected=tab->get_selection(activated);

  delete [] activated;

  return selected;
}

tablelist *show_table::get_all(void)
{
  return tab;
}

int show_table::get_rows(void)
{
  return tab->get_rows();
}

int show_table::get_columns(void)
{
  int col=tab->get_columns();
  int active=tab->get_column_number("active");

  if(active>=0)
    col--;

  return col;
}

int show_table::get_rows_selected(void)
{
  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::start_edit" << std::endl;
      return 0;
    }

  int *activated=tab->get_column_int(active);
  int i,num_active=0;
  for(i=0;i<get_rows();i++)
    if(activated[i])
      num_active++;

  delete  [] activated;

  return num_active;
}



void show_table::get_edit_window(bool new_points)
{
  int i,j=0;
  
  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::select_from_to" << std::endl;
      return;
    }
  
  if(new_points)
    {
      ed_pos=new int[num_ed];
      for(i=0;i<num_ed;i++)
	{
	  cell_content *newcont=new cell_content[tab->get_columns()];
	  for(j=0;j<tab->get_columns();j++)
	    newcont[j].cell_type=tab->get_column_type(j);
	  table_row newrow(tab->get_columns(),newcont);
	  
	  ed_pos[i] = tab->get_rows();
	  tab->insert_row(tab->get_rows(), &newrow);
	}
    }

  for(i=0;i<num_ed;i++)
    {
      int k=0;
      for(j=0;j<tab->get_columns();j++)
	if(j!=active)
	  {
	    switch(tab->get_column_type(j))
	      {
	      case TABLE_DATETIME:
		if(new_points || editdt[i][k].is_dirty())
		  {
		    int status;
		    DateTime dt=editdt[i][k].getdatetime(&status);

		    tab->set_cell(j, ed_pos[i], dt);
		  }
		break;
	      case TABLE_INT:
		if(new_points || editdig[i][k].is_dirty())
		  tab->set_cell(j, ed_pos[i], 
				editdig[i][k].getdigit((int)MISSING_VALUE));
		break;
	      case TABLE_DOUBLE:
		if(new_points || editdig[i][k].is_dirty())
		  tab->set_cell(j, ed_pos[i], 
				editdig[i][k].getdouble(MISSING_VALUE));
		break;
	      case TABLE_CHAR:
		tab->set_cell(j, ed_pos[i], *editchar[i][k]());
		break;
	      case TABLE_STRING:
		tab->set_cell(j, ed_pos[i], editchar[i][k]());
		break;
	      default:
		break;
	      }
	   
	    k++;
	  }
    }
  
  update_table();
}

void show_table::get_change_window(void)
{
  int i,j=0;
  int ncol=tab->get_columns()-1;

  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::select_from_to" << std::endl;
      return;
    }
  
  if(num_ch==0)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen rader markert!", 
		     (char *) "No rows marked!"));
      return;
    }

  int num_col_changed=0,k=0;
  for(i=0;i<ncol;i++)
    if(i!=active)
      {
	if(changetog[k]())
	  num_col_changed++;
	k++;
      }
  
  if(num_col_changed==0)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen kolonner er satt til � forandres!", 
		     (char *) "No columns are set to be changed!"));
      return;
    }
  
  for(i=0;i<num_ch;i++)
    {
      int k=0;
      for(j=0;j<tab->get_columns();j++)
	if(j!=active)
	  {
	    if(changetog[k]())
	      {
		switch(tab->get_column_type(j))
		  {
		  case TABLE_DATETIME:
		    {
		      int status;
		      DateTime dt=changedt[k].getdatetime(&status);
		      
		      tab->set_cell(j, ch_pos[i], dt);
		      break;
		    }
		  case TABLE_INT:
		    tab->set_cell(j, ch_pos[i], 
				  changedig[k].getdigit((int)MISSING_VALUE));
		    break;
		  case TABLE_DOUBLE:
		    tab->set_cell(j, ch_pos[i], 
				  changedig[k].getdouble(MISSING_VALUE));
		    break;
		  case TABLE_CHAR:
		    tab->set_cell(j, ch_pos[i], changechar[k]());
		    break;
		  case TABLE_STRING:
		    tab->set_cell(j, ch_pos[i], changechar[k]());
		    break;
		  default:
		    break;
		  }
	      }
	   
	    k++;
	  }
    }
  
  update_table();
}

void show_table::updated(void)
{
}

void show_table::OneHit(int pos, const char * /* item */)
{
  if(working)
    return;

  int *selected;

  Selected(&selected);
  
  int active=tab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error - "
	"no active column in show_table::OneHit" << std::endl;
      return;
    }

  tab->set_cell(active,pos-1,!tab->get_cell_int(active,pos-1));

  updated();
}
