#include <hydrasub/hydragui/show_stagedischarge.H>
#include <hydrasub/hydrabase/stagedischarge.H>

#ifndef NVE        
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#else
#include <envirsub/system.H>
#endif // NVE

// *******************************************************
// show_sd_button
//
// Button class for this module
// *******************************************************

void show_sd_button::Create(widget parent, const char *txt, SSD_ACTION type_,
			    show_stagedischarge *ipt)
{
  build(parent, txt);
  type=type_;
  pt=ipt;
}

void show_sd_button::pushed(void)
{
  pt->io_action(type);
}


// *******************************************************
// show_sd_fileload
//
// Fileload class for this module
// *******************************************************

void ssd_fileload::Create(show_stagedischarge *ipt, bool opt_file_load)
{
  pt=ipt;
  opt_fileformat=opt_file_load;
  sh.build(*ipt, WHAT((char *) "Velg fil � hente fra", 
		      (char *) "Choose file to load"));
  v1.build(sh);
  if(opt_file_load)
    {
      char *items[]={WHAT((char *) "Tid-vannstand-vannf�ring", 
			  (char *) "Time-stage-discharge"),
		     WHAT((char *) "All informasjon (csv)", 
			  (char *) "All information (csv)") };
      opt_tog.hbuild(v1, items, 2, 0);
    }
  build(v1);
  sh.Map();
}

bool ssd_fileload::opt_file_format(void)
{
  if(!opt_fileformat)
    return False;
  else if(opt_tog()==0)
    return False;
  else
    return True;
}

void ssd_fileload::ok(const char *filename)
{
  sh.Unmap();
  pt->load_file(filename,0,opt_file_format());
}

void ssd_fileload::cancel(void)
{
  sh.Unmap();
}




// *******************************************************
// show_sd_filesave
//
// Filesave class for this module
// *******************************************************

void ssd_filesave::Create(show_stagedischarge *ipt,
			  bool opt_file_save)
{
  pt=ipt;
  opt_fileformat=opt_file_save;
  sh.build(*ipt, WHAT((char *) "Velg fil � lagre til", 
		      (char *) "Choose file to save to"));
  v1.build(sh);
  if(opt_file_save)
    {
      char *items[]={WHAT((char *) "Tid-vannstand-vannf�ring", 
			  (char *) "Time-stage-discharge"),
		     WHAT((char *) "All informasjon (csv)", 
			  (char *) "All information (csv)") };
      opt_tog.hbuild(v1, items, 2, 0);
    }
  build(v1);
  sh.Map();
}

bool ssd_filesave::opt_file_format(void)
{
  if(!opt_fileformat)
    return False;
  else if(opt_tog()==0)
    return False;
  else
    return True;
}

void ssd_filesave::ok(const char *filename)
{
  sh.Unmap();
  pt->save_file(filename,0,opt_file_format());
}

void ssd_filesave::cancel(void)
{
  sh.Unmap();
}




// *******************************************************
// show_stagedischarge
//
// Main class of this module. This is a show_table class
// specially designed ofr handling stage-discharge
// measurements and that has possibility of coupling to
// a graphical representation class, 
// show_stagedischarge_plot. 
// *******************************************************


void show_stagedischarge::do_plot(void)
{
  tablelist *seltab=get_selected();
  int i,h_col,q_col,numrows=seltab->get_rows();

  if(numrows<=0)
    {
      ssd_err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Ingen m�linger valgt!", 
			 (char *) "No measurements chosen!"));
      return;
    }

  h_col=seltab->get_column_number("stage");
  if(h_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::do_plot - "
	"no stage column!" << std::endl;
      return;
    }
  q_col=seltab->get_column_number("discharge");
  if(q_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::do_plot - "
	"no discharge column!" << std::endl;
      return;
    }
    
  char **axistitles=new char*[2];
  axistitles[0]=new char[10];
  strcpy(axistitles[0], "m�/s");
  axistitles[1]=new char[10];
  strcpy(axistitles[1], "m");
  char *linetitle=new char[100];
  strcpy(linetitle, WHAT((char *) "M�linger - vannf�ring mot vannstand",
			 (char *) "Measurements - discharge vs stage"));
  int axis=1;
  PLOTLINE_TYPE type=PLOTLINE_DOT;
  double *arg=new double[numrows], *val=new double[numrows];
  for(i=0;i<numrows;i++)
    {
      arg[i]=seltab->get_cell_double(q_col, i);
      val[i]=seltab->get_cell_double(h_col, i);
    }
  
  if(pl)
    delete pl;
  pl=new plot_module();

  pl->Create(&arg, &val, &numrows, &axis, &linetitle, 1, 
	     axistitles, 2, NULL, &type);

  delete [] arg;
  delete [] val;
  doubledelete(axistitles,2);
  delete [] linetitle;
}

void show_stagedischarge::io_action(SSD_ACTION action)
{
  switch(action)
    {
    case SSD_STARTLOADFILE:
      start_load_file();
      break;
    case SSD_STARTSAVEFILE:
      start_save_file();
      break;
    case SSD_PLOT:
      do_plot();
      break;
    case SSD_EXTRA3:
      extra3();
      break;
    case SSD_EXTRA4:
      extra4();
      break;
    default:
      std::cerr << "Program error in show_stagedischarge::io_action "
	"-  unknown option!" << std::endl;
      exit(0);
      break;
    }
}


show_stagedischarge::show_stagedischarge() : show_table()
{
  pl=NULL;
  plot_area=NULL;
  alttext=NULL;
  numalt=0;
}

show_stagedischarge::~show_stagedischarge()
{
  if(pl)
    delete pl;
  pl=NULL;
  
  if(alttext)
    doubledelete(alttext, numalt);
}
  
void show_stagedischarge::create(widget parent, const char *extra1, const char *extra2,
				 const char *extra3, const char *extra4,
				 char const* const* attribute_names, 
				 TABLE_CONTENT *attribute_content,
				 int num_attributes,
				 char const* const* alternate_text,
				 bool opt_file_formats)
  // extra1 and extra2 are for table operations
  // extra3 and extra 4 are for alternative fetching and saving
  // (i.e. database usage).
{
  opt_fileformats=opt_file_formats;

  ssd_h1.build(parent);
  ssd_v1.build(ssd_h1);
  loadfileb.Create(ssd_v1, WHAT((char *) "Hent fra fil", 
				(char *) "Fetch file"),
		   SSD_STARTLOADFILE, this);
  loadfileb.Background("green");
  loadfileb.Foreground("black");
  if(extra3)
    {
      extra3b.Create(ssd_v1, extra3, SSD_EXTRA3, this);
      extra3b.Background("green");
      extra3b.Foreground("black");
    }
  
  if(extra4)
    {
      extra4b.Create(ssd_v1, extra4, SSD_EXTRA4, this);
      extra4b.Background("green");
      extra4b.Foreground("black");
    }
  
  spaclab1.build(ssd_v1," ");
  
  plotb.Create(ssd_v1, WHAT((char *) "Plott valgte punkter", 
			    (char *) "Plot selected points"),
	       SSD_PLOT, this);
  
  spaclab2.build(ssd_v1, " ");
  
  savefileb.Create(ssd_v1, WHAT((char *) "Lagre i fil", 
				(char *) "Save in file"),
		   SSD_STARTSAVEFILE, this);
  savefileb.Background("yellow");
  savefileb.Foreground("black");

  alttext=NULL;
  numalt=0;
  attributes *att=NULL;
  if(!attribute_names || num_attributes<=0)
    {
      TABLE_CONTENT *content=new TABLE_CONTENT[4];
      char **att_names=new char*[4];
      alttext=new char*[4];
      numalt=4;
      int i;

      for(i=0;i<4;i++)
	{
	  att_names[i]=new char[100];
	  alttext[i]=new char[100];
	}

      strcpy(att_names[0], "time");
      strcpy(att_names[1], "stage");
      strcpy(att_names[2], "discharge");
      strcpy(att_names[3], "active");
      
      if(alternate_text)
	{
	  for(i=0;i<4;i++)
	    strcpy(alttext[i], alternate_text[i]);
	}
      else
	{
	  strcpy(alttext[0], WHAT((char *) "tid", (char *) "time"));
	  strcpy(alttext[1], WHAT((char *) "vannstand", (char *) "stage"));
	  strcpy(alttext[2], 
		 WHAT((char *) "vannf�ring", (char *) "discharge"));
	  strcpy(alttext[3], "active");
	}

      content[0]=TABLE_DATETIME;
      content[1]=TABLE_DOUBLE;
      content[2]=TABLE_DOUBLE;
      content[3]=TABLE_INT;
      
      att=new attributes(4, content, att_names);
      
      doubledelete(att_names,4);
      delete [] content;
    }
  else
    {
      att=new attributes(num_attributes, attribute_content, attribute_names);
      alttext=new char*[num_attributes];
      numalt=num_attributes;
      
      for(int i=0;i<num_attributes;i++)
	{
	  alttext[i]=new char[100];
	  if(alternate_text)
	    strcpy(alttext[i], alternate_text[i]);
	  else
	    strcpy(alttext[i], attribute_names[i]);
	}
    }
  
  Create(ssd_h1, att, extra1, extra2, alttext);
}

void show_stagedischarge::start_load_file(void)
{
  ssd_load.Create(this, opt_fileformats);
}

void show_stagedischarge::start_save_file(void)
{
  ssd_save.Create(this, opt_fileformats);
}

void show_stagedischarge::save_file(const char *filename, int, 
				    bool optional_file_format)
{
  tablelist *seltab=get_selected();
  int i,h_col,q_col,t_col,numrows=seltab->get_rows();
  
  if(numrows<=0)
    {
      ssd_err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		   WHAT((char *) "Ingen m�linger valgt!", 
			(char *) "No measurements chosen!"));
      return;
    }
  
  h_col=seltab->get_column_number("stage");
  if(h_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::save_file - "
	"no stage column!" << std::endl;
      return;
    }
  q_col=seltab->get_column_number("discharge");
  if(q_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::save_file - "
	"no discharge column!" << std::endl;
      return;
    }
  t_col=seltab->get_column_number("time");
  if(t_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::save_file - "
	"no time column!" << std::endl;
      return;
    } 

  if(optional_file_format)
    seltab->to_csv(filename);
  else
    {
      FILE *f=fopen(filename, "w");
      if(!f)
	{
	  ssd_err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
			WHAT((char *) "Klarte ikke � �pne fil for skriving", 
			     (char *) "Could not open file for writing!"));
	  return;
	}
      
      fprintf(f, "# User specified stage-discharge data\n");
      for(i=0;i<numrows;i++)
	fprintf(f, "%s %9.4f %9.4g\n", 
		seltab->get_cell_datetime(t_col, i).syCh(1),
		seltab->get_cell_double(h_col, i),
	    seltab->get_cell_double(q_col, i));
      fclose(f);
    }

  delete seltab;
}

void show_stagedischarge::load_file(const char *filename, int, 
				    bool optional_file_format)
{
  int len=0;
  char errmsg[1000];
  
  if(optional_file_format)
    {
      // read csv:
      clear_rows();
      if(!tab->from_csv(filename))
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Klarte ikke � lese filen!", 
			 (char *) "Couldn't read the file!"));
	  return;
	}
      
      update_table();
      updated();
      return;
    }
  
  StageDischarge *sd=get_sd_file(filename, &len, errmsg);
  
  if(!sd || len<=0)
    {
      ssd_err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		    errmsg);
      return;
    }

  tablelist *alltab=get_all();
  int h_col, q_col, t_col, active;
  h_col=alltab->get_column_number("stage");
  if(h_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::load_file - "
	"no stage column!" << std::endl;
      return;
    }
  q_col=alltab->get_column_number("discharge");
  if(q_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::load_file - "
	"no discharge column!" << std::endl;
      return;
    }
  t_col=alltab->get_column_number("time");
  if(t_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::load_file - "
	"no time column!" << std::endl;
      return;
    } 
  active=alltab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error in show_stagedischarge::load_file - "
	"no 'active' column!" << std::endl;
      return;
    }

  clear_rows();
  
  tablelist *orig=get_all();
  attributes *att=orig->get_attributes();
  table_row **new_rows=new table_row*[len];
  int i;

  DateTime now; now.now();
  now-=(len-1)*60;
  for(i=0;i<len;i++)
    {
      new_rows[i]=new table_row(att);
      if(sd[i].dt!=NoDateTime)
	new_rows[i]->set(t_col, sd[i].dt);
      else
	new_rows[i]->set(t_col, now);
      new_rows[i]->set(h_col, sd[i].h);
      new_rows[i]->set(q_col, sd[i].q);
      new_rows[i]->set(active, (int) 1);
      now+=60;
    }
  
  insert_rows(len, new_rows);
  
  updated();

  for(i=0;i<len;i++)
    delete new_rows[i];
  delete [] new_rows;
  delete [] sd;
}


void show_stagedischarge::extra3(void)
{
}

void show_stagedischarge::extra4(void)
{
}

void show_stagedischarge::connect_to_plot(show_stagedischarge_plot *newplot)
{
  plot_area=newplot;
}

void show_stagedischarge::deactivate(table_row *ptr)
{
  int index=-1;

  tablelist *alltab=get_all();

  for(int i=0;i<alltab->get_rows() && index<0;i++)
    if(ptr->is_equal(alltab->get_row(i)))
      index=i;
    
  if(index<0)
    {
      err.build(*this, WHAT((char *) "Programfeil", (char *) "Program error"),
		WHAT((char *) "Klarte ikke � finne punkt som skulle fjernes!",
		     (char *) "Couldn't find point to be removed!"));
      return;
    }

  int active=alltab->get_column_number("active");
  if(active<0)
    {
      std::cerr << "Program error in show_stagedischarge::deactivate - "
	"no 'active' column!" << std::endl;
      return;
    }

  alltab->set_cell(active, index, 0);
  update_table();
}

void show_stagedischarge::updated(void)
{
  if(plot_area)
    plot_area->list_changed();
}

int show_stagedischarge::num_data(void)
{
  return get_rows();
}

double *show_stagedischarge::get_stage(void)
{
  tablelist *seltab=get_selected();

  int h_col=seltab->get_column_number("stage");
  if(h_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::get_stage - "
	"no stage column!" << std::endl;
      return NULL;
    }

  double *stage=seltab->get_column_double(h_col);

  delete seltab;

  return stage;
}

double *show_stagedischarge::get_discharge(void)
{
  tablelist *seltab=get_selected();

  int q_col=seltab->get_column_number("discharge");
  if(q_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::get_discharge - "
	"no discharge column!" << std::endl;
      return NULL;
    }

  double *discharge=seltab->get_column_double(q_col);

  delete seltab;

  return discharge;
}

DateTime *show_stagedischarge::get_times(void)
{
  tablelist *seltab=get_selected();

  int t_col=seltab->get_column_number("time");
  if(t_col<0)
    {
      std::cerr << "Program error in show_stagedischarge::get_times - "
	"no time column!" << std::endl;
      return NULL;
    }

  DateTime *dt=seltab->get_column_datetime(t_col);

  delete seltab;

  return dt;
}

StageDischarge *show_stagedischarge::get_stagedischarge(void)
{
  int len=num_data();
  DateTime *dt=get_times();
  double *Q=get_discharge();
  double *stage=get_stage();

  StageDischarge *sd=new StageDischarge[len];
  for(int i=0;i<len;i++)
    {
      sd[i].dt=dt[i];
      sd[i].q=Q[i];
      sd[i].h=stage[i];
    }

  delete [] dt;
  delete [] Q;
  delete [] stage;
  
  return sd;
}

char **show_stagedischarge::get_altname(int *altlen)
{
  if(altlen)
    *altlen=numalt;
  return alttext;
}





// *******************************************************
// ssdplot_button 
//
// Button class for the show_stagedischarge_plot class.
// *******************************************************

void ssdplot_button::Create(widget parent, const char *txt,SSDPLOT_ACTION type,
			    show_stagedischarge_plot *ipt)
{
  build(parent,txt);
  pt=ipt;
  typ=type;
}

void ssdplot_button::pushed(void)
{
  pt->take_action(typ);
}



// **********************************************************
// SSDPLOT_MANUAL_OR_AUTO
// 
// Toggles between manual zoom and auto zoom
// **********************************************************

// Create sthe toggle button, sotring apointer to the main
// plotting module;
void ssdplot_manual_or_auto::Create(widget parent, 
				    show_stagedischarge_plot *ipt)
{
  active=false;
  char *toggleitems[]={WHAT((char *) "Automatisk", (char *) "Automatic"),
		       WHAT((char *)"Manuell", (char *) "Manual")};

  pt=ipt;
  hbuild(parent, toggleitems, 2, 0);
  active=true;
}

// Notifies the main plotting module that the toggle button
// has been pushed;
void ssdplot_manual_or_auto::pushed(const char *)
{
   if(active)
    {
      if((*this)()==0)
        pt->auto_set();
      else
        pt->manual_set();
    }
}

// Deactivate the toggle button;
void ssdplot_manual_or_auto::deactivate()
{
  active=false;
}

// activate the toggle button;
void ssdplot_manual_or_auto::activate()
{
  active=true;
}





// ****************************************************
// show_stagedischarge_toggle
//
// toggle class for toggling 
// x=stage,y=discharge <=> x=discharge,y=stage
// ****************************************************

// Create: Creates the toggle button and stores a pointer
// back to the plot module:
void show_stagedischarge_toggle::Create(widget parent, const char *txt,
					bool start_state,
					show_stagedischarge_plot *ipt)
{
  pt=NULL;
  build(parent,txt);
  if(start_state)
    ToggleButtonOn();
  else
    ToggleButtonOff();
  pt=ipt;
}

// pushed: The toggle button has been pushed. Tell the main module.
void show_stagedischarge_toggle::pushed(bool state)
{
  if(pt)
    pt->set_stage_as_argument(state);
}





// *******************************************************
// show_stagedischarge_plot
//
// A graphical representation class for the 
// stage-discharge list, show_stagedischarge. 
// *******************************************************

// redraw the plotting area
void show_stagedischarge_plot::re_draw(void)
{
  int i=0;
  Clear(); // clear the plotting area

  // make the axis;
  Set_No_Dashes(2);
  SetFg("#ffffff");
  Line(10, sizey-10, sizex-10, sizey-10);
  Line(sizex-15, sizey-15, sizex-10, sizey-10);
  Line(sizex-15 , sizey-5, sizex-10, sizey-10);
  Line(10, sizey-10, 10, 10);
  Line(5, 15, 10, 10);
  Line(15, 15, 10, 10);
  Set_No_Dashes(1);
  
  // traverse the measurements;
  
  tablelist *sel=ssd->get_selected();
  if(!sel)
    return;

  int numsel=sel->get_rows();
  
  if(numsel<=0)
    return;

  int stage_row=sel->get_column_number("stage");
  int disch_row=sel->get_column_number("discharge");
  
  if(stage_row<0 || disch_row<0)
    {
      std::cerr << "Program error: Missing stage or discharge row in "
	"show_stagedischarge::re_draw!" << std::endl;
      exit(0);
    }

  int sortcolumn=sel->sorted_by_column();
  for(i=0;i<numsel;i++)
    {
      // fetch stage/discharge info and set the drawing type;
      double discharge=sel->get_cell_double(disch_row, i);
      double stage=sel->get_cell_double(stage_row, i);
      
      if(sortcolumn<0 || i==0 || !sel->is_equal(i-1,i,sortcolumn))
	find_color(i); // fetch the color index
      
      // Draw the measurement;
      if(stage_arg)
	Point(get_x_from_stage(stage), get_y_from_discharge(discharge),
	      DRAW_POINT_CIRCLE);
      else
	Point(get_x_from_discharge(discharge), get_y_from_stage(stage),
	      DRAW_POINT_CIRCLE);
    }
  
  // make ready to draw additional info;
  static char plotline_style[]={3,3};
  Set_Dashes(plotline_style,2,2);
  SetFg("#ffffff");
  //load_softfonts();

  // if minimal stage has been given;
  if(min_stage!=MISSING_VALUE)
    {
      if(stage_arg)
	{
	  if(get_x_from_stage(min_stage)>=0 &&
	     get_x_from_stage(min_stage)<sizex)
	    {
	      // make a label;
	      char mintext[100];
	      sprintf(mintext, WHAT((char *) "tidsserie-minimum=%5.1f", 
				    (char *) "timeserie minimum=%5.1f"), min_stage);
	      
	      // make a labelled line representing the minimal stage value;
	      Line(get_x_from_stage(min_stage), 0, get_x_from_stage(min_stage), sizey);
	      //soft_text(mintext, 
	      //	get_x_from_stage(min_stage), (int) (sizey-210), 0.0, 15);
	    }
	}
      else
	{
	  if(get_y_from_stage(min_stage)>=0 &&
	     get_y_from_stage(min_stage)<sizey)
	    {
	      // make a label;
	      char mintext[100];
	      sprintf(mintext, WHAT((char *) "tidsserie-minimum=%5.1f", 
				    (char *) "timeserie minimum=%5.1f"), min_stage);
	      
	      // make a labelled line representing the minimal stage value;
	      Line(0, get_y_from_stage(min_stage), sizex, get_y_from_stage(min_stage));
	      //soft_text(mintext, (int) (sizex-210), 
	      //	get_y_from_stage(min_stage), 0.0, 15);
	    }
	}
    }

  // if maximal stage has been given;
  if(max_stage!=MISSING_VALUE)
    {
      if(stage_arg)
	{
	  if(get_x_from_stage(max_stage)>=0 &&
	     get_x_from_stage(max_stage)<sizex)
	    {
	      // make a label;
	      char maxtext[100];
	      sprintf(maxtext, WHAT((char *) "tidsserie-maksimum=%5.1f", 
				    (char *) "timeserie maximum=%5.1f"), max_stage);
	      
	      // make a labelled line representing the maximal stage value;
	      Line(get_x_from_stage(max_stage), 0, get_x_from_stage(max_stage), sizey);
	      //soft_text(maxtext, 
	      //	get_x_from_stage(max_stage), (int) (sizey-210), 0.0, 15);
	    }
	}
      else
	{
	  if(get_y_from_stage(max_stage)>=0 &&
	     get_y_from_stage(max_stage)<sizey)
	    {
	      // make a label;
	      char maxtext[100];
	      sprintf(maxtext, WHAT((char *) "tidsserie-maksimum=%5.1f", 
				    (char *) "timeserie maximum=%5.1f"), max_stage);
	      
	      // make a labelled line representing the maximal stage value;
	      Line(0, get_y_from_stage(max_stage), sizex, get_y_from_stage(max_stage));
	      //soft_text(maxtext, (int) (sizex-210), 
	      //	get_y_from_stage(max_stage), 0.0, 15);
	    }
	}
    }

  // traverse the rating curve segments (if given);
  if(extra_curve)
    {
      int numseg=extra_curve->get_num_seg();
      // traverse the segment limits;
      for(i=0;i<numseg;i++)
	{
	  double hmax=i<(numseg-1) ? extra_curve->get_hs(i) : 
	    extra_curve->get_h_max();
	 
	  if(stage_arg)
	    {
	      double x=get_x_from_stage(hmax);
	      
	      // draw a line representing the segment limit; 
	      if(x>=0 && x<sizex)
		Line(x, 0, x, sizey);
	    }
	  else
	    {
	      double y=get_y_from_stage(hmax);
	      
	      // draw a line representing the segment limit; 
	      if(y>=0 && y<sizey)
		Line(0, y, sizex, y);
	    }
	}

      // traverse the segments;
      Set_No_Dashes(2);
      for(i=0;i<numseg;i++)
	{
	  double hmin=extra_curve->get_h_min();
	  double hmax=extra_curve->get_h_max();

	  // traverse the relevant stage values in the segment;
	  for(double stage=hmin+0.001;stage<=hmax;stage+=0.001)
	    {
	      if(stage_arg)
		{
		  // fetch coordinates for plotting this part of the curve;
		  int y1=get_y_from_discharge(extra_curve->
					      get_discharge(stage-0.001));
		  int x1=get_x_from_stage(stage-0.001);
		  int y2=get_y_from_discharge(extra_curve->get_discharge(stage));
		  int x2=get_x_from_stage(stage);
		  
		  // plot this part of the curve segment;
		  if(x1>=0 && x1<=sizex && x2>=0 && x2<=sizex &&
		     y1>=0 && y1<=sizey && y2>=0 && y2<=sizey)
		    Line(x1,y1,x2,y2);
		}
	      else
		{
		  // fetch coordinates for plotting this part of the curve;
		  int x1=get_x_from_discharge(extra_curve->
					      get_discharge(stage-0.001));
		  int y1=get_y_from_stage(stage-0.001);
		  int x2=get_x_from_discharge(extra_curve->get_discharge(stage));
		  int y2=get_y_from_stage(stage);
		  
		  // plot this part of the curve segment;
		  if(x1>=0 && x1<=sizex && x2>=0 && x2<=sizex &&
		     y1>=0 && y1<=sizey && y2>=0 && y2<=sizey)
		    Line(x1,y1,x2,y2);
		}
	    }
	}
    }
}

// finding the color for a given item by telling the index number;
void show_stagedischarge_plot::find_color(int item_number)
{
  int numactive=ssd->get_rows_selected();

  if(numactive==0)
    return;
 
  // find the color index;
  int index = 4 * item_number * 256 / numactive;
 
  // Make a color string according to the corlo index;
  if(index<256)
    sprintf(color, "#ff%02x00", index);
  else if(index<256*2)
    sprintf(color, "#%02xff00", 511-index);
  else if(index<256*3)
    sprintf(color, "#00ff%02x", index-512);
  else if(index<256*4)
    sprintf(color, "#00%02xff", 1023-index);
  else
    strcpy(color, "#0000ff");

  // Use this color;
  SetFg(color);
}

// search for a measurement graphically represented at a given coordinate;
table_row *show_stagedischarge_plot::find_point(int x, int y, int *index)
{
  tablelist *tab=ssd->get_all(); 
  double minsquaredist=10000;
  int i=0, ind=-1;
  int numrow=tab->get_rows();

  if(numrow<=0)
    return NULL;
  
  int active_row=tab->get_column_number("active");
  int stage_row=tab->get_column_number("stage");
  int disch_row=tab->get_column_number("discharge");

  if(stage_row<0 || disch_row<0 || active_row<0)
    {
      std::cerr << "Program error: Missing stage, discharge or active row in "
	"show_stagedischarge::re_draw!" << std::endl;
      exit(0);
    }

  for(i=0;i<numrow;i++)
    {
      // fetch stage/discharge info and set the drawing type;
      double discharge=tab->get_cell_double(disch_row, i);
      double stage=tab->get_cell_double(stage_row, i);
      int active=tab->get_cell_int(active_row,i);

      if(active)
	{
	  // fetch correpsonding plotting area coordinates;
	  int x2,y2;

	  if(stage_arg)
	    {
	      y2 = get_y_from_discharge(discharge);
	      x2 = get_x_from_stage(stage);
	    }
	  else
	    {
	      x2 = get_x_from_discharge(discharge);
	      y2 = get_y_from_stage(stage);
	    }

	  // find square distance to the given point
	  int squaredist=(x-x2)*(x-x2)+(y-y2)*(y-y2);
	  
	  // if this is less than the minimal square distance found so far;
	  if(squaredist < minsquaredist)
	    {
	      // update the minimal found distance;
	      minsquaredist = squaredist;
	      ind=i;
	    }
	}
    }
  
  table_row *ret=NULL;
  // if the minimal square distance is less than 81 (distance<9);
  if(ind>=0 && minsquaredist<81)
    // fetch the found measurement;
    ret=tab->get_row(ind);
  
  if(index)
    *index=ind;
  
  return ret; // return the found measurement corresponding
  // to the given coordinate
}

// methods for going from plotting area coordinates to stage/discharge
// coordinates;
double show_stagedischarge_plot::get_stage_from_y(int y)
{
  return s1 + (sizey - 10.0 - (double) y)/((double) sizey - 20.0)*(s2-s1);
}

double show_stagedischarge_plot::get_discharge_from_x(int x)
{
  return d1 + ((double) x - 10.0)/((double) sizex - 20.0)*(d2-d1);
}

int show_stagedischarge_plot::get_x_from_discharge(double discharge)
{
  return 10 + (int) ((discharge-d1)/(d2-d1)*((double) sizex - 20.0));
}

int show_stagedischarge_plot::get_y_from_stage(double stage)
{
  return int(sizey) - 10 - (int) ((stage-s1)/(s2-s1)*((double) sizey - 20.0));
}

double show_stagedischarge_plot::get_stage_from_x(int x)
{
  return s1 + ((double) x - 10.0)/((double) sizex - 20.0)*(s2-s1);
}

double show_stagedischarge_plot::get_discharge_from_y(int y)
{
  return d1 + (sizey - 10.0 - (double) y)/((double) sizey - 20.0)*(d2-d1);
}

int show_stagedischarge_plot::get_y_from_discharge(double discharge)
{
  return int(sizey) - 10 - (int) ((discharge-d1)/(d2-d1)*((double) sizey - 20.0));
}

int show_stagedischarge_plot::get_x_from_stage(double stage)
{
  return 10 + (int) ((stage-s1)/(s2-s1)*((double) sizex - 20.0));
}

void show_stagedischarge_plot::take_action(SSDPLOT_ACTION action)
{
  switch(action)
    {
    case SSDPLOT_EDIT_ZOOMOUT:
      zoomout();
      break;
    default:
      std::cerr << "Program error: unknown option in show_stagedischarge_plot"
	"::take_action!" << std::endl;
      exit(0);
      break;
    }
}

// Zooms out to the default level;
void show_stagedischarge_plot::zoomout(void)
{
  d1buffer=d1-0.5*ABSVAL((d2-d1));
  d2buffer=d2+0.5*ABSVAL((d2-d1));
  s1buffer=s1-0.5*ABSVAL((s2-s1));
  s2buffer=s2+0.5*ABSVAL((s2-s1));
                     
  d1=d1buffer;
  d2=d2buffer;
  s1=s1buffer;
  s2=s2buffer;
                     
  re_draw();
}

// Switches to auto zoom;
void show_stagedischarge_plot::auto_set(void)
{
  zoomoutb.InSensitive();
  list_changed();
}

// Switches to manual zoom;
void show_stagedischarge_plot::manual_set(void)
{
   zoomoutb.Sensitive();
}

// Update the module based on new measaurement info
void show_stagedischarge_plot::list_changed(void)
{
  bool first=True;

  tablelist *sel=ssd->get_selected();
  int i,numsel=sel->get_rows();

  if(numsel<=0)
    {
      re_draw();
      return;
    }

  int stage_row=sel->get_column_number("stage");
  int disch_row=sel->get_column_number("discharge");
  
  if(stage_row<0 || disch_row<0)
    {
      std::cerr << "Program error: Missing stage or discharge row in "
	"show_stagedischarge::re_draw!" << std::endl;
      exit(0);
    }

  // traverse the measurement
  if(autotog()!=1)
    {
      for(i=0;i<numsel;i++)
	{
	  // fetch stage/discharge info and set the drawing type;
	  double discharge=sel->get_cell_double(disch_row, i);
	  double stage=sel->get_cell_double(stage_row, i);
	  
	  // update the minimal/maximal stage/discharge values;
	  
	  if(first || discharge<d1)
	    d1=discharge;
	  
	  if(first || discharge>d2)
	    d2=discharge;
	  
	  if(first || stage<s1)
	    s1=stage;
	  
	  if(first || stage>s2)
	    s2=stage;
	  
	  first=False;
	}
      
      if(extra_curve)
	{
	  // fetch minimal/maximal discharge values;
	  double min_disc=extra_curve->get_discharge(min_stage);
	  double max_disc=extra_curve->get_discharge(max_stage);

	  // update minimal/maximal stage/discharge values 
	  // according to given min/max stage values;
	  if(min_stage!=MISSING_VALUE && min_stage<s1)
	    s1=min_stage;

	  if(min_stage!=MISSING_VALUE && min_disc!=MISSING_VALUE &&
	     min_disc<d1)
	    d1=min_disc;
	  
	  if(max_stage!=MISSING_VALUE && max_stage>s2)
	    s2=max_stage;
	  
	  if(max_stage!=MISSING_VALUE && max_disc!=MISSING_VALUE &&
	     max_disc>d2)
	    d2=max_disc;
	  
	  // traverse the segments;
	  for(i=0;i<extra_curve->get_num_seg();i++)
	    {	  
	      // update the minimal/maximal stage/discharge values;
	      double hmin=(i==0) ? extra_curve->get_h0(0) : 
		extra_curve->get_hs(i-1);  
	      double hmax=(i==(extra_curve->get_num_seg()-1)) ? 
		extra_curve->get_h_max() : extra_curve->get_hs(i);
	      double qmin=extra_curve->get_discharge(hmin);
	      double qmax=extra_curve->get_discharge(hmax);

	      if(hmin<s1)
		s1=hmin;
	      if(hmax>s2)
		s2=hmax;
	      if(qmin!=MISSING_VALUE && qmin<d1)
		d1=qmin;
	      if(qmax!=MISSING_VALUE && qmax>d2)
		d2=qmax;	  
	    }
	}

      // find the plotting area's stage/discharge borders;
      
      double ds=s2-s1, dd=d2-d1;
      
      s1 -= 0.05*ds;
      s2 += 0.05*ds;
      d1 -= 0.05*dd;
      d2 += 0.05*dd;
    }

  // redraw the plotting area;
  re_draw();
}


show_stagedischarge_plot::show_stagedischarge_plot()
{
  ssd=NULL;
  extra_curve=NULL;
  active_row=NULL;
  min_stage=max_stage=MISSING_VALUE;
}

show_stagedischarge_plot::~show_stagedischarge_plot()
{
  if(extra_curve)
    delete extra_curve;
}

// Create the plotting area;
void show_stagedischarge_plot::Create(widget parent, int width, int height, 
				      show_stagedischarge *ssd_, 
				      double timeserie_min_h,
				      double timeserie_max_h,
				      bool stage_as_argument)
{
  ssd=ssd_;
  stage_arg=stage_as_argument;

  min_stage=timeserie_min_h;
  max_stage=timeserie_max_h;

  active_row=NULL; // no actively edited measurement
  active_index=0;

  // set width and height;
  sizex=width;
  sizey=height;

  // build the surrounding widgets;
  v1.build(parent);
  h1.build(v1);
  lab.build(h1, WHAT((char *) "Zoomings-strategi:", 
		     (char *) "Zooming strategy:"));
  autotog.deactivate();
  autotog.Create(h1, this);
  zoomoutb.Create(h1, WHAT((char *) "Zoom ut", (char *) "Zoom out"),
		  SSDPLOT_EDIT_ZOOMOUT,this);
  zoomoutb.InSensitive();
  autotog.activate();
  
  // Create the toggle button for switching between 
  // x=stage,y=discharge and x=discharge,y=stage
  sdtog.Create(h1, WHAT((char *) "Vannstand langs x-aksen", 
			(char *) "Stage along the x axis"), 
	       stage_arg, this);
  

  // build the plotting area itself;
  build(v1, width, height, True);
}

// Show extra info in the form of rating curve and
// minimal/maximal time serie values;
void show_stagedischarge_plot::show_curve(ratingcurve_period *ratingperiod)
{
  if(extra_curve)
    delete extra_curve;
  extra_curve=new ratingcurve_period(ratingperiod);
  re_draw();
}


// Routines for handling user input in the plotting area;

// Handling left hand button;
void show_stagedischarge_plot::DoButton1(int x, int y)
{
  // fetch stage/discharge corresponding to the given plotting
  // area coordinate;
  double curr_stage, curr_discharge;
  
  if(stage_arg)
    {
      curr_stage = get_stage_from_x(x);
      curr_discharge = get_discharge_from_y(y);
    }
  else
    {
      curr_stage = get_stage_from_y(y);
      curr_discharge = get_discharge_from_x(x);
    }

  tablelist *sel=ssd->get_selected();
  int numsel=sel->get_rows();

  if(numsel<=0)
    return;

  int active_row=sel->get_column_number("active");
  int stage_row=sel->get_column_number("stage");
  int disch_row=sel->get_column_number("discharge");
  
  if(stage_row<0 || disch_row<0 || active_row<0)
    {
      std::cerr << "Program error: Missing stage, discharge or active row in "
	"show_stagedischarge::re_draw!" << std::endl;
      exit(0);
    }

  int i,numcol=sel->get_columns();
  cell_content *newcells=new cell_content[numcol];
  DateTime now; now.now();
  for(i=0;i<numcol;i++)
    {
      newcells[i].cell_type=sel->get_column_type(i);
      newcells[i].cell_double=MISSING_VALUE;
      newcells[i].cell_int=(int) -1;
      newcells[i].cell_datetime=now;
    }

  newcells[stage_row].cell_double=curr_stage;
  newcells[disch_row].cell_double=curr_discharge;
  newcells[active_row].cell_int=1;  
#ifndef NVE
  strcpy(newcells[8].cell_string, getpwuid(getuid())->pw_name);
#else
  strcpy(newcells[8].cell_string, hydraenvir::system::get_user_name().c_str());
#endif // NVE
  

  table_row *newrow=new table_row(numcol, newcells);
  tablelist *newtab=new tablelist(sel->get_attributes(), &newrow, 1);

  ssd->start_edit(newtab, NULL, 0);

  delete newtab;
  delete newrow;
  delete [] newcells;
}

// Handling middle button;
void show_stagedischarge_plot::DoButton2(int x, int y)
{
   // fetch the measurement corresponding to the coordinate;
  table_row *ptr=find_point(x,y);
  
  if(ptr && ssd) // if one was found
    ssd->deactivate(ptr); // deactivate the measurement
}

// Handling right hand button;
void show_stagedischarge_plot::DoButton3(int x, int y)
{
  table_row *curr_row=find_point(x,y); // fetch the measurement to be edited 
  // form the given coordinates

  if(curr_row) // if one was found...
    {
      int i, index=-1;
      tablelist *alltab=ssd->get_all();
      
      for(i=0;i<alltab->get_rows() && index<0;i++)
	if(curr_row->is_equal(alltab->get_row(i)))
	  index=i;

      if(index<0)
	{
	  err.build(*this, WHAT((char *) "Programfeil", 
				(char *) "Program error"),
		    WHAT((char *) "Klarte ikke � finne punkt som "
			 "skulle editeres!",
			 (char *) "Couldn't find point to be edited!"));
	  return;
	}

      tablelist *newtab=new tablelist(alltab->get_attributes(), &curr_row, 1);

      ssd->start_edit(newtab, &index, 1);

      delete newtab;
    }
  else // no corresponding measurement
    {
      // return the coordinates of the given point as 
      // a message dialog window;

      char str[100];
      double stage,discharge;

      if(stage_arg)
	{
	  stage = get_stage_from_x(x);
	  discharge = get_discharge_from_y(y);
	}
      else
	{
	  stage = get_stage_from_y(y);
	  discharge = get_discharge_from_x(x);
	}

      sprintf(str, WHAT((char *) "Vannstand:%f Vannf�ring=%f", 
			(char *) "Stage:%f Discharge=%f"),
	      stage, discharge);
      mess.build(mainwin::toplevel, WHAT((char *) "Koordinater:", 
					 (char *) "Coordinates:"), str);
    }
}

// Handling mouse drag;
void show_stagedischarge_plot::draw_motion_object(int x0, int y0, 
						  int x1, int y1)
{
  if(active_row) // if a measurement is under editing 
    {
      // draw the measurement on this new coordinate;
      Point(x0,y0,DRAW_POINT_CIRCLE);
      Point(x1,y1,DRAW_POINT_CIRCLE);
    }
  else if(autotog()==1) // manual zooming
    {
      // draw a rectangle;
      SetFg("yellow");
      Rectangle(x0,y0,x1,y1);
    }
}
        
// Handle drag start;
void show_stagedischarge_plot::motion_started(int newx, int newy)
{
  active_row=find_point(newx, newy, &active_index);

  // if none were found and we are in maunal zooming mode;
  if(!active_row && autotog()==1)
    {
      // update the buffer for stage/discharge;
      if(stage_arg)
	{
	  s1buffer=get_stage_from_x(newx);
	  d1buffer=get_discharge_from_y(newy);
	}
      else
	{
	  s1buffer=get_stage_from_y(newy);
	  d1buffer=get_discharge_from_x(newx);
	}
    }

  //draw_point(newx, newy
}

// Handle drag end;
void show_stagedischarge_plot::motion_dropped(int newx, int newy)
{
  if(active_row) // a measurement is under editing?
    {
      // fetch the new stage/discharge corresponding 
      // to the given coordinate;
      double stage,discharge;

      if(stage_arg)
	{
	  stage = get_stage_from_x(newx);
	  discharge = get_discharge_from_y(newy);
	}
      else
	{
	  stage = get_stage_from_y(newy);
	  discharge = get_discharge_from_x(newx);
	}

      tablelist *tab=ssd->get_all();

      int stage_row=tab->get_column_number("stage");
      int disch_row=tab->get_column_number("discharge");
  
      // Set the stage/discharge for the active measurement;
      active_row->set(stage_row, stage);
      active_row->set(disch_row, discharge);
      
      // update GUI;
      if(ssd)
	ssd->updated();
    }
  else
    {
      if(autotog()==1) // manual zooming mode
	{
	  // fetch new min and max stage/discharge;
	  if(stage_arg)
	    {
	      s2buffer=get_stage_from_x(newx);
	      d2buffer=get_discharge_from_y(newy);
	    }
	  else
	    {
	      s2buffer=get_stage_from_y(newy);
	      d2buffer=get_discharge_from_x(newx);
	    }

	  s1=MINIM(s1buffer, s2buffer);
	  s2=MAXIM(s1buffer, s2buffer);
	  d1=MINIM(d1buffer, d2buffer);
	  d2=MAXIM(d1buffer, d2buffer);

	  re_draw();
	}
      else if(motion_x0!=newx || motion_y0!=newy) // handle as button 1
	DoButton1(newx, newy);
    }
}

// Handle drawing the plotting area;
void show_stagedischarge_plot::expose()
{
  re_draw();
}                         

void show_stagedischarge_plot::set_stage_as_argument(bool stage_as_argument)
{
  stage_arg=stage_as_argument;
  re_draw();
}

bool show_stagedischarge_plot::stage_as_argument(void)
{
  return stage_arg;
}
