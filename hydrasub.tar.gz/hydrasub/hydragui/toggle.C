/*
 * $Id: toggle.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/toggle.C $
 */


#include <hydrasub/hydragui/widget.H>
#include <hydrasub/hydragui/toggle.H>
#include <hydrasub/hydragui/color.H>

#include <Xm/ToggleB.h>
#include <Xm/ToggleBG.h>


// ######################################################################
// Return    : void
// Parameters: parent - my Widget parent
//             title - the togglebuttons title
// Purpose   : builds a togglebutton with title set by title
// ######################################################################
void toggle::build(const Widget parent, const char *title) {
  // set the selectcolor to the togglebutton
  XmInitSetArg(XmNselectColor, motifsubcolors[CORAL1]);
  
  // create the togglebutton
  init(title, xmToggleButtonWidgetClass, parent);
  
  // register a callback procedure
  XtAddCallback(w, XmNvalueChangedCallback, 
		(XtCallbackProc)&toggle::pushCB,
		(XtPointer)this);
}

// ######################################################################
// Return    : void
// Parameters: parent - my parent Widget
//             title - the togglebuttons title
//             val - a value connected to this togglebutton
//             var - address to a variable
// Purpose   : when this togglebutton gain focus, we update variable 
//             var with value set by val
// ######################################################################
void toggle::build(const Widget parent, const char *title, int val, int &var) {
    value = val;
    variable = &var;
    XmInitSetArg(XmNselectColor, motifsubcolors[CORAL1]);
    init(title, xmToggleButtonWidgetClass, parent);

    XtAddCallback(w, XmNvalueChangedCallback, 
		  (XtCallbackProc)&toggle::updateCB,
		  (XtPointer)this);
}

// ######################################################################
// Return    : void
// Parameters: w - the togglebutton which called me
//             pt - connection with a toggle class
// Purpose   : callback routine for all toggleclass. calls the 
//             routine pushed() in object pt.
// ######################################################################
void toggle::pushCB(Widget  w, toggle *pt, XtPointer) {
    pt->pushed(XmToggleButtonGetState(w));
}

// ######################################################################
// Return    : void
// Parameters: w - the togglebutton which called me
//             pt - connection with a toggle class
// Purpose   : callback routine for all toggleclass. update variable var
//             with value value.
// ######################################################################
void toggle::updateCB(Widget  w, toggle *pt, XtPointer) {
  if(XmToggleButtonGetState(w))
    *(pt->variable) = pt->value;
}

// ######################################################################
// Return    : bool - true or false
// Parameters: void
// Purpose   : return the togglebuttons state
// ######################################################################
bool toggle::operator()() {
    return XmToggleButtonGetState(w);
}

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : turn this togglebutton on
// ######################################################################
void toggle::ToggleButtonOn() {
    XmToggleButtonSetState(w, True, True);
}

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : turn this togglebutton off
// ######################################################################
void toggle::ToggleButtonOff() {
    XmToggleButtonSetState(w, False, True);
}

void toggle::SetState(bool state)
{
  if(state)
    ToggleButtonOn();
  else
    ToggleButtonOff();
}

// ######################################################################
// Return    : void
// Parameters: label - a new label
// Purpose   : change this togglebuttons title
// ######################################################################
void toggle::SetLabel(const char *label)
{
    XmString xmstr = XmStringCreateSimple((char*)label);
    XtVaSetValues(w, XmNlabelString, xmstr, NULL);
    XmStringFree(xmstr);
}



// ######################################################################
// Parameters: void
// Purpose   : With this we can compose a complete horizontal or
//             vertical radiobox withh togglebuttons.
// ######################################################################
SelToggle::SelToggle() : t(NULL), len(0) 
{
  policy=XmHORIZONTAL;
} /* SelToggle */


// ######################################################################
// Purpose   : Clean after us
// ######################################################################
SelToggle::~SelToggle()
{
    if(t) 
      delete [] t; 
    t = NULL; 
} /* ~SelToggle */

// ######################################################################
// Return    : void
// Parameters: parent - my widget parent
//             items - a list of strings which will be used to build
//                     togglebuttons off.
//             ilen  - no of items
//             focus - the index of the togglebutton which be switch on
// Purpose   : Builds a horizontal radiobox with ilen togglebuttons
//             and set togglebutton with index focus to be switched on.
// ######################################################################
void SelToggle::hbuild(const Widget parent, char const* const* items, int ilen, int focus)
{
  len = ilen;
  policy=XmHORIZONTAL;
  build(parent);
  t = new stoggle[len];
  for(int i = 0; i < len; i++) 
    {
      t[i].pt = this;
      t[i].build(*this, items[i]);
    }
  if(focus>=0)
    t[focus].ToggleButtonOn();
} /* hbuild */

// ######################################################################
// Return    : void
// Parameters: parent - my widget parent
//             items - a list of strings which will be used to build
//                     togglebuttons off.
//             ilen  - no of items
//             focus - the index of the togglebutton which be switch on
// Purpose   : Builds a vertical radiobox with ilen togglebuttons
//             and set togglebutton with index focus to be switched on.
// ######################################################################
void SelToggle::vbuild(const Widget parent, char const* const* items, int ilen, int focus)
{
  len = ilen;
  policy=XmVERTICAL;
  build(parent);
  t = new stoggle[len];
  for(int i = 0; i < len; i++) 
    {
      t[i].pt = this;
      t[i].build(*this, items[i]);
    }
  if(focus>=0)
    t[focus].ToggleButtonOn();
} /* vbuild */

int SelToggle::direction(void) 
{
  return policy; 
}

// ######################################################################
// Return    : int - index of current togglebutton switch on, -1 none
// Parameters: void
// Purpose   : return the index of the togglebutton which is switched on
// ######################################################################
int SelToggle::operator()()
{
  for(int i = 0; i < len; i++)
    if(t[i]())
      return i;
  return -1;
} /* operator()() */

// ######################################################################
// Return    : void
// Parameters: newfocus - the togglebutton which should be the new one
//                        switchedon.
// Purpose   : Change focus among the togglebuyttons.
// ######################################################################
void SelToggle::SetFocus(const char *newfocus)
{
  for(int i = 0; i < len; i++)
    if(strcmp(XtName(t[i]), newfocus) == 0) 
      {
	t[i].ToggleButtonOn();
	break;
      }
} /* SetFocus */

void SelToggle::SetFocus(int newfocus)
{
  if(newfocus>=0 && newfocus<len)
    t[newfocus].ToggleButtonOn();
}

// ######################################################################
// Return    : void
// Parameters: deactivate - the togglebutton which should be deactivated
// Purpose   : Deactivate a toggle buttonc
// #####################################################################
void SelToggle::Deactivate(const char *deactivate)
{
  for(int i = 0; i < len; i++)
    if(strcmp(XtName(t[i]), deactivate) == 0) 
      {
	t[i].InSensitive();
	break;
      }
} /* Deactivate */

// ######################################################################
// Return    : void
// Parameters: activate - the togglebutton which should be activated
// Purpose   : Activate a toggle button
// ######################################################################
void SelToggle::Activate(const char *activate)
{
  for(int i = 0; i < len; i++)
    if(strcmp(XtName(t[i]), activate) == 0) 
      {
	t[i].Sensitive();
	break;
      }
} /* Deactivate */

// ######################################################################
// Return    : void
// Parameters: char * - the item choosen as a string
// Purpose   : Every time a toggle is on, this routine is called
// ######################################################################
void SelToggle::pushed(const char *)
{
} /* pushed */

// ######################################################################
// Return    : void
// Parameters: b - if True toggle is on
// Purpose   : Calls virtual pushed() in SelToggle everytime a toggel
//             is changed.
// ######################################################################
void SelToggle::stoggle::pushed(bool b)
{
    if(b) 
      pt->pushed(XtName(w));
} /* pushed */

#ifdef MAIN
#include <hydrasub/hydragui/mainwin.H>
#include <stream.h>

class st : public SelToggle {
public:
    void pushed(const char *item) { cerr << item << endl; };
};


main(int argc, char **argv) {
    mainwin m(argv[0], argc, argv);

    st s;
    char *str[] = { "a", "b", "c", "d" };
    s.hbuild(m, str, 4);
    
    m.Run();
};

#endif
