/*
 * $Id: mainwin.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/mainwin.C $
 */


#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/color.H>
#include <X11/cursorfont.h>

#ifdef NVE /* NVE-specific code */
#include <envirsub/path.H>
#endif // NVE

Widget mainwin::toplevel = NULL;
XtAppContext mainwin::app = NULL;

// **********************************************************************
// Setup everything so we cant start building a Motif application.
// **********************************************************************
mainwin::mainwin(const char *title, int &argc, char const* const*  argv)
{
  char defaults[500];

#ifdef NVE  
  sprintf(defaults, "XENVIRONMENT=%s", 
	  hydraenvir::path::etc("Xdefaults").c_str());
#else
  sprintf(defaults, "XENVIRONMENT=%s", XDEFAULTFILE);
#endif // NVE

  putenv(defaults);

  toplevel = XtVaAppInitialize(&app, argv[0],
			       NULL, 0,
			       &argc, 
			       (char**)argv, 
			       NULL, 
			       XmNtitle, (char*)title, 
			       NULL);

  // Query X-server for color definition
  SetGPGSColors(toplevel);
  InitColor(toplevel);
  Noborder();
}

// **********************************************************************
// Setup everything so we cant start building a Motif application.
// **********************************************************************
mainwin::mainwin(const char *title, int &argc, char const* const*  argv,bool iconify)
{
  char defaults[500];
  
#ifdef NVE
  sprintf(defaults, "XENVIRONMENT=%s", 
	hydraenvir::path::etc("Xdefaults").c_str());
#else
  sprintf(defaults, "XENVIRONMENT=%s", XDEFAULTFILE);
#endif // NVE

  putenv(defaults);

  if(iconify)
    toplevel = XtVaAppInitialize(&app, argv[0],
				 NULL, 0,
				 &argc, 
				 (char**)argv, 
				 NULL, 
				 XmNtitle, (char*)title, 
				 XmNiconic,True,
				 NULL);
  else
    toplevel = XtVaAppInitialize(&app, argv[0],
				 NULL, 0,
				 &argc, 
				 (char**)argv, 
				 NULL, 
				 XmNtitle, (char*)title, 
				 NULL);

  // Query X-server for color definition
  SetGPGSColors(toplevel);
  InitColor(toplevel);
  Noborder();
}

void mainwin::expose_all_widgets(void)
{
  for(int i=0;i<100;i++)
    XtAppProcessEvent(mainwin::app, XtIMAll);
}

// **********************************************************************
// This routine builds the application and starts the eventloop.
// **********************************************************************
void mainwin::Run(void)
{
  XtRealizeWidget(toplevel);
  XtAppMainLoop(app);
}

// **********************************************************************
// Change titlebar to whats set in title.
// **********************************************************************
void mainwin::NewTitle(char *title)
{
  XtVaSetValues(toplevel,
		XmNtitle, title, 
		NULL);
}
 
// **********************************************************************
// Noborder changes window apperance to decor_border, title, minimize
// **********************************************************************
void mainwin::Noborder(void)
{
  int decor; // To hold decoration bit pattern
  // decor changed to only border, title and minimize, 
  // instead of removing close.    
  decor = MWM_DECOR_BORDER | MWM_DECOR_TITLE | MWM_DECOR_MINIMIZE;
  XtVaSetValues(toplevel, XmNmwmDecorations, decor, NULL);  
}


void mainwin::activate_menu(void)
{
  int decor,functions; // To hold decoration bit pattern
  // decor changed to only border, title and minimize, instead of removing close.    
  decor = MWM_DECOR_BORDER | MWM_DECOR_TITLE | MWM_DECOR_MINIMIZE | MWM_DECOR_MENU;
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE; 
  XtVaSetValues(toplevel, XmNmwmDecorations, decor, NULL);  
  XtVaSetValues(toplevel, XmNmwmFunctions, functions, NULL);  
}


void mainwin::activate_resize(void)
{
  int functions; // To hold the bit pattern
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE | MWM_FUNC_RESIZE |
    MWM_FUNC_MAXIMIZE;
  XtVaSetValues(toplevel, XmNmwmFunctions, functions, NULL);  
}


void mainwin::deactivate_resize(void)
{
  int functions; // To hold the bit pattern
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE;
  XtVaSetValues(toplevel, XmNmwmFunctions, functions, NULL);  
}

// **********************************************************************
// Gives the width of the screen
// **********************************************************************

int mainwin::screenwidth(void)
{
    return WidthOfScreen(XtScreen(toplevel));
}


// **********************************************************************
// Gives the height of the screen
// **********************************************************************

int mainwin::screenheight(void)
{
    return HeightOfScreen(XtScreen(toplevel));
}


// ######################################################################
// Return    : int   1 is sensitive, 0 is not sensitive
// Parameters: void
// Purpose   : tell if if this widget is semsitive (grayed out)
// ######################################################################
int mainwin::IsSensitive(void)
{
    return XtIsSensitive(toplevel);
} /* IsSensitive */


// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget sensitive
// ######################################################################
void mainwin::Sensitive(void)
{
    XtSetSensitive(toplevel, True);
} /* Sensitive */


// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget insensitive (grayed out)
// ######################################################################
void mainwin::InSensitive(void)
{
    XtSetSensitive(toplevel, False);
} /* InSensitive */


// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget iconic
// ######################################################################
void mainwin::Iconify(void)
{
  XtVaSetValues(toplevel,
		XmNiconic, True, 
		NULL);
} /* Sensitive */


// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget less iconic
// ######################################################################
void mainwin::DeIconify(void)
{
    XtVaSetValues(toplevel,
		  XmNiconic, False, 
		  NULL);
} /* InSensitive */


#ifdef MAIN
main(int argc, char **argv) 
{
  mainwin m("Test av mainwin", argc, argv);
  m.Run();
}
#endif
