/*
 * $Id: header.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/header.C $
 */


#include <cstring>
#include <hydrasub/hydragui/header.H>
#include <hydrasub/hydrabase/divfunc.H>

void header::build(const Widget p,char *str)
{
  int len=strlen(str);
  char str2[100],str3[100],str4[100];

  space(str2,len);
  space(str3,30);
  space(str4,2);
  v1.build(p);
  h1.build(v1);
  v2.build(h1);
  h2.build(v2);
  l1.build(h2,str4);
  v3.build(h2);
  l2.build(v3,str);
  l2.Background("black");
  l2.Foreground("white");
  hs1.build(v3,SHADOW_ETCHED_IN_DASH);
  l3.build(v3,str2);
  l4.build(h2,str3);
  icon.build(h2),
  hs2.build(v1,SHADOW_ETCHED_IN_DASH);
}



void header::build(const Widget p,char *str,int width)
{
  int len=strlen(str);
  char str2[100],str3[100],str4[100];

  space(str2,len);
  space(str3,width);
  space(str4,3);
  v1.build(p);
  h1.build(v1);
  v2.build(h1);
  h2.build(v2);
  l1.build(h2,str4);
  v3.build(h2),
  l2.build(v3,str);
  l2.Background("black");
  l2.Foreground("white");
  hs1.build(v3,SHADOW_ETCHED_IN_DASH);
  l3.build(v3,str2);
  l4.build(h2,str3);
  icon.build(h2),
  hs2.build(v1,SHADOW_ETCHED_IN_DASH);
}

void header_lite::build(const Widget p,char *str,int width)
{
  int len=strlen(str);
  char str2[100],str3[100],str4[100];

  space(str2,len);
  space(str3,width);
  space(str4,3);
  v1.build(p);
  h2.build(v1);
  l1.build(h2,str4);
  v3.build(h2),
  l2.build(v3,str);
  l2.Background("black");
  l2.Foreground("white");
  hs1.build(v3,SHADOW_ETCHED_IN_DASH);
  l3.build(v3,str2);
  l4.build(h2,str3);
  icon.build(h2);
    //hs2.build(v1,SHADOW_ETCHED_IN_DASH);
}

