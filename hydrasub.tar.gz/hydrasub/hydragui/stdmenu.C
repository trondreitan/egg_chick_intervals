/*
 * $Id: stdmenu.C 1925 2011-04-05 11:36:24Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/stdmenu.C $
 */

#include <hydrasub/hydragui/stdmenu.H>
#include <hydrasub/hydragui/color.H>
#include <stdarg.h>

#include <Xm/CascadeB.h>
#include <Xm/RowColumn.h>
#include <Xm/SeparatoG.h>
#include <Xm/ToggleB.h>

#include <hydrasub/hydrabase/types.H>


// The available plot formats...
static const char *plotselection[2][5] = {{
    "Skjerm","Postscript-fil","Svart/hvitt","Farge","Spesifisert skriver"},{
	"Screen","Postscript-file","Black/White","Color","Specific printer"}
};

// The available table formats...
static const char *tableselection[2][8] = {{
    "Skjerm","Formatert","Uformatert","Hydark","Regneark","Vardat","Exdat","Skriver"},{
	"Screen","Formated","Unformated","Hydark","Spreadsheet","Vardat","Exdat","Printer"}
};

// Various header and pushbutton strings
static const char *filestr[2] = { "File", "File" };
static const char *plotstr[2] = { "Plott", "Plot" };
static const char *tablestr[2] = { "Tabell", "Table" };
static const char *quitstr[2] = { "Avslutt", "Quit" };
static const char *filechoicestr[2] = { "Fil - valg", "File - choice" };
static const char *plotchoicestr[2] = { "Valg av plottets utskrifts-format:", 
				 "Choice of plots printerformat: "};
static const char *printernamestr[2] = { "Skrivernavn: ", "Printername: "};
static const char *abortstr[2] = { "Avbryt", "Close" };
static const char *tablechoicestr[2] = { "Valg av tabellens utskrifts-format: ", 
				  "Choice of tables printerformat: "};

void filemenu::pushCB(Widget w, Menu *pt, XtPointer) {
    pt->pushed(XtName(w));
}      // Same as for Menu (see menu.H and menu.C).


// Menu with  automatic generation of the file
// pulldown element. This is just the code for 
// Menu::build with a little extra code...
void filemenu::build(const Widget parent, ...)
{
    va_list ap;
    char *s;
    int no = 0, n = 1;
    Widget c, p,pu;


    menubar::build(parent);

    // Counting no of CascadeMenus
    va_start(ap, parent);
    while((s = va_arg(ap, char *)) != NULL)
	if(strncmp(s, "STM:", 4) == 0) no++;

    va_end(ap);

    no++;
    pulld = new pulldown[no];
    cas = new cascade[no];
    
    pulld[0].build(w);  
    p = pulld[0];
    cas[0].build(w,*pulld, filestr[language]); // Builds the "file" element.
    
    
    pu=XtVaCreateManagedWidget (plotstr[language],
				xmPushButtonWidgetClass, p,
				XmNbackground, motifsubcolors[BISQUE3],
				NULL); 
    // Puts "plott" into the file menu.
    
    XtAddCallback(pu, XmNactivateCallback, 
		  (XtCallbackProc)&plotcall,
    (XtPointer)this);
    // Attaches the plotcall routine to the "plott" element. 
    
    pu=XtVaCreateManagedWidget (tablestr[language],
				xmPushButtonWidgetClass, p,
				XmNbackground, motifsubcolors[BISQUE3],
				NULL);
    // The same code for the "Tabell" element...
    
    XtAddCallback(pu, XmNactivateCallback, 
		  (XtCallbackProc)&tablecall,
    (XtPointer)this);
    
    // The same code for the "Avslutt" (quit) element...
    pu=XtVaCreateManagedWidget (quitstr[language],
				xmPushButtonWidgetClass, p,
				XmNbackground, motifsubcolors[BISQUE3],
				NULL);
    
    XtAddCallback(pu, XmNactivateCallback, 
		  (XtCallbackProc)&quitcall,
    (XtPointer)this);
    
    
    // Building the Menu
    va_start(ap, parent);
    while(((s = va_arg(ap, char *)) != NULL))
	if(strncmp(s, "STM:", 4) == 0) {
	    pulld[n].build(w);
	    p = pulld[n];
	    cas[n].build(w, p, s + 4);
	    c = cas[n];
	    n++;
	} else if(strncmp(s, "SEP", 3) == 0) {
	    XtVaCreateManagedWidget("separator",
				    xmSeparatorGadgetClass, p, NULL);
	} else if(strncmp(s, "T:", 2) == 0) {
	    Widget pu = 
		XtVaCreateManagedWidget (s + 2,
					 xmToggleButtonWidgetClass, p,
					 XmNselectColor, motifsubcolors[CORAL1],
					 XmNbackground, motifsubcolors[BISQUE3],
					 NULL);
	    
	    XtAddCallback(pu, XmNvalueChangedCallback, 
			  (XtCallbackProc)&filemenu::pushCB,
	    (XtPointer)this);
	    
	} else {
	    Widget pu = 
		XtVaCreateManagedWidget (s,
					 xmPushButtonWidgetClass, p,
					 XmNbackground, motifsubcolors[BISQUE3],
					 NULL);
	    
	    XtAddCallback(pu, XmNactivateCallback, 
			  (XtCallbackProc)&filemenu::pushCB,
	    (XtPointer)this);
	    
	};
    va_end(ap);
    Map();
}


// Generic button class. Creates a button and
// makes a pointer back to the filemenu. 
void okbutton::Create(Widget p,filemenu *ipt,FBTYPE type,const char *s)
{
    pt=ipt;
    typebut=type;
    build(p,s);
}

// This procedure is called when a button is pushed.
// The result is processed by filename's pushedbutton routine.
void okbutton::pushed(void)
{
    pt->pushedbutton(typebut);
}

// This procedure must be called in order to 
// make a nice plot choice window when "plott" is
// called from the menu.
void filemenu::plottoggle(int startarg, ...)
{
    va_list ap;
    char *s=NULL;
    int n=0;
    
    va_start(ap,startarg);
    while((s = va_arg(ap, char *)) != NULL)
    {
	if(!strncmp(s,"SCREEN",6))
	    ptypes[n++]=SCREEN;
	if(!strncmp(s,"PSFILE",6))
	    ptypes[n++]=PSFILE;
	if(!strncmp(s,"BW",2))
	    ptypes[n++]=BW;
        if(!strncmp(s,"COLOR",5))
	    ptypes[n++]=COLOR;
	if(!strncmp(s,"CHOOSE_PRINTER",14))
	    ptypes[n++]=CHOOSE_PRINTER;  
	s=NULL;
    } 
    va_end(ap);
    number_of_plottypes=n;
}


// This procedure must be called in order to 
// make a nice table choice window when "tabell" is
// called from the menu.
void filemenu::tabletoggle(int startarg, ...)
{
    va_list ap;
    char *s;
    int n=0;
    
    va_start(ap,startarg);
    while((s = va_arg(ap, char *)) != NULL)
    {
	if(!strncmp(s,"TSCREEN",7))
	    ttypes[n++]=TSCREEN;
	if(!strncmp(s,"FORMAT",6))
	    ttypes[n++]=FORMAT;
	if(!strncmp(s,"UNFORMAT",8))
	    ttypes[n++]=UNFORMAT;
	if(!strncmp(s,"HYDARK",6))
	    ttypes[n++]=HYDARK;
        if(!strncmp(s,"CALC",4))
	    ttypes[n++]=CALC;
	if(!strncmp(s,"VARDAT",6))
	    ttypes[n++]=VARDAT;
	if(!strncmp(s,"EXDAT",5))
	    ttypes[n++]=EXDAT;
	if(!strncmp(s,"FPRINTER",8))
	    ttypes[n++]=FPRINTER;
    } 
    va_end(ap);
    number_of_tabletypes=n;
}



// This routine is called when a button is called. The
// button type is given and the result depends on this.
void filemenu::pushedbutton(FBTYPE type)
{
    switch(type)
    {
    case PLOT_OK: {
        PLOTTYPE pl=ptypes[sel.operator()()];
        if(pl==PSFILE)
	{
	    sh2.build(w, filechoicestr[language]);
            v2.build(sh2);
            pfilechoose.Create(v2,this,&sh2);
            sh2.Map();
	}
        else
	    plotpushed(pl);
        sh.Unmap();
	} break;
    case PLOT_CANCEL:
        sh.Unmap();
	break;
    case TABLE_OK:
    {
	TABLETYPE tt=ttypes[sel2.operator()()];
	tabtype=tt;
	if(tt!=TSCREEN && tt!=FPRINTER)
	{
	    sh4.build(w, filechoicestr[language]);
	    v4.build(sh4);
	    tfilechoose.Create(v4,this,&sh4);
	    sh4.Map();
	}
	else
	    tablepushed(tt);
	sh3.Unmap();
    }
    break;
    case TABLE_CANCEL:
	sh3.Unmap();
	break;
    }
}


// This routine makes a filesc-element, which is a sub-class
// of filesel, a file selection module. A pointer
// back to the filemenu is created. 
void filesc::Create(Widget p,filemenu *ipt,shelldialog *shi)
{
    shelld=shi;
    pt=ipt;
    build(p);
}


// The Ok-button has been pushed. This class is
// used by the "plott" window, and since the only file
// option with "plott" is "ps file", such an instance
// is sent to the virtual routine plotpushed.
void filesc::ok(const char *str)
{
    shelld->Unmap();
    strcpy(pt->filename,str);
    pt->plotpushed(PSFILE);
}


// Cancel  button has been pushed...
void filesc::cancel()
{
    shelld->Unmap();
}


// This class handles the filesel window for the table
// menu choice. A window will be created and a pointer
// back to the filemenu class is made.
void filetab::Create(Widget p,filemenu *ipt,shelldialog *shi)
{
    shelld=shi;
    pt=ipt;
    build(p);
}


// The table file selection's ok button has been pressed.
// The virtual routine tablepushed is called. This routine
// can of course be redefined by the application.
void filetab::ok(const char *str)
{
    shelld->Unmap();
    strcpy(pt->filename,str);
    pt->tablepushed(pt->tabtype);
}


// The cancel button has been pressed...
void filetab::cancel()
{
    shelld->Unmap();
}



// The "plott" menu choice has been used. We'll have to make
// a window for the user so (s)he can choose the plot device.
void filemenu::plotcall(Widget  parent, filemenu *pt, XtPointer) 
{
    int n,is_choose_printer=0;
    const char *strbuf[5];
    pt->sh.build(parent, plotstr[language]); 
    pt->v1.build(pt->sh); 
    pt->lab.build(pt->v1, plotchoicestr[language]);
    for(n=0;n<(pt->number_of_plottypes);n++)
	switch(pt->ptypes[n])
	{
	case SCREEN:
	    strbuf[n]=plotselection[language][0];
            break;
        case PSFILE:
	    strbuf[n]=plotselection[language][1];
            break;
        case BW:
	    strbuf[n]=plotselection[language][2];
            break;
        case COLOR:
	    strbuf[n]=plotselection[language][3];
            break;
        case CHOOSE_PRINTER:
	    strbuf[n]=plotselection[language][4];
            is_choose_printer=1;
            break;
	}
    
    pt->sel.vbuild(pt->v1,strbuf,pt->number_of_plottypes);
    if(is_choose_printer)
	pt->tx.build(pt->v1, printernamestr[language]);
    pt->okf.Create(pt->v1,pt,PLOT_OK, plotstr[language]);
    pt->caf.Create(pt->v1,pt,PLOT_CANCEL, abortstr[language]);
    pt->sh.Map();
}



// Then "Tabell" menu element has been pressed and 
// a window must be made in order for the user to
// choose the output format.
void filemenu::tablecall(Widget  parent, filemenu *pt, XtPointer) 
{
    int n;
    const char *strbuf[6];
    pt->sh3.build(parent, tablestr[language]); 
    pt->v3.build(pt->sh3); 
    pt->lab.build(pt->v3, tablechoicestr[language]);
    for(n=0;n<(pt->number_of_tabletypes);n++)
	switch(pt->ttypes[n])
	{
	case TSCREEN:
	    strbuf[n]=tableselection[language][0];
            break;
        case FORMAT:
	    strbuf[n]=tableselection[language][1];
            break;
        case UNFORMAT:
	    strbuf[n]=tableselection[language][2];
            break;
	case HYDARK:
	    strbuf[n]=tableselection[language][3];
            break;
        case CALC:
	    strbuf[n]=tableselection[language][4];
            break;
        case VARDAT:
	    strbuf[n]=tableselection[language][5];
            break;
        case EXDAT:
	    strbuf[n]=tableselection[language][6];
            break;
	case FPRINTER:
	    strbuf[n]=tableselection[language][7];
            break;
	}
    
    pt->sel2.vbuild(pt->v3,strbuf,pt->number_of_tabletypes);
    pt->okt.Create(pt->v3,pt,TABLE_OK, "OK");
    pt->cant.Create(pt->v3,pt,TABLE_CANCEL, abortstr[language]);
    pt->sh3.Map();
}


// The "avslutt" (quit) element in the menu has been called.
// The program terminates.
void filemenu::quitcall(Widget, filemenu *pt, XtPointer) 
{
    pt->quitpushed();
}

