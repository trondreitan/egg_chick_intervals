/*
 * $Id: plot_module.C 2918 2017-05-09 09:13:59Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/plot_module.C $
 */

#include <hydrasub/hydragui/plot_module.H>

#include <hydrasub/hydrabase/types.H>
#include <hydrasub/hydrabase/divfunc.H>
#include <cmath>
 
#ifdef NVE
#include <envirsub/system.H>
#else       
#include <sys/types.h>
#include <unistd.h>
#endif // NVE


int font_x_size[]={6,7,8,9,12,13,17,0};
int font_y_size[]={12,14,17,20,24,25,34,0};

// ***************************************************
//
//               PLOT_MODULE
//
// This is a plotting module meant for multiple 
// value/value plotting, showing plotting titles
// and axis titles. 
//
//             Trond Reitan
//              5/7-2000
//
// ***************************************************



double logit(double p, bool is_percent)
{
  if(!is_percent)
    return log(p/(1.0-p));
  else
    return log(p/(100.0-p));
}

double invlogit(double x, bool is_percent)
{
  if(!is_percent)
    return 1.0/(1.0+exp(-x));
  else
    return 100.0/(1.0+exp(-x));
}

double probit(double p, bool is_percent)
{
#ifdef GSL
  if(!is_percent)
    return gsl_cdf_ugaussian_Pinv(p);
  else
    return gsl_cdf_ugaussian_Pinv(p/100.0);
#else
  return MISSING_VALUE;
#endif // GSL
}

double invprobit(double x, bool is_percent)
{
#ifdef GSL
  if(!is_percent)
    return gsl_cdf_ugaussian_P(x);
  else
    return 100.0*gsl_cdf_ugaussian_P(x);
#else
  return MISSING_VALUE;
#endif // GSL
}




// *********************************************
//
//              PLOT_POINTS
// Represents a point to be plotted
//
// *********************************************

// make a new element
plot_point::plot_point(plot_point *prev_tail, double newx, double newy,
		       bool within_plotting_area) :
  double_linked_list((double_linked_list *) prev_tail, NULL)
{
  x=newx;
  dt=NoDateTime;
  y=newy;
  timeserie_point=False;
  within=within_plotting_area;
}

// make a new element
plot_point::plot_point(plot_point *prev_tail, DateTime newx, double newy,
		       bool within_plotting_area) :
  double_linked_list((double_linked_list *) prev_tail, NULL)
{
  x=MISSING_VALUE;
  dt=newx;
  y=newy;
  timeserie_point=True;
  within=within_plotting_area;
}

// destrcut a list of elements
plot_point::~plot_point()
{
  plot_point *nextitem = (plot_point *) getnext();
  
  removefromlist();

  if(nextitem)
    delete nextitem;
}

// fetch the x coordinate
double plot_point::get_x(void) 
{
  return x;
}

// fetch the x datetime coordinate
DateTime &plot_point::get_dt(void) 
{
  return dt;
}

// fetch the y coordinate
double plot_point::get_y(void) 
{
  return y;
}

// Set the y coordinate:
void plot_point::set_y(double new_y)
{
  y=new_y;
}

bool plot_point::is_timeserie_point(void)
{
  return timeserie_point;
}

bool plot_point::is_within(void)
{
  return within;
}


// Set the within status:
void plot_point::set_within(bool new_state)
{
  within=new_state;
}


// rescale a whole list;
void plot_point::rescale(double x0, double y0, double x1, double y1,
			 double oldx0, double oldy0, 
			 double oldx1, double oldy1, bool doclip,
			 bool check_y)
{

  x = x0 + (x-oldx0) / (oldx1-oldx0) * (x1-x0);
  if(check_y)
    y = y0 + (y-oldy0) / (oldy1-oldy0) * (y1-y0);

  if(doclip)
    {
      if((x<x0 && x0<x1) || (x>x0 && x0>x1))
	x=x0;
      if((x>x1 && x1>x0) || (x<x1 && x1<x0))
	x=x1;
      if(check_y)
	{
	  if((y<y0 && y0<y1) || (y>y0 && y0>y1))
	    y=y0;
	  if((y>y1 && y1>y0) || (y<y1 && y1<y0))
	    y=y1;
	}
    }
}

// rescale a whole list;
void plot_point::rescale(double x0, double y0, double x1, double y1,
			 DateTime oldx0, double oldy0, 
			 DateTime oldx1, double oldy1, bool doclip,
			 bool check_y)
{
  //static double xmin=MISSING_VALUE,xmax=MISSING_VALUE;
  //static double ymin=MISSING_VALUE,ymax=MISSING_VALUE;
  
  /* debug
  DateTime start(2000,7,1),end(2000,7,31);
  if(dt>start && dt<end)
    cout << dt << " " << y << " -> ";
    debug */

  x = x0 + (double) dt.difference_minutes(oldx0) * (x1-x0) / 
    (double) oldx1.difference_minutes(oldx0);
  if(check_y)
    y = y0 + (y-oldy0) / (oldy1-oldy0) * (y1-y0);

  if(doclip)
    {
      if((x<x0 && x0<x1) || (x>x0 && x0>x1))
	x=x0;
      if((x>x1 && x1>x0) || (x<x1 && x1<x0))
	x=x1;
      if(check_y)
	{
	  if((y<y0 && y0<y1) || (y>y0 && y0>y1))
	    y=y0;
	  if((y>y1 && y1>y0) || (y<y1 && y1<y0))
	    y=y1;
	}
    }

  /* debug
  if(dt>start && dt<end)
    {
      if(xmin>x || xmin==MISSING_VALUE)
	xmin=x;
      if(ymin>y || ymin==MISSING_VALUE)
	ymin=y;
      if(xmax<x || xmax==MISSING_VALUE)
	xmax=x;
      if(ymax<y || ymax==MISSING_VALUE)
	ymax=y;

      cout << x << " " << y << "  R: " << xmin << " , " << ymin << " - " <<
	xmax << " , " << ymax << std::endl;
	} debug */
}


void plot_point::polar_rescale(double maxradius,
			       int years, int minutes, double y0, double y1,
			       bool check_y)
{
  if(years>0 && years!=MISSING_VALUE)
    {
      int year=1901+(dt.getYear() % years);
      DateTime dt0(1901,1,1);
      DateTime dt1(year, dt.getMonth(), dt.getDay(),
		   dt.getHour(), dt.getMinute(), dt.getSecond());
      DateTime dt2(1901+years, 1, 1);
      
      x = 2.0 * M_PI * ((double) dt1.difference_minutes(dt0)) / 
	((double) dt2.difference_minutes(dt0));      
    }
  else
    {
      DateTime dt0(1901,1,1);
      DateTime dt2=dt0+60*minutes;      

      x = 2.0 * M_PI * ((double) dt.difference_minutes(dt0)) / 
	((double) dt2.difference_minutes(dt0));
    }

  if(check_y)
    y = (y-y0) / (y1-y0) * maxradius;
}

void plot_point::polar_rescale(double maxradius,
			       double circle_length, double y0, double y1,
			       bool check_y)
{
  x = 2.0 * M_PI * x / circle_length;
  if(check_y)
    y = (y-y0) / (y1-y0) * maxradius;
}


// *****************************************
// ROUTINES;
// *****************************************


// Check if a given point is within a rectangle
bool within(double x, double y,
	    double startx, double starty, double endx, double endy,
	    bool check_y)
{
  if(check_y)
    {
      if(((x>=startx && x<=endx) || (x>=endx && x<=startx)) &&
	 ((y>=starty && y<=endy) || (y>=endy && y<=starty)))
	return True;
      else
	return False;
    }
  else
    {
      if((x>=startx && x<=endx) || (x>=endx && x<=startx))
	return True;
      else
	return False;
    }
}


// Check if qa given point is within a rectangle
bool within(DateTime x, double y,
	    DateTime startx, double starty, DateTime endx, double endy,
	    bool check_y)
{
  if(check_y)
    {
      if(((x>=startx && x<=endx) || (x>=endx && x<=startx)) &&
	 ((y>=starty && y<=endy) || (y>=endy && y<=starty)))
	return True;
      else
	return False;
    }
  else
    {
      if((x>=startx && x<=endx) || (x>=endx && x<=startx))
	return True;
      else
	return False;
    }
}


// Fetch the clipped starting point of a line (x0,y0)->(x1,y1)
// withing the rectangle (startx, starty)->(endx,endy)
// Logarithmic values are returned if that is specified.
plot_point *get_startp(double x0, double y0, double x1, double y1,
		       double startx, double starty, double endx, double endy,
		       AXIS_SCALING xscaling, AXIS_SCALING yscaling,
		       bool check_y, bool check_x)
{
  plot_point *pt=NULL;
  double x=MISSING_VALUE, y=MISSING_VALUE;
  double d1=MISSING_VALUE,d2=MISSING_VALUE,d3=MISSING_VALUE,d4=MISSING_VALUE;
 
  if(x0==MISSING_VALUE)
    return NULL;

  if(check_y && y0==MISSING_VALUE)
    return NULL;
  
  if(xscaling==AXIS_LOGARITHMIC)
    {
      if(x0<=0.0 || startx<=0.0)
	return NULL;

      x0=log10(x0);
      if(x1!=MISSING_VALUE && x1>0.0)
	x1=log10(x1);
      else
	x1=MISSING_VALUE;
      startx=log10(startx);
      if(endx!=MISSING_VALUE && endx>0.0)
	endx=log10(endx);
      else
	endx=MISSING_VALUE;
    }
  else if(xscaling==AXIS_LOGIT_PERCENT)
    {
      if(x0<=0.0 || startx<=0.0 || 
	 x0>=100.0 || startx>=100.0)
	return NULL;

      x0=logit(x0,true);
      if(x1!=MISSING_VALUE && x1>0.0 && x1<100.0)
	x1=logit(x1,true);
      else
	x1=MISSING_VALUE;
      startx=logit(startx,true);
      if(endx!=MISSING_VALUE && endx>0.0 && endx<100.0)
	endx=logit(endx,true);
      else
	endx=MISSING_VALUE;
    }
  else if(xscaling==AXIS_LOGIT_ABSOLUTE)
    {
      if(x0<=0.0 || startx<=0.0 || 
	 x0>=1.0 || startx>=1.0)
	return NULL;

      x0=logit(x0,false);
      if(x1!=MISSING_VALUE && x1>0.0 && x1<1.0)
	x1=logit(x1,false);
      else
	x1=MISSING_VALUE;
      startx=logit(startx,false);
      if(endx!=MISSING_VALUE && endx>0.0 && endx<1.0)
	endx=logit(endx,false);
    }
  else if(xscaling==AXIS_PROBIT_PERCENT)
    {
      if(x0<=0.0 || startx<=0.0 || 
	 x0>=100.0 || startx>=100.0)
	return NULL;

      x0=probit(x0,true);
      if(x1!=MISSING_VALUE && x1>0.0 && x1<100.0)
	x1=probit(x1,true);
      else
	x1=MISSING_VALUE;
      startx=probit(startx,true);
      if(endx!=MISSING_VALUE && endx>0.0 && endx<100.0)
	endx=probit(endx,true);
      else
	endx=MISSING_VALUE;
    }
  else if(xscaling==AXIS_PROBIT_ABSOLUTE)
    {
      if(x0<=0.0 || startx<=0.0 || 
	 x0>=1.0 || startx>=1.0)
	return NULL;

      x0=probit(x0,false);
      if(x1!=MISSING_VALUE && x1>0.0 && x1<1.0)
	x1=probit(x1,false);
      else
	x1=MISSING_VALUE;
      startx=probit(startx,false);
      if(endx!=MISSING_VALUE && endx>0.0 && endx<1.0)
	endx=probit(endx,false);
      else
	endx=MISSING_VALUE;
    }

  if(check_y)
    {
      if(yscaling==AXIS_LOGARITHMIC)
	{
	  if(y0<=0.0 || starty<=0.0)
	    return NULL;
	  
	  y0=log10(y0);
	  if(y1!=MISSING_VALUE && y1>0.0)
	    y1=log10(y1);
	  else
	    y1=MISSING_VALUE;
	  starty=log10(starty);
	  if(endy!=MISSING_VALUE && endy>0.0)
	    endy=log10(endy);
	  else
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_LOGIT_PERCENT)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=100.0 || starty>=100.0)
	    return NULL;
	  
	  y0=logit(y0,true);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<100.0)
	    y1=logit(y1,true);
	  else
	    y1=MISSING_VALUE;
	  starty=logit(starty,true);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<100.0)
	    endy=logit(endy,true);
	  else
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_LOGIT_ABSOLUTE)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=1.0 || starty>=1.0)
	    return NULL;
	  
	  y0=logit(y0,false);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<1.0)
	    y1=logit(y1,false);
	  else
	    y1=MISSING_VALUE;
	  starty=logit(starty,false);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<1.0)
	    endy=logit(endy,false);
	  else
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_PROBIT_PERCENT)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=100.0 || starty>=100.0)
	    return NULL;
	  
	  y0=probit(y0,true);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<100.0)
	    y1=probit(y1,true);
	  else
	    y1=MISSING_VALUE;
	  starty=probit(starty,true);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<100.0)
	    endy=probit(endy,true);
	  else
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_PROBIT_ABSOLUTE)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=1.0 || starty>=1.0)
	    return NULL;
	  
	  y0=probit(y0,false);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<1.0)
	    y1=probit(y1,false);
	  else
	    y1=MISSING_VALUE;
	  starty=probit(starty,false);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<1.0)
	    endy=probit(endy,false);
	  else
	    endy=MISSING_VALUE;
	}
    }
  
  // check if point 0 is within the plotting rectangle
  if(within(x0, y0, startx, starty, endx, endy, check_y))
    {
      pt=new plot_point(NULL, x0, y0, True);

      return pt;
    }
  else if(!check_y && x0<=startx && x1>startx)
    {
      pt=new plot_point(NULL, startx, y0, True);

      return pt;
    }
  
  
  if(x0!=x1) // not parallell to the y-axis
    {
      // fetch scale variable for intersection with left y-axis;
      d1=(startx-x0)/(x1-x0);  
      // fetch scale variable for intersection with right y-axis;
      d2=(endx-x0)/(x1-x0);
    }
  
  if(y0!=y1) // not parallell to the x-axis
    {
      // fetch scale variable for intersection with lower x-axis;
      d3=(starty-y0)/(y1-y0);
      // fetch scale variable for intersection with upper x-axis;
      d4=(endy-y0)/(y1-y0);
    }
  
  double ybuffer1=MISSING_VALUE, ybuffer2=MISSING_VALUE;
  double xbuffer1=MISSING_VALUE, xbuffer2=MISSING_VALUE;
  if(d1!=MISSING_VALUE)
    ybuffer1=y0+d1*(y1-y0);
  if(d2!=MISSING_VALUE)
    ybuffer2=y0+d2*(y1-y0);
  if(d3!=MISSING_VALUE)
    xbuffer1=x0+d3*(x1-x0);
  if(d4!=MISSING_VALUE)
    xbuffer2=x0+d4*(x1-x0);

  if(ybuffer1<MINIM(starty,endy) || ybuffer1>MAXIM(starty,endy))
    d1=MISSING_VALUE;
  if(ybuffer2<MINIM(starty,endy) || ybuffer2>MAXIM(starty,endy))
    d2=MISSING_VALUE;
  if(xbuffer1<MINIM(startx,endx) || xbuffer1>MAXIM(startx,endx))
    d3=MISSING_VALUE;
  if(xbuffer2<MINIM(startx,endx) || xbuffer2>MAXIM(startx,endx))
    d4=MISSING_VALUE;

  if(d1>=0.0 && d1<=1.0 &&
     (d1<d2 || d2<0.0 || d2>1.0) &&
     (d1<d3 || d3<0.0 || d3>1.0) &&
     (d1<d4 || d4<0.0 || d4>1.0)) // left y-axis is closest to point 0
    {
      x=startx;
      y=y0+d1*(y1-y0);
    }
  else if(d2>=0.0 && d2<=1.0 &&
	  (d2<d1 || d1<0.0 || d1>1.0) &&
	  (d2<d3 || d3<0.0 || d3>1.0) &&
	  (d2<d4 || d4<0.0 || d4>1.0)) // right y-axis is closest to point 0
    {
      x=endx;
      y=y0+d2*(y1-y0);
    }
  else if(d3>=0.0 && d3<=1.0 &&
	  (d3<d1 || d1<0.0 || d1>1.0) &&
	  (d3<d2 || d2<0.0 || d2>1.0) &&
	  (d3<d4 || d4<0.0 || d4>1.0)) // lower x-axis is closest to point 0
    {
      x=x0+d3*(x1-x0);
      y=starty;
    }
   else if(d4>=0.0 && d4<=1.0 &&
	  (d4<d1 || d1<0.0 || d1>1.0) &&
	  (d4<d2 || d2<0.0 || d2>1.0) &&
	  (d4<d3 || d3<0.0 || d3>1.0)) // upper x-axis is closest to point 0
    {
      x=x0+d4*(x1-x0);
      y=endy;
    }
  
  
  if(x!=MISSING_VALUE && y!=MISSING_VALUE) // intersection points found?
    {
      if(check_x)
	pt=new plot_point(NULL, x, y, False);
      else
	pt=new plot_point(NULL, MAXIM(x0,startx), y, True);
	
      return pt;
    }
  
  return NULL; // no intersection points found
}

// Fetch the clipped ending point of a line (x0,y0)->(x1,y1)
// withing the rectangle (startx, starty)->(endx,endy)
// Logarithmic values are returned if that is specified.
plot_point *get_endp(double x0, double y0, double x1, double y1,
		     double startx, double starty, double endx, double endy,
		     AXIS_SCALING xscaling, AXIS_SCALING yscaling,
		     bool check_y, bool check_x)
{
  plot_point *pt=NULL;
  double x=MISSING_VALUE, y=MISSING_VALUE;
  double d1=MISSING_VALUE,d2=MISSING_VALUE,d3=MISSING_VALUE,d4=MISSING_VALUE;
  
  if(x1==MISSING_VALUE)
    return NULL;
  
  if(check_y && y1==MISSING_VALUE)
    return NULL;

  if(xscaling==AXIS_LOGARITHMIC)
    {
      if(x1<=0.0 || endx<=0.0)
	return NULL;

      if(x0!=MISSING_VALUE && x0>0.0)
	x0=log10(x0);
      else
	x0=MISSING_VALUE;
      x1=log10(x1);
      if(startx!=MISSING_VALUE && startx>0.0)
	startx=log10(startx);
      else
	startx=MISSING_VALUE;
      endx=log10(endx);
    }
  else if(xscaling==AXIS_LOGIT_PERCENT)
    {
      if(x1<=0.0 || endx<=0.0 || x1>=100.0 || endx>=100.0)
	return NULL;

      if(x0!=MISSING_VALUE && x0>0.0 && x0<100.0)
	x0=logit(x0,true);
      else
	x0=MISSING_VALUE;
      x1=logit(x1,true);
      if(startx!=MISSING_VALUE && startx>0.0 && startx<100.0)
	startx=logit(startx,true);
      else
	startx=MISSING_VALUE;
      endx=logit(endx,true);
    }
  else if(xscaling==AXIS_LOGIT_ABSOLUTE)
    {
      if(x1<=0.0 || endx<=0.0 || x1>=1.0 || endx>=1.0)
	return NULL;

      if(x0!=MISSING_VALUE && x0>0.0 && x0<1.0)
	x0=logit(x0,false);
      else
	x0=MISSING_VALUE;
      x1=logit(x1,false);
      if(startx!=MISSING_VALUE && startx>0.0 && startx<1.0)
	startx=logit(startx,false);
      else
	startx=MISSING_VALUE;
      endx=logit(endx,false);
    }
  else if(xscaling==AXIS_PROBIT_PERCENT)
    {
      if(x1<=0.0 || endx<=0.0 || x1>=100.0 || endx>=100.0)
	return NULL;

      if(x0!=MISSING_VALUE && x0>0.0 && x0<100.0)
	x0=probit(x0,true);
      else
	x0=MISSING_VALUE;
      x1=probit(x1,true);
      if(startx!=MISSING_VALUE && startx>0.0 && startx<100.0)
	startx=probit(startx,true);
      else
	startx=MISSING_VALUE;
      endx=probit(endx,true);
    }
  else if(xscaling==AXIS_PROBIT_ABSOLUTE)
    {
      if(x1<=0.0 || endx<=0.0 || x1>=1.0 || endx>=1.0)
	return NULL;

      if(x0!=MISSING_VALUE && x0>0.0 && x0<1.0)
	x0=probit(x0,false);
      else
	x0=MISSING_VALUE;
      x1=probit(x1,false);
      if(startx!=MISSING_VALUE && startx>0.0 && startx<1.0)
	startx=probit(startx,false);
      else
	startx=MISSING_VALUE;
      endx=probit(endx,false);
    }

  if(check_y)
    {
      if(yscaling==AXIS_LOGARITHMIC)
	{
	  if(y1<=0.0 || endy<=0.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0)
	    y0=log10(y0);
	  else
	    y0=MISSING_VALUE;
	  y1=log10(y1);
	  if(starty!=MISSING_VALUE && starty>0.0)
	    starty=log10(starty);
	  else
	    starty=MISSING_VALUE;
	  endy=  log10(endy);
	}
      else if(yscaling==AXIS_LOGIT_PERCENT)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=100.0 || endy>=100.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<100.0)
	    y0=logit(y0,true);
	  else
	    y0=MISSING_VALUE;
	  y1=logit(y1,true);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<100.0)
	    starty=logit(starty,true);
	  else
	    starty=MISSING_VALUE;
	  endy=logit(endy,true);
	}
      else if(yscaling==AXIS_LOGIT_ABSOLUTE)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=1.0 || endy>=1.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<1.0)
	    y0=logit(y0,false);
	  else 
	    y0=MISSING_VALUE;
	  y1=logit(y1,false);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<1.0)
	    starty=logit(starty,false);
	  else
	    starty=MISSING_VALUE;
	  endy=logit(endy,false);
	}
      else if(yscaling==AXIS_PROBIT_PERCENT)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=100.0 || endy>=100.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<100.0)
	    y0=probit(y0,true);
	  else
	    y0=MISSING_VALUE;
	  y1=probit(y1,true);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<100.0)
	    starty=probit(starty,true);
	  else
	    starty=MISSING_VALUE;
	  endy=probit(endy,true);
	}
      else if(yscaling==AXIS_PROBIT_ABSOLUTE)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=1.0 || endy>=1.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<1.0)
	    y0=probit(y0,false);
	  else 
	    y0=MISSING_VALUE;
	  y1=probit(y1,false);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<1.0)
	    starty=probit(starty,false);
	  else
	    starty=MISSING_VALUE;
	  endy=probit(endy,false);
	}
	
    }

  // check if point 1 is within the plotting rectangle
  if(within(x1, y1, startx, starty, endx, endy, check_y))
    {
      pt=new plot_point(NULL, x1, y1, True);

      return pt;
    }
  else if(!check_y && x0<endx && x1>=endx)
    {
      pt=new plot_point(NULL, endx, y1, True);

      return pt;
    }
  
  if(x0!=x1) // not parallell to the y-axis
    {
      // fetch scale variable for intersection with left y-axis;
      d1=(startx-x0)/(x1-x0);  
      // fetch scale variable for intersection with right y-axis;
      d2=(endx-x0)/(x1-x0);
    }

  if(y0!=y1) // not parallell to the x-axis
    {
      // fetch scale variable for intersection with lower x-axis;
      d3=(starty-y0)/(y1-y0);
      // fetch scale variable for intersection with upper x-axis;
      d4=(endy-y0)/(y1-y0);
    }

  double ybuffer1=MISSING_VALUE,ybuffer2=MISSING_VALUE;
  double xbuffer1=MISSING_VALUE, xbuffer2=MISSING_VALUE;
  if(d1!=MISSING_VALUE)
    ybuffer1=y0+d1*(y1-y0);
  if(d2!=MISSING_VALUE)
    ybuffer2=y0+d2*(y1-y0);
  if(d3!=MISSING_VALUE)
    xbuffer1=x0+d3*(x1-x0);
  if(d4!=MISSING_VALUE)
    xbuffer2=x0+d4*(x1-x0);

  if(ybuffer1<MINIM(starty,endy) || ybuffer1>MAXIM(starty,endy))
    d1=MISSING_VALUE;
  if(ybuffer2<MINIM(starty,endy) || ybuffer2>MAXIM(starty,endy))
    d2=MISSING_VALUE;
  if(xbuffer1<MINIM(startx,endx) || xbuffer1>MAXIM(startx,endx))
    d3=MISSING_VALUE;
  if(xbuffer2<MINIM(startx,endx) || xbuffer2>MAXIM(startx,endx))
    d4=MISSING_VALUE;

  if(d1>=0.0 && d1<=1.0 &&
     (d1>d2 || d2<0.0 || d2>1.0) &&
     (d1>d3 || d3<0.0 || d3>1.0) &&
     (d1>d4 || d4<0.0 || d4>1.0)) // left y-axis is closest to point 1
    {
      x=startx;
      y=y0+d1*(y1-y0);
    }
  else if(d2>=0.0 && d2<=1.0 &&
	  (d2>d1 || d1<0.0 || d1>1.0) &&
	  (d2>d3 || d3<0.0 || d3>1.0) &&
	  (d2>d4 || d4<0.0 || d4>1.0)) // right y-axis is closest to point 1
    {
      x=endx;
      y=y0+d2*(y1-y0);
    }
  else if(d3>=0.0 && d3<=1.0 &&
	  (d3>d1 || d1<0.0 || d1>1.0) &&
	  (d3>d2 || d2<0.0 || d2>1.0) &&
	  (d3>d4 || d4<0.0 || d4>1.0)) // lower x-axis is closest to point 1
    {
      x=x0+d3*(x1-x0);
      y=starty;
    }
   else if(d4>=0.0 && d4<=1.0 &&
	  (d4>d1 || d1<0.0 || d1>1.0) &&
	  (d4>d2 || d2<0.0 || d2>1.0) &&
	  (d4>d3 || d3<0.0 || d3>1.0)) // upper x-axis is closest to point 1
    {
      x=x0+d4*(x1-x0);
      y=endy;
    }

  if(x!=MISSING_VALUE && y!=MISSING_VALUE) // intersection points found?
    {
      if(check_x)
	pt=new plot_point(NULL, x, y, False);
      else
	pt=new plot_point(NULL, MINIM(x1,endx), y, True);
	
      return pt;
    }

  return NULL; // no intersection points found
}





// Fetch the clipped starting point of a line (x0,y0)->(x1,y1)
// withing the rectangle (startx, starty)->(endx,endy)
// Logarithmic values are returned if that is specified.
plot_point *get_startp(DateTime x0, double y0, DateTime x1, double y1,
		       DateTime startx, double starty, 
		       DateTime endx, double endy,
		       AXIS_SCALING yscaling, bool check_y, bool check_x)
{
  plot_point *pt=NULL;
  DateTime x=NoDateTime;
  double y=MISSING_VALUE;
  double d1=MISSING_VALUE,d2=MISSING_VALUE,d3=MISSING_VALUE,d4=MISSING_VALUE;

  if(x0==NoDateTime)
    return NULL;

  if(check_y && y0==MISSING_VALUE)
    return NULL;

  if(check_y)
    {
      if(yscaling==AXIS_LOGARITHMIC)
	{
	  if(y0<=0.0 || starty<=0.0 )
	    return NULL;
	  
	  y0=log10(y0);
	  if(y1!=MISSING_VALUE && y1>0.0)
	    y1=log10(y1);
	  else
	    y1=MISSING_VALUE;
	  starty=log10(starty);
	  if(endy!=MISSING_VALUE && endy>0.0)
	    endy=log10(endy);
	  else
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_LOGIT_PERCENT)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=100.0 || starty>=100.0)
	    return NULL;
	  
	  y0=logit(y0,true);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<100.0)
	    y1=logit(y1,true);
	  else
	    y1=MISSING_VALUE;
	  starty=logit(starty,true);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<100.0)
	    endy=logit(endy,true);
	  else 
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_PROBIT_ABSOLUTE)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=1.0 || starty>=1.0)
	    return NULL;
	  
	  y0=probit(y0,false);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<1.0)
	    y1=probit(y1,false);
	  else
	    y1=MISSING_VALUE;
	  starty=probit(starty,false);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<1.0)
	    endy=probit(endy,false);
	  else 
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_PROBIT_PERCENT)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=100.0 || starty>=100.0)
	    return NULL;
	  
	  y0=probit(y0,true);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<100.0)
	    y1=probit(y1,true);
	  else
	    y1=MISSING_VALUE;
	  starty=probit(starty,true);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<100.0)
	    endy=probit(endy,true);
	  else 
	    endy=MISSING_VALUE;
	}
      else if(yscaling==AXIS_PROBIT_ABSOLUTE)
	{
	  if(y0<=0.0 || starty<=0.0 || y0>=1.0 || starty>=1.0)
	    return NULL;
	  
	  y0=probit(y0,false);
	  if(y1!=MISSING_VALUE && y1>0.0 && y1<1.0)
	    y1=probit(y1,false);
	  else
	    y1=MISSING_VALUE;
	  starty=probit(starty,false);
	  if(endy!=MISSING_VALUE && endy>0.0 && endy<1.0)
	    endy=probit(endy,false);
	  else 
	    endy=MISSING_VALUE;
	}
    }

  // check if point 0 is within the plotting rectangle
  if(within(x0, y0, startx, starty, endx, endy,check_y))
    {
      pt=new plot_point(NULL, x0, y0, True);

      return pt;
    }
  else if(!check_y && x0<=startx && x1>startx)
    {
      pt=new plot_point(NULL, startx, y0, True);

      return pt;
    }
  
  if(x0!=x1) // not parallell to the y-axis
    {
      // fetch scale variable for intersection with left y-axis;
      d1 = (double) startx.difference_minutes(x0) / 
	(double) x1.difference_minutes(x0);
      // fetch scale variable for intersection with right y-axis;
      d2 = (double) endx.difference_minutes(x0) / 
	(double) x1.difference_minutes(x0);
    }

  if(y0!=y1) // not parallell to the x-axis
    {
      // fetch scale variable for intersection with lower x-axis;
      d3=(starty-y0)/(y1-y0);
      // fetch scale variable for intersection with upper x-axis;
      d4=(endy-y0)/(y1-y0);
    }

  double ybuffer1=MISSING_VALUE,ybuffer2=MISSING_VALUE;
  DateTime xbuffer1=NoDateTime, xbuffer2=NoDateTime;
  if(d1!=MISSING_VALUE)
    ybuffer1=y0+d1*(y1-y0);
  if(d2!=MISSING_VALUE)
    ybuffer2=y0+d2*(y1-y0);
  if(d3!=MISSING_VALUE)
    xbuffer1=x0 + (long int) (d3 * (double) x1.difference_minutes(x0))*60;
  if(d4!=MISSING_VALUE)
    xbuffer2=x0 + (long int) (d4 * (double) x1.difference_minutes(x0))*60;

  if(ybuffer1<MINIM(starty,endy) || ybuffer1>MAXIM(starty,endy))
    d1=MISSING_VALUE;
  if(ybuffer2<MINIM(starty,endy) || ybuffer2>MAXIM(starty,endy))
    d2=MISSING_VALUE;
  if(xbuffer1<MINIM(startx,endx) || xbuffer1>MAXIM(startx,endx))
    d3=MISSING_VALUE;
  if(xbuffer2<MINIM(startx,endx) || xbuffer2>MAXIM(startx,endx))
    d4=MISSING_VALUE;

  if(d1>=0.0 && d1<=1.0 &&
     (d1<d2 || d2<0.0 || d2>1.0) &&
     (d1<d3 || d3<0.0 || d3>1.0) &&
     (d1<d4 || d4<0.0 || d4>1.0)) // left y-axis is closest to point 0
    {
      x=startx;
      y=ybuffer1;
    }
  else if(d2>=0.0 && d2<=1.0 &&
	  (d2<d1 || d1<0.0 || d1>1.0) &&
	  (d2<d3 || d3<0.0 || d3>1.0) &&
	  (d2<d4 || d4<0.0 || d4>1.0)) // right y-axis is closest to point 0
    {
      x=endx;
      y=ybuffer2;
    }
  else if(d3>=0.0 && d3<=1.0 &&
	  (d3<d1 || d1<0.0 || d1>1.0) &&
	  (d3<d2 || d2<0.0 || d2>1.0) &&
	  (d3<d4 || d4<0.0 || d4>1.0)) // lower x-axis is closest to point 0
    {
      x = xbuffer1;
      y=starty;
    }
   else if(d4>=0.0 && d4<=1.0 &&
	  (d4<d1 || d1<0.0 || d1>1.0) &&
	  (d4<d2 || d2<0.0 || d2>1.0) &&
	  (d4<d3 || d3<0.0 || d3>1.0)) // upper x-axis is closest to point 0
    {
      x = xbuffer2;
      y=endy;
    }

  if(x!=NoDateTime && y!=MISSING_VALUE) // intersection points found?
    {
      if(check_x)
	pt=new plot_point(NULL, x, y, False);
      else
	pt=new plot_point(NULL, MAXIM(x0,startx), y, True);
	
      return pt;
    }

  return NULL; // no intersection points found
}


// Fetch the clipped ending point of a line (x0,y0)->(x1,y1)
// withing the rectangle (startx, starty)->(endx,endy)
// Logarithmic values are returned if that is specified.
plot_point *get_endp(DateTime x0, double y0, DateTime x1, double y1,
		     DateTime startx, double starty, 
		     DateTime endx, double endy,
		     AXIS_SCALING yscaling, bool check_y, bool check_x)
{
  plot_point *pt=NULL;
  DateTime x=NoDateTime;
  double y=MISSING_VALUE;
  double d1=MISSING_VALUE,d2=MISSING_VALUE,d3=MISSING_VALUE,d4=MISSING_VALUE;

  if(x1==NoDateTime)
    return NULL;
  
  if(check_y && y1==MISSING_VALUE)
    return NULL;

  if(check_y)
    {
      if(yscaling==AXIS_LOGARITHMIC)
	{
	  if(y1<=0.0 || endy<=0.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0)
	    y0=log10(y0);
	  else
	    y0=MISSING_VALUE;
	  y1=log10(y1);
	  if(starty!=MISSING_VALUE && starty>0.0)
	    starty=log10(starty);
	  else
	    starty=MISSING_VALUE;
	  endy=log10(endy);
	}
      else if(yscaling==AXIS_LOGIT_PERCENT)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=100.0 || endy>=100.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<100.0)
	    y0=logit(y0,true);
	  else
	    y0=MISSING_VALUE;
	  y1=logit(y1,true);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<100.0)
	    starty=logit(starty,true);
	  else
	    starty=MISSING_VALUE;
	  endy=logit(endy,true);
	}
      else if(yscaling==AXIS_LOGIT_ABSOLUTE)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=1.0 || endy>=1.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<1.0)
	    y0=logit(y0,false);
	  else
	    y0=MISSING_VALUE;
	  y1=logit(y1,false);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<1.0)
	    starty=logit(starty,false);
	  else
	    starty=MISSING_VALUE;
	  endy=logit(endy,false);
	}
      else if(yscaling==AXIS_PROBIT_PERCENT)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=100.0 || endy>=100.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<100.0)
	    y0=probit(y0,true);
	  else
	    y0=MISSING_VALUE;
	  y1=probit(y1,true);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<100.0)
	    starty=probit(starty,true);
	  else
	    starty=MISSING_VALUE;
	  endy=probit(endy,true);
	}
      else if(yscaling==AXIS_PROBIT_ABSOLUTE)
	{
	  if(y1<=0.0 || endy<=0.0 || y1>=1.0 || endy>=1.0)
	    return NULL;
	  
	  if(y0!=MISSING_VALUE && y0>0.0 && y0<1.0)
	    y0=probit(y0,false);
	  else
	    y0=MISSING_VALUE;
	  y1=probit(y1,false);
	  if(starty!=MISSING_VALUE && starty>0.0 && starty<1.0)
	    starty=probit(starty,false);
	  else
	    starty=MISSING_VALUE;
	  endy=probit(endy,false);
	}
    }
  // check if point 1 is within the plotting rectangle
  if(within(x1, y1, startx, starty, endx, endy,check_y))
    {
      pt=new plot_point(NULL, x1, y1, True);

      return pt;
    }
  else if(!check_y && x0<endx && x1>=endx)
    {
      pt=new plot_point(NULL, endx, y1, True);
      
      return pt;
    }
  
  if(x0!=x1) // not parallell to the y-axis
    {
      // fetch scale variable for intersection with left y-axis;
      d1 = (double) startx.difference_minutes(x0) / 
	(double) x1.difference_minutes(x0);
      // fetch scale variable for intersection with right y-axis;
      d2 = (double) endx.difference_minutes(x0) / 
	(double) x1.difference_minutes(x0);
    }

  if(y0!=y1) // not parallell to the x-axis
    {
      // fetch scale variable for intersection with lower x-axis;
      d3=(starty-y0)/(y1-y0);
      // fetch scale variable for intersection with upper x-axis;
      d4=(endy-y0)/(y1-y0);
    }

  double ybuffer1=MISSING_VALUE,ybuffer2=MISSING_VALUE;
  DateTime xbuffer1=NoDateTime, xbuffer2=NoDateTime;
  if(d1!=MISSING_VALUE)
    ybuffer1=y0+d1*(y1-y0);
  if(d2!=MISSING_VALUE)
    ybuffer2=y0+d2*(y1-y0);
  if(d3!=MISSING_VALUE)
    xbuffer1=x0 + (long int) (d3 * (double) x1.difference_minutes(x0))*60;
  if(d4!=MISSING_VALUE)
    xbuffer2=x0 + (long int) (d4 * (double) x1.difference_minutes(x0))*60;

  if(ybuffer1<MINIM(starty,endy) || ybuffer1>MAXIM(starty,endy))
    d1=MISSING_VALUE;
  if(ybuffer2<MINIM(starty,endy) || ybuffer2>MAXIM(starty,endy))
    d2=MISSING_VALUE;
  if(xbuffer1<MINIM(startx,endx) || xbuffer1>MAXIM(startx,endx))
    d3=MISSING_VALUE;
  if(xbuffer2<MINIM(startx,endx) || xbuffer2>MAXIM(startx,endx))
    d4=MISSING_VALUE;

  if(d1>=0.0 && d1<=1.0 &&
     (d1>d2 || d2<0.0 || d2>1.0) &&
     (d1>d3 || d3<0.0 || d3>1.0) &&
     (d1>d4 || d4<0.0 || d4>1.0)) // left y-axis is closest to point 1
    {
      x=startx;
      y=y0+d1*(y1-y0);
    }
  else if(d2>=0.0 && d2<=1.0 &&
	  (d2>d1 || d1<0.0 || d1>1.0) &&
	  (d2>d3 || d3<0.0 || d3>1.0) &&
	  (d2>d4 || d4<0.0 || d4>1.0)) // right y-axis is closest to point 1
    {
      x=endx;
      y=y0+d2*(y1-y0);
    }
  else if(d3>=0.0 && d3<=1.0 &&
	  (d3>d1 || d1<0.0 || d1>1.0) &&
	  (d3>d2 || d2<0.0 || d2>1.0) &&
	  (d3>d4 || d4<0.0 || d4>1.0)) // lower x-axis is closest to point 1
    {
      x = x0 + (long int) (d3 * (double) x1.difference_minutes(x0))*60;
      y = starty;
    }
   else if(d4>=0.0 && d4<=1.0 &&
	  (d4>d1 || d1<0.0 || d1>1.0) &&
	  (d4>d2 || d2<0.0 || d2>1.0) &&
	  (d4>d3 || d3<0.0 || d3>1.0)) // upper x-axis is closest to point 1
    {
      x = x0 + (long int) (d4 * (double) x1.difference_minutes(x0))*60;
      y = endy;
    }

  if(x!=NoDateTime && y!=MISSING_VALUE) // intersection points found?
    {
      if(check_x)
	pt=new plot_point(NULL, x, y, False);
      else
	pt=new plot_point(NULL, MINIM(x1,endx), y, True);
	
      return pt;
    }

  return NULL; // no intersection points found
}








// *********************************************
//  
//           PLOT_TICKS
// Represents a tick on an axis
//
// *********************************************

plot_tick::plot_tick()
    : value(0.0), valuebuffer(0.0), dt(NoDateTime), deci(0.0), size(TICK_SMALL), type(TICK_DAYS),
      timeserie_tick(false), first(false), pt(NULL), parent(NULL), x(0.0), y(0.0), rad(0.0)
{
    title[0] = '\0';
}

plot_tick::~plot_tick()
{
    pt = NULL;
    parent = NULL;
    title[0] = '\0';
}

// Creates the tick, drawing it in the plotting module;
void plot_tick::Create(double newvalue, int decimals, 
		       TICK_SIZE newsize, plot_axis *parent_, 
		       plot_module *ipt)
{
  value=newvalue;
  pt=ipt;
  deci=decimals;
  size=newsize;
  parent = parent_;
  timeserie_tick = False;
}

// Creates categorical tick, drawing it in the plotting module;
void plot_tick::Create(double newvalue, const char *title_,
		       TICK_SIZE newsize, plot_axis *parent_, 
		       plot_module *ipt)
{
  value=newvalue;
  pt=ipt;
  deci=0;
  strcpy(title, title_);
  size=newsize;
  type=TICK_CATEGORICAL;
  parent = parent_;
  timeserie_tick = False;
}
 

void plot_tick::Create(DateTime newvalue, TICK_TYPE newtype, 
		       plot_axis *parent_, 
		       plot_module *ipt, bool isfirst)
{
  dt=newvalue;
  pt=ipt;
  deci=0;
  size=TICK_SMALL;
  type=newtype;
  parent = parent_;
  timeserie_tick=True;
  first=isfirst && !pt->is_radial;
}

void plot_tick::plot_y_ticks(double start, double end, 
			     double valbuffer, const char *str)
{
  if(valbuffer<start || valbuffer>end)
    return;
  
  x = (double) parent->x0;
  y = ((double) parent->y0) + (valbuffer - start) / (end - start) * 
    ((double) (parent->y1 -  parent->y0));
  int xx = (int) x;
  int yy = (int) y;
  int len = ((int) size)*5;

  valuebuffer=y;

  if(pt->is_big())
    pt->setfont(PLOT_FONT_MEDIUM);
  else
    pt->setfont(PLOT_FONT_SMALL);
  if(pt->is_radial)
    {
      y=(valbuffer - start) / (end - start) * 
	((double) pt->radius);
      x=y;
      rad=x;

      xx=(int) x;
      yy=(int) y;

      switch(parent->axisnumber)
	{
	case 0:
	  if(parent->get_axis_type() == LEFT_Y_AXIS)
	    {
	      pt->Line(pt->plot_centerx+x, pt->plot_centery, 
		       pt->plot_centerx+x, pt->plot_centery-5-len);
	      pt->Text(str, pt->plot_centerx+xx-18, pt->plot_centery-12-len);
	    }
	  else // right y-axis
	    {
	      pt->Line(pt->plot_centerx+x, pt->plot_centery, 
		       pt->plot_centerx+x, pt->plot_centery+5+len);
	      pt->Text(str, pt->plot_centerx+xx-18, pt->plot_centery+10+len);
	    }
	  break;
	case 1:
	  if(parent->get_axis_type() == LEFT_Y_AXIS)
	    {
	      pt->Line(pt->plot_centerx-5.0-len, pt->plot_centery-y, 
		       pt->plot_centerx, pt->plot_centery-y);
	      pt->Text(str, pt->plot_centerx-10-len-
		       (8 + 3*((int) size))*strlen(str), 
		       pt->plot_centery-yy+12);
	    }
	  else // right y-axis
	    {
	      pt->Line(pt->plot_centerx+5.0+len, pt->plot_centery-y, 
		       pt->plot_centerx, pt->plot_centery-y);
	      pt->Text(str, pt->plot_centerx+12+len, pt->plot_centery-yy+10);
	    }
	  break;
	case 2:
	  if(parent->get_axis_type() == LEFT_Y_AXIS)
	    {
	      pt->Line(pt->plot_centerx-x, pt->plot_centery, 
		       pt->plot_centerx-x, pt->plot_centery+5+len);
	      pt->Text(str, pt->plot_centerx - xx + 12 - 
		       (4+((int) size))*strlen(str), 
		       pt->plot_centery+15+len);
	    }
	  else // right y-axis
	    {
	      pt->Line(pt->plot_centerx-x, pt->plot_centery, 
		       pt->plot_centerx-x, pt->plot_centery-5-len);
	      pt->Text(str, pt->plot_centerx - xx + 12 -
		       (4 + ((int) size))*strlen(str), 
		       pt->plot_centery-8-len);
	    }
	  break;
	case 3:
	  if(parent->get_axis_type() == RIGHT_Y_AXIS)
	    {
	      pt->Line(pt->plot_centerx-5.0-len, pt->plot_centery+y, 
		       pt->plot_centerx, pt->plot_centery+y);
	      pt->Text(str, pt->plot_centerx-15-len - 
		       (4 + ((int) size))*strlen(str), pt->plot_centery+yy-4);
	    }
	  else // right y-axis
	    {
	      pt->Line(pt->plot_centerx, pt->plot_centery+y, 
		       pt->plot_centerx+5.0+len, pt->plot_centery+y);
	      pt->Text(str, pt->plot_centerx+15+len, pt->plot_centery+yy-4);
	    }
	  break;
	}
    }
  else // normal plot
    {
      if(parent->get_axis_type() == LEFT_Y_AXIS)
	{
	  pt->Line(x-5.0-len, y, x+len, y);
	  if(!pt->is_big())
	    pt->Text(str, xx-12-len - 3*size - 7*strlen(str), yy+5);
	  else
	    pt->Text(str, xx-12-len - 3*size - 9*strlen(str), yy+5);
	}
      else // right y-axis
	{
	  pt->Line(x-len, y, x+5.0+len, y);
	  pt->Text(str, xx+15+len, yy+5); 
	}
    }
}

void plot_tick::plot_gridline(void)
{
  char style1[]={1,8};
  char style2[]={2,4};
  char style3[]={3,3};
  TICK_SIZE sizebuffer = size;

  if(pt->is_big())
    {
      if(parent->get_axis_type()==LEFT_Y_AXIS ||
	 parent->get_axis_type()==RIGHT_Y_AXIS)
	sizebuffer = (TICK_SIZE) (((int) size)+3);
      else
	sizebuffer = (TICK_SIZE) (((int) size)+2);
    }

  pt->SetFg("black");

  switch(sizebuffer)
    {
    case TICK_SMALL: 
      pt->Set_Dashes(style1, 2, 1);
      //pt->SetLineWidth(1);
      break;
    case TICK_LARGE: 
      pt->Set_Dashes(style1, 2, 2);
      break;
    case TICK_VERYLARGE: 
      pt->Set_Dashes(style2, 2, 2);
      break;
    case TICK_SUPERLARGE: 
      pt->Set_Dashes(style2, 2, 3);
      break;
    case TICK_SUPERDUPERLARGE:
    default:
      pt->Set_Dashes(style3, 2, 4);
      break;
    }

  if(!pt->is_radial)
    {
      if(parent->get_axis_type()==LEFT_Y_AXIS || 
	 parent->get_axis_type()==RIGHT_Y_AXIS)
	pt->Line(pt->plot_x0, y, pt->plot_x1, y);
      else
	{
	  if(parent->get_axis_type()!=TIME_X_AXIS || size!=TICK_SMALL ||
	     (type!=TICK_SECONDS_SMALL && type!=TICK_MINUTES_SMALL &&
	      type!=TICK_HOURS_SMALL && type!=TICK_DAYS_SMALL &&
	      type!=TICK_MONTHS_SMALL && type!=TICK_YEARS_SMALL))
	    pt->Line(x, pt->plot_y0, x, pt->plot_y1);
	}
    }
  else
    {
      if(parent->get_axis_type()==LEFT_Y_AXIS || 
	 parent->get_axis_type()==RIGHT_Y_AXIS)
	pt->circle(pt->plot_centerx, pt->plot_centery, rad);
      else
	{
	  double angle;

	  if(parent->get_axis_type()==TIME_X_AXIS)
	    {
	      DateTime start=parent->get_start_time();
	      DateTime end=parent->get_end_time();
	      long int diff=end.difference_minutes(start);

	      if(diff>30)
		angle = 2.0 * M_PI * ((double) dt.difference_minutes(start)) /
		  ((double) diff);
	      else
		angle = 2.0 * M_PI * ((double) (dt-start)) /
		  ((double) (end-start));
	    }
	  else
	    {
	      double start=parent->get_start();
	      double end=parent->get_end();
	      
	      angle = 2.0 * M_PI * (value - start) / (end - start);
	    }

	  if(!pt->counterclockwise)
	    angle=-angle;
	  angle += M_PI/2.0*double(int(pt->radialtype)-1);

	  double x1 = ((double) pt->plot_centerx) + ((double) pt->radius) *
	    cos(angle);
	  double y1 = ((double) pt->plot_centery) - ((double) pt->radius) *
	    sin(angle);
      
	  if(parent->get_axis_type()!=TIME_X_AXIS || size!=TICK_SMALL ||
	     (type!=TICK_SECONDS_SMALL && type!=TICK_MINUTES_SMALL &&
	      type!=TICK_HOURS_SMALL && type!=TICK_DAYS_SMALL &&
	      type!=TICK_MONTHS_SMALL && type!=TICK_YEARS_SMALL))
	    pt->Line(pt->plot_centerx, pt->plot_centery, x1, y1);
	}
    }
}


void plot_tick::plot_x_ticks(double start, double end, 
			     double valbuffer, const char *str)
{
  if(valbuffer<start || valbuffer>end)
    return;
  
  if(!pt->is_radial)
    {
      x = ((double) parent->x0) + (valbuffer - start) / (end - start) * 
	((double) (parent->x1 -  parent->x0));
      y = (double) parent->y0;
      int xx = (int) x;
      int yy = (int) y;
      int len = ((int) size)*5;
      
      if(pt->is_big())
	pt->setfont(PLOT_FONT_MEDIUM);
      else
	pt->setfont(PLOT_FONT_SMALL);
      pt->Line(x, y, x, y+5.0+len);
      pt->Text(str, xx+5-4*strlen(str), yy+20+len);
    }
  else
    {
      double len = ((double) size)*5.0+5.0;
      double angle = 2.0 * M_PI * (valbuffer - start) / (end - start);
      if(!pt->counterclockwise)
	angle=-angle;
      angle += M_PI/2.0*double(int(pt->radialtype)-1);

      double x0 = ((double) pt->plot_centerx) + ((double) pt->radius) * 
	cos(angle);
      double x1 = ((double) pt->plot_centerx) + ((double) pt->radius + len) * 
	cos(angle);
      double x2 = ((double) pt->plot_centerx) + 
	((double) pt->radius + len+15.0) * cos(angle);
      double y0 = ((double) pt->plot_centery) - ((double) pt->radius) * 
	sin(angle);
      double y1 = ((double) pt->plot_centery) - ((double) pt->radius + len) * 
	sin(angle);
      double y2 = ((double) pt->plot_centery) - 
	((double) pt->radius + len + 15.0) * sin(angle);

      x=x0;
      y=y0;

      if(pt->is_big())
	pt->setfont(PLOT_FONT_MEDIUM);
      else
	pt->setfont(PLOT_FONT_SMALL);
      pt->Line(x0, y0, x1, y1);
      pt->Text(str, int(x2-3*strlen(str)), int(y2));
    }
}
  
  
void plot_tick::plot_time_ticks(void)
{
  DateTime start=parent->get_start_time();
  DateTime end=parent->get_end_time();
  char buffer[200];

  x = ((double) parent->x0) + (double) dt.difference_minutes(start) / 
    (double) end.difference_minutes(start) * 
    ((double) (parent->x1 -  parent->x0));
  y = (double) parent->y0;

  int xx = (int) x, xxx;
  int yy = (int) y;
  yearType yr = dt.getYear();
  monthType mnt= dt.getMonth();
  dayType day = dt.getDay();
  hourType hr = dt.getHour();
  minuteType min = dt.getMinute();
  secondType sec = dt.getSecond();
  int decade=yr/10;
  int steplen=parent->get_step_length();

  double len = ((double) size)*5.0+5.0;
  double angle = 2.0 * M_PI * ((double) (dt - start)) / 
			       ((double) (end - start));
  if(!pt->counterclockwise)
    angle=-angle;
  angle += M_PI/2.0*double(int(pt->radialtype)-1);

  double anglesign = pt->counterclockwise==True ? 1.0 : -1.0;
  double x0 = ((double) pt->plot_centerx) + ((double) pt->radius) * 
    cos(angle);
  double x1 = ((double) pt->plot_centerx) + ((double) pt->radius + len) * 
    cos(angle);
  double x2 = ((double) pt->plot_centerx-25) + 
    ((double) pt->radius + len+20.0) * cos(angle+anglesign*M_PI/40.0);
  double x3 = ((double) pt->plot_centerx-25) + 
    ((double) pt->radius + len+35.0) * cos(angle+anglesign*M_PI/20.0);
  double y0 = ((double) pt->plot_centery) - ((double) pt->radius) * 
    sin(angle);
  double y1 = ((double) pt->plot_centery) - ((double) pt->radius + len) * 
    sin(angle);
  double y2 = ((double) pt->plot_centery+5) - 
    ((double) pt->radius + len+15.0) * sin(angle+anglesign*M_PI/40.0);
  double y3 = ((double) pt->plot_centery+5) - 
    ((double) pt->radius + len + 22.0) * sin(angle+anglesign*M_PI/20.0);
  
  if(pt->radial_year<=0 || pt->radial_year==MISSING_VALUE)
    {
      x2 = ((double) pt->plot_centerx-5) + 
	((double) pt->radius + len+10.0) * cos(angle);
      x3 = ((double) pt->plot_centerx-10) + 
	((double) pt->radius + len+32.0) * cos(angle+anglesign*M_PI/30);
      y2 = ((double) pt->plot_centery+5) - 
	((double) pt->radius + len+10.0) * sin(angle);
      y3 = ((double) pt->plot_centery+5) - 
	((double) pt->radius + len + 32.0) * sin(angle+anglesign*M_PI/30);
    }

  if(end.difference_minutes(start)>360)
    {
      angle = 2.0 * M_PI * ((double) dt.difference_minutes(start)) / 
	((double) end.difference_minutes(start));
      if(!pt->counterclockwise)
	angle=-angle;
      angle += M_PI/2.0*double(int(pt->radialtype)-1);
    }
  
  angle=double_modulo(angle, 2.0*M_PI);
  
  pt->SetFg("black");
  size=TICK_SMALL;
  
  bool english_month=false;
  if(pt && pt->use_english_month())
    english_month=true;

  switch(type)
    {
    case TICK_SECONDS_SMALL:
      if(first)
	{
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  sprintf(buffer, "%d", yr);
	  pt->Text(buffer, xx-20, yy+65);
	  if(english_month)
	    pt->Text((char *) Month_eng[mnt-1], xx+10, yy+65);
	  else
	    pt->Text((WHAT((char *) Month[mnt-1], 
			   (char *) Month_eng[mnt-1]))  , xx+10, yy+65);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", day);
	  pt->Text(buffer, xx+5, yy+50);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", hr);
	  pt->Text(buffer, xx+5, yy+35);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_SMALL);
	  else
	    pt->setfont(PLOT_FONT_VERYSMALL);
	  sprintf(buffer, "%d", min);
	  pt->Text(buffer, xx, yy+20);
	}

      if(!first && sec==0 &&  !pt->is_radial)
	{
	  if(min==0)
	    {
	      if(hr==0)
		{
		  if(day==1) // start of month
		    {
		      size=TICK_SUPERDUPERLARGE;
		      if(pt->is_big())
			pt->setfont(PLOT_FONT_LARGE);
		      else
			pt->setfont(PLOT_FONT_MEDIUM);
		      
		      if(mnt==1)
			{
			  sprintf(buffer, "%d", yr);
			  pt->Text(buffer, xx+5, yy+65);
			}
		      else
			{
			  if(english_month)
			    pt->Text((char *) Month_eng[mnt-1], xx+5, yy+65);
			  else
			    pt->Text(WHAT((char *) Month[mnt-1], 
					  (char *) Month_eng[mnt-1]), 
				     xx+5, yy+65);
			}
		    }
		  else
		    size=TICK_SUPERLARGE;
		  
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_MEDIUM);
		  else
		    pt->setfont(PLOT_FONT_SMALL);
		  sprintf(buffer, "%d", day);
		  pt->Text(buffer, xx+5, yy+50);
		}
	      else
		size=TICK_VERYLARGE;
	      
	      xxx=(xx+steplen*60*60 < pt->plot_x1) ? 
		xx+steplen*60*60/2-10 : xx;

	      if(pt->is_big())
		pt->setfont(PLOT_FONT_MEDIUM);
	      else
		pt->setfont(PLOT_FONT_SMALL);
	      sprintf(buffer, "%d", hr);
	      pt->Text(buffer, xxx, yy+35);
	    }
	  else
	    size=TICK_LARGE;

	  
	  xxx=(xx+steplen*60 < pt->plot_x1) ? xx+steplen*60/2-10 : xx;

	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_SMALL);
	  else
	    pt->setfont(PLOT_FONT_VERYSMALL);
	  sprintf(buffer, "%d", min);
	  pt->Text(buffer, xxx, yy+20);
	}

      break;

    case TICK_MINUTES: 
      if(first)
	{
	  sprintf(buffer, "%d", yr);
	  pt->Text(buffer, xx-30, yy+60);
	  if(english_month)
	    pt->Text((char *) Month_eng[mnt-1], xx, yy+60);
	  else
	    pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
		     xx, yy+60);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", day);
	  pt->Text(buffer, xx+5, yy+45);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", hr);
	  pt->Text(buffer, xx, yy+30);
	}

      if(!first && min==0 && !pt->is_radial)
	{
	  if(hr==0)
	    {
	      if(day==1) // start of month
		{
		  size=TICK_SUPERLARGE;
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_LARGE);
		  else
		    pt->setfont(PLOT_FONT_MEDIUM);
		  
		  if(mnt==1)
		    {
		      sprintf(buffer, "%d", yr);
		      pt->Text(buffer, xx+5, yy+60);
		    }
		  else
		    {
		      if(english_month)
			pt->Text((char *) Month_eng[mnt-1], xx, yy+60);
		      else
			pt->Text(WHAT((char *) Month[mnt-1], 
				      (char *) Month_eng[mnt-1]), 
				 xx, yy+60);
		    }
		}
	      else
		size=TICK_VERYLARGE;
	    
	      if(pt->is_big())
		pt->setfont(PLOT_FONT_MEDIUM);
	      else
		pt->setfont(PLOT_FONT_SMALL);
	      sprintf(buffer, "%d", day);
	      pt->Text(buffer, xx+5, yy+45);
	    }
	  else
	    size=TICK_LARGE;
	
	  xxx=(xx+steplen*60 < pt->plot_x1) ? xx+steplen*60/2-10 : xx;

	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", hr);
	  pt->Text(buffer, xxx, yy+30);
	}
      
      if(pt->is_big())
	pt->setfont(PLOT_FONT_SMALL);
      else
	pt->setfont(PLOT_FONT_VERYSMALL);
      sprintf(buffer, "%d", min);
      xxx=(xx+steplen < pt->plot_x1) ? xx+steplen/2-5*strlen(buffer)+5 : xx;

      if(!pt->is_radial)
	pt->Text(buffer, xxx, yy+15);
      else
	pt->Text(buffer, 
		 int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					angle<4.0*M_PI/3.0)), 
		 int(y2));

      break;

    case TICK_MINUTES_SMALL:
      if(first)
	{
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  sprintf(buffer, "%d", yr);
	  pt->Text(buffer, xx-10, yy+65);
	  if(english_month)
	    pt->Text((char *) Month_eng[mnt-1], xx+5, yy+50);
	  else
	    pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
		     xx+5, yy+50);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", day);
	  pt->Text(buffer, xx+5, yy+35);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_SMALL);
	  else
	    pt->setfont(PLOT_FONT_VERYSMALL);
	  sprintf(buffer, "%d", hr);
	  pt->Text(buffer, xx, yy+20);
	}
      
      if(!first && min==0l && (!pt->is_radial || pt->radial_min>1440))
	{
	  if(hr==0 && !pt->is_radial)
	    {
	      if(day==1) // start of month
		{
		  size=TICK_SUPERLARGE;
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_LARGE);
		  else
		    pt->setfont(PLOT_FONT_MEDIUM);
		  
		  if(mnt==1)
		    {
		      sprintf(buffer, "%d", yr);
		      pt->Text(buffer, xx-10, yy+50);
		    }
		  else
		    {
		      if(english_month)
			pt->Text((char *) Month_eng[mnt-1], xx+5, yy+50);
		      else
			pt->Text(WHAT((char *) Month[mnt-1], 
				      (char *) Month_eng[mnt-1]), 
				 xx+5, yy+50);
		    }
		}
	      else
		size=TICK_VERYLARGE;
	    
	      xxx=(xx+steplen*60*24 < pt->plot_x1) ? 
		xx+steplen*60*24/2-10 : xx;

	      if(pt->is_big())
		pt->setfont(PLOT_FONT_MEDIUM);
	      else
		pt->setfont(PLOT_FONT_SMALL);
	      sprintf(buffer, "%d", day);

	      if(!pt->is_radial)
		pt->Text(buffer, int(xxx), int(yy+35));
	      else
		pt->Text(buffer, 
			 int(x3-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
						angle<4.0*M_PI/3.0)), 
			 int(y3));
	    }
	  else
	    size=TICK_LARGE;
	
	  int xxx=(xx+steplen*60 < pt->plot_x1) ? xx+steplen*60/2-10 : xx;

	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_SMALL);
	  else
	    pt->setfont(PLOT_FONT_VERYSMALL);
	  sprintf(buffer, "%d", hr);
	  
	  if(!pt->is_radial)
	    pt->Text(buffer, int(xxx), int(yy+20));
	  else
	    pt->Text(buffer, 
		     int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 && 
					    angle<4.0*M_PI/3.0)),
		     int(y2));
	}

      break; 
    case TICK_HOURS: 
      if(first)
	{
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  sprintf(buffer, "%d", yr);
	  pt->Text(buffer, int(xx), int(yy+60));
	  if(english_month)
	    pt->Text((char *) Month_eng[mnt-1], int(xx), int(yy+45));
	  else
	    pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
		     int(xx), int(yy+45));
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", day);
	  pt->Text(buffer, int(xx+5), int(yy+30));
	}

      if(!first && hr==0 && (!pt->is_radial || pt->radial_min>1440))
	{
	  if(day==1 && !pt->is_radial) // start of month
	    {
	      size=TICK_VERYLARGE;
	      if(pt->is_big())
		pt->setfont(PLOT_FONT_LARGE);
	      else
		pt->setfont(PLOT_FONT_MEDIUM);

	      if(mnt==1)
		{
		  sprintf(buffer, "%d", yr);
		  pt->Text(buffer, int(xx), int(yy+45));
		}
	      else
		{
		  if(english_month)
		    pt->Text((char *) Month_eng[mnt-1], int(xx), int(yy+45));
		  else
		    pt->Text(WHAT((char *) Month[mnt-1], 
				  (char *) Month_eng[mnt-1]), 
			     int(xx), int(yy+45));
		}
	    }
	  else
	    size=TICK_LARGE;

	  xxx=(xx+steplen*24 < pt->plot_x1) ? xx+steplen*24/2-10 : xx;

	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  sprintf(buffer, "%d", day);
	  if(!pt->is_radial)
	    pt->Text(buffer, int(xxx), int(yy+30));
	  else
	    pt->Text(buffer, 
		     int(x3-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					    angle<4.0*M_PI/3.0)), 
		     int(y3));
	}

      if(pt->is_big())
	pt->setfont(PLOT_FONT_SMALL);
      else
	pt->setfont(PLOT_FONT_VERYSMALL);
      sprintf(buffer, "%d", hr);
      xxx=(xx+steplen < pt->plot_x1) ? xx+steplen/2-5*strlen(buffer)+5 : xx;
      if(!pt->is_radial)
	pt->Text(buffer, xxx, yy+15);
      else
	pt->Text(buffer, 
		 int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					angle<4.0*M_PI/3.0)), 
		 int(y2));

      break;

    case TICK_HOURS_SMALL:
      if(first)
	{
	  sprintf(buffer, "%d", yr);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  pt->Text(buffer, xx, yy+50);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  if(english_month)
	    pt->Text((char *) Month_eng[mnt-1], xx+5, yy+35);
	  else
	    pt->Text((char *) (WHAT((char *) Month[mnt-1], 
				    (char *) Month_eng[mnt-1])), 
		     xx+5, yy+35);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_SMALL);
	  else
	    pt->setfont(PLOT_FONT_VERYSMALL);
	  sprintf(buffer, "%d", day);
	  pt->Text(buffer, xx+5, yy+20);
	}

      if(!first && hr==0)
	{
	  if(day==1 && !pt->is_radial) // start of month
	    {
	      if(mnt==1)
		{
		  size=TICK_SUPERLARGE;
		  sprintf(buffer, "%d", yr);
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_LARGE);
		  else
		    pt->setfont(PLOT_FONT_MEDIUM);
		  pt->Text(buffer, xx, yy+50);
		}
	      else
		size=TICK_VERYLARGE;
	      
	      xxx=(xx+24*30*steplen < pt->plot_x1) ? xx+steplen*24*30/2-10 : 
		xx;

	      if(pt->is_big())
		pt->setfont(PLOT_FONT_MEDIUM);
	      else
		pt->setfont(PLOT_FONT_SMALL);
	      if(english_month)
		pt->Text((char *) Month_eng[mnt-1], xxx, yy+35);
	      else
		pt->Text(WHAT((char *) Month[mnt-1], 
			      (char *) Month_eng[mnt-1]), 
			 xxx, yy+35);
	    }
	  else
	    size=TICK_LARGE;

	  xxx=(xx+24*steplen < pt->plot_x1) ? xx+24*steplen/2-10 : xx;

	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_SMALL);
	  else
	    pt->setfont(PLOT_FONT_VERYSMALL);
	  sprintf(buffer, "%d", day);
	  if(!pt->is_radial)
	    pt->Text(buffer, xxx, yy+20);
	  else
	    pt->Text(buffer, 
		     int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					    angle<4.0*M_PI/3.0)), 
		     int(y2));
	}

      break;

    case TICK_DAYS:
      if(first)
	{
	  sprintf(buffer, "%d", yr);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  pt->Text(buffer, int(xx-15), int(yy+55));
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  if(english_month)
	    pt->Text((char *) Month_eng[mnt-1], int(xx-25), int(yy+30));
	  else
	    pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
		     int(xx-25), int(yy+30));
	}

      if(!first && day==1) // start of month
	{
	  if(mnt==1 && !pt->is_radial)
	    {
	      size=TICK_VERYLARGE;
	      sprintf(buffer, "%d", yr);
	      if(pt->is_big())
		pt->setfont(PLOT_FONT_LARGE);
	      else
		pt->setfont(PLOT_FONT_MEDIUM);
	      pt->Text(buffer, int(xx+10), int(yy+55));
	    }
	  else
	    size=TICK_LARGE;
	  
	  xxx=(xx+30*steplen < pt->plot_x1) ? xx+30*steplen/2-10 : xx+10;

	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  if(!pt->is_radial)
	    {
	      if(english_month)
		pt->Text((char *) Month_eng[mnt-1], int(xx+15), int(yy+30));
	      else
		pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
			 int(xx+15), int(yy+30));
	    }
	  else
	    {
	      if(english_month)
		pt->Text((char *) Month_eng[mnt-1], 
			 int(x3-15*(angle>2.0*M_PI/3.0 &&
				    angle<4.0*M_PI/3.0)), int(y3));
	      else
		pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
			 int(x3-15*(angle>2.0*M_PI/3.0 &&
				    angle<4.0*M_PI/3.0)), int(y3));
	    }
	}
      
     
      if(pt->is_big())
	pt->setfont(PLOT_FONT_SMALL);
      else
	pt->setfont(PLOT_FONT_VERYSMALL);
      sprintf(buffer, "%d", day);
      xxx=(xx+steplen < pt->plot_x1) ? xx+steplen/2-5*strlen(buffer)+3 : xx;
      if(!pt->is_radial)
	pt->Text(buffer, int(xxx), int(yy+15));
      else
	pt->Text(buffer, 
		 int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					angle<4.0*M_PI/3.0)), 
		 int(y2));

      break;
    case TICK_DAYS_SMALL: 
      if(first)
	{
	  sprintf(buffer, "%d", yr);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_VERYLARGE);
	  else
	    pt->setfont(PLOT_FONT_LARGE);
	  pt->Text(buffer, int(xx-25), int(yy+63));
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  if(english_month)
	    pt->Text((char *) Month_eng[mnt-1], int(xx-15), int(yy+39));
	  else
	    pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
		     int(xx-15), int(yy+39));
	}

      if(!first && day==1) // start of month
	{
	  if(mnt==1 && !pt->is_radial)
	    {
	      size=TICK_SUPERDUPERLARGE;
	      sprintf(buffer, "%d", yr);
	      if(pt->is_big())
		pt->setfont(PLOT_FONT_VERYLARGE);
	      else
		pt->setfont(PLOT_FONT_LARGE);
	      pt->Text(buffer, int(xx+15), int(yy+63));
	    }
	  else
	    size=TICK_SUPERLARGE;

	  xxx=(xx+30*steplen < pt->plot_x1) ? xx+30*steplen/2-15 : xx+25;
	  if(first)
	    xxx=xx;

	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  if(!pt->is_radial)
	    {
	      if(english_month)
		pt->Text((char *) Month_eng[mnt-1], int(xxx), int(yy+39));
	      else
		pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
			 int(xxx), int(yy+39));
	    }
	  else
	    {
	      if(english_month)
		pt->Text((char *) Month_eng[mnt-1],
			 int(x3-15*(angle>2.0*M_PI/3.0 &&
				    angle<4.0*M_PI/3.0)), 
			 int(y3) );
	      else
		pt->Text(WHAT((char *) Month[mnt-1], (char *) Month_eng[mnt-1]), 
			 int(x3-15*(angle>2.0*M_PI/3.0 &&
				    angle<4.0*M_PI/3.0)), 
			 int(y3));
	    }
	  
	}
      else if(day%5 == 1 && day!=31)
	size=TICK_LARGE;

      break;
    case TICK_MONTHS:
      if(parent->show_year())
	{
	  sprintf(buffer, "%d", yr);
	  if(first && mnt!=1)
	    {
	      if(yr%10==0)
		{
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_LARGE);
		  else
		    pt->setfont(PLOT_FONT_MEDIUM);
		}
	      else
		{
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_MEDIUM);
		  else
		    pt->setfont(PLOT_FONT_SMALL);
	    }
	      pt->Text(buffer, int(xx-13), int(yy+30));
	    }
	  else if(!pt->is_radial)
	    {
	      xxx = (xx+12*steplen < pt->plot_x1) ? xx+12*steplen/2-12 : xx+5;
	      
	      if(yr%10==0 && mnt==1)
		{
		  size=TICK_VERYLARGE;
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_LARGE);
		  else
		    pt->setfont(PLOT_FONT_MEDIUM);
		  pt->Text(buffer, int(xxx), int(yy+45));
		}
	      else if(mnt==1)
		{
		  size=TICK_LARGE;
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_MEDIUM);
		  else
		    pt->setfont(PLOT_FONT_SMALL);
		  pt->Text(buffer, int(xxx), int(yy+30));
		}
	    }
	}
      
      xxx=(xx+steplen < pt->plot_x1) ? xx+steplen/2-10 : xx;
      if(first)
	xxx=xx;
      
      if(pt->is_big())
	pt->setfont(PLOT_FONT_SMALL);
      else
	pt->setfont(PLOT_FONT_VERYSMALL);
      if(english_month)
	strcpy(buffer, (char *) Month_eng_short[mnt-1]);
      else
	strcpy(buffer, WHAT((char *) Month_short[mnt-1], 
			    (char *) Month_eng_short[mnt-1]));
      if(!pt->is_radial)
	pt->Text(buffer, int(xxx), int(yy+15));
      else
	pt->Text(buffer, 
		 int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					angle<4.0*M_PI/3.0)), 
		 int(y2));
      
      break;
    case TICK_MONTHS_SMALL:
      if(parent->show_year())
	{
	  sprintf(buffer, "%d", yr);
	  if(first && mnt!=1)
	    {
	      if(pt->is_big())
		pt->setfont(PLOT_FONT_MEDIUM);
	      else
		pt->setfont(PLOT_FONT_SMALL);
	      pt->Text(buffer, int(xx-5), int(yy+35));
	    }
	  else
	    {
	      xxx=(xx+12*steplen < pt->plot_x1) ? xx+12*steplen/2-12 : xx+2;
	      
	      if(yr%10==0 && mnt==1 && !pt->is_radial)
		{
		  size=TICK_VERYLARGE;
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_LARGE);
		  else
		    pt->setfont(PLOT_FONT_MEDIUM);
		  pt->Text(buffer, int(xxx), int(yy+35));
		}
	      else if(mnt==1)
		{
		  size=TICK_LARGE;
		  if(pt->is_big())
		    pt->setfont(PLOT_FONT_MEDIUM);
		  else
		    pt->setfont(PLOT_FONT_SMALL);
		  if(!pt->is_radial)
		    pt->Text(buffer, int(xxx), int(yy+20));
		  else
		    pt->Text(buffer, 
			     int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
						    angle<4.0*M_PI/3.0)), 
			     int(y2));
		}
	    }
	}
      break;
    case TICK_YEARS:
      sprintf(buffer, "%d", yr);
      xxx=(xx+steplen < pt->plot_x1) ? xx+steplen/2-12 : xx;
      if(yr%100==0 && !pt->is_radial)
	{
	  size=TICK_VERYLARGE;
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  pt->Text(buffer, int(xxx), int(yy+25));
	}
      else if(yr%10==0 && !pt->is_radial)
	{
	  size=TICK_LARGE;
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  pt->Text(buffer, int(xxx), int(yy+20));
	}
      else
	{
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_SMALL);
	  else
	    pt->setfont(PLOT_FONT_VERYSMALL);
	  if(!pt->is_radial)
	    pt->Text(buffer, int(xxx), int(yy+15));
	  else
	    pt->Text(buffer, 
		     int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					    angle<4.0*M_PI/3.0)), 
		     int(y2));
	}
      break;
    case TICK_YEARS_SMALL:
      sprintf(buffer, "%d0", decade);
      xxx=(xx+10*steplen < pt->plot_x1) ? xx+10*steplen/2-10 : xx;
      if(yr%100==0 && !pt->is_radial)
	{
	  size=TICK_VERYLARGE;
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  pt->Text(buffer, int(xxx), int(yy+25));
	}
      else if(yr%10==0 && !pt->is_radial)
	{
	  size=TICK_LARGE;
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  pt->Text(buffer, int(xxx), int(yy+20));
	}
      else if(first)
	{
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_MEDIUM);
	  else
	    pt->setfont(PLOT_FONT_SMALL);
	  
	  if(!pt->is_radial)
	    pt->Text(buffer, int(xx-10), int(yy+20));
	  else
	    pt->Text(buffer, 
		     int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
					    angle<4.0*M_PI/3.0)), 
		     int(y2));
	}
      break;
    case TICK_DECADES: 
    default:
      if(first && decade%10!=0)
	{
	  sprintf(buffer, "%d0", decade);
	  if(pt->is_big())
	    pt->setfont(PLOT_FONT_LARGE);
	  else
	    pt->setfont(PLOT_FONT_MEDIUM);
	  pt->Text(buffer, int(xx), int(yy+15));
	}
      else
	{
	  sprintf(buffer, "%d0", decade);
	  xxx=(xx+steplen < pt->plot_x1) ? xx+steplen/2-15 : xx;
	  if(decade%10==0)
	    {
	      size=TICK_LARGE;
	      if(pt->is_big())
		pt->setfont(PLOT_FONT_LARGE);
	      else
		pt->setfont(PLOT_FONT_MEDIUM);
	      if(!pt->is_radial)
		pt->Text(buffer, int(xxx), int(yy+20));
	      else
		pt->Text(buffer, 
			 int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
						angle<4.0*M_PI/3.0)), 
			 int(y2));
	    }
	  else
	    {
	      if(!pt->is_radial)
		pt->Text(buffer, int(xxx), int(yy+15));
	      else
		pt->Text(buffer, 
			 int(x2-strlen(buffer)*(angle>2.0*M_PI/3.0 &&
						angle<4.0*M_PI/3.0)), 
			 int(y2));
	    }
	}

      break;
    }

  if(pt->is_radial)
    {
      len=5.0+((double) size)*5.0;
      x0 = ((double) pt->plot_centerx) + ((double) pt->radius) * 
	cos(angle);
      x1 = ((double) pt->plot_centerx) + ((double) pt->radius + len) * 
	cos(angle);
      y0 = ((double) pt->plot_centery) - ((double) pt->radius) * 
	sin(angle);
      y1 = ((double) pt->plot_centery) - ((double) pt->radius + len) * 
	sin(angle);
    }

  if(pt->is_big())
    pt->Set_No_Dashes(3 + (int) size);
  else
    pt->Set_No_Dashes(1 + (int) size);

  if(!pt->is_radial)
    pt->Line(x, y, x, y+5.0+((double) size)*5.0);
  else
    pt->Line(x0, y0, x1, y1);
}

void plot_tick::do_plot(void)
{
  pt->SetFg("black");
  
  if(timeserie_tick)
    {
      plot_time_ticks();
      return;
    }
  
  char buffer[200];
  double start=parent->get_start();
  double end=parent->get_end();
  double valbuffer=value;
  AXIS_SCALING scaling=parent->get_scaling();
  if(scaling==AXIS_LOGARITHMIC)
    {
      start     = log10(start);
      end       = log10(end);
      valbuffer = log10(value);
    }
  else if(scaling==AXIS_LOGIT_PERCENT)
    {
      start     = logit(start,true);
      end       = logit(end,true);
      valbuffer = logit(value,true);
    }
  else if(scaling==AXIS_LOGIT_ABSOLUTE)
    {
      start     = logit(start,false);
      end       = logit(end,false);
      valbuffer = logit(value,false);
    }
  else if(scaling==AXIS_PROBIT_PERCENT)
    {
      start     = probit(start,true);
      end       = probit(end,true);
      valbuffer = probit(value,true);
    }
  else if(scaling==AXIS_PROBIT_ABSOLUTE)
    {
      start     = probit(start,false);
      end       = probit(end,false);
      valbuffer = probit(value,false);
    }
  
  if(size == TICK_SMALL)
    {
      if(pt->is_big())
	pt->setfont(PLOT_FONT_SMALL);
      else
	pt->setfont(PLOT_FONT_VERYSMALL);
      if(pt->is_big())
	pt->Set_No_Dashes(4);
      else
	pt->Set_No_Dashes(2);
    }
  else if(size == TICK_LARGE)
    {
      if(pt->is_big())
	pt->setfont(PLOT_FONT_MEDIUM);
      else
	pt->setfont(PLOT_FONT_SMALL);
      if(pt->is_big())
	pt->Set_No_Dashes(6);
      else
	pt->Set_No_Dashes(3);
    }
  
  if(type!=TICK_CATEGORICAL)
    set_number_as_string(buffer, value, deci, 4, true);
  else
    strcpy(buffer, title);
  
  if(parent->get_axis_type() == NORMAL_X_AXIS || 
     parent->get_axis_type() == CATEGORICAL_X_AXIS)
    plot_x_ticks(start, end, valbuffer, buffer);
  else // Y-axis
    plot_y_ticks(start, end, valbuffer, buffer);
}


TICK_TYPE plot_tick::get_type(void)
{
  return type;
}




// *********************************************
//
//              PLOT_AXIS_SCALING
// Represent a scaling choice for an axis
// 
// *********************************************

void plot_axis_scaling::Create(widget parent, plot_axis *ipt, 
			       bool logit_probit_possible)
{
  pt=NULL;
  logit_probit=logit_probit_possible;
  char *items[]={WHAT((char *) "Line�r",(char *) "Linear"),
		 WHAT((char *) "Logaritmisk",(char *) "Logarithmic"),
		 WHAT((char *) "Logit",(char *) "Logit"),
		 WHAT((char *) "Probit",(char *) "Probit")};
  vbuild(parent, items,logit_probit_possible ? 4 : 2,0);
  pt=ipt;
}

void plot_axis_scaling::pushed(const char *)
{
  if(pt)
    {
      int num=(*this)();
      AXIS_SCALING scaling=AXIS_UNKNOWN_SCALING;
      
      switch(num)
	{
	case 0:
	  scaling=AXIS_LINEAR;
	  break;
	case 1:
	  scaling=AXIS_LOGARITHMIC;
	  break;
	case 2:
	  if(pt->do_percent())
	    scaling=AXIS_LOGIT_PERCENT;
	  else
	    scaling=AXIS_LOGIT_ABSOLUTE;
	  break;
	case 3:
	  if(pt->do_percent())
	    scaling=AXIS_PROBIT_PERCENT;
	  else
	    scaling=AXIS_PROBIT_ABSOLUTE;
	  break;
	default:
	  scaling=AXIS_UNKNOWN_SCALING;
	  break;
	}
      
      pt->scaling_changed(scaling);
    }
}

AXIS_SCALING plot_axis_scaling::get_scaling(bool is_percent)
{
  int num=(*this)();
  AXIS_SCALING scaling=AXIS_UNKNOWN_SCALING;
  
  switch(num)
    {
    case 0:
      scaling=AXIS_LINEAR;
      break;
    case 1:
      scaling=AXIS_LOGARITHMIC;
      break;
    case 2:
      if(is_percent)
	scaling=AXIS_LOGIT_PERCENT;
      else
	scaling=AXIS_LOGIT_ABSOLUTE;
      break;
    case 3:
      if(is_percent)
	scaling=AXIS_PROBIT_PERCENT;
      else
	scaling=AXIS_PROBIT_ABSOLUTE;
      break;
    default:
      scaling=AXIS_UNKNOWN_SCALING;
      break;
    }
  
  return scaling;
}

void plot_axis_scaling::Set(AXIS_SCALING new_scaling)
{
  switch(new_scaling)
    {
    case AXIS_LINEAR:
      SetFocus(0);
      break;
    case AXIS_LOGARITHMIC:
      SetFocus(1);
      break;
    case AXIS_LOGIT_PERCENT:
    case AXIS_LOGIT_ABSOLUTE:
      if(logit_probit)
	SetFocus(2);
      else
	Beep(1);
      break;
    case AXIS_PROBIT_PERCENT:
    case AXIS_PROBIT_ABSOLUTE:
      if(logit_probit)
	SetFocus(3);
      else
	Beep(1);
      break;
    case AXIS_UNKNOWN_SCALING:
    default:
      Beep(1);
      err.build(mainwin::toplevel, 
		WHAT((char *) "Programfeil!", (char *) "Program error!"),
		WHAT((char *) "Ukjent akse-skalering!", 
		     (char *) "Unknown axis scaling!"));
      break;
    }

  if(pt)
    pt->scaling_changed(new_scaling);
}

// *********************************************
//
//                 PLOT_AXIS
// Represent an axis in the plot
//
// *********************************************


plot_axis::plot_axis()
{
  ticks=NULL;
  pt=NULL;
  numticks=0;
  type=AXISTYPE_UNKNOWN;
  isempty=True;
  iscopy=False;
  original=NULL;
  showyear=True;
  scale_built=False;
  numcat=0;
  catstr=NULL;
  coord_built=false;
  do_nicen_start_end=true;
}


plot_axis::~plot_axis()
{
  if(ticks)
    delete [] ticks;
  ticks=NULL;
  numticks=0;
  if(catstr && numcat>0)
    doubledelete(catstr,numcat);
  coord_built=false;
}

// Creates the axis, storing necessary info;
void plot_axis::Create(const char *newtitle, 
		       int newx0, int newy0, int newx1, int newy1,
		       AXIS_TYPE axis_type, PLOT_FONT_SIZE fontsize,
		       plot_module *ipt, AXIS_SCALING axis_scaling,
		       bool nicen_start_end)
{
  do_nicen_start_end=nicen_start_end;
  axisnumber = 1;
  strcpy(title, newtitle);
  x0=newx0;
  y0=newy0;
  x1=newx1;
  y1=newy1;
  type=axis_type;
  font_size=fontsize;
  pt=ipt;
  start=non_niced_start=MISSING_VALUE;
  end=non_niced_end=MISSING_VALUE;
  origstart=MISSING_VALUE;
  origend=MISSING_VALUE;
  scaling=axis_scaling;
  iscopy=False;
  isempty=False;

  start_time=end_time=origstart_time=origend_time=NoDateTime;
  old_index=max_index=0;

  int i;
  for(i=0;i<BACK_BUFFER_SIZE;i++)
    {
      oldstart_time[i]=oldend_time[i]=NoDateTime;
      old_scaling[i]=axis_scaling;
      oldstart[i]=oldend[i]=MISSING_VALUE;
    }

  if(axis_type==CATEGORICAL_X_AXIS && axis_scaling!=AXIS_LINEAR)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Programfeil", (char *) "Program error"), 
		WHAT((char *) "Kateogriske variable kan ikke "
		     "log/logit/probit-transformeres!", 
		     (char *) "Categorical variables cannot be "
		     "log/logit/probit-transformed!"));
      scaling=AXIS_LINEAR;
      for(i=0;i<BACK_BUFFER_SIZE;i++)
	old_scaling[i]=AXIS_LINEAR;
    }
}

void plot_axis::Createradial(int axis_number, const char *newtitle, 
			     AXIS_TYPE axis_type, PLOT_FONT_SIZE fontsize, 
			     plot_module *ipt, bool is_empty, 
			     AXIS_SCALING axis_scaling)
{
  axisnumber = axis_number;
  strcpy(title, newtitle);
  pt=ipt;
  old_index=max_index=0;
  scaling=old_scaling[old_index]=axis_scaling;

  switch(axis_number % 4)
    {
    case 0:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=x0+pt->radius;
      y1=pt->plot_centery;
      break;
    case 1:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=pt->plot_centerx;
      y1=y0-pt->radius;
      break;
    case 2:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=x0-pt->radius;
      y1=pt->plot_centery;
      break;
    case 3:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=pt->plot_centerx;
      y1=y0+pt->radius;
      break;
    }

  type=axis_type;
  font_size=fontsize;
  start=non_niced_start=MISSING_VALUE;
  end=non_niced_end=MISSING_VALUE;
  origstart=MISSING_VALUE;
  origend=MISSING_VALUE;
  isempty=is_empty;
  
  start_time=end_time=origstart_time=origend_time=NoDateTime;
  for(int i=0;i<BACK_BUFFER_SIZE;i++)
    {
      oldstart_time[i]=oldend_time[i]=NoDateTime;
      oldstart[i]=oldend[i]=MISSING_VALUE;
    }
}

void plot_axis::Create_similar(int axis_number, plot_axis *orig)
{
  axisnumber = axis_number;
  strcpy(title, orig->title);
  pt=orig->pt;
  original=orig;

  type=orig->type;
  font_size=orig->font_size;
  start=non_niced_start=MISSING_VALUE;
  end=non_niced_end=MISSING_VALUE;
  origstart=MISSING_VALUE;
  origend=MISSING_VALUE;
  old_index=max_index=0;
  scaling=old_scaling[old_index]=original->scaling;
  isempty=False;
  iscopy=False;
  
  start_time=end_time=origstart_time=origend_time=NoDateTime;
  for(int i=0;i<BACK_BUFFER_SIZE;i++)
    {
      oldstart_time[i]=oldend_time[i]=NoDateTime;
      oldstart[i]=oldend[i]=MISSING_VALUE;
    }
}

void plot_axis::Createcopy(int axis_number, plot_axis *orig, 
			   AXIS_TYPE axis_type)
{
  Createcopy(axis_number, orig);
  type=axis_type;
}

void plot_axis::Createcopy(int axis_number, plot_axis *orig)
{
  axisnumber = axis_number;
  strcpy(title, orig->title);
  pt=orig->pt;
  original=orig;

  switch(axis_number % 4)
    {
    case 0:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=x0+pt->radius;
      y1=pt->plot_centery;
      break;
    case 1:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=pt->plot_centerx;
      y1=y0-pt->radius;
      break;
    case 2:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=x0-pt->radius;
      y1=pt->plot_centery;
      break;
    case 3:
      x0=pt->plot_centerx;
      y0=pt->plot_centery;
      x1=pt->plot_centerx;
      y1=y0+pt->radius;
      break;
    }

  type=orig->type;
  font_size=orig->font_size;
  start=non_niced_start=MISSING_VALUE;
  end=non_niced_start=MISSING_VALUE;
  origstart=MISSING_VALUE;
  origend=MISSING_VALUE;
  
  old_index=max_index=0;
  scaling=old_scaling[old_index]=original->scaling;
  isempty=False;
  iscopy=True;
  
  start_time=end_time=origstart_time=origend_time=NoDateTime;
  for(int i=0;i<BACK_BUFFER_SIZE;i++)
    {
      oldstart_time[i]=oldend_time[i]=NoDateTime;
      oldstart[i]=oldend[i]=MISSING_VALUE;
    }
}

void plot_axis::set_categorical(int num_categories, char const* const* category_str)
{
  if(catstr)
    doubledelete(catstr,numcat);
  numcat=num_categories;
  catstr=new char*[numcat];
  for(int i=0;i<numcat;i++)
    {
      catstr[i]=new char[100];
      strcpy(catstr[i], category_str[i]);
    }
  type=CATEGORICAL_X_AXIS;
  
  origstart=start=1.0-0.05;
  origend=end=double(numcat)+0.05;
  for(int i=0;i<BACK_BUFFER_SIZE;i++)
    {
      oldstart[i]=start;
      oldend[i]=end;
    }

  nicen();
}
  
// adds a start and end point and see if they're smaller/larger than
// the already existing start/end point;
void plot_axis::add_start_end(double newstart, double newend)
{
  if(isempty)
    return;
  
  if(newstart!=MISSING_VALUE && (newstart<start || start==MISSING_VALUE))
    start=non_niced_start=newstart;

  if(newend!=MISSING_VALUE && (newend>end || end==MISSING_VALUE))
    end=non_niced_end=newend;
}

// starts adding new extreme values
void plot_axis::start_adding(void) 
{
  if(isempty)
    return;
  
  
  oldstart[old_index]=start;
  oldend[old_index]=end;
  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;
}

// ends adding new extreme values
bool plot_axis::end_adding(void) 
{
  if(isempty)
    return True;

  if(scaling!=AXIS_LINEAR && type==TIME_X_AXIS)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Feil", "Error")),
		(char *) (WHAT("Tids-aksen kan ikke v�re "
			       "logaritmisk/logit/probit!",
			       "The time axis can't be "
			       "logarithmic/logit/probit!")));
      return False;
    }

  if(pt->is_radial && scaling!=AXIS_LINEAR && 
     (type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS))
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Feil", "Error")),
		(char *) (WHAT("Polar-aksen kan ikke v�re "
			       "logaritmisk/logit/probit!",
			       "A polar axis can't be "
			       "logarithmic/logit/probit!")));
      return False;
    }

  if(scaling!=AXIS_LINEAR && start<=0.0)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Feil", "Error")),
		(char *) (WHAT("Negative tall eller null-verdi ble funnet "
			       "for en av log/logit/probit-aksene!",
			       "A negative or zero value was found in one of "
			       "the log/logit/probit axes!")));
      return False;
    }

  if((scaling==AXIS_LOGIT_PERCENT || scaling==AXIS_PROBIT_PERCENT) && 
     end>=100.0)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Feil", "Error")),
		(char *) (WHAT("Tall over eller lik 100%% ble funnet "
			       "for en av logit/probit-aksene!",
			       "A number above or equal 100%% value "
			       "was found in one of "
			       "the logit/probit axes!")));
      return False;
    }

  if((scaling==AXIS_LOGIT_ABSOLUTE || scaling==AXIS_PROBIT_ABSOLUTE) && 
     end>=100.0)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Feil", "Error")),
		(char *) (WHAT("Tall over eller lik 1.0 ble funnet "
			       "for en av logit/probit-aksene!",
			       "A number above or equal 1.0 value "
			       "was found in one of "
			       "the logit/probit axes!")));
      return False;
    }
  
  if(pt->is_radial && iscopy && original)
    {
      start=original->start;
      end=original->end;
      non_niced_start=original->non_niced_start;
      non_niced_end=original->non_niced_end;
      scaling=original->scaling;
    }
  else if(pt->is_radial && pt->startyaxisatzero && scaling==AXIS_LINEAR)
    {
      if(-start>end)
	end=non_niced_end=-start;
      start=non_niced_start=0.0;
    }
  else if(start==end)
    {
      end+=0.01;
      non_niced_end+=0.01;
    }
  
  nicen();

  if(origstart==MISSING_VALUE)
    origstart=start;
  if(origend==MISSING_VALUE)
    origend=end;

  oldstart[old_index]=start;
  oldend[old_index]=end;
  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;

  return True;
}

void plot_axis::set_font_size(PLOT_FONT_SIZE fontsize)
{
  font_size=fontsize;
}

PLOT_FONT_SIZE plot_axis::get_font_size(void)
{
  return font_size;
}


void plot_axis::check_old(void)
{
  while(old_index>=BACK_BUFFER_SIZE)
    {
      for(int i=0;i<=(BACK_BUFFER_SIZE-2);i++)
	{
	  oldstart[i]=oldstart[i+1];
	  oldend[i]=oldend[i+1];
	  oldstart_time[i]=oldstart_time[i+1];
	  oldend_time[i]=oldend_time[i+1];
	  old_scaling[i]=old_scaling[i+1];
	}
      old_index--;
      max_index=old_index;
    }
}

void plot_axis::update_old_index(void)
{  
  old_index++;
  max_index=old_index;
  check_old();
  
  oldstart[old_index]=start;
  oldend[old_index]=end;
  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;
}


// Set the start/end point no matter what the previous values were;
void plot_axis::set_start_end(double newstart, double newend)
{
  if(isempty)
    return;

  if(origstart==MISSING_VALUE)
    origstart=start;
  if(origend==MISSING_VALUE)
    origend=end;

  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;
  
  start=non_niced_start=newstart;
  end=non_niced_end=newend;
  
  nicen();

  update_old_index();
}

void plot_axis::set_min(double new_min)
{
  if(isempty)
    return;
  
  if(origstart==MISSING_VALUE)
    origstart=start;
  
  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;

  start=non_niced_start=new_min;
  nicen();
  
  update_old_index();
}

void plot_axis::set_max(double new_max)
{
  if(isempty)
    return;

  if(origend==MISSING_VALUE)
    origend=end;

  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;

  end=non_niced_end=new_max;
  nicen();
  
  update_old_index();
}

void plot_axis::set_min(DateTime new_min)
{
  if(isempty)
    return;

  if(origstart_time==NoDateTime)
    origstart_time=start_time;

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;
  
  start_time=new_min;
  nicen_timeaxis();

  update_old_index();
}

void plot_axis::set_max(DateTime new_max)
{
  if(isempty)
    return;

  if(origend_time==NoDateTime)
    origend_time=end_time;

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;

  end_time=new_max;
  nicen_timeaxis();

  update_old_index();
}


const char *plot_axis::get_title(void)
{
  return title;
}


// adds a start and end point and see if they're smaller/larger than
// the already existing start/end point;
void plot_axis::add_start_end(DateTime newstart, DateTime newend)
{
  if(newstart<start_time || start_time==NoDateTime)
    start_time=newstart;

  if(newend>end_time || end_time==NoDateTime)
    end_time=newend;
}


// starts adding new extreme values
void plot_axis::start_adding_time(void) 
{
  if(isempty)
    return;

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
}


// ends adding new extreme values
bool plot_axis::end_adding_time(void) 
{
  if(isempty)
    return True;

  if(scaling!=AXIS_LINEAR)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Feil", "Error")),
		(char *) (WHAT("Tids-aksen kan ikke v�re log/logit/probit!",
			       "The time axis can't be log/logit/probit!")));
      return False;
    }

  nicen_timeaxis();

  if(origstart_time==NoDateTime)
    origstart_time=start_time;
  if(origend_time==NoDateTime)
    origend_time=end_time;

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;

  return True;
}

void plot_axis::set_radial_start_end(int years, int mins)
{
  if(isempty)
    return;

  if(origstart_time==NoDateTime)
    origstart_time=start_time;
  if(origend_time==NoDateTime)
    origend_time=end_time;

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;

  DateTime dt1(1901, 1, 1, 0, 0);
  DateTime dt2;
  
  if(years>0 && years!=MISSING_VALUE)
    {
      DateTime dtbuff(1901+years-1,1,1);
      dt2=dtbuff.EndOfYear();
    }
  else
    dt2=dt1;
  dt2+=60*mins;

  start_time=dt1;
  end_time=dt2;

  nicen_timeaxis();

  update_old_index();
}

// Set the start/end point no matter what the previous values were;
void plot_axis::set_start_end(DateTime newstart, DateTime newend)
{
  if(isempty)
    return;
  
  if(origstart_time==NoDateTime)
    origstart_time=start_time;
  if(origend_time==NoDateTime)
    origend_time=end_time;
  
  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;
  
  start_time=newstart;
  end_time=newend;
  
  nicen_timeaxis();
  
  update_old_index();
}

void plot_axis::set_show_year(bool show_year)
{
  showyear=show_year;
}


// get the start point;
double plot_axis::get_start(void)
{
  return start;
}

// get the end point;
double plot_axis::get_end(void)
{
  return end;
}

// get the start point;
DateTime plot_axis::get_start_time(void)
{
  return start_time;
}

// get the end point;
DateTime plot_axis::get_end_time(void)
{
  return end_time;
}

// get the original start point;
DateTime plot_axis::get_orig_start_time(void)
{
  return origstart_time;
}

// get the original end point;
DateTime plot_axis::get_orig_end_time(void)
{
  return origend_time;
}

AXIS_TYPE plot_axis::get_axis_type(void)
{
  return type;
}

// return the step length of the axis ticks
int plot_axis::get_step_length(void)
{
  return steplen;
}

void plot_axis::show_radial_direction(void)
{
  switch(pt->radialtype)
    {
    case PLOT_RADIAL_START_RIGHTWARDS:
      if(pt->counterclockwise)
	{
	  double xx=1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 0, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy+5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx+5, pt->plot_centery-yy);
	  
	  pt->Text(title, int(pt->plot_centerx+xx+5), 
		   int(pt->plot_centery-yy-5));
	}
      else // clockwise
	{
	  double xx=1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=-xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 270+45, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy-5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx+5, pt->plot_centery-yy);
	  
	  pt->Text(title, int(pt->plot_centerx+xx+5), 
		   int(pt->plot_centery-yy+5));
	}
      break;
    case PLOT_RADIAL_START_UPWARDS:
      if(pt->counterclockwise)
	{
	  double xx=-1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=-xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 90, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy-5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx+5, pt->plot_centery-yy);

	  pt->Text(title, int(pt->plot_centerx+xx-5-
			      3*((int) font_size)*strlen(title)), 
		   int(pt->plot_centery-yy+5));
	}
      else // clockwise
	{
	  double xx=1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 45, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy-5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx-5, pt->plot_centery-yy);
	  
	  pt->Text(title, int(pt->plot_centerx+xx+5), 
		   int(pt->plot_centery-yy+5));
	}
      break;
    case PLOT_RADIAL_START_LEFTWARDS:
      if(pt->counterclockwise)
	{
	  double xx=-1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 180, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy-5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx-5, pt->plot_centery-yy);
	  
	  pt->Text(title, int(pt->plot_centerx+xx-5-
			      3*((int) font_size)*strlen(title)), 
		   int(pt->plot_centery-yy+5));
	}
      else // clockwise
	{
	  double xx=-1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=-xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 90+45, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy+5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx-5, pt->plot_centery-yy);
	  
	  pt->Text(title, int(pt->plot_centerx+xx-5-
			      3*((int) font_size)*strlen(title)), 
		   int(pt->plot_centery-yy-5));
	}
      break;
    case PLOT_RADIAL_START_DOWNWARDS:
      if(pt->counterclockwise)
	{
	  double xx=1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=-xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 270, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy+5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx-5, pt->plot_centery-yy);
	  
	  pt->Text(title, int(pt->plot_centerx+xx+5), 
		   int(pt->plot_centery-yy-5));
	}
      else // clockwise
	{
	  double xx=-1.0/sqrt(2.0)*(((double) pt->radius)+90.0), yy=xx;
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius);
	  pt->circle(pt->plot_centerx, pt->plot_centery, pt->radius+90, 
		     False, 180+45, 45);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx, pt->plot_centery-yy+5);
	  pt->Line(pt->plot_centerx+xx, pt->plot_centery-yy,
		   pt->plot_centerx+xx+5, pt->plot_centery-yy);
	  
	  pt->Text(title, int(pt->plot_centerx+xx-5-
			      3*((int) font_size)*strlen(title)), 
		   int(pt->plot_centery-yy-5));
	}
      break;
    default:
      err.build(mainwin::toplevel, WHAT((char *) "Programffeil", 
					(char *) "Program error"),
		WHAT((char *) "Ukjent plotte-positsjon i setting "
		     "av polarplott", 
		     (char *) "Unknown plotting position in the "
		     "setting of polar plot"));
      break;
    }
}

// do the plotting;
void plot_axis::do_plot()
{
  register int i;

  if(pt->is_radial)
    {
      switch(axisnumber % 4)
	{
	case 0:
	  x0=pt->plot_centerx;
	  y0=pt->plot_centery;
	  x1=x0+pt->radius;
	  y1=pt->plot_centery;
	  break;
	case 1:
	  x0=pt->plot_centerx;
	  y0=pt->plot_centery;
	  x1=pt->plot_centerx;
	  y1=y0-pt->radius;
	  break;
	case 2:
	  x0=pt->plot_centerx;
	  y0=pt->plot_centery;
	  x1=x0-pt->radius;
	  y1=pt->plot_centery;
	  break;
	case 3:
	  x0=pt->plot_centerx;
	  y0=pt->plot_centery;
	  x1=pt->plot_centerx;
	  y1=y0+pt->radius;
	  break;
	}
    }
  else if(type==LEFT_Y_AXIS || type==RIGHT_Y_AXIS)
    y1=pt->plot_y1;

  if(iscopy && original)
    {
      start     = original->start;
      end       = original->end;
      for(i=0;i<BACK_BUFFER_SIZE;i++)
	{
	  oldstart[i]       = original->oldstart[i];
	  oldend[i]         = original->oldend[i];
	  old_scaling[i]    = original->old_scaling[i];
	  oldstart_time[i]  = original->oldstart_time[i];
	  oldend_time[i]    = original->oldend_time[i];
	}
      old_index=original->old_index;
      max_index=original->max_index;
      
      origstart = original->origstart;
      origend   = original->origend;
      scaling   = original->scaling;
      
      start_time     = original->start_time;
      end_time       = original->end_time;
      origstart_time = original->origstart_time;
      origend_time   = original->origend_time;

      nicen();
    }

  pt->SetFg("#000000");

  pt->setfont(font_size);

  if(pt->is_big())
    pt->Set_No_Dashes(3);
  else
    pt->Set_No_Dashes(2);

  if(pt->is_radial)
    {
      if(type==NORMAL_X_AXIS || type==TIME_X_AXIS || type==CATEGORICAL_X_AXIS)
	show_radial_direction();
      else
	{
	  pt->Line(x0, y0, x1, y1);

	  if(!isempty && iscopy)
	    {
	      pt->SetFg("#777777");

	      PLOT_FONT_SIZE fsize = 
		(PLOT_FONT_SIZE) MAXIM(((int) PLOT_FONT_VERYSMALL),
				       ((int) font_size)-1);
	      pt->setfont(fsize);
	    }

	  switch(axisnumber%4)
	    {
	    case 0:
	      pt->Line(x1,y1,x1-5, y1-5);
	      pt->Line(x1,y1,x1-5, y1+5);
	      if(!isempty && type==LEFT_Y_AXIS)
		pt->Text(title, x1+12, y1-10);
	      else if(!isempty && type==RIGHT_Y_AXIS)
		pt->Text(title, x1+12, y1+10);
	      break;
	    case 1:
	      pt->Line(x1,y1,x1-5, y1+5);
	      pt->Line(x1,y1,x1+5, y1+5);
	      if(!isempty && type==LEFT_Y_AXIS)
		pt->Text(title, x1-1-strlen(title)*(6 + ((int) font_size)), 
						    y1-6);
	      else if(!isempty && type==RIGHT_Y_AXIS)
		pt->Text(title, x1+3, y1-6);
	      break;
	    case 2:
	      pt->Line(x1,y1,x1+5, y1-5);
	      pt->Line(x1,y1,x1+5, y1+5);
	      if(!isempty && type==LEFT_Y_AXIS)
		pt->Text(title, x1+6-strlen(title)*(6 + 3*((int) font_size)), 
			 y1+6);
	      else if(!isempty && type==RIGHT_Y_AXIS)
		pt->Text(title, x1+6-strlen(title)*(6 + 3*((int) font_size)), 
			 y1-10);
	      break;
	    case 3:
	      pt->Line(x1,y1,x1+5, y1-5);
	      pt->Line(x1,y1,x1-5, y1-5);
	      if(!isempty && type==LEFT_Y_AXIS)
		pt->Text(title, x1+3, y1+16);
	      else if(!isempty && type==RIGHT_Y_AXIS)
		pt->Text(title, x1-1-strlen(title)*(6 + ((int) font_size)),
			 y1+16);
	      break;
	    }
	  
	  if(!isempty && iscopy) // restore fonts and the color
	    {
	      pt->SetFg("#000000");
	      pt->setfont(font_size);
	    }
	}
    }
  else
    {
      pt->setfont(font_size);

      if(type==NORMAL_X_AXIS || type==TIME_X_AXIS || type==CATEGORICAL_X_AXIS)
	{
	  pt->Line(x0, y0, x1+10, y0);
	  pt->Line(x1+10, y0, x1+5, y0-5);
	  pt->Line(x1+10, y0, x1+5, y0+5);
	  pt->Text(title, x1-font_x_size[font_size]*strlen(title), 
		   y0+75);
	}
      else
	{
	  pt->Line(x0, y0, x1, y1-10);
	  pt->Line(x1, y1-10, x1-5, y1-5);
	  pt->Line(x1, y1-10, x1+5, y1-5);
	  
	  if(pt->has_vertical_yaxis_titles())
	    {
	      if(type==LEFT_Y_AXIS)
		pt->soft_text(title, x1-58, 
			      y1+find_font_size(font_size)*
			      strlen(title)*2/3, 
			      90.0, find_font_size(font_size));
	      else // right y axis
		pt->soft_text(title, x1+58, y1, 270.0, 
			      find_font_size(font_size));
	    }
	  else
	    {
	      if(type==LEFT_Y_AXIS)
		pt->Text(title, 
			 x1+10-find_font_size(font_size)*strlen(title)/2, 
			 y1-20);
	      else // right y axis
		pt->Text(title, 
			 x1+10-find_font_size(font_size)*strlen(title)/2, 
			 y1-20); 
	    }
	}
    }

  if(!isempty && ticks)
    {
      if(type==TIME_X_AXIS && !showyear)
	{
	  for(i=0;i<numticks;i++)
	    if(ticks[i].get_type()!=TICK_YEARS &&
	       ticks[i].get_type()!=TICK_YEARS_SMALL &&
	       ticks[i].get_type()!=TICK_DECADES)
	      ticks[i].do_plot();
	}
      else
	for(i = ((pt->is_radial && type!=TIME_X_AXIS) ? 1 : 0);i<numticks;i++)
	  ticks[i].do_plot();
      
      if(pt->gridon)
	plot_gridlines();
    }
}

void plot_axis::plot_gridlines(void)
{
  for(int i = ((pt->is_radial && type!=TIME_X_AXIS) ? 1 : 0); i<numticks;i++)
    ticks[i].plot_gridline();
}

// finds nice start and ending points and the
// steps and number of decimals used for ticks.
void plot_axis::nicen(void)
{
  if(isempty)
    return;

  if(type==TIME_X_AXIS)
    {
      nicen_timeaxis();
      return;
    }

  if(type==CATEGORICAL_X_AXIS)
    {
      nicen_categorical();
      return;
    }

  if(scaling==AXIS_LINEAR)
    {
      double startbuffer=start, endbuffer=end;
      double diff = (pt->is_radial && 
		     (type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS)) ? 
	pt->radial_len : (end-start);
      double absdiff = (type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) ? 
	pt->plot_x1-pt->plot_x0 : pt->plot_y0-pt->plot_y1;
      double norm = (type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) ? 740.0 : 505;
      int diffsize=(int) floor(1.0*log10(diff*norm/absdiff)) - 1;
      int abssize=(int) MAXIM(ceil(log10(ABSVAL(start)+1e-30)), 
			      ceil(log10(ABSVAL(end)+1e-30)));
      int allowedsize = (type == NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) ? 
	90 : 35;
      
      if(type != NORMAL_X_AXIS && type!=TIME_X_AXIS && type!=CATEGORICAL_X_AXIS &&
	 ABSVAL((pt->plot_y0 - pt->plot_y1))<500)
	allowedsize = ABSVAL((pt->plot_y0 - pt->plot_y1))*35/500;
      
      if(pt->is_big())
	allowedsize = (type == NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) ? 70 : 25;
      if((type==RIGHT_Y_AXIS || type==LEFT_Y_AXIS) && pt->is_radial)
	allowedsize /= 3;
      if((type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) && pt->is_radial)
	allowedsize *= 3;

      step = pow(10.0, diffsize);
      decimals=abssize-diffsize;

      while(((type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) && decimals>0 && 
	     (end-start)/step > allowedsize/(decimals+1)) || 
	    (type!=NORMAL_X_AXIS && type!=CATEGORICAL_X_AXIS && 
	     (end-start)/step > allowedsize))
	{
	  diffsize++;
	  step = pow(10.0, diffsize);
	  decimals=abssize-diffsize;
	}

      if(((type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) && decimals>0 && 
	  (end-start)/step > allowedsize/(decimals+1))/2 || 
	 (type!=NORMAL_X_AXIS && type!=CATEGORICAL_X_AXIS && 
	  (end-start)/step > allowedsize/2))
	step*=2.0;

      startbuffer /= step;
      startbuffer = floor(startbuffer);
      startbuffer *= step;
  
      endbuffer /= step;
      endbuffer = ceil(endbuffer);
      endbuffer *= step;
      
      if(do_nicen_start_end)
	if(((type!=NORMAL_X_AXIS && type!=CATEGORICAL_X_AXIS) || 
	    !pt->is_radial) && !pt->func)
	{
	  start = startbuffer;
	  end   = endbuffer;
	}
    }
  else if(scaling==AXIS_LOGARITHMIC)
    {
      double startbuffer=log10(start), endbuffer=log10(end);
      
      startbuffer=floor(startbuffer);
      endbuffer=ceil(endbuffer);
      
      if(do_nicen_start_end)
	{
	  start=pow(10.0, startbuffer);
	  end=pow(10.0, endbuffer);
	}
    }

  find_new_ticks();
}


// make new ticks
void plot_axis::find_new_ticks_categorical(void)
{  
  register int i=0;
  double val=(pt->is_radial && pt->startyaxisatzero) 
    ? 1.0 : ceil(start);
  
  if(ticks)
    delete [] ticks;
  ticks=NULL;
  
  if(isempty)
    return;
  

  while(val<=end)
    {
      if(val>=start && val<=end)
	i++;
      val++;
    }
  
  numticks=i;
  
  ticks=new plot_tick[numticks];
  
  if(numticks>1)
    steplen = (pt->plot_x1-pt->plot_x0)/(numticks-1);
  else 
    steplen = 0;
  
  i=0;
  val=(pt->is_radial && pt->startyaxisatzero) ? 1.0 : ceil(start);
  while(val<=end)
    {
      if(val>=start && val<=end)
	{
	  TICK_SIZE ticksize=TICK_SMALL;
	  if(numcat<=6)
	    ticksize=TICK_LARGE;
	  
	  int index=i+int(ceil(start))-1;
	  
	  if(index>=0 && index<numcat)
	    ticks[i].Create(val, catstr[index], ticksize, this, pt);
	  else
	    ticks[i].Create(MISSING_VALUE, "", ticksize, this, pt);
	  
	  i++;
	}
      val++;
    }
}

// make new ticks
void plot_axis::find_new_ticks(void)
{
  if(type==CATEGORICAL_X_AXIS)
    {
      find_new_ticks_categorical();
      return;
    }
  
  register int i=0;
  double val=(pt->is_radial && pt->startyaxisatzero && scaling==AXIS_LINEAR) 
    ? 0.0 : start;
  
  if(ticks)
    delete [] ticks;
  ticks=NULL;
  
  if(isempty)
    return;
  
  if(scaling==AXIS_LINEAR)
    {
      while(val<=end)
	{
	  val+=step;
	  i++;
	}
      
      numticks=i;
      
      ticks=new plot_tick[numticks];
      
      if(numticks>1)
	steplen = (pt->plot_x1-pt->plot_x0)/(numticks-1);
      else 
	steplen = 0;
      
      for(i=0;i<numticks;i++)
	{
	  val=start+i*step;
	  
	  double buffer=val;
	  int buffer2;
	  TICK_SIZE ticksize=TICK_SMALL;
	  
	  buffer /= step;
	  buffer2 = (int) floor(ABSVAL(buffer*1.00000000001));
	  if(ABSVAL(buffer2) % 10 == 0)
	    ticksize=TICK_LARGE;
	  
	  ticks[i].Create(val, decimals, ticksize, this, pt);
	}
    }
  else if(scaling==AXIS_LOGARITHMIC)
    {
      double startbuff=log10(start), endbuff=log10(end), val;
      int numorders = (int) (ceil(endbuff)-floor(startbuff));
      double invalue=0.0;
      int numorders2=numorders; // for checking

      if(start<=0.0)
	{
	  char errstr[1000];
	    sprintf(errstr, 
		    WHAT((char *) "For log-akse skal start "
			 "v�re ekte st�rre enn 0.\nI dette tilfellet "
			 "var start=%9.3f.\n"
			 "Plotte-modulen skulle ha hindret at dette skjedde.", 
			 (char *) "For log axis, the start "
			 "should be greater than 0.\nIn this case, "
			 "start=%9.3f!\n"
			 "The plotting module should have stopped this "
			 "from happening"), start);
	  err.build(mainwin::toplevel, WHAT((char *) "Programfeil", 
					    (char *) "Program error"), errstr);
	  return;
	}

      if(type != NORMAL_X_AXIS && type!=TIME_X_AXIS && 
	 type!=CATEGORICAL_X_AXIS &&
	 ABSVAL((pt->plot_y0 - pt->plot_y1))<500)
	numorders2++;

      if((type == NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS) &&
	 ABSVAL((pt->plot_x0 - pt->plot_x1))<900)
	numorders2++;

      decimals++;

      if(numorders2==1)
	numticks = 9+9+1;
      else if(numorders2>=5)
	numticks = numorders + 1;
      else if(numorders2>=3)
	numticks = numorders * 4 + 1;
      else
	numticks = numorders * 9 + 1;
      
      ticks=new plot_tick[numticks];
      
      val=floor(startbuff);

      while(val<endbuff)
	{
	  TICK_SIZE ticksize = ((numorders2>=3 && i%4==0) ||
				(numorders2<3 && i%9==0)) ? TICK_LARGE : 
	    TICK_SMALL;
	  
	  if(numorders2<=1)
	    {
	      if(i%18==0)
		ticksize = TICK_LARGE;
	      else
		ticksize = TICK_SMALL;
	    }
	  
	  if(i==0)
	    invalue=pow(10.0, val);
	  else if(numorders2>=5)
	    invalue = pow(10.0, ceil(val+1));
	  else if(numorders2>=3)
	    {
	      if(i%4==0 && i>0)
		invalue = pow(10.0, ceil(val));
	      else if(i%4==1)
		invalue = 2.0*pow(10.0, floor(val));
	      else if(i%4==2)
		invalue = 3.0*pow(10.0, floor(val));
	      else if(i%4==3)
		invalue = 5.0*pow(10.0, floor(val));
	    }
	  else if(numorders2>1)
	    {
	      if(i%9==0 && i>0)
		invalue = pow(10.0, ceil(val));
	      else if(i!=0)
		invalue = (i%9+1) * pow(10.0, floor(val));
	    }
	  else
	    {
	      if(i%18==0 && i>0)
		invalue = pow(10.0, ceil(val));
	      else if(i!=0 && i%18<=9)
		invalue = (1.0+(i%9+1.0)/10.0) * pow(10.0, floor(val));
	      else if(i!=0)
		invalue = (1.0 + (i%18-9)) * pow(10.0, floor(val));
	    }
	  
	  if(i!=0)
	    val=log10(invalue);
	  
	  if(val>=startbuff && val<=endbuff)
	    {
	      decimals=int(ceil(ABSVAL(log10(invalue))));
	      ticks[i].Create(invalue, decimals,
			      ticksize, this, pt);
	      i++;
	    }
	}
      
      numticks=i;
    }
  else if(scaling==AXIS_LOGIT_PERCENT || scaling==AXIS_LOGIT_ABSOLUTE || 
	  scaling==AXIS_PROBIT_PERCENT || scaling==AXIS_PROBIT_ABSOLUTE)
    {
      bool is_probit=(scaling==AXIS_PROBIT_PERCENT || 
		      scaling==AXIS_PROBIT_ABSOLUTE) ? true : false;
      bool is_percent=(scaling==AXIS_LOGIT_PERCENT || 
		       scaling==AXIS_PROBIT_PERCENT) ? true : false;

      if(start<=0.0 || end>=(is_percent ? 100.0 : 1.0))
	{
	  char errstr[1000];
	  if(is_percent)
	    sprintf(errstr, 
		    WHAT((char *) "For logit/probit-akse i %% skal start "
			 "v�re ekte st�rre enn 0%% og slutt skal v�re ekte "
			 "mindre enn 100%%.\nI dette tilfellet var start="
			 "%9.3f%% og slutt=%9.3f%%!\n"
			 "Plotte-modulen skulle ha hindret at dette skjedde.", 
			 (char *) "For logit/probit axis in %%, the start "
			 "should be greater than 0%% and the end smaller "
			 "than 100%%.\nIn this case, start=%9.3f%% and "
			 "end=%9.3f%%!\n"
			 "The plotting module should have stopped this "
			 "from happening"), start,end);
	  else
	    sprintf(errstr, 
		    WHAT((char *) "For logit/probit-akse skal start "
			 "v�re ekte st�rre enn 0 og slutt skal v�re ekte "
			 "mindre enn 1.\nI dette tilfellet var start="
			 "%9.3f og slutt=%9.3f!\n"
			 "Plotte-modulen skulle ha hindret at dette skjedde.", 
			 (char *) "For logit/probit axis, the start "
			 "should be greater than 0 and the end smaller "
			 "than 1.\nIn this case, start=%9.3f and "
			 "end=%9.3f!\n"
			 "The plotting module should have stopped this "
			 "from happening"), start,end);
	  err.build(mainwin::toplevel, WHAT((char *) "Programfeil", 
					    (char *) "Program error"), errstr);
	  return;
	}
      
      double startbuff=is_probit ? probit(start,is_percent) :
	logit(start,is_percent);
      double endbuff=is_probit ? probit(end,is_percent) : 
	logit(end,is_percent);
      
      decimals++;
      
      numticks=0;
      double new_start=0.1,new_end=0.9;
      while((is_probit ? probit(new_start) : logit(new_start))>startbuff)
	new_start/=10.0;
      while((is_probit ? probit(new_end) : logit(new_end))<endbuff)
	new_end=1.0-(1.0-new_end)/10.0;
      double xx=new_start, trans_xx=is_probit ? probit(xx) : logit(xx);
      while(xx<new_end)
	{
	  if(trans_xx>=startbuff && trans_xx<=endbuff)
	    numticks++;
	  
	  double new_xx=xx;
	  if(xx<0.1)
	    {
	      if(ABSVAL((round(log10(xx))-log10(xx)))<0.01)
		new_xx*=5.0;
	      else
		new_xx=pow(10.0,ceil(log10(xx)));
	    }
	  else if(almost_equal(xx,0.1))
	    new_xx=0.25;
	  else if(almost_equal(xx,0.25))
	    new_xx=0.5;
	  else if(almost_equal(xx,0.5))
	    new_xx=0.75;
	  else if(almost_equal(xx,0.75))
	    new_xx=0.9;
	  else if(xx>=0.9)
	    {
	      if(ABSVAL((round(log10(1.0-xx))-log10(1.0-xx)))<0.01)
		new_xx=1.0-(1.0-xx)/2.0;
	      else
		new_xx=1.0-pow(10.0,floor(log10(1.0-xx)));
	    }

	  xx=new_xx;
	  trans_xx=is_probit ? probit(xx) : logit(xx);
	}
      
      ticks=new plot_tick[numticks];
      int i=0;
      xx=new_start;
      trans_xx=is_probit ? probit(xx) : logit(xx);
      while(xx<new_end)
	{
	  if(trans_xx>=startbuff && trans_xx<=endbuff)
	    {
	      TICK_SIZE ticksize=TICK_LARGE;
	      if(xx<0.1 && ABSVAL((round(log10(xx))-log10(xx)))>0.01)
		ticksize=TICK_SMALL;
	      if(xx>0.9 && ABSVAL((round(log10(1.0-xx))-log10(1.0-xx)))>0.01)
		ticksize=TICK_SMALL;
	      
	      decimals=1;
	      if(xx<0.1)
		decimals=(int) ceil(ABSVAL((log10(xx))));
	      else if(xx>0.)
		decimals=(int) ceil(ABSVAL((log10(1.0-xx))));
	      
	      double invalue=is_percent ? 100.0*xx : xx;
	      
	      ticks[i].Create(invalue, decimals,
			      ticksize, this, pt);
	      i++;
	    }
	  
	  double new_xx=xx;
	  if(xx<0.1)
	    {
	      if(ABSVAL((round(log10(xx))-log10(xx)))<0.01)
		new_xx*=5.0;
	      else
		new_xx=pow(10.0,ceil(log10(xx)));
	    }
	  else if(almost_equal(xx,0.1))
	    new_xx=0.25;
	  else if(almost_equal(xx,0.25))
	    new_xx=0.5;
	  else if(almost_equal(xx,0.5))
	    new_xx=0.75;
	  else if(almost_equal(xx,0.75))
	    new_xx=0.9;
	  else if(xx>=0.9)
	    {
	      if(ABSVAL((round(log10(1.0-xx))-log10(1.0-xx)))<0.01)
		new_xx=1.0-(1.0-xx)/2.0;
	      else
		new_xx=1.0-pow(10.0,floor(log10(1.0-xx)));
	    }

	  xx=new_xx;
	  trans_xx=is_probit ? probit(xx) : logit(xx);
	}
    }
}

void plot_axis::nicen_categorical(void)
{
  // nothing to do but make ticks:
  find_new_ticks_categorical();
}

// finds nice start and ending points and the
// steps and number of decimals used for ticks.
void plot_axis::nicen_timeaxis(void)
{
  TICK_TYPE ticktype;
  long int diff = end_time.difference_minutes(start_time);
  int diffx = x1-x0, normx=740;

  if(pt->is_radial)
    {
      diff = pt->radial_year*365*1440 + pt->radial_min;
      diffx = (int) (2.0*3.1415926*((double) pt->radius));
    }

  if(isempty)
    return;

  if(diff <= 3*diffx/normx)
    ticktype=TICK_SECONDS_SMALL;
  else if(diff <= 45*diffx/normx)
    ticktype=TICK_MINUTES;
  else if(diff <= 3*60*diffx/normx)
    ticktype=TICK_MINUTES_SMALL;
  else if(diff <= 2*24*60*diffx/normx)
    ticktype=TICK_HOURS;
  else if(diff <= 7*24*60*diffx/normx)
    ticktype=TICK_HOURS_SMALL;
  else if(diff <= 45*24*60*diffx/normx)
    ticktype=TICK_DAYS;
  else if(diff <= 7*30*24*60*diffx/normx)
    ticktype=TICK_DAYS_SMALL;
  else if(diff <= 2*365*24*60*diffx/normx)
    ticktype=TICK_MONTHS;
  else if(diff <= 7*365*diffx/normx*24*60)
    ticktype=TICK_MONTHS_SMALL;
  else if(diff <= 24*365*diffx/normx*24*60)
    ticktype=TICK_YEARS;
  else if(diff <= 100*365*diffx/normx*24*60)
    ticktype=TICK_YEARS_SMALL;
  else 
    ticktype=TICK_DECADES;
  
  switch(ticktype)
    {
    case TICK_MINUTES:
    case TICK_MINUTES_SMALL:
      {
	DateTime dt1(start_time.getYear(), start_time.getMonth(),
		     start_time.getDay(), start_time.getHour(), 
		     start_time.getMinute(),0);
	DateTime dt2(end_time.getYear(), end_time.getMonth(),
		     end_time.getDay(), end_time.getHour(), 
		     end_time.getMinute(),0);
	
	start_time=dt1;
	if(end_time.getSecond()!=0)
	  end_time=dt2+60;

	break;
      }
    case TICK_HOURS:
    case TICK_HOURS_SMALL:
      {
	DateTime dt1(start_time.getYear(), start_time.getMonth(),
		     start_time.getDay(), start_time.getHour(), 0, 0);
	DateTime dt2(end_time.getYear(), end_time.getMonth(),
		     end_time.getDay(), end_time.getHour(), 0, 0);
	
	start_time=dt1;
	if(end_time.getMinute()!=0 || end_time.getSecond()!=0)
	  end_time=dt2+60*60;

	break;
      }
    case TICK_DAYS:
    case TICK_DAYS_SMALL:
      {
	DateTime dt1(start_time.getYear(), start_time.getMonth(),
		     start_time.getDay(), 0, 0, 0);
	DateTime dt2(end_time.getYear(), end_time.getMonth(),
		     end_time.getDay(), 0, 0, 0);
	
	start_time=dt1;
	end_time=dt2.EndOfDay();

	break;
      }
    case TICK_MONTHS: 
      {
	DateTime dt1(start_time.getYear(), start_time.getMonth(),
		     start_time.getDay(), 0, 0, 0);
	DateTime dt2(end_time.getYear(), end_time.getMonth(),
		     end_time.getDay(), 0, 0, 0);
	
	start_time=dt1;
	end_time=dt2.EndOfDay();

	break;
      }
    case TICK_MONTHS_SMALL:
      {
	DateTime dt1(start_time.getYear(), start_time.getMonth(),
		     1, 0, 0, 0);
	DateTime dt2(end_time.getYear(), end_time.getMonth(),
		     1, 0, 0, 0);
	
	start_time=dt1;
	if(end_time.getDay()!=1 || end_time.getHour()!=0 || 
	   end_time.getMinute()!=0 || end_time.getSecond()!=0)
	  end_time=dt2.EndOfMonth();

	break;
      }
    case TICK_YEARS:
    case TICK_YEARS_SMALL:
      {
	DateTime dt1(start_time.getYear(), 1,
		     1, 0, 0, 0);
	DateTime dt2(end_time.getYear()+1, 1,
		     1, 0, 0, 0);
	
	start_time=dt1;
	if(end_time.getMonth()!=1 || end_time.getDay()!=1 || 
	   end_time.getHour()!=0 || end_time.getMinute()!=0 || 
	   end_time.getSecond()!=0)
	  end_time=dt2;

	break;
      } 
    case TICK_DECADES:
      {
	DateTime dt1((start_time.getYear()/10)*10, 1,
		     1, 0, 0, 0);
	DateTime dt2((end_time.getYear()/10)*10+10, 1,
		     1, 0, 0, 0);
	
	start_time=dt1;
	if(end_time.getYear()%10!=0 || end_time.getMonth()!=1 || 
	   end_time.getDay()!=1 || end_time.getHour()!=0 || 
	   end_time.getMinute()!=0 || end_time.getSecond()!=0)
	  end_time=dt2;

	break;
      }
    default:
      break;
    }
  
  find_new_timeticks(ticktype);
}

// make new ticks
void plot_axis::find_new_timeticks(TICK_TYPE ticktype)
{
  register long int i;
  DateTime val=start_time;
  int plotlen=pt->plot_x1-pt->plot_x0;

  if(ticks)
    delete [] ticks;
  ticks=NULL;

  if(isempty)
    return;

  switch(ticktype)
    {
    case TICK_SECONDS_SMALL:
      numticks = end_time-start_time+1;
      ticks = new plot_tick[numticks];
      for(i=0;i<numticks;i++)
	{
	  ticks[i].Create(val, ticktype, this, pt, i==0 ? True : False);

	  val += 1;
	}

      break;
    case TICK_MINUTES:
    case TICK_MINUTES_SMALL:
      numticks = end_time.difference_minutes(start_time)+1;
      ticks = new plot_tick[numticks];
      for(i=0;i<numticks;i++)
	{
	  ticks[i].Create(val, ticktype, this, pt, i==0 ? True : False);

	  val += 60;
	}

      break;
    case TICK_HOURS: 
    case TICK_HOURS_SMALL:
      numticks = end_time.difference_minutes(start_time)/60 + 1;
      ticks = new plot_tick[numticks];
      for(i=0;i<numticks;i++)
	{
	  ticks[i].Create(val, ticktype, this, pt, i==0 ? True : False);

	  val += 60*60;
	}

      break;
    case TICK_DAYS: 
    case TICK_DAYS_SMALL:
      numticks = end_time.difference_minutes(start_time)/24/60 + 1;
      ticks = new plot_tick[numticks];
      for(i=0;i<numticks;i++)
	{
	  ticks[i].Create(val, ticktype, this, pt, i==0 ? True : False);

	  val += 24*60*60;
	}

      break;
    case TICK_MONTHS: 
    case TICK_MONTHS_SMALL:
      numticks = (end_time.getYear() - start_time.getYear())*12 +
	(end_time.getMonth() - start_time.getMonth()) + 1;
      ticks = new plot_tick[numticks];
      for(i=0;i<numticks;i++)
	{
	  ticks[i].Create(val, ticktype, this, pt, i==0 ? True : False);

	  if(val.getMonth()==12)
	    {
	      DateTime dtbuff(val.getYear()+1,1,1);
	      val=dtbuff;
	    }
	  else
	    {
	      DateTime dtbuff(val.getYear(),val.getMonth()+1,1);
	      val=dtbuff;
	    }
	}

      break;
    case TICK_YEARS: 
    case TICK_YEARS_SMALL:
      numticks = end_time.getYear() - start_time.getYear() + 1;
      ticks = new plot_tick[numticks];
      for(i=0;i<numticks;i++)
	{
	  ticks[i].Create(val, ticktype, this, pt, i==0 ? True : False);

	  DateTime dtbuff(val.getYear()+1,1,1);
	  val=dtbuff;
	}

      break;
    case TICK_DECADES:
    default:
      numticks = end_time.getYear()/10 - start_time.getYear()/10 + 1;
      ticks = new plot_tick[numticks];
      for(i=0;i<numticks;i++)
	{
	  ticks[i].Create(val, ticktype, this, pt, i==0 ? True : False);

	  DateTime dtbuff(val.getYear()+10,1,1);
	  val=dtbuff;
	}

      break;
    }

  steplen = numticks<=1 ? 0 : plotlen/(numticks-1);
}



// build widgets in the "change axis" window;
void plot_axis::build_chaxis(widget parent)
{
  if(isempty)
    return;

  char *sizes[]={
    WHAT((char *) "Veldig liten", (char *) "Very small"), 
    WHAT((char *) "Liten", (char *) "Small"), 
    WHAT((char *) "Medium", (char *) "Medium"),
    WHAT((char *) "Stor", (char *) "Large"), 
    WHAT((char *) "Veldig stor",(char *) "Very large"), 
    WHAT((char *) "Ekstra stor",(char *) "Extra large"), 
    WHAT((char *) "Ekstremt stor",(char *) "Extremely large")};
  changeh1.build(parent);
  chtitlef.build(changeh1, 50, WHAT((char *) "Akse-tittel:",
				    (char *) "Axis title:"));
  chtitlef.SetText(title);
  chfontsize.Create(changeh1, WHAT((char *) "Font-st�rrelse:",
				   (char *) "Font size:"));
  chfontsize.Insert(sizes, 7, (int) font_size);
}

// do changing operations from input in the "change axis" window
void plot_axis::do_axischange(void)
{
  if(isempty)
    return;

  strcpy(title, chtitlef());
  font_size = (PLOT_FONT_SIZE) chfontsize.GetNumber();
}



void plot_axis::update_old_values(void)
{
  if(isempty)
    return;
  
  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;
  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  
  update_old_index();
}

// Builds a widget set in the logarihmic choice window;
void plot_axis::build_logwidget(widget parent, bool logit_probit_possible_, 
				bool logit_probit_percent_)
{
  if(type==TIME_X_AXIS || isempty)
    return;
  
  logit_probit_possible=logit_probit_possible_;
  if(scaling==AXIS_LOGIT_PERCENT  || scaling==AXIS_LOGIT_ABSOLUTE ||
     scaling==AXIS_PROBIT_PERCENT || scaling==AXIS_PROBIT_ABSOLUTE)
    logit_probit_possible=true;
  
  logit_probit_percent=logit_probit_percent_;
  if(scaling==AXIS_LOGIT_ABSOLUTE ||  scaling==AXIS_PROBIT_ABSOLUTE)
    logit_probit_percent=false;
  
  logh1.build(parent);
  loglab.build(logh1, title);
  scaling_choice.Create(logh1,this, logit_probit_possible);
  
  logv1.build(logh1);
  logspace.build(logv1,"    ");
  logcomment.build(logv1,"%20s",WHAT((char *) "(vanlig akse)", 
				     (char *) "(default axis)"));
  
  logv2.build(logh1);
  logh2.build(logv2);
  logstartf.build(logh2, 10, 
		  WHAT((char *) "Start-niv� for logaritmisk plotting:",
		       (char *) "Start of scale for logarithmic plot:"));
  
  logh3.build(logv2);
  logitstartf.build(logh3, 10, 
		    WHAT((char *) "Start-niv� for logit/probit plotting:",
			 (char *) "Start of scale for logit/probit plot:"));
  logitendf.build(logh3, 10, 
		  WHAT((char *) "Slutt-niv� for logit/probit plotting:",
		       (char *) "End of scale for logit/probit plot:"));
  do_percent.build(logh3,WHAT((char *) "Prosent (0%-100%):", 
			      (char *) "Percent (0%-100%):"));
  if(logit_probit_percent)
    do_percent.ToggleButtonOn();
  logh2.Unmap();
  logh3.Unmap();
  logsep.build(parent);
  
  if(type==CATEGORICAL_X_AXIS)
    scaling_choice.InSensitive();
  else if(scaling!=AXIS_LINEAR)
    scaling_choice.Set(scaling);
  
  update_logwidget();
}

// update value start field;
void plot_axis::update_logwidget(void)
{
  if(type==TIME_X_AXIS || isempty)
    return;
  
  if(non_niced_start>0.0)
    {
      logstartf.SetDouble(pow(10.0, floor(log10(non_niced_start))));
      logitstartf.SetDouble(non_niced_start);
    }
  else
    {
      double lines_min=(type==LEFT_Y_AXIS ||  type==RIGHT_Y_AXIS) ?
	(pt ? pt->get_yaxis_data_min() : MISSING_VALUE) :
	(pt ? pt->get_xaxis_data_min() : MISSING_VALUE);
      
      if(lines_min!=MISSING_VALUE && lines_min>0.0)
	{
	  //start=lines_min;

	  logstartf.SetDouble(pow(10.0, floor(log10(non_niced_start))));
	  logitstartf.SetDouble(non_niced_start);

	  if(lines_min>1.0)
	    do_percent.ToggleButtonOn();
	}
      else
	{
	  logstartf.SetText("---");
	  logitstartf.SetText("---");
	}
    }
  
  if(non_niced_end<1.0 || (non_niced_end<100.0 && do_percent()))
    logitendf.SetDouble(non_niced_end);
  else
    {
      double lines_max=(type==LEFT_Y_AXIS ||  type==RIGHT_Y_AXIS) ?
	(pt ? pt->get_yaxis_data_max() : MISSING_VALUE) :
	(pt ? pt->get_xaxis_data_max() : MISSING_VALUE);
      
      if(lines_max!=MISSING_VALUE && lines_max<1.0)
	{
	  //end=lines_max;
	  logitendf.SetDouble(lines_max);
	}
      else if(lines_max!=MISSING_VALUE && lines_max<100.0)
	{
	  //end=lines_max;
	  logitendf.SetDouble(lines_max);
	  do_percent.ToggleButtonOn();
	}
      else
	logitendf.SetText("---");
    }
}

void plot_axis::scaling_changed(AXIS_SCALING new_scaling)
{
  switch(new_scaling)
    {
    case AXIS_LINEAR:
      logh2.Unmap();
      logh3.Unmap();
      logcomment.labelString("%20s",WHAT((char *) "(vanlig akse)", 
					 (char *) "(default axis)"));
  
      break;
    case AXIS_LOGARITHMIC:
      logh2.Map();
      logh3.Unmap();
      logcomment.labelString("%20s",WHAT((char *) "(st�rrelsesorden)", 
					 (char *) "(order of magnitude)"));
      break;
    case AXIS_LOGIT_PERCENT:
    case AXIS_PROBIT_PERCENT:
      logh2.Unmap();
      logh3.Map();
      do_percent.ToggleButtonOn();
      logcomment.labelString("%20s",WHAT((char *) "(antar 0%-100%-skala)", 
					 (char *) "(assumes 0%-100% scale)"));
      break;
    case AXIS_LOGIT_ABSOLUTE:
    case AXIS_PROBIT_ABSOLUTE:
      logh2.Unmap();
      logh3.Map();
      do_percent.ToggleButtonOff();
      logcomment.labelString("%20s",WHAT((char *) "(antar 0-1-skala)", 
					 (char *) "(assumes 0-1 scale)"));
      break;
    case AXIS_UNKNOWN_SCALING:
    default:
      err.build(mainwin::toplevel, 
		WHAT((char *) "Programfeil!", (char *) "Program error!"),
		WHAT((char *) "Ukjent akse-skalering!", 
		     (char *) "Unknown axis scaling!"));
      err.Beep(1);
      logcomment.labelString("%20s",WHAT((char *) "(H�?!)", 
					 (char *) "(Huh?!)"));
      break;
    }
}



// check if start field is okay;
bool plot_axis::user_input_logwidget_okay(void)
{
  if(type==TIME_X_AXIS || isempty)
    return True;
  
  AXIS_SCALING currscaling=user_scaling();
  
  char str[100];
  double newstart,newend;

  switch(currscaling)
    {
    case AXIS_LINEAR:
      return True;
    case AXIS_LOGARITHMIC:
      strcpy(str, logstartf());

      if(strstr(str, "-"))
	return False;
  
      newstart = logstartf.getdouble();
      
      if(newstart<=0.0)
	return False;

      return True;
    case AXIS_LOGIT_ABSOLUTE:
    case AXIS_PROBIT_ABSOLUTE:
      strcpy(str, logitstartf());
      if(strstr(str, "-"))
	return False;
      strcpy(str, logitendf());
      if(strstr(str, "-"))
	return False;
  
      newstart = logitstartf.getdouble();
      newend = logitendf.getdouble();
      
      if(newstart<=0.0 || newstart>=newend || newend>=1.0)
	return False;

      return True;
    case AXIS_LOGIT_PERCENT:
    case AXIS_PROBIT_PERCENT:
      strcpy(str, logitstartf());
      if(strstr(str, "-"))
	return False;
      strcpy(str, logitendf());
      if(strstr(str, "-"))
	return False;
  
      newstart = logitstartf.getdouble();
      newend = logitendf.getdouble();
      
      if(newstart<=0.0 || newstart>=newend || newend>=100.0)
	return False;

      return True;
    default:
      return False;
    }

  return False;
}

// return the scaling to be used;
AXIS_SCALING plot_axis::get_scaling(void)
{
  if(type==TIME_X_AXIS || isempty)
    return AXIS_LINEAR;
  return scaling;
}

AXIS_SCALING plot_axis::user_scaling(void)
{
  AXIS_SCALING new_scaling=AXIS_LINEAR;

  if(!(type==TIME_X_AXIS ||  type==CATEGORICAL_X_AXIS ||
       type==AXISTYPE_UNKNOWN))
     new_scaling=scaling_choice.get_scaling(do_percent());
     
  return new_scaling;
}


// Update the scaling status of this axis;
void plot_axis::update_logstatus(void)
{
  if(type==TIME_X_AXIS || isempty)
    return;
  
  old_scaling[old_index]=scaling;
  scaling=user_scaling();
  
  oldstart[old_index]=start;
  oldend[old_index]=end;
  
  if(scaling==AXIS_LOGARITHMIC)
    start=logstartf.getdouble();
  else if(scaling==AXIS_LOGIT_PERCENT || scaling==AXIS_LOGIT_ABSOLUTE ||
	  scaling==AXIS_PROBIT_PERCENT || scaling==AXIS_PROBIT_ABSOLUTE)
    {
      start=logitstartf.getdouble();
      end=logitendf.getdouble();
    }
  
  if(old_scaling[old_index]!=scaling)
    nicen();
  
  update_old_index();
}

void plot_axis::set_scaling(AXIS_SCALING new_scaling)
{
  if(type==TIME_X_AXIS && new_scaling!=AXIS_LINEAR)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Det skal ikke g� an � gj�re "
		     "en tidsakse log/logit/probit!", 
		     (char *) "A time axis can't be made log/logit/probit!"));
      return;
    }
  
  old_scaling[old_index]=scaling;
  oldstart[old_index]=start;
  oldend[old_index]=end;
  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  scaling=new_scaling;
  
  update_old_index();
}





// zoom towards a point
void plot_axis::zoom_point(double coord, double zoomfactor)
{
  if(isempty)
    return;

  if(type==TIME_X_AXIS)
    {
      zoom_timepoint(coord, zoomfactor);
      return;
    }

  double startbuff=start, endbuff=end;
  double value, newstart, newend, diff;
  double ostart=origstart, oend=origend;

  if(scaling==AXIS_LOGARITHMIC)
    {
      startbuff = log10(start);
      endbuff   = log10(end);
      ostart=floor(log10(origstart));
      oend=ceil(log10(origend));
    }
  else if(scaling==AXIS_LOGIT_PERCENT)
    {
      startbuff = logit(start,true);
      endbuff   = logit(end,true);
      ostart=logit(origstart,true);
      oend=logit(origend,true);
    }
  else if(scaling==AXIS_LOGIT_ABSOLUTE)
    {
      startbuff = logit(start,false);
      endbuff   = logit(end,false);
      ostart=logit(origstart,false);
      oend=logit(origend,false);
    }
  else if(scaling==AXIS_PROBIT_PERCENT)
    {
      startbuff = probit(start,true);
      endbuff   = probit(end,true);
      ostart=probit(origstart,true);
      oend=probit(origend,true);
    }
  else if(scaling==AXIS_PROBIT_ABSOLUTE)
    {
      startbuff = probit(start,false);
      endbuff   = probit(end,false);
      ostart=probit(origstart,false);
      oend=probit(origend,false);
    }

  diff = endbuff - startbuff;
      
  if(type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS)
    value = startbuff + (coord - pt->plot_x0)/
      ((double) pt->plot_x1 - (double) pt->plot_x0) * 
      (endbuff-startbuff);
  else
    value = startbuff + (coord - pt->plot_y0)/
      ((double) pt->plot_y1 - (double) pt->plot_y0) * 
      (endbuff-startbuff);

  newstart = value - diff/2.0/zoomfactor;
  newend   = value + diff/2.0/zoomfactor;
  
  if(newstart<ostart)
    newstart=ostart;
  
  if(newend>oend)
    newend=oend;
  
  if(scaling==AXIS_LOGARITHMIC)
    {
      newstart = pow(10.0, newstart);
      newend   = pow(10.0, newend);
    }
  else if(scaling==AXIS_LOGIT_PERCENT)
    {
      newstart = invlogit(newstart,true);
      newend   = invlogit(newstart,true);
    }
  else if(scaling==AXIS_LOGIT_ABSOLUTE)
    {
      newstart = invlogit(newstart,false);
      newend   = invlogit(newstart,false);
    }
  else if(scaling==AXIS_PROBIT_PERCENT)
    {
      newstart = invprobit(newstart,true);
      newend   = invprobit(newstart,true);
    }
  else if(scaling==AXIS_PROBIT_ABSOLUTE)
    {
      newstart = invprobit(newstart,false);
      newend   = invprobit(newstart,false);
    }
  
  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;

  start=non_niced_start=newstart;
  end=non_niced_end=newend;

  nicen();
  
  update_old_index();
}

// zoom towards a point for a time x-axis
void plot_axis::zoom_timepoint(double coord, double zoomfactor)
{
  DateTime startbuff=start_time, endbuff=end_time;
  DateTime value, newstart, newend;
  DateTime ostart=origstart_time, oend=origend_time;
  long int diff = endbuff.difference_minutes(startbuff);

  if(isempty)
    return;
      
  if(diff<30)
    {
      value = startbuff + (long int) ((coord - (double) pt->plot_x0) /
				    ((double) pt->plot_x1 - 
				     (double) pt->plot_x0) * 
				    (double) (endbuff-startbuff));
      newstart = value - diff * 60 / (long int) (2.0*zoomfactor);
      newend   = value + diff * 60 / (long int) (2.0*zoomfactor);
    }
  else
    {
      value = startbuff.add_minutes((long int) ((coord - 
						 (double) pt->plot_x0) /
						((double) pt->plot_x1 - 
						 (double) pt->plot_x0) * 
						(double) diff));
      newstart=value;
      newend=value;
      newstart.add_minutes(-diff / (long int) (2.0*zoomfactor));
      newend.add_minutes(+diff / (long int) (2.0*zoomfactor));
    }
  
  
  if(newstart<ostart)
    newstart=ostart;

  if(newend>oend)
    newend=oend;

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;

  start_time=newstart;
  end_time=newend;
  
  nicen_timeaxis();
  
  update_old_index();
}



// zoom towards start and end;
void plot_axis::zoom_startend(double startcoord, double endcoord)
{
  double startbuff=start, endbuff=end;
  double newstart, newend;

  if(isempty)
    return;

  if(type==TIME_X_AXIS)
    {
      zoom_time_startend(startcoord, endcoord);
      return;
    }

  if(scaling==AXIS_LOGARITHMIC)
    {
      startbuff=log10(start);
      endbuff=log10(end);
    }
  else if(scaling==AXIS_LOGIT_PERCENT)
    {
      startbuff=logit(start,true);
      endbuff=logit(end,true);
    }
  else if(scaling==AXIS_LOGIT_ABSOLUTE)
    {
      startbuff=logit(start,false);
      endbuff=logit(end,false);
    }
  else if(scaling==AXIS_PROBIT_PERCENT)
    {
      startbuff=probit(start,true);
      endbuff=probit(end,true);
    }
  else if(scaling==AXIS_PROBIT_ABSOLUTE)
    {
      startbuff=probit(start,false);
      endbuff=probit(end,false);
    }

  if(type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS)
    {
      newstart = startbuff + (startcoord - pt->plot_x0) /
	((double) pt->plot_x1 - (double) pt->plot_x0) * 
	(endbuff-startbuff);
      newend = startbuff + (endcoord - pt->plot_x0) /
	((double) pt->plot_x1 - (double) pt->plot_x0) * 
	(endbuff-startbuff);
    }
  else
    {
      newstart = startbuff + (startcoord - pt->plot_y0) /
	((double) pt->plot_y1 - (double) pt->plot_y0) * 
	(endbuff-startbuff);
      newend = startbuff + (endcoord - pt->plot_y0) /
	((double) pt->plot_y1 - (double) pt->plot_y0) * 
	(endbuff-startbuff);
    }
  
  if(scaling==AXIS_LOGARITHMIC)
    {
      newstart = pow(10.0, newstart);
      newend   = pow(10.0, newend);
    }
  else if(scaling==AXIS_LOGIT_PERCENT)
    {
      newstart = invlogit(newstart,true);
      newend   = invlogit(newend,true);
    }
  else if(scaling==AXIS_LOGIT_ABSOLUTE)
    {
      newstart = invlogit(newstart,false);
      newend   = invlogit(newend,false);
    }
  else if(scaling==AXIS_PROBIT_PERCENT)
    {
      newstart = invprobit(newstart,true);
      newend   = invprobit(newend,true);
    }
  else if(scaling==AXIS_PROBIT_ABSOLUTE)
    {
      newstart = invprobit(newstart,false);
      newend   = invprobit(newend,false);
    }

  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;

  start=non_niced_start=newstart;
  end=non_niced_end=newend;

  nicen();
  
  update_old_index();
}

// zoom towards start and end;
void plot_axis::zoom_time_startend(double startcoord, double endcoord)
{
  DateTime startbuff=start_time, endbuff=end_time;
  DateTime newstart, newend;
  long int diff=endbuff.difference_minutes(startbuff);

  if(isempty)
    return;

  if(diff<30)
    {
      newstart = startbuff + (long int) ((startcoord - (double) pt->plot_x0) /
	((double) pt->plot_x1 - (double) pt->plot_x0) * 
	(double) (endbuff-startbuff));
      newend = startbuff + (long int) ((endcoord - (double) pt->plot_x0) /
	((double) pt->plot_x1 - (double) pt->plot_x0) * 
	(double) (endbuff-startbuff));
    }
  else
     {
       newstart = startbuff;

       newstart.add_minutes((long int) ((startcoord - (double) pt->plot_x0) /
					((double) pt->plot_x1 - 
					 (double) pt->plot_x0) *
					(double) diff));
       newend = startbuff;
       newend.add_minutes((long int) ((endcoord - (double) pt->plot_x0) /
				      ((double) pt->plot_x1 - 
				       (double) pt->plot_x0) * 
				      (double) diff));
    }

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;

  start_time=newstart;
  end_time=newend;

  nicen_timeaxis();
  
  update_old_index();
}



// get old coordinate settings
void plot_axis::get_old(void)
{
  if(isempty)
    return;
  
  if(old_index>=1)
    old_index--;

  start_time=oldstart_time[old_index];
  end_time=oldend_time[old_index];
  start=non_niced_start=oldstart[old_index];
  end=non_niced_end=oldend[old_index];
  scaling=old_scaling[old_index];
  
  nicen();
}

// get newer coordinate settings
void plot_axis::get_new(void)
{
  if(isempty)
    return;
  
  if(old_index<max_index)
    old_index++;
  
  start_time=oldstart_time[old_index];
  end_time=oldend_time[old_index];
  start=non_niced_start=oldstart[old_index];
  end=non_niced_end=oldend[old_index];
  scaling=old_scaling[old_index];
  
  nicen();
}

// build widgets in the plot info window
void plot_axis::build_info(widget parent)
{
  if(isempty)
    return;
  
  coordh1.build(parent);
  coordlab.build(coordh1, title);
  coordlab.build(coordh1, "  - verdi : ");
  coordvalue.build(coordh1, " ????? ");
  coordvalue.Background("white");
  coordvalue.Foreground("black");
  
  coord_built=true;
}

// update coordinate info;
general_value plot_axis::update_coordinates(double x, double y)
{
  double value;
  double startbuff=start, endbuff=end;
  general_value gv;

  gv.time=NoDateTime;
  gv.value=MISSING_VALUE;

  if(isempty)
    return gv;

  if(scaling==AXIS_LOGARITHMIC)
    {
      startbuff=log10(start);
      endbuff=log10(end);
    }
  else if(scaling==AXIS_LOGIT_PERCENT)
    {
      startbuff=logit(start,true);
      endbuff=logit(end,true);
    }
  else if(scaling==AXIS_LOGIT_ABSOLUTE)
    {
      startbuff=logit(start,false);
      endbuff=logit(end,false);
    }
  else if(scaling==AXIS_PROBIT_PERCENT)
    {
      startbuff=probit(start,true);
      endbuff=probit(end,true);
    }
  else if(scaling==AXIS_PROBIT_ABSOLUTE)
    {
      startbuff=probit(start,false);
      endbuff=probit(end,false);
    }

  if(type==TIME_X_AXIS)
    {
      long int diff=end_time.difference_minutes(start_time);
      DateTime dt;
      char *ptr;

      if(diff<30)
	dt=start_time + (long int) ((x - (double) pt->plot_x0)/
	((double) pt->plot_x1 - (double) pt->plot_x0) * 
	(double) (endbuff - startbuff));
      else
	dt=start_time + (long int) ((x - (double) pt->plot_x0)/
	((double) pt->plot_x1 - (double) pt->plot_x0) * 
	(double) diff)*60;

      ptr=dt.syCh(1);
      if(!coord_built && pt)
	build_info(*pt->get_coord_row());
      coordvalue.labelString(ptr);
      delete [] ptr;
      gv.time=dt;
      return gv;
    }
  else if(type==NORMAL_X_AXIS || type==CATEGORICAL_X_AXIS)
    value = startbuff + (x - pt->plot_x0)/
      ((double) pt->plot_x1 - (double) pt->plot_x0) * 
      (endbuff - startbuff);
  else
    value = startbuff + (y - pt->plot_y0)/
      ((double) pt->plot_y1 - (double) pt->plot_y0) * 
      (endbuff - startbuff);
  
  if(scaling==AXIS_LOGARITHMIC)
    value=pow(10.0, value);
  else if(scaling==AXIS_LOGIT_PERCENT)
    value=invlogit(value,true);
  else if(scaling==AXIS_LOGIT_ABSOLUTE)
    value=invlogit(value,false);
  else if(scaling==AXIS_PROBIT_PERCENT)
    value=invprobit(value,true);
  else if(scaling==AXIS_PROBIT_ABSOLUTE)
    value=invprobit(value,false);
  
  gv.value=value;
  
  if(!coord_built && pt)
    build_info(*pt->get_coord_row());
  coordvalue.labelString("%10.5g", value);
  
  return gv;
}


// translate;
void plot_axis::translate(double relative_translation)
{
  if(scaling==AXIS_LOGIT_PERCENT || scaling==AXIS_LOGIT_ABSOLUTE ||
     scaling==AXIS_PROBIT_PERCENT || scaling==AXIS_PROBIT_ABSOLUTE)
    return;

  double diff=end-start, startbuff=start, endbuff=end;
  double ostart=origstart, oend=origend;

  if(isempty)
    return;

  if(type==TIME_X_AXIS)
    {
      translate_time(relative_translation);
      return;
    }

  if(scaling==AXIS_LOGARITHMIC)
    {
      diff=log10(end-start);
      startbuff=log10(start);
      endbuff=log10(end);
      ostart=floor(log10(origstart));
      oend=ceil(log10(origend));
    }

  startbuff -= diff*relative_translation;
  endbuff   -= diff*relative_translation;

  if(startbuff<ostart)
    startbuff=ostart;

  if(endbuff>oend)
    endbuff=oend;

  if(scaling==AXIS_LOGARITHMIC)
    {
      startbuff = pow(10.0, startbuff);
      endbuff   = pow(10.0, endbuff);
    }

  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;
  
  start=non_niced_start=startbuff;
  end=non_niced_end=endbuff;

  nicen();

  update_old_index();
}

// translate;
void plot_axis::translate_time(double relative_translation)
{
  DateTime startbuff=start_time, endbuff=end_time;
  DateTime ostart=origstart_time, oend=origend_time;
  long int diff = endbuff.difference_minutes(startbuff);

  if(isempty)
    return;

  if(diff<60)
    {
      if(relative_translation>0.0)
	{
	  startbuff = startbuff - (long int) (((double) (endbuff-startbuff))*
					      relative_translation);
	  endbuff   = endbuff   - (long int) (((double) (endbuff-startbuff))*
					      relative_translation);
	}
      else
	{
	  startbuff = startbuff + (long int) (((double) (endbuff-startbuff))*
					      (-relative_translation));
	  endbuff   = endbuff   + (long int) (((double) (endbuff-startbuff))*
					      (-relative_translation));
	}
    }
  else
    {
      if(relative_translation>0.0)
	{
	  startbuff = startbuff - (long int) (((double) diff) * 
					      relative_translation)*60;
	  endbuff   = endbuff   - (long int) (((double) diff) * 
					      relative_translation)*60;
	}
      else
	{
	  startbuff = startbuff + (long int) (((double) diff) * 
					      (-relative_translation))*60;
	  endbuff   = endbuff   + (long int) (((double) diff) * 
					      (-relative_translation))*60;
	}
    }

  if(startbuff<ostart)
    startbuff=ostart;

  if(endbuff>oend)
    endbuff=oend;

  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;
  old_scaling[old_index]=scaling;
  
  start_time=startbuff;
  end_time=endbuff;

  nicen_timeaxis();

  update_old_index();
}


// go to original coordiante set;
void plot_axis::home(void)
{
  if(isempty)
    return;

  oldstart[old_index]=start;
  oldend[old_index]=end;
  old_scaling[old_index]=scaling;
  oldstart_time[old_index]=start_time;
  oldend_time[old_index]=end_time;

  start=non_niced_start=origstart;
  end=non_niced_end=origend;
  //logarithmic=False;

  start_time=origstart_time;
  end_time=origend_time;

  nicen();

  update_old_index();
}

// build widgets in the scaling window;
void plot_axis::build_scale(widget parent)
{
  if(isempty)
    return;

  scaleh1.build(parent);
  scalelab.build(scaleh1, title);
  if(type==TIME_X_AXIS)
    {
      timestartf.build(scaleh1, 20, "Start-tid:");
      timeendf.build(scaleh1, 20, "  Slutt-tid:");
    }
  else
    {
      scalestartf.build(scaleh1, 10, "Start-verdi:");
      scaleendf.build(scaleh1, 10, "  Slutt-verdi:");
    }

  scale_built=True;
}

// update the start and end field in the scaling window;
void plot_axis::update_scale(void)
{
  if(isempty)
    return;
  
  if(!scale_built && pt)
    {
      pt->scale_extra_text.Map();
      build_scale(pt->scalev1);
    }

  if(type==TIME_X_AXIS)
    {
      timestartf.SetDateTime(start_time,1);
      timeendf.SetDateTime(end_time,1);
    }
  else
    {
      scalestartf.SetDouble(start);
      scaleendf.SetDouble(end);
    }
}

// do scaling based on the given scaling info;
void plot_axis::do_scale(void)
{
  if(isempty)
    return;

  if(type==TIME_X_AXIS)
    {
      int status;
      DateTime startbuff, endbuff;

      startbuff = timestartf.getdatetime(&status, 1);
      if(status)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Feil", 
					    (char *) "Error"), 
		    WHAT((char *) "Feil format i tidsstart-feltet. "
		    "Korrekt format: 01/01-2000 00:00",
			 (char *) "Wrong format in time start field. "
			 "Correct format: 31/01/2000 00:00"));
	  return;
	}

      endbuff   = timeendf.getdatetime(&status, 1);
      if(status)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Feil", 
					    (char *) "Error"), 
		    WHAT((char *) "Feil format i tidsslutt-feltet. "
			 "Korrekt format: 31/12-1999 23:59",
			 (char *) "Wrong fromat in end time field."
			 " Correct format: 31/12-2000 23:59"));
	  return;
	}

      if(startbuff>=endbuff)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Feil", 
					    (char *) "Error"), 
		    WHAT((char *) "Start tid kommer etter (eller er "
			 "lik) slutt-tid!",
			 (char *) "Start time comes after (or is equal) "
			 "end time"));
	  return;
	}

      oldstart_time[old_index]=start_time;
      oldend_time[old_index]=end_time;
      old_scaling[old_index]=scaling;

      start_time=startbuff;
      end_time=endbuff;
    }
  else
    {
      oldstart[old_index]=start;
      oldend[old_index]=end;
      old_scaling[old_index]=scaling;

      start = scalestartf.getdouble();
      end   = scaleendf.getdouble();
    }

  nicen();
  update_old_index();
}



void plot_axis::set_new_plotting_coordinates(int newx0, int newy0, 
					     int newx1, int newy1)
{
  x0=newx0;
  y0=newy0;
  x1=newx1;
  y1=newy1;
}



// ***************************************************
//
//              PLOT_LINE_VIEWCOLOR
// A color viewing module meant to be used by 
// "plot_line".
//
// ***************************************************

plot_line_viewcolor::plot_line_viewcolor()
{
  created=False;
}

void plot_line_viewcolor::create(const char *initcolor, plot_line *ipt)
{
  if(!created)
    {
      sh.build(mainwin::toplevel, "Valg av farge");
      Create(sh, initcolor);
    }
  else
    setcolor(initcolor);

  sh.Map();
  pt=ipt;;

  created=True;
}

void plot_line_viewcolor::ok(const char *color, int /* red_ */, 
			     int /* green_ */, int /* blue_ */)
{
  pt->color_chosen(color);

  sh.Unmap();
}

void plot_line_viewcolor::cancelled(void)
{
  sh.Unmap();
}


// ***************************************************
//
//            PLOT_LINE_BUTTON
// A button class used by "plot_line".
//
// ***************************************************

void plot_line_button::Create(widget parent, const char *txt, plot_line *ipt)
{
  build(parent, txt);
  pt=ipt;
}

void plot_line_button::pushed(void)
{
  pt->button_pushed();
}



// ***************************************************
//
//                PLOT_LINE
// Represent a function/graph in the plotting module
//
// ***************************************************


// constructor
plot_line::plot_line()
{
  arg=NULL;
  value=NULL;
  origarg=NULL;
  origvalue=NULL;
  x_axis=NULL;
  y_axis=NULL;
  pt=NULL;
  strcpy(title, "");
  strcpy(orig_axistitle,"");
  orig_scaling=AXIS_LINEAR;
  x0=y0=x1=y1=MISSING_VALUE;
  linex=liney=(int) MISSING_VALUE;
  time1=time2=NoDateTime;
  timearg=NULL;
  origtimearg=NULL;
  minargdiff=MISSING_VALUE;
  ordered=False;
  shown=True;
}

// destructor
void plot_line::cleanup(bool clean_orig)
{
  if(arg)
    delete [] arg;
  arg=NULL;

  if(value)
    delete [] value;
  value=NULL;

  if(timearg)
    delete [] timearg;
  timearg=NULL;

  if(clean_orig)
    {
      if(origarg)
	delete [] origarg;
      origarg=NULL;
      
      if(origvalue)
	delete [] origvalue;
      origvalue=NULL;
      
      if(origtimearg)
	delete [] origtimearg;
      origtimearg=NULL;
    }

  shown=True;
}

// destructor
plot_line::~plot_line()
{
  cleanup(True);
}

// Creates the graph, sending along all neccessary info;
void plot_line::Create(const char *title_, double *newarg, double *newval, 
		       int len, plot_axis *xaxis, plot_axis *yaxis,
		       int line_x, int line_y, 
		       PLOTLINE_STYLE style_, const char *color_, int width_,
		       PLOT_FONT_SIZE fontsize, PLOTLINE_TYPE plot_type_,
		       plot_module *ipt)
{
  register int i;
  
  shown=True;
  ordered=True;
  cleanup();
  
  domake(title_, newval, len, xaxis, yaxis, line_x, line_y, 
	 style_, color_, width_, fontsize, plot_type_, ipt);
  minargdiff=MISSING_VALUE;
  
  origarg=new double[len+1];
  arg=new double[len+1];
  for(i=0;i<length;i++)
    {
      arg[i]=newarg[i];
      origarg[i]=newarg[i];

      if(i>0 && arg[i-1]>arg[i])
	ordered=False;

      if(i>0 && value[i]!=MISSING_VALUE && value[i-1]!=MISSING_VALUE &&
	 (minargdiff==MISSING_VALUE || minargdiff>(arg[i]-arg[i-1])))
	minargdiff=arg[i]-arg[i-1];
    }
  
  time1=time2=NoDateTime;
  x0=x1=MISSING_VALUE;
  for(i=0;i<length;i++)
    {
      if(arg[i]!=MISSING_VALUE   && (x0==MISSING_VALUE || x0>arg[i]))
	x0=arg[i];
      if(arg[i]!=MISSING_VALUE   && (x1==MISSING_VALUE || x1<arg[i]))
	x1=arg[i];
    }

  if(length==1)
    {
      length=2;
      arg[1]=newarg[0];
      origarg[1]=newarg[0];
      value[1]=newval[0];
      origvalue[1]=newval[0];
      minargdiff=0.0;
    }

  timeserie=False;
}

void plot_line::Create(const char *title_, DateTime *newarg, double *newval, 
		       int len, plot_axis *xaxis, plot_axis *yaxis,
		       int line_x, int line_y, 
		       PLOTLINE_STYLE style_, const char *color_, int width_,
		       PLOT_FONT_SIZE fontsize, PLOTLINE_TYPE plot_type_,
		       plot_module *ipt)
{
  register int i;

  ordered=True;
  shown=True;
  cleanup();
  domake(title_, newval, len, xaxis, yaxis, line_x, line_y, 
	 style_, color_, width_, fontsize, plot_type_, ipt);
  minargdiff=MISSING_VALUE;

  timearg=new DateTime[len+1];
  origtimearg=new DateTime[len+1];
  for(i=0;i<length;i++)
    {
      timearg[i]=newarg[i];
      origtimearg[i]=newarg[i];

      if(i>0 && timearg[i-1]>timearg[i])
	ordered=False;

      if(i>0 && value[i]!=MISSING_VALUE && value[i-1]!=MISSING_VALUE &&
	 (minargdiff==MISSING_VALUE || minargdiff>(timearg[i]-timearg[i-1])))
	minargdiff=timearg[i]-timearg[i-1];
    }

  time1=time2=NoDateTime;
  x0=x1=MISSING_VALUE;
  for(i=0;i<length;i++)
    {
      if(timearg[i]!=NoDateTime && (time1==NoDateTime || time1>timearg[i]))
	time1=timearg[i];
      if(timearg[i]!=NoDateTime && (time2==NoDateTime || time2<timearg[i]))
	time2=timearg[i];
    }

  if(length==1)
    {
      length=2;
      timearg[1]=newarg[0];
      origtimearg[1]=newarg[0];
      value[1]=newval[0];
      origvalue[1]=newval[0];
      minargdiff=0.0;
    }

  timeserie=True;
}

void plot_line::domake(const char *title_, double *newval, 
		       int len, plot_axis *xaxis, plot_axis *yaxis,
		       int line_x, int line_y, 
		       PLOTLINE_STYLE style_, const char *color_, int width_,
		       PLOT_FONT_SIZE fontsize, PLOTLINE_TYPE plot_type_,
		       plot_module *ipt)
{
  register int i;

  strcpy(title, title_);
  x_axis=xaxis;
  y_axis=yaxis;
  y_axis_orig=yaxis;
  strcpy(orig_axistitle,yaxis->get_title());
  orig_scaling=yaxis->get_scaling();
  pt=ipt;
  linex=line_x;
  liney=line_y;
  length=len;
  origlength=len;
  strcpy(color, color_);
  strcpy(colorbuffer, color_);
  style=style_;
  font_size=fontsize;
  plot_type=plot_type_;
  if(plot_type!=PLOTLINE_BACKGROUND)
    {
      width=width_;
      if(pt->is_big())
	width++;
    }
  else
    {
      width=0;
      background_y_percentage=double(width_);
    }

  value=new double[length+1];
  origvalue=new double[length+1];

  for(i=0;i<length;i++)
    {
      value[i]=newval[i];
      origvalue[i]=newval[i];
    }

  y0=y1=MISSING_VALUE;
  for(i=0;i<length;i++)
    {
      if(value[i]!=MISSING_VALUE && (y0==MISSING_VALUE || y0>value[i]))
	y0=value[i];
      if(value[i]!=MISSING_VALUE && (y1==MISSING_VALUE || y1<value[i]))
	y1=value[i];
    }
}



// plot the graph;
void plot_line::do_plot(void)
{
  plot_title();
  plot_graph();
  pt->Set_No_Dashes(width);
}



// plot the title
void plot_line::plot_title(void)
{
  static int  plotline_stylesizes[9] = { 2, 2, 2, 4, 4, 6, 2, 2, 6 };
  static char plotline_style1[]={1,0};
  static char plotline_style2[]={3,3};
  static char plotline_style3[]={9,3};
  static char plotline_style4[]={9,3,3,3};
  static char plotline_style5[]={9,3,6,3};
  static char plotline_style6[]={9,3,3,3,3,3};
  static char plotline_style7[]={6,3};
  static char plotline_style8[]={12,3};
  static char plotline_style9[]={6,4,6,4,3,4};
  static char *plotline_styles[]  = { plotline_style1, plotline_style2, 
				      plotline_style3, plotline_style4, 
				      plotline_style5, plotline_style6,
				      plotline_style7, plotline_style8, 
				      plotline_style9};

  if(title && *title)
    {
      pt->SetFg("black");
      pt->setfont(font_size);
      pt->Text(title, linex+30, liney+7); 
    }

  if(style==PLOTLINE_SOLID || plot_type==PLOTLINE_DOT || 
     plot_type==PLOTLINE_BACKGROUND)
    pt->Set_No_Dashes(width);
  else
    //pt->Set_Dashes(style3, 2, width);
    pt->Set_Dashes(plotline_styles[(int) style], 
		   plotline_stylesizes[(int) style], width);
  
  pt->SetFg(color);

  if(title && *title)
    {
      switch(plot_type)
	{
	case PLOTLINE_LINE:
	case PLOTLINE_LINEDOT:
	case PLOTLINE_BARS:
	case PLOTLINE_FILLEDBARS:
	  pt->Line(linex, liney, linex+25, liney);
	  break;
	case PLOTLINE_BACKGROUND:
	  pt->Rectangle(linex, liney-8, linex+25, liney+8, True);
	  break;
	case PLOTLINE_DOT:
	  for(int x=linex;x<=linex+25;x+=10)
	    pt->Point(x, liney, (DRAW_POINT_TYPE) style);
	  break;
	default:
	  break;
	}
    }
}


// plot the graph
void plot_line::plot_graph(void)
{
  plot_point *head=NULL, *tail=NULL;
  register int i=1, len=0;
  DateTime dt1=x_axis->get_start_time(), dt2=x_axis->get_end_time();
  bool check_y=(plot_type!=PLOTLINE_BACKGROUND) ? true : false;
  bool check_x=(plot_type!=PLOTLINE_BARS && 
		   plot_type!=PLOTLINE_FILLEDBARS) ? true : false;
		   
  if(plot_type==PLOTLINE_BACKGROUND)
    {
      // If the plotting type is 'background' the y values are immaterial
      // and can be used for indicating the start (0) and end (1) of each
      // rectangle. These are assumed to have been fed the module alternating.
      for(i=0;i<length;i++)
	value[i]=i%2;
      i=1;
    }
  
  while(i<length)
    {
      plot_point *newtail=NULL;

      if(timeserie)
	{
	  if(!pt->is_radial)
	    {
	      if(timearg[i]<dt1)
		{
		  i++;
		  continue;
		}
	      
	      if(timearg[i-1]>dt2)
		{
		  i++;
		  continue;
		}
	    }
	}

      if(head==NULL)
	{
	  if(timeserie)
	    {
	      if(!pt->is_radial)
		{
		  head=tail=get_startp(timearg[i-1], value[i-1], 
				       timearg[i], value[i],
				       x_axis->get_start_time(), 
				       y_axis->get_start(), 
				       x_axis->get_end_time(), 
				       y_axis->get_end(),
				       y_axis->get_scaling(), check_y,
				       check_x);
		}
	      else // radial series shouldn't be clipped in the x-direction
		{
		  head=tail=get_startp(timearg[i-1], value[i-1], 
				       timearg[i], value[i],
				       time1-60,
				       y_axis->get_scaling()==AXIS_LINEAR ?
				       (pt->startyaxisatzero ? 
					-y_axis->get_end() :
					y_axis->get_start()) :
				       y_axis->get_start(),
				       time2+60,
				       y_axis->get_end(),
				       y_axis->get_scaling(), check_y,
				       check_x);
		}
	    }
	  else
	    {
	      if(!pt->is_radial)
		{
		  head=tail=get_startp(arg[i-1], value[i-1], arg[i], value[i],
				       x_axis->get_start(), 
				       y_axis->get_start(), 
				       x_axis->get_end(), y_axis->get_end(),
				       x_axis->get_scaling(), 
				       y_axis->get_scaling(), check_y,
				       check_x);
		}
	      else // radial series shouldn't be clipped in the x-direction
		{
		  head=tail=get_startp(arg[i-1], value[i-1], arg[i], value[i],
				       x0-1, 
				       pt->startyaxisatzero ? 
				       -y_axis->get_end() :
				       y_axis->get_start(), 
				       x1+1, y_axis->get_end(),
				       x_axis->get_scaling(),
				       y_axis->get_scaling(), check_y,
				       check_x);
		}
	    }
	  
	  len=1;
	}
     
      if(timeserie)
	{
          if(!pt->is_radial)
	    newtail=get_endp(timearg[i-1], value[i-1], timearg[i], value[i],
			     x_axis->get_start_time(), y_axis->get_start(), 
			     x_axis->get_end_time(), y_axis->get_end(),
			     y_axis->get_scaling(), check_y,
			     check_x);
	  else // radial series shouldn't be clipped in the x-direction
	    newtail=get_endp(timearg[i-1], value[i-1], 
			     timearg[i], value[i],
			     time1-60, 
			     pt->startyaxisatzero ? -y_axis->get_end() :
			     y_axis->get_start(), 
			     time2+60, y_axis->get_end(),
			     y_axis->get_scaling(), check_y,
			     check_x);
	}
      else
	{
	  if(!pt->is_radial)
	    newtail=get_endp(arg[i-1], value[i-1], arg[i], value[i],
			     x_axis->get_start(), y_axis->get_start(), 
			     x_axis->get_end(), y_axis->get_end(),
			     x_axis->get_scaling(), 
			     y_axis->get_scaling(), check_y,
			     check_x);
	  else // radial series shouldn't be clipped in the x-direction
	    newtail=get_endp(arg[i-1], value[i-1], arg[i], value[i],
			     x0-1.0, 
			     pt-> startyaxisatzero ? -y_axis->get_end() :
			     y_axis->get_start(), 
			     x1+1.0, y_axis->get_end(),
			     x_axis->get_scaling(), 
			     y_axis->get_scaling(), check_y,
			     check_x);
	}
      
      if(newtail && !head)
	{
	  head=tail=newtail;
	  len=1;
	}
      else if(newtail)
	{
	  tail->append(newtail);
	  tail=newtail;
	  len++;
	}
      
      if(head && plot_type!=PLOTLINE_BACKGROUND)
	{
	  if(timeserie)
	    {
	      if(len>50000 || !newtail || newtail->get_dt() != timearg[i] || 
		 ((y_axis->get_scaling()==AXIS_LINEAR && 
		   newtail->get_y() != value[i]) ||
		  (y_axis->get_scaling()==AXIS_LOGARITHMIC && 
		   newtail->get_y() != log10(value[i])) ||
		  (y_axis->get_scaling()==AXIS_LOGIT_PERCENT && 
		   newtail->get_y() != logit(value[i],true)) ||
		  (y_axis->get_scaling()==AXIS_LOGIT_ABSOLUTE && 
		   newtail->get_y() != logit(value[i],false)) ||
		  (y_axis->get_scaling()==AXIS_PROBIT_PERCENT && 
		   newtail->get_y() != probit(value[i],true)) ||
		  (y_axis->get_scaling()==AXIS_PROBIT_ABSOLUTE && 
		   newtail->get_y() != probit(value[i],false)) ))
		// this point not found, or it is clipped
		{
		  plot_list(head);
		  delete head;
		  head=tail=NULL;
		  len=0;
		}
	    }
	  else
	    {
	      if(len>50000 || !newtail || 
		 ((x_axis->get_scaling()==AXIS_LINEAR && 
		   newtail->get_x() != arg[i]) || 
		  (x_axis->get_scaling()==AXIS_LOGARITHMIC && 
		   newtail->get_x() != log10(arg[i])) ||
		  (x_axis->get_scaling()==AXIS_LOGIT_PERCENT && 
		   newtail->get_x() != logit(arg[i],true)) ||
		  (x_axis->get_scaling()==AXIS_LOGIT_ABSOLUTE && 
		   newtail->get_x() != logit(arg[i],false)) ||
		  (x_axis->get_scaling()==AXIS_PROBIT_PERCENT && 
		   newtail->get_x() != probit(arg[i],true)) ||
		  (x_axis->get_scaling()==AXIS_PROBIT_ABSOLUTE && 
		   newtail->get_x() != probit(arg[i],false)) ) ||
		 ((!y_axis->get_scaling()==AXIS_LINEAR && 
		   newtail->get_y() != value[i]) ||
		  (y_axis->get_scaling()==AXIS_LOGARITHMIC && 
		   newtail->get_y() != log10(value[i]))  ||
		  (y_axis->get_scaling()==AXIS_LOGIT_PERCENT && 
		   newtail->get_y() != logit(value[i],true)) ||
		  (y_axis->get_scaling()==AXIS_LOGIT_ABSOLUTE && 
		   newtail->get_y() != logit(value[i],false)) ||
		  (y_axis->get_scaling()==AXIS_PROBIT_PERCENT && 
		   newtail->get_y() != probit(value[i],true)) ||
		  (y_axis->get_scaling()==AXIS_PROBIT_ABSOLUTE && 
		   newtail->get_y() != probit(value[i],false)) ) )  
		// this point not found, or it is clipped
		{
		  plot_list(head);
		  delete head;
		  head=tail=NULL;
		  len=0;
		}
	    }
	}
	

      i++;
    }
  
  if(head)
    {
      plot_list(head);
      delete head;
      head=tail=NULL;
    }
}



void plot_line::plot_list(plot_point *head)
{
  int len=head->number_of_elements();
  register int i;
  register plot_point *ptr;
  double xaxisstart=x_axis->get_start();
  double xaxisend=x_axis->get_end();
  double yaxisstart=y_axis->get_start();
  double yaxisend=y_axis->get_end();
  DateTime dt1=x_axis->get_start_time();
  DateTime dt2=x_axis->get_end_time();

  // If this is a background plot, there's no sense in checking the y value:
  bool check_y=(plot_type!=PLOTLINE_BACKGROUND) ? true : false;

  if(x_axis -> get_scaling()==AXIS_LOGARITHMIC)
    {
      xaxisstart=log10(xaxisstart);
      xaxisend=log10(xaxisend);
    }
  else if(x_axis -> get_scaling()==AXIS_LOGIT_PERCENT)
    {
      xaxisstart=logit(xaxisstart,true);
      xaxisend=logit(xaxisend,true);
    }
  else if(x_axis -> get_scaling()==AXIS_LOGIT_ABSOLUTE)
    {
      xaxisstart=logit(xaxisstart,false);
      xaxisend=logit(xaxisend,false);
    }
  else if(x_axis -> get_scaling()==AXIS_PROBIT_PERCENT)
    {
      xaxisstart=probit(xaxisstart,true);
      xaxisend=probit(xaxisend,true);
    }
  else if(x_axis -> get_scaling()==AXIS_PROBIT_ABSOLUTE)
    {
      xaxisstart=probit(xaxisstart,false);
      xaxisend=probit(xaxisend,false);
    }

  if(y_axis -> get_scaling()==AXIS_LOGARITHMIC)
    {
      yaxisstart=log10(yaxisstart);
      yaxisend=log10(yaxisend);
    }
  else if(y_axis -> get_scaling()==AXIS_LOGIT_PERCENT)
    {
      yaxisstart=logit(yaxisstart,true);
      yaxisend=logit(yaxisend,true);
    }
  else if(y_axis -> get_scaling()==AXIS_LOGIT_ABSOLUTE)
    {
      yaxisstart=logit(yaxisstart,false);
      yaxisend=logit(yaxisend,false);
    }
  else if(y_axis -> get_scaling()==AXIS_PROBIT_PERCENT)
    {
      yaxisstart=probit(yaxisstart,true);
      yaxisend=probit(yaxisend,true);
    }
  else if(y_axis -> get_scaling()==AXIS_PROBIT_ABSOLUTE)
    {
      yaxisstart=probit(yaxisstart,false);
      yaxisend=probit(yaxisend,false);
    }

  // rescale the list;
  if(pt->is_radial)
    {
      if(timeserie)
	for(ptr=head; ptr; ptr = (plot_point *) ptr->getnext())
	  ptr->polar_rescale(pt->radius, pt->radial_year, pt->radial_min, 
			     yaxisstart, yaxisend, check_y);
      else
	for(ptr=head; ptr; ptr = (plot_point *) ptr->getnext())
	  ptr->polar_rescale(pt->radius, pt->radial_len, 
			     yaxisstart, yaxisend, check_y);
    }
  else if(plot_type!=PLOTLINE_FILLEDBARS && plot_type!=PLOTLINE_BARS)
    {
      if(timeserie)
	for(ptr=head; ptr; ptr = (plot_point *) ptr->getnext())
	  ptr->rescale(pt->plot_x0, pt->plot_y0, pt->plot_x1, pt->plot_y1,
		       dt1, yaxisstart, dt2, yaxisend, False, check_y);
      else
	for(ptr=head; ptr; ptr = (plot_point *) ptr->getnext())
	  ptr->rescale(pt->plot_x0, pt->plot_y0, pt->plot_x1, pt->plot_y1,
		       xaxisstart, yaxisstart, xaxisend, yaxisend, 
		       False, check_y);
    }
  
  switch(plot_type)
    {
    case PLOTLINE_LINE:
    case PLOTLINE_LINEDOT:
      if(len==1)
	{
	  if(!pt->is_radial)
	    {
	      if(head->is_within())
		pt->Point(int(head->get_x()), int(head->get_y()), 
			  (DRAW_POINT_TYPE) style);
	    }
	  else
	    {
	      double x = ((double) pt->plot_centerx) + head->get_y() *
		cos(head->get_x());
	      double y = ((double) pt->plot_centery) - head->get_y() *
		sin(head->get_x());

	      if(head->is_within())
		pt->Point(int(x), int(y), (DRAW_POINT_TYPE) style);
	    }
	}
      else
	{
	  if(!pt->is_radial)
	    {
	      double *argbuffer=new double[len], *valbuffer=new double[len];
	  
	      i=0;
	      for(ptr=head; ptr; ptr=(plot_point *) ptr->getnext())
		{
		  argbuffer[i] = (double) ptr->get_x();
		  valbuffer[i] = (double) ptr->get_y();
		  i++;
		}
	      
	      // debug pt->Rectangle(627,633,633,676);
	      if(ordered)
		pt->plotlines(argbuffer, valbuffer, len);
	      else
		pt->Lines(argbuffer, valbuffer, len);
	      
	      delete [] argbuffer;
	      delete [] valbuffer;
	    }   
	  else
	    {
	      double angle;
	      double corrangle=M_PI/2.0*
		double(int(pt->radialtype)-
		       int(PLOT_RADIAL_START_RIGHTWARDS));
	      
	      for(ptr=head; ptr && ptr->getnext(); 
		  ptr=(plot_point *) ptr->getnext())
		{
		  plot_point *ptr2=(plot_point *) ptr->getnext();
		  double angle1=ptr->get_x(), angle2=ptr2->get_x();
		  double rad1=ptr->get_y(), rad2=ptr2->get_y();
		  double diffangle=angle2-angle1, oldangle=angle1;
		  
		  while(diffangle<0.0)
		    {
		      diffangle += 2.0*M_PI;
		      angle2 += 2.0*M_PI;
		    }

		  if(diffangle>pt->max_diff_angle)
		    {
		      for(angle=angle1+pt->max_diff_angle; 
			  angle<=angle2 && angle!=oldangle;
			  angle=MINIM(angle2, angle+pt->max_diff_angle))
			{
			  double bufferrad1=rad1+(rad2-rad1)*
			    (oldangle-angle1)/(angle2-angle1); 
			  double bufferrad2=rad1+(rad2-rad1)*
			    (angle-angle1)/(angle2-angle1);
			  double angle_old=oldangle,angle_new=angle;
			  if(!pt->counterclockwise)
			    {
			      angle_old=-angle_old;
			      angle_new=-angle_new;
			    }
			  angle_old+=corrangle;
			  angle_new+=corrangle;

			  double x_0 = ((double) pt->plot_centerx) + 
			    bufferrad1 * cos(angle_old);
			  double y_0 = ((double) pt->plot_centery) - 
			    bufferrad1 * sin(angle_old);
			  double x_1 = ((double) pt->plot_centerx) + 
			    bufferrad2 * cos(angle_new);
			  double y_1 = ((double) pt->plot_centery) - 
			    bufferrad2 * sin(angle_new);
			  
			  pt->Line(x_0,y_0,x_1,y_1);
			  oldangle=angle;
			}
		    }
		  else
		    {
		      double angle_old=angle1,angle_new=angle2;
		      if(!pt->counterclockwise)
			{
			  angle_old=-angle_old;
			  angle_new=-angle_new;
			}
		      angle_old+=corrangle;
		      angle_new+=corrangle;

		      double x_0 = ((double) pt->plot_centerx) + 
			rad1 * cos(angle_old);
		      double y_0 = ((double) pt->plot_centery) - 
			rad1 * sin(angle_old);
		      double x_1 = ((double) pt->plot_centerx) + 
			rad2 * cos(angle_new);
		      double y_1 = ((double) pt->plot_centery) - 
			rad2 * sin(angle_new);

		       pt->Line(x_0,y_0,x_1,y_1);
		    }
		}
	    }
	}

      if(plot_type==PLOTLINE_LINE)
	break;
    case PLOTLINE_DOT:
      pt->Set_No_Dashes(width);
      
      if(!pt->is_radial)
	{
	  for(ptr=head; ptr; ptr=(plot_point *) ptr->getnext())
	    if(ptr->is_within() && within(ptr->get_x(), ptr->get_y(), 
					  pt->plot_x0, pt->plot_y0, 
					  pt->plot_x1, pt->plot_y1))
	      pt->Point(int(ptr->get_x()), int(ptr->get_y()), 
			(DRAW_POINT_TYPE) style);
	}
      else
	{
	  for(ptr=head; ptr; ptr=(plot_point *) ptr->getnext())
	    {
	      double x = ((double) pt->plot_centerx) + ptr->get_y() *
		cos(ptr->get_x());
	      double y = ((double) pt->plot_centery) - ptr->get_y() *
		sin(ptr->get_x());
	      
	      if(ptr->is_within())
		pt->Point(int(x), int(y), (DRAW_POINT_TYPE) style);
	    }
	}
      break;
    case PLOTLINE_BACKGROUND:
      if(pt->is_radial)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Programfeil", 
					    (char *) "Program error"),
		    WHAT((char *) "Bakgrunnsfarge ikke implementert "
			 "for polarplott!", 
			 (char *) "Background color not implemented "
			 "for polar plots!"));

	}
      else
	{
	  pt->Set_No_Dashes(0);
	  int start_y=pt->plot_y0;
	  int end_y=pt->plot_y0+
	    int(floor(background_y_percentage/100.0*
		      double(pt->plot_y1-pt->plot_y0)));

	  for(ptr=head; ptr; ptr=(plot_point *) ptr->getnext())
	    if(ptr->is_within() && within(ptr->get_x(), ptr->get_y(), 
					  pt->plot_x0, pt->plot_y0, 
					  pt->plot_x1, pt->plot_y1, false))
	      {
		plot_point *nextptr=(plot_point *) ptr->getnext();
		
		if(ptr==head && ptr->get_y()>0.99) // only one value and
						   // that's the end of a rectangle?
		  pt->Rectangle(pt->plot_x0,  start_y, 
				ptr->get_x(), end_y, 
				True);
		else if(ptr->get_y()<0.01) // start of rectangle?
		  {
		    if(!nextptr) // no end of rectangle?
		      pt->Rectangle(ptr->get_x(),  start_y, 
				    pt->plot_x1, end_y, 
				    True);
		    // end of rectangle within the plotting area?
		    else if(!nextptr->is_within() ||
			    !within(nextptr->get_x(), nextptr->get_y(), 
				    pt->plot_x0, start_y, 
				    pt->plot_x1, end_y, false))
		      pt->Rectangle(ptr->get_x(),  pt->plot_y0, 
				    pt->plot_x1, pt->plot_y1, 
				    True);
		    else
		      // end of rectangle outside the plotting area?
		      pt->Rectangle(ptr->get_x(),  start_y, 
				    nextptr->get_x(), end_y, 
				    True);
		  }
	      }	  
	}
      break;
    case PLOTLINE_FILLEDBARS:
    case PLOTLINE_BARS:
      {
	char oppositecolor[100];
	unsigned int red, green, blue;
	    
	sscanf(color+1, "%02x", &red);
	sscanf(color+3, "%02x", &green);
	sscanf(color+5, "%02x", &blue);
	
	sprintf(oppositecolor, "#%02x%02x%02x", 
		255-red, 255-green, 255-blue);
	
	pt->Set_No_Dashes(width);
	
	if(!pt->is_radial)
	  {
	    plot_point *oldptr=NULL;
	    int kk=0;
    
	    for(ptr=head; ptr; ptr=(plot_point *) ptr->getnext())
	      {
		plot_point *start, *end, 
		  *nextitem=(plot_point *) ptr->getnext();
		
		if(timeserie)
		  {
		    if(ptr==head)
		      start=new plot_point(NULL, ptr->get_dt() - 
					   (long int) (minargdiff/2.0), 
					   ptr->get_y(), ptr->is_within());
		    else if((!pt->checkequalbars) || 
			    oldptr->get_y()!=ptr->get_y())
		      start=new plot_point(NULL, 
					   oldptr->get_dt() + 
					   (ptr->get_dt()-oldptr->get_dt())/2, 
					   ptr->get_y(), ptr->is_within());
		    else
		      start=new plot_point(NULL, 
					   oldptr->get_dt(), 
					   ptr->get_y(), ptr->is_within());
		    
		    if(!nextitem)
		      end=new plot_point(NULL, ptr->get_dt() +
					 (long int) (minargdiff/2.0), 0.0, 
					 ptr->is_within());
		    else if((!pt->checkequalbars) || 
			    nextitem->get_y()!=ptr->get_y())
		      end=new plot_point(NULL, ptr->get_dt() + 
					 (nextitem->get_dt() - 
					  ptr->get_dt())/2, 
					 0.0, ptr->is_within());
		    else
		      end=new plot_point(NULL, nextitem->get_dt(), 
					 0.0, ptr->is_within());

		    start->rescale(pt->plot_x0, pt->plot_y0, 
				   pt->plot_x1, pt->plot_y1,
				   dt1, yaxisstart, dt2, yaxisend, True);
		    end->rescale(pt->plot_x0, pt->plot_y0, 
				 pt->plot_x1, pt->plot_y1, 
				 dt1, yaxisstart, dt2, yaxisend, True);
		  }
		else
		  {
		    if(ptr==head)
		      start=new plot_point(NULL, ptr->get_x()-minargdiff/2.0, 
					   ptr->get_y(), ptr->is_within());
		    else
		      start=new plot_point(NULL, 
					   (ptr->get_x()+oldptr->get_x())/2.0, 
					   ptr->get_y(), ptr->is_within());
		    
		    if(!nextitem)
		      end=new plot_point(NULL, 
					 ptr->get_x()+minargdiff/2.0, 0.0, 
					 ptr->is_within());
		    else
		      end=new plot_point(NULL, 
					 (ptr->get_x()+nextitem->get_x())/2.0, 
					 0.0, ptr->is_within());

		    start->rescale(pt->plot_x0, pt->plot_y0, 
				   pt->plot_x1, pt->plot_y1,
				   xaxisstart, yaxisstart, xaxisend, yaxisend, 
				   True, check_y);
		    end->rescale(pt->plot_x0, pt->plot_y0, pt->plot_x1, 
				 pt->plot_y1,
				 xaxisstart, yaxisstart, xaxisend, yaxisend, 
				 True, check_y);
		  }
		
		if(plot_type==PLOTLINE_FILLEDBARS)
		  {
		    pt->SetFg(oppositecolor);
		    pt->Rectangle(start->get_x(), start->get_y(), 
				  end->get_x(), end->get_y());
		    pt->SetFg(color);
		  }
		
		pt->Rectangle(start->get_x(), start->get_y(), 
			      end->get_x(), end->get_y(), 
			      plot_type==PLOTLINE_FILLEDBARS ? True : False);

		if(plot_type==PLOTLINE_FILLEDBARS)
		  {
		    pt->SetFg(oppositecolor);
		    pt->Rectangle(start->get_x(), start->get_y(), 
				  end->get_x(), end->get_y());
		    pt->SetFg(color);
		  }
		
		oldptr=ptr;
		kk++;
	      } // for
	  }
	else // pt->is_radial
	  {
	    for(ptr=head; ptr && ptr->getnext(); 
		ptr=(plot_point *) ptr->getnext())
	      {
		plot_point *ptr2=(plot_point *) ptr->getnext(),
		  *ptr0=(plot_point *) ptr->getprev();
		// PS: angles in radians!
		double angle0 = ptr0 ? ptr0->get_x() : 0.0;
		double angle1=ptr->get_x(), angle2=ptr2->get_x();
		double rad=ptr->get_y();
		double x0,y0,x1,y1;
		
		if(!pt->counterclockwise)
		  {
		    angle0=-angle0;
		    angle1=-angle1;
		    angle2=-angle2;
		  }
		if(pt->radialtype==PLOT_RADIAL_START_UPWARDS)
		  {
		    angle0+=M_PI/2.0;
		    angle1+=M_PI/2.0;
		    angle2+=M_PI/2.0;
		  }
		else if(pt->radialtype==PLOT_RADIAL_START_LEFTWARDS)
		  {
		    angle0+=M_PI;
		    angle1+=M_PI;
		    angle2+=M_PI;
		  } 
		 else if(pt->radialtype==PLOT_RADIAL_START_DOWNWARDS) 
		   {
		    angle0+=3.0*M_PI/2.0;
		    angle1+=3.0*M_PI/2.0;
		    angle2+=3.0*M_PI/2.0;
		  }
		
		/*
		while(angle1<0.0)
		  angle1+=2.0*M_PI;
		while(angle1>2.0*M_PI)
		  angle1-=2.0*M_PI;
		while(angle0>angle1)
		  angle0 -= 2.0*M_PI;
		while(angle1>angle2)
		  angle2 += 2.0*M_PI;
		*/
		
		double diffangle1=angle1-angle0;
		double diffangle2=angle2-angle1;
		double diffangle=MINIM(ABSVAL((diffangle1)), 
				       ABSVAL((diffangle2)));
		if(!pt->counterclockwise)
		  diffangle=-diffangle;

		x0=((double) pt->plot_centerx)+rad*cos(angle1-diffangle/2.0);
		y0=((double) pt->plot_centery)-rad*sin(angle1-diffangle/2.0);
		x1=((double) pt->plot_centerx)+rad*cos(angle1+diffangle/2.0);
		y1=((double) pt->plot_centery)-rad*sin(angle1+diffangle/2.0);

		if(plot_type==PLOTLINE_FILLEDBARS)
		  {
		    pt->SetFg(oppositecolor);
		    pt->circle(pt->plot_centerx, pt->plot_centery, rad, False,
			       360.0/2.0/M_PI*(angle1-diffangle/2.0), 
			       360.0/2.0/M_PI*diffangle);
		    pt->Line(pt->plot_centerx, pt->plot_centery, x0, y0);
		    pt->Line(pt->plot_centerx, pt->plot_centery, x1, y1);
		    pt->SetFg(color);
		    pt->circle(pt->plot_centerx, pt->plot_centery, rad, True,
			       360.0/2.0/M_PI*(angle1-diffangle/2.0), 
			       360.0/2.0/M_PI*diffangle);
		    pt->SetFg(oppositecolor);
		    pt->circle(pt->plot_centerx, pt->plot_centery, rad, False,
			       360.0/2.0/M_PI*(angle1-diffangle/2.0), 
			       360.0/2.0/M_PI*diffangle);
		    pt->Line(pt->plot_centerx, pt->plot_centery, x0, y0);
		    pt->Line(pt->plot_centerx, pt->plot_centery, x1, y1);
		    pt->SetFg(color);
		  }
		else
		  {
		    pt->circle(pt->plot_centerx, pt->plot_centery, rad, False,
			       360.0/2.0/M_PI*(angle1-diffangle/2.0), 
			       360.0/2.0/M_PI*diffangle);
		    pt->Line(pt->plot_centerx, pt->plot_centery, x0, y0);
		    pt->Line(pt->plot_centerx, pt->plot_centery, x1, y1);
		  }

	      }
	  }
	break;
      default:
	err.build(mainwin::toplevel, WHAT((char *) "Programfeil", 
					  (char *) "Program error"),
		  WHAT((char *) "Ukjent plottetype", 
		       (char *) "Unknown plot type"));
	break;
      }
    } // switch
}

PLOT_FONT_SIZE plot_line::get_fontsize(void)
{
  if(*title)
    return font_size;
  else 
    return PLOT_FONT_UNKNOWN;
}

// smallest time-value
DateTime plot_line::get_start_time(void)
{
  return time1;
}

// largest time-value
DateTime plot_line::get_end_time(void)
{
  return time2;
}

// smallest x-value
double plot_line::get_x0(void) 
{
  return x0;
}

// smallest y-value
double plot_line::get_y0(void) 
{
  return y0;
}

// largest x-value
double plot_line::get_x1(void) 
{
  return x1;
}

// largest y-value
double plot_line::get_y1(void) 
{
  return y1;
}

void plot_line::set_title_x(double new_line_x) // start x-pos for title
{
  linex=(int) new_line_x;
}

void plot_line::set_title_y1(int newy1)
{
  liney=(int) newy1;
}

int plot_line::get_title_height(void)
{
  if(*title)
    return font_y_size[font_size];
  else
    return 0;
}

void plot_line::build_linechange(widget &parent)
{
  char *linetypes[]={(char *) "_______________ / O",
		     WHAT((char *) "............... / triangel", 
			  (char *) "............... / triangle"),
		     WHAT((char *) "___ ___ ___ ___ / kors",
			  (char *) "___ ___ ___ ___ / cross"),
		     WHAT((char *) "_ . _ . _ . _ . / kryss", 
			  (char *) "_ . _ . _ . _ . / X"),
		     WHAT((char *) "_ ___ _ ___ _   / firkant",
			  (char *) "_ ___ _ ___ _   / square"),
		     WHAT((char *) "___ . . ___ . . / ruter",
			  (char *) "___ . . ___ . . / club"),
		     (char *) "- - - - - - - - / *",
		     WHAT((char *) "_____ _____     / sirkel+kors",
			  (char *) "_____ _____     / circle+cross"),
		     WHAT((char *) "__ __ . __ __ . / firkant+x", 
			  (char *) "__ __ . __ __ . / square+X")};
  char *plottypes[]={WHAT((char *) "Linjer", (char *) "Lines"), 
		     WHAT((char *) "Punkter", (char *) "Markers"), 
		     WHAT((char *) "Linjer+punkter", 
			  (char *) "Lines+markers"),
		     WHAT((char *) "S�yler", (char *) "Columns"), 
		     WHAT((char *) "Fylte s�yler",(char *) "Filled columns")};
  char *thicknesses[]={"1","2","3","4","5","6","7","8","9",
		       "10","11","12","13","14"};
  char *background_percentages[]={"0","1","2","3","5","8",
				  "10","20","30","40","50","60","70",
				  "80","90","100"};
  char *fontsizes[]={WHAT((char *) "Veldig liten",(char *) "Very small"), 
		     WHAT((char *) "Liten",(char *) "Small"), 
		     WHAT((char *) "Medium",(char *) "Medium"), 
		     WHAT((char *) "Stor", (char *) "Large"), 
		     WHAT((char *) "Veldig stor", (char *) "Very large"), 
		     WHAT((char *) "Ekstra stor", (char *) "Extra large"), 
		     WHAT((char *) "Ekstremt stor", 
			  (char *) "Extremely large")};

  linechangefr.build(parent);
  linechangev1.build(linechangefr);
  linetext.build(linechangev1, 110, WHAT((char *) "Tittel:", 
					(char *) "Title:"));
  linetext.SetText(title);

  linechangeh1.build(linechangev1);
  isactive.build(linechangeh1, WHAT((char *) "Vises:", (char *) "Shown:"));
  isactive.ToggleButtonOn();
  linetypemenu.Create(linechangeh1, WHAT((char *) "Linjestipling/punktvalg:",
					 (char *) "Line/marker choice:"));
  linetypemenu.Insert(linetypes, 9, (int) style);
  if(plot_type!=PLOTLINE_BACKGROUND)
    {
      thickness.Create(linechangeh1, WHAT((char *) "Linje-tykkelse:",
					  (char *) "Line thickness:"));
      thickness.Insert(thicknesses, 14, width-1);
    }
  else
    {
      background_y_percentage_choice.
	Create(linechangev1, 
	       WHAT((char *) "Prosent av y-aksen tatt av bakgrunnsfargen:", 
		    (char *) "Percentage of the y axis taken by the "
		    "background color"));
      
      int index_nearest=-1, sqrdist=100;
      for(int i=0;i<16;i++)
	{
	  int curr_dist=int(background_y_percentage)-
	    atoi(background_percentages[i]);
	  int curr_sqrdist=curr_dist*curr_dist;
	  if(index_nearest<0 || sqrdist>curr_sqrdist)
	    {
	      index_nearest=i;
	      sqrdist=curr_sqrdist;
	    }
	}

      background_y_percentage_choice.Insert(background_percentages,16,
					    index_nearest);
    }
  
  sepaxis.build(linechangeh1, WHAT((char *) "Separate akse", 
				   (char *) "Separate axis"));
  sepaxis.ToggleButtonOff();
  
  linechangeh2.build(linechangev1);
  
  fontsizemenu.Create(linechangeh2, WHAT((char *) "Fontst�rrelse p� tittel:", 
					 (char *) "Font size for the title:"));
  fontsizemenu.Insert(fontsizes, 7, (int) font_size);
  if(plot_type!=PLOTLINE_BACKGROUND)
    {
      plottype.Create(linechangeh2, WHAT((char *) "Plotte-type:", 
					 (char *) "Plotting type:"));
      plottype.Insert(plottypes, 5, (int) plot_type);
    }
  else
    plottype_background.build(linechangeh2, 
			      WHAT((char *) "Plotte-type: Bakgrunn",
				   (char *) "Plot type: Background"));
  
  changecolorb.Create(linechangeh2, WHAT((char *) "Forandre farge", 
					 (char *) "Change color:"),
		      this);
  showcolor.build(linechangeh2, 30, 30);
  showcolor.Background(color);
}


bool plot_line::do_linechange(void)
{
  strcpy(color, colorbuffer);
  strcpy(title, linetext());
  if(plot_type!=PLOTLINE_BACKGROUND)
    width = thickness.GetNumber()+1;
  else
    background_y_percentage=atoi(background_y_percentage_choice.CurrStr());
  
  style = (PLOTLINE_STYLE)     linetypemenu.GetNumber();
  font_size = (PLOT_FONT_SIZE) fontsizemenu.GetNumber();
  if(plot_type!=PLOTLINE_BACKGROUND)
    plot_type = (PLOTLINE_TYPE)  plottype.GetNumber();
  shown = isactive();
  
  if(shown && sepaxis()!=separate_axis)
    {
      separate_axis=sepaxis();
      return True;
    }
  else
    return False;
}

bool plot_line::is_separate_axis(void)
{
  return separate_axis;
}

bool plot_line::is_shown(void)
{
  return shown;
}

void plot_line::button_pushed(void)
{
  viewcol.create(colorbuffer, this);
}

void plot_line::color_chosen(const char *color_)
{
  strcpy(colorbuffer, color_);
  showcolor.Background(colorbuffer);
}


void plot_line::invert_color(void)
{
  unsigned int red,green,blue;

  sscanf(color, "#%02x%02x%02x", &red, &green, &blue);
  
  red=255-red;
  green=255-green;
  blue=255-blue;

  sprintf(color, "#%02x%02x%02x", red, green, blue);
  strcpy(colorbuffer, color);
  showcolor.Background(colorbuffer);
}


void plot_line::remove_missing(double gaplen)
{
  register long int i;

  if(timeserie)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Programfeil", 
						  "Program error")),
		(char *) (WHAT("Interpolasjonsrutine til verdi-verdi-plott "
			       "kalt for tidsserie!","Interpolation for value-"
			       "value plot called for timeserie line!")));
      return;
    }

  cleanup();
  arg=new double[origlength];
  value=new double[origlength];
  length=0;
  long int nextindex = (long int) MISSING_VALUE, 
    previndex = (long int) MISSING_VALUE;
  for(i=0; i<origlength; i++)
    {
      if(origvalue[i]!=MISSING_VALUE)
	{
	  nextindex = get_next_nonmissing(origvalue, origlength, i);
	  previndex = i;
	}

      if(nextindex==MISSING_VALUE || previndex==MISSING_VALUE ||
	 origvalue[i]!=MISSING_VALUE ||
	 ABSVAL((origarg[nextindex]-origarg[previndex]))<gaplen)
	{
	  arg[length]=origarg[i];
	  value[length]=origvalue[i];
	  
	  length++;
	}
    }
}

long int plot_line::get_next_nonmissing(double *values, long int len, 
					long int startindex)
{
  register long int i;

  for(i=startindex; i<len && values[i]==MISSING_VALUE; i++);
  
  if(i>=len)
    return (long int) MISSING_VALUE;
  else
    return i;
}

void plot_line::remove_missing(int yeargap, int daygap, int minutegap, 
			       int secgap)
{
  register long int i;
  
  if(!timeserie)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Programfeil", 
						  "Program error")),
		(char *) (WHAT("Interpolasjonsrutine til tidsserie-plott "
			       "kalt for verdi-verdi-graf!", 
			       "Interpolation for time"
			       "serie plot called for value-value line!")));
      return;
    }

  cleanup();
  timearg=new DateTime[origlength];
  value=new double[origlength];
  length=0;
  long int nextindex = (long int) MISSING_VALUE, 
    previndex = (long int) MISSING_VALUE;
  for(i=0; i<origlength; i++)
    {
      if(origvalue[i]!=MISSING_VALUE)
	{
	  nextindex = get_next_nonmissing(origvalue, origlength, i+1);
	  previndex = i;
	}

      if(nextindex==MISSING_VALUE || previndex==MISSING_VALUE ||
	 origvalue[i]!=MISSING_VALUE)
	{
	  timearg[length]=origtimearg[i];
	  value[length]=origvalue[i];
	  
	  length++;
	}
      else // we're in a gap
	{
	  long int yeardiff = origtimearg[nextindex].getYear()-
	    origtimearg[previndex].getYear();
	  long int daydiff = origtimearg[nextindex].dayOfYear() - 
	    origtimearg[previndex].dayOfYear();
	  long int diff = 
	    origtimearg[nextindex].difference_minutes(origtimearg[previndex]);
	  long int mindiff = diff - daydiff*1440;
	  DateTime prevdt(origtimearg[nextindex].getYear(),
			  origtimearg[nextindex].getMonth(),
			  origtimearg[nextindex].getDay(),
			  origtimearg[previndex].getHour(),
			  origtimearg[previndex].getMinute(),
			  origtimearg[previndex].getSecond());
	  long int diff2 = origtimearg[nextindex]-prevdt;
	  long int secdiff = diff2%86400l;
	  
	  if(daydiff<0)
	    {
	      yeardiff--;
	      daydiff += origtimearg[previndex].daysInYear();
	    }

	  if(mindiff<0)
	    {
	      daydiff--;
	      mindiff += 1440;
	      secdiff = 86400-secdiff;
	    }  

	  if(yeardiff>yeargap || 
	     (yeardiff==yeargap && 
	      (daydiff>daygap || 
	       (daydiff==daygap &&
		(mindiff>minutegap ||
		 (mindiff==minutegap &&
		  (secdiff>secgap))))))) // fill the gap?
	    {
	      timearg[length] = origtimearg[i];
	      value[length]   = origvalue[i];
	      
	      length++;
	    }
	}
    }
}
 
void plot_line::restore_original(void)
{
  register long int i;

  cleanup();

  length=origlength;
  value=new double[length];
  for(i=0;i<length;i++)
    value[i]=origvalue[i];

  if(timeserie)
    {
      timearg=new DateTime[length];
      for(i=0;i<length;i++)
	timearg[i]=origtimearg[i];
    }
  else
    {
      arg=new double[length];
      for(i=0;i<length;i++)
	arg[i]=origarg[i];
    }
}

bool plot_line::do_interpolate(void)
{
  return interpoltog();
}


void plot_line::build_interpolation(widget parent)
{
  char titlebuffer[30];
  
  strncpy(titlebuffer, title, 29);
  titlebuffer[29]='\0';

  interpolfr.build(parent);
  interpolh1.build(interpolfr);
  interpoltog.build(interpolh1, "");
  interpollab.build(interpolh1, titlebuffer);
  interpoltog.ToggleButtonOn();
}

plot_axis *plot_line::get_y_axis(void)
{
  return y_axis;
}

plot_axis *plot_line::get_orig_y_axis(void)
{
  return y_axis_orig;
}

const char *plot_line::get_orig_y_axis_title(void)
{
  return orig_axistitle;
}

AXIS_SCALING plot_line::get_orig_y_axis_scaling(void)
{
  return orig_scaling;
}

void plot_line::set_y_axis(plot_axis *new_y_axis)
{
  y_axis=new_y_axis;
}

void plot_line::reset_orig_y_axis(void)
{
  y_axis=y_axis_orig;
}

PLOTLINE_TYPE plot_line::get_type(void)
{
  return plot_type;
}

double plot_line::get_arg_min(void)
{
  double min=MISSING_VALUE;
  for(int i=0;i<length;i++)
    {
      if(arg[i]!=MISSING_VALUE && (min==MISSING_VALUE ||
				    arg[i]<min))
	min=arg[i];
    }
  return min;
}

double plot_line::get_arg_max(void)
{
  double max=MISSING_VALUE;
  for(int i=0;i<length;i++)
    {
      if(arg[i]!=MISSING_VALUE && (max==MISSING_VALUE ||
				    arg[i]>max))
	max=arg[i];
    }
  return max;
}

double plot_line::get_value_min(void)
{
  double min=MISSING_VALUE;
  for(int i=0;i<length;i++)
    {
      if(value[i]!=MISSING_VALUE && (min==MISSING_VALUE ||
				      value[i]<min))
	min=value[i];
    }
  return min;
}

double plot_line::get_value_max(void)
{
  double max=MISSING_VALUE;
  for(int i=0;i<length;i++)
    {
      if(value[i]!=MISSING_VALUE && (max==MISSING_VALUE ||
				      value[i]>max))
	max=value[i];
    }
  return max;
}





// ***************************************************
//
//               PLOT_TITLE
// Title of the plot
//
// ***************************************************


// creates the title;
void plot_title::Create(const char *newtitle, int newx, int newy, 
			PLOT_FONT_SIZE fontsize, plot_module *ipt)
{
  change_title(newtitle);
  x=newx;
  y=newy;
  font_size = fontsize;
  pt=ipt;
}

// change the title; 
void plot_title::change_title(const char *newtitle)
{
  if(newtitle)
    strcpy(title, newtitle);
  else
    strcpy(title, "");
}

// redraw;
void plot_title::redraw(void)
{
  if(*title)
    {
      pt->setfont(font_size);
      pt->SetFg("#000000");
      pt->Text(title, x, y);
    }
}

// build changing widgets;
void plot_title::build_chtitle(widget parent)
{
  char *sizes[]={WHAT((char *) "Medium", (char *) "Medium"), 
		 WHAT((char *) "Stor", (char *) "Large"),
		 WHAT((char *) "Veldig stor", (char *) "Very large"),
		 WHAT((char *) "Ekstra stor", (char *) "Extra large"),
		 WHAT((char *) "Ekstremt stor", (char *) "Extremely large")};

  changeh1.build(parent);
  changetxt.build(changeh1, 50, WHAT((char *) "Forandre tittel-tekst:", 
				     (char *) "Change title text:"));
  changetxt.SetText(title);
  changefontsize.Create(changeh1, WHAT((char *) "Font-st�rrelse", 
				       (char *) "Font size:"));
  changefontsize.Insert(sizes, 5, ((int) font_size)-2);

  
}

// change title from user input in widgets
void plot_title::change_title(void)
{
  font_size = (PLOT_FONT_SIZE) (changefontsize.GetNumber()+2);
  strcpy(title, changetxt());
}

int plot_title::get_height(void)
{
  if(*title)
    return font_y_size[font_size];
  else
    return 0;
}

plot_title::plot_title()
{
  strcpy(title,"");
  x=y=0;
  pt=NULL;
  font_size=PLOT_FONT_LARGE;
}

// ***************************************************
//
//           PLOT_EMAIL
//
// Email window for the plotting module.
// Tells the module when the window has been closed.
//
// ***************************************************

void plot_email::do_create(plot_module *ipt)
{
  pt=ipt;
  Create("","","",False);
}

void plot_email::ended(void)
{
  pt->email_ended();
}



// ***************************************************
//
//             PLOT_MENU
// A menu meant for the plotting module
// 
// ***************************************************

// Creates the menu;
void plot_menu::Create(Widget parent, plot_module *ipt, bool radial_plot,
		       char const* const* extra_window_menu_options, 
		       int num_extra_window_menu_options,
		       char const* const* extra_send_menu_options, 
		       int num_extra_send_menu_options,
		       bool logit_possible)
{
  int i;
  
  pt=ipt;

  if(num_extra_window_menu_options>0 && extra_window_menu_options)
    {
      num_extra_file=num_extra_window_menu_options;
      extra_file=new char*[num_extra_file];
      for(i=0;i<num_extra_file;i++)
	{
	  extra_file[i]=new char[100];
	  strcpy(extra_file[i], extra_window_menu_options[i]);
	}
    }
  
  if(num_extra_send_menu_options>0 && extra_send_menu_options)
    {
      num_extra_send=num_extra_send_menu_options;
      extra_send=new char*[num_extra_send];
      for(i=0;i<num_extra_send;i++)
	{
	  extra_send[i]=new char[100];
	  strcpy(extra_send[i], extra_send_menu_options[i]);
	}
    }
  
  
  int num_items=(!radial_plot ? 24 : 17) + 
    num_extra_window_menu_options +
    num_extra_send_menu_options;
  
  char **menustr=new char*[num_items];
  int j=0;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "STM:Vindu", (char *) "STM:Window"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "T:Grid p�/av", (char *) "T:Grid on/off"));
  j++;

  menustr[j]=new char[100];
  if(logit_possible)
    strcpy(menustr[j], WHAT((char *) "Log/logit/probit-akser", 
			    (char *) "Log/logit/probit axis"));
  else
    strcpy(menustr[j], WHAT((char *) "Logaritmiske akser", 
			    (char *) "Logarithmic axis"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Tegn p�ny (redraw)", 
			  (char *) "Redraw"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Forandre serie-visning", 
			  (char *) "Change serie presentation"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Forandre akser/tittel", 
			  (char *) "Change axis/title presentation"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Interpolasjon", 
			  (char *) "Interpolation"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Bytt om svart og hvitt", 
			  (char *) "Change black and white"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Bytt om alle fargene", 
		 (char *) "Switch all colors"));
  j++;

  if(extra_window_menu_options)
    for(i=0;i<num_extra_window_menu_options;i++)
      {
	menustr[j]=new char[100];
	strcpy(menustr[j], extra_window_menu_options[i]);
	j++;
      }

  menustr[j]=new char[100];
  strcpy(menustr[j], "SEP");
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Avslutt", 
			  (char *) "Close window"));
  j++;

  if(!radial_plot)
    {
      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "STM:Navigasjon", 
			      (char *) "STM:Navigation"));
      j++;

      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Zoom ut (pil opp)", 
			      (char *) "Zoom up (arrow up)"));
      j++;
      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Zoom ned (pil ned)", 
			      (char *) "Zoom down (arrow down)"));
      j++;

      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Rull til venstre (venstre piltast)", 
			      (char *) "Roll left (arror left)"));
      j++;
      
      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Rull til h�yre (h�yre piltast)", 
		 (char *) "Roll right (arrow right)"));
      j++;

      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Original koordinatsetting (Home)",
			      (char *) "Original coordinate setting (home)"));
      j++;
      
      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Tilbake (PageUp)", 
			      (char *) "Back (PageUp)"));
      j++;

      menustr[j]=new char[100];
      strcpy(menustr[j], "SEP");
      j++;
      
      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Skalering", (char *) "Scaling"));
      j++;
    }  
  else
    {
      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "STM:Navigasjon", 
			      (char *) "STM:Navigation"));
      j++;
      
      menustr[j]=new char[100];
      strcpy(menustr[j], WHAT((char *) "Skalering", (char *) "Scaling"));
      j++;
    }
  
  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "STM:Sende videre", 
			  (char *) "STM:Send"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Til skriver", 
			  (char *) "To printer"));
  j++;
  
  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Til fil", 
			  (char *) "To file"));
  j++;

  menustr[j]=new char[100];
  strcpy(menustr[j], WHAT((char *) "Som epost", 
			  (char *) "As email"));
  j++;

  if(extra_send_menu_options)
    for(i=0;i<num_extra_send_menu_options;i++)
      {
	menustr[j]=new char[100];
	strcpy(menustr[j], extra_send_menu_options[i]);
	j++;
      }
	   
  if(j!=num_items)
    {
      std::cerr << "Wrong number of items in plotting menu!" << std::endl;
      std::cerr << "Scheduled:" << num_items << std::endl;
      std::cerr << "Actual:" << j << std::endl;
      exit(0);
    }

  build_(parent, menustr, num_items);
}


// Called when the menu is pushed;
void plot_menu::pushed(const char *item)
{
  send_to_plot_module(item);
}

// Creates the menu;
void plot_optmenu::create(Widget parent, plot_module *ipt, PLOT_MENU_TYPE type,
			  bool logit_possible)
{
  pt=ipt;

  switch(type)
    {
    case PLOT_MENU_FILE:
      {
	char *opts[]={WHAT((char *) "Grid p�/av", (char *) "Grid on/off"), 
		      logit_possible ? 
		      WHAT((char *) "Log/logit/probit-akser", 
			   (char *) "Log/logit/probit axis") :
		      WHAT((char *) "Logaritmiske akser",
			   (char *) "Logarithmic axis"),
		      WHAT((char *) "Tegn p�ny (redraw)", (char *) "Redraw"), 
		      WHAT((char *) "Forandre serie-visning", 
			   (char *) "Change serie presentation"),
		      WHAT((char *) "Forandre akser/tittel", 
			   (char *) "Change axis/title presentation"), 
		      WHAT((char *) "Interpolasjon", (char *) "Interpolation"),
		      WHAT((char *) "Bytt om svart og hvitt", 
			   (char *) "Change black and white"),
		      WHAT((char *) "Bytt om alle fargene", 
			   (char *) "Switch all colors")};
	Create(parent, WHAT((char *) "Opsjoner:",(char *) "Options:")); 
	Insert(opts, 8, 0);
	break;
      }
    case PLOT_MENU_NAVIGATION:
      {
	char *navs[]={WHAT((char *) "Zoom ut (pil opp)", 
			   (char *) "Zoom up (arrow up)"),
		      WHAT((char *) "Zoom inn (pil ned)", 
			   (char *) "Zoom down (arrow down)"),
		      WHAT((char *) "Rull til venstre (venstre piltast)", 
			   (char *) "Roll left (arror left)"),
		      WHAT((char *) "Rull til h�yre (h�yre piltast)", 
			   (char *) "Roll right (arrow right)"),
		      WHAT((char *) "Original koordinatsetting (Home)",
			   (char *) "Original coordinate setting (home)"),
		      WHAT((char *) "Tilbake (PageUp)", (char *) "Back (PageUp)"),  
		      WHAT((char *) "Skalering", (char *) "Scaling")};
	Create(parent, WHAT((char *) "Navigasjon:",(char *) "Navigation:"));
	Insert(navs, 7, 4);
	break;
      }
    case PLOT_MENU_SEND:
      {
	char *sends[]={WHAT((char *) "Til skriver", (char *) "To printer"), 
		       WHAT((char *) "Til fil", (char *) "To file"),
		       WHAT((char *) "Som epost", (char *) "As email")};
	Create(parent, "Send:");
	Insert(sends, 3, 1);
	break;
      }
    }
}

// Called when the menu is pushed;
void plot_optmenu::pushed(const char *item)
{
  send_to_plot_module(item);
}

plot_genericmenu::plot_genericmenu()
{
  extra_file=extra_send=NULL;
  num_extra_file=num_extra_send=0;
}

plot_genericmenu::~plot_genericmenu()
{
  if(extra_file)
    doubledelete(extra_file, num_extra_file);
  if(extra_send)
    doubledelete(extra_send, num_extra_send);
  extra_file=extra_send=NULL;
  num_extra_file=num_extra_send=0;
}

void plot_genericmenu::send_to_plot_module(const char *item)
{
  
  if(!strcmp(item, WHAT((char *) "Avslutt", (char *) "Close window")))
    pt->menu_pushed(PLOT_EXIT);
  else if(!strcmp(item, WHAT((char *) "Grid p�/av", (char *) "Grid on/off")))
    pt->menu_pushed(PLOT_GRID);
  else if(!strcmp(item, WHAT((char *) "Log/logit/probit-akser", 
			     (char *) "Log/logit/probit axis")) ||
	  !strcmp(item, WHAT((char *) "Logaritmiske akser", 
			     (char *) "Logarithmic axis")))
    pt->menu_pushed(PLOT_LOG);
  else if(!strcmp(item, WHAT((char *) "Tegn p�ny (redraw)", 
			     (char *) "Redraw")))
    pt->menu_pushed(PLOT_REDRAW);
  else if(!strcmp(item, WHAT((char *) "Zoom ut (pil opp)", 
			     (char *) "Zoom up (arrow up)")))
    pt->menu_pushed(PLOT_UP);
  else if(!strcmp(item, WHAT((char *) "Zoom inn (pil ned)", 
			     (char *) "Zoom down (arrow down)")))
    pt->menu_pushed(PLOT_DOWN);
  else if(!strcmp(item, WHAT((char *) "Rull til venstre (venstre piltast)", 
			     (char *) "Roll left (arror left)")))
    pt->menu_pushed(PLOT_LEFT);
  else if(!strcmp(item, WHAT((char *) "Rull til h�yre (h�yre piltast)", 
			     (char *) "Roll right (arrow right)"))) 
    pt->menu_pushed(PLOT_RIGHT);
  else if(!strcmp(item, WHAT((char *) "Original koordinatsetting (Home)",
	     (char *) "Original coordinate setting (home)")))
    pt->menu_pushed(PLOT_HOME);
  else if(!strcmp(item, WHAT((char *) "Tilbake (PageUp)", (char *) "Back (PageUp)")))
    pt->menu_pushed(PLOT_BACK);
  else if(!strcmp(item, WHAT((char *) "Skalering", (char *) "Scaling")))
    pt->menu_pushed(PLOT_SCALE);
  else if(!strcmp(item, WHAT((char *) "Til skriver", (char *) "To printer")))
    pt->menu_pushed(PLOT_PRINT);
  else if(!strcmp(item, WHAT((char *) "Til fil", (char *) "To file")))
    pt->menu_pushed(PLOT_FILE);
  else if(!strcmp(item, WHAT((char *) "Som epost", (char *) "As email")))
    pt->menu_pushed(PLOT_EMAIL);
  else if(!strcmp(item, WHAT((char *) "Forandre serie-visning", 
			     (char *) "Change serie presentation")))
    pt->menu_pushed(PLOT_START_LINECHANGE);
  else if(!strcmp(item, WHAT((char *) "Interpolasjon", 
			     (char *) "Interpolation")))
    pt->menu_pushed(PLOT_START_INTERPOLATION);
  else if(!strcmp(item, WHAT((char *) "Forandre akser/tittel", 
			     (char *) "Change axis/title presentation")))
    pt->menu_pushed(PLOT_STARTCHANGEAXIS);
  else if(!strcmp(item, WHAT((char *) "Bytt om svart og hvitt", 
			     (char *) "Change black and white")))
    pt->menu_pushed(PLOT_SWITCH_BW);
  else if(!strcmp(item, WHAT((char *) "Bytt om alle fargene", 
			     (char *) "Switch all colors")))
    pt->menu_pushed(PLOT_SWITCH_ALL);
  else
    {
      int i;
      for(i=0;i<num_extra_file;i++)
	if(!strcmp(item, extra_file[i]))
	  {
	    pt->extra_file_menu_pushed(i);
	    return;
	  }
      for(i=0;i<num_extra_send;i++)
	if(!strcmp(item, extra_send[i]))
	  {
	    pt->extra_send_menu_pushed(i);
	    return;
	  }
      
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Meny-strengen ble ikke funnet!",
		     (char *) "Menu string not found!"));
    }
}




// **************************************
// 
//             PLOT_BUTTON
// A button class for this module.
//
// **************************************

// Creates the button and storea apointer back to the main object and
// the button type;
void plot_button::Create(widget parent, const char *txt, plot_module *ipt, 
			 PLOT_BUTTON_TYPE type)
{
  pt=ipt;
  typ=type;
  build(parent, txt);
  
  if(type==PLOT_EXIT_BUTTON)
    {
      Foreground("white");
      Background("red");
    }
}

// notifies the plotting module that a button has been pushed;
void plot_button::pushed(void)
{
  pt->button_pushed(typ);
}




// ***************************************************
//
//            PLOT_PRINTSHELL
// A window-class for choosing pritners
//
// ***************************************************

void plot_printshell::create(plot_module *ipt)
{
  pt=ipt;
  Create(getenv("PRINTER"));
}

void plot_printshell::ok_pushed(const char *newprinter)
{
  pt->changeprinter(newprinter);
}






// ***************************************************
//
//                   PLOT_MODULE
// A module meant for value7value plotting of
// multiple graphs.
// 
// ***************************************************


// called when a menu items is pushed;
void plot_module::menu_pushed(PLOT_MENU_ITEM item)
{
  if(!created)
    return;

  switch(item)
    {
    case PLOT_EXIT:
      {
	endpostscript();
	
	if(plot_type==PLOT_IN_SEPARATE_WINDOW)
	  sh.Unmap();
	Cleanup();
	plotchanged=False;
	plot_ended();
	break;
      }
    case PLOT_GRID:
      gridon = !gridon;
      plotchanged = True;
      if(gridon)
	{
	  for(int i=0;i<num_axis; i++)
	    axis[i].plot_gridlines();
	}
      else
	expose();
      break;
    case PLOT_LOG:
      start_set_logarithmic();
      break;
    case PLOT_REDRAW:
      redraw();
      break;
    case PLOT_UP:
      DoUp();
      break;
    case PLOT_DOWN:
      DoDown();
      break;
    case PLOT_LEFT:
      DoLeft();
      break;
    case PLOT_RIGHT:
      DoRight();
      break;
    case PLOT_HOME:
      DoHome();
      break;
    case PLOT_BACK:
      DoButton2(0,0);
      break;
    case PLOT_SCALE:
      start_set_scale();
      break;
    case PLOT_PRINT:
      startprint();
      break;
    case PLOT_FILE:
      startfile();
      break;
    case PLOT_EMAIL:
      startemail();
      break;
    case PLOT_START_LINECHANGE:
      startlinechange();
      break;
    case PLOT_START_INTERPOLATION:
      startinterpolate();
      break;
    case PLOT_STARTCHANGEAXIS:
      startchangeaxis();
      break;
    case PLOT_SWITCH_BW:
      switchcolors(False);
      break;
    case PLOT_SWITCH_ALL:
      switchcolors(True);
      break;
    }
}

void plot_module::redraw(void)
{
  plotchanged=True;
  expose();
}


// called when the user pushes a button;
void plot_module::button_pushed(PLOT_BUTTON_TYPE type)
{
  if((type==PLOT_DOPRINT || type==PLOT_SENDEMAIL) && func)
    {
      postscript_picture=True;
      redraw();
    }

  switch(type)
    {
    case PLOT_SETLOG:
      update_logarithmic();
      break;
    case PLOT_SETSCALE:
      update_scale();
      break;
    case PLOT_DOLINECHANGE:
      dolinechange();
      break;
    case PLOT_DOINTERPOLATION:
      do_interpolate();
      break;
    case PLOT_CHANGEPRINTER:
      startchangeprinter();
      break;
    case PLOT_DOPRINT:
      doprint();
      break;
    case PLOT_SENDEMAIL:
      doemail();
      break;
    case PLOT_DOAXISCHANGE:
      do_axischange();
      break;
    case PLOT_EXIT_BUTTON:
      {
	endpostscript();
	
	if(plot_type==PLOT_IN_SEPARATE_WINDOW)
	  sh.Unmap();
	Cleanup();
	plotchanged=False;
	plot_ended();
	break;
      }
    }
}


// show the scaling window;
void plot_module::start_set_scale(void)
{
  scalesh.Map();
  for(int i=0;i<num_axis;i++)
    axis[i].update_scale();
}

// show the log/logit/probit choices window;
void plot_module::start_set_logarithmic(void)
{
  logsh.Map();
  for(int i=0;i<num_axis;i++)
    axis[i].update_logwidget();
}


// update the scales;
void plot_module::update_scale(void)
{
  for(int i=0;i<num_axis;i++)
    axis[i].do_scale();
  
  scalesh.Unmap();
  
  plotchanged=True;
  expose();
}


// update log/logit/probit statuses of the different axis;
void plot_module::update_logarithmic(void)
{
  char errstr[200];
  int i;

  for(i=0;i<num_axis;i++)
    {
      if(axis[i].isempty)
	continue;

      AXIS_SCALING scaling=axis[i].user_scaling();

      if(scaling==AXIS_LOGARITHMIC && !axis[i].user_input_logwidget_okay())
	{
	  sprintf(errstr, WHAT((char *) "Feil i akse nummer %d: "
			       "Start-niv� enten ikke satt eller "
			       "satt ikke-positiv", 
			       (char *) "Error in axis number %d:"
			       "Start of scale either not set or "
			       "not set positive"), i);
	  err.build(mainwin::toplevel, 
		    WHAT((char *) "Feil", (char *) "Error"), errstr);
	  axis[i].set_scaling(AXIS_LINEAR);
	  return;
	}
      else if((scaling==AXIS_LOGIT_PERCENT || 
	       scaling==AXIS_LOGIT_ABSOLUTE || 
	       scaling==AXIS_PROBIT_PERCENT || 
	       scaling==AXIS_PROBIT_ABSOLUTE) && 
	      !axis[i].user_input_logwidget_okay())
	{
	  sprintf(errstr, WHAT((char *) "Feil i akse nummer %d: "
			       "Start/slutt-niv� enten ikke satt eller "
			       "satt ut over lovlige grenser!", 
			       (char *) "Error in axis number %d:"
			       "Start/end of scale either not set or "
			       "set out of bounds!"), i);
	  err.build(mainwin::toplevel, 
		    WHAT((char *) "Feil", (char *) "Error"), errstr);
	  axis[i].set_scaling(AXIS_LINEAR);
	  return;
	}
    }
  
  for(i=0;i<num_axis;i++)
    axis[i].update_logstatus();

  logsh.Unmap();
  
  plotchanged=True;
  expose();
}


void plot_module::switchcolors(bool all)
{
  do_invert_black_and_white();

  if(all)
    for(int i=1;i<numlines;i++)
      lines[i].invert_color();

  plotchanged=True;
  expose();
}

void plot_module::doinit(void)
{
  plot_x0=plot_y0=plot_x1=plot_y1=(int) MISSING_VALUE;
  plot_centerx=plot_centery=radius=MISSING_VALUE;
  num_axis=orig_num_axis=0;
  numxaxis=0;
  axis=NULL;
  numlines=0;
  lines=NULL;
  plotchanged=True;
  old_font_size=PLOT_FONT_UNKNOWN;
  vertical_yaxis_titles=True;
  emailwin=NULL;
}

// show the printing window
void plot_module::startprint(void)
{
  printsh.Map();
}

// show the printshell window;
void plot_module::startchangeprinter(void)
{
  prsh.create(this);
}

// Called when the user has chosen another printer;
void plot_module::changeprinter(const char *newprinter)
{
  static char plot_newprinter[100];
  
  sprintf(plot_newprinter, "PRINTER=%s", newprinter);

  putenv(plot_newprinter);

  printlab2.labelString(newprinter);
}


// send postscript code to the printer
void plot_module::doprint(void)
{
  char cmd[1000], *ptr, tempfile[1000];;
  DateTime now; now.now();
  
  ptr=now.syCh(2);
  sprintf(tempfile, "/tmp/plottemp%s%02d%ld.ps", ptr, now.getSecond(),
	  random());
  delete [] ptr;
  
  //sprintf(cmd, "cp %s %s", postscript_filename, tempfile);
  //system(cmd);  
  
  endpostscript();
  sprintf(cmd, "lpr %s", postscript_filename);
  int scode=system(cmd);
  if(scode!=0)
    printf("Command \"%s\" failed, error code %d!\n", cmd, scode);
  
  //startpostscript();
  
  //sprintf(cmd, "mv %s %s", tempfile, postscript_filename);
  //system(cmd);  
  
  printsh.Unmap();
}

// start the file selection window
void plot_module::startfile(void)
{
  char bufferfile[1000], *ptr;
  DateTime now;
  shelldialog qsh;
  vrow qv1;
  honlydigit qwidth;
  pushb qok;
  int plotwidth;
  
  now.now();
  
  ptr=now.syCh(2);
  sprintf(bufferfile, "/tmp/plotoutfile%s.ps", ptr);
  delete [] ptr;
  
  endpostscript();
  
  qsh.build(mainwin::toplevel, WHAT((char *) "Plotte-vidde", 
				    (char *) "Plotting window"));
  qv1.build(qsh);
  qwidth.build(qv1, 6, WHAT((char *) "Angi plottebildets vidde "
			    "(i antall piksler):",
			    (char *) "Set the picture width (in # pixels):"));
  qwidth.SetDigit(1000);
  qok.build(qv1, "OK");
  qok.Background("green");
  qok.Foreground("black");
  qsh.Map();
  
  qok.Wait();
  AddWorkCursor(qsh);
  
  plotwidth=qwidth.getdigit();
  
  if(func)
    {
      postscript_picture=True;
      redraw();
    }
  retouch_postscript(bufferfile, plotwidth, plotwidth/2, True, True);
  filewindow.Create(bufferfile, EPS);
  
  RmWorkCursor(qsh);
  qsh.Unmap();
}

// start the emailing window;
void plot_module::startemail(void) 
{
  emailsh.Map();
}

// send via email;
void plot_module::doemail(void)
{
  IMAGE_TYPE type=emailmenu.get_filetype();
  char bufferfile[1000], /* gifbuffer[100],*/ *ptr, cmd[2000];
  DateTime now;
  int plotwidth=emailwidth.getdigit();
  
  AddWorkCursor(emailsh);

  now.now();

  ptr=now.syCh(2);
  sprintf(bufferfile, "/tmp/plotoutfile%s.%ld.ps", ptr, random());
  
  endpostscript();
  retouch_postscript(bufferfile, plotwidth, plotwidth/2 /**sy/sx*/, 
		     True, True);
  
  if(type==EPS)
    strcpy(emailbufferfile, bufferfile);
#ifdef PSTOPDF
  else if(type==PDF)
    {
      sprintf(emailbufferfile, "/tmp/plotoutfile%s.%ld.pdf", ptr,random());
      sprintf(cmd, "ps2pdf %s %s", bufferfile, emailbufferfile);

      int scode=system(cmd);
      if(scode!=0)
	printf("Error: Command \"%s\" failed, error code %d!\n", cmd, scode);

      sprintf(cmd, "rm -f %s", bufferfile);
      int scode2=system(cmd);
      if(scode2!=0)
	printf("Error: Command \"%s\" failed, error code %d!\n", cmd, scode2);
    }
#endif // PSTOPDF
#ifdef PSTOEDIT
  else if(is_vector_type(type))
    {
      char buffer2[1000];
      sprintf(buffer2,"/tmp/plotoutfilebuffer%s.%ld.%s", ptr,random(), 
	      image_ext_name[(int) type]);
      sprintf(emailbufferfile, "/tmp/plotoutfile%s.%ld.%s", ptr,random(), 
	      image_ext_name[(int) type]);
      sprintf(cmd, "pstoedit -f %s %s %s", 
	      image_ext_name[(int) type],
	      bufferfile, buffer2);
      int scode3=system(cmd);
      if(scode3!=0)
	printf("Error: Command \"%s\" failed, error code %d!\n", cmd, scode3);

      if(type==SVG)
	{
	  sprintf(cmd, "sed s/\\&\\#36\\;/e/g %s > %s",
		  buffer2, emailbufferfile);
	  int scode4=system(cmd);
	  if(scode4!=0)
	    printf("Error: Command \"%s\" failed, error code %d!\n", 
		   cmd, scode4);
#ifndef NVE
	  unlink(buffer2);
#else
	  hydraenvir::system::unlink(buffer2);
#endif // NVE
	}
      else
	{
	  sprintf(cmd, "mv %s %s", buffer2, emailbufferfile);
	  int scode5=system(cmd);
	  if(scode5!=0)
	    printf("Error: Command \"%s\" failed, error code %d!\n", 
		   cmd, scode5);
	}

      sprintf(cmd, "rm -f %s", bufferfile);
      int scode6=system(cmd);
      if(scode6!=0)
	printf("Error: Command \"%s\" failed, error code %d!\n", 
	       cmd, scode6);
    }
#endif // PSTOEDIT
  else
    {
      sprintf(emailbufferfile, "/tmp/plotoutfile%s.%ld.%s", ptr,random(), 
	      image_ext_name[(int) type]);
      /*
      sprintf(gifbuffer, "/tmp/plotoutfile%s.%ld.gif", ptr, random());
      sprintf(cmd,"echo quit | gs -sDEVICE=ppmraw -q -dNOPAUSE -g%dx%d "
	      "-sOutputFile=- %s | ppmtogif > %s 2> /dev/null",
	      plotwidth, plotwidth*sy/sx,
	      bufferfile, gifbuffer);
      system(cmd);

      if(type==GIF)
	{
	  sprintf(cmd, "mv %s %s", gifbuffer, emailbufferfile);
	  system(cmd);
	}
      else
	{
      */
      sprintf(cmd, "convert -background \"#ffffff\" -transparent-color "
	      "\"#000001\" -transparent \"#000001\" %s %s", 
	      bufferfile /*gifbuffer*/, emailbufferfile);
      int scode7=system(cmd);
      if(scode7!=0)
	printf("Error: Command \"%s\" failed, error code %d!\n", 
	       cmd, scode7);
      
      /*
      sprintf(cmd, "rm -f %s", gifbuffer);
      system(cmd);
      }*/

      sprintf(cmd, "rm -f %s", bufferfile);
      int scode8=system(cmd);
      if(scode8!=0)
	printf("Error: Command \"%s\" failed, error code %d!\n", 
	       cmd, scode8);
    }

  if(emailwin)
    delete emailwin;
  emailwin=new plot_email();
  emailwin->do_create(this);
  emailwin->attach(emailbufferfile);

  RmWorkCursor(emailsh);

  emailsh.Unmap();
  delete [] ptr;
}      

void plot_module::email_ended(void)
{
  char cmd[1000];
  sprintf(cmd, "rm -f %s", emailbufferfile);
  int scode=system(cmd);
  if(scode!=0)
    printf("Error: Command \"%s\" failed, error code %d!\n", 
	   cmd, scode);
}


void plot_module::startchangeaxis(void)
{
  chaxissh.Map();
}

void plot_module::do_axischange(void)
{
  title.change_title();
  for(int i=0;i<num_axis;i++)
    axis[i].do_axischange();

  drawrect=bordertoggle();
  drawinternalrect=internalbordertoggle();
  chaxissh.Unmap();

  plotchanged=True;
  expose();
}

void plot_module::startlinechange(void)
{
  linechangesh.Map();
}

// show the interpolation window
void plot_module::startinterpolate(void)
{
  interpolsh.Map();
}


// draw the contour plot
void plot_module::draw_contour(void)
{
  if(!axis)
    return;

  register int i,j=0;
  int numx=plot_x1-plot_x0;
  int numy=plot_y0-plot_y1;
  double **values=new double*[numy];
  double x0=axis[0].get_start();
  double x1=axis[0].get_end();
  double y1=axis[1].get_start();
  double y0=axis[1].get_end();
  double min,max;
  rgb **picture=new rgb*[numx];

  for(i=0;i<numx;i++)
    picture[i]=new rgb[numy];

  for(i=0;i<numy;i++)
    {
      double y = y0 + double(i)/double(numy-1)*(y1-y0);

      values[i]=new double[numx];
      for(j=0;j<numx;j++)
	{
	  double x = x0 + double(j)/double(numx-1)*(x1-x0);

	  values[i][j]=func(x,y);
	}
    }

  min=max=values[0][0];
  for(i=0;i<numy;i++)
    for(j=0;j<numx;j++)
      {
	if(min==MISSING_VALUE || 
	   (min>values[i][j] && values[i][j]!=MISSING_VALUE))
	  min=values[i][j];
	if(max==MISSING_VALUE || 
	   (max<values[i][j] && values[i][j]!=MISSING_VALUE))
	  max=values[i][j];
      }

  double z,step=int(floor(log10(max-min)))-1;
  step=pow(10.0, step);
  
  while((max-min)/step>60)
    step*=10.0;

  if((max-min)/step>30)
    step*=5;
  else if((max-min)/step>15)
    step*=2;

  min=floor(min/step)*step;
  max=ceil(max/step)*step;

  for(i=0;i<numy;i++)
    for(j=0;j<numx;j++)
      if(values[i][j]!=MISSING_VALUE)
	{
	  if(color_map)
	    {
	      hsv hue((values[i][j]-min)/(max-min)*0.9, 1, 1);
	      picture[j][i]=hsv_to_rgb(hue);
	    }
	  else
	    {
	      unsigned char intensity=
		(unsigned char) (255.0*(values[i][j]-min)/(max-min)*0.9);
	      rgb rgbbuffer(intensity,intensity,intensity);
	      picture[j][i]=rgbbuffer;
	    }
	}
      else
	picture[j][i]=blackrgb;

  show_sprite(picture, numx, numy, plot_x0, plot_y1, blackrgb,
	      postscript_picture);
  postscript_picture=False;

  i=0;
  for(z=min;z<=max;z+=step)
    {
      rgb color;

      if(color_map)
	{
	  hsv hue((z-min)/(max-min)*0.9, 1, 1);
	  rgb rgbbuffer=hsv_to_rgb(hue);
	  color=rgbbuffer;
	}
      else
	{
	  unsigned char intensity=
	    (unsigned char) (255.0*(z-min)/(max-min)*0.9);
	  rgb rgbbuffer(intensity,intensity,intensity);
	  color=rgbbuffer;
	}
      
      char colorname[20], value[10];

      sprintf(colorname, "#%02x%02x%02x", int(color.red), int(color.green), 
	      int(color.blue));
      SetFg(colorname);
      Rectangle(plot_x1+6, plot_y1-4+i*35, plot_x1+19, plot_y1+9+i*35, True);

      SetFg("#000000");
      Rectangle(plot_x1+5, plot_y1-5+i*35, plot_x1+20, plot_y1+10+i*35);

      set_number_as_string(value, z, 2);
      setfont(PLOT_FONT_VERYSMALL);
      Text(value, plot_x1+5, plot_y1+22+i*35);

      i++;
    }
  
}

// do the interpolation;
void plot_module::do_interpolate(void)
{
  interpolsh.Unmap();

  for(int i=0;i<numlines;i++)
    if(lines[i].do_interpolate())
      {
	if(timeserie)
	  lines[i].remove_missing(interpolyear(), interpolday(), 
				  interpolminute(), interpolsec());
	else
	  lines[i].remove_missing(interpolvalue.getdouble());
      }
    else
      lines[i].restore_original();

  plotchanged=True;
  expose();
}

void plot_module::dolinechange(void)
{
  bool sepaxis_change=False, *sepchange=new bool[numlines];;
  int i,j;
  int numlines2=0;
  
  for(i=0;i<numlines;i++)
    {
      sepchange[i]=lines[i].do_linechange();
      if(lines[i].is_shown())
	numlines2++;
    }
  
  for(i=0;i<numlines;i++)
    if(sepchange[i] && lines[i].is_shown())
      sepaxis_change=True;
  
  linechangesh.Unmap();
  
  plotchanged=True;
  
  if(sepaxis_change || numlines2!=numlines)
    {
      // count the number of axis now:
      int numaxis_new=0;
      
      //DateTime xstart2=axis[0].get_start_time();
      //DateTime xend2=axis[0].get_end_time();
      
      for(i=0;i<numlines;i++)
	if(lines[i].is_shown())
	  {
	    if(lines[i].is_separate_axis())
	      numaxis_new++;
	    else
	      {
		bool first=True;
		for(j=0;j<i && first;j++) // axis already in use?
		  if(lines[i].get_orig_y_axis()==lines[j].get_orig_y_axis() && 
		     !lines[j].is_separate_axis() && lines[j].is_shown())
		    first=False;
		if(first)
		  numaxis_new++;
	      }
	  }
      
      numaxis_new+=numxaxis;

      char **axistitles=new char*[numaxis_new];
      AXIS_SCALING *axisstatus=new AXIS_SCALING[numaxis_new];

      for(i=0;i<numaxis_new;i++)
	{
	  axistitles[i]=new char[1000];
	  axisstatus[i]=AXIS_LINEAR;
	}

      for(i=0;i<numxaxis;i++)
	{
	  strcpy(axistitles[i], axis[i].get_title());
	  axisstatus[i]=axis[i].get_scaling();
	}

      int k=0;
      for(i=0;i<numlines;i++)
	if(lines[i].is_shown())
	  {
	    if(lines[i].is_separate_axis())
	      {
		strcpy(axistitles[k+numxaxis],lines[i].get_orig_y_axis_title());
		axisstatus[k+numxaxis]=lines[i].get_orig_y_axis_scaling();
		lines[i].set_y_axis(axis+k+numxaxis);
		k++;
	      }
	    else
	      {
		bool first=True;
		for(j=0;j<i && first;j++) // axis already in use?
		  if(lines[i].get_orig_y_axis()==lines[j].get_orig_y_axis() && 
		     !lines[j].is_separate_axis() && lines[j].is_shown())
		    {
		      lines[i].set_y_axis(lines[j].get_y_axis());
		      first=False;
		    }
		if(first)
		  {
		    strcpy(axistitles[k+numxaxis],lines[i].get_orig_y_axis_title());
		    axisstatus[k+numxaxis]=lines[i].get_orig_y_axis_scaling();
		    lines[i].set_y_axis(axis+k+numxaxis);
		    k++;
		  }
	      }
	  }
      
      makeaxis(numaxis_new, axistitles, axisstatus,True,True);
      /* if(axis[0].get_axis_type()!=TIME_X_AXIS)
	axis[0].set_start_end(xstart1,xend1);
       else
      axis[0].set_start_end(xstart2,xend2); */
      for(i=0;i<numlines;i++)
	if(lines[i].is_shown())
	  lines[i].get_y_axis()->add_start_end(lines[i].get_y0(), lines[i].get_y1());
      /*
      expose();
      makeaxis(numaxis_new, axistitles, logstatus, True);
      for(i=0;i<numlines;i++)
	lines[i].get_y_axis()->add_start_end(lines[i].get_y0(),lines[i].get_y1());
      */
      for(i=0;i<numaxis_new;i++)
	axis[i].nicen();
      

      delete [] axisstatus;
      doubledelete(axistitles,numaxis_new);
    }
  do_update=True;
  plotchanged=True;

  expose();
}

// Called when the user hits the left mouse button.
// Zoom in on clicked region.
void plot_module::DoButton1(int x, int y)
{
  int i;
  
  // find standard coordinates;
  double xx,yy;
  general_value buffer;

  buffer=axis[0].update_coordinates(x,y);
  xx=buffer.value;
  buffer=axis[numxaxis].update_coordinates(x,y);
  yy=buffer.value;

  if(!left_mouse_click(xx,yy))
    return;

  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  if(!within(x, y, plot_x0, plot_y0, plot_x1, plot_y1))
    return;
     
  for(i=0;i<numxaxis;i++)
    axis[i].zoom_point(x, 1.5);
  for(i=numxaxis;i<num_axis;i++)
    axis[i].update_old_values();

  plotchanged=True;
  expose();
}

// Called when the user clicks inside the plot.
// Should return 1 if the usual zooming is to be done and 0 if not.
int plot_module::left_mouse_click(double /* x */, double /* y */)
{
  return 1;
}

// Called when the user clicks inside the plot.
// Should return 1 if the usual zooming is to be done and 0 if not.
int plot_module::right_mouse_click(double /* x */, double /* y */)
{
  return 1;
}

void plot_module::extra_file_menu_pushed(int /* index */)
{
  // NOP
}

void plot_module::extra_send_menu_pushed(int /* index */)
{
  // NOP
}

// Called when the middle button is pushed. 
// Go to old plotting parameters.   
void plot_module::DoButton2(int /* x */, int /* y */)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  for(int i=0;i<num_axis;i++)
    axis[i].get_old();

  plotchanged=True;
  expose();
}


// Called when the use hits the right hand button. 
// Shows the plotting position.
void plot_module::DoButton3(int x, int y)
{
  if(!created)
    return;

  if(!within(x, y, plot_x0, plot_y0, plot_x1, plot_y1))
    return;

  if(is_radial)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Beklager", (char *) "Sorry"),
		WHAT((char *) "Henting av koordinater fra muslokasjon ikke "
		     "tilgjengelig for polarplott!", 
		     (char *) "Fetching corrdinates from mouse location "
		     "in polar plot not available!"));
      return;
    }

  double xx,yy;
  general_value buffer;

  buffer=axis[0].update_coordinates(x,y);
  xx=buffer.value;
  buffer=axis[numxaxis].update_coordinates(x,y);
  yy=buffer.value;

  if(!right_mouse_click(xx,yy))
    return;

  for(int i=0;i<num_axis;i++)
    {
      buffer=axis[i].update_coordinates(x,y);
      if(i==0)
	xx=buffer.value;
      if(i==1)
	yy=buffer.value;
    }
  if(func)
    {
      double z=func(xx,yy);
      coordz.labelString("z=%f", z);
    }

  coordsh.Map();
}



void plot_module::Boxed(int x1, int y1, int x2, int y2)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  if(x1<plot_x0)
    x1=plot_x0;
  if(x2<plot_x0)
    x2=plot_x0;
  if(x1>plot_x1)
    x1=plot_x1;
  if(x2>plot_x1)
    x2=plot_x1;
  if(y1>plot_y0)
    y1=plot_y0;
  if(y2>plot_y0)
    y2=plot_y0;
  if(y1<plot_y1)
    y1=plot_y1;
  if(y2<plot_y1)
    y2=plot_y1;
  
  if(x1==x2)
    {
      err.build(sh, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Null bredde p� boksen!", 
		     (char *) "The box has no width!"));
      return;
    }

  if(y1==y2)
    {
      err.build(sh, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Null h�yde p� boksen!",
		     (char *) "The box has no height!"));
      return;
    }

  int i;

  for(i=0;i<numxaxis;i++)
    axis[i].zoom_startend(x1, x2);

  for(i=numxaxis;i<num_axis;i++)
    axis[i].zoom_startend(y2, y1);
  
  plotchanged=True;
  expose();
}



void plot_module::DoUp(void)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  int i;

  for(i=0;i<numxaxis;i++)
    axis[i].zoom_point((plot_x0+plot_x1)/2, 3.0/2.0);
  
  for(i=numxaxis;i<num_axis;i++)
    axis[i].update_old_values();

  plotchanged=True;
  expose();
}



void plot_module::DoDown(void)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  int i;

  for(i=0;i<numxaxis;i++)
    axis[i].zoom_point((plot_x0+plot_x1)/2, 2.0/3.0);
  
  for(i=numxaxis;i<num_axis;i++)
    axis[i].update_old_values();

  plotchanged=True;
  expose();
}



void plot_module::DoLeft(void)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  int i;

  for(i=0;i<numxaxis;i++)
    axis[i].translate(0.5);

  for(i=numxaxis;i<num_axis;i++)
    axis[i].update_old_values();

  plotchanged=True;
  expose();
}


void plot_module::DoRight(void)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  int i;

  for(i=0;i<numxaxis;i++)
    axis[i].translate(-0.5);

  for(i=numxaxis;i<num_axis;i++)
    axis[i].update_old_values();

  plotchanged=True;
  expose();
}

void plot_module::DoHome(void)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;

  for(int i=0;i<num_axis;i++)
    axis[i].home();
  plotchanged=True;
  expose();
}

void plot_module::DoPageUp(void)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;
  
  //printf("Page up!\n");
  for(int i=0;i<num_axis;i++)
    axis[i].get_old();
  
  plotchanged=True;
  expose();
}

void plot_module::DoPageDown(void)
{
  if(!created || plot_type==PLOT_IN_WIDGET_NOZOOMING || is_radial)
    return;
  
  printf("Page down!\n");
  for(int i=0;i<num_axis;i++)
    axis[i].get_new();
  
  plotchanged=True;
  expose();
}


// contructor
plot_module::plot_module()
{
  doinit();
  plot_type=PLOT_IN_SEPARATE_WINDOW;
  gridon=big=False;
  func=NULL;
  postscript_picture=False;
  drawrect=True;
  drawinternalrect=False;
  showyear=True;

  axis=NULL;
  titlesize=xaxissize=yaxissize=linesize=PLOT_FONT_UNKNOWN;

  do_update=False;

  xaxis_logit_probit_possible=xaxis_logit_probit_percent=
    yaxis_logit_probit_possible=yaxis_logit_probit_percent=false;

  DateTime now;
  char *ptr, buffer[100];
  
  now.now();
  ptr=now.syCh(2);
  sprintf(buffer, "%s%02d%04d%ld", ptr, now.getSecond(),
#ifndef NVE
	  (int) getpid(), random());
#else
	  (int) (hydraenvir::system::get_pid()), random());
#endif // NVE
  delete [] ptr;
  sprintf(postscript_filename, "/tmp/plotmodule%s.ps", buffer);
  //do_invert_black_and_white();

  for(int i=0;i<20;i++)
    {
      init_min[i]=(int) MISSING_VALUE;
      init_max[i]=(int) MISSING_VALUE;
    }

  created=False;

  radial_len=double(MISSING_VALUE);
  radial_min = (long int) MISSING_VALUE;
  radial_year = (long int) MISSING_VALUE;
  is_radial=False;
  english_month_built=false;
  show_close_button=true;
}

// destructor
plot_module::~plot_module()
{
  Cleanup();
}

void plot_module::Cleanup(void)
{
  char cmd[10000];
  
  sprintf(cmd, "rm -f %s", postscript_filename);
  int scode=system(cmd);
  if(scode!=0)
    printf("Error: Command \"%s\" failed, error code %d!\n", 
	   cmd, scode);
  
  if(axis)
    delete [] axis;
  if(lines)
    delete [] lines;
  
  if(emailwin)
    delete emailwin;
  
  doinit();
}

// options set before plotting;
void plot_module::set_grid(bool gridstatus)
{
  gridon=gridstatus;
}

void plot_module::set_check_equal_value_when_plotting_bars(bool 
							   check_equal_bars)
{
  checkequalbars=check_equal_bars;
}

void plot_module::set_outer_rectangle(bool draw_rectangle)
{
  drawrect=draw_rectangle;
}

void plot_module::set_inner_rectangle(bool draw_rectangle)
{
  drawinternalrect=draw_rectangle;
}

void plot_module::set_title_font_size(PLOT_FONT_SIZE newsize)
{
  titlesize=newsize;
}

void plot_module::set_x_axis_font_size(PLOT_FONT_SIZE newsize)
{
  xaxissize=newsize;
}

void plot_module::set_y_axis_font_size(PLOT_FONT_SIZE newsize)
{
  yaxissize=newsize;
}

void plot_module::set_standard_line_font_size(PLOT_FONT_SIZE newsize)
{
  linesize=newsize;
}

void plot_module::set_update(bool doupdate)
{
  do_update=doupdate;
}

void plot_module::set_vertical_yaxis_titles(bool status)
{
  vertical_yaxis_titles=status;
}

bool plot_module::has_vertical_yaxis_titles(void)
{
  return  vertical_yaxis_titles;
}

bool plot_module::use_english_month(void)
{
  if(english_month_built)
    return english_month();
  else
    return true;
}

widget *plot_module::get_coord_row(void)
{
  return &coordv2;
}
  

void plot_module::set_big(void)
{
  big=True;
}

bool plot_module::is_big(void)
{
  return big;
}

void plot_module::set_radial(double circle_length, 
			     bool start_yaxis_at_zero,
			     PLOT_RADIAL_TYPE plotting_position,
			     bool do_counterclockwise)
{
  if(circle_length==MISSING_VALUE)
    is_radial=False;
  else
    is_radial=True;

  radial_len=circle_length;

  if(is_radial)
    startyaxisatzero=start_yaxis_at_zero;

  if(int(plotting_position)<int(PLOT_RADIAL_START_RIGHTWARDS) ||
     int(plotting_position)>int(PLOT_RADIAL_START_DOWNWARDS))
    {
      err.build(mainwin::toplevel, WHAT((char *) "Programffeil", 
					(char *) "Program error"),
		WHAT((char *) "Ukjent plotte-positsjon i setting "
		     "av polarplott", 
		     (char *) "Unknown plotting position in the setting "
		     "of polar plot"));
      is_radial=False;
      return;
    }

  radialtype=plotting_position;
  counterclockwise=do_counterclockwise;
}

void plot_module::set_radial(long int minutes, long int years, 
			     bool start_yaxis_at_zero,
			     PLOT_RADIAL_TYPE plotting_position,
			     bool do_counterclockwise)
{
  if(minutes==MISSING_VALUE && years==MISSING_VALUE)
    is_radial=False;
  else
    is_radial=True;

  if(minutes==MISSING_VALUE)
    radial_min=0;
  else
    radial_min=minutes;

  if(years==MISSING_VALUE)
    radial_year=0;
  else
    radial_year=years;

  if(is_radial)
    startyaxisatzero=start_yaxis_at_zero;
  
  if(int(plotting_position)<int(PLOT_RADIAL_START_RIGHTWARDS) ||
     int(plotting_position)>int(PLOT_RADIAL_START_DOWNWARDS))
    {
      err.build(mainwin::toplevel, WHAT((char *) "Programffeil", 
					(char *) "Program error"),
		WHAT((char *) "Ukjent plotte-positsjon i setting "
		     "av polarplott", 
		     (char *) "Unknown plotting position in the setting "
		     "of polar plot"));
      is_radial=False;
      return;
    }

  radialtype=plotting_position;
  counterclockwise=do_counterclockwise;
}

void plot_module::set_xaxis_logit_probit_possibility(bool possibility, 
						     bool is_percent)
{
  xaxis_logit_probit_possible=possibility;
  xaxis_logit_probit_percent=is_percent;
}
  
void plot_module::set_yaxis_logit_probit_possibility(bool possibility, 
						     bool is_percent)
{
  yaxis_logit_probit_possible=possibility;
  yaxis_logit_probit_percent=is_percent;
}

double plot_module::get_xaxis_data_min(void)
{
  double min=MISSING_VALUE;
  if(!lines)
    return MISSING_VALUE;
  for(int i=0;i<numlines;i++)
    {
      double line_min=lines[i].get_arg_min();
      if(line_min!=MISSING_VALUE && (min==MISSING_VALUE || line_min<min))
	min=line_min;
    }
  return min;
}

double plot_module::get_xaxis_data_max(void)
{
  double max=MISSING_VALUE;
  if(!lines)
    return MISSING_VALUE;
  for(int i=0;i<numlines;i++)
    {
      double line_max=lines[i].get_arg_max();
      if(line_max!=MISSING_VALUE && (max==MISSING_VALUE || line_max>max))
	max=line_max;
    }
  return max;
}

double plot_module::get_yaxis_data_min(void)
{
  double min=MISSING_VALUE;
  if(!lines)
    return MISSING_VALUE;
  for(int i=0;i<numlines;i++)
    {
      double line_min=lines[i].get_value_min();
      if(line_min!=MISSING_VALUE && (min==MISSING_VALUE || line_min<min))
	min=line_min;
    }
  return min;
}

double plot_module::get_yaxis_data_max(void)
{
  double max=MISSING_VALUE;
  if(!lines)
    return MISSING_VALUE;
  for(int i=0;i<numlines;i++)
    {
      double line_max=lines[i].get_value_max();
      if(line_max!=MISSING_VALUE && (max==MISSING_VALUE || line_max>max))
	max=line_max;
    }
  return max;
}



void plot_module::set_show_year(bool show_year)
{
  showyear=show_year;
}

void plot_module::set_min(double new_min, int axis_index)
{
  if(axis_index<0 || axis_index>=20)
    {
      err.build(mainwin::toplevel, 
		(char *) (WHAT("Program-feil", "Program Error")),
		(char *) (WHAT("Indeks utenfor rekkevidde!", 
			      "Index out of range")));
      return;
    }

  init_min[axis_index]=int(new_min);
}

void plot_module::set_max(double new_max, int axis_index)
{
  if(axis_index<0 || axis_index>=20)
    {
      err.build(mainwin::toplevel, 
       (char *) (WHAT("Program-feil", "Program Error")),
       (char *) (WHAT("Indeks utenfor rekkevidde!", 
       "Index out of range")));
      return;
    }

  init_max[axis_index]=int(new_max);
}

// Creates the plotting window, storing all neccessary info;
// Parameters: arg - arguments of the different plots
//             val - values of the different plots
//             length - length of each plot (number of elements)
//             axis_ - should tell which y-axis each plot belongs to (1,2,3...)
//             linetitles - title of each plot
//             numseries - number of plots
//             axistitles - title of each axis (x-axis is axis number 0)
//             numaxis_ - number of axis ( including the x-axis)
//             title_ - title of the plot
void plot_module::Create(double **arg, double **val, int *length, int *yaxis, 
			 char const* const* linetitles, int numseries, 
			 char const* const* axistitles, 
			 int numaxis_, const char *title_,
			 PLOTLINE_TYPE *plottype, int *xaxis, 
			 PLOTLINE_STYLE *style, char const* const* colorname,
			 int *width, AXIS_SCALING *axis_scaling,
			 char const* const* extra_window_menu_options, 
			 int num_extra_window_menu_options,
			 char const* const* extra_send_menu_options, 
			 int num_extra_send_menu_options,
			 bool nicen_start_end)
{
  plot_mode=PLOT_GRAPH;
  
  register int i;
  PLOTLINE_STYLE style_choices[]={PLOTLINE_SOLID, PLOTLINE_DOTS, 
				  PLOTLINE_LARGE_DASH, 
				  PLOTLINE_DASH_DOT, PLOTLINE_SLDASH, 
				  PLOTLINE_DASH_DOT_DOT,
				  PLOTLINE_SMALL_DASH, PLOTLINE_HUGE_DASH, 
				  PLOTLINE_DASH_DASH_DOT};
  
  char *color[]={"#000000",  "#d80000", "#00c100", "#0000ff", 
		 "#d800e0", "#00e0e0", "#777700", "#aa4400"};
  timeserie=False;
  english_month_built=false;
  num_axis=orig_num_axis=numaxis_;
  numlines = numseries;
  startmake(title_,extra_window_menu_options, 
	    num_extra_window_menu_options,
	    extra_send_menu_options, 
	    num_extra_send_menu_options);

  if(is_radial)
    {
      if(numaxis_==2)
	num_axis=5;
      else if(numaxis_==3)
	num_axis=9;
      else if(numaxis_==4)
	num_axis=7;
      else if(numaxis_==5)
	num_axis=9;
    }

  
  if(xaxis && is_radial)
    {
      err.build(mainwin::toplevel, (char *) (WHAT("Program-feil", 
						  "Program Error")),
		(char *) (WHAT("Kan ikke ha multiple x-akser i polarplott!",
			       "Cannot process multiple x-axis in a "
			       "polar plot")));
      plot_ended();
      return;
    }

  // make the axis;
  axis=new plot_axis[num_axis+numseries];


  if(!xaxis) // single x-axis
    {
      if(!is_radial)
	{
	  // make the x-axis:
	  axis[0].Create(axistitles[0], plot_x0, plot_y0, plot_x1, plot_y0, 
			 NORMAL_X_AXIS, PLOT_FONT_SMALL, this, 
			 axis_scaling ? axis_scaling[0] : AXIS_LINEAR);
	  axis[0].start_adding();
	}
      else
	{
	  // make the x-axis:
	  axis[0].Create(axistitles[0], plot_centerx, plot_centery, 
			 plot_x1, plot_centery, 
			 NORMAL_X_AXIS, PLOT_FONT_SMALL, this);
	  axis[0].set_start_end(0.0, radial_len);
	}
      numxaxis=1;
    }
  else // multiple x-axis
    {
      int *usedxaxis=new int[num_axis], *usedyaxis=new int[num_axis];
      // used for tracking how many times an axis is used as x-axis and y-axis

      int lowestyindex=num_axis, highestxindex=0;
  
      // initialize the tracking arrays
      for(i=0; i<num_axis; i++)
	{
	  usedxaxis[i]=0;
	  usedyaxis[i]=0;
	}

      // examine the axis-choice of each graph
      for(i=0; i<numlines; i++)
	{
	  // check if the axis indexes are legal;

	  if(yaxis[i]<0)
	    {
	      err.build(mainwin::toplevel, WHAT((char *) "PROGRAM-FEIL", 
						(char *) "PROGRAM ERROR"),
			WHAT((char *) "Negativt y-akse indeks",
			     (char *) "Negative y-axis index"));
	      plot_ended();
	      return;
	    }
	  
	  if(yaxis[i]>=num_axis)
	    {
	      err.build(mainwin::toplevel, WHAT((char *) "PROGRAM-FEIL", 
						(char *) "PROGRAM ERROR"),
			WHAT((char *) "Y-akse indeks for h�y",
			     (char *) "Y-axis index too high"));
	      plot_ended();
	      return;
	    }
	  
	  if(xaxis[i]<0)
	    {
	      err.build(mainwin::toplevel, WHAT((char *) "PROGRAM-FEIL", 
						(char *) "PROGRAM ERROR"),
			WHAT((char *) "Negativt x-akse indeks",
			     (char *) "Negative x-axis index"));
	      plot_ended();
	      return;
	    }
	  
	  if(xaxis[i]>=num_axis)
	    {
	      err.build(mainwin::toplevel, WHAT((char *) "PROGRAM-FEIL", 
						(char *) "PROGRAM ERROR"),
			WHAT((char *) "X-akse indeks for h�y",
			     (char *) "X-axis index too high"));
	      plot_ended();
	      return;
	    }


	  // update the lowest y-index and the highest x-index found
	  if(xaxis[i]>highestxindex)
	    highestxindex=xaxis[i];

	  if(yaxis[i]<lowestyindex)
	    lowestyindex=yaxis[i];

	  // update the number of graphs that uses the graphs
	  // x- and y-axis;
	  usedxaxis[xaxis[i]]++;
	  usedyaxis[yaxis[i]]++;
	}

      // check if there's overlap between used x-axis and used y-axis
      if(highestxindex >= lowestyindex)
	{
	  err.build(mainwin::toplevel, (char *) (WHAT("PROGRAM-FEIL", 
						      "PROGRAM ERROR")),
		    WHAT((char *) "H�yeste x-akse indeks er st�rre eller "
			 "lik lavest y-akse indeks!",
			 (char *) "Highest x-axis index is greater than or "
			 "equal the lowest y-axis index!"));
	  plot_ended();
	  return;
	}

      // check if some axis aren't used;
      for(i=0; i<num_axis;i++)
	if(usedxaxis[i]==0 && usedyaxis[i]==0)
	  {
	    err.build(mainwin::toplevel, WHAT((char *) "PROGRAM-FEIL", 
					      (char *) "PROGRAM ERROR"),
		      WHAT((char *) "En av aksene ble ikke brukt!",
			   (char *) "One of the axis was not used!"));
	    plot_ended();
	    return;
	  }

      // set the number of x-axis
      numxaxis=highestxindex+1;

      // make each x-axis:
      for(i=0; i<numxaxis;i++)
	{
	  if(i>0)
	    plot_y0 -= 50;
	  axis[i].Create(axistitles[i], plot_x0, plot_y0, plot_x1, plot_y0, 
			 NORMAL_X_AXIS, PLOT_FONT_LARGE, this, 
			 axis_scaling ? axis_scaling[0] : AXIS_LINEAR,
			 nicen_start_end);
	  axis[i].start_adding();
	}

      delete [] usedxaxis;
      delete [] usedyaxis;
    }

  makeaxis(numaxis_, axistitles, axis_scaling);
  

  // make the plotting lines;
  numlines = numseries;
  lines = new plot_line[numlines];
  for(i=0;i<numlines;i++)
    {
      plot_axis *currentx = (xaxis==NULL) ? axis : axis+xaxis[i];
      plot_axis *currenty = axis+yaxis[i];
      
      PLOTLINE_TYPE curr_type = plottype ? plottype[i] : PLOTLINE_LINE;
      if(curr_type==PLOTLINE_TYPE_UNKNOWN)
	curr_type=PLOTLINE_LINE;
      int curr_width=width ? width[i] : 
	(curr_type!=PLOTLINE_BACKGROUND ? 
	 2 + (curr_type == PLOTLINE_DOT) : 100);
      if(curr_width==(int)MISSING_VALUE || curr_width<0)
	curr_width=(curr_type!=PLOTLINE_BACKGROUND ? 
		    2 + (curr_type == PLOTLINE_DOT) : 100);
      PLOT_FONT_SIZE curr_size = linesize==PLOT_FONT_UNKNOWN ?
	(is_big() ? PLOT_FONT_LARGE : PLOT_FONT_MEDIUM) : linesize;
      PLOTLINE_STYLE curr_style=style ? style[i] : style_choices[i%9];
      if(curr_style==PLOTLINE_STYLE_UNKNOWN)
	curr_style=style_choices[i%9];
      const char *curr_color=(colorname && colorname[i]) ? colorname[i] : color[i%8];
      if(curr_color==NULL || *curr_color=='\0')
	curr_color=color[i%8];
      
      lines[i].Create(linetitles[i], arg[i], val[i], length[i],
		      currentx, currenty,
		      plot_x0+10, y11+lineheight*i,
		      curr_style, curr_color,
		      curr_width, curr_size, curr_type,
		      this);
      
      if(!is_radial)
	{
	  if(!xaxis)
	    axis[0].add_start_end(lines[i].get_x0(), lines[i].get_x1());
	  else
	    axis[xaxis[i]].add_start_end(lines[i].get_x0(), lines[i].get_x1());
	}

      if(curr_type!=PLOTLINE_BACKGROUND)
	axis[yaxis[i]].add_start_end(lines[i].get_y0(), lines[i].get_y1());
    }

  if(!is_radial)
    {
      if(!axis[0].end_adding())
	{
	  plot_ended();
	  return;
	}
    }
  for(i=1;i<num_axis;i++)
    {
      if(!axis[i].end_adding())
	{
	  plot_ended();
	  return;
	}
    }
  
  for(i=0;i<num_axis;i++)
    {
      if(init_min[i]!=MISSING_VALUE)
	axis[i].set_min(init_min[i]);
      if(init_max[i]!=MISSING_VALUE)
	axis[i].set_max(init_max[i]);
    }

  for(i=0;i<num_axis;i++)
    {
      if(xaxissize!=PLOT_FONT_UNKNOWN &&
	 (axis[i].get_axis_type()==NORMAL_X_AXIS ||
	  axis[i].get_axis_type()==TIME_X_AXIS))
	axis[i].set_font_size(xaxissize);
      else if(yaxissize!=PLOT_FONT_UNKNOWN &&
	      axis[i].get_axis_type()!=NORMAL_X_AXIS &&
	      axis[i].get_axis_type()!=TIME_X_AXIS)
	axis[i].set_font_size(yaxissize);
    }

  domake();
}
// Plot with categorical x-values
// Parameters: arg - integer arguments of the different plots going form 1
//                   to number of distinct categories
//             numarg - number of distinct categories
//             argstr - string description of each category
//             val - values of the different plots
//             length - length of each plot (number of elements)
//             yaxis_ - should tell which y-axis 
//               each plot belongs to (#xaxis-1, #xaxis, ...)
//             linetitles - title of each plot
//             numseries - number of plots
//             axistitles - title of each axis (x-axis is axis number 0
//               (or in general 0-number of x-axis, if more than one is
//               spcified in the yaxis argument).
//             numaxis_ - number of axis ( including the x-axis)
//             title_ - title of the plot
//             plottype - plotting type for each graph (line,dots,
//                     line+dots, bars, filled bars or background)
//             xaxis - should tell which x-axis each plot belongs to 
//             style - line style (solid, dashed, dotted etc.)
//             colorname - a recognizable color name or a hex code
//             width - plot line width or bacground y percentage if
//                     a background is used
void plot_module::Create(int **arg, int numarg, char const* const* argstr,
			 double **val, int *length, int *yaxis, 
			 char const* const* linetitles, int numseries, 
			 char const* const* axistitles, int numaxis_, const char *title_,
			 PLOTLINE_TYPE *plottype, 
			 PLOTLINE_STYLE *style, char const* const* colorname,
			 int *width, AXIS_SCALING *axis_scaling,
			 char const* const* extra_window_menu_options, 
			 int num_extra_window_menu_options,
			 char const* const* extra_send_menu_options, 
			 int num_extra_send_menu_options)
{
  plot_mode=PLOT_GRAPH;
  
  register int i;
  PLOTLINE_STYLE style_choices[]={PLOTLINE_SOLID, PLOTLINE_DOTS, 
				  PLOTLINE_LARGE_DASH, 
				  PLOTLINE_DASH_DOT, PLOTLINE_SLDASH, 
				  PLOTLINE_DASH_DOT_DOT,
				  PLOTLINE_SMALL_DASH, PLOTLINE_HUGE_DASH, 
				  PLOTLINE_DASH_DASH_DOT};

  // Check consistency:
  int catmin=(int)MISSING_VALUE, catmax=(int)MISSING_VALUE;
  english_month_built=false;
  for(i=0;i<numseries;i++)
    {
      for(int j=0;j<length[i];j++)
	if(val[i][j]!=MISSING_VALUE)
	  {
	    if(catmin==(int)MISSING_VALUE || catmin>arg[i][j])
	      catmin=arg[i][j];
	    if(catmax==(int)MISSING_VALUE || catmax<arg[i][j])
	      catmax=arg[i][j];
	  }
    }
  if(catmin!=1)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Programfeil", (char *) "Program error"),
		WHAT((char *) "Minste kateogri!=1!", 
		     (char *) "Minimal category!=1!"));
      return;
    }
  if(catmax!=numarg)
    {
      err.build(mainwin::toplevel, 
		WHAT((char *) "Programfeil", (char *) "Program error"),
		WHAT((char *) "St�rste kateogri!=antall kateogrier!", 
		     (char *) "Maximal category!=number of cate3gories!"));
      return;
    }
  
      

  char *color[]={"#000000",  "#d80000", "#00c100", "#0000ff", 
		 "#d800e0", "#00e0e0", "#777700", "#aa4400"};
  timeserie=False;
  num_axis=orig_num_axis=numaxis_;
  numlines = numseries;
  startmake(title_,extra_window_menu_options, 
	    num_extra_window_menu_options,
	    extra_send_menu_options, 
	    num_extra_send_menu_options);
  
  if(is_radial)
    {
      if(numaxis_==2)
	num_axis=5;
      else if(numaxis_==3)
	num_axis=9;
      else if(numaxis_==4)
	num_axis=7;
      else if(numaxis_==5)
	num_axis=9;
    }
  
  // make the axis list;
  axis=new plot_axis[num_axis+numseries];

  if(!is_radial)
    {
      // make the x-axis:
      axis[0].Create(axistitles[0], plot_x0, plot_y0, plot_x1, plot_y0, 
		     CATEGORICAL_X_AXIS, PLOT_FONT_SMALL, this);
    }
  else
    {
      // make the x-axis:
      axis[0].Create(axistitles[0], plot_centerx, plot_centery, 
		     plot_x1, plot_centery, 
		     CATEGORICAL_X_AXIS, PLOT_FONT_SMALL, this);
    }
  axis[0].set_categorical(numarg, argstr);
  numxaxis=1;
  
  makeaxis(numaxis_, axistitles, axis_scaling,False,True);
  
  
  // make the plotting lines;
  numlines = numseries;
  lines = new plot_line[numlines];
  for(i=0;i<numlines;i++)
    {
      plot_axis *currentx = axis;
      plot_axis *currenty = axis+yaxis[i];
      
      PLOTLINE_TYPE curr_type = plottype ? plottype[i] : PLOTLINE_LINE;
      if(curr_type==PLOTLINE_TYPE_UNKNOWN)
	curr_type=PLOTLINE_LINE;
      int curr_width=width ? width[i] : 
	(curr_type!=PLOTLINE_BACKGROUND ? 
	 2 + (curr_type == PLOTLINE_DOT) : 100);
      if(curr_width==(int)MISSING_VALUE || curr_width<0)
	curr_width=(curr_type!=PLOTLINE_BACKGROUND ? 
		    2 + (curr_type == PLOTLINE_DOT) : 100);
      PLOT_FONT_SIZE curr_size = linesize==PLOT_FONT_UNKNOWN ?
	(is_big() ? PLOT_FONT_LARGE : PLOT_FONT_MEDIUM) : linesize;
      PLOTLINE_STYLE curr_style=style ? style[i] : style_choices[i%9];
      if(curr_style==PLOTLINE_STYLE_UNKNOWN)
	curr_style=style_choices[i%9];
      const char *curr_color=(colorname && colorname[i]) ? colorname[i] : color[i%8];
      if(curr_color==NULL || *curr_color=='\0')
	curr_color=color[i%8];
      
      double *argbuffer=new double[length[i]];
      for(int j=0;j<length[i];j++)
	argbuffer[j]=double(arg[i][j]);

      lines[i].Create(linetitles[i], argbuffer, val[i], length[i],
		      currentx, currenty,
		      plot_x0+10, y11+lineheight*i,
		      curr_style, curr_color,
		      curr_width, curr_size, curr_type,
		      this);
      delete [] argbuffer;
      
      if(!is_radial)
	axis[0].add_start_end(lines[i].get_x0(), lines[i].get_x1());

      if(curr_type!=PLOTLINE_BACKGROUND)
	axis[yaxis[i]].add_start_end(lines[i].get_y0(), lines[i].get_y1());
    }

  if(!is_radial)
    {
      if(!axis[0].end_adding())
	{
	  plot_ended();
	  return;
	}
    }
  for(i=1;i<num_axis;i++)
    {
      if(!axis[i].end_adding())
	{
	  plot_ended();
	  return;
	}
    }
  
  for(i=0;i<num_axis;i++)
    {
      if(init_min[i]!=MISSING_VALUE)
	axis[i].set_min(init_min[i]);
      if(init_max[i]!=MISSING_VALUE)
	axis[i].set_max(init_max[i]);
    }

  for(i=0;i<num_axis;i++)
    {
      if(xaxissize!=PLOT_FONT_UNKNOWN &&
	 (axis[i].get_axis_type()==NORMAL_X_AXIS ||
	  axis[i].get_axis_type()==TIME_X_AXIS))
	axis[i].set_font_size(xaxissize);
      else if(yaxissize!=PLOT_FONT_UNKNOWN &&
	      axis[i].get_axis_type()!=NORMAL_X_AXIS &&
	      axis[i].get_axis_type()!=TIME_X_AXIS)
	axis[i].set_font_size(yaxissize);
    }

  domake();
}

void plot_module::makeaxis(int numaxis_, char const* const* axistitles,
			   AXIS_SCALING *axis_scaling,
			   bool redo_plot_surface,
			   bool dont_redo_xaxis)
{
  int i;
  
  num_axis=numaxis_;
  if(redo_plot_surface)
    {
      if(num_axis<=2)
	{
	  plot_x0=80;
	  plot_x1=sx-80;
	}
      else
	{
	  plot_x0 = 80+80*((num_axis-numxaxis-1)/2);
	  plot_x1 = sx - 100 - 80 * ((num_axis-numxaxis-2)/2);
	}
      
      plot_y1=y11=title.get_height()+25;
      if(is_radial)
	plot_y1+=50;
      
      if(!func)
	{
	  for(i=0;i<numlines;i++)
	    {
	      if(lines[i].get_title_height()>0)
		plot_y1+=lines[i].get_title_height()+1;
	      lines[i].set_title_x(plot_x0+50);
	    }
	}
      
      if(!dont_redo_xaxis)
	{
	  if(!is_radial)
	    {
	      // make the x-axis:
	      axis[0].Create(axistitles[0], plot_x0, plot_y0, plot_x1, plot_y0, 
			     NORMAL_X_AXIS, PLOT_FONT_SMALL, this, 
			     axis[0].get_scaling());
	    }
	  else
	    {
	      // make the x-axis:
	      axis[0].Create(axistitles[0], plot_centerx, plot_centery, 
			     plot_x1, plot_centery, 
			     NORMAL_X_AXIS, PLOT_FONT_SMALL, this);
	    }
	  for(i=0;i<numlines;i++)
	    axis[0].add_start_end(lines[i].get_x0(), lines[i].get_x1());
	} 
      else
	axis[0].set_new_plotting_coordinates(plot_x0, plot_y0, plot_x1, plot_y0);
    }
  
  radius=MINIM(ABSVAL((plot_centerx-plot_x0)), 
	       ABSVAL((plot_centery-plot_y0)));
  max_diff_angle = 0.5 / ((double) radius); 
  
  // initialize the y-axis;
  for(i=numxaxis; i<numaxis_; i++)
    {
      int pos = 80*((numaxis_ - i - numxaxis)/2);
      
      if(!is_radial)
	{
	  if(i%2==1)
	    axis[i].Create(axistitles[i], plot_x0-pos, plot_y0,
                           plot_x0-pos, plot_y1,
			   LEFT_Y_AXIS, PLOT_FONT_LARGE, this,
			   axis_scaling ? axis_scaling[i] : AXIS_LINEAR);
	  else
	    axis[i].Create(axistitles[i], plot_x1+pos, plot_y0,
                           plot_x1+pos, plot_y1,
			   RIGHT_Y_AXIS, PLOT_FONT_LARGE, this,
			   axis_scaling ? axis_scaling[i] : AXIS_LINEAR);	
	}
      else
	{
	  if(numaxis_==2 || numaxis_==3)
	    {
	      if(!(numaxis_==3 && i==2))
		axis[i].Createradial(0, axistitles[i], 
				     LEFT_Y_AXIS, PLOT_FONT_MEDIUM, this,
				     axis_scaling ? axis_scaling[i] : 
				     AXIS_LINEAR);
	      else
		axis[i].Createradial(0, axistitles[i], 
				     RIGHT_Y_AXIS, PLOT_FONT_MEDIUM, this,
				     axis_scaling ? axis_scaling[i] : 
				     AXIS_LINEAR);
	      axis[i+1].Createcopy(1, axis+i);
	      axis[i+2].Createcopy(2, axis+i);
	      axis[i+3].Createcopy(3, axis+i);
	    } 
	  else if(numaxis_==4)
	    {
	      if(i<3)
		axis[i].Createradial(i, axistitles[i], 
				     LEFT_Y_AXIS, PLOT_FONT_MEDIUM, this,
				     axis_scaling ? axis_scaling[i] : 
				     AXIS_LINEAR);
	      else
		axis[i].Createradial(i, axistitles[i], 
				     RIGHT_Y_AXIS, PLOT_FONT_MEDIUM, this,
				     axis_scaling ? axis_scaling[i] : 
				     AXIS_LINEAR);
	      axis[i+2].Createcopy(i+2, axis+i);
	    }
	  else if(numaxis_==5 && i==1)
	    {
	      axis[i].Createradial(i, axistitles[i], 
				   LEFT_Y_AXIS, PLOT_FONT_MEDIUM, this,
				   axis_scaling ? axis_scaling[i] : 
				   AXIS_LINEAR);
	      axis[i+4].Createcopy(i+2, axis+i, RIGHT_Y_AXIS);
	    }
	  else
	    axis[i].Createradial(i, axistitles[i], 
				 LEFT_Y_AXIS, PLOT_FONT_MEDIUM, this,
				 axis_scaling ? axis_scaling[i] : 
				 AXIS_LINEAR);
	}
	
      axis[i].start_adding();
    }
}

// Creates the plotting window, storing all neccessary info;
// Parameters: arg - arguments of the different plots
//             val - values of the different plots
//             length - length of each plot (number of elements)
//             axis_ - should tell which y-axis each plot belongs to (1,2,3...)
//             linetitles - title of each plot
//             numseries - number of plots
//             axistitles - title of each axis (x-axis is axis number 0)
//             numaxis_ - number of axis ( including the x-axis)
//             title_ - title of the plot
void plot_module::Create(DateTime **arg, double **val, 
			 int *length, int *axis_, 
			 char const* const* linetitles, int numseries, 
			 char const* const* axistitles, int numaxis_, const char *title_,
			 PLOTLINE_TYPE *plottype, 
			 PLOTLINE_STYLE *style, char const* const* colorname,
			 int *width, AXIS_SCALING *axis_scaling,
			 char const* const* extra_window_menu_options, 
			 int num_extra_window_menu_options,
			 char const* const* extra_send_menu_options, 
			 int num_extra_send_menu_options)
{
  plot_mode=PLOT_GRAPH;
  
  register int i, j;

  PLOTLINE_STYLE style_choices[]={PLOTLINE_SOLID, PLOTLINE_DOTS, 
				  PLOTLINE_LARGE_DASH, 
				  PLOTLINE_DASH_DOT, PLOTLINE_SLDASH, 
				  PLOTLINE_DASH_DOT_DOT,
				  PLOTLINE_SMALL_DASH, PLOTLINE_HUGE_DASH, 
				  PLOTLINE_DASH_DASH_DOT};
  
  char *color[]={"#000000",  "#d80000", "#00c100", "#0000ff", 
		 "#d800e0", "#00e0e0", "#777700", "#aa4400"};  
  DateTime **argbuffer=new DateTime*[numseries];
  double **valbuffer=new double*[numseries];
  int *lenbuffer=new int[numseries];
  english_month_built=false;

  for(i=0;i<numseries;i++)
    {
      lenbuffer[i]=0;
      for(j=0;j<length[i];j++)
	if(!is_radial || radial_year<=0 || radial_year==MISSING_VALUE ||
	   arg[i][j].getMonth()!=2 || arg[i][j].getDay()!=29)
	  lenbuffer[i]++;

      argbuffer[i]=new DateTime[lenbuffer[i]];
      valbuffer[i]=new double[lenbuffer[i]];

      lenbuffer[i]=0;
      for(j=0;j<length[i];j++)
	if(!is_radial || radial_year<=0 || radial_year==MISSING_VALUE ||
	   arg[i][j].getMonth()!=2 || arg[i][j].getDay()!=29)
	  {
	    argbuffer[i][lenbuffer[i]]=arg[i][j];
	    valbuffer[i][lenbuffer[i]]=val[i][j];

	    lenbuffer[i]++;
	  }
    }

	
  timeserie=True;
  numlines = numseries;
  num_axis=orig_num_axis=numaxis_;
  numxaxis=1;
  startmake(title_,extra_window_menu_options, 
	    num_extra_window_menu_options,
	    extra_send_menu_options, 
	    num_extra_send_menu_options);

  if(is_radial)
    {
      if(numaxis_==2)
	num_axis=5;
      else if(numaxis_==3)
	num_axis=9;
      else if(numaxis_==4)
	num_axis=7;
      else if(numaxis_==5)
	num_axis=9;
    }


  // make the axis;
  axis=new plot_axis[num_axis+numseries];
  // make the x-axis:
  axis[0].Create(axistitles[0], plot_x0, plot_y0, plot_x1, plot_y0, 
		 TIME_X_AXIS, PLOT_FONT_MEDIUM, this,
		 axis_scaling ? axis_scaling[0] : AXIS_LINEAR);
  if(!is_radial)
    axis[0].start_adding_time();

  makeaxis(numaxis_, axistitles, axis_scaling);

  int axisy=is_radial ? y11-20 : y11;
  // make the plotting lines;
  lines = new plot_line[numlines];
  for(i=0;i<numlines;i++)
    {
      PLOTLINE_TYPE curr_type = plottype ? plottype[i] : PLOTLINE_LINE;
      if(curr_type==PLOTLINE_TYPE_UNKNOWN)
	curr_type=PLOTLINE_LINE;
      int curr_width=width ? width[i] : 
	(curr_type!=PLOTLINE_BACKGROUND ? 
	 2 + (curr_type == PLOTLINE_DOT) : 100);
      if(curr_width==(int)MISSING_VALUE || curr_width<0)
	curr_width=(curr_type!=PLOTLINE_BACKGROUND ? 
		    2 + (curr_type == PLOTLINE_DOT) : 100);
      PLOT_FONT_SIZE curr_size = linesize==PLOT_FONT_UNKNOWN ?
	(is_big() ? PLOT_FONT_LARGE : PLOT_FONT_MEDIUM) : linesize;
      PLOTLINE_STYLE curr_style=style ? style[i] : style_choices[i%9];
      if(curr_style==PLOTLINE_STYLE_UNKNOWN)
	curr_style=style_choices[i%9];
      const char *curr_color=(colorname && colorname[i]) ? colorname[i] : color[i%8];
      if(curr_color==NULL || *curr_color=='\0')
	curr_color=color[i%8];
      
      lines[i].Create(linetitles[i], argbuffer[i], valbuffer[i], lenbuffer[i],
		      axis, axis + axis_[i], 
		      plot_x0+10, axisy+lineheight*i,
		      curr_style,curr_color,curr_width,curr_size,curr_type,
		      this);
      
      if(!is_radial)
	axis[0].add_start_end(lines[i].get_start_time(), 
			      lines[i].get_end_time());
      
      if(curr_type!=PLOTLINE_BACKGROUND)
	axis[axis_[i]].add_start_end(lines[i].get_y0(), lines[i].get_y1());
    }
  
  if(!is_radial)
    {
      if(!axis[0].end_adding_time())
	{
	  plot_ended();
	  return;
	}

      axis[0].set_show_year(showyear);
    }
  else
    axis[0].set_radial_start_end(radial_year, radial_min);
    
  for(i=1;i<num_axis;i++)
    {
      if(!axis[i].end_adding())
	{
	  plot_ended();
	  return;
	}
    }
  
  for(i=1;i<num_axis;i++)
    {
      if(init_min[i]!=MISSING_VALUE)
	axis[i].set_min(init_min[i]);
      if(init_max[i]!=MISSING_VALUE)
	axis[i].set_max(init_max[i]);
    }

  for(i=0;i<num_axis;i++)
    {
      if(xaxissize!=PLOT_FONT_UNKNOWN &&
	 (axis[i].get_axis_type()==NORMAL_X_AXIS ||
	  axis[i].get_axis_type()==TIME_X_AXIS))
	axis[i].set_font_size(xaxissize);
      else if(yaxissize!=PLOT_FONT_UNKNOWN &&
	      axis[i].get_axis_type()!=NORMAL_X_AXIS &&
	      axis[i].get_axis_type()!=TIME_X_AXIS)
	axis[i].set_font_size(yaxissize);
    }

  plot_centerx = (plot_x0+plot_x1)/2;
  
  doubledelete(argbuffer, numseries);
  doubledelete(valbuffer,numseries);
  delete [] lenbuffer;
  
  domake();
}

// contour plot
void plot_module::Create(double (*function)(double,double), 
			 double xmin, double ymin, double xmax, double ymax, 
			 const char *xtitle, const char *ytitle,
			 double /* zmin */, double /* zmax */,
			 bool colormap)
{
  plot_mode=PLOT_HEATMAP;
  
  register int i;
  char **axistitles=new char*[2];
  english_month_built=false;

  axistitles[0]=new char[100];
  strcpy(axistitles[0], xtitle);
  axistitles[1]=new char[100];
  strcpy(axistitles[1], ytitle);

  color_map=colormap;
  func=function;	
  timeserie=False;
  numlines = 1;
  num_axis=orig_num_axis=2;
  numxaxis=1;
  startmake(NULL);

  // make the axis;
  axis=new plot_axis[num_axis];
  // make the x-axis:
  axis[0].Create(xtitle, plot_x0, plot_y0, plot_x1, plot_y0, 
		 NORMAL_X_AXIS, PLOT_FONT_MEDIUM, this);

  makeaxis(num_axis, axistitles, False);
  
  
  axis[0].set_start_end(xmin, xmax);
  axis[1].set_start_end(ymin, ymax);
  
  plot_centerx = (plot_x0+plot_x1)/2;
  
  for(i=0;i<num_axis;i++)
    {
      if(xaxissize!=PLOT_FONT_UNKNOWN &&
	 (axis[i].get_axis_type()==NORMAL_X_AXIS ||
	  axis[i].get_axis_type()==TIME_X_AXIS))
	axis[i].set_font_size(xaxissize);
      else if(yaxissize!=PLOT_FONT_UNKNOWN &&
	      axis[i].get_axis_type()!=NORMAL_X_AXIS &&
	      axis[i].get_axis_type()!=TIME_X_AXIS)
	axis[i].set_font_size(yaxissize);
    }
  
  domake();
  
  delete [] axistitles[0];
  delete [] axistitles[1];
  delete [] axistitles;
}

// These methods should be called before the plot is created, in order
// to set the plotting mode (window, widget with menues, widget
// without menues, static plot and background plot. If these methods
// aren't called, the plot will appear in window mode. 
void plot_module::set_background(const char *filename_without_extensions, 
				 int width, int height,
				 IMAGE_TYPE typ, bool toprinter)
{
  sprintf(outputfile, "%s.%s", filename_without_extensions,
		  image_ext_name[(int) typ]);

  if(!toprinter)
    {
      out_height=height;
      out_width=width;
      outputtype=typ;
      plot_type=PLOT_BACKGROUND;
    }
  else
    {
      outputtype=EPS;
      plot_type=PLOT_PRINTER;
    }
}

void plot_module::put_in_widget(widget parent, int width, int height, 
				PLOT_TYPE plottype,
				bool do_show_close_button)
{
  if(plottype!=PLOT_IN_WIDGET_SHOWMENUES && 
     plottype!=PLOT_IN_WIDGET_SHOWMAINMENU && 
     plottype!=PLOT_IN_WIDGET_NOMENUES &&
     plottype!=PLOT_IN_WIDGET_NOZOOMING)
    {
      std::cerr << (WHAT((char *) "Metoden \"put_in_widget\" ble kallt med en "
	"ulovlig plottetype. ProgrammeringsFeil!",
          (char *) "The method \"put_in_widhet\" was called by an illegal "
		    "plotting type. Programming error!")) << std::endl;
      exit(0);
    }

  show_close_button=do_show_close_button;

  widgetx=width;
  widgety=height;

  parentwidget=parent;
  plot_type=plottype;

  v1.build(parentwidget);
  
  if(plot_type==PLOT_IN_WIDGET_SHOWMENUES)
    {
      h1.build(v1);
      filemenu.create(h1, this, PLOT_MENU_FILE, 
		      xaxis_logit_probit_possible || 
		      yaxis_logit_probit_possible);
      if(!is_radial)
	navigationmenu.create(h1, this, PLOT_MENU_NAVIGATION);
      sendmenu.create(h1, this, PLOT_MENU_SEND);
      char format[100], str[100];
      sprintf(format, "%%%ds",MAXIM(1,int((width-800)/6)));
      //cout << width << std::endl;
      sprintf(str,format," ");
      exitspacing.build(h1,str);
      if(show_close_button)
	exitb.Create(h1,WHAT((char *) "Avslutt X",(char *) "Quit X"),
		     this,PLOT_EXIT_BUTTON);
    }
  else if(plot_type==PLOT_IN_WIDGET_SHOWMAINMENU)
    {
      h1.build(v1);
      menu.Create(h1, this, is_radial,NULL,0,NULL,0,
		  xaxis_logit_probit_possible || yaxis_logit_probit_possible);
      h1.spacing(width-270);
      if(show_close_button)
	exitb.Create(h1,WHAT((char *) "Avslutt X",(char *) "Quit X"),
		     this,PLOT_EXIT_BUTTON);
    }

  build(v1, widgetx, widgety, 
	(plot_type!=PLOT_IN_WIDGET_NOZOOMING && !is_radial) ? True : False, 
	postscript_filename);
  
  if(black_and_white_inverted())
    Background("black");
  else
    Background("white");
}


void plot_module::startmake(const char *title_,
			    char const* const* extra_window_menu_options, 
			    int num_extra_window_menu_options,
			    char const* const* extra_send_menu_options, 
			    int num_extra_send_menu_options)
{
  DateTime now;
  char *ptr, buffer[100];
  
  now.now();
  ptr=now.syCh(2);
  sprintf(buffer, "%s%02d%04d", ptr, now.getSecond(), 
	  (int) (drand48()*10000.0));
  delete [] ptr;

  lineheight = is_big() ? 24 : 15;
  y11=title_ ? lineheight*2+20 : 10+lineheight;

  if(plot_type==PLOT_IN_SEPARATE_WINDOW)
    {
      if(!created)
	{
	  if(title_)
	    sh.build(mainwin::toplevel, title_);
	  else
	    sh.build(mainwin::toplevel, WHAT((char *) "Plotte-modul 1.1", 
					     (char *) "Plotting module 1.1"));
	  
	  v1.build(sh);
	  
	  sx=v1.screenwidth()*9/10;
	  sy=sx*580/820;
	  
	  if(v1.screenheight()*9/10<sy)
	    {
	      sy=v1.screenheight()*9/10;
	      sx=sy*820/580;
	    }

	  if(getenv("MAXPLOT"))
	    {
	      int maxplot=v1.screenwidth();
	      maxplot=MINIM(maxplot, atoi(getenv("MAXPLOT")));
	      
	      int sy2=MINIM(MINIM(maxplot*9/10, 
				  v1.screenwidth()*3/4*9/10), 900);
	      if(sy>sy2)
		{
		  sy=sy2;
		  sx=sy*4/3;
		}
	    }
	  
	  //cout << sx << std::endl;
	  
	  h1.build(v1);
	  menu.Create(h1, this, is_radial,
		      extra_window_menu_options, 
		      num_extra_window_menu_options,
		      extra_send_menu_options, 
		      num_extra_send_menu_options,
		      xaxis_logit_probit_possible || 
		      yaxis_logit_probit_possible);
	  h1.spacing(sx-300);
	  if(show_close_button)
	    exitb.Create(h1,WHAT((char *) "Avslutt X",(char *) "Quit X"),
			 this,PLOT_EXIT_BUTTON);
	  
	}
    }
  else if(plot_type!=PLOT_BACKGROUND && plot_type!=PLOT_PRINTER)
    {
      sx=widgetx;
      sy=widgety;
    }
  else // background
    {
      sx=900;
      sy=900*580/820;
    }

    
  if(plot_type==PLOT_IN_SEPARATE_WINDOW)
    {
      if(!created)
	build(v1, sx, sy, 
	      (plot_type!=PLOT_IN_WIDGET_NOZOOMING && 
	       !is_radial) ? True : False, 
	      postscript_filename);
    }
  else if(plot_type==PLOT_BACKGROUND || plot_type==PLOT_PRINTER)
    do_background(postscript_filename, sx, sy);
  // else it's been previously built in "put_in_widget"

  // build the title;
  title.Create(title_, sx/4, 25, titlesize==PLOT_FONT_UNKNOWN ? 
	       PLOT_FONT_LARGE : titlesize, this); 

  // initialize the plotting coordinates
  if(num_axis<=2)
    {
      plot_x0=80;
      plot_x1=sx-80;
    }
  else
    {
      plot_x0 = 80+80*((num_axis-numxaxis-2)/2);
      plot_x1 = sx - 100 - 80 * ((num_axis-numxaxis-3)/2);
    }
  
  if(!is_radial)
    plot_y0 = sy-80;
  else
    plot_y0 = sy-50;
  plot_y1 = y11;

  plot_y1 += ((numlines-1)*lineheight+10);
  if(is_radial)
    plot_y1+=50;

  plot_centerx = (plot_x0+plot_x1)/2;
  plot_centery = (plot_y0+plot_y1)/2;
}

void plot_module::domake(void)
{
  register int i;

  
  if(plot_type!=PLOT_BACKGROUND && plot_type!=PLOT_PRINTER)
    {
      if(xaxis_logit_probit_possible || yaxis_logit_probit_possible)
	logsh.build(mainwin::toplevel, 
		    WHAT((char *) "Logaritme-opsjoner",
			 (char *) "Logarithmic settings"));
      else
	logsh.build(mainwin::toplevel, 
		    WHAT((char *) "Log/logit/probit-opsjoner",
			 (char *) "Log/logit/probit settings"));
      logv1.build(logsh);
      for(i=0;i<num_axis;i++)
	{
	  bool logit_probit_possible=
	    (axis[i].get_axis_type()==LEFT_Y_AXIS ||
	     axis[i].get_axis_type()==RIGHT_Y_AXIS) ? 
	    yaxis_logit_probit_possible : xaxis_logit_probit_possible;
	  bool logit_probit_percent=
	    (axis[i].get_axis_type()==LEFT_Y_AXIS ||
	     axis[i].get_axis_type()==RIGHT_Y_AXIS) ? 
	    yaxis_logit_probit_percent : xaxis_logit_probit_percent;
	  if(plot_mode!=PLOT_HEATMAP)
	    axis[i].build_logwidget(logv1, logit_probit_possible, 
				    logit_probit_percent);
	}
      
      logsep1.build(logv1);
      logh1.build(logv1);
      logokb.Create(logh1, "OK", this, PLOT_SETLOG);
      logokb.Background("green");
      logokb.Foreground("black");
      logcloseb.build(logh1, &logsh, WHAT((char *) "Avbryt", 
					  (char *) "Abort")); 
      logcloseb.Background("red");
      logcloseb.Foreground("white");
      
      coordsh.build(mainwin::toplevel, WHAT((char *) "Koordinater:", 
					    (char *) "Coordinates:"));
      coordv1.build(coordsh);
      coordv2.build(coordv1);
      for(i=0;i<num_axis;i++)
	axis[i].build_info(coordv2);
      if(func)
	coordz.build(coordv2, "z=???");
      coordsep1.build(coordv1);
      coordclose.build(coordv1, &coordsh, WHAT((char *) "Lukk vindu",
					       (char *) "Close the window"));
      coordclose.Background("red");
      coordclose.Foreground("white");

      if(!func)
	{
	  linechangesh.build(mainwin::toplevel, 
			     WHAT((char *) "Forandring av serie-visning",
				  (char *) "Change the serie presentation"));
	  linechangev1.build(linechangesh);
	  linechangesc.build(linechangev1);
	  linechangesc.Height(600);
	  linechangesc.Width(800);
	  linechangev2.build(linechangesc);
	  for(i=0;i<numlines;i++)
	    lines[i].build_linechange(linechangev2);
	  linechangesep1.build(linechangev1);
	  linechangeh1.build(linechangev1);
	  linechangeok.Create(linechangeh1, "OK", this, PLOT_DOLINECHANGE);
	  linechangeok.Background("green");
	  linechangeok.Foreground("black");
	  linechangeclose.build(linechangeh1, &linechangesh, 
				WHAT((char *) "Avbryt", (char *) "Abort"));
	  linechangeclose.Background("red");
	  linechangeclose.Foreground("white");
	

	  interpolsh.build(mainwin::toplevel, 
			   (char *) (WHAT("Interpolering", "Interpolation")));
	  interpolv1.build(interpolsh);
	  if(timeserie)
	    {
	      interpolfr.build(interpolv1);
	      interpolv2.build(interpolfr);
	      interpollab.build(interpolv2, (char *)
				(WHAT("                                       "
				      "Velg maksimal interpolasjonsgap-lengde;"
				      "                                       ", 
				      "                                       "
				      "     Choose maximal gap length;        "
				      "                                       ")));
	      interpollab.Background("white");
	      interpolyear.build(interpolv2, 
				 (char *) (WHAT("�r:      ", "Years:  ")), 
				 0, 20, 0);
	      interpolday.build(interpolv2, 
				(char *) (WHAT("Dager:   ","Days:   ")), 
				0, 365, 0);
	      interpolminute.build(interpolv2, 
				   (char *) (WHAT("Minutter:","Minutes:")), 
				   0, 1439, 0);
	      interpolsec.build(interpolv2,    
				(char *) (WHAT("Sekunder:","Seconds:")), 
				0, 59, 0);
	    }
	  else
	    {
	      interpolvalue.build(interpolv1, 10, 
				  (char *) (WHAT("Maks. gap-lengde:",
						 "Max. gap length:"))); 
	      interpolvalue.SetDouble(0.0);
	    }
	  for(i=0;i<numlines;i++)
	    lines[i].build_interpolation(interpolv1);
	  interpolsep.build(interpolv1);
	  interpolh1.build(interpolv1);
	  interpolok.Create(interpolh1, "OK", this, PLOT_DOINTERPOLATION);
	  interpolok.Background("green");
	  interpolok.Foreground("black");
	  interpolclose.build(interpolh1, &interpolsh, 
			      WHAT((char *) "Avbryt", (char *) "Abort"));
	  interpolclose.Background("red");
	  interpolclose.Foreground("white");
	}

      scalesh.build(mainwin::toplevel, WHAT((char *) "Skalering:", 
					    (char *) "Scaling:"));
      scalev1.build(scalesh);
      for(i=0;i<num_axis;i++)
	axis[i].build_scale(scalev1);
      scalesep1.build(scalev1);
      scaleh1.build(scalev1);
      scale_ok.Create(scaleh1, "OK", this, PLOT_SETSCALE);
      scale_ok.Background("green");
      scale_ok.Foreground("black");
      scaleclose.build(scaleh1, &scalesh, WHAT((char *) "Avslutt", 
					       (char *) "Abort"));
      scaleclose.Background("red");
      scaleclose.Foreground("white");
      scale_extra_text.
	build(scalev1, 
	      WHAT((char *) "Manuelt spesifiserte ekstra akse(r):",
		   (char *) "Manualle specified extra axis:"));
      scale_extra_text.Unmap();
      
      printsh.build(mainwin::toplevel, WHAT((char *) "Utskrift", 
					    (char *) "Printing window"));
      printv1.build(printsh);
      printh1.build(printv1);
      printlab1.build(printh1, WHAT((char *) "Valgt skriver:   ", 
				    (char *) "Choose printer:  "));
      printlab2.build(printh1, "%s", getenv("PRINTER"));
      printlab2.Background("white");
      printlab2.Foreground("black");
      print_changeprinter.Create(printh1, WHAT((char *) "Forandre skriver", 
					       (char *) " Change printer "),
				 this, PLOT_CHANGEPRINTER);
      printsep1.build(printv1);
      printh2.build(printv1);
      print_ok.Create(printh2, WHAT((char *) "Skriv ut", (char *) "Print"), 
		      this, PLOT_DOPRINT);
      print_ok.Background("green");
      print_ok.Foreground("black");
      printclose.build(printh2, &printsh, WHAT((char *) "Avbryt", 
					       (char *) "Abort"));
      printclose.Background("red");
      printclose.Foreground("white");
      
      emailsh.build(mainwin::toplevel, WHAT((char *) "Valg av "
					    "utsendingsformat",
					    (char *) "Choose picture format"));
      emailv1.build(emailsh);
      emailmenu.create(emailv1, WHAT((char *) "Valg av bilde-type:", 
				     (char *) "Choose picture type:"));
      emailwidth.build(emailv1, 6, WHAT((char *) "Angi plottebildets vidde "
					"(i piksler):",
					(char *) "Width of the picture "
					"(in pixels):"));
      emailwidth.SetDigit(1000);
      emailsep1.build(emailv1);
      emailh1.build(emailv1);
      email_ok.Create(emailh1, "Send", this, PLOT_SENDEMAIL);
      email_ok.Background("green");
      email_ok.Foreground("black");
      emailclose.build(emailh1, &emailsh, WHAT((char *) "Avbryt",
					       (char *) "Abort"));
      emailclose.Background("red");
      emailclose.Foreground("white");
      
      chaxissh.build(mainwin::toplevel, WHAT((char *) "Forandring av "
					     "tittel, og akser",
					     (char *) "Changing axis "
					     "and title"));
      chaxisv1.build(chaxissh);
      title.build_chtitle(chaxisv1);
      chaxissep2.build(chaxisv1);
      for(i=0;i<num_axis;i++)
	axis[i].build_chaxis(chaxisv1);
      
      if(language == Norwegian)
	{
	  english_month.build(chaxisv1, "Engelske m�nedsnavn");
	  english_month_built=true;
	}

      chaxish2.build(chaxisv1);
      bordertoggle.build(chaxish2, WHAT((char *) "Ytre ramme:", 
					(char *) "Outer border:"));
      if(drawrect)
	bordertoggle.ToggleButtonOn();
      else
	bordertoggle.ToggleButtonOff();
      internalbordertoggle.build(chaxish2, WHAT((char *) "Indre ramme:", 
					(char *) "Internal border:"));
      if(drawinternalrect)
	internalbordertoggle.ToggleButtonOn();
      else
	internalbordertoggle.ToggleButtonOff();
      

      chaxissep1.build(chaxisv1);
      chaxish1.build(chaxisv1);
      chaxis_ok.Create(chaxish1, "OK", this, PLOT_DOAXISCHANGE);
      chaxis_ok.Background("green");
      chaxis_ok.Foreground("black");
      chaxisclose.build(chaxish1, &chaxissh, 
			WHAT((char *) "Avbryt", (char *) "Abort"));
      chaxisclose.Background("red");
      chaxisclose.Foreground("white");

      if(vertical_yaxis_titles)
	{
	  if(!load_softfonts(NULL, False))
	    vertical_yaxis_titles=False;
	}
    }
  else // background
    {
      DateTime now; now.now();
      char *ptr=now.syCh(2), psbuffer[1000], cmd[2000], bufferfile[100];;
      
      sprintf(psbuffer, "/tmp/plotbuffer%s.%ld.ps", ptr, random());
      sprintf(bufferfile, "/tmp/plotbuffer2%s.%ld.ps", ptr, random());

      plotchanged=True;
      postscript_picture=True;
      expose();
      endpostscript();

      if(plot_type!=PLOT_PRINTER)
	retouch_postscript(psbuffer, out_width, out_height, True);
      else
	{
	  sprintf(cmd, "cp %s %s", psfile, psbuffer);
	  int scode2=system(cmd);
	  if(scode2!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode2);
	}

      if(outputtype==EPS || plot_type==PLOT_PRINTER)
	{
	  sprintf(cmd, "mv %s %s", psbuffer, outputfile);
	  int scode3=system(cmd);
	  if(scode3!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode3);
	}    
#ifdef PSTOPDF
      else if(outputtype==PDF)
 	{
 	  sprintf(cmd, "ps2pdf %s %s", psbuffer, outputfile);
	  int scode4=system(cmd);
	  if(scode4!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode4);
	  
 	  sprintf(cmd, "rm -f %s %s", psbuffer, bufferfile);
	  int scode5=system(cmd);
	  if(scode5!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode5);
 	}
#endif // PSTOPDF
#ifdef PSTOEDIT
      else if(is_vector_type(outputtype))
 	{  
	  DateTime now; now.now();
	  char *ptr=now.syCh(2), buffer2[1000];
      
	  sprintf(buffer2, "/tmp/plotbuffer%s.%ld.%s", ptr, random(),
		  image_ext_name[(int) outputtype]);
 	  sprintf(cmd, "pstoedit -f %s %s %s", 
 		  image_ext_name[(int) outputtype],
 		  psbuffer, buffer2);
	  int scode6=system(cmd);
	  if(scode6!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode6);
 
	  if(outputtype==SVG)
	    {
	      sprintf(cmd, "sed s/\\&\\#36\\;/e/g %s > %s",
		      buffer2,outputfile);
	      int scode7=system(cmd);
	      if(scode7!=0)
		printf("Command \"%s\" failed, error code %d!\n", 
		       cmd, scode7);
	      hydraenvir::system::unlink(buffer2);
	    }
	  else
	    {
	      sprintf(cmd, "mv %s %s", buffer2, outputfile);
	      int scode8=system(cmd);
	      if(scode8!=0)
		printf("Command \"%s\" failed, error code %d!\n", 
		       cmd, scode8);
	    }

 	  sprintf(cmd, "rm -f %s %s", psbuffer, bufferfile);
	  int scode9=system(cmd);
	  if(scode9!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode9);

	  delete [] ptr;
 	}
#endif // PSTOEDIT
      else
	{
	  char gifbuffer[100];

	  sprintf(gifbuffer, "/tmp/plotoutfile%s.%ld.gif", ptr, random());
	  sprintf(cmd,"echo quit | gs -sDEVICE=ppmraw -q -dNOPAUSE -g%dx%d "
		  "-sOutputFile=- %s | ppmtogif > %s 2> /dev/null",
		  out_width, out_width*sy/sx,
		  psbuffer, gifbuffer);
	  int scode10=system(cmd);
	  if(scode10!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode10);
	  
	  if(outputtype==GIF)
	    {
	      sprintf(cmd, "mv %s %s", gifbuffer, outputfile);
	      int scode11=system(cmd);
	      if(scode11!=0)
		printf("Command \"%s\" failed, error code %d!\n", 
		       cmd, scode11);
	    }
	  else
	    {
	      sprintf(cmd, "convert -background \"#ffffff\" -transparent-color \"#000001\" -transparent \"#000001\" %s %s", gifbuffer, outputfile);
	      int scode12=system(cmd);
	      if(scode12!=0)
		printf("Command \"%s\" failed, error code %d!\n", 
		       cmd, scode12);
	      
	      sprintf(cmd, "rm -f %s", gifbuffer);
	      int scode13=system(cmd);
	      if(scode13!=0)
		printf("Command \"%s\" failed, error code %d!\n", 
		       cmd, scode13);
	    }

	  sprintf(cmd, "rm -f %s %s", psbuffer, bufferfile);
	  int scode14=system(cmd);
	  if(scode14!=0)
	    printf("Command \"%s\" failed, error code %d!\n", 
		   cmd, scode14);
	}

      sprintf(cmd, "rm -f %s", postscript_filename);
      int scode15=system(cmd);
      if(scode15!=0)
	printf("Command \"%s\" failed, error code %d!\n", 
	       cmd, scode15);

      delete [] ptr;
    }
  
  if(plot_type==PLOT_IN_SEPARATE_WINDOW)
    sh.Map();

  created=True;
}

// Called when the drawing area is exposed. Draw the axis and the graphs
void plot_module::expose(void)
{
  int i;
  
  if(!do_update && !plotchanged)
    return;
  
  if(plot_type==PLOT_IN_SEPARATE_WINDOW)
    AddWorkCursor(sh);
  
  Clear("white");
  
  if(big)
    Set_No_Dashes(4);
  else
    Set_No_Dashes(2);
  if(drawrect)
    Rectangle(0,0,sx,sy);

  if(func)
    draw_contour();
  
  plot_y1=y11=title.get_height()+25;
  title.redraw();
  
  if(!func)
    {
      for(i=0;i<numlines;i++)
	if(lines[i].is_shown())
	  {
	    lines[i].set_title_y1(plot_y1);
	    if(lines[i].get_title_height()>0)
	      plot_y1+=lines[i].get_title_height()+1;
	  }
      
      // Plot background colors first:
      for(i=0;i<numlines;i++)
	if(lines[i].is_shown() && lines[i].get_type()==PLOTLINE_BACKGROUND)
	  lines[i].do_plot();
      
      // ...then plot the rest:
      for(i=0;i<numlines;i++)
	if(lines[i].is_shown() && lines[i].get_type()!=PLOTLINE_BACKGROUND)
	  lines[i].do_plot();
    }
  if(is_radial)
    plot_y1+=50;

  if(drawinternalrect)
    {      
      if(big)
	Set_No_Dashes(4);
      else
	Set_No_Dashes(2);
      SetFg("black");

      Rectangle(plot_x0,plot_y1,plot_x1,plot_y0);
    }

  for(i=0;i<num_axis;i++)
    axis[i].do_plot();

  if(plot_type==PLOT_IN_SEPARATE_WINDOW)
    RmWorkCursor(sh);
  
  plotchanged=False;
}

void plot_module::setfont(PLOT_FONT_SIZE newsize)
{
  if(big)
    newsize = (PLOT_FONT_SIZE) (((int) newsize)+1);
  
  if(old_font_size==newsize)
    return;
  
  char newfont[100];
  
  Set_No_Dashes(((int) newsize)+2);
  
  sprintf(newfont, "-*-helvetica-*-r-*-*-%d-*-*-*-*-*-*-*", 
	  find_font_size(newsize));
  SetFont(newfont);
  old_font_size=newsize;
}

int find_font_size(PLOT_FONT_SIZE size)
{
  switch(size)
    {
      /*
    case PLOT_FONT_VERYSMALL:
      return 12;
    case PLOT_FONT_SMALL:
      return 14;
    case PLOT_FONT_MEDIUM:
      return 17;
    case PLOT_FONT_LARGE:
      return 20;
    case PLOT_FONT_VERYLARGE:
      return 24;
    case PLOT_FONT_EXTRALARGE:
      return 25;
    case PLOT_FONT_EXTREMELY_LARGE:
      return 34;
      */
    case PLOT_FONT_VERYSMALL:
      return 10;
    case PLOT_FONT_SMALL:
      return 12;
    case PLOT_FONT_MEDIUM:
      return 14;
    case PLOT_FONT_LARGE:
      return 18;
    case PLOT_FONT_VERYLARGE:
      return 24;
    case PLOT_FONT_EXTRALARGE:
      return 24;
    case PLOT_FONT_EXTREMELY_LARGE:
      return 24;
    default:
      return 0;
    }
}

// Called when the window is taken down;
void plot_module::plot_ended(void)
{
  
}


void plot_shell::make_plotting_window(int width, int height, const char *title)
{
  if(title)
    sh.build(mainwin::toplevel, title);
  else
    sh.build(mainwin::toplevel, WHAT((char *) "Plottevindu", 
				     (char *) "Plotting window"));
  v1.build(sh);
  put_in_widget(v1, width, height, PLOT_IN_WIDGET_SHOWMAINMENU);
  h1.build(v1);
  closeb.build(h1, &sh, WHAT((char *) "Lukk vindu", (char *) "Close"));
  closeb.Background("red");
  closeb.Foreground("white");

  sh.Map();
}

void plot_shell::plot_ended(void)
{
  sh.Unmap();
}


#ifdef MAIN

class plot_test : public plot_module
{
public:
  void plot_ended(void) {endpostscript(); exit(0);}
};

int main(int argc, char **argv)
{
  mainwin mn("plot test", argc, argv);
  plot_test pm;
  label lab;
  shell sh;
  vrow v1;

  char *linetitles[]={"Plotting test 1","Plotting test 2",
		      "Third plotting test (tests the width "
		      "of the line text)"};
  char *axistitles[]={"x axis","y axis", "axis 2"};
  double **arg=new double*[3];
  double **val=new double*[3];
  int i, length[]={800, 875, 700};
  int axis[]={1, 1, 1};
  
  arg[0]=new double[length[0]];
  val[0]=new double[length[0]];

  for(i=0;i<length[0];i++)
    {
      double x = -1.0 + 10.0*((double) (i+1)) / ((double) length[0]);

      x = x;
      arg[0][i] = x;
      val[0][i] = x*x/10.0+0.8;
    }

  arg[1]=new double[length[1]];
  val[1]=new double[length[1]];

  for(i=0;i<length[1];i++)
    {
      double x = 1.0 + 10.0*((double) (i+1)) / ((double) length[1]);

      x = x;
      arg[1][i] = x;
      val[1][i] = x*x/10.0-0.6;
    }

  arg[2]=new double[length[2]];
  val[2]=new double[length[2]];

  for(i=0;i<length[2];i++)
    {
      double x = 1.0 + 10.0*((double) (i+1)) / ((double) length[2]);

      x = x;
      arg[2][i] = x;
      val[2][i] = x*x/10.0+0.4;
    }

  pm.set_standard_line_font_size(PLOT_FONT_EXTRALARGE);
  pm.Create(arg, val, length, axis, linetitles, 3, 
	    axistitles, 2, NULL /*"Plotte-test"*/);

  lab.build(mn, "Nothing here...");

  mn.Run();
  return 0;
}

#endif // MAIN

