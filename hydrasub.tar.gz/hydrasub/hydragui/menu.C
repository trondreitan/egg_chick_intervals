/*
 * $Id: menu.C 2885 2017-02-28 14:38:02Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/menu.C $
 */

#include <hydrasub/hydragui/menu.H>
#include <hydrasub/hydragui/color.H>
#include <stdarg.h>

#include <Xm/CascadeB.h>
#include <Xm/RowColumn.h>
#include <Xm/SeparatoG.h>
#include <Xm/ToggleB.h>


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void menubar::init(const char *name, const WidgetClass, const Widget parent)
{
  xchar na(name);
  w = XmCreateMenuBar(parent, na, args, no_args);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void menubar::build(const Widget parent) 
{
  XmNoArg;
  init("menubar", NULL, parent);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pulldown::init(const char *name, const WidgetClass, const Widget parent)
{
  xchar na(name);
  w = XmCreatePulldownMenu(parent, na, args, no_args);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pulldown::build(const Widget parent) 
{
  XmNoArg;
  init("pulldown", NULL, parent);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void cascade::build(const Widget menubar, const Widget pulldown, const char *title,
		    bool helpcascade) 
{
    xmstring str((char*)title);
  XmInitSetArg(XmNsubMenuId, pulldown);
  XmSetArg(XmNlabelString, (XmString &)str);
  
  init (title, xmCascadeButtonWidgetClass, menubar);
  if(helpcascade)
    XtVaSetValues(menubar,XmNmenuHelpWidget,w,NULL);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void optmenu::init(const char *name, const WidgetClass, const Widget parent)
{
  init2(name,NULL,parent);
}

void optmenu::init2(const char *name, const WidgetClass, const Widget parent)
{
  xchar na(name);
  w = XmCreateOptionMenu(parent, na, args, no_args);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void optmenu::build(const Widget parent, const Widget pulldown, 
		    const Widget focus, const char *title) 
{
    xmstring xtitle((char *)title);

  XmInitSetArg(XmNmenuHistory, focus);
  if(title) 
    {
      XmSetArg(XmNlabelString, (XmString &)xtitle);
    }

  XmSetArg(XmNsubMenuId, pulldown);
  init2("option", NULL, parent);
  Map();
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void optmenu::build_no_show(const Widget parent, const Widget pulldown, 
			    const Widget focus, const char *title) 
{
    xmstring xtitle((char *)title);

  XmInitSetArg(XmNmenuHistory, focus);
  if(title)
    {
      XmSetArg(XmNlabelString, (XmString &)xtitle);
    }

  XmSetArg(XmNsubMenuId, pulldown);
  init2("option", NULL, parent);
}

// ######################################################################
// Return    : void
// Parameters: pulldown
// Purpose   : Manually change to a new pulldown list
// ######################################################################
void optmenu::subMenuId(const Widget pulldown)
{
    XtVaSetValues(w, XmNsubMenuId, pulldown, NULL);
} /* subMenuId */


// ######################################################################
// Return    : void
// Parameters: focus - which pushbutton should now be in focus?
// Purpose   : Lets the programmer change focus from programs
// ######################################################################
void optmenu::ChangeFocus(const Widget focus)
{
    XtVaSetValues(w, XmNmenuHistory, focus, NULL);
} /* ChangeFocus */

// ######################################################################
// Return    : char * - returns the current pushbutton in focus
// Parameters: void
// Purpose   : 
// ######################################################################
const char *optmenu::CurrStr()
{
    static char str[100];
    Widget focus;
    XtVaGetValues(w, XmNmenuHistory, &focus, NULL);
    strcpy(str, XtName(focus));
    return str;
} /* CurrStr */


// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
void SelOptmenu::spushb::pushed()
{
  pt->pushed(XtName(w));
} /* pushed */

// ######################################################################
// Parameters: void
// Purpose   : Initiate local variables
// ######################################################################
SelOptmenu::SelOptmenu() : pulldown(),plist(NULL), len(0),seps(NULL)
{
} /* SelOptmenu */


// ######################################################################
// Purpose   : Free memory
// ######################################################################
SelOptmenu::~SelOptmenu()
{
  if(plist)
    delete [] plist;
  if(seps)
    delete [] seps;

  plist = NULL;
  len = 0;
} /* ~SelOptmenu */

// ######################################################################
// Return    : void
// Parameter : color - the name of the new background color
// Purpose   : set the background color
// ######################################################################
void SelOptmenu::SetBackground(const char *color, bool just_current_item)
{
  Background(color);
  if(!just_current_item)
    {
      opt.Background(color);
      for(int i = 0; i < len; i++)
	plist[i].Background(color);
    }
}

// ######################################################################
// Return    : void
// Parameter : color - the name of the new foreground color
// Purpose   : set the foreground color
// ######################################################################
void SelOptmenu::SetForeground(const char *color, bool just_current_item)
{
  Foreground(color);
  if(!just_current_item)
    {
      opt.Foreground(color);
      for(int i = 0; i < len; i++)
	plist[i].Foreground(color);
    }
}

// ######################################################################
// Return    : void 
// Parameters: parent - where to put this optmenu
//             title  - title for this optmenu
// Purpose   : Creates an optmenu
// ######################################################################
void SelOptmenu::Create(const Widget parent, const char *title)
{
  build(parent);
  len = 1;
  plist = new spushb[len];
  plist[0].build(*this, "??");
  plist[0].pt = this;
  opt.build(parent, *this, plist[0], title);
  strcpy(plist[0].itemname, "??");
    
  opt.ChangeFocus(plist[0]);
} /* Create */


// ######################################################################
// Return    : void
// Parameters: parent - where to put this optmenu
//             title  - title for this optmenu
// Purpose   : Creates an optmenu
// ######################################################################
void SelOptmenu::Create_no_show(const Widget parent, const char *title)
{
    build(parent);
    len = 1;
    plist = new spushb[len];
    plist[0].build(*this, "??");
    plist[0].pt = this;
    opt.build_no_show(parent, *this, plist[0], title);
} /* Create */

void SelOptmenu::show(void)
{
  opt.Map();
}

// ######################################################################
// Return    : void
// Parameters: list - list with items for this optmenu
//             ilen - no of item in this list
// Purpose   : Insert list as pushbutton inot this optmenu and remove olds.
// ######################################################################
void SelOptmenu::Insert(char const* const* list, int ilen, int focus,
			char const* const* bg_colors, char const* const* fg_colors,
			int *sep_positions,int num_seps)
{
  int i;
  
  int newlen = ilen;
  spushb   *newplist = new spushb[newlen];
  
  if(sep_positions && num_seps>0)
    {
      qsort(sep_positions, size_t(num_seps), sizeof(int), compare_int);
      if(seps)
	delete [] seps;
      seps=new hsep[num_seps];
    }
  int j=0; // tracks current separator examined

  for(i = 0; i < newlen; i++) 
    {
      if(sep_positions && num_seps>0 && j<num_seps &&
	 sep_positions[j]==i)
	{
	  seps[j].build(*this);
	  j++;
	}
      
      newplist[i].build(*this, list[i]);
      newplist[i].pt = this;
      strcpy(newplist[i].itemname, list[i]);
      if(bg_colors && bg_colors[i] && strlen(bg_colors[i])>0)
	newplist[i].Background(bg_colors[i]);
      if(fg_colors && fg_colors[i] && strlen(fg_colors[i])>0)
	newplist[i].Foreground(fg_colors[i]);
    }

  if(plist)
    {
      for(i = 0; i < len; i++)
	plist[i].Unmap();
      
      delete [] plist;
    }
  plist=newplist;
  len=newlen;
  
  opt.ChangeFocus(plist[focus]);
} /* Insert */

int SelOptmenu::GetNumber(void)
{
  char curr[100];
  int i;

  strcpy(curr,CurrStr());
  for(i=0;i<len;i++)
    {
      if(!strcmp(curr,plist[i].itemname))
	return i;
    }
  return i;
}

SelOptmenu::spushb::spushb() : pushb()
{
}

SelOptmenu::spushb::~spushb()
{
}

// ######################################################################
// Return    : void
// Parameters: newfocus - the item you want be in focus
// Purpose   : Change focus in an optionmenu
// ######################################################################
void SelOptmenu::SetFocus(const char *newfocus)
{
    for(int i = 0; i < len; i++)
	if(strcmp(XtName(plist[i]), newfocus) == 0) {
	    opt.ChangeFocus(plist[i]);
	    return;
	};
} /* SetFocus */

// ######################################################################
// Return    : void
// Parameters: newfocus - the item you want be in focus
// Purpose   : Change focus in an optionmenu
// ######################################################################
void SelOptmenu::SetFocus(int newfocus)
{
  opt.ChangeFocus(plist[newfocus]);
} /* SetFocus */


// ######################################################################
// Return    : char * - return current pushbutton
// Parameters: void
// Purpose   : Lets the user query for current pushbutton
// ######################################################################
const char *SelOptmenu::CurrStr()
{
    return opt.CurrStr();
} /* CurrStr */

// ######################################################################
// Return    : void
// Parameters: item - the item choosen as a string
// Purpose   : Every time a pushbutton is pressed, this routine is called
// ######################################################################
void SelOptmenu::pushed(const char *)
{
} /* pushed */

// ######################################################################
// Parameters: void
// Purpose   : Initiate local variables
// ######################################################################
Menu::Menu()
{
  pulld=NULL;
  cas=NULL;
  menustr=NULL;
  numitems=0;
} /* Menu */


// ######################################################################
// Purpose   : Free memory
// ######################################################################
Menu::~Menu()
{
  cleanup();
} /* ~Menu */

void Menu::cleanup(void)
{
  if(cas)
    delete [] cas;
  cas = NULL;

  if(pulld)
    delete [] pulld;
  pulld = NULL;

  doubledelete(menustr,numitems);
  numitems=0;
  menustr=NULL;
} // Menu::cleanup

// Send "STM:..." in a string if you want to start a new pulldown
// Send "HLP:..." if a help pulldown is wanted.
// SEND "SEP" if a separator in the working pulldown is wanted.
// Send "..." if a menu item should be added
// Send NULL when the parameters is terminated.
void Menu::build(const Widget parent, ...)
{
  va_list ap;
  char *s;
  int no = 0, n = 0;
  Widget c, p;
  
  menubar::build(parent);
  cleanup();

  numitems=0;
  // Counting no of CascadeMenus
  va_start(ap, parent);
  while((s = va_arg(ap, char *)) != NULL)
    {
      numitems++;
      if(strncmp(s, "STM:", 4) == 0 || strncmp(s, "HLP:", 4) == 0) 
	no++;
    }
  va_end(ap);

  menustr=new char*[numitems];
  pulld = new pulldown[no];
  cas = new cascade[no];

  // Building the Menu
  va_start(ap, parent);
  int i=0;
  while((s = va_arg(ap, char *)) != NULL)
    {
      menustr[i]=new char[strlen(s)+2];
      strcpy(menustr[i],s);
      i++;

      if(strncmp(s, "STM:", 4) == 0 || strncmp(s, "HLP:", 4) == 0) 
	{
	  pulld[n].build(w);
	  p = pulld[n];
	  cas[n].build(w, p, s + 4, strncmp(s, "HLP:", 4) == 0);
	  c = cas[n];
	  n++;
	} 
      else if(strncmp(s, "SEP", 3) == 0) 
	{
	  XtVaCreateManagedWidget("separator",
				  xmSeparatorGadgetClass, p, NULL);
	} 
      else if(strncmp(s, "T:", 2) == 0) 
	{
	  Widget pu = 
	    XtVaCreateManagedWidget (s + 2,
				     xmToggleButtonWidgetClass, p,
				     XmNselectColor, motifsubcolors[CORAL1],
				     XmNbackground, motifsubcolors[BISQUE3],
				     XmNforeground, motifsubcolors[BLACK],
				     NULL);
	  
	  XtAddCallback(pu, XmNvalueChangedCallback, 
			(XtCallbackProc)&Menu::pushCB,
			(XtPointer)this);
	  
	} 
      else 
	{
	  Widget pu = 
	    XtVaCreateManagedWidget (s,
				     xmPushButtonWidgetClass, p,
				     XmNbackground, motifsubcolors[BISQUE3],
				     XmNforeground, motifsubcolors[BLACK],
				     NULL);
	  
	  XtAddCallback(pu, XmNactivateCallback, 
			(XtCallbackProc)&Menu::pushCB,
			(XtPointer)this);
	  
	}
    }

  va_end(ap);
  Map();
}

// Send "STM:..." in a string if you want to start a new pulldown
// Send "HLP:..." if a help pulldown is wanted.
// SEND "SEP" if a separator in the working pulldown is wanted.
// Send "..." if a menu item should be added
// Send NULL when the parameters is terminated.
void Menu::build_(const Widget parent, char const* const* instr, int numstr)
{
  int i,no = 0, n = 0;
  Widget c, p;
  
  cleanup();

  for(i=0;i<numstr;i++)
   if(strncmp(instr[i], "STM:", 4) == 0 || strncmp(instr[i], "HLP:", 4) == 0) 
     no++;

  numitems=numstr;
  menustr=new char*[numitems];
  menubar::build(parent);
  pulld = new pulldown[no];
  cas = new cascade[no];

  // Building the Menu
  for(i=0;i<numitems;i++)
    {
      menustr[i]=new char[strlen(instr[i])+2];
      strcpy(menustr[i],instr[i]);

      if(strncmp(instr[i], "STM:", 4) == 0 || 
	 strncmp(instr[i], "HLP:", 4) == 0) 
	{
	  pulld[n].build(w);
	  p = pulld[n];
	  cas[n].build(w, p, instr[i] + 4, strncmp(instr[i], "HLP:", 4) == 0);
	  c = cas[n];
	  n++;
	} 
      else if(strncmp(instr[i], "SEP", 3) == 0) 
	{
	  XtVaCreateManagedWidget("separator",
				  xmSeparatorGadgetClass, p, NULL);
	} 
      else if(strncmp(instr[i], "T:", 2) == 0) 
	{
	  Widget pu = 
	    XtVaCreateManagedWidget (instr[i] + 2,
				     xmToggleButtonWidgetClass, p,
				     XmNselectColor, motifsubcolors[CORAL1],
				     XmNbackground, motifsubcolors[BISQUE3],
				     XmNforeground, motifsubcolors[BLACK],
				     NULL);
	  
	  XtAddCallback(pu, XmNvalueChangedCallback, 
			(XtCallbackProc)&Menu::pushCB,
			(XtPointer)this);
	  
	} 
      else 
	{
	  Widget pu = 
	    XtVaCreateManagedWidget (instr[i],
				     xmPushButtonWidgetClass, p,
				     XmNbackground, motifsubcolors[BISQUE3],
				     XmNforeground, motifsubcolors[BLACK],
				     NULL);
	  
	  XtAddCallback(pu, XmNactivateCallback, 
			(XtCallbackProc)&Menu::pushCB,
			(XtPointer)this);
	  
	}
    }

  Map();
} // Menu::build


void Menu::pushCB(Widget w, Menu *pt, XtPointer) {
        pt->pushed(XtName(w));
}

#ifdef MAIN
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/row.H>
class MyMenu : public Menu 
{
public:
  void build(Widget parent) 
  {
    Menu::build(parent, 
		"STM:File", "Open", "Close", "SEP", "Quit",
		"STM:Help", "T:On Context", "T:Tutorial", NULL);
  }
  void pushed(const char *name) { cout << name << endl; }
};

class seloptmenu : public SelOptmenu 
{
public:
  void pushed(const char *item) { cerr << item << endl; };
};

main(int argc, char **argv) 
{
  mainwin m(argv[0], argc, argv);
  seloptmenu so;
  
  char *l[] = {"A", "B", "C", "D", "E" };
  char *ll[] = {"1", "2", "3", "4"};
  
  so.Create(m, "Unit");
  so.Insert(l, 5);
  so.Insert(ll, 4);
  
  m.Run();
};

#endif
