/*
 * $Id: gifcanvas.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/gifcanvas.C $
 */

#include <hydrasub/hydragui/gifcanvas.H>


gifcanvas::gifcanvas() : drawgif()
{
  image_ptr=NULL;
  size_x=size_y=0;
}

gifcanvas::~gifcanvas()
{
  if(image_ptr)
    gdImageDestroy(image_ptr);
}

void gifcanvas::Build(widget parent,int sizex, int sizey)
{
  int i;
  int black_col, white_col;

  size_x=sizex;
  size_y=sizey;

  //if(image_ptr)
  //gdImageDestroy(image_ptr);
 
  image_ptr=gdImageCreate(sizex, sizey);
  
  // Allocate the color black
  // This will be the background color
  black_col=gdImageColorAllocate(image_ptr,0,0,0);
  white_col=gdImageColorAllocate(image_ptr,255,255,255);

  /*
  for(i=1;i<85;i++)
    gif_color[i+1]=gdImageColorAllocate(image_ptr,255-i*3,i*3,0);

  for(i=85;i<170;i++)
    gif_color[i+1]=gdImageColorAllocate(image_ptr,0,255-(i-85)*3,(i-85)*3);
    
  for(i=170;i<255;i++)
    gif_color[i+1]=gdImageColorAllocate(image_ptr,(i-170)*3,0,255-(i-170)*3);
  */

  for(i=1;i<85;i++)
    gif_color[i+1]=gdImageColorAllocate(image_ptr,255-i*3,0,0);

  for(i=85;i<170;i++)
    gif_color[i+1]=gdImageColorAllocate(image_ptr,0,255-(i-85)*3,0);
    
  for(i=170;i<255;i++)
    gif_color[i+1]=gdImageColorAllocate(image_ptr,0,0,255-(i-170)*3);

  Create(parent, image_ptr);
}

  

void gifcanvas::save(char *filename)
  
{
  FILE *out;

   // Open a file fro writing
  out=fopen(filename,"wb");
  
  // Send the image to the file
  gdImageGif(image_ptr,out);

  // Close the file
  fclose(out);
}

void gifcanvas::setcolor(int red, int green, int blue)
{
  currcolor=gdImageColorClosest(image_ptr, red, green, blue);
}

void gifcanvas::setcolor(int current_color)
{
  currcolor=current_color;
}

void gifcanvas::circle(int x, int y, int r)
{
  gdImageArc(image_ptr, x, y, r, r, 0, 360, currcolor);
}

void gifcanvas::point(int x, int y)
{
  gdImageSetPixel(image_ptr,x,y,currcolor);
}

void gifcanvas::line(int x1, int y1, int x2, int y2)
{
  gdImageLine(image_ptr,x1,y1,x2,y2,currcolor);
}

void gifcanvas::dashedline(int x1, int y1, int x2, int y2)
{
  gdImageDashedLine(image_ptr,x1,y1,x2,y2,currcolor);
}

void gifcanvas::fill(int x, int y)
{
  gdImageFill(image_ptr, x, y, currcolor);
}

void gifcanvas::showtext(int x, int y, char *txt)
{
  gdImageString(image_ptr, gdFontSmall, x, y, (unsigned char*)txt, currcolor);
}






#ifdef MAIN

#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/pushb.H>
#include <hydrasub/hydragui/row.H>
#include <hydrasub/hydragui/filesel.H>


class gifcanvas_mainwin;
enum GC_TYPE {GC_EXIT,GC_SAVE};

class gifcanvas_button : public pushb
{
  GC_TYPE typ;
  gifcanvas_mainwin *pt;
public:
  void Create(widget parent, char *title, gifcanvas_mainwin *ipt, 
	      GC_TYPE type);
  void pushed(void);
};


class gifcanvas_mainwin : public mainwin
{
  friend class gifcanvas_button;
  friend class gifcanvas_filesel;
private:
  gifcanvas gc;
  vrow v1;
  hrow h1;
  gifcanvas_button exitb,saveb;
  image_filesel isel;

  char tempfile[100];
protected:
  void file_chosen(char *file);
  void buttonpushed(GC_TYPE type);
public:
  gifcanvas_mainwin(char *title, int argc, char ** argv);
};



void gifcanvas_button::Create(widget parent, char *title, 
			      gifcanvas_mainwin *ipt, GC_TYPE type)
{
  typ=type;
  pt=ipt;
  build(parent, title);
}

void gifcanvas_button::pushed(void)
{
  pt->buttonpushed(typ);
}


void gifcanvas_mainwin::buttonpushed(GC_TYPE type)
{
  switch(type)
    {
    case GC_EXIT:
      exit(0);
    case GC_SAVE:
      strcpy(tempfile,"/tmp/filecanvas.gif");
      gc.save(tempfile);
      isel.Create(tempfile, GIF);
    }
}

gifcanvas_mainwin::gifcanvas_mainwin(char *title, int argc, char ** argv) :
  mainwin(title, argc, argv)
{
  v1.build(*this);
  gc.Build(v1, 700, 700);

  gc.setcolor(255,0,0);
  gc.circle(100,100,30);
  gc.setcolor(0,255,0);
  gc.fill(100,100);
  gc.setcolor(255,255,255);
  gc.showtext(125,125,"Dette er flott, hva?");

  for(int i=0;i<700;i+=2)
    {
      gc.setcolor(255,255,255);
      gc.line(350,0,i,699);
      gc.setcolor(0,0,0);
      gc.line(350,0,i+1,699);
    }

  h1.build(v1);
  exitb.Create(h1, "Avslutt", this, GC_EXIT);
  exitb.Background("red");
  exitb.Foreground("white");

  saveb.Create(h1, "Lagre", this, GC_SAVE);
  saveb.Background("green");
  saveb.Foreground("black");
}


void main(int argc,char **argv)
{
  gifcanvas_mainwin gcm("gifcanvas", argc, argv);
  gcm.Run();
}

#endif // MAIN
