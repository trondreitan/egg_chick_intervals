/*
 * $Id: row.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/row.C $
 */

#include <hydrasub/hydragui/row.H>

#include <Xm/RowColumn.h>
#include <hydrasub/hydragui/frame.H>
#include <hydrasub/hydragui/label.H>
#include <hydrasub/hydragui/separator.H>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void row::build(const Widget parent, const char *title)
{
    if(title != NULL) {
	frame f; f.build(parent);
	if(direction() == XmVERTICAL) {
	    vrow r;
	    r.build(f);
	    label l; l.build(r, title);
	    hsep  s; s.build(r);
	    
	    XmInitSetArg(XmNorientation, direction());
	    init(widgetname(), xmRowColumnWidgetClass, r);

	} else {
	    hrow r;
	    r.build(f);
	    label l; l.build(r, title);
	    
	    XmInitSetArg(XmNorientation, direction());
	    init(widgetname(), xmRowColumnWidgetClass, r);
	};
    } else {
	XmInitSetArg(XmNorientation, direction());
	init(widgetname(), xmRowColumnWidgetClass, parent);
    };
}



// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Set aligment for this RowColumn to Beginning
// ######################################################################
void row::alignBeginning()
{
    XtVaSetValues(w, XmNalignment, XmALIGNMENT_BEGINNING, NULL);
} /* alignBeginning */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Set aligment for this RowColumn to Center
// ######################################################################
void row::alignCenter()
{
    XtVaSetValues(w, XmNalignment, XmALIGNMENT_CENTER, NULL);
} /* alignCenter */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Set aligment for this RowColumn to End
// ######################################################################
void row::alignEnd()
{
    XtVaSetValues(w, XmNalignment, XmALIGNMENT_END, NULL);
} /* alignEnd */

// ######################################################################
// Return    : void
// Parameters: col - no. of columns
// Purpose   : Set no. of columsn for each row
// ######################################################################
void row::numColumns(int col)
{
    XtVaSetValues(w, XmNnumColumns, col, NULL);
} /* numColumns */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Set packing rules for this RowColumn to pack column
// ######################################################################
void row::packColumn()
{
    XtVaSetValues(w, XmNpacking, XmPACK_COLUMN, NULL);
} /* packColumn */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Set packing rules for this RowColumn to pack tight
// ######################################################################
void row::packTight()
{
    XtVaSetValues(w, XmNpacking, XmPACK_TIGHT, NULL);
} /* packTight */

// ######################################################################
// Return    : void
// Parameters: pixels - positive pixels spacing values
// Purpose   : Add spacing to each cell in this RowColumn
// ######################################################################
void row::spacing(int pixels)
{
    XtVaSetValues(w, XmNspacing, pixels, NULL);
} /* spacing */
