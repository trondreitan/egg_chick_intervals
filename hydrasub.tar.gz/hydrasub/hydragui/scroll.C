/*
 * $Id: scroll.C 2056 2012-09-07 11:22:56Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/scroll.C $
 */

#include <hydrasub/hydragui/scroll.H>

#include <Xm/ScrolledW.h>
#include <Xm/ScrollBar.h>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void scroll::build(const Widget parent) 
{
  XmInitSetArg(XmNscrollingPolicy, XmAUTOMATIC);
  init("scroll", xmScrolledWindowWidgetClass, parent);
}
