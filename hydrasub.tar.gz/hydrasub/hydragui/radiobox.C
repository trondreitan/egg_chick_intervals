/*
 * $Id: radiobox.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/radiobox.C $
 */

#include <hydrasub/hydragui/radiobox.H>
#include <Xm/RowColumn.h>


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void radiobox::init(const char *name, const WidgetClass, 
		      const Widget parent)
{
  char *na = new char[strlen(name) + 1];
  strcpy(na, name);

  XmInitSetArg(XmNorientation, direction());
  w = XmCreateRadioBox(parent, na, args, no_args);

  delete [] na;
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void radiobox::build(const Widget parent) 
{
  init("radiobox", NULL, parent);
  Map();
}
