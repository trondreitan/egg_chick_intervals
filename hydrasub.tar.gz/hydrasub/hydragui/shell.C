/*
 * $Id: shell.C 2232 2013-04-11 11:41:09Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/shell.C $
 */

#include <hydrasub/hydragui/shell.H>

#include <Xm/BulletinB.h>
#include <Xm/MwmUtil.h>
#include <X11/Shell.h>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void shelldialog::init(const char *name, const WidgetClass, 
		       const Widget parent)
{
    xchar na(name);
    w = XmCreateBulletinBoardDialog(parent, na, args, no_args);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void shelldialog::build(const Widget parent, const char *title) 
{
  xmstring xtitle(title);
  XmInitSetArg(XmNdialogTitle, (XmString &)xtitle);
  init(title, NULL, parent);
  Noborder();
}

void shelldialog::Noborder(void)
{
  int decor; // To hold decoration bit pattern
  // decor changed to only border, title and minimize, instead of removing close.    
  decor = MWM_DECOR_BORDER | MWM_DECOR_TITLE | MWM_DECOR_MINIMIZE;
  XtVaSetValues(w, XmNmwmDecorations, decor, NULL);   
}

void shelldialog::activate_menu(void)
{
  int decor,functions; // To hold decoration bit pattern
  // decor changed to only border, title and minimize, instead of removing close.    
  decor = MWM_DECOR_BORDER | MWM_DECOR_TITLE | MWM_DECOR_MINIMIZE | MWM_DECOR_MENU;
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE; 
  XtVaSetValues(w, XmNmwmDecorations, decor, NULL);  
  XtVaSetValues(w, XmNmwmFunctions, functions, NULL);  
}

void shelldialog::activate_resize(void)
{
  int functions; // To hold the bit pattern
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE | MWM_FUNC_RESIZE |
    MWM_FUNC_MAXIMIZE;
  XtVaSetValues(w, XmNmwmFunctions, functions, NULL);  
}

void shelldialog::deactivate_resize(void)
{
  int functions; // To hold the bit pattern
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE;
  XtVaSetValues(w, XmNmwmFunctions, functions, NULL);  
}



// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget iconic
// ######################################################################
void shelldialog::Iconify(void)
{
  XtVaSetValues(w,XmNiconic, True, NULL);
} /* Sensitive */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget less iconic
// ######################################################################
void shelldialog::DeIconify(void)
{
  XtVaSetValues(w,XmNiconic, False, NULL);
} /* InSensitive */

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void closeshelldialog::build(Widget parent, shelldialog *s, const char *str)
{
  pushb::build(parent, str);
  sh = s;
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void closeshelldialog::pushed()
{
  sh->Unmap();
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void shell::build(const Widget parent, const char *title) 
{
  xmstring xmstr(title);
  XmInitSetArg(XmNallowShellResize, True);
  XmSetArg(XmNdialogTitle, (XmString &)xmstr);
  
  w = XtCreatePopupShell(title, transientShellWidgetClass,
			 parent, args, no_args);
  Noborder();
}

void shell::Noborder(void)
{
  int decor; // To hold decoration bit pattern
  // decor changed to only border, title and minimize, instead of removing close.    
  decor = MWM_DECOR_BORDER | MWM_DECOR_TITLE | MWM_DECOR_MINIMIZE;
  XtVaSetValues(w, XmNmwmDecorations, decor, NULL);  
}

void shell::activate_menu(void)
{
  int decor,functions; // To hold decoration bit pattern
  // decor changed to only border, title and minimize, instead of removing close.    
  decor = MWM_DECOR_BORDER | MWM_DECOR_TITLE | MWM_DECOR_MINIMIZE | MWM_DECOR_MENU;
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE; 
  XtVaSetValues(w, XmNmwmDecorations, decor, NULL);  
  XtVaSetValues(w, XmNmwmFunctions, functions, NULL);  
}

void shell::activate_resize(void)
{
  int functions; // To hold the bit pattern
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE | MWM_FUNC_RESIZE |
    MWM_FUNC_MAXIMIZE;
  XtVaSetValues(w, XmNmwmFunctions, functions, NULL);  
}

void shell::deactivate_resize(void)
{
  int functions; // To hold the bit pattern
  functions = MWM_FUNC_MOVE | MWM_FUNC_MINIMIZE;
  XtVaSetValues(w, XmNmwmFunctions, functions, NULL);  
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void shell::Map() 
{
  XtPopup(w, XtGrabNone);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void shell::GrabMap() 
{
  XtPopup(w, XtGrabExclusive);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void shell::PartGrabMap() 
{
  XtPopup(w, XtGrabNonexclusive);
}
 

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   :  
// ######################################################################
void shell::Unmap() 
{
  XtPopdown(w);
}


// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget iconic
// ######################################################################
void shell::Iconify(void)
{
  XtVaSetValues(w, XmNiconic, True, NULL);
} /* Sensitive */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : make this widget less iconic
// ######################################################################
void shell::DeIconify(void)
{
  XtVaSetValues(w, XmNiconic, False, NULL);
} /* InSensitive */

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void closeshell::build(Widget parent, shell *s, const char *str)
{
  pushb::build(parent, str);
  Background("red");
  Foreground("white");
  sh = s;
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void closeshell::pushed()
{
  sh->Unmap();
}
