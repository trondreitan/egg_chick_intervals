/*
 * $Id: draw.C 2610 2015-11-23 10:26:43Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/draw.C $
 */

#include <hydrasub/hydragui/draw.H>
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydrabase/divfunc.H>
#include <X11/keysym.h>
#include <Xm/DrawingA.h>
#include <cmath>

#include <sys/time.h>

#ifdef NVE /* NVE specific code */
#include <envirsub/system.H>
#include <envirsub/path.H>
#else  
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#endif // NVE

sprite::sprite(sprite *previtem, sprite *nextitem, draw *ipt,
	       int width_, int height_, int x_, int y_, rgb **image_,
	       rgb background_) :
  double_linked_list((double_linked_list *) previtem, 
		     (double_linked_list *) nextitem)
{
  pt=ipt;
  
  Set(width_, height_, x_, y_, image_, background_);
  
  shown=False;
  prev=curr=NULL;
}

sprite::sprite(draw *ipt, int width_, int height_, int x_, int y_, 
	       rgb **image_, rgb background_) : double_linked_list()
{
  pt=ipt;
  
  Set(width_, height_, x_, y_, image_, background_);
  
  shown=False;
  prev=curr=NULL;
}

sprite::sprite(sprite *previtem, sprite *nextitem, draw *ipt, sprite *orig) :
  double_linked_list((double_linked_list *) previtem, 
		     (double_linked_list *) nextitem)
{
  pt=ipt;
  
  Set(orig->width, orig->height, orig->x0, orig->y0, orig->image, 
      orig->background);
  
  shown=False;
  prev=curr=NULL;
}

void sprite::cleanup(void)
{
  if(prev && prev->data)
    {
      XFree(prev->data);
      prev->data=NULL;
      XFree(prev);
      prev=NULL;
    }
  
  if(curr && curr->data)
    {
      XFree(curr->data);
      curr->data=NULL;
      XFree(curr);
      curr=NULL;
    }

  if(image)
    {
      for(int i=0;i<width;i++)
	if(image[i])
	  delete [] image[i];
      delete [] image;
    }
  image=NULL;
}

sprite::~sprite()
{
  remove();

  cleanup();
  pt=NULL;
}

void sprite::Set(int width_, int height_, int x_, int y_, rgb **image_, 
		 rgb background_)
{
  int i,j;

  height=height_;
  width=width_;
  x0=x_;
  y0=y_;

  image=new rgb*[width];
  for(i=0;i<width;i++)
    {
      image[i]=new rgb[height];
      for(j=0;j<height;j++)
	image[i][j]=image_[i][j];
    }

  background=background_;
}

void sprite::change_coordinates(int newx, int newy)
{
  if(shown)
    remove();
  x0=newx;
  y0=newy;
  show();
}

void sprite::change_image(rgb **newimage, bool doremove)
{
  if(shown && doremove)
    remove();

  for(int i=0;i<width;i++)
    {
      for(int j=0;j<height;j++)
	image[i][j]=newimage[i][j];
    }

  show();
}

void sprite::change_image(int newx, int newy,rgb **newimage, bool doremove)
{
  if(shown && doremove)
    remove();  
  
  x0=newx;
  y0=newy;

  for(int i=0;i<width;i++)
    {
      for(int j=0;j<height;j++)
	image[i][j]=newimage[i][j];
    }

  show();
}

void sprite::change_image(sprite *orig)
{
  if(shown)
    remove();

  cleanup();
  Set(orig->width, orig->height, orig->x0, orig->y0, orig->image, 
      orig->background);
  
  show();
}

void sprite::show(void)
{
  if(pt)
    {
      int x,y;

      pt->findcontext();

      struct timeval tv, tv2;
      struct timezone tz, tz2;
      int dt;
      double dt2;
      
      int width2=MINIM(width, pt->get_width()-x0);
      int height2=MINIM(height, pt->get_height()-y0);

      if(width2<=0 || height2<=0)
	return;

      gettimeofday(&tv, &tz);
      if(!shown && x0>=0 && (x0 < pt->get_width()) && y0>=0 && (y0 < pt->get_height()))
	prev=XGetImage(pt->display, pt->window, x0, y0, width2, height2, 
		       AllPlanes, ZPixmap);

      gettimeofday(&tv2, &tz2);
      dt = (tv2.tv_sec - tv.tv_sec)*1000000+(tv2.tv_usec-tv.tv_usec);
      dt2=double(dt)/1000000.0;
      //cout << "getprev:" << dt2 << endl;

      if(curr && curr->data)
	{
	  XFree(curr->data);
	  curr->data=NULL;
	  XFree(curr);
	  curr=NULL;
	}

      
      gettimeofday(&tv, &tz);

      curr=new XImage();
      *curr=*prev;
      curr->data=(char *) malloc(4*width2*height2);
      for(x=0;x<4*width2*height2;x++)
	curr->data[x]=prev->data[x];
      
      gettimeofday(&tv2, &tz2);
      dt = (tv2.tv_sec - tv.tv_sec)*1000000+(tv2.tv_usec-tv.tv_usec);
      dt2=double(dt)/1000000.0;
      //cout << "getcurr:" << dt2 << endl;


      curr->format=2;
      curr->width=width2;
      curr->height=height2;
      curr->bitmap_pad=32;
      curr->byte_order=curr->bitmap_bit_order=1;
      curr->obdata=NULL; 
      curr->bytes_per_line=4*width2;
      curr->bitmap_unit=8;
      curr->bits_per_pixel=32;
      curr->red_mask=255;
      curr->green_mask=65280;
      curr->blue_mask=16711680;
      
      gettimeofday(&tv, &tz);

      int pos=0;
      char buffer;
      for(y=0;y<height2;y++)
	for(x=0;x<width2;x++)
	  {
	    pos+=4;
	    if( image[x][y].red!=background.red || 
		image[x][y].green!=background.green || 
		image[x][y].blue!=background.blue ) 
	      {
		curr->data[pos] = 0;
		curr->data[pos+1] = image[x][y].red;
		curr->data[pos+2] = image[x][y].green;
		curr->data[pos+3] = image[x][y].blue;
	      }
	    else
	      {
		buffer=prev->data[pos+2];
		curr->data[pos+3] = prev->data[pos];
		curr->data[pos+2] = prev->data[pos+1];
		curr->data[pos+1] = buffer;
		curr->data[pos] = 0;
	      }
	  }
      
      gettimeofday(&tv2, &tz2);
      dt = (tv2.tv_sec - tv.tv_sec)*1000000+(tv2.tv_usec-tv.tv_usec);
      dt2=double(dt)/1000000.0;
      //cout << "fillimage:" << dt2 << endl;

      gettimeofday(&tv, &tz);

      XPutImage(pt->display, pt->window, pt->gc, curr, 0, 0, 
		x0, y0, width2, height2);
      shown=True;
      
      gettimeofday(&tv2, &tz2);
      dt = (tv2.tv_sec - tv.tv_sec)*1000000+(tv2.tv_usec-tv.tv_usec);
      dt2=double(dt)/1000000.0;
      //cout << "showcurr:" << dt2 << endl;
    }
}

void sprite::remove(void)
{
  if(pt)
    {
      struct timeval tv, tv2;
      struct timezone tz, tz2;
      int dt;
      double dt2;

      gettimeofday(&tv, &tz);

      if(prev)
	XPutImage(pt->display, pt->window, pt->gc, prev, 0, 0, 
		  x0, y0, width, height);

      gettimeofday(&tv2, &tz2);
      dt = (tv2.tv_sec - tv.tv_sec)*1000000+(tv2.tv_usec-tv.tv_usec);
      dt2=double(dt)/1000000.0;
      //cout << "removecurr:" << dt2 << endl;

      if(prev && prev->data)
	{
	  // memory leak?

	  //XFree(prev->data);
	  //delete [] prev->data;
	  free(prev->data);
	  prev->data=NULL;
	  XFree(prev);
	  prev=NULL;
	}
      
      if(curr && curr->data)
	{
	  //XFree(curr->data);
	  //delete [] curr->data;
	  //curr->data=NULL;
	  free(curr->data);
	  curr->data=NULL;
	  XFree(curr);
	  curr=NULL;
	}

      shown=False;
    }
}


int sprite::get_x0(void)
{
  return x0;
}

int sprite::get_y0(void)
{
  return y0;
}

int sprite::get_width(void)
{
  return width;
}

int sprite::get_height(void)
{
  return height;
}


softfont::softfont(std::istream &in, softfont *previous, const char *name_) :
  double_linked_list((double_linked_list *) previous, NULL)
{
  char line[100]="", *ptr;
  int startbitmap=0, index=0;
  int buffer;

  contents=NULL;
  strcpy(name, name_);
  
  in.getline(line, 99);
  while(!strstr(line, "ENDCHAR") && !in.eof() && !in.fail())
    {
      if((ptr=strstr(line,      "STARTCHAR"))!=NULL)
	sscanf(ptr+10, "%s", name);
      else if((ptr=strstr(line, "ENCODING"))!=NULL)
	sscanf(ptr+9, "%d", &number);
      else if((ptr=strstr(line, "SWIDTH"))!=NULL)
	sscanf(ptr+7, "%d", &buffer);
      else if((ptr=strstr(line, "DWIDTH"))!=NULL)
	sscanf(ptr+7, "%d", &width);
      else if((ptr=strstr(line, "BBX"))!=NULL)
	{
	  sscanf(ptr+4, "%d %d", &width, &height);
	  contents=new char[height];
	}
      else if(strstr(line, "BITMAP"))
	startbitmap=1;
      else if(startbitmap)
	{
	  unsigned int b;
	  sscanf(line, "%x", &b);
	  buffer = b;
	  contents[index]=(char) buffer;
	  index++;
	}
      
      in.getline(line, 99);
    }
}

softfont::~softfont()
{
  if(contents)
    delete [] contents;

  softfont *next=(softfont *) getnext();

  removefromlist();

  if(next)
    delete next;
}

const char *softfont::get_name(void)
{
  return name;
}

int softfont::get_number(void)
{
  return number;
}

int softfont::get_width(void)
{
  return width;
}

int softfont::get_height(void)
{
  return height;
}

const char *softfont::get_contents(void)
{
  return contents;
}

bool softfont::get_bit(int x, int y)
{
  int bit = 1 << (width-1-x);
  
  if(contents[y] & bit)
    return true;
  else
    return false;
}



draw *motion_pt=NULL;

void motionCB(Widget, XEvent *event, String*, Cardinal*)
{
  XButtonEvent *be = (XButtonEvent *) event;

  if(motion_pt)
    motion_pt->handle_motion(be->x, be->y);
}


void draw::handle_motion(int newx, int newy)
{
  if(!point_visited)
    {
      display=XtDisplay(w);
      window=XtWindow(w);
      point_visited=1;
    }

  if(dragging_started)
    draw_motion_object(motion_x0, motion_y0, motion_oldx, motion_oldy);
  dragging_started=True;
  draw_motion_object(motion_x0, motion_y0, newx, newy);

  motion_oldx=newx;
  motion_oldy=newy;
}

void draw::draw_motion_object(int x0, int y0, int x1, int y1)
{
  Rectangle(x0, y0, x1, y1);
}

void draw::motion_dropped(int, int)
{
  
}

void draw::motion_started(int, int)
{
  
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::build(const Widget parent, int width, int height, bool doboxing,
		 const char *postscriptbufferfile) 
{
  XmInitSetArg(XmNwidth, width);
  XmSetArg(XmNheight, height);
  XmSetArg(XmNresizePolicy, XmRESIZE_NONE);
  XmSetArg(XmNbackground, BlackPixelOfScreen(XtScreen(parent)));
  //randify();

  
  do_boxing=doboxing;

  init("draw", xmDrawingAreaWidgetClass, parent);
  
  XtAddCallback(w, XmNexposeCallback, 
		(XtCallbackProc)&draw::exposeCB,
		(XtPointer)this);
  XtAddCallback(w, XmNinputCallback, 
		(XtCallbackProc)&draw::inputCB,
		(XtPointer)this);
  XtAddCallback(w, XmNresizeCallback, 
		(XtCallbackProc)&draw::resizeCB,
		(XtPointer)this);
 
  
  display=XtDisplay(w);
  window=XtWindow(w);

  if(do_boxing)
    {
      String translation="<Btn1Motion>:    motionCB(motion)   "
	"ManagerGadgetButtonMotion() \n"
	"<KeyDown>: DrawingAreaInput() ManagerGadgetKeyInput() \n"
	"<Btn1Down>: DrawingAreaInput() ManagerGadgetArm() \n"
	"<Btn1Up>: DrawingAreaInput() ManagerGadgetArm() \n"
	"<Btn2Up>: DrawingAreaInput() ManagerGadgetArm() \n"
	"<Btn3Up>: DrawingAreaInput() ManagerGadgetArm()";
      
      XtActionsRec actions;
      actions.string="motionCB";
      actions.proc=motionCB;
      XtAppAddActions(mainwin::app, &actions, 1);
      XtVaSetValues(w, XmNtranslations, XtParseTranslationTable(translation), 
		    NULL);
    }

  called = 0;

  if(postscriptbufferfile && *postscriptbufferfile)
    initialize_postscript(postscriptbufferfile, width, height);
  else
    strcpy(psfile, "");

  sizex=(double) width;
  sizey=(double) height;

  background=False;
}

// sends all drawing primitives only to the postscript file;
void draw::do_background(const char *postscriptbufferfile, int width, int height)
{
  background=True;
  initialize_postscript(postscriptbufferfile, width, height);
}

int draw::get_width(void)
{
  return (int) sizex;
}

int draw::get_height(void)
{
  return (int) sizey;
}

void draw::initialize_postscript(const char *postscriptbufferfile, 
				 int width, int height)
{
  DateTime now; now.now();

  sprintf(psfile, "%s", postscriptbufferfile);
  sizex=width;
  sizey=height;
  
  if(sizex>sizey)
    {
      dorot=True;
      
      if(sizex > 1.41*sizey)
	scale = 820.0 / sizex;
      else
	scale = 580 / sizey;
    }
  else
    {
      dorot=False;
      
      if(sizey > 1.41*sizex)
	scale = 820.0 / sizey;
      else
	scale = 580 / sizex;
    }
      
  scale *= 0.96;

  startpostscript();
}

void draw::startpostscript(void)
{
  if(*psfile)
    {
      psout.open(psfile, std::ios::out);
      
      if(!psout.good())
	{
	  std::cerr << "Couldn't open the postscript file \"" << psfile << 
	    "\"!" << std::endl;
	  exit(0);
	}

      psout << "%!PS-Adobe-2.0 EPSF-1.2" << std::endl;
      psout << "%%Title: PostScript file" << std::endl;
      psout << "%%Creator: trr" << std::endl;
#ifdef NVE
      psout << "%%For: " << hydraenvir::system::get_user_name().c_str() << std::endl;
#else
      psout << "%%For: " << getpwuid(getuid())->pw_name << std::endl;
#endif // NVE
      psout << "%%Pages: (atend)" << std::endl;
      if(dorot)
	psout << "%%BoundingBox: 0 0 580 820" << std::endl;
      else
	psout << "%%BoundingBox: 0 0 820 580" << std::endl;
      psout << "%%EndComments" << std::endl;
      psout << std::endl;
      psout << "newpath" << std::endl << std::endl;
      psout << "   " << scale << " " << scale << " scale" << std::endl;
      
      if(dorot)
	{
	  psout << "   90 rotate" << std::endl;
	  psout << "   15 " << -((int) sizey) << " translate" << std::endl;
	}

      psout << "   0.95 0.95 scale" << std::endl;
      
    }
  
  postscript_ended=False;
}  


void draw::endpostscript(void)
{
  if(!postscript_ended)
    {
      psout << std::endl;
      psout << "stroke" << std::endl;
      psout << "showpage" << std::endl;
      psout << std::endl;
      psout << "%%Trailer" << std::endl;
      psout << "%%Pages: 1" << std::endl;

      psout.close();
      
      postscript_ended=True;
    }
}

// rotates and scales the postscript picture
void draw::retouch_postscript(const char *newfile, int newx, int newy,
			      bool removerotation,
			      bool fromscreen)
{
  char bufferfile[1000], *ptr, cmd[2000], line[1000];
  DateTime now;
  std::ifstream in;
  std::ofstream out;
  double newscale;

  if(!*psfile)
    return;

  now.now();
  ptr=now.syCh(2);
  sprintf(bufferfile, "/tmp/rotfile%s.%ld.ps", ptr, random());
  delete [] ptr;

  if(newx>newy)
    {
      // rotation set
      if(newx > 1.41*newy)
	{
	  newscale = ((double) newx) / 820.0;
	  newy = int(sizey/sizex * newx);
	}
      else
	{
	  newscale = ((double) newy) / 580.0;
	  newx = int(sizex/sizey * newy);
	}

      //newscale *= 1000.0/792.0;

      //newx = (int) (820.0 * ((double) newscale));
      //newy=(int) (580.0 * ((double) newscale));
    }
  else
    {
      // no rotation
      if(sizey > 1.41*sizex)
	{
	  newscale = ((double) newy) / 820.0;
	  newx = int(sizex/sizey * newy);
	}
      else
	{
	  newscale = ((double) newx) / 580;
	  newy = int(sizey/sizex * newx);
	}

      //newscale *= 1000.0/792.0;

      //newx = (int) (580.0 * ((double) newscale));
      //newy=(int) (820.0 * ((double) newscale));
    }
      
  if(!fromscreen)
    newscale *= 1.1;
  else
    newscale *= 1.215; // 1.23;

  endpostscript();

  in.open(psfile, std::ios::in);
  if(in.fail())
    {
      std::cerr << "Error opening postscript driver file " << psfile << "!" << std::endl;
      return;
    }

  out.open(bufferfile, std::ios::out);
  if(out.fail())
    {
      std::cerr << "Error opening rotated postscript output file " << 
	bufferfile << "!" << std::endl;
      in.close();
      return;
    }
  
  bool firstscale=True;
  while(!in.eof() && !in.fail())
    {
      in.getline(line, 999);

      if(in.fail())
	break;

      if(strstr(line, "rotate") && removerotation && !strstr(line, "moveto"))
	out << std::endl;
      else if(strstr(line, "translate") && dorot)
	out << std::endl;
      else if(strstr(line, "scale") && !strstr(line, "scalefont") && 
	      firstscale)
	{
	  out << line << std::endl;
	  out << "   " << newscale << " " << newscale << " scale" << std::endl;
	  firstscale=False;
	}
      else if(!strncasecmp(line, "%%BoundingBox: ", 15))
	{
	  if(dorot && !removerotation)
	    out << "%%BoundingBox: 0 0 " << newy << " " << newx << std::endl;
	  else
	    out << "%%BoundingBox: 0 0 " << newx+50 << " " << newy*11/10 << std::endl;
	}
      else 
	out << line << std::endl;
    }

  in.close();
  out.close();

  //sprintf(cmd, "sed \"s/90 rotate/0 %d translate/g\" < %s > %s",
  //  (int) sizey, psfile, bufferfile);
  //system(cmd);
  
  sprintf(cmd, "mv %s %s", bufferfile, newfile);
  system(cmd);
}


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::exposeCB(Widget w, draw *pt, XtPointer) 
{
  //cout << "expose" << std::endl;

  if(!pt->called) 
    {
      XGCValues values;
      XSetWindowAttributes winattset;
      unsigned int winmask;
      winattset.backing_store = Always;
      winattset.bit_gravity = ForgetGravity;
      winmask = CWBackingStore | CWBitGravity;
      XChangeWindowAttributes(XtDisplay(w), XtWindow(w), winmask, 
			      &winattset);
      XFlush(XtDisplay(w));
      
      values.foreground = gpgscolors[CCYAN];
      values.background = gpgscolors[CGREEN];
      values.line_style = LineSolid;
      values.line_width = 3;
      pt->gc = XCreateGC(XtDisplay(w), XtWindow(w), 
			 GCForeground | GCBackground |
			 GCLineWidth | GCLineStyle, 
			 &values);
      if(!pt->display)
	pt->display=XtDisplay(w);
      pt->called = 1;
    }

  XFlush(XtDisplay(w));
  pt->expose();
}


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::inputCB(Widget w, draw *pt, XmDrawingAreaCallbackStruct *p) 
{
  //cout << "input" << std::endl;

  XButtonEvent *be = (XButtonEvent *)p->event;
  XKeyEvent *ke = (XKeyEvent *)p->event;
  
  if(!pt->display)
    pt->display=XtDisplay(w);

  //cout << (int) p->event->type << " : " << (int) be->button << std::endl;
  
  if(pt->do_boxing)
    {
      if (p->event->type == ButtonPress && be->button == 1) 
	{
	  if(pt->black_and_white_inverted())
	    pt->SetFg("black");
	  else
	    pt->SetFg("white");
	  
	  pt->dragging_started=False;
	  pt->motion_started(be->x, be->y);
	  pt->do_xor();
	  motion_pt     = pt;
	  pt->motion_x0 = pt->motion_oldx = be->x;
	  pt->motion_y0 = pt->motion_oldy = be->y;
	}
      else if(p->event->type == ButtonRelease && be->button == 1) 
	{
	  pt->draw_motion_object( pt->motion_x0,    pt->motion_y0,
				  pt->motion_oldx,  pt->motion_oldy );
	  XFlush(pt->display);
	  pt->do_copy();
	  pt->motion_dropped(be->x, be->y);
	  pt->dragging_started=False;
	}
    }

  if (p->event->type == ButtonRelease) 
    {
      switch(be->button) 
	{
	case 1:
	  if(pt->do_boxing && 
	     (pt->motion_oldx!=pt->motion_x0 && 
	      pt->motion_oldy!=pt->motion_y0))
	    pt->Boxed(MINIM(pt->motion_x0, pt->motion_oldx),
		      MINIM(pt->motion_y0, pt->motion_oldy),
		      MAXIM(pt->motion_x0, pt->motion_oldx),
		      MAXIM(pt->motion_y0, pt->motion_oldy));
	  else
	    pt->DoButton1(be->x, be->y);
	  break;
	case 2:
	  pt->DoButton2(be->x, be->y);
	  break;
	case 3:
	  pt->DoButton3(be->x, be->y);
	  break;
	}
    } 
  else if (p->event->type == KeyPress) 
    {
      char buffer[20];
      int bufsize = 20;
      KeySym keysym;
      XComposeStatus compose;
      XLookupString(ke, buffer, bufsize, &keysym, &compose);
      switch(keysym) 
	{
	case XK_Left:                // LEFT ARROW
	  pt->DoLeft();
	  break;
        case XK_Right:               // RIGHT ARROW
	  pt->DoRight();
	  break;
        case XK_Up:               // UP
	  pt->DoUp();
	  break;
        case XK_Down:               // DOWN
	  pt->DoDown();
	  break;
        case XK_Page_Up:
	  pt->DoPageUp();
	  break;
        case XK_Page_Down:
	  pt->DoPageDown();
	  break;
        case XK_Home:
	  pt->DoHome();
	  break;
        case XK_End:
	  pt->DoEnd();
	  break;
        case XK_Insert:
	  pt->DoInsert();
	  break;
        case XK_Delete:
	  pt->DoDelete();
	  break;
        case XK_Escape:
	  pt->DoEscape();
	  break;
        case XK_F1:
	  pt->DoF1();
	  break;
        case XK_F2:
	  pt->DoF2();
	  break;
        case XK_F3:
	  pt->DoF3();
	  break;
        case XK_F4:
	  pt->DoF4();
	  break;
        case XK_F5:
	  pt->DoF5();
	  break;
        case XK_F6:
	  pt->DoF6();
	  break;
        case XK_F7:
	  pt->DoF7();
	  break;
        case XK_F8:
	  pt->DoF8();
	  break;
        case XK_F9:
	  pt->DoF9();
	  break;
        case XK_F10:
	  pt->DoF10();
	  break;
        case XK_F11:
	  pt->DoF11();
	  break;
        case XK_F12:
	  pt->DoF12();
	  break;
        default:
	  printf("%d\n", ke->keycode);
	  return;
        }
    }
}

void draw::do_xor(void)
{
  if(!display)
    display=XtDisplay(w);
  XSetFunction(display, gc, GXxor);
  values.function=GXxor;
  XChangeGC(display, gc, GCFunction, &values);
}

void draw::do_or(void)

{
  if(!display)
    display=XtDisplay(w);
  XSetFunction(display, gc, GXor);
  values.function=GXor;
  XChangeGC(display, gc, GCFunction, &values);
}

void draw::do_copy(void)
{
  if(!display)
    display=XtDisplay(w);
  XSetFunction(display, gc, GXcopy);
  values.function=GXcopy;
  XChangeGC(display, gc, GCFunction, &values);
}


void draw::Clear(const char *color)
{
  if(!background)
    {
      SetFg(color);
      XFillRectangle(XtDisplay(w), XtWindow(w), gc, 
		     0,0,Width()-1, Height()-1);
    }

  if(*psfile)
    {
      if(!postscript_ended)
	endpostscript();
      startpostscript();
    }
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::resizeCB(Widget, draw*, XmDrawingAreaCallbackStruct*) 
{
  //cout << "resize" << std::endl;

  //static XWindowAttributes attr;
  //XGetWindowAttributes(XtDisplay(w), XtWindow(w), &attr);
  //pt->resize(attr.width, attr.height);
}


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::SetFg(GPGSCOLOR col)
{
  if(invert_black_and_white)
    {
      if(col==CBACKGR)
	col=CFOREGR;
      else if(col==CFOREGR)
	col=CBACKGR;
    }

  if(setfg_visited && values.foreground == gpgscolors[col])
    return;
  setfg_visited=1;
  
  values.foreground = gpgscolors[col];  
  XChangeGC(display, gc, GCForeground, &values);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::SetFg(Pixel col)
{
  if(!display)
    display=XtDisplay(w);

  XGCValues values;
  values.foreground = col;
  XChangeGC(display, gc, GCForeground, &values);
}

void draw::SetFg(const char *colour_name)
{
  if(!background)
    {
      char buffer[100];
      strcpy(buffer, colour_name); 

      if(invert_black_and_white)
	{
	  if(!strncasecmp(buffer, "black",5) || 
	     !strncasecmp(buffer, "#000000",7))
	    strcpy(buffer, "white");
	  else if(!strncasecmp(buffer, "white",5) || 
		  !strncasecmp(buffer, "#ffffff",7))
	    strcpy(buffer, "black");
	}

      Pixel p=GetColor(buffer);
      SetFg(p);
    }

  if(*psfile)
    {
      if(!strcmp(colour_name, "black"))
	psout << "   0 0 0 setrgbcolor" << std::endl;
      else if(!strcmp(colour_name, "white"))
	psout << "   1 1 1 setrgbcolor" << std::endl;
      else if(!strcmp(colour_name, "red"))
	psout << "   1 0 0 setrgbcolor" << std::endl;
      else if(!strcmp(colour_name, "green"))
	psout << "   0 1 0 setrgbcolor" << std::endl;
      else if(!strcmp(colour_name, "blue"))
	psout << "   0 0 1 setrgbcolor" << std::endl;
      else if(!strcmp(colour_name, "yellow"))
	psout << "   1 1 0 setrgbcolor" << std::endl;
      else if(!strcmp(colour_name, "purple"))
	psout << "   0 1 1 setrgbcolor" << std::endl;
      else if(colour_name[0]=='#')
	{
	  unsigned int red, green, blue;
	  double r,g,b;
	  
	  sscanf(colour_name+1, "%02x%02x%02x", &red, &green, &blue);
	  r=((double) red)/256.0;
	  g=((double) green)/256.0;
	  b=((double) blue)/256.0;
	  
	  psout << "   " << r << " " << g << " " << b << 
	    " setrgbcolor" << std::endl;
	}
    }
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::SetBg(GPGSCOLOR /*col*/)
{
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
bool draw::SetFont(const char *font)
{
  if(!strcmp(font, oldfont))
    return True;

  strcpy(oldfont, font);

  const char *ptr=font;
  int spacers=0;
      
  while(spacers<7 && *ptr!='\0')
    {
      if(*ptr=='-')
	spacers++;
      ptr++;
    }

  if(*ptr && sscanf(ptr, "%d", &fontsize))
    {
      if(*psfile && fontsize>0)
	{
	  psout << "   /Helvetica findfont" << std::endl;
	  psout << "   " << fontsize << " scalefont setfont" << std::endl;
	}
    }


  if(!background)
    {
      if(!display)
	display=XtDisplay(w);
      
      XGCValues values;
      if((theFont = XLoadQueryFont(display, font)) != NULL) 
	{
	  values.font = theFont->fid;
	  XChangeGC(display, gc, GCFont, &values);
	}
      else 
	return load_softfonts();
    }
  
  
  return True;
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::SetLineWidth(int width)
{
  if(!background)
    {
      if(!display)
	display=XtDisplay(w);
      
      XGCValues values;
      values.line_width = width;
      XChangeGC(display, gc, GCLineWidth, &values);
    }

  if(*psfile)
    psout << "   " << ((double) width)/2.0 << " setlinewidht" << std::endl;
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::Line(double x0, double y0, double x1, double y1)
{
  if(!background)
    {
      if(!point_visited)
	{
	  display=XtDisplay(w);
	  window=XtWindow(w);
	  point_visited=1;
	}

      XDrawLine(display, window, gc, (int) x0, (int) y0, (int) x1, (int) y1);
    }

  if(*psfile)
    {
      psout << "   " << x0+2 << " " << sizey-y0+2 << " moveto" << std::endl;
      psout << "   " << x1+2 << " " << sizey-y1+2 << " lineto" << std::endl;

      psout << "stroke" << std::endl << std::endl;
    }
}

void draw::circle(double x0, double y0, double r, bool filled,
		  double startarc, double numarc)
{
  if(!(startarc>-360.0 && startarc<+720.0))
    return;
  if(!(numarc>-360.0 && numarc<+720.0))
    return;

  double start_arc=startarc, num_arc=numarc;
  if(numarc<0.0)
    {
      start_arc=startarc+numarc;
      num_arc=-numarc;
    }    
  while(start_arc<0.0)
    start_arc+=360.0;
  while(start_arc>360.0)
    start_arc-=360.0;
  
  if(!background)
    {
      if(!point_visited)
	{
	  display=XtDisplay(w);
	  window=XtWindow(w);
	  point_visited=1;
	}

      if(!filled)
	XDrawArc(display, window, gc, (int) (x0-r), (int) (y0-r), 
		 (int) (2.0*r), (int) (2.0*r),
		 (int) (start_arc*64.0), (int) (num_arc*64.0));
      else
	XFillArc(display, window, gc, (int) (x0-r), (int) (y0-r), 
		 (int) (2.0*r), (int) (2.0*r),
		 (int) (start_arc*64.0), (int) (num_arc*64.0));
    }
  
  if(*psfile)
    {
      double arc1=start_arc, arc2;

      while(arc1<0.0)
	arc1+=360.0;
      arc2 = arc1 + num_arc;

      if(filled)
	{
	  double x1=x0+r*cos(2.0*M_PI*arc2/360.0);
	  double y1=y0-r*sin(2.0*M_PI*arc2/360.0);
	  double x2=x0+r*cos(2.0*M_PI*arc1/360.0);
	  double y2=y0-r*sin(2.0*M_PI*arc1/360.0);

	  psout << "   " << x1+2 << " " << sizey-y1+2 << " moveto" << std::endl;
	  psout << "   " << x0+2 << " " << sizey-y0+2 << " lineto" << std::endl;
	  psout << "   " << x2+2 << " " << sizey-y2+2 << " lineto" << std::endl;
	}

      psout << "   " << x0+2 << " " << sizey-y0+2 << " " <<
	r << " " << arc1 << " " << arc2 << " arc" << std::endl;      

      if(filled)
	psout << "   fill" << std::endl;
      else
	psout << "stroke" << std::endl << std::endl;
    }

}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::Rectangle(double x0, double y0, double x1, double y1,
		     bool filled)
{
  if(y1==y0 || x1==x0)
    {
      Line(x0,y0,x1,y1);
      return;
    }

  if(!background)
    {
      if(!point_visited)
	{
	  display=XtDisplay(w);
	  window=XtWindow(w);
	  point_visited=1;
	}
      
      if(!filled)
	XDrawRectangle(XtDisplay(w), XtWindow(w), gc, 
		       (int) MINIM(x0, x1),   (int) MINIM(y0, y1),
		       (int) ABSVAL((x0 - x1)), (int) ABSVAL((y0 - y1)));
      else
	XFillRectangle(XtDisplay(w), XtWindow(w), gc, 
		       (int) MINIM(x0, x1),   (int) MINIM(y0, y1),
		       (int) ABSVAL((x0 - x1)), (int) ABSVAL((y0 - y1)));

    }

  if(*psfile)
    {
      int dy = (int) sizey;

      psout << "newpath" << std::endl;
      psout << "   " << MINIM(x0,x1)+1 << " " << dy-MINIM(y0,y1)+2 << 
	" moveto" << std::endl;
      psout << "   " << MINIM(x0,x1)+1 << " " << dy-MAXIM(y0,y1)+2 <<
	" lineto" << std::endl;
      psout << "   " << MAXIM(x0,x1)+1 << " " << dy-MAXIM(y0,y1)+2 <<
	" lineto" << std::endl;
      psout << "   " << MAXIM(x0,x1)+1 << " " << dy-MINIM(y0,y1)+2 <<
	" lineto" << std::endl;
      psout << "   " << MINIM(x0,x1)+1 << " " << dy-MINIM(y0,y1)+2 <<
	" lineto" << std::endl;
      psout << "   closepath" << std::endl;
      if(filled)
	psout << "   fill" << std::endl;
      psout << "stroke" << std::endl << std::endl;
    }
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::Lines(double *xvalues, double *yvalues, int arraylength,
		 double x0, double y0)
{
  if(!background)
    {
      if(!point_visited)
	{
	  display=XtDisplay(w);
	  window=XtWindow(w);
	  point_visited=1;
	}
      
      XPoint *points=new XPoint[arraylength];
      for(register int i=0;i<arraylength;i++)
	{
	  points[i].x = (int) (xvalues[i]+x0);
	  points[i].y = (int) (yvalues[i]+y0);
	}
      
      XDrawLines(display, window, gc, points, arraylength, CoordModeOrigin);
      delete [] points;
    }

  if(*psfile)
    {
      psout << "   " << xvalues[0]+x0+2 << " " << sizey-yvalues[0]-y0+2 << 
	" moveto" << std::endl;

      for(register int i=1;i<arraylength;i++)
	psout << "   " << xvalues[i]+x0+1 << " " << sizey-yvalues[i]-y0+2 << 
	  " lineto" << std::endl;

      psout << "stroke" << std::endl << std::endl;
    }
}


// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : for use when plotting along a x-axis;
// ######################################################################
void draw::plotlines(double *xvalues, double *yvalues, int arraylength)
{
  int x0 = (int) xvalues[0], x1 = (int) xvalues[arraylength-1];
  int xlen = x1-x0+1;

  if(arraylength<xlen*2)
    {
      Lines(xvalues, yvalues, arraylength);
      return;
    }
	
  if(!background)
    {
      int *miny=new int[xlen], *maxy=new int[xlen], len=0;
      int *starty=new int[xlen], *endy=new int[xlen];
      register int i;

      for(i=0;i<xlen;i++)
	{
	  miny[i] = (int) MISSING_VALUE;
	  maxy[i] = (int) MISSING_VALUE;
	  starty[i] = (int) MISSING_VALUE;
	  endy[i] = (int) MISSING_VALUE;
	}

      for(i=0;i<arraylength;i++)
	{
	  int x = (int) xvalues[i] - x0;
	  if(starty[x]==MISSING_VALUE && yvalues[i]!=MISSING_VALUE)
	    starty[x]=(int)yvalues[i];
	}

      for(i=arraylength-1;i>=0;i--)
	{
	  int x = (int) xvalues[i] - x0;
	  if(endy[x]==MISSING_VALUE && yvalues[i]!=MISSING_VALUE)
	    endy[x]=(int)yvalues[i];
	}

      for(i=0;i<arraylength;i++)
	if(yvalues[i]!=MISSING_VALUE)
	  {
	    int x = (int) xvalues[i] - x0;
	    if(miny[x]==MISSING_VALUE || miny[x]>yvalues[i])
	      miny[x] = (int) yvalues[i];
	    if(maxy[x]==MISSING_VALUE || maxy[x]<yvalues[i])
	      maxy[x] = (int) yvalues[i];
	  }

      if(!point_visited)
	{
	  display=XtDisplay(w);
	  window=XtWindow(w);
	  point_visited=1;
	}
      
      XPoint *points=new XPoint[xlen*4];
      for(i=0;i<xlen;i++)
	{
	  if(starty[i]!=MISSING_VALUE)
	    {
	      points[len].x = i + x0;
	      points[len].y = starty[i];
	      len++;
	    }

	  if(miny[i]!=MISSING_VALUE)
	    {
	      points[len].x = i + x0;
	      points[len].y = miny[i];
	      len++;
	    }

	  if(maxy[i]!=MISSING_VALUE && maxy[i]!=miny[i])
	    {
	      points[len].x = i + x0;
	      points[len].y = maxy[i];
	      len++;
	    }

	  if(endy[i]!=MISSING_VALUE)
	    {
	      points[len].x = i + x0;
	      points[len].y = endy[i];
	      len++;
	    }
	}
      
      XDrawLines(display, window, gc, points, len, CoordModeOrigin);
      delete [] points;
      delete [] miny;
      delete [] maxy;
    }

  if(*psfile)
    {
      xlen *= 10;

      if(arraylength<xlen*2)
	{
	  psout << "   " << xvalues[0]+2 << " " << sizey-yvalues[0]+2 << 
	    " moveto" << std::endl;
	  for(register int i=1;i<arraylength;i++)
	    psout << "   " << xvalues[i]+1 << " " << sizey-yvalues[i]+2 << 
	      " lineto" << std::endl;
	  psout << "stroke" << std::endl << std::endl;
	}
      else
	{
	  int *miny=new int[xlen], *maxy=new int[xlen], len=0;
	  int *starty=new int[xlen], *endy=new int[xlen];
	  register int i;
	  
	  for(i=0;i<xlen;i++)
	    {
	      miny[i] = (int) MISSING_VALUE;
	      maxy[i] = (int) MISSING_VALUE;
	      starty[i] = (int) MISSING_VALUE;
	      endy[i] = (int) MISSING_VALUE;
	    }

	  for(i=0;i<arraylength;i++)
	    {
	      //int x = (int) xvalues[i] - x0;
	      int x = int(10.0*(xvalues[i] - x0));
	      if(starty[x]==MISSING_VALUE && yvalues[i]!=MISSING_VALUE)
		starty[x]=(int)yvalues[i];

	      if(x<0 || x>=xlen)
		std::cout << "Index out of range 1, i=" << i << std::endl;
	    }

	  for(i=arraylength-1;i>=0;i--)
	    {
	      //int x = (int) xvalues[i] - x0;
	      int x = int(10.0*(xvalues[i] - x0));
	      if(endy[x]==MISSING_VALUE && yvalues[i]!=MISSING_VALUE)
		endy[x]=(int)yvalues[i];

	      if(x<0 || x>=xlen)
		std::cout << "Index out of range 2, i=" << i << std::endl;
	    }

	  for(i=0;i<arraylength;i++)
	    {
	      int x = int(10.0*(xvalues[i] - x0));
	      if(miny[x]==MISSING_VALUE || miny[x]>yvalues[i])
		miny[x] = (int) yvalues[i];
	      if(maxy[x]==MISSING_VALUE || maxy[x]<yvalues[i])
		maxy[x] = (int) yvalues[i];

	      if(x<0 || x>=xlen)
		std::cout << "Index out of range 3, i=" << i << std::endl;
	    }

	  XPoint *points=new XPoint[xlen*4];
	  for(i=0;i<xlen;i++)
	    {
	      if(starty[i]!=MISSING_VALUE)
		{
		  points[len].x = (short int)(x0 + ((double) i)/10.0);
		  points[len].y = starty[i];
		  len++;
		}

	      if(miny[i]!=MISSING_VALUE)
		{
		  points[len].x = (short int)(x0 + ((double) i)/10.0);
		  points[len].y = miny[i];
		  len++;
		}
	      
	      if(maxy[i]!=MISSING_VALUE && maxy[i]!=miny[i])
		{
		  points[len].x = (short int)(x0 + ((double) i)/10.0);
		  points[len].y = maxy[i];
		  len++;
		}
	      
	      if(endy[i]!=MISSING_VALUE)
		{
		  points[len].x = (short int)(x0 + ((double) i)/10.0);
		  points[len].y = endy[i];
		  len++;
		}
	    }
	  
	  psout << "   " << points[0].x+2 << " " << sizey-points[0].y+2 << 
	    " moveto" << std::endl;
	  
	  for(i=1;i<len;i++)
	    psout << "   " << points[i].x+1 << " " << sizey-points[i].y+2 << 
	      " lineto" << std::endl;
	  
	  psout << "stroke" << std::endl << std::endl;

	  delete [] points;
	  delete [] miny;
	  delete [] maxy;
	}
    }
}



void draw::Set_No_Dashes(int linewidth)
{
  if(!background)
    {
      if(!display)
	{
	  display=XtDisplay(w);
	  window=XtWindow(w);
	}
      
      XSetLineAttributes(display, gc, linewidth, 
			 LineSolid, CapButt, JoinRound);
    }

  if(*psfile)
    {
      psout << "stroke" << std::endl << std::endl;
      psout << "   [ 1 0 ] 0 setdash" << std::endl; 
      psout << "   " << ((double) linewidth/2.0) << " setlinewidth" << std::endl;
      psout << std::endl;
    }
}

void draw::Set_Dashes(const char *dashlist, int length, int linewidth)
{
  if(!background)
    {
      if(!display)
	{
	  display=XtDisplay(w);
	  window=XtWindow(w);
	}
      
      XSetLineAttributes(display, gc, linewidth==1 ? 0 : linewidth, 
			 LineOnOffDash, CapButt, JoinRound);

      XSetDashes(display, gc, 0, dashlist, length);
    }

  if(*psfile)
    {
      psout << "stroke" << std::endl << std::endl;
      psout << "   [ ";
      for(int i=0;i<length;i++)
	psout << (int) dashlist[i] << " ";
      psout << " ] 0 setdash" << std::endl;
      psout << "   " << ((double) linewidth/2.0) << " setlinewidth" << std::endl;
      psout << std::endl;
    }
}

void draw::Point(int x,int y, DRAW_POINT_TYPE type)
{ 
  static int oldx=-1, oldy=-1;
  static DRAW_POINT_TYPE oldtype;

  if(x==oldx && y==oldy && type==oldtype)
    return;

  oldx=x;
  oldy=y;
  oldtype=type;

  if(!background && !point_visited)
    {
      display=XtDisplay(w);
      window=XtWindow(w);
      point_visited=1;
    }

  double x0=(double) x , y0=(double) y;

  switch(type)
    {
    case DRAW_POINT_CIRCLECROSS:
      Line(x0, y0-2.0, x0, y0+2.0);
      Line(x0-2.0, y0, x0+2.0, y0);
    case DRAW_POINT_CIRCLE: 
      {
	static double xx[12], yy[12], pi=3.141592653589793;
	static int visited=0;
	double i;

	if(!visited)
	  for(i=0.0; i<12.0; i+=1.0)
	    {
	      xx[(int) i] = 3.0*cos(2.0*pi*i/11.0);
	      yy[(int) i] = 3.0*sin(2.0*pi*i/11.0);
	    }

	visited=1;

	Lines(xx,yy,12,x0,y0);

	break;
      }
    case DRAW_POINT_TRIANGLE: 
      Line(x0, y0-3.0, x0+3.0, y0+3.0);
      Line(x0, y0-3.0, x0-3.0, y0+3.0);
      Line(x0-3.0, y0+3.0, x0+3.0, y0+3.0);
      break;
    case DRAW_POINT_CROSS: 
      Line(x0, y0-3.0, x0, y0+3.0);
      Line(x0-3.0, y0, x0+3.0, y0);
      break;
    case DRAW_POINT_X: 
      Line(x0-3.0, y0-3.0, x0+3.0, y0+3.0);
      Line(x0-3.0, y0+3.0, x0+3.0, y0-3.0);
      break;
    case DRAW_POINT_SQUARE:
      Line(x0-3.0, y0-3.0, x0-3.0, y0+3.0);
      Line(x0-3.0, y0+3.0, x0+3.0, y0+3.0);
      Line(x0+3.0, y0+3.0, x0+3.0, y0-3.0);
      Line(x0+3.0, y0-3.0, x0-3.0, y0-3.0);
      break;
    case DRAW_POINT_CLUB: 
      Line(x0, y0-3.0, x0+3.0, y0);
      Line(x0+3.0, y0, x0, y0+3.0);
      Line(x0, y0+3.0, x0-3.0, y0);
      Line(x0-3.0, y0, x0, y0-3.0);
      break;
    case DRAW_POINT_STAR: 
      Line(x0-3.0, y0-3.0, x0+3.0, y0+3.0);
      Line(x0-3.0, y0+3.0, x0+3.0, y0-3.0);
      Line(x0, y0-3.0, x0, y0+3.0);
      Line(x0-3.0, y0, x0+3.0, y0);
      break;
    case DRAW_POINT_SQUAREX: 
      Line(x0-3.0, y0-3.0, x0+3.0, y0+3.0);
      Line(x0-3.0, y0+3.0, x0+3.0, y0-3.0);
      Line(x0-3.0, y0-3.0, x0-3.0, y0+3.0);
      Line(x0-3.0, y0+3.0, x0+3.0, y0+3.0);
      Line(x0+3.0, y0+3.0, x0+3.0, y0-3.0);
      Line(x0+3.0, y0-3.0, x0-3.0, y0-3.0);
      break;
    case DRAW_POINT_PIXEL:
      XDrawPoint(display, window, gc, x, y);

      if(*psfile)
	{
	  psout << "newpath" << std::endl;
	  psout << "   " << x0+2.0 << " " << sizey-y0+2.0 << 
	    " moveto" << std::endl;
	  psout << "   " << x0+2.0 << " " << sizey-y0+0.001 <<
	    " lineto" << std::endl;
	  psout << "   " << x0+3.999 << " " << sizey-y0+0.001 <<
	    " lineto" << std::endl;
	  psout << "   " << x0+3.999 << " " <<sizey -y0+2.0 <<
	    " lineto" << std::endl;
	  psout << "   " << x0+2.0 << " " << sizey-y0+2.0 <<
	    " lineto" << std::endl;
	  psout << "   closepath" << std::endl;
	  psout << "   fill" << std::endl;
	  psout << "stroke" << std::endl << std::endl;
	}

      break;
    }
}



// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################

#define PSFONTRESIZE 3.375
void draw::Text(const char *str, int x, int y)
{
  if(theFont==NULL)
    {
      soft_text(str, x, y, 0.0, 0);
      return;
    }

  //int wi, h;
  int l = strlen(str);
  int x0=x;
  int y0=y;

  if(!background)
    {
      //GetFontGeom(wi, h);
      
      if(!display)
	display=XtDisplay(w);

      if(!window)
	window=XtWindow(w);

      XDrawString(display, window, gc, x0, y0, str, l);
    }

  if(*psfile)
    postscript_text(str, x, y, 0.0);
}

// SOFT_TEXT
// Shows softfont text on the screen
// str - the given text
// x,y - the starting corrdinate
// angle - the roation agnle in degrees
// The font size should have been set by SetFont, but can
// alsa be set by using 'font_size'.
void draw::soft_text(const char *str, int x, int y, double angle, int font_size)
{
  if(font_size != MISSING_VALUE && font_size>0)
    fontsize=font_size;

  if(!background)
    {
      if(!softhead)
	{
	  err.build(mainwin::toplevel, 
		    (char *) (WHAT("Program-feil", "Program error")),
		    (char *) (WHAT("Karaktersett er ikke innlastet!",
				   "Soft font set is not loaded!")));
	  return;
	}
      
      int i, xx, yy, gridlen=fontsize*2*2*strlen(str), rep;
      int **grid=new int*[gridlen];
      
      for(xx=0;xx<gridlen;xx++)
	{
	  grid[xx]=new int[gridlen];
	  for(yy=0;yy<gridlen;yy++)
	    grid[xx][yy]=0;
	}
      
      for(i=0;i<(int)strlen(str);i++)
	{
	  softfont *active=findsoftfont(str[i]);
	  int fw=active->get_width(), fh=active->get_height();
	  
	  rep=fontsize*4/fh;
	  
	  for(xx=0; xx<fw*rep;xx++)
	    for(yy=0; yy<fh*rep;yy++)
	      if(active->get_bit(xx/rep, yy/rep))
		{
		  int x0=(i*(fw+2)*rep+xx)*fontsize;
		  int y0=fontsize*yy;
		  double x1 = ((double) x0)/((double) rep*fh);
		  double y1 = ((double) y0)/((double) rep*fh);
		  double g2 = ((double) gridlen)/2.0;
		  
		  double xf=g2 + x1*cos(2*M_PI*angle/360.0) +
		    y1*sin(2*M_PI*angle/360.0);
		  double yf=g2 - x1*sin(2*M_PI*angle/360.0) +
		    y1*cos(2*M_PI*angle/360.0);
		  
		  int x2=(int) xf;
		  int y2=(int) yf;

		  if(x2>=0 && x2<gridlen && y2>=0 && y2<gridlen)
		    grid[x2][y2]++;
		}
	}
	    

      int **grid2=new int*[gridlen];
      for(xx=0;xx<gridlen;xx++)
	{
	  grid2[xx]=new int[gridlen];
	  
	  for(yy=0;yy<gridlen;yy++)
	    {
	      if(grid[xx][yy]<2)
		{
		  grid2[xx][yy]=0;
		  continue;
		}
	      
	      int x1 = MAXIM(0, xx-1), x2 = MINIM(gridlen-1, xx+1);
	      int y1 = MAXIM(0, yy-1), y2 = MINIM(gridlen-1, yy+1);
	      
	      int diff = MAXIM(MAXIM(ABSVAL((grid[xx][yy]-grid[xx][y1])),
				     ABSVAL((grid[xx][yy]-grid[xx][y2]))),
			       MAXIM(ABSVAL((grid[xx][yy]-grid[x1][yy])),
				     ABSVAL((grid[xx][yy]-grid[x2][yy]))));
	      
	      if( grid[xx][yy] > diff/2 )
		grid2[xx][yy]=1;
	      else
		grid2[xx][yy]=0;
	      
	    }
	}

      for(xx=0;xx<gridlen;xx++)
	for(yy=0;yy<gridlen;yy++)
	  if(grid2[xx][yy])
	    XDrawPoint(display, window, gc, x+xx-gridlen/2-15, y+yy-gridlen/2);
      
      doubledelete(grid,gridlen);
      doubledelete(grid2,gridlen);
    }

  if(*psfile)
    postscript_text(str, x, y, angle);
}

void draw::findcontext(void)
{
  if(!display)
    display=XtDisplay(w);
  if(!window)
    window=XtWindow(w);
}  

softfont *draw::findsoftfont(char c)
{
  int pos=(int) c;
  if(pos<0)
    pos=256+pos;
  
  if(c=='�')
    pos=145;
  else if(c=='�')
    pos=146;
  else if(c=='�')
    pos=237;
  else if(c=='�')
    pos=48;
  else if(c=='�')
    pos=134;
  else if(c=='�')
    pos=143;
  else if(c=='�')
    pos=217;
  else if(c=='�')
    pos=253;
  else if(c=='�')
    pos=248;
  else if(c=='�')
    pos=230;

  if(!softhead || softhead->number_of_elements()<pos || pos<0)
    return NULL;

  softfont *active=(softfont *) softhead->get_rel_next(pos);
  
  return active;
}

// POSTSCRIPT_TEXT
// Writes to postscript file
// str - the given text
// x,y - the starting corrdinate
// angle - the roation agnle in degrees
void draw::postscript_text(const char *str, int x, int y, double angle)
{
  fontsize++;
  
  char strbuffer[1000], *ptr;
  double fsize=((double) fontsize);
  
  if(fsize==0)
    {
      fontsize--;
      return;
    }
  
  psout << "   " << x+2  << " " << sizey-y+2  <<  
    " moveto";
  psout << "   " << angle << " rotate" << std::endl;
  
  psout << "   /Helvetica-Bold findfont" << std::endl;
  psout << "   " << fontsize << " scalefont setfont" << std::endl;
  
  strcpy(strbuffer, str);
  for(ptr=strbuffer; ptr < strbuffer+strlen(strbuffer); ptr++)
    {
      if(*ptr=='�')
	{
	  psout << "   0 " << fsize/3.0 << " rmoveto" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << MAXIM(fontsize/2, 8) << 
	    " scalefont setfont" << std::endl;
	  psout << "   (3) show" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << fontsize << " scalefont setfont" << std::endl;
	  psout << "   0 " << -fsize/3.0 << " rmoveto" << std::endl;
	  
	  continue;
	}
      
      if(*ptr=='�')
	{
	  psout << "   0 " << fsize/3.0 << " rmoveto" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << MAXIM(fontsize/2, 8) << 
	    " scalefont setfont" << std::endl;
	  psout << "   (2) show" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << fontsize << " scalefont setfont" << std::endl;
	  psout << "   0 " << -fsize/3.0 << " rmoveto" << std::endl;
	  
	  continue;
	}
      
      if(*ptr=='�')
	{
	  psout << "   0 " << fsize/3.0 << " rmoveto" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << MAXIM(fontsize/2, 8) << 
	    " scalefont setfont" << std::endl;
	  psout << "   (o) show" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << fontsize << " scalefont setfont" << std::endl;
	  psout << "   0 " << -fsize/3.0 << " rmoveto" << std::endl;
	  
	  continue;
	}

      
      if(*ptr=='�')
	{
	  psout << "   (a) show" << std::endl;
	  psout << "   " << -fsize/2.2 << " " << fsize/1.5 << 
	    " rmoveto" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << MAXIM(fontsize/2, 8) << 
	    " scalefont setfont" << std::endl;
	  psout << "   (o) show" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << fontsize << " scalefont setfont" << std::endl;
	  psout << "   " << fsize/6.0 << " " << -fsize/1.5 << 
	    " rmoveto" << std::endl;
	  
	  continue;
	}

      if(*ptr=='�')
	{
	  psout << "   (A) show" << std::endl;
	  psout << "   " << -fsize/2.0 << " " << fsize*2.5/3.0 << 
	    " rmoveto" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << MAXIM(fontsize/2, 8) << 
	    " scalefont setfont" << std::endl;
	  psout << "   (o) show" << std::endl;
	  psout << "   /Helvetica-Bold findfont" << std::endl;
	  psout << "   " << fontsize << " scalefont setfont" << std::endl;
	  psout << "   " << fsize/10.0 << " " << -fsize*2.5/3.0 << 
	    " rmoveto" << std::endl;
	  
	  continue;
	}

      if(*ptr=='�')
	*ptr = (char) 241;
      else if(*ptr=='�')
	*ptr = (char) 225;
      else if(*ptr=='�')
	*ptr = (char) 249;
      else if(*ptr=='�')
	*ptr = (char) 233;
      
      if(*ptr ==')')
	{
	  psout << "   (\\)) show" << std::endl;
	}
      else if(*ptr =='(')
	{
	  psout << "   (\\() show" << std::endl;
	}
      else
	psout << "   (" << *ptr << ") show" << std::endl;
      //psout << "   " << fontsize/4 << " 0 rmoveto" << std::endl;
    }

  psout << "   0 0 moveto   " << -angle << " rotate" << std::endl;

  fontsize--;
}


bool draw::load_softfonts(const char *fontfile, bool doerr)
{
  std::ifstream in;
  char name[10], line[100], *ptr=NULL, font_file[1000];;

  if(fontfile)
    strcpy(font_file, fontfile);
#ifdef NVE
  else
    sprintf(font_file, "%spc8x16s.bdf", "/usr/local/hydra3/etc/fonts/");
#else
#ifdef LIBDIR
  else
    sprintf(font_file, "%spc8x16s.bdf", LIBDIR);
#else
#ifdef FONTS_DIR
  else
    sprintf(font_file, "%spc8x16s.bdf", FONTS_DIR);
#endif // FONTS_DIR
#endif // LIBDIR
#endif // NVE

  if(!strcmp(font_file, oldsoftfont) || font_file[0]=='\0')
    return oldsoftstatus;

  strcpy(oldsoftfont, font_file);

  in.open(font_file, std::ios::in);
  if(in.fail())
    {
      char errstr[100];
      sprintf(errstr, (char *) (WHAT("Klarte ikke � �pne fontfilen \"%s\"!",
				     "Couldn't open the font file \"%s\"!")), 
	font_file);

      if(doerr)
	err.build(mainwin::toplevel, 
		  (char *) (WHAT("Program-feil", "Program error")), errstr);
      oldsoftstatus=False;
      return False;
    }

  softhead=softtail=NULL;

  in.getline(line, 99);
  while(!in.fail() && !(ptr=strstr(line, "STARTCHAR")))
    in.getline(line, 99);

  if(!ptr || in.fail())
    {
      char errstr[100];
      sprintf(errstr, 
	      (char *) (WHAT("Klarte ikke � lese fontfilen \"%s\"!",
			     "Couldn't read the font file \"%s\"!")), 
	      font_file);

      if(doerr)
	err.build(mainwin::toplevel, 
		  (char *) (WHAT("Program-feil", "Program error")), errstr);
      oldsoftstatus=False;
      return False;
    }

  sscanf(ptr+10, "%s", name);
  softhead=softtail=new softfont(in, NULL, name);
  
  in.getline(line, 99);
  while(!in.fail())
    {
      if((ptr=strstr(line, "STARTCHAR"))!=NULL)
	{
	  sscanf(ptr+10, "%s", name);
	  softtail=new softfont(in, softtail, name);
	}

      in.getline(line, 99);
    }

  if(!softhead)
    {
      oldsoftstatus=False;
      return False;
    }
  else
    {
      oldsoftstatus=True;
      return True;
    }
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::GetGeom(unsigned int &width, unsigned int &height)
{
  Window root;
  int x, y;
  unsigned int bwidth, depth;
  XGetGeometry(XtDisplay(w), XtWindow(w), &root, &x, &y, &width, &height,
	       &bwidth, &depth);
}

bool draw::black_and_white_inverted(void)
{
  return invert_black_and_white;
}

void draw::do_invert_black_and_white(void)
{
  invert_black_and_white = !invert_black_and_white;
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void draw::GetFontGeom(int &width, int &height)
{
  if(theFont!=NULL)
    {
      width = XTextWidth(theFont, "a", 1);
      height = theFont->ascent + theFont->descent;
    }
  else
    {
      width=0;
      height=0;
    }
}

draw::draw() : widget()
{
  softhead=softtail=NULL;
  point_visited=0;
  setfg_visited=0;
  display=NULL;
  postscript_ended=True;
  fontsize=0;
  background=False;
  invert_black_and_white=False;
  strcpy(oldfont, "none");
  strcpy(oldsoftfont, "none");
  theFont=NULL;
}

draw::~draw()
{
  if(!postscript_ended && !psout.fail())
    endpostscript();
  if(softhead)
    delete softhead;
}

// Show a colored sprite. Requires 24-bit color
void draw::show_sprite(rgb **array, int width_, int height_, 
		       int startx, int starty, rgb rgbbackground,
		       bool do_posrtscript)
{
  int x,y;
  int dy = (int) sizey;

  if(!display)
    display=XtDisplay(w);
  if(!window)
    window=XtWindow(w);

  XImage *xi=XGetImage(display, window, 
		       startx, starty, width_, height_, AllPlanes, ZPixmap);;
  xi->format=2;
  xi->width=width_;
  xi->height=height_;
  xi->bitmap_pad=32;
  xi->byte_order=xi->bitmap_bit_order=1;
  xi->obdata=NULL; 
  xi->bytes_per_line=4*width_;
  xi->bitmap_unit=8;
  xi->bits_per_pixel=32;
  xi->red_mask=255;
  xi->green_mask=65280;
  xi->blue_mask=16711680;
    
  for(x=0;x<width_;x++)
    for(y=0;y<height_;y++)
      if( array[x][y].red!=rgbbackground.red || 
	  array[x][y].green!=rgbbackground.green || 
	  array[x][y].blue!=rgbbackground.blue ) 
	{
	  xi->data[4*(y*width_+x)] = 0;
	  xi->data[4*(y*width_+x)+1] = array[x][y].red;
	  xi->data[4*(y*width_+x)+2] = array[x][y].green;
	  xi->data[4*(y*width_+x)+3] = array[x][y].blue;
	}
      else
	{
	  /*char buffer=xi->data[4*(y*width_+x)+2];
	  xi->data[4*(y*width_+x)+3] = xi->data[4*(y*width_+x)];
	  xi->data[4*(y*width_+x)+2] = xi->data[4*(y*width_+x)+1];
	  xi->data[4*(y*width_+x)+1] = buffer;
	  xi->data[4*(y*width_+x)] = 0;*/
	}

  if(*psfile && do_posrtscript)
    {
      bool bgbuffer=background;
      background=True;
      
      psout << "   " << 0.01 << " setlinewidth" << std::endl;
      for(x=0;x<width_;x++)
	for(y=0;y<height_;y++)
	  {
	    int red=int((unsigned char) xi->data[4*(y*width_+x)+1]), 
	      green=int((unsigned char) xi->data[4*(y*width_+x)+2]), 
	      blue=int((unsigned char) xi->data[4*(y*width_+x)+3]);
	    double r,g,b;
	    int x0=x+startx, y0=y+starty;
	    int x1=x+startx+1, y1=y+starty+1;

	    r=((double) red)/256.0;
	    g=((double) green)/256.0;
	    b=((double) blue)/256.0;
	  
	    psout << "   " << r << " " << g << " " << b << 
	      " setrgbcolor" << std::endl;
	    psout << "newpath" << std::endl;
	    psout << "   " << MINIM(x0,x1)+1 << " " << dy-MINIM(y0,y1)+2 << 
	      " moveto" << std::endl;
	    psout << "   " << MINIM(x0,x1)+1 << " " << dy-MAXIM(y0,y1)+2 <<
	      " lineto" << std::endl;
	    psout << "   " << MAXIM(x0,x1)+1 << " " << dy-MAXIM(y0,y1)+2 <<
	      " lineto" << std::endl;
	    psout << "   " << MAXIM(x0,x1)+1 << " " << dy-MINIM(y0,y1)+2 <<
	      " lineto" << std::endl;
	    psout << "   " << MINIM(x0,x1)+1 << " " << dy-MINIM(y0,y1)+2 <<
	      " lineto" << std::endl;
	    psout << "   closepath" << std::endl;
	    psout << "   fill" << std::endl;
	    psout << "stroke" << std::endl << std::endl;
	  }
      
      background=bgbuffer;
    }

  XPutImage(display, window, gc, xi, 0, 0, startx, starty, width_, height_);
  XFree(xi->data);
}



hypertext::hypertext()
{
  exposed=False;
}

void hypertext::DoButton1(int, int)
{
  pushed();
}

void hypertext::Build(widget parent, const char *txt)
{
  width = 7*strlen(txt);
  height=15;

  strcpy(textbuffer, txt);
  build(parent, width+12, height+12);
}


void hypertext::expose(void)
{
  if(!SetFont("-*-helvetica-*-r-*-*-12-*-*-*-*-*-*-*"))
    return;

  standard_colours();
  SetFg("blue");

  if(!exposed)
    {
      totwidth=Width();
      totheight=Height();
    }
  else
    {
      Width(totwidth);
      Height(totheight);
    }

  Text(textbuffer, 5, 10);
  Line(2, height+1, width, height+1);

  exposed=True;
}



void hypertext_explanation_button::Create(widget parent, const char *txt, 
					  hypertext_explanation *ipt,
					  HYPERTEXT_ACTION action)
{
  pt=ipt;
  type=action;
  build(parent,txt);
}

void hypertext_explanation_button::pushed(void)
{
  pt->take_action(type);
}

hypertext_explanation::hypertext_explanation() : hypertext()
{
  explanation_str=NULL;
}

hypertext_explanation::~hypertext_explanation()
{
  if(explanation_str)
    delete [] explanation_str;
}

void hypertext_explanation::toprinter(void)
{
  FILE *p=popen("lpr", "w");
  if(!p)
    {
      err.build(*this, WHAT((char *) "Eksekveringsfeil", 
			    (char *) "Execution error"),
		WHAT((char *) "Klarte ikke � �pne pipe til lpr",
		     (char *) "Couldn't open pipe to lpr"));
      return;
    }

  fprintf(p, "%s\n", explanation_str);

  pclose(p);
}

void hypertext_explanation::take_action(HYPERTEXT_ACTION action)
{
  switch(action)
    {
    case HYPERTEXT_CLOSE:
      sh.Unmap();
      break;
    case HYPERTEXT_PRINT:
      toprinter();
      break;
    case HYPERTEXT_CHANGEPRINTER:
      prsh.Create(getenv("PRINTER"));
      break;
    }
}

void hypertext_explanation::Create(widget parent, 
				   const char *prelabel, const char *txt,
				   const char *postlabel, 
				   const char *explanation)
{
  set_explanation(explanation);
  
  if((prelabel && *prelabel) || (postlabel && *postlabel))
    {
      labh_created=true;
      labh.build(parent);
      if(prelabel && *prelabel)
	prelab.build(labh, prelabel);
      Build(labh,txt);
      if(postlabel && *postlabel)
	postlab.build(labh, postlabel);
    }
  else
    {
      labh_created=false;
      Build(parent,txt);
    }

  sh.build(mainwin::toplevel, WHAT((char *) "Forklaring", 
				   (char *) "Explanation"));
  v1.build(sh);
  lab.build(v1, "");
  sep1.build(v1);
  h1.build(v1);
  closeb.Create(h1, WHAT((char *) "Lukk vindu", (char *) "Close"), 
		this, HYPERTEXT_CLOSE);
  closeb.Background("red");
  closeb.Foreground("white");
  printlab.build(h1, WHAT((char *) "  Skriver: %s", (char *) "  Printer: %s"),
		 getenv("PRINTER"));
  
  printb.Create(h1, WHAT((char *) "Skriv ut", (char *) "Print"), 
		this, HYPERTEXT_PRINT);
  printb.Background("blue");
  printb.Foreground("white");
  chprinterb.Create(h1, WHAT((char *) "Forandre skriver", 
			     (char *) "Change printer"), 
		    this, HYPERTEXT_CHANGEPRINTER);
}

void hypertext_explanation::set_explanation(const char *new_explanation)
{
  if(explanation_str)
    delete [] explanation_str;
  explanation_str=new char[strlen(new_explanation)+1];
  strcpy(explanation_str, new_explanation);
}

void hypertext_explanation::pushed(void)
{
  lab.labelString(explanation_str);
  sh.Map();
}

void hypertext_explanation::Map()
{
  if(labh_created)
    labh.Map();
  else
    widget::Map();
}

void hypertext_explanation::Unmap()
{
  if(labh_created)
    labh.Unmap();
  else
    widget::Unmap();
}

#ifdef MAIN
#include <hydrasub/hydragui/shell.H>
#include <hydrasub/hydragui/pushb.H>
#include <hydrasub/hydragui/row.H>
#include <iostream>

shell sh;

class map : public pushb 
{
public:
    void pushed() { sh.Map(); };
};

class unmap : public pushb 
{
public:
    void pushed() { sh.Unmap(); };
};



class mydraw : public draw 
{
  static int done;
public:
  void build(Widget par) 
  {
    draw::build(par, 500, 500);
  }

  void expose() 
  {
    std::cout << "expose"<< std::endl;
    if(!done++) Line(10, 10, 100, 100);
  }

  void redraw() 
  {
    std::cout << "redraw"<< std::endl;
  }

  void resize(int w, int h) 
  {
    std::cout << "expose" << std::endl;
  }

  void DoLeft() 
  {
    char c;
    std::cout << "Left" << std::endl << flush;
    sh.Unmap();
    cin >> c;
    sh.Map();
  }
};

int mydraw::done = 0;

main(int argc, char **argv) 
{
  XtAppContext app;
  char *str = "Test av draw";
  hrow h;
  mydraw d;
  map mapp;
  unmap unmapp;
  Widget toplevel = XtVaAppInitialize(&app, "dagut",
				      NULL, 0,
				      &argc, 
				      argv, 
				      NULL, 
				      XmNtitle, str, 
				      NULL);
  h.build(toplevel);
  mapp.build(h, "Map");
  unmapp.build(h, "Unmap");
  
  sh.build(toplevel, str);
  SetGPGSColors(sh);
  d.build(sh);
  sh.Map();
  XtRealizeWidget(toplevel);
  XtAppMainLoop(app);
}

#endif
