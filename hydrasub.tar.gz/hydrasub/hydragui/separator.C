/*
 * $Id: separator.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/separator.C $
 */


#include <hydrasub/hydragui/separator.H>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void sep::build(const Widget parent) {
    XmInitSetArg(XmNorientation, direction());
    init("sep", xmSeparatorWidgetClass, parent);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void sep::build(const Widget parent,SEPTYPE separator_type) {
    XmInitSetArg(XmNorientation, direction());
    init("sep", xmSeparatorWidgetClass, parent);
    XtVaSetValues(w,XmNseparatorType,(int) separator_type,NULL);
}


