/*
 * $Id: histogram.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/histogram.C $
 */

#include <hydrasub/hydragui/histogram.H>
#include <cmath>

void histogram_button::Create(widget parent, char *txt, 
			      HIST_ACTION buttontype, histogram *ipt)
{
  pt=ipt;
  type=buttontype;
  build(parent, txt);
}

void histogram_button::pushed(void)
{
  pt->button_pushed(type);
}

void histogram_toggle::Create(widget parent, histogram *ipt)
{
  pt=NULL;
  build(parent, WHAT((char *) "Akkumulert sannsynelighet",
		     (char *) "Accumulate probability"));
  pt=ipt;
}

void histogram_toggle::pushed(bool state)
{
  if(pt)
    pt->toggle_pushed(state);
}

void histogram::create(double **values_, int *length_, int numseries_,
		       char **linetitles_, char *xaxis, char *yaxis,
		       bool numeric,double steplength,
		       int argc, char **argv)
{
  int i,j;
  double max=0.0, minlen=MISSING_VALUE, logscale;
  
  minval=MISSING_VALUE;
  maxval=MISSING_VALUE;

  num_series=numseries_;

  if(numeric)
    donumeric=True;
  else
    donumeric=False;

  // copy info;
  values=new double*[num_series];
  serielength=new int[num_series];
  line_titles=new char*[num_series];
  axis_titles=new char*[2];

  axis_titles[0]=new char[100];
  strcpy(axis_titles[0], xaxis);
  axis_titles[1]=new char[100];
  strcpy(axis_titles[1], yaxis);

  for(i=0;i<num_series;i++)
    {
      serielength[i]=length_[i];

      if(minlen==MISSING_VALUE || minlen>serielength[i])
	minlen=serielength[i];

      values[i]=new double[serielength[i]];
      line_titles[i]=new char[200];
      
      strcpy(line_titles[i], linetitles_[i]);
      
      for(j=0;j<serielength[i];j++)
	{
	  values[i][j]=values_[i][j];
	  if(values[i][j]!=MISSING_VALUE)
	    max=MAXIM(max, ABSVAL((values[i][j])));

	  if(values[i][j]!=MISSING_VALUE &&
	     (maxval==MISSING_VALUE || maxval<values[i][j]))
	    maxval=values[i][j];

	  if(values[i][j]!=MISSING_VALUE &&
	     (minval==MISSING_VALUE || minval>values[i][j]))
	    minval=values[i][j];
	}
    }

  logscale=log10(max);
  logscale=floor(logscale);

  scale = pow(10.0, logscale);
  
  startval=scale*floor(minval/scale);
  endval=scale*ceil(maxval/scale);

  logscale=floor(log10(max/sqrt(minlen)));
  if(steplength!=MISSING_VALUE)
    step=steplength;
  else
    {
      step=pow(10.0, logscale);
      
      if(log10(max/sqrt(minlen))-logscale>log10(5.0))
	step=5.0*step;
      else if(log10(max/sqrt(minlen))-logscale>log10(2.0))
	step=2.0*step;
    }
  
  if(argc<1 || !argv)
    {
      sh.build(mainwin::toplevel, "Histogram");
      v1.build(sh);
      mainwindow=False;
    }
  else
    {
      mn=new mainwin("Histogram",argc, argv);
      v1.build(*mn);
      mainwindow=True;
    }
  
  set_grid(True);
  put_in_widget(v1, 900, 700, PLOT_IN_WIDGET_SHOWMAINMENU);
  h1.build(v1);
  if(mainwindow)
    exitb.Create(h1, WHAT((char *) "Avslutt", (char *) "Exit"));
  else
    {
      closeb.Create(h1, WHAT((char *) "Lukk vindu", (char *) "Close window"),
		    HIST_CLOSE, this);
      closeb.Background("red");
      closeb.Foreground("white");
    }

  accumulatedtog.Create(h1, this);
  stepf.build(h1, 10, WHAT((char *) "Steglengde:", (char *) "Step length:"));
  stepf.SetDouble(step);
  rerunb.Create(h1,WHAT((char *) "Nytt plott", (char *) "New plot"),
			HIST_RERUN, this);
  rerunb.Background("yellow");
  rerunb.Foreground("black");

  accumulated=False;

  if(!mainwindow)
    sh.Map();

  first=TRUE;
  drawplot();

  if(mainwindow)
    mn->Run();
}

void histogram::button_pushed(HIST_ACTION action)
{
  switch(action)
    {
    case HIST_RERUN:
      step=stepf.getdouble();
      drawplot();
      break;
    case HIST_CLOSE:
      sh.Unmap();
      break;
    default:
      break;
    }
}

void histogram::toggle_pushed(bool state)
{
  accumulated=state;
  drawplot();
}


void histogram::drawplot(void)
{
  double **arg=new double*[num_series], **val=new double*[num_series];
  int i,j, *len=new int[num_series], *axis=new int[num_series];
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[num_series];

  for(i=0;i<num_series;i++)
    {
      len[i]=(int) ceil((endval-startval)/step+3);

      val[i]=new double[len[i]];
      arg[i]=new double[len[i]];

      axis[i]=1;
      type[i]=accumulated ? PLOTLINE_LINE : PLOTLINE_BARS;
      
      for(j=0;j<len[i];j++)
	{
	  arg[i][j]=startval+j*step-step/2.0-step;
	  val[i][j]=0.0;
	}
      
      int newlen=0;
      for(j=0;j<serielength[i];j++)
	if(values[i][j]!=MISSING_VALUE)
	  {
	    int index=2 + (int) floor((values[i][j]-startval)/
				      (endval-startval)*
				      ((double) (len[i]-3)));
	    if(index>0 && index<len[i]-1)
	      {
		newlen++;
		val[i][index]++;
	      }
	    else
		std::cout << "Index out of range " << index << " " << values[i][j] << 
		    " ( " << startval << " - " << endval << " )" << std::endl;
	  }

      if(accumulated)
	{
	  for(j=1;j<len[i];j++)
	    val[i][j]+=val[i][j-1];
	  if(!donumeric)
	    for(j=0;j<len[i];j++)
	      val[i][j]/=val[i][len[i]-1];
	}
      else
	{
	  if(!donumeric)
	    for(j=0;j<len[i];j++)
	      val[i][j] /= double(newlen)*step;
	}
    }

  Create(arg, val, len, axis, line_titles, 
	 num_series, axis_titles, 2, NULL, type);

  if(!first)
    redraw();

  first=False;
}

void histogram::plot_ended(void)
{
  if(mainwindow)
    exit(0);
  else
    sh.Unmap();
}






void twoD_histogram_button::Create(widget parent, twoD_histogram *ipt)
{
  pt=ipt;
  build(parent, WHAT((char *) "Nytt plott", (char *) "New plot"));
  Background("yellow");
  Foreground("black");
}

void twoD_histogram_button::pushed(void)
{
  pt->button_pushed();
}

void twoD_histogram::create(double *values_, int length_, 
			  char *linetitle_, char *unitname_,
			  bool numeric, bool logprob,
			    int argc, char **argv)
{
  int j;
  double max=0.0, logscale;
  
  minval=MISSING_VALUE;
  maxval=MISSING_VALUE;

  if(numeric)
    donumeric=True;
  else
    donumeric=False;

  dologprob=logprob;

  // copy info;
  serielength=length_;
  line_titles=new char[strlen(linetitle_)+2];
  axis_titles=new char*[2];

  axis_titles[0]=new char[100];
  sprintf(axis_titles[0], "%s - %s", unitname_, WHAT((char *) "gammel",
						     (char *) "old"));
  axis_titles[1]=new char[100];
  sprintf(axis_titles[1], "%s - %s", unitname_, WHAT((char *) "ny",
						     (char *) "new"));
  
  values=new double[serielength];
  strcpy(line_titles, linetitle_);
  
  for(j=0;j<serielength;j++)
    {
      values[j]=values_[j];

      if(values[j]!=MISSING_VALUE)
	max=MAXIM(max, ABSVAL((values[j])));
      
      if(values[j]!=MISSING_VALUE &&
	 (maxval==MISSING_VALUE || maxval<values[j]))
	maxval=values[j];
      
      if(values[j]!=MISSING_VALUE &&
	 (minval==MISSING_VALUE || minval>values[j]))
	minval=values[j];
    }

  logscale=log10(max);
  logscale=floor(logscale-1.0);

  scale = pow(10.0, logscale);
  
  startval=scale*floor(minval/scale);
  endval=scale*ceil(maxval/scale);

  step=scale/sqrt(sqrt(double(serielength)));
  
  logscale=ceil(log10(step));
  step=pow(10.0, logscale);

  if(argc<1 || !argv)
    {
      sh.build(mainwin::toplevel, "twoD_Histogram");
      v1.build(sh);
      mainwindow=False;
    }
  else
    {
      mn=new mainwin("twoD_Histogram",argc, argv);
      v1.build(*mn);
      mainwindow=True;
    }

  set_grid(True);
  put_in_widget(v1, 900, 700, PLOT_IN_WIDGET_SHOWMAINMENU);
  h1.build(v1);
  stepf.build(h1, 10, WHAT((char *) "Steglengde:", (char *) "Step length:"));
  stepf.SetDouble(step);
  rerunb.Create(h1,this);

  if(!mainwindow)
    sh.Map();

  first=TRUE;
  drawplot();

  if(mainwindow)
    mn->Run();
}

void twoD_histogram::button_pushed(void)
{
  step=stepf.getdouble();
  drawplot();
}


// Usage of global variables makes using more than one instance of this
// module at once dangerous!
int twoD_histogram_size;
double **twoD_histogram_numeric=NULL;
double twoD_histogram_minx, twoD_histogram_miny, twoD_histogram_maxx,
  twoD_histogram_maxy, twoD_histogram_step;
double get_twoD_histogram(double x, double y)
{
  int xindex=(int) floor((x-twoD_histogram_minx)/twoD_histogram_step);
  int yindex=(int) floor((y-twoD_histogram_miny)/twoD_histogram_step);
  
  if(xindex<0 || xindex>=twoD_histogram_size ||
     yindex<0 || yindex>=twoD_histogram_size)
    return 0.0;

  return twoD_histogram_numeric[xindex][yindex];
}

void twoD_histogram::drawplot(void)
{
  int i,j,num=0;

  if(twoD_histogram_numeric)
    doubledelete(twoD_histogram_numeric, twoD_histogram_size);

  twoD_histogram_size=(int) ceil((maxval-minval)/step);
  twoD_histogram_numeric=new double*[twoD_histogram_size];

  for(i=0;i<twoD_histogram_size;i++)
    {
      twoD_histogram_numeric[i]=new double[twoD_histogram_size];
      for(j=0;j<twoD_histogram_size;j++)
	twoD_histogram_numeric[i][j]=0.0;
    }

  for(i=1;i<serielength;i++)
    if(values[i-1]!=MISSING_VALUE && values[i]!=MISSING_VALUE)
      {
	int xindex=(int) floor((values[i-1]-minval)/step);
	int yindex=(int) floor((values[i]-minval)/step);

	if(xindex>=0 && yindex>=0 && xindex<twoD_histogram_size &&
	   yindex<twoD_histogram_size)
	  {
	    twoD_histogram_numeric[xindex][yindex]++;
	    num++;
	  }
      }
  
  if(!donumeric)
    for(i=0;i<twoD_histogram_size;i++)
      {
	int numx=0;

	for(j=0;j<twoD_histogram_size;j++)
	  numx+=(int)twoD_histogram_numeric[i][j];

	if(numx>0)
	  for(j=0;j<twoD_histogram_size;j++)
	    twoD_histogram_numeric[i][j] /= double(numx);
      }

  if(dologprob)
    for(i=0;i<twoD_histogram_size;i++)
      for(j=0;j<twoD_histogram_size;j++)
	if(twoD_histogram_numeric[i][j]>0.0)
	  twoD_histogram_numeric[i][j]=log(twoD_histogram_numeric[i][j]);
	else
	  twoD_histogram_numeric[i][j]=MISSING_VALUE;

  twoD_histogram_minx=minval;
  twoD_histogram_miny=minval;
  twoD_histogram_maxx=maxval;
  twoD_histogram_maxy=maxval;
  twoD_histogram_step=step;

  Create(get_twoD_histogram, minval,minval,maxval,maxval,
	 axis_titles[0], axis_titles[1], 0);
  
  if(!first)
    redraw();

  first=False;
}

void twoD_histogram::plot_ended(void)
{
  if(mainwindow)
    exit(0);
  else
    sh.Unmap();
}

void twoD_histogram::init(void)
{
  first=True;
  mainwindow=False;
  donumeric=False;
  values=NULL;
  axis_titles=NULL;
  line_titles=NULL;
}

void twoD_histogram::cleanup(void)
{
  init();
}

twoD_histogram::twoD_histogram()
{
  init();
}

twoD_histogram::~twoD_histogram()
{
  cleanup();
}

void show_multivariate_menu::create(widget parent, char *txt, char **items, 
				    int numitems, int focus,
				    show_multivariate_function *ipt)
{
  pt=NULL;
  Create(parent,txt);
  Insert(items, numitems, focus);
  pt=ipt;
}

void show_multivariate_menu::pushed(const char *)
{
  if(pt)
    pt->handle_action(SHOW_MULTIVARIATE_NEWMENU);
}

void show_multivariate_button::Create(widget parent, char *txt, 
				      show_multivariate_function *ipt,
				      SHOW_MULTIVARIATE_ACTION type)
{
  typ=type;
  pt=ipt;
  build(parent, txt);
}

void show_multivariate_button::pushed(void)
{
  pt->handle_action(typ);
}


void show_multivariate_function::handle_action(SHOW_MULTIVARIATE_ACTION type)
{
  switch(type)
    {
    case SHOW_MULTIVARIATE_START:
      make_plot_window();
      break;
    case SHOW_MULTIVARIATE_CANCEL:
      startsh.Unmap();
      break; 
    case SHOW_MULTIVARIATE_RERUN:
      rerun();
      break; 
    case SHOW_MULTIVARIATE_NEWMENU: 
      menu_changed();
      break;
    case SHOW_MULTIVARIATE_CLOSE:
      plot_ended();
      break;
    }
}

show_multivariate_function::show_multivariate_function() :
  plot_module()
{
  first=True;
  starthr=NULL;
  startf=NULL;
  endf=NULL;
  defaultf=NULL;
  startvalues=NULL;
  endvalues=NULL;
  defaultvalues=NULL;
  paramname=NULL;
  functiontitle=NULL;
  startlab=NULL;
  params=NULL;
  valuef=NULL;
  valueh=NULL;
}

show_multivariate_function::~show_multivariate_function()
{
  cleanup();
}

bool show_multivariate_function::check_start_window(void)
{
  int i;

  startvalues=new double[numparams];
  endvalues=new double[numparams];
  defaultvalues=new double[numparams];

  for(i=0;i<numparams;i++)
    {
      double start, end, def;
      char errmsg[200];

      if(!sscanf(startf[i](), "%lf", &start))
	{
	  sprintf(errmsg, 
		  WHAT((char *) "Klarte ikke � lese startfelt for "
		       "parameter %d, %s", 
		       (char *) "Couldn't read start field for parameter "
		       "%d, %s"), i+1, paramname[i]);
	  err.build(startsh, WHAT((char *) "Feil", (char *) "Error"), errmsg);
	  cleanup_limits();
	  return False;
	}

      if(!sscanf(endf[i](), "%lf", &end))
	{
	  sprintf(errmsg, 
		  WHAT((char *) "Klarte ikke � lese sluttfelt for "
		       "parameter %d, %s", 
		       (char *) "Couldn't read end field for parameter "
		       "%d, %s"), i+1, paramname[i]);
	  err.build(startsh, WHAT((char *) "Feil", (char *) "Error"), errmsg);
	  cleanup_limits();
	  return False;
	}

      if(!sscanf(defaultf[i](), "%lf", &def))
	{
	  sprintf(errmsg, 
		  WHAT((char *) "Klarte ikke � lese defaultfelt for "
		       "parameter %d, %s", 
		       (char *) "Couldn't read default field for parameter "
		       "%d, %s"), i+1, paramname[i]);
	  err.build(startsh, WHAT((char *) "Feil", (char *) "Error"), errmsg);
	  cleanup_limits();
	  return False;
	}

      if(end<=start)
	{
	  sprintf(errmsg, 
		  WHAT((char *) "Start kommer etter slutt for parameter "
		       "%d, %s", 
		       (char *) "Start comes after end for parameter "
		       "%d, %s"), i+1, paramname[i]);
	  err.build(startsh, WHAT((char *) "Feil", (char *) "Error"), errmsg);
	  cleanup_limits();
	  return False;
	}

      if(def<=start)
	{
	  sprintf(errmsg, 
		  WHAT((char *) "Default kommer f�r start for parameter "
		       "%d, %s", 
		       (char *) "Default comes before start for parameter "
		       "%d, %s"), i+1, paramname[i]);
	  err.build(startsh, WHAT((char *) "Feil", (char *) "Error"), errmsg);
	  cleanup_limits();
	  return False;
	}

      if(def>=end)
	{
	  sprintf(errmsg, 
		  WHAT((char *) "Default kommer etter slutt for parameter "
		       "%d, %s", 
		       (char *) "Default comes after end for parameter "
		       "%d, %s"), i+1, paramname[i]);
	  err.build(startsh, WHAT((char *) "Feil", (char *) "Error"), errmsg);
	  cleanup_limits();
	  return False;
	}

      startvalues[i]=start;
      endvalues[i]=end;
      defaultvalues[i]=def;
    }

  return True;
}

void show_multivariate_function::make_plot_window(void)
{
  int i;

  if(defaults)
    delete [] defaults;
  defaults=new double[numparams];

  if(params)
    delete [] params;
  params=new double[numparams];

  if(!check_start_window())
    return;

  startsh.Unmap();

  plotsh.build(mainwin::toplevel, functiontitle);
  plotv1.build(plotsh);

  index1=0;
  index2=1;
  num_parameters=numparams;
  for(i=0;i<numparams;i++)
    defaults[i]=defaultvalues[i];
  put_in_widget(plotv1, 800, 500, PLOT_IN_WIDGET_SHOWMAINMENU);
  set_grid(True);
  Create(show_multivariate_function::function_buffer, 
	 startvalues[0], startvalues[1],
	 endvalues[0], endvalues[1], paramname[0], paramname[1]);
	 
  valueh=new hrow[numparams];
  valuef=new honlydigit[numparams];
  for(i=0;i<numparams;i++)
    {
      valueh[i].build(plotv1);
      valuef[i].build(valueh[i], 10, paramname[i]);
      valuef[i].SetDouble(defaultvalues[i], 5);
    }
  
  ploth1.build(plotv1);
  rerunb.Create(ploth1, WHAT((char *) "Kj�r p�ny", (char *) "Run again"),
		this,SHOW_MULTIVARIATE_RERUN);
  rerunb.Background("green");
  rerunb.Foreground("black");
  ploth2.build(plotv1);
  coord1.create(ploth2, WHAT((char *) "X-aksens type:", 
			     (char *) "X axis type:"),
		paramname, numparams, 0, this);
  coord2.create(ploth2, WHAT((char *) "Y-aksens type:", 
			     (char *) "Y axis type:"),
		paramname, numparams, 1, this);
  ploth3.build(plotv1);
  closeb.Create(ploth3, WHAT((char *) "Avslutt", (char *) "Close window"),
		this, SHOW_MULTIVARIATE_CLOSE);
  closeb.Background("red");
  closeb.Foreground("white");

  plotsh.Map();
  valuef[0].Unmap();
  valuef[1].Unmap();
}

// Used for setting unspecified things in 'function_buffer'
int show_multivariate_function::index1=0, 
  show_multivariate_function::index2=0, 
  show_multivariate_function::num_parameters=0;
double *show_multivariate_function::defaults=NULL,
  *show_multivariate_function::params=NULL;

double 
(*show_multivariate_function::multivariate_function1)(double *,int)=NULL;
double 
(*show_multivariate_function::multivariate_function2)(double *)=NULL;
  
double show_multivariate_function::function_buffer(double x, double y)
{
  for(int i=0;i<num_parameters;i++)
    params[i]=defaults[i];
  params[index1]=x;
  params[index2]=y;

  if(multivariate_function1)
    return multivariate_function1(params, num_parameters);
  else if(multivariate_function2)
    return multivariate_function2(params);
  else
    return MISSING_VALUE;
}

void show_multivariate_function::rerun(void)
{
  int i;
  
  for(i=0;i<numparams;i++)
    if(i!=index1 && i!=index2)
      defaults[i]=valuef[i].getdouble();

  AddWorkCursor(plotsh);
  Create(function_buffer, startvalues[index1], startvalues[index2],
	 endvalues[index1], endvalues[index2], 
	 paramname[index1], paramname[index2]);	 
  redraw();
  RmWorkCursor(plotsh);
}

void show_multivariate_function::menu_changed(void)
{
  int i;

  index1=coord1.GetNumber();
  index2=coord2.GetNumber();

  for(i=0;i<numparams;i++)
    valuef[i].Map();
  valuef[index1].Unmap();
  valuef[index2].Unmap();
  
  rerun();
}


void show_multivariate_function::cleanup_limits(void)
{
  if(startvalues)
    delete [] startvalues;
  startvalues=NULL;
  
  if(endvalues)
    delete [] endvalues;
  endvalues=NULL;
  
  if(defaultvalues)
    delete [] defaultvalues;
  defaultvalues=NULL;
}

void show_multivariate_function::cleanup(void)
{
  cleanup_limits();

  if(params)
    delete [] params;
  params=NULL;

  if(defaults)
    delete [] defaults;
  defaults=NULL;

  if(starthr)
    delete [] starthr;
  starthr=NULL;

  if(startf)
    delete [] startf;
  startf=NULL;

  if(endf)
    delete [] endf;
  endf=NULL;

  if(valuef)
    delete [] valuef;
  valuef=NULL;

  if(valueh)
    delete [] valueh;
  valueh=NULL;

  if(defaultf)
    delete [] defaultf;
  defaultf=NULL;

  if(paramname)
    {
      for(int i=0;i<numparams;i++)
	if(paramname[i])
	  delete [] paramname[i];
      delete [] paramname;
    }
  paramname=NULL;

  if(functiontitle)
    delete [] functiontitle;
  functiontitle=NULL;

  if(startlab)
    delete [] startlab;
  startlab=NULL;

  numparams=num_parameters=0;
  multivariate_function1=NULL;
  multivariate_function2=NULL;
}

void show_multivariate_function::create(double (*function)(double *,int), 
					int num_params, char **param_names, 
					char *function_title, 
					double *start_proposal,
					double *end_proposal,
					double *default_proposal)
{  
  cleanup();
  first=True;
  multivariate_function1=function;
  multivariate_function2=NULL;

  startup(num_params, param_names, function_title, start_proposal,
	  end_proposal, default_proposal);
}

void show_multivariate_function::create(double (*function)(double *), 
					int num_params, char **param_names, 
					char *function_title, 
					double *start_proposal,
					double *end_proposal,
					double *default_proposal)
{  
  cleanup();
  first=True;
  multivariate_function2=function;
  multivariate_function1=NULL;

  startup(num_params, param_names, function_title, start_proposal,
	  end_proposal, default_proposal);
}

void show_multivariate_function::startup(int num_params, char **param_names, 
					 char *function_title, 
					 double *start_proposal,
					 double *end_proposal,
					 double *default_proposal)
{
  int i;

  // Store the incoming info;
  numparams=num_params;
  
  paramname=new char*[numparams];
  for(i=0;i<numparams;i++)
    {
      paramname[i]=new char[strlen(param_names[i])+2];
      strcpy(paramname[i], param_names[i]);
    }

  functiontitle=new char[strlen(function_title)+2];
  strcpy(functiontitle, function_title);

  // Make the start window;
  startsh.build(mainwin::toplevel, 
		WHAT((char *)"Velg spenn i verdier for hver koordinat:",
		     (char *)"Choose interval for each coordinate:"));
  startv1.build(startsh);
  startlab=new label[numparams];
  startf=new honlydigit[numparams];
  endf=new honlydigit[numparams];
  defaultf=new honlydigit[numparams];
  starthr=new hrow[numparams];
  for(i=0;i<numparams;i++)
    {
      starthr[i].build(startv1);
      startlab[i].build(starthr[i], "%s: ", paramname[i]);
      startf[i].build(starthr[i], 10, WHAT((char *) "Minste aktuelle verdi:",
					   (char *) "Least relevant value:"));
      endf[i].build(starthr[i], 10, WHAT((char *) "St�rste aktuelle verdi:",
					 (char *) "Largest relevant value:"));
      defaultf[i].build(starthr[i], 10, WHAT((char *) "Default verdi:",
					     (char *) "Default value:"));

      if(start_proposal && start_proposal[i]!=MISSING_VALUE)
	startf[i].SetDouble(start_proposal[i], 5);
      if(end_proposal && end_proposal[i]!=MISSING_VALUE)
	endf[i].SetDouble(end_proposal[i], 5);
      if(default_proposal && default_proposal[i]!=MISSING_VALUE)
	defaultf[i].SetDouble(default_proposal[i], 5);
    }
  
  starth1.build(startv1);
  startb.Create(starth1, WHAT((char *) "Kj�r", (char *) "Run"), this,
		SHOW_MULTIVARIATE_START);
  startb.Background("green");
  startb.Foreground("black");
  cancelb.Create(starth1, WHAT((char *) "Avbryt", (char *) "Abort"), this,
		 SHOW_MULTIVARIATE_CANCEL);
  cancelb.Background("red");
  cancelb.Foreground("white");

  startsh.Map();
}

void show_multivariate_function::plot_ended(void)
{
  plotsh.Unmap();
}

