/*
 * $Id: independencetesting.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/independencetesting.C $
 */

#include <hydrasub/hydragui/independencetesting.H>
#include <cmath>
#include <hydrasub/hydrabase/divfunc.H>
#include <gsl/gsl_cdf.h>

double find_mean_with_cutoff(double *values, int len, double cutoff)
{
  int len2=0, i=0;
  double mean=0.0;

  for(i=0;i<len;i++)
    if(cutoff==MISSING_VALUE || values[i]<cutoff)
      {
	mean+=values[i];
	len2++;
      }

  if(len2>0)
    mean/=double(len2);
  else
    mean=MISSING_VALUE;

  return mean;
}

void gettimeresname(char *unitname, BASE_TIME btime)
{
  if(btime==MIN0)
    strcpy(unitname, WHAT((char *) "sekunder", (char *) "seconds"));
  else
    strcpy(unitname, get_timeres_name(btime));
}

void independecetesting_button::Create(widget parent, char *txt, 
				       independecetesting *ipt,
				       INDEP_ACTION_TYPE actiontype)
{
  type=actiontype;
  pt=ipt;
  build(parent, txt);
}

void independecetesting_button::pushed(void)
{
  pt->button_pushed(type);
}

void independecetesting_floating_argument::Create(widget parent, char *txt, 
						  independecetesting *ipt)
{
  pt=NULL;
  build(parent,txt);
  ToggleButtonOn();
  pt=ipt;
}

void independecetesting_floating_argument::pushed(bool state)
{
  if(pt)
    pt->floating_state_changed(state);
}

double *independecetesting::get_cathegories(double T, int *num_cath)
{
  double *ret=NULL;
  int i;

  if(floating())
    {
      length_of_cathegories=resolution.getdouble();
      cutoff_length=cutoff.getdouble();
      double cathlen=length_of_cathegories;

      *num_cath=int(floor(MAXIM(1.0, (cutoff_length/cathlen))))+1;
      ret=new double[*num_cath];
      
      for(i=0;i<*num_cath;i++)
	ret[i]=double(i)*cathlen;
    }
  else
    {
      *num_cath=resolution2.getdigit();
      double c=double(*num_cath);

      ret=new double[*num_cath];
      ret[0]=0.0;
      for(i=1;i<*num_cath;i++)
	ret[i]=T*log(c/(c-double(i)));
      
      length_of_cathegories=ret[1];
      cutoff_length=ret[*num_cath-1];
    }

  return ret;
}

void independecetesting::newtest(void)
{
  double T=find_mean_with_cutoff(intereventtimes,len,timedifference_cutoff);
  int num_cath;
  double *cath_borders=get_cathegories(T, &num_cath);
  int i, j, len2=0;
  double maxdiff=0.0;
  double *interevents2=new double[len];

  kolm_pvaluef.Clear();
  chi2_pvaluef.Clear();

  for(i=0;i<len;i++)
    if(timedifference_cutoff==MISSING_VALUE || 
       intereventtimes[i]<timedifference_cutoff)
      interevents2[len2++]=intereventtimes[i];  
  if(len2<1)
    {
      errdiag.build(mainwin::toplevel, 
		    WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Ingen m�lepunkt igjen etter beskj�ring!", 
			 (char *) "No data left after cutoff!"));
      return;
    }

  qsort(interevents2, size_t(len2), sizeof(double), compare_double);
  
  for(i=0;i<len2;i++)
    {
      double sn=double(i)/double(len2);
      double theory=1.0-exp(-interevents2[i]/T);
      double diff=ABSVAL((sn-theory));
      
      maxdiff=MAXIM(maxdiff,diff);
    }

  char strbuffer[500];

  resultf.Clear();
  resultf+=WHAT((char *) "Kologorov-test:\n", (char *) "Kolmogorov test:\n");
  sprintf(strbuffer, WHAT((char *) "Max differanse mellom akkumulert "
			  "sannsynelighet for m�lte interevent-tider\nog "
			  "eksponensialfordelingen: %8.5f\n", 
			  (char *) "Maximum differance between accumulated "
			  "propability from measured interevent times\nand "
			  "the exponensial distribution: %8.5f\n"), maxdiff);
  resultf+=strbuffer;

  double len3=len2;
  double maxdiff3=maxdiff;

  while(len3>250)
    {
      len3/=10;
      maxdiff3*=sqrt(10.0);
    }

#ifdef GOOSE
  double kolm_pvalue=1.0-kolmogorov_smirnov_2sample_exact((unsigned int)len3,1000, 
							  maxdiff3);
  kolm_pvaluef.SetDouble(kolm_pvalue*100.0, 5);
  sprintf(strbuffer, WHAT((char *) "P-verdi: %8.5g%%\n\n", 
			  (char *) "P value: %8.5g%%\n\n"), 100.0*kolm_pvalue);
  resultf+=strbuffer;
#else
  sprintf(strbuffer, WHAT((char *) "P-verdi: %8.5g%%\n\n", 
			  (char *) "P value: %8.5g%%\n\n"), MISSING_VALUE);
  resultf+=strbuffer;
#endif // GOOSE

  if(num_cath<3)
    {
      errdiag.build(mainwin::toplevel,
		    WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "For f� kategorier. Pr�v med litt finere "
			 "oppl�snsing.",
			 (char *) "Too few cathegories. Try again with a "
			 "finer resolution."));
      return;
    }

  double *predicted=new double[num_cath], *found=new double[num_cath];
  for(i=0;i<num_cath;i++)
    found[i]=0.0;

  for(i=0;i<num_cath-1;i++)
    predicted[i]=exp(-cath_borders[i]/T)-exp(-cath_borders[i+1]/T);
  predicted[i]=exp(-cath_borders[i]/T);
  
  len2=0;
  for(i=0;i<len;i++)
    if(timedifference_cutoff==MISSING_VALUE || 
       intereventtimes[i]<timedifference_cutoff)
      {
	for(j=0;j<num_cath;j++)
	  if(cath_borders[j]<=intereventtimes[i] &&
	     (j==num_cath-1 || intereventtimes[i]<cath_borders[j+1]))
	    found[j]++;

	len2++;
      }

  for(i=0;i<num_cath;i++)
    {
      predicted[i]*=double(len2);

      if(predicted[i]<5.0)
	{
	  char errmsg[300];

	  if(i<num_cath-1)
	    sprintf(errmsg, WHAT((char *) "Kan ikke test p� kategorier med "
				 "mindre enn 5 forventede treff. "
				 "Intervallet %8.1f-%8.1f har %8.3f "
				 "forventede treff.", 
				 (char *) "Can't test on catheogries with "
				 "less than 5 expected hits. The interval "
				 "%8.1f-%8.1f has only %8.3f expected "
				 "hits."),
		    cath_borders[i], cath_borders[i+1],
		    predicted[i]);
	  else
	    sprintf(errmsg, WHAT((char *) "Kan ikke test p� kategorier med "
				 "mindre enn 5 forventede treff. "
				 "Intervallet %8.1f++ har %8.3f "
				 "forventede treff.", 
				 (char *) "Can't test on catheogries with "
				 "less than 5 expected hits. The interval "
				 "%8.1f++ has only %8.3f expected "
				 "hits."), cath_borders[i], predicted[i]);
	  
	  errdiag.build(mainwin::toplevel, WHAT((char *) "Feil", 
					    (char *) "Error"),
		    errmsg);

	  delete [] predicted;
	  delete [] found;
	  return;
	}
    }
  
  double kisquared=0.0;
  resultf+=WHAT((char *) "Ki-kvadrat-test:\n", (char *) "Chi-square test");
  sprintf(strbuffer, "%s: %8.3g  ",
	  WHAT((char *) "Karakteristisk tidsdifferans", 
	       (char *) "Characteristic time difference"), T);
  resultf+=strbuffer;
  sprintf(strbuffer, "%10s: %8.3g\n\n",
	  WHAT((char *) "Rate", (char *) "Rate"), 1.0/T);
  resultf+=strbuffer;
  sprintf(strbuffer, "%15s %11s %11s %9s %19s\n", 
	  WHAT((char *) "Kategori-nummer", (char *) "Category number"),
	  WHAT((char *) "Avgrensning", (char *) "Range"),
	  WHAT((char *) "Antall m�lt", (char *) "Measured"),
	  WHAT((char *) "Forventet", (char *) "Predicted"),
	  WHAT((char *) "KI�-bidrag", (char *) "Contribution to KI�"));
  resultf+=strbuffer;

  for(i=0;i<num_cath;i++)
    {
      double kicontrib=(found[i]-predicted[i])*(found[i]-predicted[i])/
	predicted[i];

      kisquared+=kicontrib;

      if(i<num_cath-1)
	sprintf(strbuffer, 
		"%-9d %8.2g-%8.2g     %7.2f   %7.2f %10s  %7.2f\n",
		i+1, cath_borders[i], cath_borders[i+1], 
		found[i], predicted[i], " ", kicontrib);
      else
	sprintf(strbuffer, 
		"%-9d %8.2g %-8s     %7.2f   %7.2f %10s  %7.2f\n",
		i+1, cath_borders[i], "++", 
		found[i], predicted[i], " ", kicontrib);
      resultf+=strbuffer;
    }
  
  
  sprintf(strbuffer, "%-27s %11d %20s %9.2f\n", 
	  WHAT((char *) "Totalt:", (char *) "Total:"),
	  len2, " ", kisquared);
  resultf+=strbuffer;

#ifdef GSL
  double chi2_pvalue = kisquared > 1000.0 ? 0.0 : 
      1.0 - gsl_cdf_chisq_P(kisquared, double(num_cath-2));
#endif

  chi2_pvaluef.SetDouble(100.0*chi2_pvalue, 4);

  sprintf(strbuffer, "%7s: %7.4g%%\n", 
	  WHAT((char *) "P-verdi",
	       (char *) "P-value"), 
	  100.0*chi2_pvalue);
  resultf+=strbuffer;

  doplot(predicted,found,num_cath, cath_borders);

  delete [] predicted;
  delete [] found;
}

void independecetesting::doplot(double *predicted, double *found, 
				int num_cath, double *cath_borders)
{
  char **axisstr=new char*[2];
  char **linestr=new char*[2];
  int i, axis[2], length[2];
  double **arg=new double*[2], **val=new double*[2];
  PLOTLINE_TYPE type[2];
  bool logaxis[2];

  for(i=0;i<2;i++)
    {
      axisstr[i]=new char[100];
      linestr[i]=new char[100];
      arg[i]=new double[num_cath+2];
      type[i]=PLOTLINE_BARS;
      axis[i]=1;
      length[i]=num_cath+2;
    }

  logaxis[0]=False;
  logaxis[1]=True;
  char unitname[100];
  gettimeresname(unitname, timeres);
  sprintf(axisstr[0], WHAT((char *) "Tid mellom hendelser (%s)", 
			   (char *) "Interevent time (%s)"), unitname);
  strcpy(axisstr[1], WHAT((char *) "Antall", (char *) "Number"));
  strcpy(linestr[0], WHAT((char *) "Forventet", (char *) "Expected"));
  strcpy(linestr[1], WHAT((char *) "M�lt", (char *) "Measured"));

  val[0]=new double[num_cath+2];
  for(i=0;i<num_cath;i++)
    val[0][i+1]=predicted[i];
  val[0][0]=0.0;
  val[0][num_cath+1]=0.0;

  val[1]=new double[num_cath+2];
  for(i=0;i<num_cath;i++)
    val[1][i+1]=found[i];
  val[1][0]=0.0;
  val[1][num_cath+1]=0.0;

  arg[0][0]=cath_borders[0]-(cath_borders[1]-cath_borders[0])/2.0;
  for(i=0;i<num_cath;i++)
    arg[0][i+1]=2*cath_borders[i]-arg[0][i];
  arg[0][num_cath+1]=arg[0][num_cath]+(cath_borders[num_cath-1]-
				       cath_borders[num_cath-2]);
  for(i=0;i<num_cath+2;i++)
    arg[1][i]=arg[0][i];

  Create(arg,val,length,axis,linestr,2,axisstr,2,NULL,type);
  //,NULL,NULL,NULL, NULL,logaxis);
  if(!firstplot)
    redraw();
  firstplot=False;

  doubledelete(arg,2);
  doubledelete(val,2);
  doubledelete(linestr,2);
  doubledelete(axisstr,2);
}

void independecetesting::init(void)
{
  intereventtimes=NULL;
  eventtimes=NULL;
  len=0;
  timedifference_cutoff=MISSING_VALUE;
}

void independecetesting::cleanup(void)
{
  if(intereventtimes)
    delete [] intereventtimes;
  if(eventtimes)
    delete [] eventtimes;
  init();
}

void independecetesting::make_widgets(widget parent)
{
  v1.build(parent);
  put_in_widget(v1, 800, 400, PLOT_IN_WIDGET_SHOWMAINMENU);
  h2.build(v1);
  resultf.build(h2, 80, 12);
  v2.build(h2);
  resultf.build_printb(v2);
  resultf.build_chprintb(v2);
  resultf.build_printlab(v2);
  resultf.build_emailb(v2);
  resultf.build_saveb(v2);
  kolm_pvaluef.build(v2, 10, WHAT((char *) "P-verdi fra Kolmogorov-test(%):", 
				  (char *) "P-value from Kolmogorov "
				  "test(%):"));
  chi2_pvaluef.build(v2, 10, WHAT((char *) "P-verdi fra chi-kvardat-"
				  "test(%):", 
				  (char *) "P-value from chi sqaure "
				  "test(%):"));

  char resstr[100], unitname[100], cutoffstr[100];
  gettimeresname(unitname, timeres);
  sprintf(resstr, "%s (%s):", WHAT((char *) "Kategorienes st�rrelse:", 
				   (char *) "Cathegory length:"), unitname);
  sprintf(cutoffstr, "%s (%s):", WHAT((char *) "Kategorisere opp til:", 
				      (char *) "Cathegory cutoff:"), 
	  unitname);
  h3.build(v1);
  h4.build(h3);
  resolution.build(h4, 10, resstr);
  resolution.SetDouble(length_of_cathegories, 2);
  cutoff.build(h4, 10, cutoffstr);
  cutoff.SetDouble(cutoff_length, 2);
  h5.build(h3);
  resolution2.build(h5, 5, WHAT((char *) "Antall kategorier:", 
				(char *) "Number of cathegories:"));
  resolution2.SetDigit(len/20);
  h5.Unmap();
  floating.Create(h3, WHAT((char *) "Fast kategorilengde", 
			   (char *) "Catheogry length"), this);

  h1.build(v1);
  closeb.Create(h1, WHAT((char *) "Avslutt", (char *) "Close"), this,
		INDEP_CLOSE);
  closeb.Background("red");
  closeb.Foreground("white");
  newtestb.Create(h1, WHAT((char *) "Ny test", (char *) "New test"), this,
		INDEP_NEWTEST);
  newtestb.Background("green");
  newtestb.Foreground("black");
}

void independecetesting::store_event_times(DateTime *event_times, int length, 
					   double default_length)
{
  register int i;

  len=length;
  eventtimes=new DateTime[len];

  for(i=0;i<len;i++)
    eventtimes[i]=event_times[i];

  len--;
  intereventtimes=new double[len];
  for(i=0;i<len;i++)
    if(timeres==MIN0)
      intereventtimes[i]=eventtimes[i+1]-eventtimes[i];
    else
      intereventtimes[i]=eventtimes[i+1].difference_minutes(eventtimes[i])/
	((double) timeres);

  find_default_cath_length(default_length);
}

void independecetesting::find_default_cath_length(double default_length)
{
  double T=find_mean_with_cutoff(intereventtimes,len,timedifference_cutoff);
  double cutoff_buffer=T*log(double(len)/9.0);
  double cathlen=cutoff_buffer+T*log(exp(-cutoff_buffer/T)+9.0/double(len));
  
  if(default_length!=MISSING_VALUE)
    cathlen=length_of_cathegories=default_length;

  double scale=floor(log(cathlen)/log(10.0));
  double size=pow(10.0, scale);

  if(default_length==MISSING_VALUE)
    {
      length_of_cathegories=ceil(cathlen/size)*size;
      if(timedifference_cutoff==MISSING_VALUE)
	cutoff_length=floor(cutoff_buffer/size)*size;
      else
	cutoff_length=timedifference_cutoff;
    }
  else
    {
      cutoff_length=cathlen;
      while(exp(-cutoff_length/T)-exp(-(cutoff_length+cathlen)/T) > 
	    5.0/double(len))
	cutoff_length+=cathlen;
    }
}

void independecetesting::store_interevent_times(double *interevent_times, 
						int length,double 
						default_length)
{
  len=length;
  intereventtimes=new double[len];

  for(int i=0;i<len;i++)
    intereventtimes[i]=interevent_times[i];

  find_default_cath_length(default_length);
}

void independecetesting::button_pushed(INDEP_ACTION_TYPE actiontype)
{
  switch(actiontype)
    {
    case INDEP_CLOSE:
      plot_ended();
      break;
    case INDEP_NEWTEST:
      newtest();
      break;
    }
}

void independecetesting::floating_state_changed(bool state)
{
  if(!state)
    {
      h4.Unmap();
      h5.Map();
    }
  else
    {
      h4.Map();
      h5.Unmap();
    }
}

independecetesting::independecetesting() : plot_module()
{
  init();
  firstplot=True;
}

independecetesting::~independecetesting()
{
  cleanup();
}

void independecetesting::create(widget parent, DateTime *event_times, 
				int length, BASE_TIME time_resolution, 
				double default_length,
				double timediff_cutoff)
{
  cleanup();
  timedifference_cutoff=timediff_cutoff;
  timeres=time_resolution;
  store_event_times(event_times, length, default_length);
  make_widgets(parent);
  newtest();
}

void independecetesting::create(widget parent, 
				double *interevent_times, int length, 
				BASE_TIME, 
				double default_length,
				double timediff_cutoff)
{
  cleanup();
  timedifference_cutoff=timediff_cutoff;
  store_interevent_times(interevent_times, length, 
			 default_length);
  make_widgets(parent);
  newtest();
}

void independecetesting::create(widget parent, 
				int *seconds_since_1_1_1970, int length,
				BASE_TIME,  
				double default_length,
				double timediff_cutoff)
{
  register int i;
  DateTime dtstart(1970,1,1), *dtbuff=new DateTime[length];

  for(i=0;i<length;i++)
    dtbuff[i] = dtstart+seconds_since_1_1_1970[i];

  cleanup();
  timedifference_cutoff=timediff_cutoff;
  store_event_times(dtbuff, length, default_length);
  make_widgets(parent);
  newtest();

  delete [] dtbuff;
}


#ifdef MAIN

class main_independecetesting : public independecetesting
{
public:
  void plot_ended(void) {exit(0);}
};

void usage(void)
{
  cout << "Usage: independencetesting [-d] [-i] [-c <cutoff>] "
    "<time file>" << endl;
  cout << "Default file contains 12-digit date7time specifications" <<
	endl;
  cout << "-i toggles reading interevent times in seconds" << endl;
  cout << "-d toggles reading date/times as integer seconds after 1/1/"
    "1970" << endl;
  cout << "-c sets a cutoff time difference in order to remove "
    "strays." << endl;
  exit(0);
}

int main(int argc, char **argv)
{
  int modus=1;
  double cutoff=MISSING_VALUE;

  while(argc>2 && argv[1][0]=='-')
    {
      switch(argv[1][1])
	{
	case 'd':
	  modus=2;
	  break;
	case 'i': 
	  modus=3;
	  break;
	case 'c':
	  if(argc<3)
	    usage();

	  cutoff=atof(argv[2]);
	  argc--;
	  argv++;
	  break;
	default:
	  usage();
	  break;
	}

      argc--;
      argv++;
    }

  if(argc!=2)
    usage();
  
  mainwin mn("Independence testing", argc, argv);
  vrow v1;
  main_independecetesting it;
  v1.build(mn);
  
  int len, i=1;
  ifstream in;
  char line[1000];

  in.open(argv[1], ios::in);
  if(in.fail())
    {
      cout << "Couldn't open file " << argv[1] << endl;
      return 1;
    }
  
  in.getline(line,999);

  switch(modus)
    {
    case 1:
      {
	timelist *head=NULL, *tail=NULL;
	
	while(!in.fail())
	  {
	    char dtstr[20];
	    
	    if(isdigit(line[0]))
	      {
		if(line[8]=='/')
		  {
		    strncpy(dtstr, line, 8);
		    strncpy(dtstr+8, line+9, 4);
		    dtstr[12]='\0';
		  }
		else
		  {
		    strncpy(dtstr, line, 12);
		    dtstr[12]='\0';
		  }
		
		DateTime dt(dtstr);
		if(!dt.legal())
		  {
		    cout << "Illegal time on line number " << i << endl;
		    cout << "Exiting..." << endl;
		    return 2;
		  }
		
		tail=new timelist(tail, NULL, dt);
		if(!head)
		  head=tail;
	      }
	    
	    i++;
	    in.getline(line,999);
	  }
	
	if(!head)
	  {
	    cout << "No elements found!" << endl;
	    return 3;
	  }
	
	if(head->number_of_elements()<10)
	  {
	    cout << "Too few elements!" << endl;
	    return 4;
	  }
	
	DateTime *dts=head->getarray(len);
	it.create(v1, dts, len, MIN0, MISSING_VALUE, cutoff);
	break;
      }
    case 2:
      {
	longintlist *head=NULL, *tail=NULL;
	
	while(!in.fail())
	  {
	    int dtint;
	    
	    if(sscanf(line, "%ld", &dtint))
	      {
		tail=new longintlist(tail, NULL, dtint);
		if(!head)
		  head=tail;
	      }

	    in.getline(line,999);
	  }
  
	if(!head)
	  {
	    cout << "No elements found!" << endl;
	    return 3;
	  }
	
	if(head->number_of_elements()<10)
	  {
	    cout << "Too few elements!" << endl;
	    return 4;
	  }
	
	int *dts=head->getarray(len);
	it.create(v1, dts, len, MIN0, MISSING_VALUE, cutoff);
	
	break;
      }
    case 3:
      {
	valuelist *head=NULL, *tail=NULL;
	
	while(!in.fail())
	  {
	    double val;
	    
	    if(sscanf(line, "%f", &val))
	      {
		tail=new valuelist(tail, NULL, val);
		if(!head)
		  head=tail;
	      }

	    in.getline(line,999);
	  }
  
	if(!head)
	  {
	    cout << "No elements found!" << endl;
	    return 3;
	  }
	
	if(head->number_of_elements()<10)
	  {
	    cout << "Too few elements!" << endl;
	    return 4;
	  }
	
	double *vals=head->getarray(len);
	it.create(v1, vals, len, MIN0, MISSING_VALUE, cutoff);
	
	break;
      }
    }

  in.close();
	
  mn.Run();
}


#endif // MAIN
