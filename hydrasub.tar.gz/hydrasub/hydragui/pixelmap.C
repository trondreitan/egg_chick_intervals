/*
 * $Id: pixelmap.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/pixelmap.C $
 */


#include <hydrasub/hydragui/pixelmap.H>
#include <hydrasub/hydragui/mainwin.H>

#ifdef NVE /* NVE specific code */
#include <envirsub/path.H>
#endif // NVE

void pixelmap::build(const Widget parent,char *filename)
{
    Pixel fg,bg;
    Pixmap pcx;

    XtVaGetValues(parent,XmNforeground,&fg,XmNbackground,&bg,NULL);
    pcx=XmGetPixmap(XtScreen (parent),filename,fg,bg);
    if(pcx==XmUNSPECIFIED_PIXMAP)
	std::cout << "Couldn't load pixmap:" << filename << std::endl;
    else
    {
      w=XtVaCreateManagedWidget(filename,xmLabelGadgetClass,parent,
              XmNlabelType,XmPIXMAP,
              XmNlabelPixmap,pcx,NULL);
    }
}



void pixelmap::build(const Widget parent,char *filename,char *fground_name)
{
    Pixel fg,bg;
    Pixmap pcx;
    Display *display = XtDisplay(parent);
    Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
    XColor col;

    XParseColor(display, cmap, fground_name, &col);
    XAllocColor(display, cmap, &col);
    fg=col.pixel;

    XtVaGetValues(parent,XmNbackground,&bg,NULL);

    pcx=XmGetPixmap(XtScreen (parent),filename,fg,bg);
    if(pcx==XmUNSPECIFIED_PIXMAP)
	std::cout << "couldn't load pixmap:" << filename << std::endl;
    else
    {
	w=XtVaCreateManagedWidget(filename,xmLabelGadgetClass,parent,
              XmNlabelType,XmPIXMAP,
              XmNlabelPixmap,pcx,NULL);
    }
}

void pixelmap::build(const Widget parent,char *filename,
		     char *fground_name,char *bground_name)
{
    Pixel fg,bg;
    Pixmap pcx;
    Display *display = XtDisplay(parent);
    Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
    XColor col;

    XParseColor(display, cmap, fground_name, &col);
    XAllocColor(display, cmap, &col);
    fg=col.pixel;

    XParseColor(display, cmap, bground_name, &col);
    XAllocColor(display, cmap, &col);
    bg=col.pixel;  

    pcx=XmGetPixmap(XtScreen (parent),filename,fg,bg);
    if(pcx==XmUNSPECIFIED_PIXMAP)
	std::cout << "couldn't load pixmap:" << filename << std::endl;
    else
    {
	w=XtVaCreateManagedWidget(filename,xmLabelGadgetClass,parent,
              XmNlabelType,XmPIXMAP,
              XmNlabelPixmap,pcx,NULL);
    }
}

void pixelmap::changepic(char *filename,char *fground_name,
			 char *bground_name)
{
  Pixel fg,bg;
  Pixmap pcx;
  Display *display = XtDisplay(mainwin::toplevel);
  Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
  XColor col;
  
  XParseColor(display, cmap, fground_name, &col);
  XAllocColor(display, cmap, &col);
  fg=col.pixel;
  
  XParseColor(display, cmap, bground_name, &col);
  XAllocColor(display, cmap, &col);
  bg=col.pixel;  
  
  pcx=XmGetPixmap(XtScreen (mainwin::toplevel),filename,fg,bg);
  if(pcx==XmUNSPECIFIED_PIXMAP)
      std::cout << "couldn't load pixmap:" << filename << std::endl;
  else
    {
      XtVaSetValues(w, XmNlabelPixmap,pcx,NULL);
    }
}

void icon_header::build(const Widget parent)
{
#ifdef NVE
  pixelmap::build(parent,
		  (char*)hydraenvir::path::icon("icon.xbm").c_str(),
		  "red","white");
#else
  char str[200];
  sprintf(str,"%s/%s",ICONDIR,"icon.xbm");
  pixelmap::build(parent,str,"red","white");
#endif // NVE
}

void icon_small::build(const Widget parent)
{
#ifdef NVE
  pixelmap::build(parent,
		  (char*)hydraenvir::path::icon("icon_small.xbm").c_str(),
		  "red","white");
#else
  char str[200];
  sprintf(str,"%s/%s",ICONDIR,"icon_small.xbm");
  pixelmap::build(parent,str,"red","white");
#endif // NVE
}
