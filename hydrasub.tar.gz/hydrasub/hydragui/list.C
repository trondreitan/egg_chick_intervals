/*
 * $Id: list.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/list.C $
 */

#include <hydrasub/hydragui/list.H>
#include <hydrasub/hydragui/color.H>

#include <Xm/List.h>
#include <X11/keysym.h>
#include <Xm/XmStrDefs.h>

// ##############################################################
// Return    : none
// Parameters: none
// Purpose   : Initializes the list object
// ##############################################################

list::list() 
{
  pos=0;
  v=NULL;
}

// ###############################################################
// Return    : void
// Parameters: name - resourcename
//             parent - my parent
// Purpose   : Generates a list widget
// ###############################################################

void list::init(const char *name, const WidgetClass, const Widget parent)
{
  xchar na(name);
  w = XmCreateScrolledList(parent, na, args, no_args);
  Map();
} /* init */

// ###############################################################
// Return    : void
// Parameters: parent - my parent
//             rows - no of visible rows
// Purpose   : Builds a list widget. Make no. of rows visible as
//             specified by parameter rows. Set backgroundcolor to
//             an another color than default color. Also put on
//             scrollbar when needed.
// ###############################################################


void list::build(const Widget parent, int rows, int hor_scrollbar)
{
  // XtAppContext appl=mainwin::app;
  // XtActionsRec action;
  // String tran="<Key>Return:    onreturn()";
  XmInitSetArg(XmNvisibleItemCount,   rows);
  XmSetArg(XmNbackground,             motifsubcolors[BISQUE2]);
  XmSetArg(XmNforeground,             motifsubcolors[BLACK]);
  XmSetArg(XmNselectionPolicy,        selectionPolicy());
  XmSetArg(XmNscrollBarDisplayPolicy, XmSTATIC);
  if(hor_scrollbar)
    {
      XmSetArg(XmNlistSizePolicy,XmCONSTANT);
    }

  init("list", NULL, parent);
  
  // action.string="onreturn";
  // action.proc=(XtActionProc)list ::onreturn;
  // XtAppAddActions(appl,&action,1);
  // XtOverrideTranslations(w,XtParseTranslationTable(tran));
  // Set up for callback.
  XtAddCallback(w, XmNsingleSelectionCallback, 
		(XtCallbackProc)&list::OneHitCB, 
		(XtPointer) this); 
  
  XtAddCallback(w, XmNmultipleSelectionCallback, 
		(XtCallbackProc)&list::OneHitCB, 
		(XtPointer) this); 
} /* build */





void list::onreturn(Widget	/* wid */ ,
		    XEvent*	/* event */,
		    String*	/* params */, 
		    Cardinal*	/* num_param */)
{

} 

// ############################################################
// Return    : void
// Parameters: pt - pointer to which class I exist in.
//             l - listcallback pointer which holds information about
//                 which element in list was selected
// Purpose   : Every time an element is selected, this routine
//             is called, which again calls OneHit() routine in
//             list object pointed by pointer pt.
//             We send ower position and the text for the selected elem.
// ############################################################
void list::OneHitCB(Widget , list *pt, XmListCallbackStruct *l)
{
  if(pt->v) 
    { 
      XtFree(pt->v); 
      pt->v = NULL; 
    }
  XmStringGetLtoR(l->item, XmSTRING_DEFAULT_CHARSET, &(pt->v));
  pt->OneHit(l->item_position, pt->v);
  XmListUpdateSelectedList(pt->w);
} /* OneHitCB */

// ######################################################################
// ## Adding to list
// ######################################################################

// ######################################################################
// Return    : list &
// Parameters: text - text to be added
// Purpose   : Add text at the end of list
// ######################################################################
list &list::operator+=(const char *text) 
{
    XmString item = XmStringCreateSimple((char*)text);
  XmListAddItem(w, item, pos++);
  XmStringFree(item);
  XmListUpdateSelectedList(w);
  
  return *this;
} /* operator += */


// ######################################################################
// Return    : void
// Parameters: str - text to be added
// Purpose   : Add text at the end of list
// ######################################################################
void list::Insert(const char *str)
{
  xmstring xstr((char*)str);
  XmListAddItem(w, (XmString &)xstr, NoInList() + 1);
  XmUpdateDisplay(w);
  XmListUpdateSelectedList(w);
} /* Insert */

void list::Change(const char *oldstr, const char *newstr)
{
  xmstring xoldstr((char*)oldstr), xnewstr((char*)newstr);
  XmListReplaceItems(w, (XmString *) &xoldstr, 1, (XmString *) &xnewstr);
  XmListUpdateSelectedList(w);
} /* Change */

void list::Change(int pos, const char *newstr)
{
  char **str;

  Get(&str);

  Change(str[pos], newstr);
  XmListUpdateSelectedList(w);
  /* this routine will leak memory */
} /* Change */

 
// ######################################################################
// Return    : void
// Parameters: text - pointer to a list of texts
//             len - no of lines in text
// Purpose   : Update list with text
// ######################################################################
void list::Inserts(char const* const* text, int len, bool deleteall_previous) 
{
  XmString *str = new XmString[len];
  int i;

  if(deleteall_previous)
    XmListDeleteAllItems (w);
    
  for(i = 0; i < len; i++) 
      str[i] = (XmString)XmStringCreateLtoR((char*)text[i], XmSTRING_DEFAULT_CHARSET);
   
  XmListAddItems (w, str, i, 1);
  for(i = 0; i < len; i++)
    if(str[i])
      XmStringFree(str[i]);
  delete [] str;

  XmListUpdateSelectedList(w);
} /* Inserts */


// ######################################################################
// ## Remove from list
// ######################################################################

// ######################################################################
// Return    : void
// Parameters: pos - position in list
// Purpose   : Remove element at position pos
// ######################################################################
void list::Delete(int pos) 
{
  XmListDeletePos(w, pos);
} /* Delete */


// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Empty list
// ######################################################################
void list::Clear()
{
  if(NoInList()>0)
    XmListDeleteAllItems (w);
} /* Clear */

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Remove all elements which are marked
// ######################################################################
void list::ClearSelected()
{
  int *pos_list, pos_count;
  pos_count=Selected(&pos_list);

  if(pos_count>0)
    XmListDeletePositions (w, pos_list, pos_count);
} /* ClearSelected */


// ######################################################################
// ## Marking
// ######################################################################

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Make the hole list marked
// ######################################################################
void list::MarkAll(bool policy)
{
  if(policy)
    {
      for(int i = 0; i < NoInList(); i++)
	{
	  if(!XmListPosSelected(w,i+1))
	    XmListSelectPos(w, i+1, policy);
	}
    }
  else
    {
      for(int i = 0; i < NoInList(); i++)
	if(!XmListPosSelected(w,i+1))
	  XmListSelectPos(w, i+1, policy);
    }
} /* MarkAll */

// ######################################################################
// ## Remove marks
// ######################################################################

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Remove all marks
// ######################################################################
void list::RemoveMarks()
{
  for(int i = 0; i < NoInList(); i++)
    if(XmListPosSelected(w,i+1))
      XmListDeselectPos(w,i+1);
} /* RemoveMarks */

// ######################################################################
// Return    : void
// Parameters: pos - positition of the marked text
// Purpose   : Make a single row
// ######################################################################
void list::Mark(int pos)
{ 
  if(pos<=0 || pos>NoInList())
    {
	std::cerr << "Position " << pos << " does not exist in the list!" << std::endl;
      return;
    }

  if(!XmListPosSelected(w,pos))
    XmListSelectPos(w, pos, False);
} /* Mark */

// ######################################################################
// Return    : void
// Parameters: pos - positition of the de-marked text
// Purpose   : Remove the mark on a single row
// ######################################################################
void list::RemoveMark(int pos)
{ 
  if(XmListPosSelected(w,pos))
    XmListDeselectPos(w,pos);
} /* Mark */

// ######################################################################
// ## Selections
// ######################################################################

// ######################################################################
// Return    : int - position
// Parameters: void
// Purpose   : Returns position of the first one selected
// ######################################################################
int list::Selected()
{
  int i = 0;
  int *pos_list, pos_no;
  XmListUpdateSelectedList(w);
  if(XmListGetSelectedPos(w, &pos_list, &pos_no)) 
    {
      if(pos_no > 0) 
	{
	  i = pos_list[0];
	  //free(pos_list);
	  //delete [] pos_list;
        }
    }
  return (i - 1);
} /* Selected */

// ######################################################################
// Return    : int
// Parameters: pos_list - an array of elementspos which ar marked
// Purpose   : Return a list elements marked by user
// ######################################################################
int list::Selected(int **pos_list)
{
  int no;
  XmListUpdateSelectedList(w);
  XmListGetSelectedPos(w, pos_list, &no);
  return no;
} /* Selected */


// ######################################################################
// ## Check for exsistence
// ######################################################################

// ######################################################################
// Return    : int - 1 exist, 0 - not exist
// Parameters: str - element to search for
// Purpose   : Check for excistence in list.
// ######################################################################
int list::ExistInList(const char *str)
{
    xmstring xstr((char*)str);
  return XmListItemExists(w, (XmString &)xstr);
} /* ExistInList */


// ######################################################################
// ## Set mark
// ######################################################################

// ######################################################################
// Return    : void
// Parameters: pos - position to element to be selected
// Purpose   : Marks an element
// ######################################################################
void list::SetActive(int pos)
{
  XmListSetPos(w, pos);
  XmListSelectPos(w, pos, True);
} /* SetActive */

// ######################################################################
// ## No. 
// ######################################################################

// ######################################################################
// Return    : int
// Parameters: void
// Purpose   : Return no. of elements in list
// ######################################################################
int list::NoInList()
{
  int no;
  XtVaGetValues(w, XmNitemCount, &no, NULL);
  return no;
} /* NoInList */


// ######################################################################
// Return    : int
// Parameters: 
// Purpose   : 
// ######################################################################
#include <iostream>
int list::Get(char*** str)
{
  XmStringTable str_list;
  int no;
  
  XtVaGetValues(w,
		XmNitems, &str_list,
		XmNitemCount, &no,
		NULL);
  
  if(no) 
    {
      (*str) = new char*[no];
      for(int i = 0; i < no; i++) 
	{
	  XmStringGetLtoR(str_list[i], XmFONTLIST_DEFAULT_TAG, &(*str)[i]);
	}
    }
  return no;
} /* Get */

#ifdef MAIN
#include <hydrasub/hydragui/row.H>

static char *stri[] = {
    "a", "a", "a", "a", "a", 
    "b", "a", "a", "a", "a", 
    "c", "a", "a", "a", "a"
};

int main(int argc, char **argv) {
    XtAppContext app;
    char *str = "Test av menu";
    vrow v;

    list l;

    Widget toplevel = XtVaAppInitialize(&app, "dagut",
                                        NULL, 0,
                                        &argc, 
                                        argv, 
                                        NULL, 
                                        XmNtitle, str, 
                                        NULL);
    InitColor(toplevel);
    v.build(toplevel);
    l.build(v, 10);
    l.Inserts(stri, 15);

    XtRealizeWidget(toplevel);
    XtAppMainLoop(app);

    return 0;
}

#endif
