/*
 * $Id: PrinterList.C 2634 2016-01-26 14:59:22Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/PrinterList.C $
 */

#include <fstream>
#include <hydrasub/hydrabase/divfunc.H>
#include <hydrasub/hydragui/PrinterList.H>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
#include <ctype.h>

#define PRINTCAP "/etc/printcap"

#ifdef NVE /* NVE specific code */

#include <sysub/fd_ofstream.H>

// ######################################################################
// class Printer
// ######################################################################

// This class tries to retrieve list of available printers
// It depends on calling system commands
class Printer {

  // All printers found are stored in this vector
  std::vector<std::string> printers;

  // Run the system commands and try to find printers
  // The command should only give one printer per line
  void discover(char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (pipe == NULL) {
      return;
    }
    fd_ifstream str(pipe);
    std::string printername;
    while (str >> printername) {
      printers.push_back(printername);
    }
    pclose(pipe);
  }
public:
  Printer() {
    // Use lpstat to find printers.
    discover("/usr/bin/lpstat -a|/usr/bin/cut -d ' ' -f 1 "
	     "| /usr/bin/sort");
  }

  // Return true or false if printername is a known one
  // The match is case sensitive
  bool exists(std::string printername) {
    for (unsigned int i = 0; i < printers.size(); i++) {
      if(printername.compare(printers[i]) == 0) {
	return true;
      }
    }
    return false;
  }

  // Return number of printers found
  unsigned int no() {
    return printers.size();
  }

  // Return the printer list as a double char array.
  // Caller is responsible for deleting
  char** lists() {
    char** c_list = new char*[printers.size()];
    for (unsigned int i = 0; i < printers.size(); i++) {
      c_list[i] = new char[printers[i].size() + 1];
      strcpy(c_list[i], printers[i].c_str());
    }
    return c_list;
  }
};

static Printer printers;

#endif // NVE

// ######################################################################

bool findprinter(const char *printername)
{
#ifdef NVE
  return printers.exists(printername) ? True : False;
#else
  std::ifstream printcap;

  if(!printername)
    return False;

  printcap.open(PRINTCAP);
  while(!printcap.eof())
    {
      char line[1000],prname[100],*lineptr;
      char *prptr=prname;
      printcap.getline(line,999);

      if (strlen(line) == 0)
	continue;		// Ignore empty lines
      if (isspace(line[0]))
	continue;		// Ignore lines starting with empty content
      if (line[0] == '#')
	continue;		// Ignore lines strating with tab

      lineptr = line;
      while(*lineptr!='\0' && *lineptr!=':' && *lineptr!='|')
	{
	  *prptr=*lineptr;
	  lineptr++;
	  prptr++;
	}
      *prptr='\0';
      
      if(!strncmp(printername, prname, MINIM(strlen(prname), 
					     strlen(printername))))
	return True;
    }

  printcap.close();
  return False;
#endif // not NVE
}



void printsize_button::Create(widget parent, const char *txt, printsize *ipt, 
			      PRINTSIZE_BUTTONTYPE type)
{
  build(parent,txt);
  pt=ipt;
  typ=type;
}

void printsize_button::pushed(void)
{
  pt->button_pushed(typ);
}


printsize::printsize()
{
  sizes=NULL;
  len=0;
}

printsize::~printsize()
{
  cleanup();
}

void printsize::cleanup(void)
{
  len=0;
  if(sizes)
    delete [] sizes;
  sizes=NULL;
}

void printsize::button_pushed(PRINTSIZE_BUTTONTYPE type)
{
  switch(type)
    {
    case PRINTSIZE_OKB:
      {
	int size;
	if(!get_size(&size))
	  return;
	ok(size);
	break;
      }
    case PRINTSIZE_CANCELB:
      cancel();
      break;
    }

  Unmap();
}

bool printsize::get_size(int *size)
{
  int sel=sizelist.Selected();
  if(sel==-1)
    {
      err.build(*this,"Feil", "Ingen st�rrelse er valgt!");
      return False;
    }

  *size=sizes[sel];
  return True;
}

void printsize::Create(int origsize, int *size_array, int array_length)
{
  int i;
  cleanup();

  len=array_length;
  sizes=new int[len];
  for(i=0;i<len;i++)
    sizes[i]=size_array[i];
  
  build(mainwin::toplevel, "Valg av utskrifts-st�rrelse");
  
  v1.build(*this);
  lab.build(v1,"Valg av utskrifts-st�rrelse:");
  lab.Background("white");
  lab.Foreground("black");
  sizelist.build(v1,7);
  
  sep1.build(v1);
  h1.build(v1);
  okb.Create(h1, "OK", this, PRINTSIZE_OKB);
  okb.Background("green");
  okb.Foreground("black");
  cancelb.Create(h1, "Avbryt", this, PRINTSIZE_CANCELB);
  cancelb.Background("red");
  cancelb.Foreground("white");

  for(i=0;i<len;i++)
    {
      char item[10];
      sprintf(item,"%d",sizes[i]);
      sizelist.Insert(item);
      if(sizes[i]==origsize)
	sizelist.Mark(i+1);
    }

  Map();
}



printerlist::printerlist()
{
#ifdef NVE
  printername = printers.lists();
  numprinters = printers.no();
#else
  printername=NULL;
  numprinters=0;
#endif // not NVE
  visited=false;
}

printerlist::~printerlist()
{
  doubledelete(printername,numprinters);
}
 
void printerlist::Create(Widget parent,const char *defaultprinter)
{
  char printer[100];

  if(!visited)
    build(parent,10);
  else
    Clear();
  visited=true;
  
  if(!defaultprinter)
    {
      strcpy(printer,getenv("PSPRINTER"));
      if(printer[0]==' ' || printer[0]=='\0')
	strcpy(printer,getenv("PRINTER"));
      //if(printer[0]==' ' || printer[0]=='\0')
      //strcpy(printer,"n3p");
    }
  else
    strcpy(printer,defaultprinter);
  
#ifndef NVE
  std::ifstream printcap;
  stringlist *head=NULL,*tail=NULL,*sorted_head;
  printcap.open(PRINTCAP);
  while(!printcap.eof())
    {
      char line[1000],prname[100],*lineptr;
      char *prptr=prname;
      printcap.getline(line,999);

      if (strlen(line) == 0)
	continue;		// Ignore empty lines
      if (isspace(line[0]))
	continue;		// Ignore lines starting with empty content
      if (line[0] == '#')
	continue;		// Ignore lines strating with tab

      lineptr = line;
      while(*lineptr!='\0' && *lineptr!=':' && *lineptr!='|')
	{
	  *prptr=*lineptr;
	  lineptr++;
	  prptr++;
	}
      *prptr='\0';
      
      if(!head)
	head=tail=new stringlist(prname);
      else
	tail=new stringlist(tail,NULL,prname);
    }
  printcap.close();

  
  if(head)
    {
      int i=0;
      head=order_stringlist(head,ORDER_LEAST);

      numprinters=head->number_of_elements();
      printername=new char*[numprinters];

      for(stringlist *ptr=head;ptr && i<numprinters;
          ptr=(stringlist *) ptr->getnext())
        {
          printername[i]=new char[100];
          strcpy(printername[i], ptr->getstring());
          
          //if(!strncasecmp(printername[i], 
          //      printer,strlen(printer)))
          //pos=i;
          
          i++;
        }

      delete head;
    }

#endif

  Inserts(printername, numprinters);
  
  setprinter(printer, true);
}

void printerlist::setprinter(const char *printer, bool nowarn)
{
  bool found=False;

  for(int i=0;i<numprinters;i++)
    if(!strcasecmp(printer,printername[i]))
      {
	Mark(i+1);
	found=True;
      }

  if(!found && !nowarn)
    {
      char errmsg[100];
      sprintf(errmsg, WHAT((char *) "Fant ikke skriveren \"%s\" i listen!",
			   (char *) "Could not find the printer "
			   "\"%s\" in the list!"), printer);

      err.build(mainwin::toplevel, WHAT((char *) "Feil",(char *) "Error"),
		errmsg);
      return;
    }
}

char *printerlist::getprinter(int *status)
{
  int sel=Selected();

  *status=0;
  if(sel<0)
    {
      *status=1;
      return NULL;
    }
  
  return printername[sel];
}

void printershellbutton::Create(Widget parent,const char *text,printershell *ipt,
				PRINTERBUTTON type)
{
  pt=ipt;
  typ=type;
  build(parent,text);
}

void printershellbutton::pushed(void)
{
  pt->buttonpushed(typ);
} 

printershell::printershell()
{
  created=false;
}

void printershell::buttonpushed(PRINTERBUTTON type)
{
  switch(type)
    {
    case PRINTSHELL_OK:
      {
	int status;
	char *prname;

	prname=plist.getprinter(&status);
	if(status)
	  {
	    err.build(*this,"Feil","Ingen skriver er avmerket!");
	    return;
	  }
	ok_pushed(prname);
	Unmap();
	break;
      }
    case PRINTSHELL_CANCEL:
      Unmap();
      break;
    }
}

void printershell::Create(const char *defaultprinter)
{
  if(!created)
    {
      build(mainwin::toplevel,"Valg av skriver:");
      
      v1.build(*this);
      plist.Create(v1,defaultprinter);
      h1.build(v1);
      
      cancelb.Create(h1,"Avbryt",this,PRINTSHELL_CANCEL);
      cancelb.Background("red");
      cancelb.Foreground("white");
      okb.Create(h1,"OK",this,PRINTSHELL_OK);
      okb.Background("green");
      okb.Foreground("black");
      
      created=true;
    }
  
  Map();
}



void allprintershellbutton::Create(Widget parent,const char *text,
				   allprintershell *ipt)
{
  pt=ipt;
  build(parent,text);
}

void allprintershellbutton::pushed(void)
{
  pt->buttonpushed();
} 

void allprintertoggle::Create(Widget parent, allprintershell *ipt)
{
  pt=ipt;
  char *selitems[]={"Sort/hvitt-skriver","Farge-skriver"};
  hbuild(parent,selitems,2,0);
}

void allprintertoggle::pushed(const char *item)
{
  if(!strcmp(item,"Sort/hvitt-skriver"))
    pt->togglepushed(PRINTER_BW);
  else
    pt->togglepushed(PRINTER_COLOR);
}

void allprintershell::togglepushed(PRINTER_TOGGLE state)
{
  if(state==prevstate)
    return;
  if(!created)
    return;
  int status;

  switch(state)
    {
    case PRINTER_BW:
      strcpy(colprinter, plist.getprinter(&status));
      plist.setprinter(bwprinter, true);
      break;
    case PRINTER_COLOR:
      strcpy(bwprinter, plist.getprinter(&status));
      plist.setprinter(colprinter, true);
      break;
    }

  prevstate=state;
}

static char allprintershell_printer[100];
static char allprintershell_psprinter[100];
static char allprintershell_pscolprinter[100];

void allprintershell::buttonpushed(void)
{
  int status;
  char *prname;
  
  prname=plist.getprinter(&status);
  if(status)
    {
      err.build(*this,"Feil","Ingen skriver er avmerket!");
      return;
    }

  if(selcol()==0)
    strcpy(bwprinter, prname);
  else
    strcpy(colprinter, prname);

  sprintf(allprintershell_pscolprinter,"PSCOLPRINTER=%s",colprinter);
  putenv(allprintershell_pscolprinter);
  sprintf(allprintershell_printer,"PRINTER=%s", bwprinter);
  putenv(allprintershell_printer);
  sprintf(allprintershell_psprinter,"PSPRINTER=%s",bwprinter);
  putenv(allprintershell_psprinter);

  Unmap();

  printer_chosen(bwprinter, colprinter);
}


void allprintershell::Create(void)
{
  Create(getenv("PSPRINTER"), getenv("PSCOLPRINTER"));
}

void allprintershell::Create(const char *bw_printer, const char *col_printer)
{
  if(!created)
    {
      build(mainwin::toplevel,"Valg av skriver:");
      
      v1.build(*this);
      selcol.Create(v1,this);
      plist.Create(v1, bw_printer);
      if (bw_printer && strlen(bw_printer) > 0)
	strcpy(bwprinter, bw_printer);
      if (col_printer && strlen(col_printer) > 0)
	strcpy(colprinter, col_printer);
      
      h1.build(v1);
      
      cancelb.build(h1,this,"Avbryt");
      cancelb.Background("red");
      cancelb.Foreground("white");
      okb.Create(h1,"OK",this);
      okb.Background("green");
      okb.Foreground("black");

      prevstate=PRINTER_BW;

      created=1;
    }

  Map();
}

void allprintershell::printer_chosen(const char* /* bw_printer */, 
				     const char* /* col_printer */)
{

}



#ifdef MAIN
#include <hydrasub/hydragui/label.H>
class pmain;

class pbutton : public pushb
{
public:
  pmain *pt;
  void pushed(void);
};

class pshell : public printershell
{
public:
  pmain *pt;
  void ok_pushed(const char *newprinter);
};

class pmain : public mainwin
{
  pbutton okb;
  label lab;
  pshell ps;
  vrow v1;
public:
  pmain(const char *title,int &argc,char const* const* argv);
  void bpushed(void);
  void ppushed(const char *prname);
};

void pbutton::pushed(void) { pt->bpushed(); }
void pshell::ok_pushed(const char *newprinter) { pt->ppushed(newprinter); }
void pmain::bpushed(void) { ps.Create(); ps.pt=this; }
void pmain::ppushed(const char *prname) {lab.labelString(prname); }
pmain::pmain(const char *title,int &argc,char const* const* argv) : mainwin(title,argc,argv)
{
  v1.build(*this);
  lab.build(v1,"                ");
  lab.Background("white");
  okb.build(v1,"OK");
  okb.pt=this;
}

int main(int argc, char **argv)
{
  pmain pm("PrinterList -test",argc,argv);
  pm.Run();
  return 0;
}

#endif /* MAIN */

