/*
 * $Id: timer.C 1918 2011-03-23 14:25:50Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/timer.C $
 */

#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/timer.H>

timer::timer()
{}

void timer::Set(unsigned int millisec)
{
  XtAppAddTimeOut(mainwin::app,millisec,
		  (XtTimerCallbackProc)timer::timeoutCB,
		  (XtPointer)this); 
}

void timer::timeoutCB(timer *ipt,XtIntervalId*)
{ 
  ipt->wakeup();
}
