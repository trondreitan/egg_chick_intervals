/*
 * $Id: pushb.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/pushb.C $
 */


#include <hydrasub/hydragui/pushb.H>
#include <hydrasub/hydragui/color.H>
#include <fstream>
#include <hydrasub/hydrabase/divfunc.H>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::pinit(const char *title, const Widget parent)
{
  XmInitSetArg(XmNbackground, motifsubcolors[BISQUE3]);
  XmSetArg(XmNforeground, motifsubcolors[BLACK]);
  init(title, xmPushButtonWidgetClass, parent);
}

void pushb::set_title(const char *title)
{ 
  xmstring xstr(title);
  XtVaSetValues(w, XmNlabelString, (XmString &) xstr, NULL);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::build(const Widget parent, const char *title) 
{
  buttonpushed=0;
  pinit(title, parent);
  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&pushb::pushCB,
		(XtPointer)this);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::build(const Widget parent, const char *title, int in, int *out) 
{
  buttonpushed=0;
  type = 1;
  Iin = in;
  Iout = out;
  pinit(title, parent);
  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&pushb::setICB,
		(XtPointer)this);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::build(const Widget parent, const char *title, float in, float *out) 
{
  buttonpushed=0;
  type = 2;
  Fin = in;
  Fout = out;
  pinit(title, parent);
  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&pushb::setFCB,
		(XtPointer)this);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::build(const Widget parent, const char *title, const char *in, const char *out) 
{
  buttonpushed=0;
  type = 3;
  Cin = in;
  Cout = out;
  pinit(title, parent);
  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&pushb::setCCB,
		(XtPointer)this);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::pushCB(Widget , pushb *pt, XtPointer) 
{
  pt->buttonpushed=1;
  pt->pushed();
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::setICB(Widget , pushb *pt, XtPointer) 
{
  pt->setI();
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::setFCB(Widget , pushb *pt, XtPointer) 
{
  pt->setF();
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void pushb::setCCB(Widget , pushb *pt, XtPointer) 
{
  pt->setC();
}

#include <hydrasub/hydragui/mainwin.H>
void pushb::Wait(void)
{
  buttonpushed = 0;
  while(buttonpushed == 0)
    XtAppProcessEvent(mainwin::app, XtIMAll);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void arrowb::pinit(const Widget parent)
{
  XmInitSetArg(XmNbackground, motifsubcolors[BISQUE3]);
  init("arrow", xmArrowButtonGadgetClass, parent);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void arrowb::pushCB(Widget , arrowb *pt, XtPointer) 
{
  pt->pushed();
}

ARROWB_DIR arrowb::get_type(void)
{
  return arrowtype;
}

void arrowb::build(const Widget parent, ARROWB_DIR direction)
{
  arrowtype=direction;

  pinit(parent);
  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&arrowb::pushCB,
		(XtPointer)this);

  switch(direction)
    {
    case ARROWB_LEFT:
      XtVaSetValues(w,XmNarrowDirection, XmARROW_LEFT, NULL);
      break;
    case ARROWB_RIGHT:
      XtVaSetValues(w,XmNarrowDirection, XmARROW_RIGHT, NULL);
      break;
    case ARROWB_UP:
      XtVaSetValues(w,XmNarrowDirection, XmARROW_UP, NULL);
      break;
    case ARROWB_DOWN:
      XtVaSetValues(w,XmNarrowDirection, XmARROW_DOWN, NULL);
      break;
    }
}




// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void drawnb::pushCB(Widget , drawnb *pt, XtPointer) 
{
  pt->pushed();
}

void drawnb::exposeCB(Widget , drawnb *pt, XtPointer) 
{
  pt->expose();
}

void drawnb::resizeCB(Widget , drawnb *pt, XtPointer) 
{
  pt->resize();
}

#include <iostream>
#include <hydrasub/hydragui/mainwin.H>
void drawnb::build(const Widget parent, const char *filename, 
		   const char *background, const char *foreground)
{
  Pixel fg,bg;
  
  Dimension width, height;
  Dimension ht, st;
  Display *display;
  Screen *screen;

  display = XtDisplay(parent);
  Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
  XColor col;

  XmInitSetArg(XmNbackground, motifsubcolors[BISQUE3]);
  XtVaGetValues(mainwin::toplevel, XmNforeground ,&fg, XmNbackground, &bg, 
		NULL);
  if(foreground)
    {
      XParseColor(display, cmap, foreground, &col);
      XAllocColor(display, cmap, &col);
      fg=col.pixel;
    }
  
  if(background)
    {
      XParseColor(display, cmap, background, &col);
      XAllocColor(display, cmap, &col);
      bg=col.pixel;  
    }
  
  
  screen=XtScreen(parent);
  pcx=XmGetPixmap(screen, (char*)filename, fg, bg);
  v1.build(parent);
  h1.build(v1);
  w=XtVaCreateManagedWidget(filename,xmDrawnButtonWidgetClass, h1,
              XmNlabelType, XmPIXMAP,
              XmNlabelPixmap,pcx,NULL);
  

  std::ifstream in;
  char line[100], *ptr;
  int x,y;
  in.open(filename, std::ios::in);
  in.getline(line,99);
  ptr=strstr(line, "width");
  sscanf(ptr+6, "%d", &x);
  width=(Dimension) x;
  in.getline(line,99);
  ptr=strstr(line, "height");
  sscanf(ptr+7, "%d", &y);
  height=(Dimension) y;
  in.close();

  XtVaGetValues(w, XmNhighlightThickness, &ht,
		XmNshadowThickness, &st, NULL);

  XtVaSetValues(w, XmNheight, 2*ht + 2*st + height,
		XmNwidth, 2*ht + 2*st + width, NULL);
  Foreground(fg);
  Background(bg);

  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&drawnb::pushCB,
		(XtPointer)this);
  XtAddCallback(w, XmNresizeCallback, 
		(XtCallbackProc)&drawnb::resizeCB,
		(XtPointer)this);
  
  XtAddCallback(w, XmNexposeCallback, 
		(XtCallbackProc)&drawnb::exposeCB,
		(XtPointer)this);
}

void drawnb::resize(void)
{
  expose();
}

void drawnb::expose(void)
{
  //win=XtWindow(mainwin::toplevel);

  //XCopyArea(XtDisplay(w), pcx, XtWindow(mainwin::toplevel), 
  //    XDefaultGCOfScreen(XtScreen(w)),
  //    0, 0, width, height, ht+st, ht+st);
  XtVaSetValues(w, XmNlabelPixmap, pcx, NULL);
}

void exitbutton::Create(widget parent, const char *txt)
{
  build(parent, txt ? txt :
	WHAT((char *) "Avslutt", (char *) "Exit"));
  Background("red");
  Foreground("white");
}
    
void exitbutton::pushed(void)
{
  exit(0);
}
