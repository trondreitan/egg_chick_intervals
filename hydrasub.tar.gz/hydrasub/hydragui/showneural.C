/*
 * $Id: showneural.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/showneural.C $
 */

#include <hydrasub/hydragui/showneural.H>
#include <cmath>
#include <hydrasub/hydrabase/divfunc.H>


// *********************************************
//
//                   SHOWNODE
//
// Shows a single node and holds the the
// threads out of the node.
//
// *********************************************

void shownode::Create(node *nd, showneural *ipt, double xx, double yy,
		      bool input, bool output)
{
  nodeparent = nd;
  drawparent = ipt;
  x = xx;
  y = yy;
  inputnode=input;
  outputnode=output;
  held=False;
}

void shownode::findthreads(shownode *nodes, int numnodes)
{
  threadlist *thlist = nodeparent->get_out_threads();
  int i=0;

  numoutthreads = thlist->number_of_elements();
  outthreads    = new showthread[numoutthreads];
  
  for( ; thlist; thlist=thlist->get_next_threadlistelement())
    {
      thread *th=thlist->get_thread();
      shownode *dest=NULL;
      
      for(int j=0; j<numnodes && !dest; j++)
	if(nodes[j].nodeparent == th->get_dest())
	  dest=nodes+j;

      if(dest)
	outthreads[i++].Create(th, drawparent, this, dest);
    }
}

void shownode::increment(shownode *nodes, int numnodes)
{
  register int i;
  double dx=0.0, dy=0.0, g1=50.0*50.0, g2=1/500.0;

  for(i=0;i<numnodes;i++)
    {
      if(nodes+i != this)
	{
	  double r2=(x - nodes[i].x)*(x - nodes[i].x) + 
	    (y - nodes[i].y)*(y - nodes[i].y);
	  double r3=pow(r2, 3.0/2.0);

	  double ddx = g1*(x - nodes[i].x)/r3;
	  double ddy = g1*(x - nodes[i].x)/r3;

	  dx += ddx;
	  dy += ddy;
	}
    }

  for(i=0; i<numoutthreads; i++)
    {
      shownode *dest=outthreads[i].get_dest();
      double ddx = -g2*(dest->x - x);
      double ddy = -g2*(dest->y - y);
      
      dx -= ddx;
      dy -= ddy;

      if(!dest->inputnode && !dest->outputnode && !dest->held)
	{
	  dest->x += ddx;
	  dest->y += ddy;
	}
      else
	{
	  //dx -= ddx;
	  //dy -= ddy;
	}
    }
    
  dx += 100.0/(x*x);
  dy += 100.0/(y*y);

  dx -= 100.0/((drawparent->sizex-x)*(drawparent->sizex-x));
  dy -= 100.0/((drawparent->sizex-y)*(drawparent->sizex-y));

  if(!inputnode && !outputnode && !held)
    {
      x += dx;
      y += dy;
    }
}

void shownode::start_increment(void)
{
  oldx=x;
  oldy=y;
}

void shownode::end_increment(void)
{
  show(False);
  show(True);
}

int colorlimit(int colorindex)
{
  if(colorindex<0)
    return 0;
  
  if(colorindex>255)
    return 255;

  return colorindex;
}

void shownode::show(bool dodraw)
{
  int i, xx,yy,x0,y0;
  char color[20];

  if(!dodraw)
    drawparent->translate(oldx, oldy, &x0, &y0, True);
  else
    drawparent->translate(x, y, &x0, &y0, False);

  if(!dodraw)
    sprintf(color, "black");
  else
    {
      int red   = (int) (127.0+10.0*log(nodeparent->get_state())); 
      int green = (int) (127.0+10.0*log(nodeparent->get_fire())); 
      int blue  = (int) (127.0+10.0*log(ABSVAL(nodeparent->get_gamma()))); 

      red=colorlimit(red);
      green=colorlimit(green);
      blue=colorlimit(blue);

      sprintf(color, "#%02x%02x%02x", red, green, blue);
    }

  drawparent->SetFg(color);
  for(xx=-5;xx<=5;xx++)
    for(yy=-5;yy<=5;yy++)
      if(xx*xx+yy*yy<25)
	drawparent->Point(x0+xx,y0+yy);

  if(dodraw)
    {
      drawparent->SetFg("white");
      for(xx=-5;xx<=5;xx++)
	for(yy=-5;yy<=5;yy++)
	  if(xx*xx+yy*yy>16 && xx*xx+yy*yy<25)
	    drawparent->Point(x0+xx,y0+yy);
    }

  for(i=0;i<numoutthreads;i++)
    outthreads[i].show(dodraw);
}


double shownode::get_x(void)
{
  return x;
}

double shownode::get_y(void)
{
  return y;
}

double shownode::get_oldx(void)
{
  return oldx;
}

double shownode::get_oldy(void)
{
  return oldy;
}

bool shownode::Hit(double xhit, double yhit)
{
  int x0,y0,x1,y1;

  drawparent->translate(x,y,&x0,&y0);
  drawparent->translate(xhit, yhit, &x1, &y1);

  if(((x0-x1)*(x0-x1)+(y0-y1)*(y0-y1)) < 25)
    return True;
  else
    return False;
}

void shownode::Hold(double holdx, double holdy)
{
  held=True;
  x=holdx;
  y=holdy;
}

void shownode::StopHold(void)
{
  held=False;
}



// *********************************************
//
//               SHOWTHREAD
//
// Shows a singel thread hoing from one 
// "shownode" object to another.
//
// *********************************************

void showthread::Create(thread *th, showneural *ipt, 
			shownode *orig_, shownode *dest_)
{
  threadparent=th;
  drawparent=ipt;
  orig=orig_;
  dest=dest_;
}

void showthread::show(bool dodraw)
{
  int x0, y0, x1, y1;

  if(!dodraw)
    {
      drawparent->translate(orig->get_oldx(), orig->get_oldy(), &x0, &y0, True);
      drawparent->translate(dest->get_oldx(), dest->get_oldy(), &x1, &y1, True);
    }
  else
    {
      drawparent->translate(orig->get_x(), orig->get_y(), &x0, &y0);
      drawparent->translate(dest->get_x(), dest->get_y(), &x1, &y1);
    }

  double x0buff, y0buff, x1buff, y1buff;
  double rad = sqrt((double)((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)));
  static double pi=3.141592653;
  static double cos1 = cos(2.0*pi*30.0/360.0), 
    cos2 = cos(-2.0*pi*30.0/360.0);
  static double sin1 = sin(2.0*pi*30.0/360.0), 
    sin2 = sin(-2.0*pi*30.0/360.0);

  x0buff = x0 + 5.0 * ((double) (x1-x0))/rad;
  y0buff = y0 + 5.0 * ((double) (y1-y0))/rad;
  x1buff = x1 + 5.0 * ((double) (x0-x1))/rad;
  y1buff = y1 + 5.0 * ((double) (y0-y1))/rad;

  x0=(int) x0buff;
  y0=(int) y0buff;
  x1=(int) x1buff;
  y1=(int) y1buff;
  rad = sqrt((double)((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)));

  x0buff = x1 + 15.0 * (((double) (x0-x1))*cos1/rad+
			((double) (y0-y1))*sin1/rad);
  y0buff = y1 + 15.0 * (((double) (y0-y1))*cos1/rad-
			((double) (x0-x1))*sin1/rad);
  x1buff = x1 + 15.0 * (((double) (x0-x1))*cos2/rad+
			((double) (y0-y1))*sin2/rad);
  y1buff = y1 + 15.0 * (((double) (y0-y1))*cos2/rad-
			((double) (x0-x1))*sin2/rad);

  char color[20];
  if(!dodraw)
    strcpy(color, "black");
  else
    {
      int red, green, blue; 
      
      red = (int) (127.0 + 50.0*threadparent->get_strength());  
      red=green=colorlimit(red);
      blue = colorlimit((int) (255.0-255.0*threadparent->get_fire()));
      
      sprintf(color, "#%02x%02x%02x", red ,green, blue);
    }
  
  drawparent->SetFg(color);
  drawparent->Line(x0, y0, x1, y1);
  drawparent->Line(x1, y1, x0buff, y0buff);
  drawparent->Line(x1, y1, x1buff, y1buff);
}



// *********************************************
//             
//                 SHOWNEURAL
//
// This is a subclass of "draw". It takes
// a neural net as input and shows the nodes
// and threads of that net graphically in the
// draw widget.
//
// *********************************************

void showneural::translate(double x, double y, int *x0, int *y0, 
			   bool oldcoord)
{
  if(oldcoord)
    {
      *x0 = (int) ((x-oldminx)/((double) (oldmaxx-oldminx)) * (double) sizex);
      *y0 = (int) ((y-oldminy)/((double) (oldmaxy-oldminy)) * (double) sizey);
    }
  else
    {
      *x0 = (int) ((x-minx)/((double) (maxx-minx)) * (double) sizex);
      *y0 = (int) ((y-miny)/((double) (maxy-miny)) * (double) sizey);
    }
}

void showneural::expose()
{
  if(first)
    show();
  first=False;
}

showneural::showneural() : draw(), timer()
{
  first=True;
  num=0;
}

void showneural::show(void)
{
  register int i;
  
  do_copy();
  findnewlimits();

  for(i=0;i<numnodes;i++)
    nodes[i].start_increment();

  for(i=0;i<numnodes;i++)
    nodes[i].increment(nodes, numnodes);

  for(i=0;i<numnodes;i++)
    nodes[i].end_increment();

  for(i=0;i<numnodes;i++)
    nodes[i].show(True);

  Set(2);
}


void showneural::wakeup(void)
{
  show();
}

void showneural::findnewlimits(void)
{
  oldminx=minx;
  oldminy=miny;
  oldmaxx=maxx;
  oldmaxy=maxy;

  minx = maxx = nodes[0].get_x();
  miny = maxy = nodes[0].get_y();

  for(register int i=1; i<numnodes; i++)
    {
      minx=MINIM(minx, nodes[i].get_x());
      maxx=MAXIM(maxx, nodes[i].get_x());
      miny=MINIM(miny, nodes[i].get_y());
      maxy=MAXIM(maxy, nodes[i].get_y());
    }

  minx -= 0.05 * (maxx-minx);
  maxx += 0.05 * (maxx-minx);

  miny -= 0.05 * (maxy-miny);
  maxy += 0.05 * (maxy-miny);

  //cout << FORM("( %f , %f ) - (%f, %f )", minx, miny, maxx, maxy) << endl; 
}

void showneural::recreate(neuralnet &nn)
{
  node **allnodes=nn.get_all_nodes(&numnodes);
  register int i;

  nodes=new shownode[numnodes];
  activenode=NULL;

  for(i=0;i<numnodes;i++)
    {
      bool input = i<nn.get_num_input() ? True : False;
      bool output = i>(numnodes-nn.get_num_output()-1) ? True : False;

      double xx = drand48() * sizex;
      double yy = drand48() * sizey;
      
      if(input) 
	{
	  xx = ((double) i) / ((double) nn.get_num_input() - 1) *
	    ((double) sizex);
	  yy = sizey;
	}
      else if(output)
	{
	  xx = ((double) (numnodes-i-1)) / ((double) nn.get_num_output() - 1) *
	    ((double) sizex);
	  yy = 0;
	}

      nodes[i].Create(allnodes[i], this, xx, yy, input, output);
    }

  for(i=0; i<numnodes; i++)
    nodes[i].findthreads(nodes, numnodes);
}

void showneural::Create(widget parent, int sizex_, int sizey_, neuralnet &nn)
{
  sizex = sizex_;
  sizey = sizey_;
  recreate(nn);
  build(parent, sizex_, sizey_, True);
}

void showneural::DoButton1(int /* x */, int /* y */)
{
  activenode = NULL;
}

void showneural::translate_back(int x, int y, double *xx, double *yy)
{
  *xx = minx + ((double) x)/((double) sizex)*(maxx-minx);
  *yy = miny + ((double) y)/((double) sizey)*(maxy-miny);
}

int showneural::get_node_hit(int x , int y )
{
  bool hit = False;
  double xx, yy;
  register int i;

  translate_back(x, y, &xx, &yy);

  for(i=0; i<numnodes && !hit; i++)
    hit=nodes[i].Hit(xx,yy);
    
  if(hit)
    return i-1;
  else
    return -1;
}

void showneural::DoButton2(int /* x */, int /* y */)
{
  activenode = NULL;
}

void showneural::DoButton3(int /* x */, int /* y */)
{
  activenode = NULL;
}

void showneural::draw_motion_object(int /* x1 */,int /* y1 */, int x2, int y2)
{
  int i;

  do_copy();
  if(!activenode)
    return;

  findnewlimits();

  for(i=0; i<numnodes; i++)
    nodes[i].start_increment();

  double xx,yy;
  translate_back(x2, y2, &xx, &yy);
  
  activenode->Hold(xx, yy);

  for(i=0; i<numnodes; i++)
    nodes[i].end_increment();
}

void showneural::motion_started(int newx, int newy)
{
  int i, index=get_node_hit(newx, newy);

  do_copy();
  findnewlimits();
  if(index >= 0)
    {
      for(i=0; i<numnodes; i++)
	nodes[i].start_increment();

      double xx,yy;
      translate_back(newx, newy, &xx, &yy);
  
      activenode = nodes+index;
      activenode->Hold(xx, yy);

      for(i=0; i<numnodes; i++)
	nodes[i].end_increment();
    }
}

void showneural::motion_dropped(int newx, int newy)
{
  int i;
  double xx, yy;

  do_copy();
  findnewlimits();
  if(activenode)
    {
      Clear();
      for(i=0; i<numnodes; i++)
	nodes[i].start_increment();

      translate_back(newx, newy, &xx, &yy);
      activenode->Hold(xx, yy);
      activenode->StopHold();
      activenode = NULL;

      for(i=0; i<numnodes; i++)
	nodes[i].end_increment();
    }
}
