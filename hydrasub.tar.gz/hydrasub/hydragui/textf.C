/*
 * $Id: textf.C 2731 2016-06-14 10:25:20Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/textf.C $
 */


#include <hydrasub/hydragui/textf.H>
#include <hydrasub/hydragui/color.H>

#include <Xm/TextF.h>

#include <ctype.h>
#include <string.h> 
#include <strings.h> 
#include <ctype.h>
#include <hydrasub/hydragui/mainwin.H>

// ######################################################################
// textf
// ######################################################################

textf::textf() : widget()
{
  currenttitle=NULL;
}

textf::~textf()
{
  //if(currenttitle)
  //delete [] currenttitle;
  currenttitle=NULL;
}

char *textf::get_current_title(void)
{
  return currenttitle;
}

// ######################################################################
// Return    : void
// Parameters: parent - my parent Widget
//             title - a label text
// Purpose   : builds a textfield. We add a label either left or topside 
//             depending on Row()
// ######################################################################
void textf::build(const Widget parent, const char *title) 
{
  if(title && Row())
    Row()->build(parent, title);    
  XmInitSetArg(XmNbackground, motifsubcolors[BISQUE1]);
  if(title && Row())
    init("textf", xmTextFieldWidgetClass, *Row());
  else
    init("textf", xmTextFieldWidgetClass, parent);
  Background("bisque1");
  Foreground("black");

  //if(currenttitle)
  //delete [] currenttitle;
  if(title)
    {
      currenttitle=new char[strlen(title)+2];
      strcpy(currenttitle, title);
    }
  else
    currenttitle=NULL;
}


// ######################################################################
// Return    : void
// Parameters: parent - my parent Widget
//             len - max length
//             title - a label text
// Purpose   : builds a textfield. We add a label either left or topside 
//             dcdcepending on Row()
// ######################################################################
void textf::build(const Widget parent, int len, const char *title) 
{
  if(title && Row())
    Row()->build(parent, title);
  XmInitSetArg(XmNbackground, motifsubcolors[BISQUE1]);
  //XmSetArg(XmNmaxLength, len);
  XmSetArg(XmNcolumns,   len);
  if(title && Row())
    init("textf", xmTextFieldWidgetClass, *Row());
  else
    init("textf", xmTextFieldWidgetClass, parent);
  Background("bisque1");
  Foreground("black");
  
  //if(currenttitle) // Should be here but valgrind complains... Trond
  //delete [] currenttitle;
  if(title)
    {
      currenttitle=new char[strlen(title)+2];
      strcpy(currenttitle, title);
    }
  else
    currenttitle=NULL;
}

// ######################################################################
// Return    : void
// Parameters: s - a textstring to be inserted
// Purpose   : update textstring s to the textfield
// ######################################################################
textf &textf::operator=(const char *s) 
{
    SetText(s);
    return *this;
}

// ######################################################################
// Return    : void
// Parameters: s - a textstring to be inserted
// Purpose   : update textstring s to the textfield
// ######################################################################
void textf::SetText(const char *s)
{
    XmTextFieldSetString(w, (char*)s);
}

// ######################################################################
// Return    : char * - pointer to the contents in this textfield
// Parameters: void
// Purpose   : return the textfield contents
// ######################################################################
char *textf::operator()() 
{
  return (XmTextFieldGetString(w));
}

// ######################################################################
// Return    : void
// Parameters: b - true or false
// Purpose   : make textfield editabel or not
// ######################################################################
void textf::EditAble(bool b) 
{
  XmTextFieldSetEditable(w, b);
  XtVaSetValues(w, XmNcursorPositionVisible, b, NULL);
}

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : clear all text in textfield
// ######################################################################
void textf::Clear() 
{
  XmTextFieldSetString(w, "");
}



void textf::Map()
{
  widget::Map();
  if(Row())
    Row()->Map();
}

void textf::Unmap()
{
  widget::Unmap();
  if(Row())
    Row()->Unmap();
}

bool sensitive_textf::is_dirty(void)
{
  return dirty;
}


sensitive_textf::sensitive_textf() : textf()
{
  dirty=False;
}


// ######################################################################
// Return    : void
// Parameters: parent - my parent Widget
//             title - a label text
// Purpose   : builds a textfield. We add a label either left or topside 
//             depending on Row()
// ######################################################################
void sensitive_textf::Build(const Widget parent, const char *title) 
{
  textf::build(parent, title);

  XtAddCallback(w, XmNmodifyVerifyCallback, 
		(XtCallbackProc)&sensitive_textf::CheckCB,
		(XtPointer)this);
  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&sensitive_textf::EnterCB,
		(XtPointer)this);
}


// ######################################################################
// Return    : void
// Parameters: parent - my parent Widget
//             len - max length
//             title - a label text
// Purpose   : builds a textfield. We add a label either left or topside 
//             depending on Row()
// ######################################################################
void sensitive_textf::Build(const Widget parent, int len, const char *title) 
{
  textf::build(parent, len, title);

  XtAddCallback(w, XmNmodifyVerifyCallback, 
		(XtCallbackProc)&sensitive_textf::CheckCB,
		(XtPointer)this);
  XtAddCallback(w, XmNactivateCallback, 
		(XtCallbackProc)&sensitive_textf::EnterCB,
		(XtPointer)this);
}


// ######################################################################
// Return    : void
// Parameters: pt - pointer to the text field, 
//             p - the event
// Purpose   : called when the user pushes a key
// ######################################################################
void sensitive_textf::EnterCB(Widget, sensitive_textf *pt, XmTextVerifyPtr)
{
  pt->enter_pushed();
}

// ######################################################################
// Return    : void
// Parameters: pt - pointer to the text field, 
//             p - the event
// Purpose   : called when the user pushes a key
// ######################################################################
void sensitive_textf::CheckCB(Widget /* wid */, sensitive_textf *pt, 
			      XmTextVerifyPtr p)
{
  char comp='\0';
  
  pt->dirty=True;

  if(p->text->ptr == NULL)
    {
      p->doit = True;
      return;
    }

  comp=p->text->ptr[0];
  
  if(comp=='\n')
    {
      p->doit = True;
      pt->enter_pushed();
    }
  else
    {
      p->doit = True;
      pt->keystroke(p);
    }
}

void sensitive_textf::keystroke(XmTextVerifyPtr /* cl */)
{
  // do nothing
}

void sensitive_textf::enter_pushed(void)
{
  // do nothing
}



// ######################################################################
// onlydigit
// ######################################################################

// ######################################################################
// Return    : void
// Parameters: parent - my parent Widget
//             title - a label text
// Purpose   : builds a textfield which only allows a int/float digit
// ######################################################################
void onlydigit::build(const Widget parent, char *title,int max_len) 
{
  sensitive_textf::Build(parent, title);
  maxlen=max_len;
}


// ######################################################################
// Return    : void
// Parameters: parent - my parent Widget
//             len - max length on digit
//             title - a label text
// Purpose   : builds a textfield which only allows a int/float digit
// ######################################################################
void onlydigit::build(const Widget parent, int len, char *title,int max_len) 
{
  sensitive_textf::Build(parent, len, title);
  maxlen=max_len;
}


// ######################################################################
// Return    : void
// Parameters: cl - holds information about what is going to be inserted
// Purpose   : check that we only have a int/float digit in textfield
// ######################################################################
void onlydigit::keystroke(XmTextVerifyPtr cl) 
{
  char *str = XmTextFieldGetString(w);
  if(cl->text->ptr == NULL)
    cl->doit = True;
  char *missingstr="missing";
  char comp=cl->text->ptr[0];

  if(cl->startPos<=7 && comp==missingstr[cl->startPos])
    cl->doit = True;
  else if(isdigit(comp))
    cl->doit = True;
  else if(comp == '.' && !index(str, '.'))
    cl->doit = True;
  else if(comp == '-' && !index(str, '-'))
    cl->doit = True;
  else
    cl->doit = False;

  if(maxlen!=(int)MISSING_VALUE && maxlen>0 &&
     cl->startPos>=maxlen)
    cl->doit = False;
}

// ######################################################################
// Return    : void
// Parameters: i - an int value
// Purpose   : change the content of onlydigit
// ######################################################################
onlydigit &onlydigit::operator=(int i) 
{
  static char s[20];
  if(i==MISSING_VALUE)
    sprintf(s, "missing");
  else
    sprintf(s, "%d", i);
  XmTextFieldSetString(w, s);
  return *this;
}

// ######################################################################
// Parameters: i - an int value
// Purpose   : change the content of onlydigit
// ######################################################################
void onlydigit::SetDigit(int i) 
{
  static char s[20];
  if(i==MISSING_VALUE)
    sprintf(s, "missing");
  else
    sprintf(s, "%d", i);
  XmTextFieldSetString(w, s);
}

// ######################################################################
// Return    : int - the onlydigits content
// Parameters: void
// Purpose   : return the content as an int
// ######################################################################
int onlydigit::getdigit(int empty_value)
{
  int buff;

  if(*operator()() && !strncasecmp(operator()(),"missing",7))
    return (int) MISSING_VALUE;
  else if(*operator()() && sscanf(operator()(),"%d",&buff))
    return buff;
  else
    return empty_value;
}

// ######################################################################
// Return    : float - the onlydigits content
// Parameters: void
// Purpose   : return the content as a float
// ######################################################################
float onlydigit::getfloat(float empty_value)
{
  float buff;

  if(*operator()() && !strncasecmp(operator()(),"missing",7))
     return (float) MISSING_VALUE;
  else if(*operator()() && sscanf(operator()(),"%f",&buff))
    return buff;
  else
    return empty_value;
}

// ######################################################################
// Parameters: f - a float value
// Purpose   : change the content of onlydigit
// ######################################################################
void onlydigit::SetFloat(float f) 
{
  static char s[20];
  if((int)f==MISSING_VALUE)
    sprintf(s, "missing");
  else 
    sprintf(s, "%f", f);
  XmTextFieldSetString(w, s);
}

// ######################################################################
// Parameters: f - a float value
// Purpose   : change the content of onlydigit
// ######################################################################
void onlydigit::SetFloat(float f,int pres) 
{
  static char spr[10],s[20];
  if((int)f==MISSING_VALUE)
    sprintf(s, "missing");
  else if(f==0.0)
    strcpy(s,"0.0");
  else
    {
      sprintf(spr,"%%-%1dg",pres);
      sprintf(s, spr, f);
    }
  XmTextFieldSetString(w, s);
}

// ######################################################################
// Return    : double - the onlydigits content
// Parameters: void
// Purpose   : return the content as a double
// ######################################################################
double onlydigit::getdouble(double empty_value)
{
  double buff;

  if(*operator()() && !strncasecmp(operator()(),"missing",7))
     return (double) MISSING_VALUE;
  else if(*operator()() && sscanf(operator()(),"%lf",&buff))
    return buff;
  else
    return empty_value;
}

// ######################################################################
// Parameters: f - a double value
// Purpose   : change the content of onlydigit
// ######################################################################
void onlydigit::SetDouble(double f) 
{
  static char s[20];
  if((int)f==MISSING_VALUE)
    sprintf(s, "missing");
  else 
    sprintf(s, "%f", f);
  XmTextFieldSetString(w, s);
}

// ######################################################################
// Parameters: f - a double value
// Purpose   : change the content of onlydigit
// ######################################################################
void onlydigit::SetDouble(double f,int pres) 
{
  static char spr[10],s[20];
  if((int)f==MISSING_VALUE)
    sprintf(s, "missing");
  else if(f==0.0)
    strcpy(s,"0.0");
  else
    {
      sprintf(spr,"%%-%d.%dg",pres+2,pres);
      sprintf(s, spr, f);
    }
  XmTextFieldSetString(w, s);
}

// ######################################################################
// onlydatetime
// ######################################################################

// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
void onlydatetime::build(const Widget parent, char *title) 
{
  sensitive_textf::Build(parent, title);
  /*XtAddCallback(w, XmNmodifyVerifyCallback, 
		(XtCallbackProc)&onlydatetime::CheckCB,
		(XtPointer)this);*/
}


// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
void onlydatetime::build(const Widget parent, int len, char *title) 
{
  sensitive_textf::Build(parent, len, title);
  /*XtAddCallback(w, XmNmodifyVerifyCallback, 
		(XtCallbackProc)&onlydatetime::CheckCB,
		(XtPointer)this);
  XtAddCallback(w, XmNmodifyVerifyCallback, 
		(XtCallbackProc)&onlydatetime::CheckCB,
		(XtPointer)this);*/
}


// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
void onlydatetime::keystroke(XmTextVerifyPtr cl) 
{
  if(cl->text->ptr == NULL)
    cl->doit = True;
  else
    {
      // finds out which chracters are legal or illegal in a textfield
      static char *chr = ".,:_;- \\/";
      
      if(isdigit(cl->text->ptr[0])
	 || strchr(chr, cl->text->ptr[0]) )
	cl->doit = True;
      else 
	cl->doit = False;
    }
}

// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
void onlydatetime::SetDateTime(DateTime dt,int form)
{
  static char s[30];
  char *pt = dt.syCh(form);
  
  if(dt!=NoDateTime)
    sprintf(s, "%s", pt);
  else
    strcpy(s,"---");
  SetText(s);
  delete [] pt; 
  pt = NULL;
}

// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
onlydatetime &onlydatetime::operator=(DateTime dt) 
{
  static char s[30];
  char *pt = dt.syCh(3);
  
  sprintf(s, "%s", pt);
  XmTextFieldSetString(w, s);
  delete [] pt; pt = NULL;
  return *this;
}


// ######################################################################
// Return    : DateTime and int *status - 1 if the string
//                      conversion didn't go well
// Parameters: int form - the method to be used for string conversion
//                      see date_time.h - syCh(int form)
// Purpose   : convert the string in a datetime field into a
//             DateTime structure
// ######################################################################
DateTime onlydatetime::getdatetime(int *status,int form) // form not in use...
{
  char buff1[100],*buff;
 
  if(status)
    *status=0;

  strcpy(buff1,operator()());
  if(!buff1)
    return NoDateTime;
  buff=stripspaces(buff1);
   
  if(!buff || !buff[0])
    return NoDateTime;
  else
    {
      DateTime dt(buff,form); // direct transition from string to datetime

      if(!dt.legal() && status)
	*status=1;
      return dt;
    }
}





// ***************************************************************************
//
// Name:                       getdateinfo
//
// Returns:    0 if something is wrong and 1 if everything went well. 
//
// Parameters: datefield1 - the text field for the start time
//             datefield2 - the text field for the end time
//             start - an output parameter returning the found start time
//             end   - an output parameter returning the found end time
//             err   - an error dialog window for showing error messages
//             is_season - try to get date fields as seasons? (other format)
//
// Purpose:    Gets date/time information from two text fields, and
//             checks the resulting DateTime objects. 
// ***************************************************************************
int getdateinfo(onlydatetime &datefield1, 
		onlydatetime &datefield2, 
		DateTime *start, DateTime *end, 
		ErrorDialog &err, bool is_season,
		int formtype)
{
  int status1, status2;
  // Get the contents of the text fields as strings;
  char *str1=datefield1(), *str2=datefield2(), *ptr1, *ptr2;

  // Set default season starts and season ends
  DateTime seasonstart(1904,1,1), seasonend(1904,12,31);
  DateTime dt1=NoDateTime, dt2=NoDateTime;

  if(!is_season)
    {
      // Get the contents of the text fields as DateTime objects;
      dt1 = datefield1.getdatetime(&status1, formtype);
      dt2 = datefield2.getdatetime(&status2, formtype);
    }
  // If this is a season and the first text field isn't empty...
  else if(is_season && *str1) 
    {
      int day1, month1;
      status1=0; // everything okay...
      
      // get the day and check the success of the operation 
      if((ptr1=getnextint(str1, &day1))==NULL)
	status1=1;
      // get the month and check the success of the operation 
      else if((ptr1=getnextint(ptr1, &month1))==NULL)
	status1=1;

      DateTime dt(1904, month1, day1); // make a season start DateTime
      dt1=dt; // Set the season start
    }
  
  // If this is a season and the second text field isn't empty...
  if(is_season && *str2)
    {
      int day2, month2;
      status2=0; // everything okay...
      
      // get the day and check the success of the operation 
      if((ptr2=getnextint(str2, &day2))==NULL)
	status2=1;
      // get the month and check the success of the operation 
      else if((ptr2=getnextint(ptr2, &month2))==NULL)
	status2=1;

      DateTime dt(1904, month2, day2); // make a season end DateTime
      dt2=dt; // Set the season end
    }


  if(status1!=0) // If fetching the first DateTime failed...
    {
      // Notify the user;

      if(!is_season) 
	err.build(mainwin::toplevel, "Feil", 
		  "Feil i periodens start-tid. Bruk DD/MM-YYYY");
      else
	err.build(mainwin::toplevel, "Feil", 
		  "Feil i sesongens start-tid. Bruk DD/MM");

      return 0; // operation failed...
    }

  if(status2!=0) // If fetching the second DateTime failed...
    {
      // Notify the user;

      if(!is_season)
	err.build(mainwin::toplevel, "Feil", 
		  "Feil i periodens slutt-tid. Bruk DD/MM-YYYY");
      else
	err.build(mainwin::toplevel, "Feil", 
		  "Feil i sesongens start-tid. Bruk DD/MM");

	return 0; // operation failed...
    }
  
  
  // If this is a season and the start field was empty, set the
  // season start DateTime to 1904.1.1
  if(is_season && dt1==NoDateTime) 
    dt1=seasonstart;
  
  // If this is a season and the end field was empty, set the
  // season end DateTime to 1904.12.31
  if(is_season && dt2==NoDateTime)
    dt2=seasonend;
  
  // If the start time is larger than the end time...
  if(dt1!=NoDateTime && dt2!=NoDateTime && dt1>dt2 && !is_season)
    {
      // Notify the user;
      err.build(mainwin::toplevel, "Feil", 
		"Periodens slutt-tid kommer f�r periodens start-tid!");
      return 0; // the operation failed...
    }
  
  
  *start=dt1; // return the fetched start DateTime
  *end=dt2;   // return the fetched end DateTime
  
  return 1;   // the operation was a success!
  
} // getdateinfo








// ######################################################################
// password
// ######################################################################

// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
void password::keystroke(XmTextVerifyPtr cl)
{
  XmTextVerifyCallbackStruct *cbs = (XmTextVerifyCallbackStruct *) cl;
  
  char *New;
  int len;
  
  if(cbs->reason == XmCR_ACTIVATE) 
    return;

  if(cbs->text->ptr == NULL) 
    {
      cbs->endPos = strlen(passwd);
      passwd[cbs->startPos] = 0;
      return;
    }

  if(cbs->text->length > 1) 
    {
      cbs->doit = False;
      return;
    }

  New = XtMalloc(cbs->endPos + 2);
  if(passwd) 
    {
      strcpy(New, passwd);
      XtFree(passwd);
    } 
  else
    New[0] = '\0';

  passwd = New;
  strncat(passwd, cbs->text->ptr, cbs->text->length);
  passwd[cbs->endPos + cbs->text->length] = 0;
  for(len = 0; len < cbs->text->length; len++) 
    cbs->text->ptr[len] = '*';
   
  cbs->doit = True;
}

// ######################################################################
// Return    : void
// Parameters: 
// Purpose   : 
// ######################################################################
void password::build(const Widget parent)
{
  r.build(parent, "Passord");
  XmInitSetArg(XmNbackground, motifsubcolors[BISQUE1]);
  init("honlydigit", xmTextFieldWidgetClass, r);
}

#ifdef MAIN
#include <hydrasub/hydragui/mainwin.H>
main(int argc, char **argv) 
{
  mainwin m("onlydate", argc, argv);
  htextf h;
  h.build(mainwin::toplevel, 8, "Input:");
  h.SetText(argc>1 ? (char *) argv[1] : (char *) "NULL");
  m.Run();
}
#endif
