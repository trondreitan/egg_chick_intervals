/*
 * $Id: drawgif.C 1162 2008-02-01 15:08:20Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/drawgif.C $
 */

#include <hydrasub/hydragui/drawgif.H>
#include <fstream>
#include <hydrasub/hydrabase/divfunc.H>

void drawgif::Create(widget parent, gdImagePtr in_image)
{
  
  // Allocate the image
  im=in_image;
  
  xlen=gdImageSX(im);
  ylen=gdImageSY(im);

  oldim = gdImageCreate(xlen,ylen);
  gdImageCopy(oldim,im,0,0,0,0,xlen,ylen);

  originalim = gdImageCreate(xlen,ylen);
  gdImageCopy(originalim,im,0,0,0,0,xlen,ylen);

  // Declare the image...
  build(parent,xlen,ylen);
}

void drawgif::Create(widget parent, char *filename)
{
  strcpy(file_name,filename);
  FILE *in;
  in=fopen(file_name,"r");

  // Allocate the image
  im=gdImageCreateFromGif(in);
  black=gdImageColorAllocate(im,0,0,0);
  white=gdImageColorAllocate(im,255,255,255);
  blue=gdImageColorAllocate(im,0,0,100);
  
  fclose(in);

  xlen=gdImageSX(im);
  ylen=gdImageSY(im);

  oldim = gdImageCreate(xlen,ylen);
  gdImageCopy(oldim,im,0,0,0,0,xlen,ylen);

  originalim = gdImageCreate(xlen,ylen);
  gdImageCopy(originalim,im,0,0,0,0,xlen,ylen);

  // Declare the image...
  build(parent,xlen,ylen);
}

drawgif::drawgif()
{
  exposed=0;
  reexposed=0;
}

drawgif::~drawgif()
{
  if(exposed)
    {
      delete [] mapping2;
      gdImageDestroy(im);
      gdImageDestroy(oldim);
      gdImageDestroy(originalim);
    }
}

void drawgif::reexpose(void)
{
  exposed=0;
  reexposed=1;
  expose();
}

void drawgif::restore(void)
{
  restore_original_memory();
  reexpose();
}

void drawgif::restore_old_memory(void)
{
  gdImageDestroy(im);
  im=gdImageCreate(xlen,ylen);
  gdImageCopy(im,oldim,0,0,0,0,xlen,ylen);
}

void drawgif::restore_original_memory(void)
{
  gdImageDestroy(oldim);
  oldim=gdImageCreate(xlen,ylen);
  gdImageCopy(oldim,im,0,0,0,0,xlen,ylen);
  gdImageDestroy(im);
  im=gdImageCreate(xlen,ylen);
  gdImageCopy(im,originalim,0,0,0,0,xlen,ylen);
}

void drawgif::mark(int x,int y,int radius)
{
  if(x>radius && x<(xlen-radius) && y>radius && y<(ylen-radius))
    gdImageFilledRectangle(im, x-radius/2, y-radius/2, x+radius/2, y+radius/2,
			   6);
  //gdImageArc(im,x,y,radius,radius,0,360,blue);
  //gdImageFillToBorder(im,x,y,blue,blue);
} 

// Tries to save the current gif image to a file
// Returns 0 if successful, 1 if the writing fails
int drawgif::saveimage(char *filename)
{
  // Open a file for writing
  FILE *out=fopen(filename,"wb");
  if(!out)
    {
      err.build(mainwin::toplevel,WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � �pne tempor�re filer!",
		     (char *) "Couldn't open the temp file!"));
      return 1;
    }

  gdImageGif(im,out);
  fclose(out);
  return 0;
}

// tries to send the current image to a postscript printer
void drawgif::printimage(void)
{
  char printer[100],cmd[200];
  DateTime now;
  now.now();
  char giffile[1000],psfile[1000],*ptr;

  sprintf(giffile,"/tmp/DRAWGIF%s.gif",ptr=now.syCh(2));
  delete [] ptr;
  sprintf(psfile,"/tmp/DRAWGIF%s.ps",ptr=now.syCh(2));
  delete [] ptr;
  strcpy(printer,getenv("PSPRINTER"));

  if(saveimage(giffile))
    return;
  
  sprintf(cmd,"convert %s %s",giffile,psfile);
  system(cmd);
  sprintf(cmd,"lpr -P%s %s",printer,psfile);
  system(cmd);
  sprintf(cmd,"rm %s",giffile);
  system(cmd);
  sprintf(cmd,"rm %s",psfile);
  system(cmd);
}

void drawgif::expose(void)
{
  int i;
  
  // Declare an output file...
  int clen=0;
  char str[1000],str2[200];;
  
  int *xred,*xgreen,*xblue;

  addworkcurs();
  if(!exposed)
    {
	std::ifstream cmapfile;
      char **colstr=NULL;
      char* rgbfile = NULL;
      int i;

      char* rgbfiles[] = {
	"/usr/lib/X11/rgb.txt",
	"/usr/share/X11/rgb.txt"
      };

      for (i = 0; i < 2; i++) {
	  cmapfile.open(rgbfiles[i], std::ios::in);
	if (cmapfile.good()) {
	  rgbfile = rgbfiles[i];
	  cmapfile.close();
	  break;
	}
	cmapfile.close();
      }

      cmapfile.open(rgbfile, std::ios::in);
  
      cmapfile.getline(str,1000);
      while(!cmapfile.eof())
	{
	  //cout << str << endl;
	  if(!strstr(str,"!"))
	    clen++;
	  cmapfile.getline(str,1000);
	}
      cmapfile.close();

      xred=new int[clen];
      xgreen=new int[clen];
      xblue=new int[clen];
      mapping2=new int[clen];
      colstr=new char*[clen];

      cmapfile.open(rgbfile, std::ios::in);
  
      i=0;
      
      Display *display = XtDisplay(w);
      Colormap cmap = XDefaultColormap(display, DefaultScreen(display));
      XColor col;

      cmapfile.getline(str,1000);
      while(!cmapfile.eof())
	{
	  if(!strstr(str,"!"))
	    {
	      sscanf(str,"%d",xred+i);
	      sscanf(str+4,"%d",xgreen+i);
	      sscanf(str+8,"%d",xblue+i);
	      sscanf(str+12,"%s",str2);
      
	      colstr[i]=new char[100];	  
	      strcpy(colstr[i],str2);
	      
	      i++; 
	    }
	  cmapfile.getline(str,1000);
	}
      cmapfile.close();

      for(i=0;i<256;i++)
	{
	  int radmin=256*256*256*127;
	  int red=gdImageRed(im, i);
	  int green=gdImageGreen(im, i);
	  int blue=gdImageBlue(im, i);

	  //cout << i << " - " << red << "," << green << "," << blue << endl;

	  mapping[i]=0;
	  for(int j=0;j<clen;j++)
	    {
	      int rad=(red-xred[j])*(red-xred[j])+
		(green-xgreen[j])*(green-xgreen[j])+
		(blue-xblue[j])*(blue-xblue[j]);
	      if(rad<radmin)
		{
		  radmin=rad;
		  mapping[i]=j;
		}
	      //if(i==253)
	      //cout << FORM("j:%d - %d,%d,%d rad=%d",j,xred[j],xgreen[j],xblue[j],rad) << endl;
	    }
	  //cout << i << " -> " << mapping[i] << endl;
	  
	  //cout << "Color number:" << i << endl;
	  //cout << str << endl;
	  //cout << FORM("%d.%d.%d",xred[i],xgreen[i],xblue[i]) << " \"" << str2 << "\"" << endl;
	  
	  XParseColor(display, cmap, colstr[mapping[i]], &col);
	  XAllocColor(display, cmap, &col);
	  mapping2[mapping[i]]=col.pixel;
	  
	  //cout << "red   :" << col.red << endl;
	  //cout << "green :" << col.green << endl;
	  //cout << "blue  :" << col.blue << endl;
	  //cout << "pixel:" << col.pixel << endl << endl;
	}

      // Free space
      //gdImageDestroy(im);
      //RmWorkCursor(*this);
      

      for(i=0;i<clen;i++)
	delete [] colstr[i];
      delete [] colstr;

      delete [] xred;
      delete [] xgreen;
      delete [] xblue;
    }

  //cout << xlen << " x " << ylen << endl;
      
  XImage *xi=XGetImage(XtDisplay(mainwin::toplevel), 
		       XtWindow(mainwin::toplevel), 
		       0, 0, 10, 10, AllPlanes, ZPixmap);;

  xi->format=2;
  xi->width=xlen;
  xi->height=ylen;
  xi->bitmap_pad=32;
  xi->byte_order=xi->bitmap_bit_order=1;
  xi->obdata=NULL;

  if(xi->depth==24)
    {
      xi->bytes_per_line=4*xlen;
      xi->bitmap_unit=8;
      xi->bits_per_pixel=32;
      xi->red_mask=255;
      xi->green_mask=65280;
      xi->blue_mask=16711680;
      xi->data=new char[4*xlen*ylen];
    }
  else // 8 bits color
    {
      xi->bytes_per_line=xlen;
      xi->bitmap_unit=32;
      xi->bits_per_pixel=8;
      xi->red_mask=0;
      xi->green_mask=0;
      xi->blue_mask=0;
      xi->data=new char[xlen*ylen];
    }

  int gdcol,red,green,blue;
  // i.e. different from the original
  SetLineWidth(1);
  
  i=0;
  for(register int x=0;x<xlen;x++)
    {
      for(register int y=0;y<ylen;y++)
	{
	  gdcol=gdImageGetPixel(im,x,y);
	  red=gdImageRed(im, gdcol);
	  green=gdImageGreen(im, gdcol);
	  blue=gdImageBlue(im, gdcol);

	  char pixelvalue=(char) (mapping2[mapping[gdcol]]%256);

	  if(xi->depth==24)
	    {
	      xi->data[4*(y*xlen+x)] = 0;
	      xi->data[4*(y*xlen+x)+1] = blue;
	      xi->data[4*(y*xlen+x)+2] = green;
	      xi->data[4*(y*xlen+x)+3] = red;
	    }
	  else
	    xi->data[y*xlen+x]=pixelvalue;
	   

	  i++;
	}
    }


  Display *display2=XtDisplay(*this);
  Window window2=XtWindow(*this);
  XPutImage(display2, window2, gc, xi, 0, 0, 0, 0, xlen, ylen); 

  exposed=1;
  reexposed=0;
  rmworkcurs();
}

#ifdef MAIN

motifgif::motifgif(char *title,int argc,char **argv) : mainwin(title,argc,argv)
{
  v1.build(*this);
  //lab.build(v1,"Testing av gd og Motif");
  if(argc>1)
    dr.Create(v1,argv[1]);
  else
    {
      cout << "Usage: drawgif <gif-file>" << endl;
      exit(0);
    }
}

void main(int argc,char **argv)
{
  motifgif mg("Motifgif",argc,argv);

  mg.Run();
}
#endif



