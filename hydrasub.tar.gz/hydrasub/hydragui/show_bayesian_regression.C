/*
 * $Id: show_bayesian_regression.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/show_bayesian_regression.C $
 */

#include <hydrasub/hydragui/show_bayesian_regression.H>
#include <hydrasub/hydragui/mainwin.H>
#include <cmath>

#ifdef GSL
#include <gsl/gsl_cdf.h>
#endif

const char *bay_reg_func_names[]=
{WHAT((char *) "Line�r", (char *) "Linear"),
 WHAT((char *) "Kvadrat", (char *) "Square"),
 WHAT((char *) "Kubisk", (char *) "Cube"),
 WHAT((char *) "Kvadratrot", (char *) "Square root"),
 WHAT((char *) "Log", (char *) "Log"),
 WHAT((char *) "Exp", (char *) "Exp"),
 WHAT((char *) "Sin", (char *) "Sin"),
 WHAT((char *) "Cos", (char *) "Cos"),
 WHAT((char *) "Indikator>=", (char *) "Indicator>="),
 WHAT((char *) "Indikator=", (char *) "Indicator="),
 WHAT((char *) "Opph�yd i", (char *) "In the power of"),
 WHAT((char *) "Konstant", (char *) "Constant")};

const char *bay_reg_func_names_short[]=
{WHAT((char *) "", (char *) ""),
 WHAT((char *) "�", (char *) "�"),
 WHAT((char *) "�", (char *) "�"),
 WHAT((char *) "sqr", (char *) "sqr"),
 WHAT((char *) "log", (char *) "log"),
 WHAT((char *) "exp", (char *) "exp"),
 WHAT((char *) "sin", (char *) "sin"),
 WHAT((char *) "cos", (char *) "cos"),
 WHAT((char *) "I_gt", (char *) "I_gt"),
 WHAT((char *) "I_eq", (char *) "I_eq"),
 WHAT((char *) "^", (char *) "^"),
 WHAT((char *) "C", (char *) "C")};
bool bay_reg_func_before[]=
{True, False, False, True, True, True, True, True, True, True,False};
bool bay_reg_func_substract[]=
{True, True, True, True, True, True, False, False, True, False,False};
int num_functions=BAY_REG_FUNCTION_NUMBER;


bay_reg_rule::bay_reg_rule(bayesian_regression *result_, int numseries_,
			   int numpredictors_, int *predictor_index_,
			   int *interaction_index_, int response_index_,
			   BAY_REG_FUNC_TYPE *predictor_func_, 
			   BAY_REG_FUNC_TYPE *interaction_func_,
			   BAY_REG_FUNC_TYPE response_func_,
			   double *predictor_scales_,
			   double *interaction_scales_,
			   double response_scale_)
{
  result         = new bayesian_regression(*result_);
  numseries      = numseries_;
  numpredictors  = numpredictors_;
  response_func  = response_func_;
  response_scale = response_scale_;
  response_index = response_index_;
  
  predictor_index    = new int[numpredictors];
  predictor_func     = new BAY_REG_FUNC_TYPE[numpredictors];
  predictor_scales   = new double[numpredictors];
  interaction_index  = new int[numpredictors];
  interaction_func   = new BAY_REG_FUNC_TYPE[numpredictors];
  interaction_scales = new double[numpredictors];
  
  for(int i=0;i<numpredictors;i++)
    {
      predictor_index[i]   = predictor_index_[i];
      predictor_scales[i]  = predictor_scales_[i];
      predictor_func[i]    = predictor_func_[i];
      interaction_index[i] = interaction_index_ ? interaction_index_[i] : -1;
      interaction_scales[i]= interaction_scales_ ? interaction_scales_[i] : 0;
      interaction_func[i]  = interaction_func_ ? interaction_func_[i] : 
	BAY_REG_LINEAR;
    }
}

bay_reg_rule::bay_reg_rule(bay_reg_rule &orig)
{
  init();
  copy(orig);
}

bay_reg_rule::bay_reg_rule()
{
  init();
}

bay_reg_rule::~bay_reg_rule()
{
  cleanup();
}

void bay_reg_rule::init(void)
{
  predictor_index    = NULL;
  predictor_scales   = NULL;
  predictor_func     = NULL;
  interaction_index  = NULL;
  interaction_scales = NULL;
  interaction_func   = NULL;
  result = NULL;
  numpredictors = numseries = response_index = 0;
}

void bay_reg_rule::cleanup(void)
{
  if(predictor_index)
    delete [] predictor_index;
  if(predictor_scales)
    delete [] predictor_scales;
  if(predictor_func)
    delete [] predictor_func;
  if(interaction_index)
    delete [] interaction_index;
  if(interaction_scales)
    delete [] interaction_scales;
  if(interaction_func)
    delete [] interaction_func;
  if(result)
    delete result;
  init();
}

void bay_reg_rule::copy(bay_reg_rule &orig)
{
  result         = new bayesian_regression(*orig.result);
  numseries      = orig.numseries;
  numpredictors  = orig.numpredictors;
  response_func  = orig.response_func;
  response_scale = orig.response_scale;
  response_index = orig.response_index;

  predictor_index  = new int[numpredictors];
  predictor_func   = new BAY_REG_FUNC_TYPE[numpredictors];
  predictor_scales = new double[numpredictors];
  
  interaction_index  = new int[numpredictors];
  interaction_func   = new BAY_REG_FUNC_TYPE[numpredictors];
  interaction_scales = new double[numpredictors];
  
  for(int i=0;i<numpredictors;i++)
    {
      predictor_index[i]  = orig.predictor_index[i];
      predictor_scales[i] = orig.predictor_scales[i];
      predictor_func[i]   = orig.predictor_func[i];

      interaction_index[i]  = orig.interaction_index ?
	orig.interaction_index[i] : -1;
      interaction_scales[i] = orig.interaction_scales ?
	orig.interaction_scales[i] : 0;
      interaction_func[i]   = orig.interaction_func ?
	orig.interaction_func[i] : BAY_REG_LINEAR;
    }
}

// returns a response value according to the input (of size 'numseries');
double bay_reg_rule::find_response_value(double *predictor_set)
{
  double ret = find_response(predictor_set);

  ret = inverse_bay_reg_funcvalue(ret, response_func, response_scale);

  return ret;
}

double *bay_reg_rule::find_predictors(double *predictor_set)
{
  int i;
  double *ret=new double[numpredictors];
  
  for(i=0;i<numpredictors;i++)
    {
      double arg=predictor_set[predictor_index[i]];
      double transformed=bay_reg_funcvalue(arg, predictor_func[i],
					   predictor_scales[i]);
      if(interaction_index && interaction_index[i]>=0)
	{
	  double interaction=predictor_set[interaction_index[i]];
	  double interactiontransf=bay_reg_funcvalue(interaction,
						     interaction_func[i],
						     interaction_scales[i]);

	  ret[i]=transformed*interactiontransf;
	}
      else
	ret[i] = transformed; 
    }

  return ret;
}

double bay_reg_rule::find_response(double *predictor_set)
{
  int i;
  double ret=0.0;
  
  for(i=0;i<numpredictors;i++)
    {
      double arg=predictor_set[predictor_index[i]];
      double transformed=bay_reg_funcvalue(arg, predictor_func[i],
					   predictor_scales[i]);
      if(interaction_index && interaction_index[i]>=0)
	{
	  double interaction=predictor_set[interaction_index[i]];
	  double interactiontransf=bay_reg_funcvalue(interaction,
						     interaction_func[i],
						     interaction_scales[i]);

	  ret += 
	    result->get_mean_coefficient(i)*transformed*interactiontransf;
	}
      else
	ret += result->get_mean_coefficient(i)*transformed; 
    }

  return ret;
}

bayesian_regression *bay_reg_rule::get_bayesian_regression(void)
{
  return result;
}

int bay_reg_rule::get_numseries(void)
{
  return numseries;
}

int bay_reg_rule::get_numpredictors(void)
{
  return numpredictors;
}

int *bay_reg_rule::get_predictor_index(void)
{
  return predictor_index;
}

int *bay_reg_rule::get_interaction_index(void)
{
  return interaction_index;
}

int bay_reg_rule::get_response_index(void)
{
  return response_index;
}

BAY_REG_FUNC_TYPE *bay_reg_rule::get_predictor_func(void) 
{
  return predictor_func;
}

BAY_REG_FUNC_TYPE *bay_reg_rule::get_interaction_func(void) 
{
  return interaction_func;
}

BAY_REG_FUNC_TYPE bay_reg_rule::get_response_func(void)
{
  return response_func;
}

double *bay_reg_rule::get_predictor_scales(void)
{
  return predictor_scales;
}

double *bay_reg_rule::get_interaction_scales(void)
{
  return interaction_scales;
}

double bay_reg_rule::get_response_scale(void)
{
  return response_scale;
}

bool bay_reg_rule::is_predictor(int index)
{
  if(index<0 || index>numseries)
    return False;

  for(int i=0;i<numpredictors;i++)
    {
      if(predictor_index[i]==index)
	return True;
      if(interaction_index && interaction_index[i]==index)
	return True;
    }

  return False;
}

// Predicts the response based on input values (numseries of them).
// Inputs not in use can be set to MISSING_VALUE
// If a used predictor has MISSING_VALUE, the result
// is MISSING_VALUE.
double bay_reg_rule::predict(double *input_values)
{
  double prediction=0.0;

  for(int j=0;j<numpredictors;j++)
    {
      double arg=input_values[predictor_index[j]];
      double arg2=1;
      
      if(interaction_index[j]>=0)
	arg2=input_values[interaction_index[j]];

      if(arg!=MISSING_VALUE && arg2!=MISSING_VALUE &&
	 prediction!=MISSING_VALUE)
	{
	  arg=bay_reg_funcvalue(arg,predictor_func[j],
				predictor_scales[j]);
	  if(interaction_index[j]>=0)
	    arg *= bay_reg_funcvalue(arg,interaction_func[j],
				     interaction_scales[j]);
	  
	  prediction+=result->get_mean_coefficient(j)*arg;
	}
      else
	prediction=MISSING_VALUE;
    }
  
  if(prediction!=MISSING_VALUE)
    prediction=inverse_bay_reg_funcvalue(prediction,response_func,
					 response_scale);
  return prediction;
}

void bay_reg_rule::print(std::ostream& /* out */)
{
  
}

void bay_reg_button::create(widget parent, const char *txt, show_bay_reg *ipt,
			    BAY_REG_ACTION action)
{
  pt=ipt;
  type=action;
  build(parent,txt);
}

void bay_reg_button::pushed(void)
{
  pt->take_action(type);
}

void bay_reg_function_choice::create(widget parent, show_bay_reg *ipt, 
				     bool primary)
{
  is_primary=primary;
  pt=NULL;
  Create(parent, WHAT((char *) "Funksjonsvalg", (char *) "Function"));
  Insert(bay_reg_func_names, BAY_REG_CONSTANT, 0);
  pt=ipt;
}

void bay_reg_function_choice::pushed(const char* /*item */)
{
  if(pt)
    {
      BAY_REG_FUNC_TYPE functype=get_function_type();

      switch(functype)
	{
	case BAY_REG_POWER:
	  if(is_primary)
	    pt->take_action(BAY_REG_POW);
	  else
	    pt->take_action(BAY_REG_POW2);
	  break;
	case BAY_REG_SIN:
	case BAY_REG_COS:
	  if(is_primary)
	    pt->take_action(BAY_REG_TRIGONOMETRIC);
	  else
	    pt->take_action(BAY_REG_TRIGONOMETRIC2);
	  break;
	default:
	  pt->take_action(BAY_REG_DEFAULT_CHOICE);
	  break;
	}
    }
}

void bay_reg_savefile::Create(show_bay_reg *ipt)
{
  pt=ipt;
  sh.build(mainwin::toplevel, WHAT((char *) "Velg filnavn:", 
				   (char *) "Choose file name:"));
  v1.build(sh);
  build(v1);
  sh.Map();
}

void bay_reg_savefile::ok(const char *filename)
{
  pt->savefile_chosen(filename);
  sh.Unmap();
}

void bay_reg_savefile::cancel(void)
{
  sh.Unmap();
}

void bay_reg_printershell::create(show_bay_reg *ipt)
{
  pt=ipt;
  Create();
}

void bay_reg_printershell::ok_pushed(const char *newprinter)
{
  pt->printer_changed(newprinter);
}


double bay_reg_funcvalue(double arg, BAY_REG_FUNC_TYPE functype,
			 double scale)
{
  double newval=0.0;

  switch(functype)
    {
    case BAY_REG_LINEAR:
      newval=arg-scale;
      break;
    case BAY_REG_SQUARE: 
      newval=(arg-scale)*(arg-scale);
      break;
    case BAY_REG_CUBE:
      newval = (arg-scale)*(arg-scale)*(arg-scale);
      break;
    case BAY_REG_SQUARE_ROOT:
      newval = sqrt(arg-scale);
      break;
    case BAY_REG_LOG:
      newval = log(arg-scale);
      break;
    case BAY_REG_EXP:
      newval = exp(newval-scale);
      break;
    case BAY_REG_SIN:
      newval = sin(arg*scale);
      break;
    case BAY_REG_COS:
      newval=cos(arg*scale);
      break;
    case BAY_REG_POWER:
      newval = pow(arg, scale);
      break;
    case BAY_REG_STEP:
      newval = (arg>=scale) ? 1.0 : 0.0;
      break;
    case BAY_REG_EQUAL:
      newval = (arg==scale) ? 1.0 : 0.0;
      break;
    case BAY_REG_CONSTANT:
      newval = 1.0;
      break;
	default:
	    break;
    }

  return newval;
}

double inverse_bay_reg_funcvalue(double arg, BAY_REG_FUNC_TYPE functype,
				 double scale)
{
  double newval=arg;

  switch(functype)
    {
    case BAY_REG_LINEAR:
      newval=arg+scale;
      break;
    case BAY_REG_SQUARE: 
      newval = sqrt(ABSVAL(arg))+scale;
      break;
    case BAY_REG_CUBE:
      newval = pow(ABSVAL(arg), 1.0/3.0)+scale;
      break;
    case BAY_REG_SQUARE_ROOT:
      newval = arg*arg+scale;
      break;
    case BAY_REG_LOG:
      newval = exp(newval)+scale;
      break;
    case BAY_REG_EXP:
      newval = log(newval)+scale;
      break;
    case BAY_REG_SIN:
      newval = asin(arg)/scale;
      break;
    case BAY_REG_COS:
      newval = acos(arg)/scale;
      break;
    case BAY_REG_POWER:
      newval = pow(arg, 1.0/scale);
      break;
    case BAY_REG_STEP:
      newval = arg>0.5 ? scale : scale-0.000001;
      break;
    case BAY_REG_EQUAL:
      newval = arg==scale ? scale : 0.0;
      break;
    case BAY_REG_CONSTANT:
      newval = 1.0;
      break;
	default:
	    break;
    }
  
  return newval;
}

BAY_REG_FUNC_TYPE bay_reg_function_choice::get_function_type(void)
{
  BAY_REG_FUNC_TYPE functype=(BAY_REG_FUNC_TYPE) GetNumber();
  
  return functype;
}

void bay_reg_function_choice::set_function_type(BAY_REG_FUNC_TYPE func)
{
  int num=(int) func;
  SetFocus(num);
}

void bay_reg_plot_alternatives::create(widget parent)
{
  char *alternatives[]=
  { WHAT((char *) "Kurve for gjennomsnittsverdier av de ubrukte prediktorene",
	 (char *) "Curve for mean values of the unused predictors"),
    WHAT((char *) "M�linger", (char *) "Measurements"),
    WHAT((char *) "Kurve+m�linger", (char *) "Curve+measurements"),
    WHAT((char *) "M�linger+prediksjoner", (char *)"Measurements+predictions"),
    WHAT((char *) "Kurve+m�linger+prediksjoner", 
	 (char *) "Curve+measurements+predictions"),
    WHAT((char *) "Residual", (char *) "Residuals")};

  activated=False;
  fr.build(parent);
  v1.build(fr);
  Create(v1, WHAT((char *) "", (char *) ""));
  Insert(alternatives, 6, 1);

  h1.build(v1);
  showcredibility.build(h1, WHAT((char *) "Vis troverdighetsgrenser:", 
				 (char *) "Show credibility limits"));
  credf.build(h1, 10, WHAT((char *) "Troverdighets-niv� (%):", 
			   (char *) "Credibility level (%):"));
  credf.SetDouble(95);
  h1.Unmap();

  activated=True;
}

void bay_reg_plot_alternatives::change_numpredictors(int numpred)
{
  numpredictors=numpred;
  
  check_alternatives();
}

void bay_reg_plot_alternatives::check_alternatives(void)
{
  BAY_REG_PLOT_ALTERNATIVES alt=get_plot_alternative();
  
  if(alt==BAY_REG_PLOT_MEAS)
    h1.Unmap();
  else if(alt==BAY_REG_PLOT_CURVE_MEAS)
    {
      //if(numpredictors==1)
      h1.Map();
      //else
      //{
      //  showcredibility.ToggleButtonOff();
      //  h1.Unmap();
      //}
    }
  else
    h1.Map();

  
}

void bay_reg_plot_alternatives::pushed(const char *)
{
  if(!activated)
    return;

  check_alternatives();
}

BAY_REG_PLOT_ALTERNATIVES bay_reg_plot_alternatives::get_plot_alternative(void)
{
  return (BAY_REG_PLOT_ALTERNATIVES) GetNumber();
}

bool bay_reg_plot_alternatives::show_credibility(void)
{
  BAY_REG_PLOT_ALTERNATIVES alt=get_plot_alternative();
  
  if(alt!=BAY_REG_PLOT_MEAS || 
     (alt!=BAY_REG_PLOT_CURVE_MEAS)) // || numpredictors==1))
    return showcredibility();
  else
    return False;
}

double bay_reg_plot_alternatives::credibility(void)
{
  BAY_REG_PLOT_ALTERNATIVES alt=get_plot_alternative();
  
  if(alt!=BAY_REG_PLOT_MEAS || 
     (alt!=BAY_REG_PLOT_CURVE_MEAS || numpredictors==1))
    return credf.getdouble();
  else
    return 95.0;
}

void bay_reg_plot_alternatives::set_plot_alternative(BAY_REG_PLOT_ALTERNATIVES
						     alternative)
{
  SetFocus((int) alternative);
}



// Makes a description of a predictor or response and sends it along
// in 'return_string';
void make_func_description(int index, char const* const* alias, BAY_REG_FUNC_TYPE functype,
			   double scale, char *return_string, char *title)
{
  char titlestr[100], *str=return_string;

  if(title)
    sprintf(titlestr, "%s: ", title);
  else
    strcpy(titlestr,"");
  
  if((almost_equal(scale,1.0) && !bay_reg_func_substract[(int) functype]) ||
     (almost_equal(scale,0.0) && bay_reg_func_substract[(int) functype]))
    {
      if(functype==BAY_REG_POWER)
	sprintf(str, "%s%s ", titlestr,
		alias[index]);
      else if(functype==BAY_REG_CONSTANT)
	strcpy(str, "C");
      else if(bay_reg_func_before[(int) functype])
	sprintf(str, "%s%s( %s )", titlestr, 
		bay_reg_func_names_short[(int) functype], alias[index]);
      else
	sprintf(str, "%s (%s)%s", titlestr, 
		alias[index], bay_reg_func_names_short[(int) functype]);
    }
  else
    {
      if(functype==BAY_REG_POWER)
	sprintf(str, "%s%s^%-5.3f ", titlestr,
		alias[index], scale);
      else if(functype==BAY_REG_CONSTANT)
	strcpy(str, "C");
      else if(bay_reg_func_before[(int) functype])
	{
	  if(!bay_reg_func_substract[(int) functype])
	    sprintf(str, "%s%s( %5.3f*%s )", titlestr, 
		    bay_reg_func_names_short[(int) functype],
		    scale, alias[index]);
	  else
	    sprintf(str, "%s%s( %s-%5.3f )", titlestr, 
		    bay_reg_func_names_short[(int) functype],
		    alias[index],scale);
	}
      else
	{
	  if(!bay_reg_func_substract[(int) functype])
	    sprintf(str, "%s (%5.3f*%s)%s", titlestr, 
		    scale, alias[index],
		    bay_reg_func_names_short[(int) functype]);
	  else
	    sprintf(str, "%s (%s-%5.3f)%s", titlestr, 
		    alias[index], scale,
		    bay_reg_func_names_short[(int) functype]);
	}
    }
}


void bay_reg_predictorlist::Create(widget parent, show_bay_reg *ipt)
{
  pt=ipt;
  v1.build(parent);
  lab.build(v1, WHAT((char *) "Liste over brukte prediktorer og respons:  ",
		     (char *) "List of used predictors and response:      "));
  build(v1, 5, 1);
}

void bay_reg_predictorlist::Update(int numpredictors, int *predictor_index, 
				   int *interaction_index, int response_index,
				   BAY_REG_FUNC_TYPE *predictor_func,
				   BAY_REG_FUNC_TYPE *interaction_func,  
				   BAY_REG_FUNC_TYPE response_func, 
				   double *predictor_scales, 
				   double *interaction_scales, 
				   double response_scale, char const* const* alias,
				   bool response_set)
{
  Clear();

  if(response_set)
    {
      char str[100];
      
      make_func_description(response_index, alias, response_func,
			    response_scale, str,
			    WHAT((char *) "Respons", (char *) "Response"));
      Insert(str);
    }
  
  for(int i=0;i<numpredictors;i++)
    if(predictor_func[i]!=BAY_REG_CONSTANT)
      {
	char title[100];
	char desc1[100], desc2[100]="",totaldesc[200]; 
	
	sprintf(title, "%s %i", WHAT((char *) "Prediktor", 
				     (char *) "Predictor"), i+1);
	make_func_description(predictor_index[i], alias, predictor_func[i],
			      predictor_scales[i], desc1, title);
	if(interaction_index && interaction_index[i]>=0)
	  {
	    strcpy(desc2, "*");
	    make_func_description(interaction_index[i], 
				  alias, interaction_func[i],
				  interaction_scales[i], desc2+1);
	  }
	
	sprintf(totaldesc, "%s%s", desc1, desc2); 
	
	Insert(totaldesc);
      }
}

void bay_reg_predictorlist::OneHit(int index, const char *)
{
  pt->list_hit(index-1);
}


void bay_reg_change_descriptors_button::Create(widget parent, const char *txt, 
					       bay_reg_change_descriptors *ipt)
{
  pt=ipt;
  build(parent,txt);
  Background("green");
  Foreground("black");
}

void bay_reg_change_descriptors_button::pushed(void)
{
  pt->ok_pushed();
}

bay_reg_change_descriptors::bay_reg_change_descriptors() : shell()
{
  alias=NULL;
  titles=NULL;
  num_desc=0;
  titlef=NULL;
  aliasf=NULL;
  h=NULL;
}

bay_reg_change_descriptors::~bay_reg_change_descriptors()
{
  cleanup();
}

void bay_reg_change_descriptors::cleanup(void)
{
  int i;

  if(alias)
    {
      for(i=0;i<num_desc;i++)
	if(alias[i])
	  delete [] alias[i];
      delete [] alias;
    }
  alias=NULL;

  if(titles)
    {
      for(i=0;i<num_desc;i++)
	if(titles[i])
	  delete [] titles[i];
      delete [] titles;
    }
  titles=NULL;

  if(h)
    delete [] h;
  h=NULL;

  if(titlef)
    delete [] titlef;
  titlef=NULL;

  if(aliasf)
    delete [] aliasf;
  aliasf=NULL;

  num_desc=0;
}

void bay_reg_change_descriptors::ok_pushed(void)
{
  for(int i=0;i<num_desc;i++)
    {
      delete [] alias[i];
      alias[i]=new char[strlen(aliasf[i]())+2];
      strcpy(alias[i], aliasf[i]());

      delete [] titles[i];
      titles[i]=new char[strlen(titlef[i]())+2];
      strcpy(titles[i], titlef[i]());
    }

  pt->set_descriptions(alias, titles, num_desc);
  Unmap();
}

void bay_reg_change_descriptors::Create(show_bay_reg *ipt, 
					char const* const* alias_, char const* const* title_, int num)
{
  cleanup();

  pt=ipt;

  num_desc=num;
  alias=new char*[num];
  titles=new char*[num];
  h=new hrow[num];
  aliasf=new htextf[num];
  titlef=new htextf[num];

  build(mainwin::toplevel, WHAT((char *) "Forandring av beskrivelse", 
				(char *) "Change of descriptions"));
  v1.build(*this);

  for(int i=0;i<num;i++)
    {
      alias[i]=new char[strlen(alias_[i])+2];
      strcpy(alias[i],alias_[i]);
      titles[i]=new char[strlen(title_[i])+2];
      strcpy(titles[i],title_[i]);

      h[i].build(v1);
      aliasf[i].build(h[i], 6, "Alias:");
      aliasf[i].SetText(alias[i]);
      titlef[i].build(h[i], 40, WHAT((char *) "Tittel:", (char *) "Title:"));
      titlef[i].SetText(titles[i]);
    }

  h1.build(v1);
  okb.Create(h1, "OK", this);
  cancelb.build(h1, this, WHAT((char *) "Avbryt", (char *) "Cancel"));
  cancelb.Background("red");
  cancelb.Foreground("white");

  Map();
}


void prior_ok::Create(widget parent, const char *txt, priorwindow *ipt)
{
  build(parent,txt);
  Background("green");
  Foreground("black");
  pt=ipt;
}

void prior_ok::pushed(void)
{
  pt->ok_pushed();
}

void priorwindow::ok_pushed(void)
{
  double *new_mean=new double[numpred];
  double *new_sdev=new double[numpred];
  double *new_zero=new double[numpred];
  double sigma_mean=sigma_meanf.getdouble()/100.0;
  double sigma_sdev=sigma_sdevf.getdouble()/100.0;
  double prob_all_zero=check_all_zero ? nopredf.getdouble()/100.0 : 0.0;
  double prob_const=check_only_constant ? only_constantf.getdouble()/100.0 : 
    0.0;
  double prob_autocorr=probability_autocorrf.getdouble()/100.0;

  for(int i=0;i<numpred;i++)
    {
      new_mean[i]=meanf[i].getdouble();
      new_sdev[i]=sdevf[i].getdouble();
      new_zero[i]=prob_of_zerof[i].getdouble()/100.0;
    }

  pt->set_new_priors(new_mean, new_sdev, new_zero, prob_all_zero,
		     prob_const, sigma_mean, sigma_sdev,
		     prob_autocorr);

  delete [] new_zero;
  delete [] new_mean;
  delete [] new_sdev;
}

priorwindow::priorwindow()
{
  meanf=NULL;
  sdevf=NULL;
  prob_of_zerof=NULL;
  hrows=NULL;
  coeflab=NULL;
}

priorwindow::~priorwindow()
{
  cleanup();
}

void priorwindow::cleanup(void)
{
  if(meanf)
    delete [] meanf;
  meanf=NULL;
  if(sdevf)
    delete [] sdevf;
  sdevf=NULL;
  if(prob_of_zerof)
    delete [] prob_of_zerof;
  prob_of_zerof=NULL;
  if(hrows)
    delete [] hrows;
  hrows=NULL;
  if(coeflab)
    delete [] coeflab;
  coeflab=NULL;
}

void priorwindow::create(show_bay_reg *ipt, bool has_constant,
			 int numpredictors,char const* const* names,
			 double *mean,double *sdev,
			 double *probability_of_zero, 
			 double probability_of_all_zero,
			 double probability_of_only_constant, 
			 double sigma_mean, double sigma_sdev,
			 double probability_autocorr,
			 bool check_all_zero_, 
			 bool check_only_constant_)
{
  cleanup();
  pt=ipt;
  numpred=numpredictors;
  hasconstant=has_constant;

  check_all_zero=check_all_zero_;
  check_only_constant=check_only_constant_;

  build(*pt, WHAT((char *) "Spesifikasjon av informasjon f�r data (a priori)",
		  (char *) "Specification of information before data "
		  "(a priori)"));
  v1.build(*this);
  
  hrows=new hrow[numpred];
  meanf=new honlydigit[numpred];
  sdevf=new honlydigit[numpred];
  prob_of_zerof=new honlydigit[numpred];
  coeflab=new label[numpred];

  for(int i=0;i<numpred;i++)
    {
      hrows[i].build(v1);
      coeflab[i].build(hrows[i], "%s: ", names[i]);
      meanf[i].build(hrows[i], 10, WHAT((char *) "forventet:", 
					(char *) "expected:"));
      meanf[i].SetDouble(mean[i], 8);
      sdevf[i].build(hrows[i], 10, 
		     WHAT((char *) " usikkerhet (st.avvik):", 
			  (char *) " uncertainty (st.devation):"));
      sdevf[i].SetDouble(sdev[i], 8);
      prob_of_zerof[i].build(hrows[i], 10, 
			     WHAT((char *) " sannsynelighet for v�re "
				  "unv�dvendig:", 
				  (char *) " probability for being "
				  "uneccessary:"));
      prob_of_zerof[i].SetDouble(100.0*probability_of_zero[i], 8);
    }

  h1.build(v1);
  if(check_only_constant)
    {
      only_constantf.build(h1, 10, WHAT((char *) "Sanns. for kun "
					"konstant-ledd:", 
					(char *) "Prob. for only constant:"));
      only_constantf.SetDouble(100.0*probability_of_only_constant, 8);
    }

  if(check_all_zero)
    {
      nopredf.build(h1, 10, WHAT((char *) "Sanns. for � v�re hvit st�y:", 
				 (char *) "Prob. of being white noise:"));
      nopredf.SetDouble(100.0*probability_of_all_zero, 8);
    }

  h2.build(v1);
  sigma_meanf.build(h2, 10, WHAT((char *) "Forventet st�y-st�rrelse:", 
				 (char *) "Expected size of noise:"));
  sigma_meanf.SetDouble(sigma_mean,8);
  sigma_sdevf.build(h2, 10, WHAT((char *) "Usikkerhet i st�y-st�rrelse:", 
				 (char *) "Uncertainty of noise size:"));
  sigma_sdevf.SetDouble(sigma_sdev,8);
  
  probability_autocorrf.build(h2, 10, 
			      WHAT((char *) "Sannsynlighet for trend:",
				   (char *) "Probability of trend:"));
  probability_autocorrf.SetDouble(probability_autocorr*100.0,8);
  
  sep1.build(v1);
  h3.build(v1);
  okb.Create(h1,"OK", this);
  cancelb.build(h1, this, WHAT((char *) "Avbryt", (char *) "Cancel"));
  cancelb.Background("red");
  cancelb.Foreground("white");
  
  Map();
}

void constant_toggle::create(widget parent, show_bay_reg *ipt)
{
  pt=NULL;
  build(parent, "Konstant");
  pt=ipt;
}

void constant_toggle::pushed(bool state)
{
  if(pt && state)
    pt->add_constant();
  else if(pt && !state)
    pt->removepredictor(True);
}

void show_bay_reg::update_bay_reg_type(void)
{
  predictorlist.Update(numpredictors, predictor_index, interaction_index,
		       response_index, predictor_func, interaction_func,
		       response_func, predictor_scales, interaction_scales,
		       response_scale, alias, response_set);

  show_current_bay_reg_type();
  altmenu.change_numpredictors(numpredictors);

  if(result)
    delete result;
  result=NULL;

  if(numpredictors>=3 && use_constant())
    check_only_constant=True;
  else
    check_only_constant=False;

  if(numpredictors>=2)
    check_all_zero=True;
  else
    check_all_zero=False;

  if(predictorf)
    {
      for(int i=0;i<oldprednum;i++)
	predictorh[i].Unmap();
      delete [] predictorf;
      delete [] predictorh;;
    }
  predictorf=NULL;
  predictorh=NULL;
  if(numpredictors>0)
    {
      predictorh=new hrow[numpredictors];
      predictorf=new honlydigit[numpredictors];
    }

  if(curr_coef_mean)
    delete [] curr_coef_mean;
  if(curr_coef_sdev)
    delete [] curr_coef_sdev;
  if(curr_prob_zero)
    delete [] curr_prob_zero;

  curr_coef_mean=new double[numpredictors];
  curr_coef_sdev=new double[numpredictors];
  curr_prob_zero=new double[numpredictors];

  for(int i=0;i<numpredictors;i++)
    {
      if(predictor_func[i]==BAY_REG_CONSTANT)
	{
	  curr_coef_mean[i]=standard_prior_constant_estimate;
	  curr_coef_sdev[i]=standard_prior_constant_sdev;
	}
      else
	{
	  curr_coef_mean[i]=standard_prior_coefficient_estimate;
	  curr_coef_sdev[i]=standard_prior_coefficient_sdev;
	}
      curr_prob_zero[i]=0.9/2.0/double(numpredictors);

      char predname[200];
      make_func_description(predictor_index[i], alias, 
			    predictor_func[i], 
			    predictor_scales[i], predname);
      if(interaction_index && interaction_index[i]>=0)
	{
	  int plen=strlen(predname);
	  predname[plen]='*';
	  predname[plen+1]='\0';
	  
	  make_func_description(interaction_index[i], alias, 
				interaction_func[i], 
				interaction_scales[i],
				predname+strlen(predname));
	}

      double mean=0.0;
      for(int j=0;j<len;j++)
	{
	  double arg=bay_reg_funcvalue(serievalues[predictor_index[i]][j],
				       predictor_func[i], 
				       predictor_scales[i]);
	  if(interaction_index && interaction_index[i]>=0)
	    arg *= bay_reg_funcvalue(serievalues[interaction_index[i]][j],
				     predictor_func[i], 
				     predictor_scales[i]);
	  mean += arg;
	}
      mean/=double(len);
      
      predictorh[i].build(predictorv1);
      predictorf[i].build(predictorh[i], 14, predname);
      predictorf[i].SetDouble(mean);
      //predictorf[i].EditAble(True);
    }

  oldprednum=numpredictors;
}

void show_bay_reg::cleanpredictors(void)
{
  if(predictor_index)
    delete [] predictor_index;
  predictor_index=NULL;

  if(predictor_func)
    delete [] predictor_func;
  predictor_func=NULL;

  if(predictor_scales)
    delete [] predictor_scales;
  predictor_scales=NULL;

  if(interaction_index)
    delete [] interaction_index;
  interaction_index=NULL;

  if(interaction_func)
    delete [] interaction_func;
  interaction_func=NULL;

  if(interaction_scales)
    delete [] interaction_scales;
  interaction_scales=NULL;
}

void show_bay_reg::add(void)
{
  int i, varindex = variablemenu1.GetNumber();
  BAY_REG_FUNC_TYPE functype = fchoice.get_function_type();
  double scale = scalef.getdouble();

  int varindex2 = variablemenu4.GetNumber()-1;
  BAY_REG_FUNC_TYPE functype2 = fchoice2.get_function_type();
  double scale2 = scalef2.getdouble();

  if(pred_or_resp() == 1) // response
    {
      if(varindex2>=0)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Ikke mulig",
					    (char *) "Not possible"),
		    WHAT((char *) "Interaksjon i responsleddet er ikke "
			 "mulig i denne implementasjonen!",
			 (char *) "Interaction in the response is not "
			 "possible in this implementation!"));
	  return;
	}

      if(response_set)
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Respons er allerede satt!",
			 (char *) "Response is already set!"));
	  return;
	}
      
      response_func  = functype;
      response_scale = scale;
      response_index = varindex;
      response_set   = True;

      pred_or_resp.SetFocus(0);
    }
  else // predictor
    {
      int *predindex=new int[numpredictors+1];
      BAY_REG_FUNC_TYPE *predfunc=new BAY_REG_FUNC_TYPE[numpredictors+1];
      double *predscales=new double[numpredictors+1];
      int *interindex=new int[numpredictors+1];
      BAY_REG_FUNC_TYPE *interfunc=new BAY_REG_FUNC_TYPE[numpredictors+1];
      double *interscales=new double[numpredictors+1];

      for(i=0;i<numpredictors;i++)
	{
	  predindex[i]  = predictor_index[i];
	  predfunc[i]   = predictor_func[i];
	  predscales[i] = predictor_scales[i];
	  interindex[i]  = interaction_index[i];
	  interfunc[i]   = interaction_func[i];
	  interscales[i] = interaction_scales[i];
	}

      predindex[numpredictors]  = varindex;
      predfunc[numpredictors]   = functype;
      predscales[numpredictors] = scale;
      interindex[numpredictors] = varindex2;
      interfunc[numpredictors]  = functype2;
      interscales[numpredictors]= scale2;

      cleanpredictors();

      predictor_index  = predindex;
      predictor_func   = predfunc;
      predictor_scales = predscales;
      interaction_index  = interindex;
      interaction_func   = interfunc;
      interaction_scales = interscales;

      numpredictors++;
    }
  
  update_bay_reg_type();
}

void show_bay_reg::add_constant(void)
{
  int i, *predindex=new int[numpredictors+1];
  BAY_REG_FUNC_TYPE *predfunc=new BAY_REG_FUNC_TYPE[numpredictors+1];
  double *predscales=new double[numpredictors+1];
  int *interindex=new int[numpredictors+1];
  BAY_REG_FUNC_TYPE *interfunc=new BAY_REG_FUNC_TYPE[numpredictors+1];
  double *interscales=new double[numpredictors+1];
  
  for(i=0;i<numpredictors;i++)
    {
      predindex[i+1]  = predictor_index[i];
      predfunc[i+1]   = predictor_func[i];
      predscales[i+1] = predictor_scales[i];
      interindex[i+1]  = interaction_index[i];
      interfunc[i+1]   = interaction_func[i];
      interscales[i+1] = interaction_scales[i];
    }
  
  predindex[0]  = 0;
  predfunc[0]   = BAY_REG_CONSTANT;
  predscales[0] = 1.0;
  interindex[0] = -1;
  interfunc[numpredictors]  = BAY_REG_CONSTANT;
  interscales[numpredictors]= 1.0;
  
  cleanpredictors();

  predictor_index  = predindex;
  predictor_func   = predfunc;
  predictor_scales = predscales;
  interaction_index  = interindex;
  interaction_func   = interfunc;
  interaction_scales = interscales;
  
  numpredictors++;
  
  update_bay_reg_type();
}


void show_bay_reg::removepredictor(bool is_constant)
{
  int i,listnum=is_constant ? 0 : predictorlist.Selected();
  
  if(listnum<0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen prediktor eller respons er markert i "
		     "lista!",
		     (char *) "No predictor or response is marked in the "
		     "list!"));
      return;
    }

  if(listnum==0 && response_set && !is_constant) // response
    response_set=False;
  else // predictor
    {
      if(!is_constant && response_set)
	listnum--;
      if(use_constant() && !is_constant)
	listnum++;
      
      if(numpredictors>1)
	{
	  int *predindex = new int[numpredictors-1];
	  BAY_REG_FUNC_TYPE *predfunc=new BAY_REG_FUNC_TYPE[numpredictors-1];
	  double *predscales = new double[numpredictors-1];
	  int *interindex = new int[numpredictors-1];
	  BAY_REG_FUNC_TYPE *interfunc=new BAY_REG_FUNC_TYPE[numpredictors-1];
	  double *interscales = new double[numpredictors-1];
	  
	  for(i=0;i<listnum;i++)
	    {
	      predindex[i]    = predictor_index[i];
	      predfunc[i]     = predictor_func[i];
	      predscales[i]   = predictor_scales[i];
	      interindex[i]    = interaction_index[i];
	      interfunc[i]     = interaction_func[i];
	      interscales[i]   = interaction_scales[i];
	    }
	  for(i=listnum+1;i<numpredictors;i++)
	    {
	      predindex[i-1]  = predictor_index[i];
	      predfunc[i-1]   = predictor_func[i];
	      predscales[i-1] = predictor_scales[i];
	      interindex[i-1]  = interaction_index[i];
	      interfunc[i-1]   = interaction_func[i];
	      interscales[i-1] = interaction_scales[i];
	    }
	  
	  cleanpredictors();
	 
	  predictor_index  = predindex;
	  predictor_func   = predfunc;
	  predictor_scales = predscales;
	  interaction_index  = interindex;
	  interaction_func   = interfunc;
	  interaction_scales = interscales;

	  numpredictors--;
	}
      else
	{
	  cleanpredictors();

	  predictor_index  = NULL;
	  predictor_func   = NULL;
	  predictor_scales = NULL;
	  interaction_index  = NULL;
	  interaction_func   = NULL;
	  interaction_scales = NULL;
	  
	  numpredictors = 0;
	}
    }
  
  update_bay_reg_type();
}


void show_bay_reg::changepredictor(void)
{
  int varindex=variablemenu1.GetNumber();
  BAY_REG_FUNC_TYPE functype=fchoice.get_function_type();
  double scale=scalef.getdouble();
  int varindex2=variablemenu4.GetNumber()-1;
  BAY_REG_FUNC_TYPE functype2=fchoice2.get_function_type();
  double scale2=scalef2.getdouble();
  int listnum=predictorlist.Selected();

  if(listnum<0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen prediktor eller respons er markert i "
		     "lista!",
		     (char *) "No predictor or response is marked in the "
		     "list!"));
      return;
    }

  if(listnum==0 && response_set) // response
    {
      if(varindex2>=0)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Ikke mulig",
					    (char *) "Not possible"),
		    WHAT((char *) "Interaksjon i responsleddet er ikke "
			 "mulig i denne implementasjonen!",
			 (char *) "Interaction in the response is not "
			 "possible in this implementation!"));
	  return;
	}

      if(pred_or_resp()!=1)
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kan ikke forandre respons til prediktor!",
		     (char *) "Can't change response to predictor!"));
	  return;
	}

      response_func  = functype;
      response_scale = scale;
      response_index = varindex;
      response_set   = True;
    }
  else // predictor
    {
      if(use_constant())
	listnum++;

      if(pred_or_resp()!=0)
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kan ikke forandre prediktor til respons!",
		     (char *) "Can't change predictor to response!"));
	  return;
	}

      int index=response_set ? listnum-1 : listnum;

      predictor_index[index]  = varindex;
      predictor_scales[index] = scale;
      predictor_func[index]   = functype;
      interaction_index[index]  = varindex2;
      interaction_scales[index] = scale2;
      interaction_func[index]   = functype2;
    }
  
  update_bay_reg_type();
}

bool show_bay_reg::check_run(void)
{
  if(!response_set)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Respons er ikke satt!",
		     (char *) "Response is not set!"));
      return False;
    }

  /*
  if(numpredictors<1 || predictor_index==NULL)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen prediktorer er ikke satt!",
		     (char *) "No predictors are set!"));
      return False;
    }
  */

  return True;
}

void show_bay_reg::run_bay_reg(void)
{
  if(!check_run())
    return;

  int i,j;
  double *response=new double[len];
  double **predictors=new double*[numpredictors];
  
  for(i=0;i<numpredictors;i++)
    {
      predictors[i]=new double[len];

      for(j=0;j<len;j++)
	predictors[i][j]=bay_reg_funcvalue(serievalues[predictor_index[i]][j],
					   predictor_func[i], 
					   predictor_scales[i]);
      if(interaction_index)
	for(j=0;j<len;j++)
	  if(interaction_index[i]>=0)
	    predictors[i][j] *= bay_reg_funcvalue(
                         serievalues[interaction_index[i]][j],
			 interaction_func[i], 
			 interaction_scales[i]);
    }

  for(j=0;j<len;j++)
    response[j]=bay_reg_funcvalue(serievalues[response_index][j],
				  response_func, 
				  response_scale);

  double sigma_a=2.0+curr_sigma_mean/curr_sigma_sdev/curr_sigma_sdev;
  double sigma_b=(sigma_a-1.0)*curr_sigma_mean;
  
  double **var=new double*[numpredictors];
  for(i=0;i<numpredictors;i++)
    {
      var[i] = new double[numpredictors];
      for(j=0;j<numpredictors;j++)
	{
	  if(j==i)
	    var[i][j]=curr_coef_sdev[i]*curr_coef_sdev[i]/
	      sigma_b*(sigma_a-2.0);
	  else
	    var[i][j]=0.0;
	}
    }

  if(!check_all_zero)
    curr_prob_all_zero=0.0;
  if(!check_only_constant)
    curr_prob_only_constant=0.0;

  result = get_bayesian_regression(predictors, numpredictors, response, len,
				   curr_coef_mean, var, sigma_a, sigma_b,
				   true, curr_prob_zero,curr_prob_all_zero,
				   curr_prob_only_constant,
				   curr_prob_autocorr);

  if(!result)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � foreta regresjon!",
		     (char *) "Couldn't do bay_reg analysis!"));
      return;
    }

  if(currentrule)
    delete currentrule;
  currentrule=new bay_reg_rule(result, numseries, 
			       numpredictors, predictor_index, 
			       interaction_index, response_index,
			       predictor_func, interaction_func, 
			       response_func, predictor_scales, 
			       interaction_scales, response_scale);
  
  show_regression_result();

  predictb.Sensitive();

  if(response)
    delete [] response;
  if(predictors)
    {
      for(i=0;i<numpredictors;i++)
	if(predictors[i])
	  delete [] predictors[i];
      delete [] predictors;
    }
}

void show_bay_reg::start_change_prior(void)
{
  setprior.create(this, use_constant(),
		  numpredictors, titles,
		  curr_coef_mean, curr_coef_sdev,
		  curr_prob_zero, curr_prob_all_zero, 
		  curr_prob_only_constant, 
		  curr_sigma_mean, curr_sigma_sdev,
		  curr_prob_autocorr, check_all_zero,
		  check_only_constant);
}

void show_bay_reg::predict(void)
{
  int i=0,j=0;
  double cred=credibilityf.getdouble()/100.0;
  double *predictors=new double[numpredictors];

  if(use_constant())
    predictors[i++]=1.0;
  for(;i<numpredictors;i++,j++)
    predictors[i]=predictorf[j].getdouble();

  double pred=result->predict(predictors);
  double upper=mean_pred() ? 
    result->upper_estimate_credibility(predictors, cred) :
    result->upper_prediction_credibility(predictors, cred);
  double lower=mean_pred() ? 
    result->lower_estimate_credibility(predictors, cred) :
    result->lower_prediction_credibility(predictors, cred);

  double tpred=inverse_bay_reg_funcvalue(pred, response_func, 
					 response_scale);
  double tlower=inverse_bay_reg_funcvalue(lower, response_func, 
					  response_scale);
  double tupper=inverse_bay_reg_funcvalue(upper, response_func, 
					  response_scale);
  char strbuffer[500];

  predictionlab.labelString(WHAT((char *) "Respons:  %8.3f %3.1f%%"
				 " kredibilitetsintervall:  %8.3f - %-8.3f",
				 (char *) "Response: %8.3f %3.1f%%"
				 " credibility interval: %8.3f - %-8.3f"),
			    pred,cred*100.0,upper,lower);
  showresult += "\n";
  showresult += WHAT((char *) "Prediksjon:\n", (char *) "Prediction:");
  for(i=0;i<numpredictors;i++)
    {
      sprintf(strbuffer, "%s: %8.3f\n",predictorf[i].get_current_title(),
	      predictorf[i].getdouble());
      showresult += strbuffer;
    }

  sprintf(strbuffer, WHAT((char *) "Respons:  %8.3f %3.1f%% "
			  "troverdighetsintervall:  %8.3f - %-8.3f\n", 
			  (char *) "Response: %8.3f %3.1f%% "
			  "credibility interval: %8.3f - %-8.3f\n"), 
	  pred,cred*100.0,upper,lower);
  showresult += strbuffer;

  if(response_func!=BAY_REG_LINEAR || !almost_equal(response_scale,1.0))
    {
      transformedlab.labelString(WHAT((char *) "%s(%s): %8.3f %3.1f%% "
				      "troverdighetsintervall:  "
				      "%8.3f - %-8.3f",
				      (char *) "%s(%s): %8.3f %3.1f%% "
				      "credibility interval: "
				      "%8.3f - %-8.3f"),
				 titles[response_index],
				 alias[response_index],
				 tpred,100.0*cred,tupper,tlower);
      
      sprintf(strbuffer, WHAT((char *) "%s(%s): %8.3f %3.1f%% "
			      "troverdighetsintervall:  %8.3f - %-8.3f",
			      (char *) "%s(%s): %8.3f %3.1f%% "
			      "credibility interval: %8.3f - %-8.3f"),
	      titles[response_index],
	      alias[response_index],
	      tpred,100.0*cred,tupper,tlower);
      showresult += strbuffer;
    }
}


void show_bay_reg::doplot(bool bay_reg_predictor_plot)
{
  int numlines=0;
  BAY_REG_PLOT_ALTERNATIVES alt=altmenu.get_plot_alternative();
  int showcurve=0, showcurvecred=0, showmeas=0,
    showpred=0, showpredcred=0, showresidual=0, showresidualcred=0;
  bool docred=altmenu.show_credibility();
  double cred=altmenu.credibility()/100.0;
  
#ifndef GSL
  docred=False;
#endif // GSL

  switch(alt)
    {
    case BAY_REG_PLOT_CURVE:
      showcurve=1;
      if(docred)
	showcurvecred=1;
      break;
    case BAY_REG_PLOT_MEAS:
      showmeas=1;
      break;
    case BAY_REG_PLOT_CURVE_MEAS:
      showcurve=1;
      showmeas=1;
      if(docred) // && numpredictors==1)
	showcurvecred=1;
      break;		
    case BAY_REG_PLOT_PRED_MEAS: 
      showmeas=showpred=1;
      if(docred)
	showpredcred=1;
      break;
    case BAY_REG_PLOT_CURVE_PRED_MEAS:
      showcurve=showmeas=showpred=1;
      if(docred)
	{
	  //if(numpredictors==1)
	  showcurvecred=1;
	  //else
	  showpredcred=1;
	}
      break;
    case BAY_REG_PLOT_RESIDUAL:
      showresidual=1;
      if(docred)
	showresidualcred=1;
      break;
    }

  numlines = (showcurve+showmeas+showpred+showresidual) + 
    2*showcurvecred + showpredcred + showresidualcred;
  
  double **arg=new double*[numlines], **val=new double*[numlines];
  int *axis=new int[numlines], *lengths=new int[numlines];
  PLOTLINE_TYPE *type = new PLOTLINE_TYPE[numlines];
  char **linetitles=new char*[numlines], **axistitles=new char*[2];
  int predindex=variablemenu3.GetNumber();
  int aliasindex=variablemenu2.GetNumber();
  char respname[100], predname[200];
  int i,j;
  double *pred=new double[numpredictors];
  
  for(i=0;i<numlines;i++)
    linetitles[i] = new char[300];
  axistitles[0] = new char[100];
  axistitles[1] = new char[100];
  for(i=0;i<numlines;i++)
    axis[i] = 1;
  
  if(!bay_reg_predictor_plot)
    {
      strcpy(respname, alias[response_index]);
      strcpy(predname, alias[aliasindex]);
    }
  else
    {
      make_func_description(response_index, alias, response_func, 
			    response_scale, respname);
      make_func_description(predictor_index[predindex], alias, 
			    predictor_func[predindex], 
			    predictor_scales[predindex],
			    predname);
      if(interaction_index && interaction_index[predindex]>=0)
	{
	  int plen=strlen(predname);
	  predname[plen]='*';
	  predname[plen+1]='\0';
	  
	  make_func_description(interaction_index[predindex], alias, 
				interaction_func[predindex], 
				interaction_scales[predindex],
				predname+strlen(predname));
	}
    }

  strcpy(axistitles[0], predname);
  strcpy(axistitles[1], respname);
  
  double minarg=MISSING_VALUE, maxarg=MISSING_VALUE,
    minval=MISSING_VALUE,maxval=MISSING_VALUE;
  double *meanpred=new double[numpredictors];  
  int lineindex=0;

  for(j=0;j<numpredictors;j++)
    meanpred[j]=0.0;


  if(showmeas)
    {
      sprintf(linetitles[lineindex], WHAT((char *) "M�linger av %s", 
					  (char *) "Measurements of %s"), 
	      respname);

      lengths[lineindex] = len;
      type[lineindex] = PLOTLINE_DOT;
      arg[lineindex]  = new double[len];
      val[lineindex]  = new double[len];
    }

  for(i=0;i<len;i++)
    {
      double argbuff=serievalues[aliasindex][i];
      double valbuff=serievalues[response_index][i];
      
      for(j=0;j<numpredictors;j++)
	if(interaction_index && interaction_index[j]>=0)
	  meanpred[j]+=bay_reg_funcvalue(serievalues[predictor_index[j]][i],
					 predictor_func[j],
					 predictor_scales[j]) *
	    bay_reg_funcvalue(serievalues[interaction_index[j]][i],
			      interaction_func[j],
			      interaction_scales[j]);
	else
	  meanpred[j]+=bay_reg_funcvalue(serievalues[predictor_index[j]][i],
					 predictor_func[j], 
					 predictor_scales[j]);

      if(bay_reg_predictor_plot)
	{
	  argbuff=serievalues[predictor_index[predindex]][i];
	  argbuff=bay_reg_funcvalue(argbuff, predictor_func[predindex],
				    predictor_scales[predindex]);
	  
	  if(interaction_index && interaction_index[predindex]>=0)
	    {
	      double arg2=serievalues[interaction_index[predindex]][i];
	      argbuff *= bay_reg_funcvalue(arg2, interaction_func[predindex],
					   interaction_scales[predindex]);
	    }
	  
	  valbuff=bay_reg_funcvalue(valbuff, response_func,
				    response_scale);
	}
      
      if(minarg==MISSING_VALUE || minarg>argbuff)
	minarg=argbuff;
      if(maxarg==MISSING_VALUE || maxarg<argbuff)
	maxarg=argbuff;
      if(minval==MISSING_VALUE || minval>valbuff)
	minval=valbuff;
      if(maxval==MISSING_VALUE || maxval<valbuff)
	maxval=valbuff;

      if(showmeas)
	{
	  arg[lineindex][i]=argbuff;
	  val[lineindex][i]=valbuff;
	}
    }

  if(showmeas)
    lineindex++;

  for(j=0;j<numpredictors;j++)
    meanpred[j]/=double(len);

  if(showcurve)
    {    
      sprintf(linetitles[lineindex], 
	      WHAT((char *) "Funksjonssammenheng for %s", 
		   (char *) "%s as a function"), respname);
      if(numpredictors>1)
	strcpy(linetitles[lineindex]+strlen(linetitles[lineindex]), 
	       WHAT((char *) " (gj.verdier for andre pred.)",
		    (char *) " (av.values for other pred."));
      
      type[lineindex]    = PLOTLINE_LINE;
      lengths[lineindex] = 1000;
      arg[lineindex]     = new double[1000];
      val[lineindex]     = new double[1000];
      
      if(showcurvecred)
	{
	  sprintf(linetitles[lineindex+1], 
		  WHAT((char *) "Nedre %5.3f %% troverdighet for %s", 
		       (char *) "Lower %5.3f %% credibility for %s"), 
		  100.0*cred, respname);
	  type[lineindex+1]    = PLOTLINE_LINE;
	  lengths[lineindex+1] = 1000;
	  arg[lineindex+1] = new double[1000];
	  val[lineindex+1] = new double[1000];
	  sprintf(linetitles[lineindex+2], 
		  WHAT((char *) "�vre %5.3f %% troverdighet for %s", 
		       (char *) "Upper %5.3f %% credibility for %s"), 
		  100.0*cred, respname);
	  type[lineindex+2]   = PLOTLINE_LINE;
	  lengths[lineindex+2] = 1000;
	  arg[lineindex+2]=new double[1000];
	  val[lineindex+2]=new double[1000];
	}

      for(i=0;i<1000;i++)
	{
	  double x=minarg+(maxarg-minarg)*double(i)/double(1000-1);
	  double newval=0.0;
	  
	  arg[lineindex][i]=x;
	  if(!bay_reg_predictor_plot)
	    x=bay_reg_funcvalue(x, predictor_func[aliasindex],
				predictor_scales[aliasindex]);
	  
	  for(j=0;j<numpredictors;j++)
	    if(predictor_func[j]==BAY_REG_CONSTANT)
	      pred[j]=1;
	    else if(bay_reg_predictor_plot)
	      pred[j]=(j==predindex ? x : meanpred[j]);
	    else if(predictor_index[j]==aliasindex && 
		    interaction_index[j]<0)
	      pred[j]=bay_reg_funcvalue(x, predictor_func[j],
					predictor_scales[j]);
	    else
	      pred[j]=meanpred[j];
	  
	  newval = result->predict(pred);
	  
	  if(!bay_reg_predictor_plot)
	    val[lineindex][i]=inverse_bay_reg_funcvalue(newval, response_func,
							response_scale);
	  else
	    val[lineindex][i]=newval;

	  if(showcurvecred)
	    {
	      arg[lineindex+1][i]=arg[lineindex+2][i]=arg[lineindex][i];
	      
#ifdef GSL	      
	      
	      val[lineindex+1][i]=result->upper_estimate_credibility(pred,
								     cred);
	      val[lineindex+2][i]=result->lower_estimate_credibility(pred,
								     cred);

#endif // GSL

	      if(!bay_reg_predictor_plot)
		{
		  val[lineindex+1][i]=
		    inverse_bay_reg_funcvalue(val[lineindex+1][i], 
					      response_func, response_scale);
		  val[lineindex+2][i]=
		    inverse_bay_reg_funcvalue(val[lineindex+2][i], 
					      response_func, response_scale);
		}
	    }
	}
      
      lineindex++;
      if(showcurvecred)
	lineindex+=2;
    }

  bool mean_prediction = mean_pred();
  if(showpred)
    {
      sprintf(linetitles[lineindex], 
	      WHAT((char *) "Prediksjon av %s for m�lepunktene", 
		   (char *) "Predictions of %s for the measurement points"), 
	      respname);
      lengths[lineindex] = len;
      type[lineindex]    = PLOTLINE_DOT;
      arg[lineindex]     = new double[len];
      val[lineindex]     = new double[len];
      
      if(showpredcred)
	{
	  sprintf(linetitles[lineindex+1], 
		  WHAT((char *) "%5.3f %% troverdighet for %s", 
		       (char *) "%5.3f %% credibility for %s"), 
		  100.0*cred, respname);
	  type[lineindex+1]   = PLOTLINE_LINE;
	  lengths[lineindex+1] = 3*len;
	  arg[lineindex+1] = new double[3*len];
	  val[lineindex+1] = new double[3*len];
	}

      for(i=0;i<len;i++)
	{
	  int currindex = bay_reg_predictor_plot ? 
	    predictor_index[predindex] : aliasindex;
	  double argbuff = serievalues[currindex][i];
	  int predindex2=0;
	  double *predictors=new double[numseries];

	  for(j=0;j<numseries;j++)
	    predictors[j]=serievalues[j][i];

	  for(j=0;j<numpredictors;j++)
	    if(predictor_index[j]==currindex)
	      predindex2 = j;
	      
	  if(pred)
	    delete [] pred;
	  pred=currentrule->find_predictors(predictors);
	  
	  if(bay_reg_predictor_plot)
	    {
	      arg[lineindex][i]=
		bay_reg_funcvalue(argbuff, predictor_func[predindex2],
				  predictor_scales[predindex2]);

	      if(interaction_index && interaction_index[predindex]>=0)
		{
		  double arg2=serievalues[interaction_index[predindex]][i];
		  arg[lineindex][i] *= 
		    bay_reg_funcvalue(arg2, interaction_func[predindex],
				      interaction_scales[predindex]);
		}

	      val[lineindex][i]=result->predict(pred);
	    }
	  else
	    {
	      arg[lineindex][i]=argbuff;

	      val[lineindex][i]=
		inverse_bay_reg_funcvalue(result->predict(pred), 
					  response_func, response_scale);
	    }

	  delete [] predictors;

	  if(showpredcred)
	    {
	      arg[lineindex+1][3*i]=arg[lineindex][i];
	      arg[lineindex+1][3*i+1]=arg[lineindex][i]-
		ABSVAL((arg[lineindex][i]))*0.000000001;
	      arg[lineindex+1][3*i+2]=arg[lineindex][i]+
		ABSVAL((arg[lineindex][i]))*0.000000001;
#ifdef GSL
	      if(mean_prediction)
		{
		  val[lineindex+1][3*i]=result->
		    upper_estimate_credibility(pred,cred);
		  val[lineindex+1][3*i+1]=result->
		    lower_estimate_credibility(pred,cred);
		}
	      else
		{
		  val[lineindex+1][3*i]=result->
		    upper_prediction_credibility(pred,cred);
		  val[lineindex+1][3*i+1]=result->
		    lower_prediction_credibility(pred,cred);
		}

#endif // GSL
	      
	      if(!bay_reg_predictor_plot)
		{
		  val[lineindex+1][3*i] = 
		    inverse_bay_reg_funcvalue(val[lineindex+1][3*i],
					      response_func,
					      response_scale);
		  val[lineindex+1][3*i+1] = 
		    inverse_bay_reg_funcvalue(val[lineindex+1][3*i+1],
					      response_func,
					      response_scale);
		}
	      
	      val[lineindex+1][3*i+2] = MISSING_VALUE;
	    }
	}
      
      lineindex++;
      if(showpredcred)
	lineindex++;
    }
  
  if(showresidual)
    {
      sprintf(linetitles[lineindex], 
	      WHAT((char *) "Residualer %s", 
		   (char *) "Residuals %s"), respname);
      lengths[lineindex]=len;
      type[lineindex]=PLOTLINE_DOT;
      arg[lineindex]=new double[len];
      val[lineindex]=new double[len];
      
      if(showresidualcred)
	{
	  sprintf(linetitles[lineindex+1], 
		  WHAT((char *) "%5.3f %% troverdighet for residual %s", 
		       (char *) "%5.3f %% credibility for residuals %s"), 
		  100.0*cred, respname);
	  type[lineindex+1]   = PLOTLINE_LINE;
	  lengths[lineindex+1] = 3*len;
	  arg[lineindex+1]=new double[3*len];
	  val[lineindex+1]=new double[3*len];
	}
      
      for(i=0;i<len;i++)
	{
	  int currindex = bay_reg_predictor_plot ? 
	    predictor_index[predindex] : aliasindex;
	  double argbuff = serievalues[currindex][i];
	  double valbuff = 0.0;
	  double val2buff = serievalues[response_index][i];
	  int predindex2=0;
	  
	  for(j=0;j<numpredictors;j++)
	    if(predictor_index[j]==currindex)
	      predindex2=j;

	  for(j=0;j<numpredictors;j++)
	    {
	      if(interaction_index && interaction_index[j]>=0)
		pred[j]=
		  bay_reg_funcvalue(serievalues[predictor_index[j]][i],
				    predictor_func[j], predictor_scales[j]) *
		  bay_reg_funcvalue(serievalues[interaction_index[j]][i],
				    interaction_func[j], 
				    interaction_scales[j]);
	      else
		pred[j]=
		  bay_reg_funcvalue(serievalues[predictor_index[j]][i],
				    predictor_func[j], predictor_scales[j]);
	    }

	  valbuff=result->predict(pred);

	  if(bay_reg_predictor_plot)
	    {
	      arg[lineindex][i]=
		bay_reg_funcvalue(argbuff, predictor_func[predindex2],
				  predictor_scales[predindex2]);
	      if(interaction_index && interaction_index[predindex]>=0)
		{
		  double arg2=serievalues[interaction_index[predindex]][i];
		  arg[lineindex][i] *=
		    bay_reg_funcvalue(arg2, interaction_func[predindex],
				      interaction_scales[predindex]);
		}

	      val[lineindex][i]=bay_reg_funcvalue(val2buff,
						  response_func,
						  response_scale)-valbuff;
	    }
	  else
	    {
	      arg[lineindex][i]=argbuff;
	      val[lineindex][i]=-inverse_bay_reg_funcvalue(valbuff, 
							   response_func,
							   response_scale)+
		val2buff;
	    }
	  
	  if(showresidualcred)
	    {
	      arg[lineindex+1][3*i]=arg[lineindex][i];
	      arg[lineindex+1][3*i+1]=arg[lineindex][i]+
		ABSVAL(arg[lineindex][i])*1.0e-9;
	      arg[lineindex+1][3*i+2]=arg[lineindex][i]+
		ABSVAL(arg[lineindex][i])*2.0e-9;
	      
	      
#ifdef GSL
	      val[lineindex+1][3*i] = bay_reg_funcvalue(val2buff,
							response_func,
							response_scale)-
		result->upper_prediction_credibility(pred,cred);

	      val[lineindex+1][3*i+1] = bay_reg_funcvalue(val2buff,
							  response_func,
							  response_scale)-
		result->lower_prediction_credibility(pred,cred);

	      val[lineindex+1][3*i+2] = MISSING_VALUE;

#endif // GSL

	      if(!bay_reg_predictor_plot)
		{
		  val[lineindex+1][3*i] = 
		    inverse_bay_reg_funcvalue(val[lineindex+1][3*i],
					      response_func,
					      response_scale);
		  val[lineindex+1][3*i+1] = 
		    inverse_bay_reg_funcvalue(val[lineindex+1][3*i+1],
					      response_func,
					      response_scale);
		}
	    }
	}

      lineindex++;
      if(showpredcred)
	lineindex++;
    }


  if(plot)
    delete plot;
  plot = new plot_module();
  
  plot->Create(arg,val, lengths, axis, linetitles,numlines,
	       axistitles,2,NULL,type);

  delete [] axistitles[0];
  delete [] axistitles[1];
  for(i=0;i<numlines;i++)
    {
      delete [] arg[i];
      delete [] val[i];
      delete [] linetitles[i];
    }
  delete [] axistitles;
  delete [] linetitles;
  delete [] arg;
  delete [] val;
}

void show_bay_reg::close(void)
{
  Unmap();
  if(currentrule)
    bay_reg_done(currentrule);
}

void show_bay_reg::fetch_pow(bool is_primary)
{
  powsh.build(*this, WHAT((char *) "Innhenting av 'opph�yd i'-faktor", 
			  (char *) "Specification of power factor"));
  powv1.build(powsh);
  powfield.build(powv1, 12, WHAT((char *) "Opph�yd i:", 
				 (char *) "Power faktor"));
  powfield.SetDouble(1.0);
  powcloseb.build(powv1, "OK");
  powsh.Map();
  powcloseb.Wait();
  powsh.Unmap();
  
  if(is_primary)
    {
      scalef.SetDouble(powfield.getdouble());
      //scalef.EditAble(True);
    }
  else
    {
      scalef2.SetDouble(powfield.getdouble());
      //scalef2.EditAble(True);
    }
}

void show_bay_reg::fetch_trigonometric(bool is_primary)
{
  trigsh.build(*this, WHAT((char *) "Innhenting av trigonometrisk "
			   "skalafaktor", 
			   (char *) "Specification of trigonometric scale"
			   " factor"));
  trigv1.build(trigsh);
  trigfield.build(trigv1, 12, WHAT((char *) "Skalafaktor:", 
				 (char *) "Scale factor"));
  trigfield.SetDouble(2.0*M_PI);
  trigcloseb.build(trigv1, "OK");
  trigsh.Map();
  trigcloseb.Wait();
  trigsh.Unmap();
  
  if(is_primary)
    {
      scalef.SetDouble(trigfield.getdouble());
      //scalef.EditAble(True);
    }
  else
    {
      scalef2.SetDouble(trigfield.getdouble());
      //scalef2.EditAble(True);
    }
}
    
void show_bay_reg::set_default_choice(void)
{
  scalef.SetDouble(0.0,3);
  scalef2.SetDouble(0.0,3);
}

void show_bay_reg::show_current_bay_reg_type(void)
{
  char total[1000];
  int i;

  if(response_set)
    make_func_description(response_index, alias, response_func,
			  response_scale, total);
  else
    strcpy(total, "???");
  strcpy(total+strlen(total), " = ");
  
  if(numpredictors==0)
    strcpy(total+strlen(total), "0");
  else
    {
      char **pred=new char*[numpredictors];
      for(i=0;i<numpredictors;i++)
	{
	  pred[i]=new char[100];
	  make_func_description(predictor_index[i], alias, predictor_func[i],
				predictor_scales[i], pred[i]);
	  if(interaction_index && interaction_index[i]>=0)
	    {
	      strcpy(pred[i]+strlen(pred[i]), "*");
	      make_func_description(interaction_index[i], alias, 
				    interaction_func[i],
				    interaction_scales[i], 
				    pred[i]+strlen(pred[i]));
	    }
	  if(predictor_func[i]==BAY_REG_CONSTANT)
	    strcpy(total+strlen(total), " C ");
	  else
	    sprintf(total+strlen(total), "%s C%d * %s", i==0 ? "" : " + ", 
		    i+1, pred[i]);
	}
      variablemenu3.Insert(pred,numpredictors);

      for(i=0;i<numpredictors;i++)
	delete [] pred[i];
      delete [] pred;
    }

  resultlab.labelString(total);
}

void show_bay_reg::show_regression_result(void)
{
  char total[1000], str[100], strbuffer[500];
  int i;

  if(response_set)
    make_func_description(response_index, alias, response_func,
			  response_scale, total);
  else
    strcpy(total, "???");
  strcpy(total+strlen(total), " = ");
  
  if(numpredictors==0)
    strcpy(total+strlen(total), "0");
  else
    {
      showresult.Clear();

      for(i=0;i<numpredictors;i++)
	{
	  char pred[100];
	  make_func_description(predictor_index[i], alias, predictor_func[i],
				predictor_scales[i], pred);
	  if(interaction_index && interaction_index[i]>=0)
	    {
	      strcpy(pred+strlen(pred), "*");
	      make_func_description(interaction_index[i], alias, 
				    interaction_func[i],
				    interaction_scales[i], pred+strlen(pred));
	    }

	  if(predictor_func[i]==BAY_REG_CONSTANT)
	    sprintf(total+strlen(total), " %8.5f ",
		    result->get_mean_coefficient(i));
	  else
	    sprintf(total+strlen(total), " %s%8.5f * %s",
		    (i==0 ? "" : "+ "),
		    result->get_mean_coefficient(i), pred);
	}
      
      showresult += total;
      showresult += "\n\n";

      for(i=0;i<numpredictors;i++)
	{
	  sprintf(str, WHAT((char *) "Prediktor nr. %d: %8.5f +/- %8.5f  "
			    "sanns. for koeffisient=0: %8.5g %%\n", 
			    (char *) "Predictor %d:  %8.5f +/- %8.5f  "
			    "prob. for coefficient=0: %8.5g %%\n"),
		  i+1, result->get_mean_coefficient(i), 
		  sqrt(result->get_covariance_coefficient(i,i)),
		  result->get_coefficient_removal_probability(i)*100.0);
	  showresult+=str;
	}

      if(check_all_zero)
	{
	  sprintf(strbuffer, WHAT((char *) "Sannsynlighet for alle "
				  "koeffisienter=0: %8.5g %%\n",
				  (char *) "Probability for all "
				  "coefficients=0: %8.5g %%\n"),
		  result->probability_all_zero()*100.0);
	  showresult += strbuffer;
	}

      if(check_only_constant)
	{
	  sprintf(strbuffer, WHAT((char *) "Sannsynlighet for kun "
				  "konstant: %8.5g %%\n",
				  (char *) "Probability for only "
				  "constant: %8.5g %%\n"),
		  result->probability_only_constant()*100.0);
	  showresult += strbuffer;
	}
    }

  bool *used=new bool[numseries]; 
  for(i=0;i<numseries;i++)
    used[i]=False;

  used[response_index]=True;
  showresult += "\n";
  showresult += alias[response_index];
  showresult += " = \"";
  showresult += titles[response_index];
  showresult += "\"\n";

  for(i=0;i<numpredictors;i++)
    {
      if(!used[predictor_index[i]])
	{
	  showresult += alias[predictor_index[i]];
	  showresult += " = \"";
	  showresult += titles[predictor_index[i]];
	  showresult += "\"\n";
	  used[predictor_index[i]]=True;
	}
      else if(interaction_index && interaction_index[i]>=0 && 
	      !used[interaction_index[i]])
	{
	  showresult += alias[interaction_index[i]];
	  showresult += " = \"";
	  showresult += titles[interaction_index[i]];
	  showresult += "\"\n";
	  used[interaction_index[i]]=True;
	}
    }
  
  show_goodness_of_fit();
  show_residual_trend();
  //show_residual_normality();

  sprintf(str, WHAT((char *) "\nSannsynelighetstetthet for modellen: "
		    "%8.5g\n",
		    (char *) "\nProbability density for the model: "
		    "%8.5g\n"),
	  result->probability_density_of_data());
  showresult+=str;

  showresult += "\n";
  showresult += WHAT((char *) "Kovarians-matrise elementer\n", 
		     (char *) "Covariance matrix elements;\n");
  sprintf(strbuffer, "%3s %7s | %10s %16s\n", 
	  WHAT((char *) "Rad", (char *) "Row"), 
	  WHAT((char *) "Kolonne", (char *) "Column"), 
	  WHAT((char *) "Kovarianse", (char *) "Covariance"), 
	  WHAT((char *) "Est. korrelasjon", 
	       (char *) "Est. correlation")); 
  showresult += strbuffer;
	
  for(i=0;i<numpredictors+1;i++)
    for(int j=0;j<=i;j++)
      {
	sprintf(strbuffer, "%3d %7d : %10.3g\n", i, j,
		result->get_covariance_coefficient(i,j));
	showresult += strbuffer;
      }
}

void show_bay_reg::show_goodness_of_fit(void)
{
  double *residual=fetch_residuals();
  int i;
  double var=0.0, mean=0.0, rss=0.0, *meas=new double[len], goodness;
  char str[1000];

  for(i=0;i<len;i++)
    meas[i]=bay_reg_funcvalue(serievalues[response_index][i],
			      response_func, response_scale);

  for(i=0;i<len;i++)
    mean+=meas[i];
  mean/=double(len);

  for(i=0;i<len;i++)
    {
      var += (meas[i]-mean)*(meas[i]-mean);
      rss += residual[i]*residual[i];
    }
  
  goodness = 1.0 - rss/var;

  delete [] residual;
  delete [] meas;

  showresult+="\n";
  sprintf(str,  "Goodness-of-fit: %8.3g %%", goodness*100.0);
  showresult+=str;
  showresult+="\n";
}

double *show_bay_reg::fetch_residuals(void)
{
  if(len==0)
    return NULL;

  int i,j;
  double *residual=new double[len];
  
  for(i=0;i<len;i++)
    {
      double meas = bay_reg_funcvalue(serievalues[response_index][i],
				      response_func, response_scale);
      double pred = 0.0;
	  
      for(j=0;j<numpredictors;j++)
	if(interaction_index && interaction_index[j]>=0)
	  pred += result->get_mean_coefficient(j)*
	    bay_reg_funcvalue(serievalues[predictor_index[j]][i],
			      predictor_func[j], predictor_scales[j])*
	    bay_reg_funcvalue(serievalues[interaction_index[j]][i],
			      interaction_func[j], interaction_scales[j]);
	else
	  pred += result->get_mean_coefficient(j)*
	    bay_reg_funcvalue(serievalues[predictor_index[j]][i],
			      predictor_func[j], predictor_scales[j]);
      
      residual[i]=meas-pred;
    }

  return residual;
}

// fetches values as x-coordinate and residuals as y-coordinates;
double_2d *show_bay_reg::fetch_values_and_residuals(void)
{
  double *residual=fetch_residuals();
  double_2d *result=new double_2d[len];

  for(int i=0;i<len;i++)
    {
      result[i].x=bay_reg_funcvalue(serievalues[response_index][i],
				    response_func, response_scale);
      result[i].y=residual[i];
    }

  delete [] residual;

  return result;
}

void show_bay_reg::show_residual_trend(void)
{
  char str[1000];

  showresult+="\n";
  sprintf(str, WHAT((char *) "Sannsynelighet for ingen trend: %8.3g %%",
		    (char *) "Probability for having no trend: %8.3g %%"),
	  result->probability_no_autocorrelation()*100.0);
  showresult+=str;
  showresult+="\n";
}

void show_bay_reg::show_residual_normality(void)
{
  double *residuals=fetch_residuals();
  double skew=find_statistics(residuals, len, SKEW);
  double curtosis=find_statistics(residuals, len, CURTOSIS);

  // experimentally found expressions for standard deviations as a function of
  // the sample size;
  double sdev_skew=sqrt(5.42*pow(len+1.92, -0.979));
  double sdev_curt=sqrt(41.73*pow(len+22.0, -1.095));

  double test_skew=-ABSVAL(skew/sdev_skew);
  double test_curt=-ABSVAL((curtosis-3.0)/sdev_curt);

#ifdef GSL
  double p_skew=test_skew>-37.0 ? gsl_cdf_ugaussian_P(test_skew) : 0.0;
  double p_curt=test_curt>-37.0 ? gsl_cdf_ugaussian_P(test_curt) : 0.0;
#endif

  char str[1000];

  showresult+="\n";
  showresult += WHAT((char *) "Normalitets-analyse:\n", 
		     (char *) "Normality analysis:");
  sprintf(str, WHAT((char *) "Residualenes skjevhet: %6.3f   "
		    "p-verdi for normalitet: %8.3g %%",
		    (char *) "Skew of the residuals: %6.3f   "
		    "p-value for normality: %8.3g %%"),
	  skew, p_skew*100.0);
  showresult+=str;
  showresult+="\n";
  sprintf(str, WHAT((char *) "Residualenes kurtose: %6.3f   "
		    "p-verdi for normalitet: %8.3g %%",
		    (char *) "Curtosis of the residuals: %6.3f   "
		    "p-value for normality: %8.3g %%"),
	  curtosis, p_curt*100.0);
  showresult+=str;
  showresult+="\n";

  delete [] residuals;
}

void show_bay_reg::cleanup(void)
{
  int i=0;

  len=0;

  if(serievalues)
    {
      for(i=0;i<numseries;i++)
	if(serievalues[i])
	  delete [] serievalues[i];
      delete [] serievalues;
    }
  serievalues=NULL;

  if(titles)
    {
      for(i=0;i<numseries;i++)
	if(titles[i])
	  delete [] titles[i];
      delete [] titles;
    }
  titles=NULL;
  
  if(alias)
    {
      for(i=0;i<numseries;i++)
	if(alias[i])
	  delete [] alias[i];
      delete [] alias;
    }
  alias=NULL;
  
  if(aliaslab)
    delete [] aliaslab;
  aliaslab=NULL;

  if(result)
    delete result;
  result=NULL;

  cleanpredictors();
  numpredictors=0;

  if(plot)
    delete plot;
  plot=NULL;

  if(currentrule)
    delete currentrule;
  currentrule=NULL;

  if(curr_coef_mean)
    delete [] curr_coef_mean;
  curr_coef_mean=NULL;
  if(curr_coef_sdev)
    delete [] curr_coef_sdev;
  curr_coef_sdev=NULL;
  if(curr_prob_zero)
    delete [] curr_prob_zero;
  curr_prob_zero=NULL;
}


void show_bay_reg::make_window(void)
{
  int i;
  char *pred_resp[]={WHAT((char *) "Prediktor", (char *) "Predictor"),
		     WHAT((char *) "Respons", (char *) "Response")};

  build(mainwin::toplevel, WHAT((char *) "Regresjons-analyse", 
				(char *) "Bay_Reg analysis"));
  v1.build(*this);
  
  h1.build(v1);
  pred_or_resp.vbuild(h1, pred_resp, 2, 1);
  v10.build(h1);
  h10.build(v10);
  variablemenu1.Create(h10, WHAT((char *) "Variabel:", (char *) "Variable:"));
  variablemenu1.Insert(alias, numseries, 0);
  fchoice.create(h10, this, True);
  v5.build(h10);
  scalef.build(v5, 10, WHAT((char *) "Skalering:", (char *) "Scaling:"));
  //scalef.SetText("0.0");
  //scalef.EditAble(True);

  //  interaction widgets;
  h11.build(v10);
  variablemenu4.Create(h11, WHAT((char *) "Interaksjons-variabel:",
				(char *) "interaction variable:"));
  char **itembuf=new char*[numseries+1];
  for(i=0;i<numseries+1;i++)
    itembuf[i]=new char[100];
  strcpy(itembuf[0], WHAT((char *) "Ingen", (char *) "None"));
  for(i=0;i<numseries;i++)
    strcpy(itembuf[i+1], alias[i]);
  variablemenu4.Insert(itembuf, numseries+1, 0);
  for(i=0;i<numseries+1;i++)
    delete [] itembuf[i];
  delete [] itembuf;
  fchoice2.create(h11, this, False);
  v9.build(h11);
  scalef2.build(v9, 10, WHAT((char *) "Skalering:", (char *) "Scaling:"));
  //scalef2.SetDouble(0.0);
  //scalef2.EditAble(True);

  v4.build(h1);
  addb.create(v4, WHAT((char *) "Legg til prediktor/respons", 
		       (char *) "Add predictor or response"),
	      this, BAY_REG_ADD);
  
  h2.build(v1);
  predictorlist.Create(h2, this);


  v3.build(h2);
  changepredb.create(v3, WHAT((char *) "Forandre liste-element",
			      (char *) "Change list element"), this,
		     BAY_REG_CHANGE_PREDICTOR);
  removepredb.create(v3, WHAT((char *) "Fjerne liste-element",
			      (char *) "Remove list element"), this,
		     BAY_REG_REMOVE_PREDICTOR);

  v8.build(h2);
  sc.build(v8);
  sc.Height(80);
  sc.Width(450);
  v2.build(sc);
  aliaslab=new label[numseries];
  for(i=0;i<numseries;i++)
    aliaslab[i].build(v2, "%s=%s",alias[i],titles[i]);
  changedescb.create(v8, WHAT((char *) "Forandre beskrivelser", 
			      (char *) "Change descriptions"), this,
		     BAY_REG_CHANGE_DESCRIPTIONS);
		     


  use_constant.create(v1, this);

  resultlab.build(v1, "? = ?");
  h3.build(v1);
  runb.create(h3, WHAT((char *) "Kj�r regresjonsanalyse",
		       (char *) "Run bay_reg analysis"), this,
	      BAY_REG_RUN);
  runb.Background("green");
  runb.Foreground("black");

  changepriorb.create(h3, WHAT((char *) "Forandre apriori-sannynligheter",
			       (char *) "Change apriori probabilities"),
		      this, BAY_REG_CHANGEPRIOR);

  h8.build(v1);
  showresult.build(h8, 100, 10);
  
  v11.build(h8);
  predictorsc.build(v11);
  predictorsc.Height(100);
  predictorsc.Width(200);
  predictorv1.build(predictorsc);
  predictorf=NULL;
  predictorh=NULL;
  predictorh1.build(v11);
  credibilityf.build(predictorh1, 5, WHAT((char *) "Troverdighet (%): ",
					  (char *) "Credibility (%): "));
  credibilityf.SetDigit(5);
  predictb.create(predictorh1, WHAT((char *) "Kj�r prediksjon",
				    (char *) "Run prediction"), 
		  this, BAY_REG_PREDICT);
  predictb.InSensitive();
  predictionlab.build(v11, "                                              ");
  predictionlab.Background("white");
  predictionlab.Foreground("black");
  transformedlab.build(v11,"");
  mean_pred.build(v11, WHAT((char *) "Troverdighetsgrense til forventet "
			    "prediksjon?", 
			    (char *) "Credibility limits for mean "
			    "predictions?")); 
  
  h7.build(v1);
  altmenu.create(h7);
  v7.build(h7);
  
  h4.build(v7);
  plotlab.build(h4, WHAT((char *) "Plotting av respons/residual-variabel mot ",
			 (char *) "Plot response/residual variable against "));
  variablemenu2.Create(h4, WHAT((char *) "variabel:", (char *) "variable:"));
  variablemenu2.Insert(alias, numseries, 0);
  plotvarb.create(h4, WHAT((char *) "Plott", (char *) "Plot"), this,
		  BAY_REG_PLOT_VARIABLE);

  h5.build(v7);
  plotlab.build(h5, WHAT((char *) "Plotting av respons/residual mot ",
			 (char *) "Plot response/residual against "));
  variablemenu3.Create(h5, WHAT((char *) "prediktor:", (char *) "predictor:"));
  //variablemenu3.Inserts(alias, numseries, 0);
  plotpredb.create(h5, WHAT((char *) "Plott", (char *) "Plot"), this,
		   BAY_REG_PLOT_PREDICTOR);
  
  sep1.build(v1);
  
  h6.build(v1);
  closeb.create(h6, WHAT((char *) "Lukk vindu", (char *) "Close window"),
		this, BAY_REG_CLOSE);
  closeb.Background("red");
  closeb.Foreground("white");

  spacelab.build(h6, "       ");
  savefileb.create(h6, WHAT((char *) "Lagre resultattekst p� fil", 
			    (char *) "Save result texct on file"), this,
		   BAY_REG_SAVEFILE);
  savefileb.Background("yellow");
  savefileb.Foreground("black");
  printb.create(h6, WHAT((char *) "Skriv ut", (char *) "Print"), this,
		BAY_REG_PRINT);
  printb.Background("blue");
  printb.Foreground("white");
  printerlab.build(h6, WHAT((char *) "Skriver: %s", (char *) "Printer: %s"),
		 getenv("PRINTER"));
  changeprinterb.create(h6, WHAT((char *) "Forandre skriver", 
				 (char *) "Change printer"), this,
			BAY_REG_CHANGEPRINTER);

  Map();
}


void show_bay_reg::startchangeprinter(void)
{
  prsh.create(this);
}

void show_bay_reg::start_savefile(void)
{
  fsel.Create(this);
}

void show_bay_reg::doprint(void)
{
  FILE *p=popen("lpr", "w");
  if(!p)
    {
      err.build(*this, WHAT((char *) "Eksekveringsfeil", 
			    (char *) "Execution error"),
		WHAT((char *) "Klarte ikke � �pne pipe til lpr",
		     (char *) "Couldn't open pipe to lpr"));
      return;
    }

  fprintf(p, "%s\n", showresult.GetText());

  fprintf(p, "%s", showresult.GetText());
  pclose(p);
}

void show_bay_reg::savefile_chosen(const char *filename)
{
    std::ofstream out;

    out.open(filename, std::ios::out);
  if(out.fail())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � �pne filen for skriving!", 
		     (char *) "Couldn't open the file for writing!"));
      return;
    }
  
  out << showresult.GetText() << "\n";
  out.close();
}

void show_bay_reg::printer_changed(const char *newprinter)
{
  printerlab.labelString(WHAT((char *) "Skriver: %s",
			      (char *) "Printer: %s"), newprinter);
}

void show_bay_reg::take_action(BAY_REG_ACTION action)
{
  switch(action)
    {
    case BAY_REG_CHANGE_DESCRIPTIONS:
      descript_change.Create(this, alias, titles, numseries);
      break;
    case BAY_REG_RUN:
      run_bay_reg();
      break;
    case BAY_REG_CHANGEPRIOR:
      start_change_prior();
      break;
    case BAY_REG_PREDICT:
      predict();
      break;
    case BAY_REG_ADD: 
      add();
      break;
    case BAY_REG_REMOVE_PREDICTOR: 
      removepredictor();
      break;
    case BAY_REG_CHANGE_PREDICTOR:
      changepredictor();
      break;
    case BAY_REG_POW:
      fetch_pow(True);
      break;
    case BAY_REG_DEFAULT_CHOICE:
      set_default_choice();
      break;
    case BAY_REG_TRIGONOMETRIC:
      fetch_trigonometric(True);
      break;
    case BAY_REG_POW2:
      fetch_pow(False);
      break;
    case BAY_REG_TRIGONOMETRIC2:
      fetch_trigonometric(False);
      break;
    case BAY_REG_CLOSE:
      close();
      break;
    case BAY_REG_PLOT_VARIABLE:
      doplot(False);
      break;
    case BAY_REG_PLOT_PREDICTOR:
      doplot(True);
      break;
    case BAY_REG_PRINT:
      doprint();
      break;
    case BAY_REG_CHANGEPRINTER:
      startchangeprinter();
      break;
    case BAY_REG_SAVEFILE:
      start_savefile();
      break;
    }
}

void show_bay_reg::list_hit(int index)
{
  if(response_set && index==0)
    {
      pred_or_resp.SetFocus(1);
      variablemenu1.SetFocus(response_index);
      variablemenu4.SetFocus(0);
      fchoice.set_function_type(response_func);
      scalef.SetDouble(response_scale);
      //scalef.EditAble(True);
    }
  else
    {
      int index2=response_set ? index-1 : index;

      if(use_constant())
	index2++;

      pred_or_resp.SetFocus(0);
      variablemenu1.SetFocus(predictor_index[index2]);
      fchoice.set_function_type(predictor_func[index2]);
      scalef.SetDouble(predictor_scales[index2]);
      //scalef.EditAble(True);
      variablemenu4.SetFocus(interaction_index[index2]+1);
      fchoice2.set_function_type(interaction_func[index2]);
      scalef2.SetDouble(interaction_scales[index2]);
      //scalef2.EditAble(True);
    }
}

void show_bay_reg::set_descriptions(char const* const* newalias, char const* const* newtitle, 
				    int num)
{
  int i;

  if(titles)
    {
      for(i=0;i<numseries;i++)
	if(titles[i])
	  delete [] titles[i];
      delete [] titles;
    }
  
  if(alias)
    {
      for(i=0;i<numseries;i++)
	if(alias[i])
	  delete [] alias[i];
      delete [] alias;
    }
  
  titles=new char*[num];
  alias=new char*[num];
  for(i=0;i<num;i++)
    {
      alias[i]=new char[strlen(newalias[i])+2];
      strcpy(alias[i], newalias[i]);
      titles[i]=new char[strlen(newtitle[i])+2];
      strcpy(titles[i], newtitle[i]);
    }

  update_bay_reg_type();

  for(i=0;i<numseries;i++)
    aliaslab[i].labelString("%s=%s",alias[i],titles[i]);
  variablemenu1.Insert(alias, numseries, 0);
  variablemenu2.Insert(alias, numseries, 0);

  char **itembuf=new char*[numseries+1];
  for(i=0;i<numseries+1;i++)
    itembuf[i]=new char[100];
  strcpy(itembuf[0], WHAT((char *) "Ingen", (char *) "None"));
  for(i=0;i<numseries;i++)
    strcpy(itembuf[i+1], alias[i]);
  variablemenu4.Insert(itembuf, numseries+1, 0);
  for(i=0;i<numseries+1;i++)
    delete [] itembuf[i];
  delete [] itembuf;
}

void show_bay_reg::set_new_priors(double *mean,double *sdev,
				  double *probability_of_zero, 
				  double probability_of_all_zero,
				  double probability_of_only_constant,
				  double sigma_mean, double sigma_sdev,
				  double prob_autocorr)
{
  for(int i=0;i<numpredictors;i++)
    {
      curr_coef_mean[i]=mean[i];
      curr_coef_sdev[i]=sdev[i];
      curr_prob_zero[i]=probability_of_zero[i];
    }

  curr_prob_all_zero=probability_of_all_zero;
  curr_prob_only_constant=probability_of_only_constant;
  curr_sigma_mean=sigma_mean;
  curr_sigma_sdev=sigma_sdev;
  curr_prob_autocorr=prob_autocorr;
}

show_bay_reg::show_bay_reg()
{
  response_set = False;
  numseries = 0;
  len = 0;
  serievalues = NULL;
  titles   = NULL;
  alias    = NULL;
  aliaslab = NULL;
  result   = NULL;
  predictor_index  = NULL;
  predictor_func   = NULL;
  predictor_scales = NULL;
  interaction_index  = NULL;
  interaction_func   = NULL;
  interaction_scales = NULL;
  plot = NULL;
  currentrule = NULL;
  curr_coef_mean=curr_coef_sdev=curr_prob_zero=NULL;
  curr_prob_autocorr=0.1;
}

show_bay_reg::~show_bay_reg(void)
{
  cleanup();
}

void show_bay_reg::Create(double **seriedata, int length, 
			  int numseries_, char const* const* serietitles, 
			  double standard_prior_constant_estimate_, 
			  double standard_prior_constant_sdev_, 
			  double standard_prior_coefficient_estimate_,
			  double standard_prior_coefficient_sdev_,
			  double standard_prior_sigma_estimate_,
			  double standard_prior_sigma_sdev_)
{
  int i,j;


  cleanup();

  check_all_zero=check_only_constant=False;

  standard_prior_constant_estimate=standard_prior_constant_estimate_;
  standard_prior_constant_sdev=standard_prior_constant_sdev_;
  standard_prior_coefficient_estimate=standard_prior_coefficient_estimate_;
  standard_prior_coefficient_sdev=standard_prior_coefficient_sdev_;
  standard_prior_sigma_estimate=standard_prior_sigma_estimate_;
  standard_prior_sigma_sdev=standard_prior_sigma_sdev_;

  numseries=numseries_;
  

  curr_sigma_mean=standard_prior_sigma_estimate;
  curr_sigma_sdev=standard_prior_sigma_sdev;
  curr_prob_all_zero=0.05;
  curr_prob_only_constant=0.05;
  curr_prob_autocorr=0.1;
  

  response_set=False;

  // copy the incoming data;
  serievalues = new double*[numseries];
  titles = new char*[numseries];
  alias  = new char*[numseries];

  int timeindex  = 1;
  int valueindex = 1;
  len = length;

  for(i=0;i<numseries;i++)
    {
      serievalues[i] = new double[length];
      titles[i] = new char[strlen(serietitles[i])+2];
      alias[i]  = new char[10];

      strcpy(titles[i], serietitles[i]);
      if(!strncasecmp(titles[i], WHAT((char *) "Tid", "Time"), WHAT(3,4)))
	sprintf(alias[i], "T%d", timeindex++);
      else
	sprintf(alias[i], "X%d", valueindex++);

      for(j=0;j<length;j++)
	serievalues[i][j]=seriedata[i][j];
    }

  make_window();
}

void show_bay_reg::bay_reg_done(bay_reg_rule* /* rule */)
{
}

#ifdef MAIN

void main(int argc, char **argv)
{
  int i, j, len=100;;
  mainwin mn("show_bay_reg", argc, argv);
  double **values=new double*[3];
  char **titles=new char*[3];
  show_bay_reg sr;

  for(i=0;i<3;i++)
    {
      titles[i] = new char[100];
      values[i] = new double[len];
    }

  strcpy(titles[0], "x");
  strcpy(titles[1], "y");
  strcpy(titles[2], "z");

  for(j=0;j<len;j++)
    {
      values[1][j] = 0.9*drand48()+0.1;
      values[0][j] = 2.0*pow(values[1][j], 1.5) + 0.1*drand48()-0.05;
      values[2][j] = drand48();
    }

  sr.Create(values, len, 3, titles);
  mn.Run();
}

#endif // MAIN
