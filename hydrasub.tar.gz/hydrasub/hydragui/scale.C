/*
 * $Id: scale.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/scale.C $
 */

#include <hydrasub/hydragui/scale.H>

#include <Xm/Scale.h>
#include <X11/Intrinsic.h>
#include <Xm/XmStrDefs.h>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void scale::build(const Widget parent, const char *title, int min, int max, 
		  int value) 
{
  xmstring xtitle(title);
  
  XmInitSetArg(XmNtitleString, (XmString &)xtitle);
  XmSetArg(XmNmaximum, max);
  XmSetArg(XmNminimum, min);
  XmSetArg(XmNvalue, value);
  XmSetArg(XmNshowValue, True);
  XmSetArg(XmNorientation, direction());
  init(title, xmScaleWidgetClass, parent);
  
  XtAddCallback(w, XmNvalueChangedCallback, 
		(XtCallbackProc)&scale::changedCB,
		(XtPointer)this);
}

void scale::SetMin(int newmin)
{
  XtVaSetValues(w, XmNminimum, newmin, NULL);
}

void scale::SetMax(int newmax)
{
  XtVaSetValues(w, XmNmaximum, newmax, NULL);
}

void scale::changedCB(Widget , scale *pt, XtPointer)
{
  pt->changed();
}

void scale::changed(void)
{

}

// ######################################################################
// Return    : void
// Parameters: value - the new value that should be set
// Purpose   : set the value of the scale from a program
// ######################################################################
void scale::SetValue(int value)
{
  XtVaSetValues(w, XmNvalue, value, NULL);
    
  //XmSetArg(XmNvalue, value);
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
int scale::operator()() {
    int v;
    XmScaleGetValue(w, &v);
    return v;
}



void scale_arrow::Create(widget parent, ARROWB_DIR direction, 
			 scale_with_arrows *ipt, SCALE_TYPE type)
{
  typ=type;
  pt=ipt;
  build(parent, direction);
}

void scale_arrow::pushed(void)
{
  if(typ==SCALE_UP)
    pt->up();
  else
    pt->down();
}


void scale_with_arrows::up(void)
{
}

void scale_with_arrows::down(void)
{
}

void scale_with_arrows::build(widget /* parent */, 
			      const char* /*title */, 
			      int /* min */, 
			      int /* max */,
			      int /* value */,
			      int /* increment */)
{
}


void vscale_with_arrows::up(void)
{
  int val=(*this)();
  val+=increment;
  if(val<=max)
    {
      SetValue(val);
      changed();
    }
}

void vscale_with_arrows::down(void)
{
  int val=(*this)();
  val-=increment;
  if(val>=min)
    {
      SetValue(val);
      changed();
    }
}

void vscale_with_arrows::build(widget parent, const char *title, 
			       int min, int max, int value,
			       int increment)
{
  this->increment=increment;
  this->min = min;
  this->max = max;

  h1.build(parent);
  v1.build(h1);

  vup.build(v1);
  hup.build(vup);
  upb.Create(hup, ARROWB_UP, this, SCALE_UP); 

  scale::build(v1, title, min, max, value); 
  
  vdown.build(v1);
  hdown.build(vdown);
  downb.Create(hdown, ARROWB_DOWN, this, SCALE_DOWN);
}

void hscale_with_arrows::up(void)
{
  int val=(*this)();
  val+=increment;
  if(val<=max)
    {
      SetValue(val);
      changed();
    }
}

void hscale_with_arrows::down(void)
{
  int val=(*this)();
  val-=increment;
  if(val>=min)
    {
      SetValue(val);
      changed();
    }
}

void hscale_with_arrows::build(widget parent, const char *title, 
			       int min, int max, int value,
			       int increment)
{
  this->increment = increment;
  this->min = min;
  this->max = max;

  v1.build(parent);
  h1.build(v1);

  vdown.build(h1);
  hdown.build(vdown);
  downb.Create(hdown, ARROWB_LEFT, this, SCALE_DOWN); 

  scale::build(h1, title, min, max, value); 
  
  vup.build(h1);
  hup.build(vup);
  upb.Create(hup, ARROWB_RIGHT, this, SCALE_UP);
}




