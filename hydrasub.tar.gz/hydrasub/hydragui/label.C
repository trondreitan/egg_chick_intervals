/*
 * $Id: label.C 2545 2015-09-15 14:50:17Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/label.C $
 */

#include <hydrasub/hydragui/label.H>
 
#include <stdarg.h>
#include <stdio.h>
#include <Xm/Label.h>

label::label()
{
  content=NULL;
}

label::~label()
{
  if(content)
    delete [] content;
}

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void label::build(const Widget parent, const char *fmt, ...) 
{
  char buf[BUFSIZ];
  va_list ap;
  va_start(ap, fmt);
  vsprintf(buf, fmt, ap);
  
  xmstring xstr(buf);
  XmInitSetArg(XmNlabelString, (XmString &)xstr);
  init(buf, xmLabelWidgetClass, parent);
  
  va_end(ap);
  
  if(content)
    delete [] content;
  content=new char[strlen(buf)+2];
  strcpy(content, buf);
}

// ######################################################################
// Return    : void
// Parameters: fmt - format string just like printf()
// Purpose   : set new labelString for label
// ######################################################################
void label::labelString(const char *fmt, ...)
{
  char buf[BUFSIZ];
  va_list ap;
  va_start(ap, fmt);
  vsprintf(buf, fmt, ap);
  
  xmstring xstr(buf);
  XtVaSetValues(w, XmNlabelString, (XmString &)xstr, NULL);
  
  va_end(ap);

  if(content)
    delete [] content;
  content=new char[strlen(buf)+2];
  strcpy(content, buf);
} /* labelString */


// ######################################################################
// Return    : current content in the form of a string
// Parameters: void
// Purpose   : get string for label
// ######################################################################
const char *label::getString(void)
{
  return content;
}

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Align text from beginning
// ######################################################################
void label::align_beginning() {
  XtVaSetValues(w, XmNalignment, XmALIGNMENT_BEGINNING, NULL);
}

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Align text from end
// ######################################################################
void label::align_end() {
  XtVaSetValues(w, XmNalignment, XmALIGNMENT_END, NULL);
}

// ######################################################################
// Return    : void
// Parameters: void
// Purpose   : Align text from center
// ######################################################################
void label::align_center() {
  XtVaSetValues(w, XmNalignment, XmALIGNMENT_CENTER, NULL);
}

