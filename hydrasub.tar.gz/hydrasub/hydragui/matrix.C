/*
 * $Id: matrix.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/matrix.C $
 */

#include <hydrasub/hydragui/matrix.H>
#include <ctype.h>

#include <Xbae/Caption.h>
#include <cstring>
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydrabase/divfunc.H>
#include <X11/Xdmcp.h>

#define COLOR_NUMBER 20
char *matrix_color[COLOR_NUMBER]={"black","coral3","dark orange",
				  "#a08000","dark green","blue4",
				  "dark violet","red","dark red","blue",
				  "violet","steelblue4","orange", "dark cyan",
				  "green","magenta","#55aa00",
				  "grey32","indigo","burlywood4"};


matrix::matrix(void)
{
  only_one_marked=False;
  lastrow=-1;
  numins=1;
  selectedrows=NULL; 
  column_restrictions=NULL;
  colarray=NULL;
  matrixpixels=NULL;
  display=NULL;
  prev_numrows=0;
}

matrix::~matrix()
{
  if(selectedrows)
    delete [] selectedrows;
  if(column_restrictions)
    delete [] column_restrictions;
}

void matrix::modified(int,int)
{
}

// set the color of a row 
void matrix::setrowcolor(int row,int color)
{
  if(!matrixpixels)
    fetch_fixed_colors();

  for(int i=0;i<numcolumns();i++)   
    XbaeMatrixSetCellColor(w,row,i,matrixpixels[color]);    
}

//      set the color of a single cell
void    matrix::setcellcolor(int row, int column, int color)
{
  if(!matrixpixels)
    fetch_fixed_colors();

  XbaeMatrixSetCellColor(w,row,column,matrixpixels[color]);
}

// Should be called before getrowcolor and getcellcolor in order
// to fetch color values into local arrays;
bool matrix::fetch_matrix_colors(void)
{
  colarray=NULL;
  prev_numrows=0;

  XtVaGetValues(w, XmNcolors, &colarray, NULL);
  if(!colarray)
    return False;
  prev_numrows=numrows();

  if(!matrixpixels)
    fetch_fixed_colors();

  return True;
}

void matrix::fetch_fixed_colors(void)
{
  if(!display)
    {
      display = XtDisplay(w);
      cmap = XDefaultColormap(display, DefaultScreen(display));
    }

  matrixpixels=new Pixel[COLOR_NUMBER];
  for(int i=0;i<COLOR_NUMBER;i++)
    {
      XColor col;
      
      XParseColor(display, cmap, matrix_color[i], &col);
      XAllocColor(display, cmap, &col);
      
      matrixpixels[i]=col.pixel;
    }
}

int matrix::getrowcolor(int row)
{
  Pixel prow;

  if(!matrixpixels || !colarray)
    {
      matrixerr.build(mainwin::toplevel, WHAT((char *) "Programfeil!", 
					      (char *) "Program error!"),
		      WHAT((char *) "'getrowcolor' kalt f�r 'fetch_matrix_colors'",
			   (char *) "'getrowcolor' called before "
			   "'fetch_matrix_colors'"));
      return -1;
    }

  prow=**(colarray+row);
  
  for(int i=0;i<COLOR_NUMBER;i++)
    if(matrixpixels[i]==prow)
      return i;

  return -1;
}

int matrix::getcellcolor(int row, int column)
{
  Pixel prow;

  if(!matrixpixels || !colarray)
    {
      matrixerr.build(mainwin::toplevel, WHAT((char *) "Programfeil!", 
					      (char *) "Program error!"),
		      WHAT((char *) "'getcellcolor' kalt f�r 'fetch_matrix_colors'",
			   (char *) "'getcellcolor' called before "
			   "'fetch_matrix_colors'"));
      return -1;
    }

  prow=colarray[row][column];

  for(int i=0;i<COLOR_NUMBER;i++)
    if(matrixpixels[i]==prow)
      return i;

  return -1;
}


String matrix::getcell(int column, int row)
{
  return XbaeMatrixGetCell(w,row,column);
}

//      make the given column receptive only to characters
//      describing a datetime
void    matrix::set_datetime_column(int column_number)
{
  column_restrictions[column_number]=COLUMN_DATETIME;
}

//      make the given column receptive only to characters
//      describing a number
void    matrix::set_number_column(int column_number)
{
  column_restrictions[column_number]=COLUMN_NUMBERS;
}

//      allow all characters on the given column
void    matrix::set_text_column(int column_number)
{
  column_restrictions[column_number]=COLUMN_TEXT;
}

//      allow no characters modifications on the given column
void    matrix::set_noedit_column(int column_number)
{
  column_restrictions[column_number]=COLUMN_NOEDIT;
}


void matrix::deleterows(int pos,int num)
{
  XbaeMatrixDeleteRows(w,pos,num);
  deselectall();
  commit_edit(True);
}

bool matrix::ismarked(void)
{
  bool ok=False;
  for(int i=0;i<numrows();i++)
    if(selectedrow(i))
      ok=True;
  return ok;
}

void matrix::insertselectedafter(int num,int color)
{
  int i,j;
  char **labels;
  
  labels=new char*[num];
  for(j=0;j<num;j++)
    labels[j]=new char[10];
  
  for(i=(numrows()-1);i>=0;i--)
    if(selectedrow(i))
      {
	for(j=0;j<num;j++)
	  sprintf(labels[j],"i%d",numins+j);
	numins+=num;
	XbaeMatrixAddRows(w,i+1,NULL,labels,NULL,num);
	for(j=0;j<num;j++)
	  setrowcolor(i+1+j,color);
      }
  for(j=0;j<num;j++)
    delete [] labels[j];
  delete [] labels;
  deselectall();
  commit_edit(False);
}


void matrix::insertselectedbefore(int num,int color)
{
  int i,j;
  char **labels;
  
  labels=new char*[num];
  for(j=0;j<num;j++)
    labels[j]=new char[10];
  
  for(i=(numrows()-1);i>=0;i--)
    if(selectedrow(i))
      {
	for(j=0;j<num;j++)
	  sprintf(labels[j],"i%d",numins+j);
	numins+=num;
	XbaeMatrixAddRows(w,i,NULL,labels,NULL,num);
	for(j=0;j<num;j++)
	  setrowcolor(i+j,color);
      }
  for(j=0;j<num;j++)
    delete [] labels[j];
  delete [] labels;
  deselectall();
  commit_edit(False);
}


void matrix::deleteselected(void)
{
  for(int i=(numrows()-1);i>=0;i--)
    if(selectedrow(i))
      XbaeMatrixDeleteRows(w,i,1);
  selectall();
  deselectall();
  commit_edit(True);
}


void matrix::update(void)
{
  lastrow=-1;
  delete [] selectedrows;
  selectedrows=new bool[numrows()];
}

void matrix::addrows(int pos,String *labels,int num)
{
  XbaeMatrixAddRows(w,pos,NULL,labels,NULL,num);
  deselectall();
}

void matrix::setcell(int column,int row,String str)
{
  XbaeMatrixSetCell(w,row,column,str);
}


void matrix::build(const Widget parent, int rows,
		   int columns, short *width_list,
		   String *column_labels, 
		   String *row_labels,
		   int fixedcolumns,
		   bool onlyonemarked,int maxrows)
{
  short *wl;
  int i;
  static String translations =
    "<Btn1Down>:       SelectCell(start) EditCell(Pointer)\n"
    "<Btn1Motion>:     SelectCell()\n"
    "<Btn1Up>:         SelectCell(end)";

  only_one_marked=onlyonemarked;

  if(!width_list)
    {
      wl=new short[columns];
      for(i=0;i<columns;i++)
	wl[i]=6;
    }
  else
    wl=width_list;

  column_restrictions=new COLUMN_RESTRICTIONS[columns];
  for(i=0;i<columns;i++)
    column_restrictions[i]=COLUMN_TEXT;

  w=XtVaCreateManagedWidget("Matrise",
			    xbaeMatrixWidgetClass,
			    parent,
			    XmNtranslations, 
			    XtParseTranslationTable(translations),
			    XmNrows,rows,
			    XmNcolumns,columns,
			    XmNcolumnWidths,wl,

			    XmNcellHighlightThickness, 1,
			    XmNcellMarginHeight,       1,
			    XmNcellMarginWidth,        1,
			    XmNcellShadowThickness,    1,
			    XmNtopAttachment,          XmATTACH_WIDGET,
			    XmNtopWidget,              (Widget)parent,
			    XmNleftAttachment,         XmATTACH_FORM,
			    XmNrightAttachment,        XmATTACH_FORM,
			    XmNbottomAttachment,       XmATTACH_FORM,
			    NULL);
  
     
  if(rows<=maxrows)
    XtVaSetValues(w,XmNvisibleRows,rows+2,NULL);
  else
    XtVaSetValues(w,XmNvisibleRows,maxrows+2,NULL);
    

  XtVaSetValues(w,XmNfixedColumns,fixedcolumns,NULL);
  
  if(column_labels)
    XtVaSetValues(w,XmNcolumnLabels,column_labels,NULL);
  
  if(row_labels)
    XtVaSetValues(w,XmNrowLabels,row_labels,NULL);

  
  if(!width_list)
    delete [] wl;
  
  XtAddCallback(w, XmNselectCellCallback, 
		(XtCallbackProc) &matrix::SelectCB, (XtPointer) this);
  
  XtAddCallback(w, XmNmodifyVerifyCallback,
		(XtCallbackProc) &matrix::ModifyCB, (XtPointer) this);

  XtAddCallback(w, XmNenterCellCallback, 
		(XtCallbackProc) &matrix::enterCellCB,
		(XtPointer) this);

  if(selectedrows)
    delete [] selectedrows;
  selectedrows=new bool[rows];
  for(i=0;i<rows;i++)
    selectedrows[i]=False;
  
  for(i=COLOR_NUMBER-1;i>=0;i--)
    setrowcolor(0,i);
}

// **********************************************************************
// enterCell - Check if user is allowed to edit cell
// **********************************************************************
void matrix::enterCellCB(Widget, matrix *pt, 
			 XbaeMatrixEnterCellCallbackStruct *p)
{
  p->doit = pt->valid(p->row, p->column);
}

void matrix::ModifyCB(Widget, matrix *pt,
		      XbaeMatrixModifyVerifyCallbackStruct *call_data)
{
  XmTextVerifyCallbackStruct *tv=(call_data->verify);

  //if(int(tv)<100)
  // return;

  XmTextBlock tb=tv->text;
  char str[100],str2[100];
  
  switch(pt->column_restrictions[call_data->column])
    {
    case COLUMN_NOEDIT:
      tv->doit = False;
      return;
    case COLUMN_TEXT:
      tv->doit = True;
      break;
    case COLUMN_NUMBERS:
      if(tb->length<1 || tb->ptr[0]=='\0' || isdigit(tb->ptr[0]) || 
	 tb->ptr[0]=='.' || tb->ptr[0]==' ' || tb->ptr[0]=='-')
	tv->doit = True;
      else
	{
	  tv->doit = False;
	  return;
	}
      break;
    case COLUMN_DATETIME:
      if(tb->length<1 || tb->ptr[0]=='\0' || isdigit(tb->ptr[0]) || 
	 tb->ptr[0]=='.' || tb->ptr[0]==' ' || tb->ptr[0]=='/' || 
	 tb->ptr[0]==':' || tb->ptr[0]=='-')
	tv->doit = True;
      else
	{
	  tv->doit = False;
	  return;
	}
      break;
    }

  if(tb && tb->ptr)
    sprintf(str,"\"%s\"",tb->ptr);
  else
    sprintf(str,"\"\"");
  sprintf(str2,"\"%s\"",pt->getcell(call_data->column,
				    call_data->row));
  if(strcmp(str,str2))
    pt->modified(call_data->column, call_data->row);
}


void matrix::SelectCB(Widget,matrix *pt,
		      XbaeMatrixSelectCellCallbackStruct *call_data)
{
  // Not interested in columns outside matrix
  if (call_data->row == -1 || call_data->column == -1)
    return;

  if(call_data->num_params == 0 || call_data->num_params > 1e+6)
    pt->MoreSelect(call_data->row, call_data->column);
  else if(strcmp(call_data->params[0], "start") == 0)
    pt->StartSelect(call_data->row, call_data->column);
  else
    pt->EndSelect(call_data->row, call_data->column);
}

bool matrix::valid(int /* row */, int /* column */)
{
  return True;
}

void  matrix::StartSelect(int /* row */, int /* column */)
{
}

void  matrix::MoreSelect(int /* row */, int /* column */)
{
}

void  matrix::EndSelect(int /* row */, int /* column */)
{
}

bool matrix::selectedrow(int row)
{
  return selectedrows[row];
}

bool matrix::selectedcell(int row, int /* column */)
{
  return selectedrows[row];
}


int matrix::numrows(void)
{
  int num;
  
  XtVaGetValues(w, XmNrows, &num, NULL);
  
  return num;
}


int matrix::numcolumns(void)
{
  int num;
  
  XtVaGetValues(w, XmNcolumns, &num, NULL);

  return num;
}

void matrix::deselectall(void)
{
  XbaeMatrixDeselectAll(w);
  update();
  for(int i=0;i<numrows();i++)
    selectedrows[i]=False;
}

void matrix::selectrow(int row)
{
  XbaeMatrixSelectRow(w,row);
  selectedrows[row]=True;
}

void matrix::deselectrow(int row)
{
  XbaeMatrixDeselectRow(w,row);
  selectedrows[row]=False;
}

void matrix::selectcell(int row, int column)
{
  XbaeMatrixSelectCell(w,row,column);
}

void matrix::deselectcell(int row, int column)
{
  XbaeMatrixDeselectCell(w,row,column);
}

void matrix::selectcolumn(int column)
{
  XbaeMatrixSelectColumn(w,column);
}

void matrix::deselectcolumn(int column)
{
  XbaeMatrixDeselectColumn(w,column);
}

void matrix::commit_edit(bool state)
{
  XbaeMatrixCommitEdit(*this, state);
}

void matrix::selectall(void)
{
  update();

  lastrow=numrows()-1;

  for(int i=0;i<numcolumns();i++)
    XbaeMatrixSelectColumn(w, i);
}

#ifdef MAIN
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/row.H>

class lmatrix : public matrix
{
public:
  bool valid(int row, int column);
};

class matmain : public mainwin
{
  vrow v1;
  lmatrix mt;
public:
  matmain(char *title, int argc, char **argv); 
};

matmain::matmain(char *title, int argc, char **argv) : mainwin(title,argc,argv)
{
  v1.build(*this);
  mt.build(v1, 5, 3);
}

bool lmatrix::valid(int row, int column)
{
  if(row==4 && column==1)
    return False;
  else 
    return True;
}

void main(int argc,char **argv)
{
  matmain mat("matmain",argc,argv);
  mat.Run();
}

#endif // MAIN






