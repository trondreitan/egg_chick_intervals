/*
 * $Id: show_regression.C 2569 2015-10-16 11:25:26Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/show_regression.C $
 */

#include <hydrasub/hydragui/show_regression.H>
#include <hydrasub/hydragui/mainwin.H>
#include <cmath>

#ifdef GSL
#include <gsl/gsl_cdf.h>
#endif // GSL

void regress_button::create(widget parent, const char *txt, show_regression *ipt,
			    REGRESS_ACTION action)
{
  pt=ipt;
  type=action;
  build(parent,txt);
}

void regress_button::pushed(void)
{
  pt->take_action(type);
}

void regress_function_choice::create(widget parent, show_regression *ipt, 
				     bool primary)
{
  is_primary=primary;
  pt=NULL;
  Create(parent, WHAT((char *) "Funksjonsvalg", (char *) "Function"));
  Insert(regress_func_names, REGRESS_FUNCTION_NUMBER, 0);
  pt=ipt;
}

void regress_function_choice::pushed(const char* /* item */)
{
  if(pt)
    {
      REGRESS_FUNC_TYPE functype=get_function_type();

      switch(functype)
	{
	case REGRESS_POWER:
	  if(is_primary)
	    pt->take_action(REGRESS_POW);
	  else
	    pt->take_action(REGRESS_POW2);
	  break;
	case REGRESS_SIN:
	case REGRESS_COS:
	  if(is_primary)
	    pt->take_action(REGRESS_TRIGONOMETRIC);
	  else
	    pt->take_action(REGRESS_TRIGONOMETRIC2);
	  break;
	default:
	  break;
	}
    }
}

void regress_savefile::Create(show_regression *ipt)
{
  pt=ipt;
  sh.build(mainwin::toplevel, WHAT((char *) "Velg filnavn:", 
				   (char *) "Choose file name:"));
  v1.build(sh);
  build(v1);
  sh.Map();
}

void regress_savefile::ok(const char *filename)
{
  pt->savefile_chosen(filename);
  sh.Unmap();
}

void regress_savefile::cancel(void)
{
  sh.Unmap();
}

void regress_printershell::create(show_regression *ipt)
{
  pt=ipt;
  Create();
}

void regress_printershell::ok_pushed(const char *newprinter)
{
  pt->printer_changed(newprinter);
}


REGRESS_FUNC_TYPE regress_function_choice::get_function_type(void)
{
  REGRESS_FUNC_TYPE functype=(REGRESS_FUNC_TYPE) GetNumber();
  
  return functype;
}

void regress_function_choice::set_function_type(REGRESS_FUNC_TYPE func)
{
  int num=(int) func;
  SetFocus(num);
}

void regress_plot_alternatives::create(widget parent)
{
  char *alternatives[]=
  { WHAT((char *) "Kurve for gjennomsnittsverdier av de ubrukte prediktorene",
	 (char *) "Curve for mean values of the unused predictors"),
    WHAT((char *) "M�linger", (char *) "Measurements"),
    WHAT((char *) "Kurve+m�linger", (char *) "Curve+measurements"),
    WHAT((char *) "M�linger+prediksjoner", (char *)"Measurements+predictions"),
    WHAT((char *) "Kurve+m�linger+prediksjoner", 
	 (char *) "Curve+measurements+predictions"),
    WHAT((char *) "Residual", (char *) "Residuals"),
    WHAT((char *) "Cooks distanse", (char *) "Cook's distance")};

  activated=False;
  fr.build(parent);
  v1.build(fr);
  Create(v1, WHAT((char *) "", (char *) ""));
  Insert(alternatives, 7, 1);

  h1.build(v1);
  showconfidence.build(h1, WHAT((char *) "Vis konfidensgrenser:", 
				(char *) "Show confidence limits"));
  conff.build(h1, 10, WHAT((char *) "Konfidens-niv�: 1-", 
			   (char *) "Confidence level : 1-"));
  conff.SetDouble(0.05);
  h1.Unmap();

  activated=True;
}

void regress_plot_alternatives::change_numpredictors(int numpred)
{
  numpredictors=numpred;
  
  check_alternatives();
}

void regress_plot_alternatives::check_alternatives(void)
{
  REGRESS_PLOT_ALTERNATIVES alt=get_plot_alternative();
  
  if(alt==REGRESS_PLOT_MEAS)
    h1.Unmap();
  else if(alt==REGRESS_PLOT_CURVE_MEAS)
    {
      if(numpredictors==1)
	h1.Map();
      else
	{
	  showconfidence.ToggleButtonOff();
	  h1.Unmap();
	}
    }
  else
    h1.Map();
}

void regress_plot_alternatives::pushed(const char *)
{
  if(!activated)
    return;

  check_alternatives();
}

REGRESS_PLOT_ALTERNATIVES regress_plot_alternatives::get_plot_alternative(void)
{
  return (REGRESS_PLOT_ALTERNATIVES) GetNumber();
}

bool regress_plot_alternatives::show_confidence(void)
{
  REGRESS_PLOT_ALTERNATIVES alt=get_plot_alternative();
  
  if(alt!=REGRESS_PLOT_MEAS || 
     (alt!=REGRESS_PLOT_CURVE_MEAS || numpredictors==1))
    return showconfidence();
  else
    return False;
}

double regress_plot_alternatives::confidence(void)
{
  REGRESS_PLOT_ALTERNATIVES alt=get_plot_alternative();
  
  if(alt!=REGRESS_PLOT_MEAS || 
     (alt!=REGRESS_PLOT_CURVE_MEAS || numpredictors==1))
    return conff.getdouble();
  else
    return 0.05;
}

void regress_plot_alternatives::set_plot_alternative(REGRESS_PLOT_ALTERNATIVES
						     alternative)
{
  SetFocus((int) alternative);
}




void regress_predictorlist::Create(widget parent, show_regression *ipt)
{
  pt=ipt;
  v1.build(parent);
  lab.build(v1, WHAT((char *) "Liste over brukte prediktorer og respons:  ",
		     (char *) "List of used predictors and response:      "));
  build(v1, 5, 1);
}

void regress_predictorlist::Update(int numpredictors, int *predictor_index, 
				   int *interaction_index, int response_index,
				   REGRESS_FUNC_TYPE *predictor_func,
				   REGRESS_FUNC_TYPE *interaction_func,  
				   REGRESS_FUNC_TYPE response_func, 
				   double *predictor_scales, 
				   double *interaction_scales, 
				   double response_scale, char const* const* alias,
				   bool response_set)
{
  Clear();

  if(response_set)
    {
      char str[100];
      
      make_func_description(response_index, alias, response_func,
			    response_scale, str,
			    WHAT((char *) "Respons", (char *) "Response"));
      Insert(str);
    }
  
  for(int i=0;i<numpredictors;i++)
    {
      char title[100];
      char desc1[100], desc2[100]="",totaldesc[200]; 

      sprintf(title, "%s %i", WHAT((char *) "Prediktor", (char *) "Predictor"),
	      i+1);
      make_func_description(predictor_index[i], alias, predictor_func[i],
			    predictor_scales[i], desc1, title);
      if(interaction_index && interaction_index[i]>=0)
	{
	  strcpy(desc2, "*");
	  make_func_description(interaction_index[i], 
				alias, interaction_func[i],
				interaction_scales[i], desc2+1);
	}

      sprintf(totaldesc, "%s%s", desc1, desc2); 

      Insert(totaldesc);
    }
}

void regress_predictorlist::OneHit(int index, const char *)
{
  pt->list_hit(index-1);
}


void regress_change_descriptors_button::Create(widget parent, const char *txt, 
					       regress_change_descriptors *ipt)
{
  pt=ipt;
  build(parent,txt);
  Background("green");
  Foreground("black");
}

void regress_change_descriptors_button::pushed(void)
{
  pt->ok_pushed();
}

regress_change_descriptors::regress_change_descriptors() : shell()
{
  alias=NULL;
  titles=NULL;
  num_desc=0;
  titlef=NULL;
  aliasf=NULL;
  h=NULL;
}

regress_change_descriptors::~regress_change_descriptors()
{
  cleanup();
}

void regress_change_descriptors::cleanup(void)
{
  int i;

  if(alias)
    {
      for(i=0;i<num_desc;i++)
	if(alias[i])
	  delete [] alias[i];
      delete [] alias;
    }
  alias=NULL;

  if(titles)
    {
      for(i=0;i<num_desc;i++)
	if(titles[i])
	  delete [] titles[i];
      delete [] titles;
    }
  titles=NULL;

  if(h)
    delete [] h;
  h=NULL;

  if(titlef)
    delete [] titlef;
  titlef=NULL;

  if(aliasf)
    delete [] aliasf;
  aliasf=NULL;

  num_desc=0;
}

void regress_change_descriptors::ok_pushed(void)
{
  for(int i=0;i<num_desc;i++)
    {
      delete [] alias[i];
      alias[i]=new char[strlen(aliasf[i]())+2];
      strcpy(alias[i], aliasf[i]());

      delete [] titles[i];
      titles[i]=new char[strlen(titlef[i]())+2];
      strcpy(titles[i], titlef[i]());
    }

  pt->set_descriptions(alias, titles, num_desc);
  Unmap();
}

void regress_change_descriptors::Create(show_regression *ipt, 
					char const* const* alias_, char const* const* title_, int num)
{
  cleanup();

  pt=ipt;

  num_desc=num;
  alias=new char*[num];
  titles=new char*[num];
  h=new hrow[num];
  aliasf=new htextf[num];
  titlef=new htextf[num];

  build(mainwin::toplevel, WHAT((char *) "Forandring av beskrivelse", 
				(char *) "Change of descriptions"));
  v1.build(*this);

  for(int i=0;i<num;i++)
    {
      alias[i]=new char[strlen(alias_[i])+2];
      strcpy(alias[i],alias_[i]);
      titles[i]=new char[strlen(title_[i])+2];
      strcpy(titles[i],title_[i]);

      h[i].build(v1);
      aliasf[i].build(h[i], 6, "Alias:");
      aliasf[i].SetText(alias[i]);
      titlef[i].build(h[i], 40, WHAT((char *) "Tittel:", (char *) "Title:"));
      titlef[i].SetText(titles[i]);
    }

  h1.build(v1);
  okb.Create(h1, "OK", this);
  cancelb.build(h1, this, WHAT((char *) "Avbryt", (char *) "Cancel"));
  cancelb.Background("red");
  cancelb.Foreground("white");

  Map();
}


void show_regression::update_regression_type(void)
{
  predictorlist.Update(numpredictors, predictor_index, interaction_index,
		       response_index, predictor_func, interaction_func,
		       response_func, predictor_scales, interaction_scales,
		       response_scale, alias, response_set);

  show_current_regression_type();
  altmenu.change_numpredictors(numpredictors);

  if(result)
    delete result;
  result=NULL;

  if(predictorf)
    {
      for(int i=0;i<oldprednum;i++)
	predictorh[i].Unmap();
      delete [] predictorf;
      delete [] predictorh;;
    }
  predictorf=NULL;
  predictorh=NULL;
  if(numpredictors>0)
    {
      predictorh=new hrow[numpredictors];
      predictorf=new honlydigit[numpredictors];
    }

  for(int i=0;i<numpredictors;i++)
    {
      char predname[200];
      make_func_description(predictor_index[i], alias, 
			    predictor_func[i], 
			    predictor_scales[i], predname);
      if(interaction_index && interaction_index[i]>=0)
	{
	  int plen=strlen(predname);
	  predname[plen]='*';
	  predname[plen+1]='\0';
	  
	  make_func_description(interaction_index[i], alias, 
				interaction_func[i], 
				interaction_scales[i],
				predname+strlen(predname));
	}

      double mean=0.0;
      for(int j=0;j<len;j++)
	{
	  double arg=regress_funcvalue(serievalues[predictor_index[i]][j],
				       predictor_func[i], 
				       predictor_scales[i]);
	  if(interaction_index && interaction_index[i]>=0)
	    arg *= regress_funcvalue(serievalues[interaction_index[i]][j],
				     predictor_func[i], 
				     predictor_scales[i]);
	  mean += arg;
	}
      mean/=double(len);

      predictorh[i].build(predictorv1);
      predictorf[i].build(predictorh[i], 14, predname);
      predictorf[i].SetDouble(mean);
      predictorf[i].EditAble(True);
    }

  oldprednum=numpredictors;
}

void show_regression::cleanpredictors(void)
{
  if(predictor_index)
    delete [] predictor_index;
  predictor_index=NULL;

  if(predictor_func)
    delete [] predictor_func;
  predictor_func=NULL;

  if(predictor_scales)
    delete [] predictor_scales;
  predictor_scales=NULL;

  if(interaction_index)
    delete [] interaction_index;
  interaction_index=NULL;

  if(interaction_func)
    delete [] interaction_func;
  interaction_func=NULL;

  if(interaction_scales)
    delete [] interaction_scales;
  interaction_scales=NULL;
}

void show_regression::add(void)
{
  int i, varindex = variablemenu1.GetNumber();
  REGRESS_FUNC_TYPE functype = fchoice.get_function_type();
  double scale = scalef.getdouble();

  int varindex2 = variablemenu4.GetNumber()-1;
  REGRESS_FUNC_TYPE functype2 = fchoice2.get_function_type();
  double scale2 = scalef2.getdouble();

  if(pred_or_resp() == 1) // response
    {
      if(varindex2>=0)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Ikke mulig",
					    (char *) "Not possible"),
		    WHAT((char *) "Interaksjon i responsleddet er ikke "
			 "mulig i denne implementasjonen!",
			 (char *) "Interaction in the response is not "
			 "possible in this implementation!"));
	  return;
	}

      if(response_set)
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Respons er allerede satt!",
			 (char *) "Response is already set!"));
	  return;
	}
      
      response_func  = functype;
      response_scale = scale;
      response_index = varindex;
      response_set   = True;

      pred_or_resp.SetFocus(0);
    }
  else // predictor
    {
      int *predindex=new int[numpredictors+1];
      REGRESS_FUNC_TYPE *predfunc=new REGRESS_FUNC_TYPE[numpredictors+1];
      double *predscales=new double[numpredictors+1];
      int *interindex=new int[numpredictors+1];
      REGRESS_FUNC_TYPE *interfunc=new REGRESS_FUNC_TYPE[numpredictors+1];
      double *interscales=new double[numpredictors+1];

      for(i=0;i<numpredictors;i++)
	{
	  predindex[i]  = predictor_index[i];
	  predfunc[i]   = predictor_func[i];
	  predscales[i] = predictor_scales[i];
	  interindex[i]  = interaction_index[i];
	  interfunc[i]   = interaction_func[i];
	  interscales[i] = interaction_scales[i];
	}

      predindex[numpredictors]  = varindex;
      predfunc[numpredictors]   = functype;
      predscales[numpredictors] = scale;
      interindex[numpredictors] = varindex2;
      interfunc[numpredictors]  = functype2;
      interscales[numpredictors]= scale2;

      cleanpredictors();

      predictor_index  = predindex;
      predictor_func   = predfunc;
      predictor_scales = predscales;
      interaction_index  = interindex;
      interaction_func   = interfunc;
      interaction_scales = interscales;

      numpredictors++;
    }
  
  update_regression_type();
}

void show_regression::removepredictor(void)
{
  int i,listnum=predictorlist.Selected();
  
  if(listnum<0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen prediktor eller respons er markert i "
		     "lista!",
		     (char *) "No predictor or response is marked in the "
		     "list!"));
      return;
    }

  if(listnum==0 && response_set) // response
    response_set=False;
  else // predictor
    {
      if(response_set)
	listnum--;

      if(numpredictors>1)
	{
	  int *predindex = new int[numpredictors-1];
	  REGRESS_FUNC_TYPE *predfunc=new REGRESS_FUNC_TYPE[numpredictors-1];
	  double *predscales = new double[numpredictors-1];
	  int *interindex = new int[numpredictors-1];
	  REGRESS_FUNC_TYPE *interfunc=new REGRESS_FUNC_TYPE[numpredictors-1];
	  double *interscales = new double[numpredictors-1];
	  
	  for(i=0;i<listnum;i++)
	    {
	      predindex[i]    = predictor_index[i];
	      predfunc[i]     = predictor_func[i];
	      predscales[i]   = predictor_scales[i];
	      interindex[i]    = interaction_index[i];
	      interfunc[i]     = interaction_func[i];
	      interscales[i]   = interaction_scales[i];
	    }
	  for(i=listnum+1;i<numpredictors;i++)
	    {
	      predindex[i-1]  = predictor_index[i];
	      predfunc[i-1]   = predictor_func[i];
	      predscales[i-1] = predictor_scales[i];
	      interindex[i-1]  = interaction_index[i];
	      interfunc[i-1]   = interaction_func[i];
	      interscales[i-1] = interaction_scales[i];
	    }
	  
	  cleanpredictors();
	 
	  predictor_index  = predindex;
	  predictor_func   = predfunc;
	  predictor_scales = predscales;
	  interaction_index  = interindex;
	  interaction_func   = interfunc;
	  interaction_scales = interscales;

	  numpredictors--;
	}
      else
	{
	  cleanpredictors();

	  predictor_index  = NULL;
	  predictor_func   = NULL;
	  predictor_scales = NULL;
	  interaction_index  = NULL;
	  interaction_func   = NULL;
	  interaction_scales = NULL;
	  
	  numpredictors = 0;
	}
    }
  
  update_regression_type();
}


void show_regression::changepredictor(void)
{
  int varindex=variablemenu1.GetNumber();
  REGRESS_FUNC_TYPE functype=fchoice.get_function_type();
  double scale=scalef.getdouble();
  int varindex2=variablemenu4.GetNumber()-1;
  REGRESS_FUNC_TYPE functype2=fchoice2.get_function_type();
  double scale2=scalef2.getdouble();
  int listnum=predictorlist.Selected();

  if(listnum<0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen prediktor eller respons er markert i "
		     "lista!",
		     (char *) "No predictor or response is marked in the "
		     "list!"));
      return;
    }

  if(listnum==0 && response_set) // response
    {
      if(varindex2>=0)
	{
	  err.build(mainwin::toplevel, WHAT((char *) "Ikke mulig",
					    (char *) "Not possible"),
		    WHAT((char *) "Interaksjon i responsleddet er ikke "
			 "mulig i denne implementasjonen!",
			 (char *) "Interaction in the response is not "
			 "possible in this implementation!"));
	  return;
	}

      if(pred_or_resp()!=1)
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kan ikke forandre respons til prediktor!",
		     (char *) "Can't change response to predictor!"));
	  return;
	}

      response_func  = functype;
      response_scale = scale;
      response_index = varindex;
      response_set   = True;
    }
  else // predictor
    {
      if(pred_or_resp()!=0)
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kan ikke forandre prediktor til respons!",
		     (char *) "Can't change predictor to response!"));
	  return;
	}

      int index=response_set ? listnum-1 : listnum;

      predictor_index[index]  = varindex;
      predictor_scales[index] = scale;
      predictor_func[index]   = functype;
      interaction_index[index]  = varindex2;
      interaction_scales[index] = scale2;
      interaction_func[index]   = functype2;
    }
  
  update_regression_type();
}

bool show_regression::check_run(void)
{
  if(!response_set)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Respons er ikke satt!",
		     (char *) "Response is not set!"));
      return False;
    }

  if(numpredictors<1 || predictor_index==NULL)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen prediktorer er ikke satt!",
		     (char *) "No predictors are set!"));
      return False;
    }

  return True;
}

void show_regression::start_extra_sum_of_squares(void)
{
  extrasum_predlist.Clear();

  for(int i=0;i<numpredictors;i++)
    {
      char title[100];
      char desc1[100], desc2[100]="",totaldesc[200]; 

      sprintf(title, "%s %i", WHAT((char *) "Prediktor", (char *) "Predictor"),
	      i+1);
      make_func_description(predictor_index[i], alias, predictor_func[i],
			    predictor_scales[i], desc1);
      if(interaction_index && interaction_index[i]>=0)
	{
	  strcpy(desc2, "*");
	  make_func_description(interaction_index[i], alias, 
				interaction_func[i],
				interaction_scales[i], desc2+1);
	}
      sprintf(totaldesc, "%s%s", desc1, desc2); 

      extrasum_predlist.Insert(totaldesc);
    }

  extrasumsh.Map();
}

void show_regression::extra_sum_of_squares(void)
{
  int i,j,k,l;
  int *pos, chosen=extrasum_predlist.Selected(&pos);
  int numpred2=numpredictors-chosen;

  if(chosen<=0)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Du m� velge noen predikotorer � teste!", 
		     (char *) "You must choose some predictors to test!"));
      return;
    }

  if(chosen==numpredictors)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "F-test for alle preiksjonskoeffisienter "
		     "lik 0 er dekket i varians-tabellen!", 
		     (char *) "F test for alle prediction coefficients"
		     " equal to zero i covered in the variance table!"));
      return;
    }

  double *response=new double[len];
  double **predictors=new double*[numpred2];

  l=0;
  for(i=0;i<numpredictors;i++)
    {
      bool ischosen=false;

      for(k=0;k<chosen;k++)
	if(i+1==pos[k])
	  ischosen=true;

      if(!ischosen)
	{
	  predictors[l]=new double[len];
	  
	  for(j=0;j<len;j++)
	    predictors[l][j]=
	      regress_funcvalue(serievalues[predictor_index[i]][j],
				predictor_func[i], 
				predictor_scales[i]);
	  if(interaction_index)
	    for(j=0;j<len;j++)
	      if(interaction_index[i]>=0)
		predictors[l][j] *= 
		  regress_funcvalue(serievalues[interaction_index[i]][j],
				    interaction_func[i], 
				    interaction_scales[i]);

	  l++;
	}
    }

  for(j=0;j<len;j++)
    response[j]=regress_funcvalue(serievalues[response_index][j],
				  response_func, 
				  response_scale);
  
  regression_result *result2 = 
    get_regression(predictors, numpred2, response, len);

  if(!result2)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � foreta ekstra regresjon!",
		     (char *) "Couldn't do extra regression analysis!"));
      return;
    }

  variance_table vtab1=result->get_variance_table();
  variance_table vtab2=result2->get_variance_table();
  double extra_SS=vtab1.SS_reg-vtab2.SS_reg;
  double extra_MS=extra_SS/double(chosen);
  double F=extra_MS/vtab1.MS_res;
  double pF=MISSING_VALUE;

#ifdef GSL
  pF=1.0-gsl_cdf_fdist_P(F, chosen, len-numpredictors);
#endif // GSL

  showresult += "\n\n";
  showresult += WHAT((char *) "Test av ekstra sum av kvadrater:\n", 
		     (char *) "Extra sum of squares test:\n");
  for(i=0;i<numpredictors;i++)
    for(j=0;j<chosen;j++)
      if(i+1==pos[j])
	{
	  char title[100];
	  char desc1[100], desc2[100]="",totaldesc[200]; 
	  
	  sprintf(title, "%s %i", WHAT((char *) "Prediktor", 
				       (char *) "Predictor"), i+1);
	  make_func_description(predictor_index[i], alias, predictor_func[i],
				predictor_scales[i], desc1, title);
	  if(interaction_index && interaction_index[i]>=0)
	    {
	      strcpy(desc2, "*");
	      make_func_description(interaction_index[i], alias, 
				    interaction_func[i],
				    interaction_scales[i], desc2+1);
	    }

	  sprintf(totaldesc, "%s%s", desc1, desc2); 
	  showresult += totaldesc;
	  showresult+="\n";
	}

  char strbuffer[500];

  sprintf(strbuffer, "%-15s %4s %10s %10s %10s %10s\n", 
	  WHAT((char *) "Kilde", (char *) "Source"),
	  "DF", "SS", "MS", "F", "P");
  showresult+=strbuffer;
  sprintf(strbuffer, "%-15s %4d %10.4f %10.4f %10.4f %10.4f\n",
	  WHAT((char *) "Regresjon", (char *) "Regression"),
	  chosen, extra_SS, extra_MS, F, pF);
  showresult+=strbuffer;
  sprintf(strbuffer, "%-15s %4d %10.4f %10.4f\n", "Residual",
	  int(vtab1.df_res), vtab1.SS_res, vtab1.MS_res);
  showresult+=strbuffer;

  extrasumsh.Unmap();

  if(response)
    delete [] response;
  if(predictors)
    {
      for(i=0;i<numpred2;i++)
	if(predictors[i])
	  delete [] predictors[i];
      delete [] predictors;
    }
}

void show_regression::run_regression(void)
{
  if(!check_run())
    return;

  int i,j;
  double *response=new double[len];
  double **predictors=new double*[numpredictors];
  
  for(i=0;i<numpredictors;i++)
    {
      predictors[i]=new double[len];

      for(j=0;j<len;j++)
	predictors[i][j]=regress_funcvalue(serievalues[predictor_index[i]][j],
					   predictor_func[i], 
					   predictor_scales[i]);
      if(interaction_index)
	for(j=0;j<len;j++)
	  if(interaction_index[i]>=0)
	    predictors[i][j] *= regress_funcvalue(
                         serievalues[interaction_index[i]][j],
			 interaction_func[i], 
			 interaction_scales[i]);
    }

  for(j=0;j<len;j++)
    response[j]=regress_funcvalue(serievalues[response_index][j],
				  response_func, 
				  response_scale);

  result = get_regression(predictors, numpredictors, response, len);

  if(!result)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � foreta regresjon!",
		     (char *) "Couldn't do regression analysis!"));
      return;
    }

  if(currentrule)
    delete currentrule;
  currentrule=new regression_rule(result, numseries, 
				  numpredictors, predictor_index, 
				  interaction_index, response_index,
				  predictor_func, interaction_func, 
				  response_func, predictor_scales, 
				  interaction_scales, response_scale);
  
  show_regression_result();

  predictb.Sensitive();
  extrasumstartb.Sensitive();

  if(response)
    delete [] response;
  if(predictors)
    {
      for(i=0;i<numpredictors;i++)
	if(predictors[i])
	  delete [] predictors[i];
      delete [] predictors;
    }
}

void show_regression::predict(void)
{
  double pred=0.0, var=0.0,
    sdev,confsize,lower,upper;
  double tpred,tlower,tupper; // re-transformed values
  double conf=confidencef.getdouble();
  int i,j;
  char strbuffer[500];

  for(i=0;i<numpredictors+1;i++)
    {
      double arg1 = (i==0) ? 1.0 : predictorf[i-1].getdouble();
      
      pred += result->get_coefficient(i)*arg1;

      for(j=0;j<numpredictors+1;j++)
	{
	  double arg2 = (j==0) ? 1.0 :  predictorf[j-1].getdouble();
	  
	  var += arg1*arg2*result->
	    get_square_standard_deviation_coefficients(i,j);
	}
    }

  if(!mean_pred())
    {
      var += result->get_square_standard_deviation();
      //showresult += FORM("s�=%8.4f\n", 
      //		 result->get_square_standard_deviation());
    }

  /*
  for(i=0;i<numpredictors;i++)
    {
      double arg=predictorf[i].getdouble();
      
      pred += result->get_coefficient(i+1)*arg;
      var += result->get_square_standard_deviation_coefficient(i+1)*arg*arg;
    }
  */

  sdev=sqrt(var);
#ifdef GSL
  confsize = sdev * gsl_cdf_tdist_Pinv(0.01*conf/2.0, len-numpredictors-1);
#endif // GSL

  lower=pred-confsize;
  upper=pred+confsize;
  tpred=inverse_regress_funcvalue(pred, response_func, response_scale);
  tlower=inverse_regress_funcvalue(lower, response_func, response_scale);
  tupper=inverse_regress_funcvalue(upper, response_func, response_scale);
  predictionlab.labelString(WHAT((char *) "Respons:  %8.3f+/-%-8.3f %3.1f%%"
				 " konfidensintervall:  %8.3f - %-8.3f",
				 (char *) "Response: %8.3f+/-%-8.3f %3.1f%%"
				 " confidence interval: %8.3f - %-8.3f"),
			    pred,sdev,100.0-conf,upper,lower);
  showresult += "\n";
  showresult += WHAT((char *) "Prediksjon:\n", (char *) "Prediction:");
  for(i=0;i<numpredictors;i++)
    {
      sprintf(strbuffer, "%s: %8.3f\n",predictorf[i].get_current_title(),
		       predictorf[i].getdouble());
      showresult += strbuffer;
    }
 
  sprintf(strbuffer, 
	  WHAT((char *) "Respons:  %8.3f+/-%-8.3f %3.1f%% "
	       "konfidensintervall:  %8.3f - %-8.3f\n", 
	       (char *) "Response: %8.3f+/-%-8.3f %3.1f%% "
	       "confidence interval: %8.3f - %-8.3f\n"), 
	  pred,sdev,100.0-conf,upper,lower);
  showresult += strbuffer;

  if(response_func!=REGRESS_LINEAR || !almost_equal(response_scale,1.0))
    {
      transformedlab.labelString(WHAT((char *) "%s(%s): %8.3f %3.1f%% "
				      "konfidensintervall:  %8.3f - %-8.3f",
				      (char *) "%s(%s): %8.3f %3.1f%% "
				      "confidence interval: %8.3f - %-8.3f"),
				 titles[response_index],
				 alias[response_index],
				 tpred,100.0-conf,tupper,tlower);
      sprintf(strbuffer, 
	      WHAT((char *) "%s(%s): %8.3f %3.1f%% "
		   "konfidensintervall:  %8.3f - %-8.3f",
		   (char *) "%s(%s): %8.3f %3.1f%% "
		   "confidence interval: %8.3f - %-8.3f"),
	      titles[response_index],
	      alias[response_index],
	      tpred,100.0-conf,tupper,tlower);
      showresult += strbuffer;
    }
}


void show_regression::doplot(bool regress_predictor_plot)
{
  int numlines=0;
  REGRESS_PLOT_ALTERNATIVES alt=altmenu.get_plot_alternative();
  int showcurve=0, showcurveconf=0, showmeas=0,
    showpred=0, showpredconf=0, showresidual=0, showresidualconf=0,
    showcooks=0;
  bool doconf=altmenu.show_confidence();
  double conf=altmenu.confidence();

  switch(alt)
    {
    case REGRESS_PLOT_CURVE:
      showcurve=1;
      if(doconf)
	showcurveconf=1;
      break;
    case REGRESS_PLOT_MEAS:
      showmeas=1;
      break;
    case REGRESS_PLOT_CURVE_MEAS:
      showcurve=1;
      showmeas=1;
      if(doconf && numpredictors==1)
	showcurveconf=1;
      break;		
    case REGRESS_PLOT_PRED_MEAS: 
      showmeas=showpred=1;
      if(doconf)
	showpredconf=1;
      break;
    case REGRESS_PLOT_CURVE_PRED_MEAS:
      showcurve=showmeas=showpred=1;
      if(doconf)
	{
	  if(numpredictors==1)
	    showcurveconf=1;
	  else
	    showpredconf=1;
	}
      break;
    case REGRESS_PLOT_RESIDUAL:
      showresidual=1;
      if(doconf)
	showresidualconf=1;
      break;
    case REGRESS_PLOT_COOKS:
      showcooks=1;
      break;
    }

  numlines = (showcurve+showmeas+showpred+showresidual) + 
    2*showcurveconf + showpredconf + showresidualconf + showcooks;
  
  double **arg=new double*[numlines], **val=new double*[numlines];
  int *axis=new int[numlines], *lengths=new int[numlines];
  PLOTLINE_TYPE *type = new PLOTLINE_TYPE[numlines];
  char **linetitles=new char*[numlines], **axistitles=new char*[2];
  int predindex=variablemenu3.GetNumber();
  int aliasindex=variablemenu2.GetNumber();
  char respname[100], predname[200];
  int i,j;

  for(i=0;i<numlines;i++)
    linetitles[i] = new char[300];
  axistitles[0] = new char[100];
  axistitles[1] = new char[100];
  for(i=0;i<numlines;i++)
    axis[i] = 1;

  if(!regress_predictor_plot)
    {
      strcpy(respname, alias[response_index]);
      strcpy(predname, alias[aliasindex]);
    }
  else
    {
      make_func_description(response_index, alias, response_func, 
			    response_scale, respname);
      make_func_description(predictor_index[predindex], alias, 
			    predictor_func[predindex], 
			    predictor_scales[predindex],
			    predname);
      if(interaction_index && interaction_index[predindex]>=0)
	{
	  int plen=strlen(predname);
	  predname[plen]='*';
	  predname[plen+1]='\0';
	  
	  make_func_description(interaction_index[predindex], alias, 
				interaction_func[predindex], 
				interaction_scales[predindex],
				predname+strlen(predname));
	}
    }

  strcpy(axistitles[0], predname);
  strcpy(axistitles[1], respname);
  
  double minarg=MISSING_VALUE, maxarg=MISSING_VALUE,
    minval=MISSING_VALUE,maxval=MISSING_VALUE;
  double *meanpred=new double[numpredictors];  
  int lineindex=0;

  for(j=0;j<numpredictors;j++)
    meanpred[j]=0.0;


  if(showmeas)
    {
      sprintf(linetitles[lineindex], WHAT((char *) "M�linger av %s", 
					  (char *) "Measurements of %s"), 
	      respname);

      lengths[lineindex] = len;
      type[lineindex] = PLOTLINE_DOT;
      arg[lineindex]  = new double[len];
      val[lineindex]  = new double[len];
    }

  for(i=0;i<len;i++)
    {
      double argbuff=serievalues[aliasindex][i];
      double valbuff=serievalues[response_index][i];
      
      for(j=0;j<numpredictors;j++)
	if(interaction_index && interaction_index[j]>=0)
	  meanpred[j]+=regress_funcvalue(serievalues[predictor_index[j]][i],
					 predictor_func[j],
					 predictor_scales[j]) *
	    regress_funcvalue(serievalues[interaction_index[j]][i],
			      interaction_func[j],
			      interaction_scales[j]);
	else
	  meanpred[j]+=regress_funcvalue(serievalues[predictor_index[j]][i],
					 predictor_func[j], 
					 predictor_scales[j]);

      if(regress_predictor_plot)
	{
	  argbuff=serievalues[predictor_index[predindex]][i];
	  argbuff=regress_funcvalue(argbuff, predictor_func[predindex],
				    predictor_scales[predindex]);

	  if(interaction_index && interaction_index[predindex]>=0)
	    {
	      double arg2=serievalues[interaction_index[predindex]][i];
	      argbuff *= regress_funcvalue(arg2, interaction_func[predindex],
					   interaction_scales[predindex]);
	    }

	  valbuff=regress_funcvalue(valbuff, response_func,
				    response_scale);
	}
      
      if(minarg==MISSING_VALUE || minarg>argbuff)
	minarg=argbuff;
      if(maxarg==MISSING_VALUE || maxarg<argbuff)
	maxarg=argbuff;
      if(minval==MISSING_VALUE || minval>valbuff)
	minval=valbuff;
      if(maxval==MISSING_VALUE || maxval<valbuff)
	maxval=valbuff;

      if(showmeas)
	{
	  arg[lineindex][i]=argbuff;
	  val[lineindex][i]=valbuff;
	}
    }

  if(showmeas)
    lineindex++;

  for(j=0;j<numpredictors;j++)
    meanpred[j]/=double(len);

  if(showcurve)
    {    
      sprintf(linetitles[lineindex], 
	      WHAT((char *) "Funksjonssammenheng for %s", 
		   (char *) "%s as a function"), respname);
      if(numpredictors>1)
	strcpy(linetitles[lineindex]+strlen(linetitles[lineindex]), 
	       WHAT((char *) " (gj.verdier for andre pred.)",
		    (char *) " (av.values for other pred."));

      type[lineindex]    = PLOTLINE_LINE;
      lengths[lineindex] = 1000;
      arg[lineindex]     = new double[1000];
      val[lineindex]     = new double[1000];
      
      if(showcurveconf)
	{
	  sprintf(linetitles[lineindex + 1], 
		  WHAT((char *) "Nedre %5.3f %% konfidens for %s", 
		       (char *) "Lower %5.3f %% confidence for %s"), 
		  100.0*conf/2.0, respname);
	  type[lineindex+1]    = PLOTLINE_LINE;
	  lengths[lineindex+1] = 1000;
	  arg[lineindex+1] = new double[1000];
	  val[lineindex+1] = new double[1000];
	  sprintf(linetitles[lineindex + 2], 
		  WHAT((char *) "�vre %5.3f %% konfidens for %s", 
		       (char *) "Upper %5.3f %% confidence for %s"), 
		  100.0*conf/2.0, respname);
	  type[lineindex+2]   = PLOTLINE_LINE;
	  lengths[lineindex+2] = 1000;
	  arg[lineindex+2]=new double[1000];
	  val[lineindex+2]=new double[1000];
	}

      for(i=0;i<1000;i++)
	{
	  double x=minarg+(maxarg-minarg)*double(i)/double(1000-1);
	  double newarg,newval=result->get_coefficient(0);
	  
	  arg[lineindex][i]=x;
	  if(!regress_predictor_plot)
	    x=regress_funcvalue(x, predictor_func[predindex],
				predictor_scales[predindex]); 
	  
	  for(j=0;j<numpredictors;j++)
	    {
	      newarg=(j==predindex ? x : meanpred[j]);
	      
	      newval += result->get_coefficient(j+1)*newarg;
	    }
	  
	  if(!regress_predictor_plot)
	    val[lineindex][i]=inverse_regress_funcvalue(newval, response_func,
							response_scale);
	  else
	    val[lineindex][i]=newval;

	  if(showcurveconf)
	    {
	      double var=0.0;

	      for(j=-1;j<numpredictors;j++)
		for(int k=-1;k<numpredictors;k++)
		  {
		    double arg1=(j==-1 ? 1 : (j==predindex ? x : meanpred[j]));
		    double arg2=(k==-1 ? 1 : (k==predindex ? x : meanpred[k]));

		    var += arg1*arg2*result->
		      get_square_standard_deviation_coefficients(j+1,k+1);
		  }

	      arg[lineindex+1][i]=arg[lineindex+2][i]=arg[lineindex][i];
	     
#ifdef GSL

	      val[lineindex+1][i]=newval+sqrt(var)*
		gsl_cdf_tdist_Pinv(conf / 2.0, len - numpredictors - 1);
	      val[lineindex+2][i]=newval-sqrt(var)*
		gsl_cdf_tdist_Pinv(conf/2.0, len- numpredictors-1);

#endif // GSL

	      if(!regress_predictor_plot)
		{
		  val[lineindex+1][i]=
		    inverse_regress_funcvalue(val[lineindex+1][i], 
					      response_func, response_scale);
		  val[lineindex+2][i]=
		    inverse_regress_funcvalue(val[lineindex+2][i], 
					      response_func, response_scale);
		}
	    }
	}
      
      lineindex++;
      if(showcurveconf)
	lineindex+=2;
    }

  bool mean_prediction = mean_pred();
  if(showpred)
    {
      sprintf(linetitles[lineindex], 
	      WHAT((char *) "Prediksjon av %s for m�lepunktene", 
		   (char *) "Predictions of %s for the measurement points"), 
	      respname);
      lengths[lineindex] = len;
      type[lineindex]    = PLOTLINE_DOT;
      arg[lineindex]     = new double[len];
      val[lineindex]     = new double[len];
      
      if(showpredconf)
	{
	  sprintf(linetitles[lineindex+1], 
		  WHAT((char *) "%5.3f %% konfidens for %s", 
		       (char *) "%5.3f %% confidence for %s"), 
		  100.0*(1.0-conf), respname);
	  type[lineindex+1]   = PLOTLINE_LINE;
	  lengths[lineindex+1] = 3*len;
	  arg[lineindex+1] = new double[3*len];
	  val[lineindex+1] = new double[3*len];
	}

      for(i=0;i<len;i++)
	{
	  int currindex = regress_predictor_plot ? 
	    predictor_index[predindex] : aliasindex;
	  double argbuff = serievalues[currindex][i];
	  int predindex2=0;
	  double *predictors=new double[numseries];

	  for(j=0;j<numseries;j++)
	    predictors[j]=serievalues[j][i];

	  for(j=0;j<numpredictors;j++)
	    if(predictor_index[j]==currindex)
	      predindex2 = j;
	      
	  if(regress_predictor_plot)
	    {
	      arg[lineindex][i]=
		regress_funcvalue(argbuff, predictor_func[predindex2],
				  predictor_scales[predindex2]);

	      if(interaction_index && interaction_index[predindex]>=0)
		{
		  double arg2=serievalues[interaction_index[predindex]][i];
		  arg[lineindex][i] *= 
		    regress_funcvalue(arg2, interaction_func[predindex],
				      interaction_scales[predindex]);
		}

	      val[lineindex][i]=currentrule->find_response(predictors);
	    }
	  else
	    {
	      arg[lineindex][i]=argbuff;
	      val[lineindex][i]=currentrule->find_response_value(predictors);
	    }
	  delete [] predictors;

	  if(showpredconf)
	    {
	      double var=0.0;
	      
	      for(j=-1;j<numpredictors;j++)
		for(int k=-1;k<numpredictors;k++)
		  {
		    double arg1=(j==-1) ? 1 :
		      regress_funcvalue(serievalues[predictor_index[j]][i], 
					predictor_func[j],
					predictor_scales[j]);
		    if(j>=0 && interaction_index && interaction_index[j]>=0)
		      arg1 *=
			regress_funcvalue(serievalues[interaction_index[j]][i],
					  interaction_func[j],
					  interaction_scales[j]);
		    
		    double arg2=(k==-1) ? 1 :
		      regress_funcvalue(serievalues[predictor_index[k]][i], 
					predictor_func[k],
					predictor_scales[k]);
		    if(k>=0 && interaction_index && interaction_index[k]>=0)
		      arg2 *=
			regress_funcvalue(serievalues[interaction_index[k]][i],
					  interaction_func[k],
					  interaction_scales[k]);
		    
		    var += arg1*arg2*
		      result->get_square_standard_deviation_coefficients(j+1,
									 k+1);
		  }

	      if(!mean_prediction)
		var += result->get_square_standard_deviation();
	      //cout << i << " " << var << " " << sqrt(var) << endl;

	      arg[lineindex+1][3*i]=arg[lineindex][i];
	      arg[lineindex+1][3*i+1]=arg[lineindex][i]-
		ABSVAL((arg[lineindex][i]))*0.000000001;
	      arg[lineindex+1][3*i+2]=arg[lineindex][i]+
		ABSVAL((arg[lineindex][i]))*0.000000001;

#ifdef GSL
	      val[lineindex+1][3*i] = val[lineindex][i] + sqrt(var)*
		gsl_cdf_tdist_Pinv(conf/2.0, len-numpredictors-1);
	      val[lineindex+1][3*i+1] = val[lineindex][i] - sqrt(var)*
		gsl_cdf_tdist_Pinv(conf/2.0, len-numpredictors-1);

#endif // GSL
	      
	      if(!regress_predictor_plot)
		{
		  val[lineindex+1][3*i] = 
		    inverse_regress_funcvalue(val[lineindex+1][3*i],
					      response_func,
					      response_scale);
		  val[lineindex+1][3*i+1] = 
		    inverse_regress_funcvalue(val[lineindex+1][3*i+1],
					      response_func,
					      response_scale);
		}
	      
	      val[lineindex+1][3*i+2] = MISSING_VALUE;
	    }
	}
      
      lineindex++;
      if(showpredconf)
	lineindex++;
    }
  
  if(showresidual)
    {
      strcpy(linetitles[lineindex], 
	      WHAT((char *) "Residualer", 
		   (char *) "Residuals"));
      lengths[lineindex]=len;
      type[lineindex]=PLOTLINE_DOT;
      arg[lineindex]=new double[len];
      val[lineindex]=new double[len];
      
      if(showresidualconf)
	{
	  sprintf(linetitles[lineindex+1], 
		  WHAT((char *) "%5.3f %% konfidens for residualer", 
		       (char *) "%5.3f %% confidence for residuals"), 
		  100.0*(1.0-conf));
	  type[lineindex+1]   = PLOTLINE_LINE;
	  lengths[lineindex+1] = 3*len;
	  arg[lineindex+1]=new double[3*len];
	  val[lineindex+1]=new double[3*len];
	}
      
      for(i=0;i<len;i++)
	{
	  int currindex = regress_predictor_plot ? 
	    predictor_index[predindex] : aliasindex;
	  double argbuff = serievalues[currindex][i];
	  double valbuff = result->get_coefficient(0);
	  double val2buff = serievalues[response_index][i];
	  int predindex2=0;
	  
	  for(j=0;j<numpredictors;j++)
	    if(predictor_index[j]==currindex)
	      predindex2=j;

	  for(j=0;j<numpredictors;j++)
	    {
	      if(interaction_index && interaction_index[j]>=0)
		valbuff += result->get_coefficient(j+1)*
		  regress_funcvalue(serievalues[predictor_index[j]][i],
				    predictor_func[j], predictor_scales[j]) *
		  regress_funcvalue(serievalues[interaction_index[j]][i],
				    interaction_func[j], 
				    interaction_scales[j]);
	      else
		valbuff += result->get_coefficient(j+1)*
		  regress_funcvalue(serievalues[predictor_index[j]][i],
				    predictor_func[j], predictor_scales[j]);
	    }

	  if(regress_predictor_plot)
	    {
	      arg[lineindex][i]=
		regress_funcvalue(argbuff, predictor_func[predindex2],
				  predictor_scales[predindex2]);
	      if(interaction_index && interaction_index[predindex]>=0)
		{
		  double arg2=serievalues[interaction_index[predindex]][i];
		  arg[lineindex][i] *=
		    regress_funcvalue(arg2, interaction_func[predindex],
				      interaction_scales[predindex]);
		}

	      val[lineindex][i]=-valbuff+regress_funcvalue(val2buff,
							   response_func,
							   response_scale);
	    }
	  else
	    {
	      arg[lineindex][i]=argbuff;
	      val[lineindex][i]=-inverse_regress_funcvalue(valbuff, 
							   response_func,
							   response_scale)+
		val2buff;
	    }
	  
	  if(showresidualconf)
	    {
	      double var=result->get_square_standard_deviation_coefficient(0);

	      arg[lineindex+1][3*i]=arg[lineindex][i];
	      arg[lineindex+1][3*i+1]=arg[lineindex][i]+
		ABSVAL(arg[lineindex][i])*1.0e-9;
	      arg[lineindex+1][3*i+2]=arg[lineindex][i]+
		ABSVAL(arg[lineindex][i])*2.0e-9;
	      
	      for(j=0;j<numpredictors;j++)
		{
		  double arg1=
		    regress_funcvalue(serievalues[predictor_index[j]][i],
				      predictor_func[j], predictor_scales[j]);
		  double arg2=(interaction_index && interaction_index[j]>=0) ?
		    regress_funcvalue(serievalues[interaction_index[j]][i],
				      interaction_func[j], 
				      interaction_scales[j])
		    : 1.0;

		  var += arg1*arg1*arg2*arg2*
		    result->get_square_standard_deviation_coefficient(j+1);
		}
	      
#ifdef GSL
	      val[lineindex+1][3*i] = sqrt(var)*
		gsl_cdf_tdist_Pinv(conf/2.0, len-numpredictors-1);
	      val[lineindex+1][3*i+1] = - sqrt(var)*
		gsl_cdf_tdist_Pinv(conf/2.0, len-numpredictors-1);
	      val[lineindex+1][3*i+2] = MISSING_VALUE;
#endif // GSL

	      if(!regress_predictor_plot)
		{
		  val[lineindex+1][3*i] = 
		    inverse_regress_funcvalue(val[lineindex+1][3*i],
					      response_func,
					      response_scale);
		  val[lineindex+1][3*i+1] = 
		    inverse_regress_funcvalue(val[lineindex+1][3*i+1],
					      response_func,
					      response_scale);
		}
	    }
	}

      lineindex++;
      if(showpredconf)
	lineindex++;
    }

  if(showcooks)
    {
      strcpy(linetitles[lineindex], 
	     WHAT((char *) "Cooks distanse", 
		  (char *) "Cook's distance"));
      lengths[lineindex]=len;
      type[lineindex]=PLOTLINE_DOT;
      arg[lineindex]=new double[len];
      val[lineindex]=new double[len];
      
      for(i=0;i<len;i++)
	{
	  int currindex   = regress_predictor_plot ? 
	    predictor_index[predindex] : aliasindex;
	  double argbuff  = serievalues[currindex][i];
	  double valbuff  = result->get_coefficient(0);
	  int predindex2  = 0;
	  
	  for(j=0;j<numpredictors;j++)
	    if(predictor_index[j]==currindex)
	      predindex2  = j;

	  valbuff=result->get_cooks_distance(i);

	  if(regress_predictor_plot)
	    {
	      arg[lineindex][i] =
		regress_funcvalue(argbuff, predictor_func[predindex2],
				  predictor_scales[predindex2]);
	      if(interaction_index && interaction_index[predindex]>=0)
		{
		  double arg2 = serievalues[interaction_index[predindex]][i];
		  arg[lineindex][i] *=
		    regress_funcvalue(arg2, interaction_func[predindex],
				      interaction_scales[predindex]);
		}
	    }
	  else
	    arg[lineindex][i] = argbuff;
	  val[lineindex][i] = valbuff;
	}
      
      lineindex++;
    }


  if(plot)
    delete plot;
  plot = new plot_module();
  
  plot->Create(arg,val, lengths, axis, linetitles,numlines,
	       axistitles,2,NULL,type);

  delete [] axistitles[0];
  delete [] axistitles[1];
  for(i=0;i<numlines;i++)
    {
      delete [] arg[i];
      delete [] val[i];
      delete [] linetitles[i];
    }
  delete [] axistitles;
  delete [] linetitles;
  delete [] arg;
  delete [] val;
}

void show_regression::close(void)
{
  Unmap();
  if(currentrule)
    regression_done(currentrule);
}

void show_regression::fetch_pow(bool is_primary)
{
  powsh.build(*this, WHAT((char *) "Innhenting av 'opph�yd i'-faktor", 
			  (char *) "Specification of power factor"));
  powv1.build(powsh);
  powfield.build(powv1, 12, WHAT((char *) "Opph�yd i:", 
				 (char *) "Power faktor"));
  powfield.SetDouble(1.0);
  powcloseb.build(powv1, "OK");
  powsh.Map();
  powcloseb.Wait();
  powsh.Unmap();
  
  if(is_primary)
    {
      scalef.SetDouble(powfield.getdouble());
      scalef.EditAble(True);
    }
  else
    {
      scalef2.SetDouble(powfield.getdouble());
      scalef2.EditAble(True);
    }
}

void show_regression::fetch_trigonometric(bool is_primary)
{
  trigsh.build(*this, WHAT((char *) "Innhenting av trigonometrisk "
			   "skalafaktor", 
			   (char *) "Specification of trigonometric scale"
			   " factor"));
  trigv1.build(trigsh);
  trigfield.build(trigv1, 12, WHAT((char *) "Skalafaktor:", 
				 (char *) "Scale factor"));
  trigfield.SetDouble(2.0*M_PI);
  trigcloseb.build(trigv1, "OK");
  trigsh.Map();
  trigcloseb.Wait();
  trigsh.Unmap();
  
  if(is_primary)
    {
      scalef.SetDouble(trigfield.getdouble());
      scalef.EditAble(True);
    }
  else
    {
      scalef2.SetDouble(trigfield.getdouble());
      scalef2.EditAble(True);
    }
}
    


void show_regression::show_current_regression_type(void)
{
  char total[1000];
  int i;

  if(response_set)
    make_func_description(response_index, alias, response_func,
			  response_scale, total);
  else
    strcpy(total, "???");
  strcpy(total+strlen(total), " = C0 + ");
  
  if(numpredictors==0)
    strcpy(total+strlen(total), "???");
  else
    {
      char **pred=new char*[numpredictors];
      for(i=0;i<numpredictors;i++)
	{
	  pred[i]=new char[100];
	  make_func_description(predictor_index[i], alias, predictor_func[i],
				predictor_scales[i], pred[i]);
	  if(interaction_index && interaction_index[i]>=0)
	    {
	      strcpy(pred[i]+strlen(pred[i]), "*");
	      make_func_description(interaction_index[i], alias, 
				    interaction_func[i],
				    interaction_scales[i], 
				    pred[i]+strlen(pred[i]));
	    }
	  sprintf(total+strlen(total), "%s C%d * %s", i==0 ? "" : " + ", 
		  i+1, pred[i]);
	}
      variablemenu3.Insert(pred,numpredictors);

      for(i=0;i<numpredictors;i++)
	delete [] pred[i];
      delete [] pred;
    }

  resultlab.labelString(total);
}

void show_regression::show_regression_result(void)
{
  char total[1000], str[100], strbuffer[500];
  int i;

  if(response_set)
    make_func_description(response_index, alias, response_func,
			  response_scale, total);
  else
    strcpy(total, "???");
  strcpy(total+strlen(total), " = ");
  
  if(numpredictors==0)
    strcpy(total+strlen(total), "???");
  else
    {
      showresult.Clear();

      sprintf(total+strlen(total), "%8.5f", result->get_coefficient(0));

      for(i=0;i<numpredictors;i++)
	{
	  char pred[100];
	  make_func_description(predictor_index[i], alias, predictor_func[i],
				predictor_scales[i], pred);
	  if(interaction_index && interaction_index[i]>=0)
	    {
	      strcpy(pred+strlen(pred), "*");
	      make_func_description(interaction_index[i], alias, 
				    interaction_func[i],
				    interaction_scales[i], pred+strlen(pred));
	    }
	  sprintf(total+strlen(total), " + %8.5f * %s",  
		  result->get_coefficient(i+1), pred);
	}
      
      showresult += total;
      showresult += "\n\n";
      sprintf(str, WHAT((char *) "Konstant: %8.5f +/- %8.5f  "
			"T=%8.5g p-verdi for konstant=0: %8.5g %%\n", 
			(char *) "Constant:  %8.5f +/- %8.5f  "
			"T=%8.5g p-value for constant=0: %8.5g %%\n"),
	      result->get_coefficient(0), 
	      sqrt(result->get_square_standard_deviation_coefficient(0)),
	      result->get_t_observator(0),
	      100.0*result->get_pvalue(0));
      showresult+=str;

      for(i=0;i<numpredictors;i++)
	{
	  sprintf(str, WHAT((char *) "Prediktor nr. %d: %8.5f +/- %8.5f  "
			    "T=%8.5g p-verdi for koeffisient=0: %8.5g %%\n", 
			    (char *) "Predictor %d:  %8.5f +/- %8.5f  "
			    "T=%8.5g p-value for coefficient=0: %8.5g %%\n"),
		  i+1, result->get_coefficient(i+1), 
		  sqrt(result->get_square_standard_deviation_coefficient(i+1)),
		  result->get_t_observator(i+1),
		  100.0*result->get_pvalue(i+1));
	  showresult+=str;
	}

      variance_table vtab=result->get_variance_table();
      if(vtab.SS_tot!=MISSING_VALUE)
	{
	  showresult+="\n\n";
	  showresult+=WHAT((char *) "Varians-tabell\n", 
			   (char *) "Table of variance\n");
	  sprintf(strbuffer, "%-15s %4s %10s %10s %10s %10s\n", 
		  WHAT((char *) "Kilde", (char *) "Source"),
		  "DF", "SS", "MS", "F", "P");
	  showresult+=strbuffer;
	  sprintf(strbuffer, "%-15s %4d %10.4f %10.4f %10.4f %10.4f\n",
		  WHAT((char *) "Regresjon", (char *) "Regression"),
		  int(vtab.df_reg), vtab.SS_reg, vtab.MS_reg, vtab.F,
		  vtab.p_F);
	  showresult+=strbuffer;
	  sprintf(strbuffer, "%-15s %4d %10.4f %10.4f\n", "Residual",
		  int(vtab.df_res), vtab.SS_res, vtab.MS_res);
	  showresult+=strbuffer;
	  sprintf(strbuffer, "%-15s %4d %10.4f\n", "Total",
		  int(vtab.df_tot), vtab.SS_tot); 
	  showresult+=strbuffer;
	}
    }

  bool *used=new bool[numseries]; 
  for(i=0;i<numseries;i++)
    used[i]=False;

  used[response_index]=True;
  showresult += "\n";
  showresult += alias[response_index];
  showresult += " = \"";
  showresult += titles[response_index];
  showresult += "\"\n";

  for(i=0;i<numpredictors;i++)
    {
      if(!used[predictor_index[i]])
	{
	  showresult += alias[predictor_index[i]];
	  showresult += " = \"";
	  showresult += titles[predictor_index[i]];
	  showresult += "\"\n";
	  used[predictor_index[i]]=True;
	}
      else if(interaction_index && interaction_index[i]>=0 && 
	      !used[interaction_index[i]])
	{
	  showresult += alias[interaction_index[i]];
	  showresult += " = \"";
	  showresult += titles[interaction_index[i]];
	  showresult += "\"\n";
	  used[interaction_index[i]]=True;
	}
    }

  
  show_goodness_of_fit();
  show_residual_trend();
  show_residual_normality();

  showresult += "\n";
  showresult += WHAT((char *) "Kovarians-matrise elementer\n", 
		     (char *) "Covariance matrix elements;\n");
  sprintf(strbuffer, "%3s %7s | %10s %16s\n", 
	  WHAT((char *) "Rad", (char *) "Row"), 
	  WHAT((char *) "Kolonne", (char *) "Column"), 
	  WHAT((char *) "Kovarianse", (char *) "Covariance"), 
	  WHAT((char *) "Est. korrelasjon", 
	       (char *) "Est. correlation")); 
  showresult+=strbuffer;

  for(i=0;i<numpredictors+1;i++)
    for(int j=0;j<=i;j++)
      if(i==j)
	{
	  sprintf(strbuffer, "%3d %7d : %10.3g\n", i, j, 
		  result->get_square_standard_deviation_coefficients(i,j));
	  showresult+=strbuffer;
	}
      else
	{
	  sprintf(strbuffer, "%3d %7d : %10.3g             %5.3f\n", i, j,
                result->get_square_standard_deviation_coefficients(i,j),
                result->get_square_standard_deviation_coefficients(i,j)/
                sqrt(result->get_square_standard_deviation_coefficients(i,i))/
                sqrt(result->get_square_standard_deviation_coefficients(j,j)));
	  showresult+=strbuffer;
	}
}

void show_regression::show_goodness_of_fit(void)
{
  double *residual=fetch_residuals();
  int i;
  double var=0.0, mean=0.0, rss=0.0, *meas=new double[len], goodness;
  char str[1000];

  for(i=0;i<len;i++)
    meas[i]=regress_funcvalue(serievalues[response_index][i],
			      response_func, response_scale);

  for(i=0;i<len;i++)
    mean+=meas[i];
  mean/=double(len);

  for(i=0;i<len;i++)
    {
      var += (meas[i]-mean)*(meas[i]-mean);
      rss += residual[i]*residual[i];
    }
  
  goodness = 1.0 - rss/var;

  delete [] residual;
  delete [] meas;

  showresult+="\n";
  sprintf(str,  "Goodness-of-fit: %8.3g %%", goodness*100.0);
  showresult+=str;
  showresult+="\n";
}

double *show_regression::fetch_residuals(void)
{
  if(len==0)
    return NULL;

  int i,j;
  double *residual=new double[len];
  
  for(i=0;i<len;i++)
    {
      double meas = regress_funcvalue(serievalues[response_index][i],
				      response_func, response_scale);
      double pred = result->get_coefficient(0);
	  
      for(j=0;j<numpredictors;j++)
	if(interaction_index && interaction_index[j]>=0)
	  pred += result->get_coefficient(j+1)*
	    regress_funcvalue(serievalues[predictor_index[j]][i],
			      predictor_func[j], predictor_scales[j])*
	    regress_funcvalue(serievalues[interaction_index[j]][i],
			      interaction_func[j], interaction_scales[j]);
	else
	  pred += result->get_coefficient(j+1)*
	    regress_funcvalue(serievalues[predictor_index[j]][i],
			      predictor_func[j], predictor_scales[j]);
      
      residual[i]=meas-pred;
    }

  return residual;
}

// fetches values as x-coordinate and residuals as y-coordinates;
double_2d *show_regression::fetch_values_and_residuals(void)
{
  double *residual=fetch_residuals();
  double_2d *result=new double_2d[len];

  for(int i=0;i<len;i++)
    {
      result[i].x=regress_funcvalue(serievalues[response_index][i],
				    response_func, response_scale);
      result[i].y=residual[i];
    }

  delete [] residual;

  return result;
}

void show_regression::show_residual_trend(void)
{
  double_2d *residuals=fetch_values_and_residuals();
  double corr=0.0, var=0.0,mean=0.0;
  int i;

  //qsort(residuals, size_t(len), sizeof(double_2d), compare_double_2d_x);
  
  for(i=0;i<len;i++)
    mean += residuals[i].y;
  mean/=double(len);

  for(i=0;i<len;i++)
    {
      var += (residuals[i].y-mean)*(residuals[i].y-mean);
      if(i==0)
	corr+=(residuals[0].y-mean)*(residuals[len-1].y-mean);
      else
	corr+=(residuals[i].y-mean)*(residuals[i-1].y-mean);
    }
  corr/=var;

  // conf.interval for correlation=(1+/-Z(p/2)*sqrt(size-2))/(size-1);
  double corr_z=-ABSVAL((1.0+(double(len)-1.0)*corr)/sqrt(double(len)-2.0));
  double corr_p=MISSING_VALUE;

#ifdef GSL
  corr_p=corr_z>-37 ? 2.0*gsl_cdf_ugaussian_P(corr_z) : 0.0;
#endif // GSL

  char str[1000];

  showresult+="\n";
  showresult += WHAT((char *) "Trend-analyse:\n", (char *) "Trend analysis:");
  sprintf(str, WHAT((char *) "Residualenes autokorrelasjon: %6.3f   "
		    "p-verdi for at det ikke er noen trend: %8.3g %%",
		    (char *) "Auto correlation of residuals: %6.3f   "
		    "p-value for residuals having no trend: %8.3g %%"),
	  corr, corr_p*100.0);
  showresult+=str;
  showresult+="\n";

  delete [] residuals;
}

void show_regression::show_residual_normality(void)
{
  double *residuals=fetch_residuals();
  double skew=find_statistics(residuals, len, SKEW);
  double curtosis=find_statistics(residuals, len, CURTOSIS);

  // experimentally found expressions for standard deviations as a function of
  // the sample size;
  double sdev_skew=sqrt(5.42*pow(len+1.92, -0.979));
  double sdev_curt=sqrt(41.73*pow(len+22.0, -1.095));

  double test_skew=-ABSVAL(skew/sdev_skew);
  double test_curt=-ABSVAL((curtosis-3.0)/sdev_curt);

  double p_skew=MISSING_VALUE; 
  double p_curt=MISSING_VALUE; 

#ifdef GSL
  p_skew=test_skew>-37.0 ? gsl_cdf_ugaussian_P(test_skew) : 0.0;
  p_curt=test_curt>-37.0 ? gsl_cdf_ugaussian_P(test_curt) : 0.0;
#endif // GSL 

  char str[1000];

  showresult+="\n";
  showresult += WHAT((char *) "Normalitets-analyse:\n", 
		     (char *) "Normality analysis:");
  sprintf(str, WHAT((char *) "Residualenes skjevhet: %6.3f   "
		    "p-verdi for normalitet: %8.3g %%",
		    (char *) "Skew of the residuals: %6.3f   "
		    "p-value for normality: %8.3g %%"),
	  skew, p_skew*100.0);
  showresult+=str;
  showresult+="\n";
  sprintf(str, WHAT((char *) "Residualenes kurtose: %6.3f   "
		    "p-verdi for normalitet: %8.3g %%",
		    (char *) "Curtosis of the residuals: %6.3f   "
		    "p-value for normality: %8.3g %%"),
	  curtosis, p_curt*100.0);
  showresult+=str;
  showresult+="\n";

  delete [] residuals;
}

void show_regression::cleanup(void)
{
  int i=0;

  len=0;

  if(serievalues)
    {
      for(i=0;i<numseries;i++)
	if(serievalues[i])
	  delete [] serievalues[i];
      delete [] serievalues;
    }
  serievalues=NULL;

  if(titles)
    {
      for(i=0;i<numseries;i++)
	if(titles[i])
	  delete [] titles[i];
      delete [] titles;
    }
  titles=NULL;
  
  if(alias)
    {
      for(i=0;i<numseries;i++)
	if(alias[i])
	  delete [] alias[i];
      delete [] alias;
    }
  alias=NULL;
  
  if(aliaslab)
    delete [] aliaslab;
  aliaslab=NULL;

  if(result)
    delete result;
  result=NULL;

  cleanpredictors();
  numpredictors=0;

  if(plot)
    delete plot;
  plot=NULL;

  if(currentrule)
    delete currentrule;
  currentrule=NULL;
}


void show_regression::make_window(void)
{
  int i;
  char *pred_resp[]={WHAT((char *) "Prediktor", (char *) "Predictor"),
		     WHAT((char *) "Respons", (char *) "Response")};

  build(mainwin::toplevel, WHAT((char *) "Regresjons-analyse", 
				(char *) "Regression analysis"));
  v1.build(*this);
  
  h1.build(v1);
  pred_or_resp.vbuild(h1, pred_resp, 2, 1);
  v10.build(h1);
  h10.build(v10);
  variablemenu1.Create(h10, WHAT((char *) "Variabel:", (char *) "Variable:"));
  variablemenu1.Insert(alias, numseries, 0);
  fchoice.create(h10, this, True);
  v5.build(h10);
  scalef.build(v5, 10, WHAT((char *) "Skalering:", (char *) "Scaling:"));
  scalef.SetDouble(0.0);
  scalef.EditAble(True);

  //  interaction widgets;
  h11.build(v10);
  variablemenu4.Create(h11, WHAT((char *) "Interaksjons-variabel:",
				(char *) "interaction variable:"));
  char **itembuf=new char*[numseries+1];
  for(i=0;i<numseries+1;i++)
    itembuf[i]=new char[100];
  strcpy(itembuf[0], WHAT((char *) "Ingen", (char *) "None"));
  for(i=0;i<numseries;i++)
    strcpy(itembuf[i+1], alias[i]);
  variablemenu4.Insert(itembuf, numseries+1, 0);
  for(i=0;i<numseries+1;i++)
    delete [] itembuf[i];
  delete [] itembuf;
  fchoice2.create(h11, this, False);
  v9.build(h11);
  scalef2.build(v9, 10, WHAT((char *) "Skalering:", (char *) "Scaling:"));
  scalef2.SetDouble(1.0);
  scalef2.EditAble(True);

  v4.build(h1);
  addb.create(v4, WHAT((char *) "Legg til prediktor/respons", 
		       (char *) "Add predictor or response"),
	      this, REGRESS_ADD);
  
  h2.build(v1);
  predictorlist.Create(h2, this);


  v3.build(h2);
  changepredb.create(v3, WHAT((char *) "Forandre liste-element",
			      (char *) "Change list element"), this,
		     REGRESS_CHANGE_PREDICTOR);
  removepredb.create(v3, WHAT((char *) "Fjerne liste-element",
			      (char *) "Remove list element"), this,
		     REGRESS_REMOVE_PREDICTOR);

  v8.build(h2);
  sc.build(v8);
  sc.Height(80);
  sc.Width(450);
  v2.build(sc);
  aliaslab=new label[numseries];
  for(i=0;i<numseries;i++)
    aliaslab[i].build(v2, "%s=%s",alias[i],titles[i]);
  changedescb.create(v8, WHAT((char *) "Forandre beskrivelser", 
			      (char *) "Change descriptions"), this,
		     REGRESS_CHANGE_DESCRIPTIONS);
		     




  resultlab.build(v1, "? = ?");
  h3.build(v1);
  runb.create(h3, WHAT((char *) "Kj�r regresjonsanalyse",
		       (char *) "Run regression analysis"), this,
	      REGRESS_RUN);
  runb.Background("green");
  runb.Foreground("black");
  extrasumstartb.create(h3, WHAT((char *) "Ekstra kvadratsum-test", 
				 (char *) "Extra sum of squares test"), 
			this, REGRESS_EXTRA_SUM_START);
  extrasumstartb.InSensitive();

  extrasumsh.build(mainwin::toplevel, 
		   WHAT((char *) "Ekstra sum av kvadrater", 
			(char *) "Extra sum of squares"));
  extrasumv1.build(extrasumsh);
  extrasumlab.build(extrasumv1,
		    WHAT((char *) "Velg prediktorleddledd som skal teste"
			 "s:     ", 
			 (char *) "Choose prediction terms that will be "
			 "tested:"));
  extrasum_predlist.build(extrasumv1, 10);
  extrasumh1.build(extrasumv1);
  extrasumb.create(extrasumh1, "OK", this, REGRESS_EXTRA_SUM);
  extrasumb.Background("green");
  extrasumb.Foreground("black");
  extrasumcancelb.build(extrasumh1, &extrasumsh, 
			WHAT((char *) "Avbryt", (char *) "Cancel"));
  extrasumcancelb.Background("red");
  extrasumcancelb.Foreground("white");

  h8.build(v1);
  showresult.build(h8, 100, 10);
  
  v11.build(h8);
  predictorsc.build(v11);
  predictorsc.Height(100);
  predictorsc.Width(200);
  predictorv1.build(predictorsc);
  predictorf=NULL;
  predictorh=NULL;
  predictorh1.build(v11);
  confidencef.build(predictorh1, 5, WHAT((char *) "Konfidens (%): 100.0-",
					  (char *) "Confidence (%): 100.0-"));
  confidencef.SetDigit(5);
  predictb.create(predictorh1, WHAT((char *) "Kj�r prediksjon",
				    (char *) "Run prediction"), 
		  this, REGRESS_PREDICT);
  predictb.InSensitive();
  predictionlab.build(v11, "                                              ");
  predictionlab.Background("white");
  predictionlab.Foreground("black");
  transformedlab.build(v11,"");
  mean_pred.build(v11, WHAT((char *) "Konfidensgrense til forventet "
			    "prediksjon?", 
			    (char *) "Confidence limits for mean "
			    "predictions?")); 

  h7.build(v1);
  altmenu.create(h7);
  v7.build(h7);
    
  h4.build(v7);
  plotlab.build(h4, WHAT((char *) "Plotting av respons/residual-variabel mot ",
			 (char *) "Plot response/residual variable against "));
  variablemenu2.Create(h4, WHAT((char *) "variabel:", (char *) "variable:"));
  variablemenu2.Insert(alias, numseries, 0);
  plotvarb.create(h4, WHAT((char *) "Plott", (char *) "Plot"), this,
		  REGRESS_PLOT_VARIABLE);

  h5.build(v7);
  plotlab.build(h5, WHAT((char *) "Plotting av respons/residual mot ",
			 (char *) "Plot response/residual against "));
  variablemenu3.Create(h5, WHAT((char *) "prediktor:", (char *) "predictor:"));
  //variablemenu3.Inserts(alias, numseries, 0);
  plotpredb.create(h5, WHAT((char *) "Plott", (char *) "Plot"), this,
		   REGRESS_PLOT_PREDICTOR);
  
  sep1.build(v1);
  
  h6.build(v1);
  closeb.create(h6, WHAT((char *) "Lukk vindu", (char *) "Close window"),
		this, REGRESS_CLOSE);
  closeb.Background("red");
  closeb.Foreground("white");

  spacelab.build(h6, "       ");
  savefileb.create(h6, WHAT((char *) "Lagre resultattekst p� fil", 
			    (char *) "Save result texct on file"), this,
		   REGRESS_SAVEFILE);
  savefileb.Background("yellow");
  savefileb.Foreground("black");
  printb.create(h6, WHAT((char *) "Skriv ut", (char *) "Print"), this,
		REGRESS_PRINT);
  printb.Background("blue");
  printb.Foreground("white");
  printerlab.build(h6, WHAT((char *) "Skriver: %s", (char *) "Printer: %s"),
		 getenv("PRINTER"));
  changeprinterb.create(h6, WHAT((char *) "Forandre skriver", 
				 (char *) "Change printer"), this,
			REGRESS_CHANGEPRINTER);

  Map();
}


void show_regression::startchangeprinter(void)
{
  prsh.create(this);
}

void show_regression::start_savefile(void)
{
  fsel.Create(this);
}

void show_regression::doprint(void)
{
  FILE *p=popen("lpr", "w");
  if(!p)
    {
      err.build(*this, WHAT((char *) "Eksekveringsfeil", 
			    (char *) "Execution error"),
		WHAT((char *) "Klarte ikke � �pne pipe til lpr",
		     (char *) "Couldn't open pipe to lpr"));
      return;
    }
    
  fprintf(p, "%s\n", showresult.GetText());

  fprintf(p, "%s", showresult.GetText());
  pclose(p);
}

void show_regression::savefile_chosen(const char *filename)
{
    std::ofstream out;

    out.open(filename, std::ios::out);
  if(out.fail())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � �pne filen for skriving!", 
		     (char *) "Couldn't open the file for writing!"));
      return;
    }
  
  out << showresult.GetText() << "\n";
  out.close();
}

void show_regression::printer_changed(const char *newprinter)
{
  printerlab.labelString(WHAT((char *) "Skriver: %s",
			      (char *) "Printer: %s"), newprinter);
}

void show_regression::take_action(REGRESS_ACTION action)
{
  switch(action)
    {
    case REGRESS_CHANGE_DESCRIPTIONS:
      descript_change.Create(this, alias, titles, numseries);
      break;
    case REGRESS_RUN:
      run_regression();
      break;
    case REGRESS_EXTRA_SUM:
      extra_sum_of_squares();
      break;
    case REGRESS_EXTRA_SUM_START:
      start_extra_sum_of_squares();
      break;
    case REGRESS_PREDICT:
      predict();
      break;
    case REGRESS_ADD: 
      add();
      break;
    case REGRESS_REMOVE_PREDICTOR: 
      removepredictor();
      break;
    case REGRESS_CHANGE_PREDICTOR:
      changepredictor();
      break;
    case REGRESS_POW:
      fetch_pow(True);
      break;
    case REGRESS_TRIGONOMETRIC:
      fetch_trigonometric(True);
      break;
    case REGRESS_POW2:
      fetch_pow(False);
      break;
    case REGRESS_TRIGONOMETRIC2:
      fetch_trigonometric(False);
      break;
    case REGRESS_CLOSE:
      close();
      break;
    case REGRESS_PLOT_VARIABLE:
      doplot(False);
      break;
    case REGRESS_PLOT_PREDICTOR:
      doplot(True);
      break;
    case REGRESS_PRINT:
      doprint();
      break;
    case REGRESS_CHANGEPRINTER:
      startchangeprinter();
      break;
    case REGRESS_SAVEFILE:
      start_savefile();
      break;
    }
}

void show_regression::list_hit(int index)
{
  if(response_set && index==0)
    {
      pred_or_resp.SetFocus(1);
      variablemenu1.SetFocus(response_index);
      variablemenu4.SetFocus(0);
      fchoice.set_function_type(response_func);
      scalef.SetDouble(response_scale);
      scalef.EditAble(True);
    }
  else
    {
      int index2=response_set ? index-1 : index;

      pred_or_resp.SetFocus(0);
      variablemenu1.SetFocus(predictor_index[index2]);
      fchoice.set_function_type(predictor_func[index2]);
      scalef.SetDouble(predictor_scales[index2]);
      scalef.EditAble(True);
      variablemenu4.SetFocus(interaction_index[index2]+1);
      fchoice2.set_function_type(interaction_func[index2]);
      scalef2.SetDouble(interaction_scales[index2]);
      scalef2.EditAble(True);
    }
}

void show_regression::set_descriptions(char const* const* newalias, char const* const* newtitle, 
				       int num)
{
  int i;

  if(titles)
    {
      for(i=0;i<numseries;i++)
	if(titles[i])
	  delete [] titles[i];
      delete [] titles;
    }
  
  if(alias)
    {
      for(i=0;i<numseries;i++)
	if(alias[i])
	  delete [] alias[i];
      delete [] alias;
    }
  
  titles=new char*[num];
  alias=new char*[num];
  for(i=0;i<num;i++)
    {
      alias[i]=new char[strlen(newalias[i])+2];
      strcpy(alias[i], newalias[i]);
      titles[i]=new char[strlen(newtitle[i])+2];
      strcpy(titles[i], newtitle[i]);
    }

  update_regression_type();

  for(i=0;i<numseries;i++)
    aliaslab[i].labelString("%s=%s",alias[i],titles[i]);
  variablemenu1.Insert(alias, numseries, 0);
  variablemenu2.Insert(alias, numseries, 0);

  char **itembuf=new char*[numseries+1];
  for(i=0;i<numseries+1;i++)
    itembuf[i]=new char[100];
  strcpy(itembuf[0], WHAT((char *) "Ingen", (char *) "None"));
  for(i=0;i<numseries;i++)
    strcpy(itembuf[i+1], alias[i]);
  variablemenu4.Insert(itembuf, numseries+1, 0);
  for(i=0;i<numseries+1;i++)
    delete [] itembuf[i];
  delete [] itembuf;
}

show_regression::show_regression()
{
  response_set = False;
  numseries = 0;
  len = 0;
  serievalues = NULL;
  titles   = NULL;
  alias    = NULL;
  aliaslab = NULL;
  result   = NULL;
  predictor_index  = NULL;
  predictor_func   = NULL;
  predictor_scales = NULL;
  interaction_index  = NULL;
  interaction_func   = NULL;
  interaction_scales = NULL;
  plot = NULL;
  currentrule = NULL;
}

show_regression::~show_regression(void)
{
  cleanup();
}

void show_regression::Create(double **seriedata, int length, 
			     int numseries_, char const* const* serietitles)
{
  int i,j;

  cleanup();

  response_set=False;

  numseries=numseries_;

  // copy the incoming data;
  serievalues = new double*[numseries];
  titles = new char*[numseries];
  alias  = new char*[numseries];

  int timeindex  = 1;
  int valueindex = 1;
  len = length;

  for(i=0;i<numseries;i++)
    {
      serievalues[i] = new double[length];
      titles[i] = new char[strlen(serietitles[i])+2];
      alias[i]  = new char[10];

      strcpy(titles[i], serietitles[i]);
      if(!strncasecmp(titles[i], WHAT((char *) "Tid", "Time"), WHAT(3,4)))
	sprintf(alias[i], "T%d", timeindex++);
      else
	sprintf(alias[i], "X%d", valueindex++);

      for(j=0;j<length;j++)
	serievalues[i][j]=seriedata[i][j];
    }

  make_window();
}

void show_regression::regression_done(regression_rule* /* rule */)
{
}

#ifdef MAIN

void main(int argc, char **argv)
{
  int i, j, len=100;;
  mainwin mn("show_regression", argc, argv);
  double **values=new double*[3];
  char **titles=new char*[3];
  show_regression sr;

  for(i=0;i<3;i++)
    {
      titles[i] = new char[100];
      values[i] = new double[len];
    }

  strcpy(titles[0], "x");
  strcpy(titles[1], "y");
  strcpy(titles[2], "z");

  for(j=0;j<len;j++)
    {
      values[1][j] = 0.9*drand48()+0.1;
      values[0][j] = 2.0*pow(values[1][j], 1.5) + 0.1*drand48()-0.05;
      values[2][j] = drand48();
    }

  sr.Create(values, len, 3, titles);
  mn.Run();
}

#endif // MAIN
