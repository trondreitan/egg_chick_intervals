/*
 * $Id: selmethod.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/selmethod.C $
 */

#include <hydrasub/hydragui/selmethod.H>

void selmethod::init(void)
{
  mets=NULL;
  nummets=0;
}

void selmethod::cleanup(void)
{
  if(mets)
    delete [] mets;
  init();
}

selmethod::selmethod()
{
  init();
}

selmethod::~selmethod()
{
  cleanup();
}

void selmethod::create(widget parent, METHOD *methods, int num_methods)
{
  int i;

  cleanup();

  if(methods && num_methods>0)
    {
      nummets=num_methods;
      mets=new METHOD[nummets];
      for(i=0;i<nummets;i++)
	mets[i]=methods[i];
    }
  else
    {
      nummets=NUMBER_OF_METHODS-1;
      mets=new METHOD[nummets];
      for(i=0;i<nummets;i++)
	mets[i]=methodlist[i+1];
    }
  
  char **metstr=new char*[nummets];
  for(i=0;i<nummets;i++)
    {
      metstr[i]=new char[100];
      strcpy(metstr[i], Get_method_name(mets[i]));
    }
  
  Create(parent, WHAT((char *) "Metode:", (char *) "Method:"));
  Insert(metstr, nummets);

  doubledelete(metstr, nummets);
}

void selmethod::setfocus(METHOD met)
{
  for(int i=0;i<nummets;i++)
    if(mets[i]==met)
      SetFocus(i);
}

METHOD selmethod::getmethodkey(void)
{
  int index=GetNumber();

  if(index>=0 && index<nummets)
    return mets[index];
  else
    return UNKNOWN_METHOD;
}
