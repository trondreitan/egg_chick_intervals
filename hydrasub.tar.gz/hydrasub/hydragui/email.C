/*
 * $Id: email.C 2610 2015-11-23 10:26:43Z trr $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/email.C $
 */

#include <hydrasub/hydragui/email.H>
#include <fstream>
#include <string>
#include <sys/types.h>

#ifdef NVE
#include <envirsub/system.H>    
#else
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#endif // NVE

void email_module_button::Create(Widget par, const char *name, email_module *ipt,
				 EMAIL_MODULE_TYPE type)
{
  build(par,name);
  typ=type;
  pt=ipt;
}

void email_module_button::pushed(void)
{
  pt->buttonpushed(typ);
}



void email_fsel::Create(email_module *ipt)
{
  pt=ipt;
  sh.build(mainwin::toplevel, "Hente fil");
  v1.build(sh);
  build(v1);
  sh.Map();
}

void email_fsel::ok(const char *file)
{
  pt->attach(file);
  sh.Unmap();
}

void email_fsel::cancel(void)
{
  sh.Unmap();
}


void email_printershell::create(email_module *ipt)
{
  pt=ipt;
  Create();
}

void email_printershell::ok_pushed(const char *newprinter)
{
#ifdef LINUX  
  setenv("PRINTER", newprinter, 1);
#else
  char cmd[1200];
  sprintf(cmd, "PRINTER=%s", newprinter);
  putenv(cmd);
#endif
  pt->printer_changed(newprinter);
}

email_module::email_module()
{
  created=False;
  parentwindow=NULL;
}


void email_module::Create(widget parent, email *parent_window,
			  const char *receiver, const char *subject, const char *start,
			  bool fakemail)
{
  parentwindow=parent_window;
  Create(parent, receiver, subject, start, fakemail);
}

void email_module::Create(widget parent, 
			  const char *receiver, const char *subject, const char *start,
			  bool fakemail)
{
  fake=fakemail;
  
  do_make(parent, receiver, subject);
  
  if(start && *start)
    inputf.SetText(start);
  else
    inputf.Clear();
}

bool email_module::addfile(const char *file)
{
  std::ifstream in;
  char line[1000];

  in.open(file, std::ios::in);

  if(in.fail())
    {
      char errstr[1000];
      sprintf(errstr, "Klarte ikke � �pne filen %s", file);
      err.build(*this, "Feil", errstr);
      return False;
    }

  in.getline(line, 999);
  while(!in.fail())
    {
      inputf += line;
      inputf += "\n";

      in.getline(line, 999);
    }

  in.close();

  return True;
}


bool email_module::attach(const char *file)
{
  std::ifstream in;

  in.open(file, std::ios::in);

  if(in.fail())
    {
      char errstr[1000];
      sprintf(errstr, "Klarte ikke � �pne filen %s", file);
      err.build(*this, "Feil", errstr);
      return False;
    }

  in.close();

  attachlist.Insert(file);

  return True;
}

void email_module::doprint(void)
{
  char cmd[1000];
  int num,i;
  char **attfiles;

  sprintf(cmd,"lpr");
  FILE *p = popen(cmd, "w");
  if(!p) 
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Klarer ikke � skrive ut", 
		     (char *) "Couldn't print!"));
      return;
    }

  if(fake)
    {
      fprintf(p, "From: %s", fromf());
      if(*(aliasf())!='\0')
	fprintf(p, " (%s)", aliasf());
      fprintf(p, "\n");
      fprintf(p, "To: %s\n", fakerecf());
    }
  else
    fprintf(p, "To: %s\n", receiverf());

  fprintf(p, "Subject: %s\n", subjectf());
  fprintf(p, "%s\n", inputf.GetText());

  num=attachlist.Get(&attfiles);
  for(i=0;i<num;i++)
    {
      char strbuffer[200];
      sprintf(strbuffer, "Attachement %d: %s", i+1, attfiles[i]);
      fprintf(p, "%s\n", strbuffer);
    }
  pclose(p);

  char printstr[100];
  sprintf(printstr, WHAT((char *) "Utskrift sendt til %s",
			 (char *) "Text sent to %s"), getenv("PRINTER"));
  mess.build(mainwin::toplevel, WHAT((char *) "Melding", (char *) "Message"),
	     printstr);
}

bool email_module::do_attach(FILE *p, const char *file)
{
  std::ifstream in;
  char cmd[1000];
  FILE *p2;

  in.open(file, std::ios::in);
  if(in.fail())
    {
      char errstr[1000];
      sprintf(errstr, "Klarte ikke � �pne filen %s", file);
      err.build(*this, "Feil", errstr);
      return False;
    }
  in.close();

  const char* ptr;
  for(ptr=file+strlen(file)-1; ptr>=file && *ptr!='/'; ptr--);
  ptr++;

  sprintf(cmd,"uuencode %s < %s", ptr, file);
  p2 = popen(cmd, "r"); // start reading using 'ls'

  char c;
  while(!feof(p2)) //while there's more input coming our way
    {
      fread(&c, sizeof(char), 1, p2);
      fwrite(&c, sizeof(char), 1, p);
    }

  pclose(p2);
  
  return True;
}

void email_module::printer_changed(const char *newprinter)
{
  printerlab.labelString(WHAT((char *) "Skriver: %s", 
			      (char *) "Printer: %s"), newprinter);
}

void email_module::do_make(widget parent, const char *receiver, const char *subject)
{
  char host[100], addr[200], user[100];

#ifdef NVE
  strcpy(user, hydraenvir::system::get_user_name().c_str());
#else
  strcpy(user, getpwuid(getuid())->pw_name);
#endif // NVE

  if(!created)
    {
      build(parent);
      
      h3.build(*this);
      v1.build(h3);

      if(fake)
	{
	  fromf.build(v1,25, WHAT((char *) "Fra: ", (char *) "From:"));
	  aliasf.build(v1, 30, WHAT((char *) "Fullt navn", 
				    (char *) "Full name:"));
	}

      receiverf.build(v1,50,WHAT((char *) "Til: ", (char *) "To:  "));     
      if(fake)
	fakerecf.build(v1, 40, WHAT((char *) "Falsk \"til\":", 
				    (char *) "False \"to\": "));
      subjectf.build(v1,50, WHAT((char *) "Tema:", (char *) "Subject:"));
      
      v3.build(h3);
      attlabel.build(v3, "     Attachments:          ");
      attachlist.build(v3, 8, 1);

      h4.build(v3);
      attachb.Create(h4, WHAT((char *) "Legg til", (char *) "Append"), 
		     this, EMAIL_ATTACH);
      removeattb.Create(h4, WHAT((char *) "Fjern", (char *) "Remove"), 
			this, EMAIL_REMOVE_ATT);

      inputf.build(*this, 80, 25, True);

      sep1.build(*this);
      h1.build(*this);

      sendb.Create(h1,"Send",this,EMAIL_SEND);
      sendb.Background("green");
      sendb.Foreground("black");

      printb.Create(h1, WHAT((char *) "Skriv ut", (char *) "Print"), 
		    this, EMAIL_PRINT);
      printb.Background("blue");
      printb.Foreground("white");
      
      printerlab.build(h1, WHAT((char *) "Skriver: %s", 
				(char *) "Printer: %s"), 
		       getenv("PRINTER"));
      printerlab.Background("white");
      printerlab.Foreground("black");

      chprinterb.Create(h1, WHAT((char *) "Forandre skriver", 
				 (char *) "Change printer"), this,
			EMAIL_CH_PRINTER);
    }

  if(receiver && *receiver)
    {
      char recstr[100];
      
      if(!strstr(receiver,"@"))
	sprintf(recstr,"%s@nve.no",receiver);
      else
	strcpy(recstr,receiver);
      receiverf.SetText(recstr);

      if(fake)
	fakerecf.SetText(recstr);
    }

  if(subject && *subject)
    subjectf.SetText(subject);

  if(fake)
    {
#ifdef NVE
      strncpy(host, hydraenvir::system::get_host_name().c_str(), sizeof(host));
#else
      gethostname(host, 99);
#endif // NVE

      sprintf(addr, "%s@%s", user, host);
      
      fromf.SetText(addr);      
    }

  findfullname(user);
  
  attachlist.Clear();

  created=True;
}


void email_module::findfullname(const char *user)
{
  std::ifstream in;
  char line[1000], name[1000], *ptr;

  in.open("/etc/passwd");
  if(in.fail())
    return;

  while(!in.eof() && !in.fail())
    {
      in.getline(line, 999);
      if(in.fail())
	break;
      
      if(!strncasecmp(user, line, strlen(user)) && line[strlen(user)]==':')
	{
	  int numcol=0, i=0;

	  while(i<(int)strlen(line) && numcol<4)
	    {
	      if(line[i]==':')
		numcol++;
	      i++;
	    }

	  if(numcol==4)
	    {
	      ptr=name;

	      while(i<(int)strlen(line) && line[i]!=':')
		{
		  *ptr=line[i];
		  
		  i++;
		  ptr++;
		}
	      
	      *ptr='\0';

	      if(fake)
		aliasf.SetText(name);
	    }
	  
	  return;
	}
    }
}


void email_module::start_attach(void)
{
  fsel.Create(this);
}


void email_module::buttonpushed(EMAIL_MODULE_TYPE type)
{
  switch(type)
    {
    case EMAIL_PRINT:
      doprint();
      break;
    case EMAIL_CH_PRINTER:
      prsh.create(this);
      break;
    case EMAIL_ATTACH:
      start_attach();
      break;
    case EMAIL_REMOVE_ATT:
      attachlist.ClearSelected();
      break;
    case EMAIL_SEND:
      send();
      //mess.build(mainwin::toplevel,
      //	 WHAT((char *) "Melding:", (char *) "Message:"),
      //	 WHAT((char *) "Epost har blitt (fors�kt) sendt!", 
      //	      (char *) "Email has been sent!"));
      if(parentwindow)
	{
	  parentwindow->ended();
	  parentwindow->Unmap();
	}
      break;
    }
}




void email_module::send(void)
{
  char cmd[1000];
  int num,i;
  char **attfiles;
  char receivers[1000];
  strcpy(receivers,receiverf());
  
  int num_rec=1, n=strlen(receivers);
  for(i=0;i<n;i++)
    if((receivers[i]==';' || receivers[i]==',') && 
       (i==0 || (receivers[i-1]!=';' && receivers[i-1]!=',')) && i<(n-1))
      num_rec++;

  char **receiver=new char*[num_rec];
  for(i=0;i<num_rec;i++)
    receiver[i]=new char[100];
  int j=0,k=0;
  for(i=0;i<n;i++)
    {
      if(receivers[i]!=';' && receivers[i]!=',')
	{
	  if(receivers[i]!=' ') // ignore spaces
	    receiver[j][k++]=receivers[i];
	}
      else if((receivers[i]==';' || receivers[i]==',')  && 
	      (i==0 || (receivers[i-1]!=';' && receivers[i-1]!=',')) && 
	      i<(n-1))
	{
	  receiver[j][k++]='\0';
	  j++;
	  k=0;
	}
    }
  receiver[j][k]='\0';

  for(i=0;i<num_rec;i++)
    {
      sprintf(cmd,"/usr/lib/sendmail \"%s\"",
	      receiver[i]);
      FILE *p = popen(cmd, "w");
      if(!p) 
	{
	  err.build(mainwin::toplevel, 
		    WHAT((char *) "Feil", (char *) "Error"), 
		    WHAT((char *) "Klarer ikke � sende", 
			 (char *) "Couldn't send email!"));
	  return;
	}
      
      if(fake)
	{
	  fprintf(p, "From: %s",fromf());
	  if(*(aliasf())!='\0')
	    {
	      fprintf(p, " (%s)",  aliasf());
	    }
	  fprintf(p,"\n");
	  
	  fprintf(p, "To: %s\n", fakerecf());
	}
      else
	{
	  fprintf(p, "To: %s\n",receiverf());
	}
      fprintf(p, "Subject: %s\n\n", subjectf()); 
      fprintf(p, "%s\n", inputf.GetText());
      
      num=attachlist.Get(&attfiles);
      for(j=0;j<num;j++)
	{
	  if(!do_attach(p, attfiles[j]))
	    return;
	}
      
      pclose(p);
    }
}



void emailbutton::Create(Widget par,const char *name,email *ipt,
			 EMAIL_BUTTON_TYPE type)
{
  build(par,name);
  typ=type;
  pt=ipt;
}

void emailbutton::pushed(void)
{
  pt->buttonpushed(typ);
}



email::email()
{
  created=False;
}

void email::buttonpushed(EMAIL_BUTTON_TYPE type)
{
  switch(type)
    {
    case EMAIL_QUIT:
      ended();
      Unmap();
      break;
    }
}

void email::ended(void)
{
}


void email::Create(const char *receiver,const char *subject,const char *start, 
		   bool fakemail)
{
  if(!created)
    {
      build(mainwin::toplevel, "Email");
      v1.build(*this);
      emod.Create(v1, this, receiver, subject, start, fakemail);
      sep1.build(v1);
      h1.build(v1);
      closeb.Create(h1, WHAT((char *) "Avslutt", (char *) "Quit"), 
		    this, EMAIL_QUIT);
      closeb.Background("red");
      closeb.Foreground("white");
    }
  
  created=True;
  Map();
}

bool email::addfile(const char *file)
{
  return emod.addfile(file);
}

bool email::attach(const char *file)
{
  return emod.attach(file);
}



#ifdef MAIN

class emailwin;
class emailwinbutton : public pushb
{
  emailwin *pt;
public:
  void Create(Widget parent, const char *title, emailwin *ipt);
  void pushed(void);
};

class emailwin : public mainwin
{
  vrow v1;
  email_module mail;
  emailwinbutton exitb;
public:
  emailwin(const char *title, int argc, const char **argv);
};

void emailwinbutton::Create(Widget parent, const char *title, emailwin *ipt)
{
  build(parent, title);
  pt=ipt;
}

void emailwinbutton::pushed(void)
{
  exit(0);
}

emailwin::emailwin(const char *title, int argc, const char **argv) : mainwin(title, 
								 argc, argv)
{
  v1.build(*this);
  mail.Create(v1);
  exitb.Create(v1, WHAT((char *) "Avslutt", (char *) "Close"), this);
  exitb.Background("red");
  exitb.Foreground("white");
}

void main(int argc, char **argv)
{
  emailwin ew("postut", argc, argv);
 
  ew.Run();
}

#endif // MAIN

