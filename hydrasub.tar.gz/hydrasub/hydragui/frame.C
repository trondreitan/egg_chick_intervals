/*
 * $Id: frame.C 458 2006-03-10 08:26:27Z bjg $
 * $URL: svn://h-dev02.nve.no/hydra/trunk/source/hydrasub/hydragui/frame.C $
 */

#include <hydrasub/hydragui/frame.H>

#include <Xm/Frame.h>

// ######################################################################
// Return    : 
// Parameters: 
// Purpose   : 
// ######################################################################
void frame::build(const Widget parent) {
    XmNoArg;
    init("frame", xmFrameWidgetClass, parent);
}
