#include <hydrabase/linalg.H>
#include "wavelab.H"
#include <math.h>

void wavelab_startstop::Create(widget parent, wavelab_draw *ipt)
{
  build(parent, "Start/Stop");
  pt=ipt;
}

void wavelab_startstop::pushed(void)
{
  pt->startstop();
}

void wavelab_init::pushed(char *)
{
  if((*this)()>=2)
    pt->flat_pushed();
}

void wavelab_restart::Create(widget parent, wavelab_draw *ipt)
{
  build(parent, "Restart");
  pt=ipt;
  Background("green");
  Foreground("black");
}

void wavelab_restart::pushed(void)
{
  pt->restart();
}

wavelab_draw::wavelab_draw(int argc, char **argv)
{
  if(argc<3)
    {
      len_x=300;
      len_n=300;
    }
  else
    {
      len_x=atoi(argv[1]);
      len_n=atoi(argv[2]);
    }

  if(argc<4)
    dt=0.0001;
  else
    dt=atof(argv[3]);
  w=screenwidth()-10;
  h=screenheight()-200;
  t=0;
  istate=0;

  p0=100;
  if(argc>4)
    p0=atof(argv[4]);

  sigma=0.04;
  if(argc>5)
    sigma=atof(argv[5]);

  prevballpos=MISSING_VALUE;

  numclassic=10000;
  if(argc>6)
    numclassic=atoi(argv[6]);

  init();
  dorun=b_false;
}


void wavelab_draw::init(void)
{
  long int i,j;
  cvector bufx(len_x), bufn(len_n);

  complex im(0,1);

  psi_x=bufx;
  if(istate==0)
    {
      for(i=0;i<len_x;i++)
	{
	  double x=double(i)/double(len_x-1);
	  complex ea(1.0,p0*x,1);
	  double xsq=-(x-0.5)*(x-0.5)/4.0/sigma/sigma;
	  complex cc=ea;

	  cc*=exp(xsq);
	  cc/=sqrt(sigma*sqrt(2.0*M_PI));
	  psi_x.set_element(i, cc);
	}
    }
  else if(istate==1)
    {
      for(i=0;i<len_x/2;i++)
	{
	  double x=double(i)/double(len_x-1);
	  double x2=double(len_x-1-i)/double(len_x-1);
	  complex ea(1.0,p0*x,1), ea2(1.0,-p0*x2,1);
	  double xsq=-(x-0.25)*(x-0.25)/4.0/sigma/sigma;
	  double xsq2=-(x2-0.75)*(x2-0.75)/4.0/sigma/sigma;
	  complex cc=ea, cc2=ea2;

	  cc*=exp(xsq);
	  cc2*=exp(xsq2);
	  cc/=sqrt(sigma*sqrt(2.0*M_PI));
	  cc2/=sqrt(sigma*sqrt(2.0*M_PI));
	  psi_x.set_element(i, cc);
	  psi_x.set_element(len_x-1-i, cc2);
	}
    }
  else if(istate==2)
    {
      for(i=0;i<len_x;i++)
	{
	  double x=double(i)/double(len_x-1);
	  complex ea(1.0,p0*x,1);
	  psi_x.set_element(i,ea);

	  //psi_x.set_element(i, sin(2.0*M_PI*p0*x)>0 ? 1 : -1);
	}
    }
  else if(istate==3)
    {
      for(i=0;i<len_x;i++)
	{
	  double x=double(i)/double(len_x-1);
	  complex ea(1.0,p0*x,1);
	  
	  if((x-0.5)*(x-0.5)<sigma*sigma)
	    psi_x.set_element(i,ea);
	  else
	    psi_x.set_element(i,0);
	}
    }
  else if(istate==4)
    {
      for(i=0;i<len_x;i++)
	{
	  double x=double(i)/double(len_x-1);
	  complex ea(1.0,p0*x,1);
	  double scale=sqrt(2.0-4.0*ABSVAL((x-0.5)));

	  psi_x.set_element(i,ea*scale);
	}
    }
  else if(istate==5)
    {
      for(i=0;i<len_x;i++)
	{
	  double x=double(i)/double(len_x-1);
	  complex ea(1.0,p0*x,1);
	  double scale=sqrt(1.0-ABSVAL((x-0.5))/sigma)/sigma;
	  
	  if((x-0.5)*(x-0.5)<sigma*sigma)
	    psi_x.set_element(i,ea*scale);
	  else
	    psi_x.set_element(i,0);
	}
    }

  psi_x.set_element(0,0);
  //psi_x.set_element(1,0);
  //psi_x.set_element(2,0);
  //psi_x.set_element(len_x-3,0);
  //psi_x.set_element(len_x-2,0);
  psi_x.set_element(len_x-1,0);

  double sigmax=sigma, sigmap=0.5/sigma;
  if(numclassic>0)
    {
      clx=new double[numclassic], clp=new double[numclassic];
      prob_classic=new double[len_x];
      for(i=0;i<numclassic;i++)
	{
	  if(istate==0)
	    {
	      clx[i]=0.5+gauss()*sigmax;
	      clp[i]=p0+gauss()*sigmap;
	    }
	  else if(istate==1)
	    {
	      if(drand48()<0.5)
		{
		  clx[i]=0.25+gauss()*sigmax;
		  clp[i]=p0+gauss()*sigmap;
		}
	      else
		{
		  clx[i]=0.75+gauss()*sigmax;
		  clp[i]=-p0+gauss()*sigmap;
		}
	    }
	  else if(istate==2)
	    {
	      clx[i]=drand48();

	      sigmap=0.5/sqrt(1.0/12.0);
	      clp[i]=p0+gauss()*sigmap;
	    }
	  else if(istate==3)
	    {
	      clx[i]=0.5+sigma*(2.0*drand48()-1.0);

	      sigmap=0.5/sqrt(1.0/12.0)*0.5/sigma;
	      clp[i]=p0+gauss()*sigmap;
	    }
	  else if(istate==4)
	    {
	      clx[i]=0.5*(drand48()+drand48());

	      sigmap=0.5/sqrt(7.0/24.0);
	      clp[i]=p0+gauss()*sigmap;
	    }
	  else if(istate==5)
	    {
	      clx[i]=0.5+sigma*(drand48()+drand48()-1.0);

	      sigmap=0.5/sqrt(7.0/24.0)*0.5/sigma;
	      clp[i]=p0+gauss()*sigmap;
	    }
	}
    }

  complex psilen=psi_x.length();
  psi_x/=psilen;
  
  max=0;
  for(i=0;i<len_x;i++)
    max=MAXIM(psi_x(i).abs2(),max);
  cout << max << endl;
  max=10.0/double(len_x); 
  if(istate==2 || istate==4)
    max/=3.0;

  psi_n=bufn;
  for(i=0;i<len_n;i++)
    {
      complex c=0;

      for(j=0;j<len_x;j++)
	{
	  double x=double(j)/double(len_x-1);
	  c+=2.0*sin(M_PI*double(i+1)*x)*psi_x(j);
	}

      psi_n.set_element(i,c);
    }

  cmatrix mbuf(len_x, len_n);

  for(j=0;j<len_x;j++)
    for(i=0;i<len_n;i++)
      {
	double x=double(j)/double(len_x-1);
	complex c=2.0*sin(M_PI*double(i+1)*x);
	mbuf.set_element(j,i,c);
      }
  
  n_x=mbuf;

  
  prob=new double[len_x];
  xx=new double[len_x];
  yy=new double[len_x];
  yold=new double[len_x];
  for(i=0;i<len_x;i++)
    {
      yold[i]=prob[i]=yy[i]=0;
      xx[i]=floor(double(w)-2-double(w)*double(i)/double(len_x));
    }

  hsv black;
  rgb black2=hsv_to_rgb(black);
  srgb=new rgb*[20];
  brgb=new rgb*[20];
  for(i=0;i<20;i++)
    {
      srgb[i]=new rgb[20];
      brgb[i]=new rgb[20];

      for(j=0;j<20;j++)
	{
	  hsv col(0.5, 0.5, 
		  MINIM(1.0, MAXIM(0.0,1.0-double((i-7)*(i-7)+
						  (j-8)*(j-8))/100.0))); 
	  rgb col2=hsv_to_rgb(col);
	  
	  brgb[i][j]=black2;
	  if((i-10)*(i-10)+(j-10)*(j-10)<=100)
	    srgb[i][j]=col2;
	  else
	    srgb[i][j]=black2;
	}
    }
}

void wavelab_draw::Create(widget parent)
{
  v1.build(parent);
  build(v1,w,h);

  h2.build(v1);
  numclassicf.build(h2, 6, "#classic part:");
  numclassicf.SetDigit(numclassic);
  showphase.build(h2, "<-Show phase  ");
  showphase.ToggleButtonOff();
  doshowphase=b_false;
  char *items[]={"One packet","Two packets","Flat", "Rectangular", 
		 "Triangular-all","Triangular"};
  ilab.build(h2, "Initial state:");
  initialstate.hbuild(h2, items,6,0);
  istate=0;
  initialstate.pt=this;

  h1.build(v1);
  exitb.Create(h1);
  ssb.Create(h1, this);
  restartb.Create(h1, this);
  stepf.build(h1, 8, "Time step rate:");
  stepf.SetDouble(dt, 7);
  resolutionf.build(h1, 4, "resolution:");
  resolutionf.SetDigit(len_x);
  momentf.build(h1, 4, "Mean moment:");
  momentf.SetDigit((int) p0);
  sigmaf.build(h1, 6, "Sigma:");
  sigmaf.SetDouble(sigma, 6);
}

void wavelab_draw::wakeup(void)
{
  expose();
}

void wavelab_draw::restart(void)
{
  len_x=len_n=resolutionf.getdigit();
  sigma=sigmaf.getdouble();
  dt=stepf.getdouble();
  p0=momentf.getdouble();
  numclassic=numclassicf.getdigit();

  if(showphase())
    doshowphase=b_true;
  else
    doshowphase=b_false;

  istate=initialstate();

  do_xor();
  if(prevballpos!=MISSING_VALUE)
    show_sprite(srgb, 20, 20, (int)prevballpos-10, h-25);
  do_copy();
  prevballpos=MISSING_VALUE;

  t=0;
  init();
  Clear();
  expose();
  dorun=b_false;
}

void wavelab_draw::startstop(void)
{
  if(dorun)
    dorun=b_false;
  else
    {
      dorun=b_true;
      Set(1);
    }
}

void wavelab_draw::flat_pushed(void)
{
  stepf.SetDouble(0.00001);
  momentf.SetDigit(0);
  numclassicf.SetDigit(0);
}

void wavelab_draw::expose(void)
{
  long int i;

  cvector psi_nt(len_n);
  for(i=0;i<len_n;i++)
    {
      double en=0.5*M_PI*M_PI*double(i+1)*double(i+1);
      complex c(1,-en*t,1);
      psi_nt.set_element(i,c*psi_n(i));
    }
  
  psi_x=n_x*psi_nt;
  psi_x/=psi_x.length();

  for(i=0;i<len_x;i++)
    prob[i]=psi_x(i).abs2();
  
  for(i=0;i<len_x;i++)
    yy[i]=double(h-30)-2-double(h-30)*0.5*prob[i]/max;
  
  Set_No_Dashes(2);
  for(i=1;i<len_x;i++)
    {
      SetFg("black");
      Line(xx[i-1],yold[i-1],xx[i],yold[i]);
      SetFg("white");
      Line(xx[i-1],yy[i-1],xx[i],yy[i]);
    }

  for(i=0;i<len_x;i++)
    yold[i]=yy[i];

  for(i=1;i<len_x;i++)
    {
      char col[100];
      int intensity=(int)floor(255.0*prob[i]/max);
      intensity=MINIM(255,MAXIM(0,intensity));
      
      sprintf(col, "#%02x%02x%02x", intensity,intensity,intensity);
      SetFg(col);
      Rectangle(floor(xx[i-1]), 30, ceil(xx[i]), 60,True);

      if(doshowphase)
	{
	  // Show phase
	  double angle=0.5+psi_x(i).angle()/2.0/M_PI;
	  hsv h(angle,1.0,1.0);
	  rgb r=hsv_to_rgb(h);
	  
	  sprintf(col, "#%02x%02x%02x", r.red, r.green, r.blue);
	  SetFg(col);
	  Rectangle(floor(xx[i-1]), 0, ceil(xx[i]), 10,True);
	}
    }

  // Show mean position:
  ballpos=0;
  for(i=0;i<len_x;i++)
    ballpos+=xx[i]*prob[i];
  do_xor();
  if(prevballpos!=MISSING_VALUE)
    show_sprite(srgb, 20, 20, (int)prevballpos-10, h-25);
  show_sprite(srgb, 20, 20, (int)ballpos-10, h-25);
  prevballpos=ballpos;
  do_copy();

  // classic
  SetFg("black");
  Rectangle(0,h-5,w,h);
  SetFg("white");

  for(i=0;i<len_x;i++)
    prob_classic[i]=0;

  if(numclassic>0)
    {
      for(i=0;i<numclassic;i++)
	{
	  double x=clx[i]+clp[i]*t;
	  int numover=(int)floor(x);
	  double clx2;
	  
	  if(numover%2==0)
	    clx2=x-numover;
	  else
	    clx2=numover+1-x;
	  
	  int pos=(int) floor(clx2*len_x);
	  if(pos>=0 && pos<len_x)
	    prob_classic[pos]++;
	}
      
      for(i=0;i<len_x;i++)
	prob_classic[i]/=double(numclassic);
  
      for(i=1;i<len_x;i++)
	{
	  char col[100];
	  int intensity=(int)floor(255.0*prob_classic[i]/max);
	  intensity=MINIM(255,MAXIM(0,intensity));
	  sprintf(col, "#%02x%02x%02x", intensity,intensity,intensity);
	  
	  SetFg(col);
	  Rectangle(floor(xx[i-1]), 60, ceil(xx[i]), 90,True);
	}
    }

  t+=dt;

  if(dorun)
    Set(1);
}

void usage(void)
{
  cout << "Usage: wavelab [<x resolution> <energy resolution> " << endl;
  cout << "               [<time step rate> [<mean moment>" << endl;
  cout << "               [<sigma> [<number in classic ensemble>]]]]]" << endl;
  cout << "The program can be started without input arguments." << endl;
  exit(0);
}

int main(int argc, char **argv)
{
  if(argc>1 && !strncasecmp(argv[1], "-h", 2))
    usage();

  mainwin sc("Wavelab", argc, argv);
  vrow v1;
  hrow h1;
  wavelab_draw dr(argc, argv);
  
  v1.build(sc);
  dr.Create(v1);

  sc.Run();
}
