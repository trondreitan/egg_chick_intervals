#include <hydrasub/hydrabase/divfunc.H>
#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/stagedischarge.H>
#include <hydrasub/hydrabase/regression.H>
#include <hydrasub/hydrabase/linalg.H>
#include <gsl/gsl_randist.h>
#include <cmath>
 

double B1(double h, double hs, double h01)
{
  if(h<hs && h>h01)
    return log(h-h01);
  else if(h>=hs && hs>h01)
    return log(hs-h01);
  else
    return MISSING_VALUE;
}

double B2(double h, double hs, double h02)
{
  if(h<hs)
    return 0.0;
  else if(h>hs && hs>h02)
    return log(h-h02)-log(hs-h02);
  else
    return MISSING_VALUE;
}

double logprob(double *q, double *h, int len, double hmin, double hmax,
	       double a1, double b1, double b2, double hs, double h01, double h02, 
	       double s2, double **inv_var,
	       double a1_m, double b1_m, double b2_m, double mu_q, double sigma2_q,
	       double sigma_a, double sigma_b, double mu_h02, double sd_h02,
	       double T,
	       double h01_m=MISSING_VALUE, double h01_s2=MISSING_VALUE, 
	       double h02_m=MISSING_VALUE, double h02_s2=MISSING_VALUE,
	       double hs_m=MISSING_VALUE, double hs_s2=MISSING_VALUE)
{
  int i;
  double n=(double) len;

  if(s2<0.0 || h01>hs || h02>hs || hmin<h01 || hs<hmin || hs>hmax)
    return -1e+216;

  // contrubtion from (beta-m)V^(-1)(beta-m);
  double contrib_pri_beta = - 0.5*
    ((a1-a1_m)*(a1-a1_m)*inv_var[0][0]+
     (a1-a1_m)*(b1-b1_m)*(inv_var[0][1]+inv_var[1][0])+
     (a1-a1_m)*(b2-b2_m)*(inv_var[0][2]+inv_var[2][0])+
     (b1-b1_m)*(b2-b2_m)*(inv_var[1][2]+inv_var[2][1])+
     (b1-b1_m)*(b1-b1_m)*inv_var[1][1]+
     (b2-b2_m)*(b2-b2_m)*inv_var[2][2]);
  

  /*
  double contrib_h01=-0.5*(a1+b1*log(hs-h01)-mu_q)*(a1+b1*log(hs-h01)-mu_q)/sigma2_q+
    log(b1)-log(hs-h01)-0.5*log(sigma2_q);
  double contrib_h02=-0.5*(a2+b2*log(hs-h02)-mu_q)*(a2+b2*log(hs-h02)-mu_q)/sigma2_q+
    log(b2)-log(hs-h02)-0.5*log(sigma2_q);
  double contrib_hs=0.0;
  */
  double contrib_h01=0.0;
  double contrib_hs=log(b1)-log(2.0*M_PI*sigma2_q)-
    0.5*(a1+b1*log(hs-h01)-mu_q)*(a1+b1*log(hs-h01)-mu_q)/sigma2_q;
  double contrib_h02=//-0.5*(h02-h01-mu_h02)*(h02-h01-mu_h02)/sd_h02/sd_h02;
    -ABSVAL((h02-h01-mu_h02))*sqrt(2.0)/sd_h02;

  if(h01_m!=MISSING_VALUE && h01_s2!=MISSING_VALUE)
    contrib_h01=-0.5*(h01-h01_m)*(h01-h01_m)/h01_s2;
  if(h02_m!=MISSING_VALUE && h02_s2!=MISSING_VALUE)
    contrib_h02=-0.5*(h02-h02_m)*(h02-h02_m)/h02_s2;
  if(hs_m!=MISSING_VALUE && hs_s2!=MISSING_VALUE)
    contrib_hs=-0.5*(hs-hs_m)*(hs-hs_m)/hs_s2;


  // contribution from (sigma�)^-(a+2+n/2)*exp(-b/sigma�)
  double contrib_s2 = - (sigma_a+1.0)*log(s2) - sigma_b/s2;
  
  double SS=0.0;
  // contribution from the exponensial data part of the likelihood function;
  for(i=0;i<len;i++)
    if(B1(h[i],hs,h01)==MISSING_VALUE || B2(h[i],hs,h02)==MISSING_VALUE)
      return -1e+216;
    else
      SS+=(q[i]-a1-b1*B1(h[i],hs,h01)-b2*B2(h[i],hs,h02))*
	(q[i]-a1-b1*B1(h[i],hs,h01)-b2*B2(h[i],hs,h02));
  
  double ret = contrib_pri_beta +contrib_s2 +contrib_h01+contrib_h02 +contrib_hs 
    -0.5*n*log(s2)-SS/2.0/s2;

  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;

  return ret/T;
}

void draw_parameters(double *stage, double *discharge, 
		     int number_of_measurements, 
		     // measurements
		     
		     // output:
		     double **sampled_a1,
		     double **sampled_b1,
		     double **sampled_b2,
		     double **sampled_hs,
		     double **sampled_h01,
		     double **sampled_h02,
		     double **sampled_s2,
		     double **sampled_psi,

		     // Optional input::
		     
		     int num_sim, 
		     // number of drawings
		     
		     // prior knowledge:
		     double est_exp, 
		     double sdev_exp, 
		     double est_logconst, 
		     double sdev_logconst,
		     double corr,
		     double sigma_a, 
		     double sigma_b, 
		     //double h01_mean, double h01_sdev,
		     //double h02_mean, double h02_sdev,
		     //double hs_mean, double hs_sdev,
		     double mu_q, double sd_q,
		     double mu_h02, double sd_h02,
		     
		     int indep, 
		     /* spacing between drawings */
		     
		     int burnin, 
		     /* burn-in length */
		     int num_temp,

		     /* RW metropolis steps: */
		     double sd_a, double sd_b, double sd_h, double sd_s2
		     )
{
  int i;

  // Store the measurements:
  int num_meas=number_of_measurements;
  double *q=new double[num_meas];
  double *h=new double[num_meas];
  for(i=0;i<num_meas;i++)
    {
      q[i]=log(discharge[i]);
      h[i]=stage[i];
    }    
  
  double *m=new double[3];
  double minh=find_statistics(h,num_meas,MIN);
  double maxh=find_statistics(h,num_meas,MAX);
  double *T=new double[num_temp];
  double *prev_logprob=new double[num_temp];

  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  
  double **var=new double*[3];
  var[0]=new double[3];
  var[1]=new double[3];
  var[2]=new double[3];
  m[0]=est_logconst;
  m[1]=est_exp;
  m[2]=est_exp;
  var[0][0]=sdev_logconst*sdev_logconst;
  var[1][1]=var[2][2]=sdev_exp*sdev_exp;
  var[0][1]=corr*sdev_logconst*sdev_exp;
  var[0][2]=corr*sdev_logconst*sdev_exp;
  var[1][0]=corr*sdev_logconst*sdev_exp;
  var[2][0]=corr*sdev_logconst*sdev_exp;
  var[2][1]=corr*corr*sdev_exp*sdev_exp;
  var[1][2]=corr*corr*sdev_exp*sdev_exp;
  double **inv_var=inverse_matrix(var,3);


  double *a1=new double[num_sim];
  double *b1=new double[num_sim];
  double *b2=new double[num_sim];
  double *hs=new double[num_sim];
  double *h01=new double[num_sim];
  double *h02=new double[num_sim];
  double *s2=new double[num_sim];
  double *psi=new double[num_sim];
  
  double *prev_a1=new double[num_temp], *prev_b1=new double[num_temp], 
    *prev_b2=new double[num_temp], *prev_h01=new double[num_temp], 
    *prev_h02=new double[num_temp], *prev_hs=new double[num_temp],
    *prev_s2=new double[num_temp];

  int t;
  int *numswaps=new int[num_temp-1];
  // First sample;
  for(t=0;t<num_temp;t++)
    {
      if(t==0)
	T[t]=1.0;
      else
	T[t]=2.0*T[t-1];
      if(t<num_temp-1)
	numswaps[t]=0; 

      prev_a1[t]=est_logconst+gsl_ran_gaussian(rptr, sdev_logconst);
      prev_b1[t]=est_exp;//+gsl_ran_gaussian(rptr, sdev_exp);
      prev_b2[t]=est_exp;//+gsl_ran_gaussian(rptr, sdev_exp);
      prev_h01[t]=minh-drand48();
      prev_h02[t]=minh-drand48();
      prev_hs[t]=minh+drand48()*(maxh-minh);
      prev_s2[t]=sigma_a>0.0 ? 1.0/gsl_ran_gamma(rptr,sigma_a,1.0/sigma_b) :
	1.0e+5*drand48();
      
      prev_logprob[t]=logprob(q,h,num_meas,minh,maxh,
			      prev_a1[t],prev_b1[t],prev_b2[t],prev_hs[t],
			      prev_h01[t],prev_h02[t],prev_s2[t],
			      inv_var,est_logconst,est_exp,est_exp,
			      mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
    }

  double acc_a=0.0, acc_b=0.0, acc_h=0.0, acc_s2=0.0;
  
  for(i=1;i<=num_sim*indep+burnin;i++)
    {
      if(drand48()<0.1 && num_temp>1)
	{
	  int t=(int) floor(drand48()*double(num_temp-1));

	  double new_logprob1=
	    logprob(q,h,num_meas,minh,maxh,prev_a1[t+1],prev_b1[t+1],prev_b2[t+1],
		    prev_hs[t+1],prev_h01[t+1], prev_h02[t+1],prev_s2[t+1],
		    inv_var,est_logconst,est_exp,est_exp,
		    mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	  double new_logprob2=
	    logprob(q,h,num_meas,minh,maxh,prev_a1[t],prev_b1[t],prev_b2[t],
		    prev_hs[t],prev_h01[t], prev_h02[t],prev_s2[t],
		    inv_var,est_logconst,est_exp,est_exp,
		    mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t+1]);

	  // swap parameters between distribution t and distribution t+1
	  if(log(drand48())< new_logprob1+new_logprob2-prev_logprob[t]-prev_logprob[t+1])
	    {
	      //cout << "Swap: " << t+1 << " vs " << t+2 << endl; 
	      numswaps[t]++;

	      double a1_buff=prev_a1[t],b1_buff=prev_b1[t],b2_buff=prev_b2[t],
		hs_buff=prev_hs[t],h01_buff=prev_h01[t],h02_buff=prev_h02[t],
		s2_buff=prev_s2[t];

	      prev_a1[t]=prev_a1[t+1];
	      prev_b1[t]=prev_b1[t+1];
	      prev_b2[t]=prev_b2[t+1];
	      prev_hs[t]=prev_hs[t+1];
	      prev_h01[t]=prev_h01[t+1];
	      prev_h02[t]=prev_h02[t+1];
	      prev_s2[t]=prev_s2[t+1];
	      prev_logprob[t]=new_logprob1;

	      prev_a1[t+1]=a1_buff;
	      prev_b1[t+1]=b1_buff;
	      prev_b2[t+1]=b2_buff;
	      prev_hs[t+1]=hs_buff;
	      prev_h01[t+1]=h01_buff;
	      prev_h02[t+1]=h02_buff;
	      prev_s2[t+1]=s2_buff;
	      prev_logprob[t+1]=new_logprob2;
	    }
	}
      else // parallell MCMC
	for(t=0;t<num_temp;t++)
	  {
	    double steptype=T[t];
	    double r=drand48();
	    if(r<0.1)
	      steptype/=10.0;
	    else if(r<0.2)
	      steptype/=300.0;
	    else if(r<0.3)
	      steptype/=10000.0;
	    else if(r<0.4)
	      steptype*=10.0;
	    else if(r<0.5)
	      steptype*=100.0;

	    double new_a1=prev_a1[t]+gsl_ran_gaussian(rptr,sd_a)*steptype;
	    double new_b1=prev_b1[t]+gsl_ran_gaussian(rptr,sd_b)*steptype;
	    double new_b2=prev_b2[t]+gsl_ran_gaussian(rptr,sd_b)*steptype;
	    double new_hs=prev_hs[t]+gsl_ran_gaussian(rptr,sd_h)*steptype;
	    double new_h01=prev_h01[t]+gsl_ran_gaussian(rptr,sd_h)*steptype;
	    double new_h02=prev_h02[t]+gsl_ran_gaussian(rptr,sd_h)*steptype;
	    double new_s2=prev_s2[t]+gsl_ran_gaussian(rptr,sd_s2)*steptype;
	    double new_logprob;
	    
	    /*
	    if(burnin>1000 && i<burnin/2 && i%100==0 && t==0)
	      {
		acc_a/=double(100);
		acc_b/=double(2*100);
		acc_h/=double(3*100);
		acc_s2/=double(100);
		sd_a*=exp((acc_a-0.25)*2.0);
		sd_b*=exp((acc_b-0.25)*2.0);
		sd_h*=exp((acc_h-0.25)*2.0);
		sd_s2*=exp((acc_s2-0.25)*2.0);
		acc_a=acc_b=acc_h=acc_s2=0.0;
	      }
	    */
	    
	    // Update a1:
	    new_logprob=logprob(q,h,num_meas,minh,maxh,new_a1,prev_b1[t],prev_b2[t],
				prev_hs[t],prev_h01[t], prev_h02[t],prev_s2[t],
				inv_var,est_logconst,est_exp,est_exp,
				mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_a1[t]=new_a1;
		prev_logprob[t]=new_logprob;
		acc_a++;
	      }
	    
	    // Update b1:
	    new_logprob=logprob(q,h,num_meas,minh,maxh,prev_a1[t],new_b1,prev_b2[t],
				prev_hs[t],prev_h01[t], prev_h02[t],prev_s2[t],
				inv_var,est_logconst,est_exp,est_exp,
				mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_b1[t]=new_b1;
		prev_logprob[t]=new_logprob;
		acc_b++;
	      }
	    
	    // Update b2[t]:
	    new_logprob=logprob(q,h,num_meas,minh,maxh,prev_a1[t],prev_b1[t],new_b2,
				prev_hs[t],prev_h01[t], prev_h02[t],prev_s2[t],
				inv_var,est_logconst,est_exp,est_exp,
				mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_b2[t]=new_b2;
		prev_logprob[t]=new_logprob;
		acc_b++;
	      }
	    
	    // Update hs:
	    new_logprob=logprob(q,h,num_meas,minh,maxh,prev_a1[t],prev_b1[t],
				prev_b2[t],new_hs,prev_h01[t], prev_h02[t],prev_s2[t],
				inv_var,est_logconst,est_exp,est_exp,
				mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_hs[t]=new_hs;
		prev_logprob[t]=new_logprob;
		acc_h++;
	      }
	    
	    // Update h01[t]:
	    new_logprob=logprob(q,h,num_meas,minh,maxh,prev_a1[t],prev_b1[t],
				prev_b2[t],prev_hs[t],new_h01, prev_h02[t],prev_s2[t],
				inv_var,est_logconst,est_exp,est_exp,
				mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_h01[t]=new_h01;
		prev_logprob[t]=new_logprob;
		acc_h++;
	      }
	    
	    // Update h02:
	    new_logprob=logprob(q,h,num_meas,minh,maxh,prev_a1[t],prev_b1[t],
				prev_b2[t],prev_hs[t], prev_h01[t], new_h02,prev_s2[t],
				inv_var,est_logconst,est_exp,est_exp,
				mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_h02[t]=new_h02;
		prev_logprob[t]=new_logprob;
		acc_h++;
	      }

	    // Update s2:
	    new_logprob=logprob(q,h,num_meas,minh,maxh,prev_a1[t],prev_b1[t],prev_b2[t],
				prev_hs[t],prev_h01[t], prev_h02[t], new_s2,
				inv_var,est_logconst,est_exp,est_exp,
				mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_s2[t]=new_s2;
		prev_logprob[t]=new_logprob;
		acc_s2++;
	      }
	  }

      if(i%1000==0)
	cout << i << " " << prev_a1[0] << " " << prev_b1[0] << " " << prev_b2[0] << 
	  " " << prev_hs[0] << " "  << prev_h01[0] << " " << prev_h02[0] << " " << 
	  prev_s2[0] << " " << prev_logprob[0] << endl;

      if(i>burnin && (i-burnin)%indep==0)
	{
	  a1[(i-burnin)/indep-1]=prev_a1[0];
	  b1[(i-burnin)/indep-1]=prev_b1[0];
	  b2[(i-burnin)/indep-1]=prev_b2[0];
	  hs[(i-burnin)/indep-1]=prev_hs[0];
	  h01[(i-burnin)/indep-1]=prev_h01[0];
	  h02[(i-burnin)/indep-1]=prev_h02[0];
	  s2[(i-burnin)/indep-1]=prev_s2[0];
	  psi[(i-burnin)/indep-1]=prev_logprob[0];
	}
    }

  for(t=0;t<num_temp-1;t++)
    cout << "Number of swaps from " << t+1 << " to " << t+2 << " : " << numswaps[t] << 
      endl;
  cout << "acc a:" << acc_a/double(num_sim*indep)*100.0 << "%" << endl;
  cout << "acc b:" << acc_b/double(2*num_sim*indep)*100.0 << "%" << endl;
  cout << "acc h:" << acc_h/double(3*num_sim*indep)*100.0 << "%" << endl;
  cout << "acc s2:" << acc_s2/double(num_sim*indep)*100.0 << "%" << endl;

  *sampled_a1=a1;
  *sampled_b1=b1;
  *sampled_b2=b2;
  *sampled_hs=hs;
  *sampled_h01=h01;
  *sampled_h02=h02;
  *sampled_s2=s2;
  *sampled_psi=psi;

  delete [] m;
  doubledelete(var,3);
  doubledelete(inv_var,3);  
}

void usage(void)
{
  cout << "Usage: 2seg <input file> <number of simulations> <burnin> <indep> "
    "<num temp>" << endl;
  exit(0);
}

double get_Q(double h, double a1, double b1, double b2, double hs, 
	     double h01, double h02)
{
  double Q=0.0;
  if(h<hs && h>h01)
    Q=exp(a1)*pow(h-h01, b1);
  else if(h>hs && h>h02)
    {
      double a2=a1+b1*log(hs-h01)-b2*log(hs-h02);
      Q=exp(a2)*pow(h-h02, b2);
    }

  return Q;
}

int main(int argc, char **argv)
{
  if(argc!=6)
    usage();
 
  randify();

  // Fetch the data file;
  int i,j,len, N=atoi(argv[2]);
  char errmsg[1000];
  StageDischarge *data=get_sd_file(argv[1], &len, errmsg);
  /*double sd_a=atof(argv[3]);
  double sd_b=atof(argv[4]);
  double sd_h=atof(argv[5]);
  double sd_s2=atof(argv[6]);*/
  int burnin=atoi(argv[3]);
  int indep=atoi(argv[4]);
  int numtemp=atoi(argv[5]);
  

  if(len<=0 || !data) // test if there's an error reading data
    {
      cout << errmsg << endl;
      exit(0);
    }
   
  double *q=new double[len], *h=new double[len];
  for(i=0;i<len;i++)
    {
      q[i]=data[i].q;
      h[i]=data[i].h;
      // cout << h[i] << " " << q[i] << endl;
    }
  
  double *a1,*b1,*b2,*hs,*h01,*h02,*s2,*psi;
  draw_parameters(h,q,len,&a1,&b1,&b2,&hs,&h01,&h02,&s2,&psi,N,
		  2.46,0.92, 2.84,1.38, -0.42, 1.356, 0.00176, 
		  1.8, 2.35, 0.264, 0.683, // default
		  //2.46,0.92, 2.84,1.38, -0.42, 0.0, 0.0, 
		  //1.8, 2.35, 0.0, 2.0, // wide hs
		  //2.46,2.0, 2.84,3.0, -0.42, 0.0,0.0,
		  //1.8, 3.0, 0.0, 2.0, // wide hs,h02
		  //2.46,0.92, 2.84, 1.38, -0.42, 0.0, 0.0, 
		  //10.0, 0.4, 0.0, 10.0, // corrientes
		  indep, burnin, numtemp, 0.1, 0.1, 0.1, 0.01); 

  double rho_a1=get_auto_correlation(a1, N);

  double spacing_a1=2.0*(0.5+rho_a1/(1.0-rho_a1));
  cout << "a1 - spacing between independent samples:" << spacing_a1 << endl;

  FILE *p;

  double med_a1=find_statistics(a1, N, MEDIAN);
  double med_b1=find_statistics(b1, N, MEDIAN);
  double med_b2=find_statistics(b2, N, MEDIAN);
  double med_hs=find_statistics(hs, N, MEDIAN);
  double med_h01=find_statistics(h01, N, MEDIAN);
  double med_h02=find_statistics(h02, N, MEDIAN);
  double med_s=sqrt(find_statistics(s2, N, MEDIAN));
  double min_h=find_statistics(h01, N, MIN);
  double max_h=find_statistics(h, len, MAX);

  p=popen("vvgraph -x m -y \"m^3/s\"","w");
  fprintf(p,"# Column 1: median(Q(h))\n");
  fprintf(p,"# Column 2: Q(h) (med.par: a1=%5.3f b1=%5.3f b2=%5.3f hs=%5.3f "
	  "h01=%5.3f h02=%5.3f s=%5.3f)\n", med_a1, med_b1, med_b2, med_hs,
	  med_h01, med_h02, med_s);
  fprintf(p,"# Column 3: lower limit for 95%% credibility\n");
  fprintf(p,"# Column 4: upper limit for 95%% credibility\n");
  fprintf(p,"# Column 5: measurements\n");
  fprintf(p,"# Column 5 - type: dot\n");
  fprintf(p,"###################\n");
  double *Q=new double[N],x;
  for(x=min_h;x<max_h+1.0;x+=0.005)
    {
      for(i=0;i<N;i++)
	Q[i]=get_Q(x,a1[i],b1[i],b2[i],hs[i],h01[i],h02[i]);
      
      double Q_med=find_statistics(Q,N,MEDIAN);
      double Q_par=get_Q(x, med_a1, med_b1, med_b2, med_hs, med_h01, med_h02);
      double lower=find_statistics(Q,N,PERCENTILE_2_5);
      double upper=find_statistics(Q,N,PERCENTILE_97_5);
      
      fprintf(p, "%f %f %f %f %f -10000000\n", x, Q_med, Q_par, lower, upper);
    }
  delete [] Q;
  for(j=0;j<len;j++)
    fprintf(p, "%f -10000000 -10000000 -10000000 -10000000 %f\n", h[j], q[j]);
  
  pclose(p);


  p=popen("vvgraph -x a1","w");
  fprintf(p,"# Column 1: a1\n");
  fprintf(p,"###################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%d %f\n", i+1, a1[i]);
  pclose(p);

  p=popen("histogramme","w");
  for(i=0;i<N;i++)
    fprintf(p,"%f\n", a1[i]);
  pclose(p);

  double rho_b1=get_auto_correlation(b1, N);

  double spacing_b1=2.0*(0.5+rho_b1/(1.0-rho_b1));
  cout << "b1 - spacing between independent samples:" << spacing_b1 << endl;

  p=popen("vvgraph","w");
  fprintf(p,"# Column 1: b1\n");
  fprintf(p,"###################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%d %f\n", i+1, b1[i]);
  pclose(p);

  p=popen("histogramme","w");
  for(i=0;i<N;i++)
    fprintf(p,"%f\n", b1[i]);
  pclose(p);

  
  double rho_b2=get_auto_correlation(b2, N);

  double spacing_b2=2.0*(0.5+rho_b2/(1.0-rho_b2));
  cout << "b2 - spacing between independent samples:" << spacing_b2 << endl;

  p=popen("vvgraph","w");
  fprintf(p,"# Column 1: b2\n");
  fprintf(p,"###################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%d %f\n", i+1, b2[i]);
  pclose(p);

  p=popen("histogramme","w");
  for(i=0;i<N;i++)
    fprintf(p,"%f\n", b2[i]);
  pclose(p);

  
  double rho_hs=get_auto_correlation(hs, N);

  double spacing_hs=2.0*(0.5+rho_hs/(1.0-rho_hs));
  cout << "hs - spacing between independent samples:" << spacing_hs << endl;

  p=popen("vvgraph","w");
  fprintf(p,"# Column 1: hs\n");
  fprintf(p,"###################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%d %f\n", i+1, hs[i]);
  pclose(p);

  p=popen("histogramme","w");
  for(i=0;i<N;i++)
    fprintf(p,"%f\n", hs[i]);
  pclose(p);

  double rho_h01=get_auto_correlation(h01, N);

  double spacing_h01=2.0*(0.5+rho_h01/(1.0-rho_h01));
  cout << "h01 - spacing between independent samples:" << spacing_h01 << endl;

  p=popen("vvgraph","w");
  fprintf(p,"# Column 1: h01\n");
  fprintf(p,"###################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%d %f\n", i+1, h01[i]);
  pclose(p);

  p=popen("histogramme","w");
  for(i=0;i<N;i++)
    fprintf(p,"%f\n", h01[i]);
  pclose(p);
  
  double rho_h02=get_auto_correlation(h02, N);

  double spacing_h02=2.0*(0.5+rho_h02/(1.0-rho_h02));
  cout << "h02 - spacing between independent samples:" << spacing_h02 << endl;

  p=popen("vvgraph","w");
  fprintf(p,"# Column 1: h02\n");
  fprintf(p,"###################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%d %f\n", i+1, h02[i]);
  pclose(p);

  p=popen("histogramme","w");
  for(i=0;i<N;i++)
    fprintf(p,"%f\n", h02[i]);
  pclose(p);

  double rho_s2=get_auto_correlation(s2, N);

  double spacing_s2=2.0*(0.5+rho_s2/(1.0-rho_s2));
  cout << "s2 - spacing between independent samples:" << spacing_s2 << endl;

  p=popen("vvgraph","w");
  fprintf(p,"# Column 1: s\n");
  fprintf(p,"###################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%d %f\n", i+1, sqrt(s2[i]));
  pclose(p);

  p=popen("histogramme","w");
  for(i=0;i<N;i++)
    fprintf(p,"%f\n", sqrt(s2[i]));
  pclose(p);



  
  p=popen("vvgraph -x a1 -y b1","w");
  fprintf(p, "# Column 1: a1 vs b1\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", a1[i], b1[i]);
  pclose(p);

  p=popen("vvgraph -x a1 -y b2","w");
  fprintf(p, "# Column 1: a1 vs b2\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", a1[i], b2[i]);
  pclose(p);

  p=popen("vvgraph -x a1 -y hs","w");
  fprintf(p, "# Column 1: a1 vs hs\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", a1[i], hs[i]);
  pclose(p);

  p=popen("vvgraph -x a1 -y h01","w");
  fprintf(p, "# Column 1: a1 vs h01\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", a1[i], h01[i]);
  pclose(p);

  p=popen("vvgraph -x a1 -y h02","w");
  fprintf(p, "# Column 1: a1 vs h02\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", a1[i], h02[i]);
  pclose(p);

  p=popen("vvgraph -x a1 -y s","w");
  fprintf(p, "# Column 1: a1 vs s\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", a1[i], sqrt(s2[i]));
  pclose(p);

  p=popen("vvgraph -x b1 -y b2","w");
  fprintf(p, "# Column 1: b1 vs b2\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b1[i], b2[i]);
  pclose(p);

  p=popen("vvgraph -x b1 -y hs","w");
  fprintf(p, "# Column 1: b1 vs hs\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b1[i], hs[i]);
  pclose(p);

  p=popen("vvgraph -x b1 -y h01","w");
  fprintf(p, "# Column 1: b1 vs h01\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b1[i], h01[i]);
  pclose(p);

  p=popen("vvgraph -x b1 -y h02","w");
  fprintf(p, "# Column 1: b1 vs h02\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b1[i], h02[i]);
  pclose(p);

  p=popen("vvgraph -x b1 -y s","w");
  fprintf(p, "# Column 1: b1 vs s\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b1[i], sqrt(s2[i]));
  pclose(p);

  p=popen("vvgraph -x b2 -y hs","w");
  fprintf(p, "# Column 1: b2 vs hs\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b2[i], hs[i]);
  pclose(p);

  p=popen("vvgraph -x b2 -y h01","w");
  fprintf(p, "# Column 1: b2 vs h01\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b2[i], h01[i]);
  pclose(p);

  p=popen("vvgraph -x b2 -y h02","w");
  fprintf(p, "# Column 1: b2 vs h02\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b2[i], h02[i]);
  pclose(p);

  p=popen("vvgraph -x b2 -y s","w");
  fprintf(p, "# Column 1: b2 vs s\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", b2[i], sqrt(s2[i]));
  pclose(p);

  p=popen("vvgraph -x hs -y h01","w");
  fprintf(p, "# Column 1: hs vs h01\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", hs[i], h01[i]);
  pclose(p);

  p=popen("vvgraph -x hs -y h02","w");
  fprintf(p, "# Column 1: hs vs h02\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", hs[i], h02[i]);
  pclose(p);

  p=popen("vvgraph -x hs -y s","w");
  fprintf(p, "# Column 1: hs vs s\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", hs[i], sqrt(s2[i]));
  pclose(p);

  p=popen("vvgraph -x h01 -y h02","w");
  fprintf(p, "# Column 1: h01 vs h02\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", h01[i], h02[i]);
  pclose(p);

  p=popen("vvgraph -x h01 -y s","w");
  fprintf(p, "# Column 1: h01 vs s\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", h01[i], sqrt(s2[i]));
  pclose(p);

  p=popen("vvgraph -x h02 -y s","w");
  fprintf(p, "# Column 1: h02 vs s\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<N;i++)
    fprintf(p,"%f %f\n", h02[i], sqrt(s2[i]));
  pclose(p);

}





