#include "bayes_file_ratingcurve.H"
#include <hydrasub/hydrabase/regression.H>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <cmath>

void bayes_ratingcurve_button::Create(widget parent, char *txt, 
			       BAYES_RATINGCURVE_ACTION buttontype,
			       bayes_ratingcurve *ipt)
{
  associated_action=buttontype;
  pt=ipt;
  build(parent, txt);
}

void bayes_ratingcurve_button::pushed(void)
{
  pt->take_action(associated_action);
}

void bayes_stage_vs_discharge::Create(widget parent, bayes_ratingcurve *ipt)
{
  char *items[]={WHAT((char *) "x=vannstand, y=vannf�ring", 
		      (char *) "x=stage, y=discharge"), 
		 WHAT((char *) "x=vannf�ring, y=vannstand", 
		      (char *) "x=discharge, y=stage")};
  pt=NULL;
  hbuild(parent, items, 2, 0);
  pt=ipt;
}

void bayes_stage_vs_discharge::pushed(char *item)
{
  if(pt)
    pt->stage_vs_discharge_changed((*this)() ? False : True);
}

void bayes_fetchfile::Create(bayes_ratingcurve *ipt)
{
  pt=ipt;
  sh.build(*ipt, WHAT((char *) "Hent fil", (char *) "Fetch file"));
  v1.build(sh);
  build(v1);
  sh.Map();
}

void bayes_fetchfile::ok(char *filename)
{
  if(pt->fetchfile(filename))
    sh.Unmap();
}

void bayes_fetchfile::cancel(void)
{
  sh.Unmap();
}

void bayes_noninfo_toggle::Create(widget parent,  
				  bayes_ratingcurve *ipt)
{
  char *txt[]={WHAT((char *) "Ikke-informativ lokasjonsparameter",
		    (char *) "Non-informative location parameter"),
	       WHAT((char *) "Informativ skala-start, ikke-informativ "
		    "skala-parameter",
		    (char *) "Informative scale start, non-informative "
		    "scale parameter"),
	       WHAT((char *) "Informativ normalfordeling",
		    (char *) "Informative normal distribution")};
  pt=NULL;
  hbuild(parent, txt, 3, 0);
  pt=ipt;
}

void bayes_noninfo_toggle::pushed(char *item)
{
  if(pt)
    pt->noninfo_state_changed((*this)());
}


double wanted_min, wanted_max, wanted_cred;
double sqrerr(double a, double b)
{
  /*
  double start=gsl_cdf_gamma_Pinv(0.025, a, 1.0/b);
  double end=gsl_cdf_gamma_Pinv(0.975, a, 1.0/b);
  
  double ret=(start-wanted_min)*(start-wanted_min)+
    (end-wanted_max)*(end-wanted_max);
  */

  double ptail=(1.0-wanted_cred)/2.0;
  double this_p1=gsl_cdf_gamma_P(wanted_min, a, 1.0/b);
  double this_p2=1.0-gsl_cdf_gamma_P(wanted_max,a, 1.0/b);
  double ret=(ptail-this_p1)*(ptail-this_p1)+(ptail-this_p2)*(ptail-this_p2);
  
  return ret;
}

void bayes_ratingcurve::plot_invgamma_search(void)
{
  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();

  wanted_min=1.0/sigma_2/sigma_2;
  wanted_max=1.0/sigma_1/sigma_1;
  wanted_cred=0.95;

  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(sqrerr, 0.01, 0.0001, 10.0, 0.2, "a", "b");
}

void bayes_ratingcurve::plot_sigma(void)
{
  double a,b;
  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();
  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=sigma_2*2.0, step=size/double(len),sigma=step;
  int axis=1;
  
  find_invgamma_distribution(sigma_1*sigma_1, sigma_2*sigma_2, 
			     95.0, &a, &b);
  
  sprintf(line, WHAT((char *) "Fordeling til sigma n�r sigma^2 ~ "
		     "IG(a=%7.3f, b=%7.5g)", 
		     (char *) "Distribution of sigma when sigma^2 ~ "
		     "IG(a=%7.3f, b=%7.3g)"), a, b);
  axislab[0]=new char[10];
  strcpy(axislab[0], "sigma");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(int i=0;i<len;i++, sigma+=step)
    {
      double logf=log(2.0)+a*log(b)-gamma(a)-(2.0*a+1.0)*log(sigma)-
	b/sigma/sigma;
      
      arg[i]=sigma;
      val[i]=exp(logf);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void bayes_ratingcurve::plot_exp(void)
{
  int i, len=1000, axis=1;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[200], **axislab=new char*[2];
  double exp1=startexpf.getdouble(), exp2=endexpf.getdouble();
  double m,v;
  double size=(exp2+1.0)*2.0, step=size/double(len), x=-1.0;
  
  m=(exp1+exp2)/2.0;
  v=(exp2-exp1)/2.0/1.96;
  
  sprintf(line, WHAT((char *) "Fordeling til eksponent ~ "
		     "N(m=%7.3f, std=%7.5g)",
		     (char *) "Distribution of the exponent ~ "
		     "N(m=%7.3f, std=%7.5g)"), m, v);
  axislab[0]=new char[10];
  strcpy(axislab[0], "b");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");
  
  for(i=0;i<len;i++, x+=step)
    {
      arg[i]=x;
      val[i]=1.0/sqrt(2.0*M_PI)/v*exp(-0.5*(x-m)*(x-m)/v/v); 
      // normal distribution
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);
  
  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void bayes_ratingcurve::plot_const(void)
{
  int i, len=1000, axis=1;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[200], **axislab=new char*[2];
  double const1=log(startconstf.getdouble()), 
    const2=log(endconstf.getdouble());
  double m,v;
  double size=2.0*exp(const2), step=size/double(len), x=step;

  m=(const1+const2)/2.0;
  v=(const2-const1)/2.0/1.96;

  sprintf(line, WHAT((char *) "Fordeling til const n�r log(const) ~ "
		     "N(m=%7.3f, std=%7.5g)", 
		     (char *) "Distribution of constant when log(const) ~ "
		     "N(m=%7.3f, std=%7.5g)"), m, v);
  axislab[0]=new char[10];
  strcpy(axislab[0], "const");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(i=0;i<len;i++, x+=step)
    {
      arg[i]=x;
      val[i]=1.0/sqrt(2.0*M_PI)/v/x*exp(-0.5*(log(x)-m)*(log(x)-m)/v/v);
    }

  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);
  
  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void bayes_ratingcurve::plot_h0(void) 
{
  int i, len=1000, axis=1;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[200], **axislab=new char*[2];
  double h01=starth0f.getdouble(), h02=endh0f.getdouble();
  double m=0.5*(h01+h02);
  double v=(h02-h01)/2.0/1.96;
  
  if(!*starth0f() || !*endh0f())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Begge bunnstandandsgrensene m� v�re "
		     "utfylt\nfor at en skal ha en informativ fordeling!",
		     (char *) "Both bottom stage limits must be given!"));
      return;
    }
  
  double size=(h02-h01+1.0)*2.0, step=size/double(len-1), 
    h0start=h01-0.5*(h02-h01)-1.0, x=h0start;
  
  sprintf(line, WHAT((char *) "Fordeling til H0~N(m=%7.3g, std=%7.3g) ",
		     (char *) "Distribution of H0~N(m=%7.3g, std=%7.3g)"),m,v);
  axislab[0]=new char[10];
  strcpy(axislab[0], "h0");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(i=0;i<len;i++, x+=step)
    {
      arg[i]=x;
      val[i]=1.0/sqrt(2.0*M_PI)/v*exp(-0.5*(x-m)*(x-m)/v/v);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2, NULL);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}



void bayes_ratingcurve::generate(void)
{
  if(sdlen<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Inget datasett hentet!",
		     (char *) "No dataset fetched!"));
      return;
    }

  // Fetch prior quantiles:
  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();
  double corr=corrf.getdouble();
  double upperstage=stageendf.getdouble();
  double exp1=startexpf.getdouble(), exp2=endexpf.getdouble();
  double const1=log(startconstf.getdouble()), 
    const2=log(endconstf.getdouble());
  double c_1=-endh0f.getdouble(), c_2=-starth0f.getdouble(), 
    c_m=MISSING_VALUE, c_s=MISSING_VALUE;
  BAYES_RATINGCURVE_C_PRIOR c_priortype=(BAYES_RATINGCURVE_C_PRIOR) h0tog();
  double a,b,m1,v1,m2,v2;
  int i;

  // c prior given by the user?
  if(c_priortype==BAYES_RATINGCURVE_C_NORMAL)
    {
      if(!*starth0f() || !*endh0f())
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Begge bunnstandandsgrensene m� v�re "
			 "utfylt\nfor at en skal ha en informativ fordeling!",
			 (char *) "Both bottom stage limits must be given!"));
	  return;
	}

      // Set c prior info:
      c_m=(c_1+c_2)/2.0;
      c_s=(c_2-c_1)/2.0/1.96;
    }
  
  // set sigma^2-info:
  if(noninfo_sigma2())
    a=b=0.0;
  else
    find_invgamma_distribution(sigma_1*sigma_1, sigma_2*sigma_2, 
			       95.0, &a, &b);
  double d_a, d_b;
  find_invgamma_distribution(default_sigma_start*default_sigma_start, 
			     default_sigma_end*default_sigma_end, 
			     95.0, &d_a, &d_b);

  // Set the linear priors:
  m1=(exp1+exp2)/2.0;
  v1=(exp2-exp1)/2.0/1.96;
  m2=(const1+const2)/2.0;
  v2=(const2-const1)/2.0/1.96;

  double d_m1=(default_b_start+default_b_end)/2.0; 
  double d_v1=(default_b_end-default_b_start)/2.0/1.96;
  double d_m2=(log(default_const_start)+log(default_const_end))/2.0;
  double d_v2=(log(default_const_end)-log(default_const_start))/2.0/1.96;
  double d_m_h0=(default_h0_start+default_h0_end)/2.0; 
  double d_v_h0=(default_h0_end-default_h0_start)/2.0/1.96; 

  // Fetch the measurements:
  DateTime *dt=new DateTime[sdlen];
  double *h=new double[sdlen], *q=new double[sdlen];
  for(i=0;i<sdlen;i++)
    {
      h[i]=sd[i].h;
      q[i]=sd[i].q;
      dt[i]=sd[i].dt;
    }

  if(mcmccurve)
    delete mcmccurve;
  mcmccurve=new bayes_mcmc_curve();
  
  mcmccurve->create(h,q,sdlen,num_simf.getdigit(), m1, v1, m2, v2, corr, a, b, 
		    c_priortype, c_m, c_s, upperstage, x_stage, dt,
		    show_curve_mean(), show_curve_median(), 
		    show_par_mean(), show_par_median(),
		    show_credibility(), show_default_priors(), show_freq(),
		    d_m1, d_v1, d_m2, d_v2, d_a, d_b, d_m_h0, d_v_h0,
		    default_corr);

  delete [] h;
  delete [] q;
  delete [] dt;
}

void bayes_ratingcurve::stage_vs_discharge_changed(Boolean stage_vs_discharge)
{
  x_stage=stage_vs_discharge;
  if(sdlen>0)
    plot_measurements();
}

void bayes_ratingcurve::take_action(BAYES_RATINGCURVE_ACTION action)
{
  switch(action)
    {
    case BAYES_RATINGCURVE_FETCHFILE:
      ff.Create(this);
      break;
    case BAYES_RATINGCURVE_GENERATE:
      generate();
      break;
    case BAYES_RATINGCURVE_SHOW_PRIORS:
      sh.Map();
      break;
    case BAYES_RATINGCURVE_PLOT_SIGMA:
      plot_sigma();
      break;
    case BAYES_RATINGCURVE_PLOT_INVGAMMA:
      plot_invgamma_search();
      break;
    case BAYES_RATINGCURVE_PLOT_EXP: 
      plot_exp();
      break;
    case BAYES_RATINGCURVE_PLOT_CONST:
      plot_const();
      break;
    case BAYES_RATINGCURVE_PLOT_H0: 
      plot_h0();
      break;
    case BAYES_RATINGCURVE_RESTORE_DEFAULT:
      restore_default();
      break;
    case BAYES_RATINGCURVE_OPTIONS:
      optsh.Map();
      break;
    case BAYES_RATINGCURVE_EXIT:
      exit(0);
      break;
    default:
      err.build(*this, WHAT((char *) "Program-feil", 
			    (char *) "Program error"),
		WHAT((char *) "Ukjent handling", 
		     (char *) "Unknown action"));
      break;
    }
}

void bayes_ratingcurve::restore_default()
{
  noninfo_sigma2.ToggleButtonOff();
  startsigmaf.SetDouble(default_sigma_start, 4);
  endsigmaf.SetDouble(default_sigma_end, 4);
  startexpf.SetDouble(default_b_start, 5);
  endexpf.SetDouble(default_b_end, 5);
  startconstf.SetDouble(default_const_start, 5);
  endconstf.SetDouble(default_const_end, 5);
  corrf.SetDouble(default_corr, 4);
  h0tog.SetFocus(2);
  starth0f.SetDouble(default_h0_start, 4);
  endh0f.SetDouble(default_h0_end, 4);
  h5.Sensitive();
}

Boolean bayes_ratingcurve::fetchfile(char *filename)
{
  double zeropoint;
  char errmsg[1000];

  sd=get_sd_file(filename, &sdlen, errmsg, &zeropoint);  
  
  if(!sd || sdlen<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"), errmsg);
      return False;
    }
  
  restore_default();

  if(zeropoint!=MISSING_VALUE)
    {
      h0tog.SetFocus(2);
      h5.Sensitive();

      starth0f.SetDouble(zeropoint-0.1, 7);
      endh0f.SetDouble(zeropoint+0.1, 7);

      char message[400];
      sprintf(message, 
	      WHAT((char *) "Datasettet inneholdt et nullpunkt. F�r"
		   "kunnskap om nullpunktet er satt til %7.2f - %7.2f",
		   (char *) "The dataset containt a zeropoint. Prior "
		   "info about the zeropoint has been set to %7.2f - %7.2f."), 
	      zeropoint-0.1, zeropoint+0.1);
      mess.build(*this, WHAT((char *) "Melding", (char *) "Message"),
		 message);
    }
  
  plot_measurements();

  return True;
}

void bayes_ratingcurve::plot_measurements(void)
{
  double *arg=new double[sdlen], *val=new double[sdlen];
  char *linestr=new char[100], **axisstr=new char*[2];
  int i,axis=1;
  PLOTLINE_TYPE type=PLOTLINE_DOT;
  
  axisstr[0]=new char[100];
  axisstr[1]=new char[100];
  if(x_stage)
    {
      strcpy(axisstr[1], "Q");
      strcpy(axisstr[0], "h");
    }
  else
    {
      strcpy(axisstr[0], "Q");
      strcpy(axisstr[1], "h");
    }
    
  strcpy(linestr, WHAT((char *) "M�linger", (char *) "Measurements"));
  
  for(i=0;i<sdlen;i++)
    {
      arg[i]=sd[i].h;
      val[i]=sd[i].q;
    }
  
  double maxh=find_statistics(arg,sdlen,MAX);
  stageendf.SetDouble(maxh+1.0);
  
  if(x_stage)
    measurement_plot.Create(&arg, &val, &sdlen, &axis, &linestr, 1, 
			    axisstr, 2, NULL, &type);
  else
    measurement_plot.Create(&val, &arg, &sdlen, &axis, &linestr, 1, 
			    axisstr, 2, NULL, &type);
  measurement_plot.redraw();
  
  doubledelete(axisstr, 2);
  delete [] arg;
  delete [] val;
  delete [] linestr;
}

void bayes_ratingcurve::noninfo_state_changed(int state)
{
  if(state==2)
    h5.Sensitive();
  else
    h5.InSensitive();
}

bayes_ratingcurve::bayes_ratingcurve(int argc, char **argv) : 
  mainwin("bayes_file_ratingcurve",argc,argv)
{
  plot=NULL;
  mcmccurve=NULL;
  
  v0.build(*this);
  h0.build(v0);
  fetchb.Create(h0, WHAT((char *) "Hent fra fil", (char *) "Fetch from file"),
		BAYES_RATINGCURVE_FETCHFILE, this);
  fetchb.Background("green");
  fetchb.Foreground("black");
  stage_vs_discharge.Create(h0,this);

  measurement_plot.put_in_widget(v0,1000,600,PLOT_IN_WIDGET_SHOWMENUES);

  sh.build(*this, WHAT((char *) "Prior info - studying and changing", 
		       (char *) "F�rkunnskap - studering og forandring"));
  shv1.build(sh);
  fr1.build(shv1);
  v1.build(fr1);
  sigmalab.build(v1,WHAT((char *) "95%% sannsynlighet for at relativ st�y "
			 "ligger i f�lgende omr�de:",
			 (char *) "95%% probability that the relative noise "
			 "lies within the following interval:"));
  h1.build(v1);
  noninfo_sigma2.build(h1, WHAT((char *) "Ikke-informativ f�rkunnskap om "
				"st�yledd:", (char *) "non-informative prior "
				"on the noise part"));
  startsigmaf.build(h1, 10, WHAT((char *) "Start:", (char *) "Start:"));
  endsigmaf.build(h1,10, WHAT((char *) "Slutt:", (char *) "End:"));
  plotsigmab.Create(h1, WHAT((char *) "Plott fordelingen til sigma",
			     (char *) "Plot the distribution of sigma"),
		    BAYES_RATINGCURVE_PLOT_SIGMA, this);
  plotinvgammab.Create(h1, WHAT((char *) "Plott s�keflate for IG",
				(char *) "Plot the search area for IG"),
		       BAYES_RATINGCURVE_PLOT_INVGAMMA, this);
  
  fr2.build(shv1);
  v2.build(fr2);
  explab.build(v2, WHAT((char *) "95%% sannsynlighet for at eksponent "
			"ligger i f�lgende omr�de:",
			(char *) "95%% probability that the exponent "
			"lies in the following interval:"));
  h2.build(v2);
  startexpf.build(h2, 10, WHAT((char *) "Start:", (char *) "Start:"));
  endexpf.build(h2,10, WHAT((char *) "Slutt:", (char *) "End:"));
  plotexpb.Create(h2, WHAT((char *) "Plott fordelingen til eksponent",
			   (char *) "Plot the distribution of the exponent"),
		  BAYES_RATINGCURVE_PLOT_EXP, this);

  fr3.build(shv1);
  v3.build(fr3);
  constlab.build(v3, WHAT((char *) "95%% sannsynlighet for at konstant "
			  "ligger i f�lgende omr�de:",
			  (char *) "95%% probability that the constant "
			  "lies in the following interval:"));
  h3.build(v3);
  startconstf.build(h3, 10, WHAT((char *) "Start:", (char *) "Start:"));
  endconstf.build(h3,10, WHAT((char *) "Slutt:", (char *) "End:"));
  plotconstb.Create(h3, WHAT((char *) "Plott fordelingen til konstant",
			     (char *) "Plot the distribution of the "
			     "constant"),
		    BAYES_RATINGCURVE_PLOT_CONST, this);
  
  corrf.build(h3, 7, WHAT((char *) "Korrelasjon mellom eksponent og "
			  "log-konstant:", 
			  (char *) "Correlation between exponent and "
			  "log-constant:"));
  
  fr4.build(shv1);
  v5.build(fr4);
  h0tog.Create(v5, this);
  h5.build(v5);
  h0lab.build(h5, WHAT((char *) "95%% sannsynlighet for at bunnvannstanden "
		       "ligger i f�lgende omr�de:",
		       (char *) "95%% probability that the bottom stage "
		       "lies in the following interval:")); 
  starth0f.build(h5, 10, WHAT((char *) "Start:", (char *) "Start:"));
  endh0f.build(h5,10, WHAT((char *) "Slutt:", (char *) "End:"));
  ploth0b.Create(h5, WHAT((char *) "Plott fordelingen til bunnvannstanden",
			  (char *) "Plot the dist. of the bottom stage"),
		 BAYES_RATINGCURVE_PLOT_H0, this);


  default_sigma_start=0.02;
  default_sigma_end=0.15;
  default_b_start=2.46-0.92*1.96;
  default_b_end=2.46+0.92*1.96;
  default_const_start=exp(2.84-1.38*1.96);
  default_const_end=exp(2.84+1.38*1.96);
  default_corr=-0.42;
  default_h0_start=-2500.0;
  default_h0_end=2500.0;
  restore_default();


  h6.build(shv1);
  clsh.build(h6, &sh, WHAT((char *) "Close window", 
			   (char *) "Lukk vindu"));
  clsh.Background("red");
  clsh.Foreground("white");
  restore_default_b.Create(h6, WHAT((char *) "Standard-innstillinger", 
				    (char *) "Restore default"),
			   BAYES_RATINGCURVE_RESTORE_DEFAULT, this);
  
  sep1.build(v0);
  h4.build(v0);
  exitb.Create(h4, WHAT((char *) "Avslutt", (char *) "Quit"),
	       BAYES_RATINGCURVE_EXIT, this);
  exitb.Background("red");
  exitb.Foreground("white");
  generateb.Create(h4, WHAT((char *) "Generer kurve", 
			    (char *) "Generate curve"), 
		   BAYES_RATINGCURVE_GENERATE, this);
  generateb.Background("green");
  generateb.Foreground("black");
  optionsb.Create(h4, WHAT((char *) "Visnings-opsjoner", 
			   (char *) "Output options"), 
		  BAYES_RATINGCURVE_OPTIONS, this);
  stageendf.build(h4, 8, WHAT((char *) "�vre gyldighetsomr�de for vannstand:", 
			      (char *) "Upper limit for stage values:"));
  showpriorsb.Create(h4, WHAT((char *) "Vis f�rkunnskap", 
			      (char *) "Show prior info"), 
		     BAYES_RATINGCURVE_SHOW_PRIORS, this);
  showpriorsb.Background("yellow");
  showpriorsb.Foreground("black");

  optsh.build(*this, WHAT((char *) "Opsjoner", (char *) "Options"));
  optv1.build(optsh);
  opth1.build(optv1);

  show_curve_mean.build(opth1, WHAT((char *) "Vis forventet kurve", 
				    (char *) "Show expected curve"));
  show_curve_mean.ToggleButtonOn();

  show_curve_median.build(opth1, WHAT((char *) "Vis median kurve", 
				      (char *) "Show median curve"));
  show_curve_median.ToggleButtonOn();

  show_par_mean.build(opth1, WHAT((char *) "Vis kurve fra forv. parametre", 
				  (char *) "Show curve from "
				  "expected parameters"));
  show_par_mean.ToggleButtonOn();
  
  show_par_median.build(opth1, WHAT((char *) "Vis kurve fra median parametre",
				    (char *) "Show kurve from "
				    "median parameters"));
  show_par_median.ToggleButtonOn();

  opth2.build(optv1);
  show_credibility.build(opth2, WHAT((char *) "Vis troverdighetsintervall", 
				     (char *) "Show credibility interval"));
  show_credibility.ToggleButtonOn();
  show_default_priors.build(opth2, WHAT((char *) "Vis i tillegg resultater "
					"fra default-parametre", 
					(char *) "Show in addition "
					"results from default parameters"));
  show_default_priors.ToggleButtonOff();
  show_freq.build(opth2, WHAT((char *) "Vis frekventistisk estimat", 
			      (char *) "Show frequentist estimate"));
  show_freq.ToggleButtonOff();

  num_simf.build(opth2, 6, WHAT((char *) "Antall trekninger:", 
				(char *) "Number of samples:"));
  num_simf.SetDigit(10000);

  opth3.build(optv1);
  optcl.build(opth3, &optsh, WHAT((char *) "Close window", 
			   (char *) "Lukk vindu"));
}

int main(int argc, char **argv)
{
  randify();
  
  bayes_ratingcurve tp(argc, argv);
  tp.Run();
}
