#include "bayes_file_ratingcurve_old.H"
#include <hydrabase/regression.H>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <math.h>

void bayes_ratingcurve_button::Create(widget parent, char *txt, 
			       BAYES_RATINGCURVE_ACTION buttontype,
			       bayes_ratingcurve *ipt)
{
  associated_action=buttontype;
  pt=ipt;
  build(parent, txt);
}

void bayes_ratingcurve_button::pushed(void)
{
  pt->take_action(associated_action);
}

void bayes_stage_vs_discharge::Create(widget parent, bayes_ratingcurve *ipt)
{
  char *items[]={WHAT((char *) "x=vannstand, y=vannf�ring", 
		      (char *) "x=stage, y=discharge"), 
		 WHAT((char *) "x=vannf�ring, y=vannstand", 
		      (char *) "x=discharge, y=stage")};
  pt=NULL;
  hbuild(parent, items, 2, 0);
  pt=ipt;
}

void bayes_stage_vs_discharge::pushed(char *item)
{
  if(pt)
    pt->stage_vs_discharge_changed((*this)() ? False : True);
}

void bayes_fetchfile::Create(bayes_ratingcurve *ipt)
{
  pt=ipt;
  sh.build(*ipt, WHAT((char *) "Hent fil", (char *) "Fetch file"));
  v1.build(sh);
  build(v1);
  sh.Map();
}

void bayes_fetchfile::ok(char *filename)
{
  if(pt->fetchfile(filename))
    sh.Unmap();
}

void bayes_fetchfile::cancel(void)
{
  sh.Unmap();
}


void bayes_noninfo_toggle::Create(widget parent,  
				  bayes_ratingcurve *ipt)
{
  char *txt[]={WHAT((char *) "Ikke-informativ lokasjonsparameter",
		    (char *) "Non-informative location parameter"),
	       WHAT((char *) "Informativ skala, ikke-informativ "
		    "skala-parameter",
		    (char *) "Informative scale, non-informative "
		    "scale parameter"),
	       WHAT((char *) "Informativ normalfordeling",
		    (char *) "Informative normal distribution")};
  pt=NULL;
  hbuild(parent, txt, 3, 0);
  pt=ipt;
}

void bayes_noninfo_toggle::pushed(char *item)
{
  if(pt)
    pt->noninfo_state_changed((*this)());
}


double wanted_min, wanted_max;
double sqrerr(double a, double b)
{
  double start=gsl_cdf_gamma_Pinv(0.025, a, 1.0/b);
  double end=gsl_cdf_gamma_Pinv(0.975, a, 1.0/b);
  
  double ret=(start-wanted_min)*(start-wanted_min)+
    (end-wanted_max)*(end-wanted_max);
  
  return log(ret);
}

void bayes_ratingcurve::plot_invgamma_search(void)
{
  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();

  wanted_min=1.0/sigma_2/sigma_2;
  wanted_max=1.0/sigma_1/sigma_1;
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(sqrerr, 0.1, 0.0000001, 5.0, 0.04, "a", "1/b");
}

void bayes_ratingcurve::plot_sigma(void)
{
  double a,b;
  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();
  int len=1000;
  double *arg=new double[len], *val=new double[len];
  char *line=new char[100], **axislab=new char*[2];
  double size=sigma_2*sigma_2*4.0, step=size/double(len),sigma2=step;
  int axis=1;

  find_invgamma_distribution(sigma_1*sigma_1, sigma_2*sigma_2, 
			     95.0, &a, &b);

  sprintf(line, WHAT((char *) "Fordeling til sigma^2 ~ "
		     "IG(a=%7.3f, b=%7.5g)", 
		     (char *) "Distribution of sigma^2 ~ "
		     "IG(a=%7.3f, b=%7.3g)"), a, b);
  axislab[0]=new char[10];
  strcpy(axislab[0], "sigma^2");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(int i=0;i<len;i++, sigma2+=step)
    {
      double logf=a*log(b)-gamma(a)-(a+1.0)*log(sigma2)-b/sigma2;
      
      arg[i]=sigma2;
      val[i]=exp(logf);
    }
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(&arg, &val, &len, &axis, &line, 1, axislab, 2);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void bayes_ratingcurve::plot_exp(void)
{
  int i,numsample=100000;
  double a,b;
  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();
  int *len=new int[2], *axis=new int[2];
  double **arg=new double*[2], **val=new double*[2];
  char **line=new char*[2], **axislab=new char*[2];
  double exp1=startexpf.getdouble(), exp2=endexpf.getdouble();
  double m,v;
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[2];

  type[0]=PLOTLINE_LINE;
  type[1]=PLOTLINE_BARS;
  len[0]=1000;
  len[1]=100;
  arg[0]=new double[len[0]];
  val[0]=new double[len[0]];
  arg[1]=new double[len[1]];
  val[1]=new double[len[1]];
  axis[0]=axis[1]=1;

  double size=(exp2+1.0)*2.0, step=size/double(len[0]), 
    step2=size/double(len[1]), x=-1.0;

  line[0]=new char[100];
  line[1]=new char[100];

  find_invgamma_distribution(sigma_1*sigma_1, sigma_2*sigma_2, 
			     95.0, &a, &b);
  double c=2.0*a;

  find_student_t(exp1,exp2, 95.0, c, &m, &v);

  double v2=v/2.0/b;
  sprintf(line[0], WHAT((char *) "Fordeling til eksponent ~ "
			"stud_t(m=%7.3lf, st_v=%7.5g "
			"(v=%7.5g) , c=%5.2lf)",
			(char *) "Distribution of the exponent ~ "
			"stud_t(m=%7.3lf, st_v=%7.5g "
			"(v=%7.5g) , c=%5.2lf)"), m, v, v2, c);
  sprintf(line[1], "Sampling");
  axislab[0]=new char[10];
  strcpy(axislab[0], "exp");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");
  
  for(i=0;i<len[0];i++, x+=step)
    {
      double logf=gamma(0.5*(c+1.0))-gamma(0.5*c)-0.5*log(v*M_PI)-0.5*(c+1.0)*
	log(1.0+(x-m)*(x-m)/v);
      
      arg[0][i]=x;
      val[0][i]=pdf_student_t(m, v, 2.0*a, x);   //exp(logf);
    }
  
  for(i=0;i<len[1];i++)
    {
      arg[1][i]=-1.0+step2*i;
      val[1][i]=0.0;
    }

  static gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, 1);

  int num_under=0;
  for(i=0;i<numsample;i++)
    {
      double invsigma2=gsl_ran_gamma(rptr, a, 1.0/b);
      double sigma=1.0/sqrt(invsigma2);
      double sampled_exp=m + sigma*sqrt(v/2.0/b)*gsl_ran_gaussian(rptr, 1);
      int index=(int) floor((sampled_exp+1.0)/size*double(len[1]));
      
      //cout << sampled_exp << " " << index << endl;

      if(sampled_exp<exp1)
	num_under++;

      if(index>=0 && index<len[1])
	val[1][index]++;
    }
  cout << (WHAT((char *) "Rate under 2.5% persentil:",
	       (char *) "Rate under 2.5% percentile:")) << 
    double(num_under)/double(numsample)*100.0 << "%"  << endl;
 
  for(i=0;i<len[1];i++)
    val[1][i]/=double(numsample)*step2;

  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(arg, val, len, axis, line, 2, axislab, 2, NULL, type);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void bayes_ratingcurve::plot_const(void)
{
  int i,numsample=100000;
  double a,b;
  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();
  int *len=new int[2], *axis=new int[2];
  double **arg=new double*[2], **val=new double*[2];
  char **line=new char*[2], **axislab=new char*[2];
  double const1=log(startconstf.getdouble()), 
    const2=log(endconstf.getdouble());
  double m,v;
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[2];

  type[0]=PLOTLINE_LINE;
  type[1]=PLOTLINE_BARS;
  len[0]=10000;
  len[1]=1000;
  arg[0]=new double[len[0]];
  val[0]=new double[len[0]];
  arg[1]=new double[len[1]];
  val[1]=new double[len[1]];
  axis[0]=axis[1]=1;

  double size=exp(const2), step=size/double(len[0]), 
    step2=size/double(len[1]), x=step;

  line[0]=new char[100];
  line[1]=new char[100];

  find_invgamma_distribution(sigma_1*sigma_1, sigma_2*sigma_2, 
			     95.0, &a, &b);
  double c=2.0*a;

  find_student_t(const1,const2, 95.0, c, &m, &v);

  double v2=v/2.0/b;
  sprintf(line[0], WHAT((char *) "Fordeling til const n�r log(const) ~ "
			"stud_t(m=%7.3lf, st_v=%7.5g (v=%7.5g) , c=%5.2lf)", 
			(char *) "Distribution of constant when log(const) ~ "
			"stud_t(m=%7.3lf, st_v=%7.5g (v=%7.5g) , c=%5.2lf)"),
	  m, v, v2, c);
  sprintf(line[1], "Sampling");
  axislab[0]=new char[10];
  strcpy(axislab[0], "const");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(i=0;i<len[0];i++, x+=step)
    {
      double logf=gamma(0.5*(c+1.0))-gamma(0.5*c)-0.5*log(v*M_PI)-0.5*(c+1.0)*
	log(1.0+(log(x)-m)*(log(x)-m)/v)-log(x);
      
      arg[0][i]=x;
      val[0][i]=exp(logf);
    }
  
  for(i=0;i<len[1];i++)
    {
      arg[1][i]=step2*double(i+1);
      val[1][i]=0.0;
    }

  static gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, 1);

  for(i=0;i<numsample;i++)
    {
      double invsigma2=gsl_ran_gamma(rptr, a, 1.0/b);
      double sigma=1.0/sqrt(invsigma2);
      double sampled_const=exp(m+gsl_ran_gaussian(rptr, sigma*sqrt(v2)));
      int index=(int) ceil(sampled_const/size*double(len[1]));
      
      //cout << sampled_const << " " << index << endl;
      
      if(index>=0 && index<len[1])
	val[1][index]++;
    }
  
  for(i=0;i<len[1];i++)
    val[1][i]/=double(numsample)*step2;
  
  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(arg, val, len, axis, line, 2, axislab, 2, NULL, type);
  
  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}

void bayes_ratingcurve::plot_h0(void) 
{
  int i,numsample=100000;
  int *len=new int[2], *axis=new int[2];
  double **arg=new double*[2], **val=new double*[2];
  char **line=new char*[2], **axislab=new char*[2];
  double h01=starth0f.getdouble(), h02=endh0f.getdouble();
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[2];
  double m=0.5*(h01+h02);
  double v=(h02-h01)/2.0/1.96;

  if(!*starth0f() || !*endh0f())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Begge bunnstandandsgrensene m� v�re "
		     "utfylt\nfor at en skal ha en informativ fordeling!",
		     (char *) "Both bottom stage limits must be given!"));
      return;
    }
  
  type[0]=PLOTLINE_LINE;
  type[1]=PLOTLINE_BARS;
  len[0]=1000;
  len[1]=100;
  arg[0]=new double[len[0]];
  val[0]=new double[len[0]];
  arg[1]=new double[len[1]];
  val[1]=new double[len[1]];
  axis[0]=axis[1]=1;

  line[0]=new char[100];
  line[1]=new char[100];

  double size=(h02-h01+1.0)*2.0, step=size/double(len[0]-1), 
    step2=size/double(len[1]-1), h0start=h01-0.5*(h02-h01)-1.0, x=h0start;

  sprintf(line[0], WHAT((char *) "Fordeling til H0~N(%7.3g, %7.3g^2) ",
			(char *)  "Distribution of H0~N(%7.3g, %7.3g^2) "),
	  m, v);
  sprintf(line[1], "Sampling");
  axislab[0]=new char[10];
  strcpy(axislab[0], "h0");
  axislab[1]=new char[10];
  strcpy(axislab[1], "f");

  for(i=0;i<len[0];i++, x+=step)
    {
      double f=1.0/sqrt(2.0*M_PI)/v*exp(-0.5*(x-m)*(x-m)/v/v);
      
      arg[0][i]=x;
      val[0][i]=f;
    }
  
  for(i=0;i<len[1];i++)
    {
      arg[1][i]=h0start+step2*i;
      val[1][i]=0.0;
    }
  
  for(i=0;i<numsample;i++)
    {
      double sampled_h0=m+v*gauss();
      int index=(int) floor((sampled_h0-h0start)/size*double(len[1]));
      
      if(index>=0 && index<len[1])
	val[1][index]++;
    }

  for(i=0;i<len[1];i++)
    val[1][i]/=double(numsample)*step2;

  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(arg, val, len, axis, line, 2, axislab, 2, NULL, type);

  doubledelete(axislab,2);
  delete [] arg;
  delete [] val;
  delete [] line;
}



void bayes_ratingcurve::generate(int type)
{
  if(sdlen<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Inget datasett hentet!",
		     (char *) "No dataset fetched!"));
      return;
    }

  double sigma_1=startsigmaf.getdouble();
  double sigma_2=endsigmaf.getdouble();
  double corr=corrf.getdouble();
  double upperstage=stageendf.getdouble();
  double exp1=startexpf.getdouble(), exp2=endexpf.getdouble();
  double const1=log(startconstf.getdouble()), 
    const2=log(endconstf.getdouble());
  double c_1=-endh0f.getdouble(), c_2=-starth0f.getdouble(), c_m, c_s;
  BAYES_RATINGCURVE_C_PRIOR c_priortype=(BAYES_RATINGCURVE_C_PRIOR) h0tog();
  double a,b,m1,v1,m2,v2,c;
  int i;

  if(c_priortype==BAYES_RATINGCURVE_C_NORMAL)
    {
      if(!*starth0f() || !*endh0f())
	{
	  err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		    WHAT((char *) "Begge bunnstandandsgrensene m� v�re "
			 "utfylt\nfor at en skal ha en informativ fordeling!",
			 (char *) "Both bottom stage limits must be given!"));
	  return;
	}

      c_m=(c_1+c_2)/2.0;
      c_s=(c_2-c_1)/2.0/1.96;
    }
  
  find_invgamma_distribution(sigma_1*sigma_1, sigma_2*sigma_2, 
			     95.0, &a, &b);
  c=2.0*a; //2.0*a;

  if(noninfo_sigma2() && type==0)
    a=b=0.0;

  if(type>0)
    {
      find_student_t(exp1,exp2, 95.0, c, &m1, &v1);
      find_student_t(const1,const2, 95.0, c, &m2, &v2);
    }
  else
    {
      m1=(exp1+exp2)/2.0;
      v1=(exp2-exp1)/2.0/1.96;
      m2=(const1+const2)/2.0;
      v2=(const2-const1)/2.0/1.96;
    }
  
  DateTime *dt=new DateTime[sdlen];
  double *h=new double[sdlen], *q=new double[sdlen];
  for(i=0;i<sdlen;i++)
    {
      h[i]=sd[i].h;
      q[i]=sd[i].q;
      dt[i]=sd[i].dt;
    }
  int numh0=1000;
  double hmin=find_statistics(h,sdlen,MIN), hstart=hmin-30.0;
  double *h0=new double[numh0], *p_h0=new double[numh0];

  int c_state=h0tog();
  double h01=starth0f.getdouble();
  double h02=endh0f.getdouble();
  double h0sigma=(h02-h01)/2.0/1.96;
  double h0mean=(h02+h01)/2.0;

  for(i=0;i<numh0;i++)
    {
      h0[i]=hstart+(hmin-hstart)*double(i)/double(numh0);
      if(c_state==1)
	p_h0[i]=1.0/(hmin-h0[i]);
      else if(c_state==0)
	p_h0[i]=1.0/double(numh0);
      else
	p_h0[i]=exp(-0.5*(h0[i]-h0mean)*(h0[i]-h0mean)/h0sigma/h0sigma)/
	  sqrt(2.0*M_PI)/h0sigma;
    }
  double ptot=0.0;
  for(i=0;i<numh0;i++)
    ptot+=p_h0[i];
  for(i=0;i<numh0;i++)
    p_h0[i]/=ptot;

  cout << cdf_student_t(m1,v1,c,exp1) << " " << 
    cdf_student_t(m1,v1,c,exp2) << endl;
  
  /*
  double *st=new double[10000];
  int outside=0;
  for(i=0;i<10000;i++)
    {
      st[i]=sample_from_student_t(m1,v2,2.0*a);
      if(st[i]<exp1 || st[i]>exp2)
	outside++;
    }
  cout << "sample st.dev=" << sqrt(find_statistics(st,10000,VARIATION)) << 
    endl;
  cout << "Rate outside:" << double(outside)/100.0 << "%" << endl;
  */

  double s1=sqrt(v1), s2=sqrt(v1/(c-2.0)), s3=sqrt(v1*(c-2.0)),
    s4=sqrt(v1*b), s5=sqrt(v1*b/(c-2.0)), s6=sqrt(v1/(c-2.0)),
    s7=sqrt(v1*(c-2.0)/c);
  cout << s1 << " " << s2 << " " << s3 << " " << s4 << " " << s5 << 
    " " << s6 << " " << s7 << endl;

  switch(type)
    {
    case 0:
      if(mcmccurve)
	delete mcmccurve;
      mcmccurve=new bayes_mcmc_curve();
      
      mcmccurve->create(h,q,sdlen,10000, m1, v1, m2, v2, corr, a, b, 
			c_priortype, c_m, c_s, upperstage, x_stage, dt);
      break;
    case 1:
      if(showcurve)
	delete showcurve;
      showcurve=new bayes_show_curve();
      
      showcurve->create(h,q,sdlen, p_h0, h0, numh0, m1, sqrt(v1/(c-2.0)), 
			m2, sqrt(v2/(c-2.0)), a, b);
      break;
    case 2:
      if(mcmc)
	delete mcmc;
      mcmc=new bayes_mcmc_old();
      
      mcmc->create(m1,sqrt(v1/(c-2.0)), m2, sqrt(v2/(c-2.0)), a, b, sd, sdlen);
      break;
    default:
      err.build(*this, WHAT((char *) "Programfeil", 
			    (char *) "Program error"),
		WHAT((char *) "Ukjent genereringsopsjon!", 
		     (char *) "Unknown generation option!"));
      break;
    }
  
  delete [] h;
  delete [] q;
  delete [] dt;
}

void bayes_ratingcurve::stage_vs_discharge_changed(Boolean stage_vs_discharge)
{
  x_stage=stage_vs_discharge;
  if(sdlen>0)
    plot_measurements();
}

void bayes_ratingcurve::take_action(BAYES_RATINGCURVE_ACTION action)
{
  switch(action)
    {
    case BAYES_RATINGCURVE_FETCHFILE:
      ff.Create(this);
      break;
    case BAYES_RATINGCURVE_GENERATE:
      generate(1);
      break;
    case BAYES_RATINGCURVE_MCMC:
      generate(0);
      break;
    case BAYES_RATINGCURVE_MCMC2:
      generate(2);
      break;
    case BAYES_RATINGCURVE_PLOT_SIGMA:
      plot_sigma();
      break;
    case BAYES_RATINGCURVE_PLOT_INVGAMMA:
      plot_invgamma_search();
      break;
    case BAYES_RATINGCURVE_PLOT_EXP: 
      plot_exp();
      break;
    case BAYES_RATINGCURVE_PLOT_CONST:
      plot_const();
      break;
    case BAYES_RATINGCURVE_PLOT_H0: 
      plot_h0();
      break;
    case BAYES_RATINGCURVE_EXIT:
      exit(0);
      break;
    }
}

Boolean bayes_ratingcurve::fetchfile(char *filename)
{
  double zeropoint;
  char errmsg[1000];

  sd=get_sd_file(filename, &sdlen, errmsg, &zeropoint);  
  
  if(!sd || sdlen<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"), errmsg);
      return False;
    }
  
  if(zeropoint!=MISSING_VALUE)
    {
      h0tog.SetFocus(2);
      h5.Sensitive();
      
      starth0f.SetDouble(zeropoint-0.1, 7);
      endh0f.SetDouble(zeropoint+0.1, 7);
    }
  else
    {
      h0tog.SetFocus(0);
      starth0f.SetText("");
      endh0f.SetText("");
    }
  
  plot_measurements();

  return True;
}

void bayes_ratingcurve::plot_measurements(void)
{
  double *arg=new double[sdlen], *val=new double[sdlen];
  char *linestr=new char[100], **axisstr=new char*[2];
  int i,axis=1;
  PLOTLINE_TYPE type=PLOTLINE_DOT;
  
  axisstr[0]=new char[100];
  axisstr[1]=new char[100];
  if(x_stage)
    {
      strcpy(axisstr[1], "Q");
      strcpy(axisstr[0], "h");
    }
  else
    {
      strcpy(axisstr[0], "Q");
      strcpy(axisstr[1], "h");
    }
    
  strcpy(linestr, WHAT((char *) "M�linger", (char *) "Measurements"));
  
  for(i=0;i<sdlen;i++)
    {
      arg[i]=sd[i].h;
      val[i]=sd[i].q;
    }
  
  double maxh=find_statistics(arg,sdlen,MAX);
  stageendf.SetDouble(maxh+1.0);
  
  if(x_stage)
    measurement_plot.Create(&arg, &val, &sdlen, &axis, &linestr, 1, 
			    axisstr, 2, NULL, &type);
  else
    measurement_plot.Create(&val, &arg, &sdlen, &axis, &linestr, 1, 
			    axisstr, 2, NULL, &type);
  measurement_plot.redraw();
  
  doubledelete(axisstr, 2);
  delete [] arg;
  delete [] val;
  delete [] linestr;
}

void bayes_ratingcurve::noninfo_state_changed(int state)
{
  if(state==2)
    h5.Sensitive();
  else
    h5.InSensitive();
}

bayes_ratingcurve::bayes_ratingcurve(int argc, char **argv) : 
  mainwin("bayes_file_ratingcurve",argc,argv)
{
  plot=NULL;
  showcurve=NULL;
  mcmc=NULL;
  mcmccurve=NULL;
  
  v0.build(*this);
  h0.build(v0);
  fetchb.Create(h0, WHAT((char *) "Hent fra fil", (char *) "Fetch from file"),
		BAYES_RATINGCURVE_FETCHFILE, this);
  fetchb.Background("green");
  fetchb.Foreground("black");
  stage_vs_discharge.Create(h0,this);

  measurement_plot.put_in_widget(v0,1000,350,PLOT_IN_WIDGET_SHOWMENUES);

  fr1.build(v0);
  v1.build(fr1);
  sigmalab.build(v1,WHAT((char *) "95%% sannsynlighet for at relativ st�y "
			 "ligger i f�lgende omr�de:",
			 (char *) "95%% probability that the relative noise "
			 "lies within the following interval:"));
  h1.build(v1);
  noninfo_sigma2.build(h1, WHAT((char *) "Ikke-informativ f�rkunnskap om "
				"st�yledd:", (char *) "non-informative prior "
				"on the noise part"));
  startsigmaf.build(h1, 10, WHAT((char *) "Start:", (char *) "Start:"));
  startsigmaf.SetDouble(1.0/sqrt(gsl_cdf_gamma_Qinv(0.025, 4.0, 1.0/0.03)), 4);
  endsigmaf.build(h1,10, WHAT((char *) "Slutt:", (char *) "End:"));
  endsigmaf.SetDouble(1.0/sqrt(gsl_cdf_gamma_Qinv(0.975, 4.0, 1.0/0.03)), 4);
  plotsigmab.Create(h1, WHAT((char *) "Plott fordelingen til sigma^2",
			     (char *) "Plot the distribution of sigma^2"),
		    BAYES_RATINGCURVE_PLOT_SIGMA, this);
  plotinvgammab.Create(h1, WHAT((char *) "Plott s�keflate for IG",
				(char *) "Plot the search area for IG"),
		       BAYES_RATINGCURVE_PLOT_INVGAMMA, this);

  fr2.build(v0);
  v2.build(fr2);
  explab.build(v2, WHAT((char *) "95%% sannsynlighet for at eksponent "
			"ligger i f�lgende omr�de:",
			(char *) "95%% probability that the exponent "
			"lies in the following interval:"));
  h2.build(v2);
  startexpf.build(h2, 10, WHAT((char *) "Start:", (char *) "Start:"));
  startexpf.SetDouble(inv_cdf_student_t(2.5, 1.0*1.0, 
					4.0, 0.025), 4);
  endexpf.build(h2,10, WHAT((char *) "Slutt:", (char *) "End:"));
  endexpf.SetDouble(inv_cdf_student_t(2.5, 1.0*1.0, 
				      4.0, 0.975),4);
  plotexpb.Create(h2, WHAT((char *) "Plott fordelingen til eksponent",
			   (char *) "Plot the distribution of the exponent"),
		  BAYES_RATINGCURVE_PLOT_EXP, this);

  fr3.build(v0);
  v3.build(fr3);
  constlab.build(v3, WHAT((char *) "95%% sannsynlighet for at konstant "
			  "ligger i f�lgende omr�de:",
			  (char *) "95%% probability that the constant "
			  "lies in the following interval:"));
  h3.build(v3);
  startconstf.build(h3, 10, WHAT((char *) "Start:", (char *) "Start:"));
  startconstf.SetDouble(exp(inv_cdf_student_t(2.6, 1.3*1.3, 
					      4.0, 0.025)), 2);
  endconstf.build(h3,10, WHAT((char *) "Slutt:", (char *) "End:"));
  endconstf.SetDouble(exp(inv_cdf_student_t(2.6, 1.3*1.3, 
					    4.0, 0.975)), 2);
  plotconstb.Create(h3, WHAT((char *) "Plott fordelingen til log-konstant",
			     (char *) "Plot the distribution of the "
			     "log-constant"),
		  BAYES_RATINGCURVE_PLOT_CONST, this);

  corrf.build(h3, 7, WHAT((char *) "Korrelasjon mellom eksponent og "
			  "log-konstant:", 
			  (char *) "Correlation between exponent and "
			  "log-constant:"));
  corrf.SetDouble(-0.2);
  
  fr4.build(v0);
  v5.build(fr4);
  h0tog.Create(v5, this);
  h5.build(v5);
  h0lab.build(h5, WHAT((char *) "95%% sannsynlighet for at bunnvannstanden "
		       "ligger i f�lgende omr�de:",
		       (char *) "95%% probability that the bottom stage "
		       "lies in the following interval:")); 
  starth0f.build(h5, 10, WHAT((char *) "Start:", (char *) "Start:"));
  endh0f.build(h5,10, WHAT((char *) "Slutt:", (char *) "End:"));
  ploth0b.Create(h5, WHAT((char *) "Plott fordelingen til bunnvannstanden",
			  (char *) "Plot the dist. of the bottom stage"),
		 BAYES_RATINGCURVE_PLOT_H0, this);
  h5.InSensitive();

  sep1.build(v0);
  h4.build(v0);
  exitb.Create(h4, WHAT((char *) "Avslutt", (char *) "Quit"),
	       BAYES_RATINGCURVE_EXIT, this);
  exitb.Background("red");
  exitb.Foreground("white");
  mcmcb.Create(h4, WHAT((char *) "Generer kurve", (char *) "Generate curve"), 
	       BAYES_RATINGCURVE_MCMC, this);
  mcmcb.Background("green");
  mcmcb.Foreground("black");
  stageendf.build(h4, 8, WHAT((char *) "�vre gyldighetsomr�de for vannstand:", 
			      (char *) "Upper limit for stage values:"));
  generateb.Create(h4, WHAT((char *) "Diskretisering p� gammel prior", 
			    (char *) "Discretization on old prior"),
		   BAYES_RATINGCURVE_GENERATE, this);
  mcmcb2.Create(h4, WHAT((char *) "MCMC - gammel prior", 
			 (char *) "MCMC - old prior"),
		BAYES_RATINGCURVE_MCMC, this);
}

int main(int argc, char **argv)
{
  randify();
  
  bayes_ratingcurve tp(argc, argv);
  tp.Run();
}
