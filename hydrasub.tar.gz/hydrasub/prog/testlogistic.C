#include <hydrasub/hydrabase/regression.H>
#include <hydrasub/hydrabase/lists.H>
#include <hydrasub/hydrabase/linalg.H>
#include <cmath>
#include <fstream.h>

class logistic_data : public double_linked_list
{
public:
  logistic_data(logistic_data *prev, long int y_, long int n_,
		double x_);

  logistic_data *suc(void);

  long int y,n;
  double x;
};

logistic_data::logistic_data(logistic_data *prev, long int y_, long int n_,
			     double x_) : 
  double_linked_list((double_linked_list *) prev, NULL)
{
  y=y_;
  n=n_;
  x=x_;
}

logistic_data *logistic_data::suc(void)
{
  return (logistic_data *) getnext();
}

logistic_data *fetchfile(char *filename)
{
  char line[1000];
  ifstream in;

  in.open(filename, ios::in);
  
  if(in.fail())
    return NULL;
  
  logistic_data *head=NULL, *tail=NULL;

  in.getline(line,999);
  while(!in.fail())
    {
      long int y,n;
      double x;
      
      if(sscanf(line, "%lf %ld %ld", &x, &n, &y)==3)
	{
	  tail=new logistic_data(tail, y, n, x);
	  if(!head)
	    head=tail;
	}

      in.getline(line,999);
    }
    
  return head;
}


/*
// Performs a regssion analysis on the given predictors and response
// measurements. The predictor should have 'numpredictors' arrays
// each of size 'arraysize' while the response should have 'arraysize' 
// response measurements. PS: fixed constant part
logistic_regression *get_logistic_regression(double **predictor, 
					     int numpredictors,
					     long int *response, 
					     long int *numresponse,
					     int arraysize)
{
  int i,j,k;
  double *numresp2=new double[arraysize], *resp2=new double[arraysize];
  for(i=0;i<arraysize;i++)
    {
      numresp2[i]=numresponse[i];
      resp2[i]=response[i];
    }
  
  Matrix X(predictor, numpredictors, arraysize);
  vector y(resp2, arraysize);
  vector n(numresp2, arraysize);
  vector pi(arraysize), piinv(arraysize);
  vector b(numpredictors), JinvU(numpredictors);
  vector U(numpredictors);
  double diff=1.0;
  
  delete [] numresp2;
  delete [] resp2;
  
  while(diff>0.0001)
    {
      for(k=0;k<arraysize;k++)
	{
	  double nu=0;
	  for(i=0;i<numpredictors;i++)
	    nu += predictor[i][k]*b(i);
	  
	  pi.set_element(k, exp(nu)/(1.0+exp(nu)));
	  piinv.set_element(k, pi(k)*(1.0-pi(k)));
	}
      
      Matrix J(numpredictors,numpredictors);
      Matrix Jinv(numpredictors,numpredictors);
      for(i=0;i<numpredictors;i++)
	for(j=0;j<numpredictors;j++)
	  {
	    double res=0;
	    for(k=0;k<arraysize;k++)
	      res += piinv(k)*X(i,k)*X(j,k)*n(k);
	    
	    J.set_element(i,j,res);
	  }

      for(i=0;i<numpredictors;i++)
	{
	  double res=0;
	  for(k=0;k<arraysize;k++)
	    res += X(i,k)*(y(k)-n(k)*pi(k));
	  
	  U.set_element(i,res);
	}
      
      Jinv=inverse(J);
      JinvU=Jinv*U;
      
      b=b+JinvU;
      diff=JinvU.length();
    }
  
  double *coef=b.get_as_double_array();

  logistic_regression *result=new logistic_regression(coef, numpredictors,
						      arraysize);

  return result;
}

*/

// Performs a regssion analysis on the given predictors and response
// measurements. The predictor should have 'numpredictors' arrays
// each of size 'arraysize' while the response should have 'arraysize' 
// response measurements. PS: fixed constant part
logistic_regression *get_logistic_regression(double **predictor, 
					     int numpredictors,
					     long int *response, 
					     long int *numresponse,
					     int arraysize)
{
  int i,j,k;
  double *numresp2=new double[arraysize], *resp2=new double[arraysize];
  for(i=0;i<arraysize;i++)
    {
      numresp2[i]=numresponse[i];
      resp2[i]=response[i];
    }
  
  Matrix X(predictor, numpredictors, arraysize);
  vector y(resp2, arraysize);
  vector n(numresp2, arraysize);
  vector pi(arraysize), piinv(arraysize);
  vector b(numpredictors), JinvU(numpredictors);
  vector U(numpredictors);
  double diff=1.0;
  
  delete [] numresp2;
  delete [] resp2;
  
  while(diff>0.0001)
    {
      for(k=0;k<arraysize;k++)
	{
	  double nu=0;
	  for(i=0;i<numpredictors;i++)
	    nu += predictor[i][k]*b(i);
	  
	  pi.set_element(k, exp(nu)/(1.0+exp(nu)));
	  piinv.set_element(k, pi(k)*(1.0-pi(k)));
	}
      
      Matrix J(numpredictors,numpredictors);
      Matrix Jinv(numpredictors,numpredictors);
      for(i=0;i<numpredictors;i++)
	for(j=0;j<numpredictors;j++)
	  {
	    double res=0;
	    for(k=0;k<arraysize;k++)
	      res += piinv(k)*X(i,k)*X(j,k)*n(k);
	    
	    J.set_element(i,j,res);
	  }

      for(i=0;i<numpredictors;i++)
	{
	  double res=0;
	  for(k=0;k<arraysize;k++)
	    res += X(i,k)*(y(k)-n(k)*pi(k));
	  
	  U.set_element(i,res);
	}
      
      Jinv=inverse(J);
      JinvU=Jinv*U;
      
      b=b+JinvU;
      diff=JinvU.length();
    }
  
  double *coef=b.get_as_double_array();

  logistic_regression *result=new logistic_regression(coef, numpredictors,
						      arraysize);

  return result;
}

int main(int argc, char **argv)
{
  int i;
  logistic_data *indata;
  long int len, *y, *n;
  double **X=new double*[2];

  if(argc>1)
    indata=fetchfile(argv[1]); 
  else
    indata=fetchfile("beetle.txt");
  
  if(!indata)
    {
      cout << "couldn't read the file!" << endl;
      return 1;
    }
  
  len=indata->number_of_elements();
  X[0]=new double[len];
  X[1]=new double[len];
  y=new long int[len];
  n=new long int[len];

  i=0;
  for(logistic_data *ptr=indata; ptr; ptr=ptr->suc())
    {
      X[0][i]=1.0;
      X[1][i]=ptr->x;
      y[i]=ptr->y;
      n[i]=ptr->n;
      i++;
    }

  logistic_regression *res=get_logistic_regression(X, 2, y, n, len);

  if(res)
    {
      cout << "# Column 1: b0=" << res->get_coefficient(0) << " b1=" << 
	res->get_coefficient(1) << endl;
      cout << "# Column 2: Measurements" << endl;
      cout << "# Column 2 - type: dot" << endl;
      cout << "###################" << endl;
      
      double x1=find_statistics(X[1], len, MIN);
      double x2=find_statistics(X[1], len, MAX);
      double step=(x2-x1);

      x1-=step*0.25;
      x2+=step*0.25;
      step=(x2-x1)/500.0;

      double xx[2];
      
      xx[0]=1.0;

      for(double x=x1;x<=x2;x+=step)
	{
	  xx[1]=x;
	  cout << x << " " << res->predict(xx) << " -10000000" << endl;
	}

      for(i=0;i<len;i++)
	cout << X[1][i] << " -10000000 " << double(y[i])/double(n[i]) << endl;
    }
  else
    cout << "Regression failed!" << endl;
}
