#include "linreg.H"
#include <unistd.h>
#include <stdlib.h>
#include <fstream.h>

void linreg::regression_done(regression_rule *rule)
{
  exit(0);
}

void usage(void)
{
  cout << "Usage: linreg <filename>" << endl;
  cout << "Pops up a window for doing linear regression on the" << endl;
  cout << "content of the given file. The file must contain at least" << endl;
  cout << "two lines. all lines should have the same number of columns." 
       << endl;
  exit(0);
}

double **fetch_content(istream &in, int &numvar, int&len, char ***names)
{
  int i,j;
  char line[1000];
  double **val=NULL;
  int linenum=1;
  valuelist **colhead=NULL,
    **coltail=NULL;
  double valuebuffer;

  numvar=0;
  len=0;

  do
    {
      in.getline(line, 999);
      if(in.fail())
	{
	  cerr << "No content" << endl;
	  return NULL;
	}
      linenum++;
    } while(line[0]=='\0' || line[0]=='#');

  char *line2=stripspaces(line);
  if(line2[0]=='\"')
    {
      stringlist *linehead=NULL, *linetail=NULL;
      char *strptr=line2;
      char strbuffer[1000];
      
      while(strptr=getnextdelimitedstr(strptr, strbuffer))
	{
	  numvar++;
	  
	  linetail=new stringlist(linetail, NULL, strbuffer);
	  if(!linehead)
	    linehead=linetail;
	}
      
      if(!linehead)
	{
	  cerr << "No number columns found in line line" << endl;
	  return NULL;
	}
      
      colhead=new valuelist*[numvar]; 
      coltail=new valuelist*[numvar];
      *names=new char*[numvar];
      for(i=0;i<numvar;i++)
	{
	  colhead[i]=NULL;
	  coltail[i]=NULL;
	}

      stringlist *ptr=linehead;
      for(i=0;i<numvar;i++)
	{
	  (*names)[i]=new char[100];
	  strcpy((*names)[i], ptr->getstring());
	  ptr=(stringlist *) ptr->getnext();
	}

      delete linehead;
      linehead=linetail=NULL;
    }
  else
    {
      valuelist *linehead=NULL, *linetail=NULL;
      char *strptr=line;
      
      while(strptr=getnextdouble(strptr, &valuebuffer))
	{
	  numvar++;
	  
	  linetail=new valuelist(linetail, NULL, valuebuffer);
	  if(!linehead)
	    linehead=linetail;
	}
      
      if(!linehead)
	{
	  cerr << "No number columns found in line " << linenum << endl;
	  return NULL;
	}
  
      // insert line line into the column lists;
      colhead=new valuelist*[numvar]; 
      coltail=new valuelist*[numvar];
      valuelist *ptr=linehead;
      for(i=0;i<numvar;i++)
	{
	  colhead[i]=new valuelist(NULL,NULL,ptr->getvalue());
	  coltail[i]=colhead[i];
	  ptr=(valuelist *) ptr->getnext();
	}
      delete linehead;
      linehead=linetail=NULL;
      *names=NULL;
    }

  in.getline(line,999);
  char *strptr;
  valuelist *linehead=NULL, *linetail=NULL;
  while(!in.fail())
    {
      if(line[0]!='\0' && line[0]!='#')
	{
	  strptr=line;
	  while(strptr=getnextdouble(strptr, &valuebuffer))
	    {
	      linetail=new valuelist(linetail, NULL, valuebuffer);
	      if(!linehead)
		linehead=linetail;
	    }
	  
	  int numitems = linehead ? linehead->number_of_elements() : 0;
	  
	  if(numitems!=numvar)
	    {
	      printf("Error in line %d, %d columns, while the first "
		     "row had %d\n", linenum, numitems, numvar);
	      return NULL;
	    }
	  
	  valuelist *ptr=linehead;
	  for(i=0;i<numvar;i++)
	    {
	      coltail[i]=new valuelist(coltail[i],NULL,ptr->getvalue());
	      if(!colhead[i])
		colhead[i]=coltail[i];
	      ptr=(valuelist *) ptr->getnext();
	    }
	  delete linehead;
	  linehead=linetail=NULL;
	}
      
      in.getline(line,999);
      linenum++;
    }
  
  len=colhead[0]->number_of_elements();
  
  if(len<=numvar)
    {
      cerr << "Too few datasets:" << len << endl;
      return NULL;
    }
  
  val=new double*[numvar];
  for(i=0;i<numvar;i++)
    {
      val[i]=new double[len];
      j=0;
      for(valuelist *ptr=colhead[i];ptr;ptr=(valuelist *) ptr->getnext())
	{
	  val[i][j]=ptr->getvalue();
	  j++;
	}
      
      delete colhead[i];
      colhead[i]=NULL;
    }
  delete [] colhead;
  delete [] coltail;
  
  return val;
}

int main(int argc, char **argv)
{
  if(argc!=2)
    usage();
  
  ifstream in;
  
  in.open(argv[1], ios::in);
  if(in.fail())
    {
      cerr << "Couldn't open the file " << argv[1] << endl;
      exit(0);
    }
  
  double **content;
  int numvar=0, len=0;
  char **serietitles;
  
  content=fetch_content(in, numvar, len, &serietitles);
  in.close();
  
  if(content && len && numvar)
    {
      mainwin mn("linreg",argc,argv);
      linreg lr;
      
      if(!serietitles)
	{
	  serietitles=new char*[numvar];
	  for(int i=0;i<numvar;i++)
	    {
	      serietitles[i]=new char[10];
	      sprintf(serietitles[i], "x%d", i+1);
	    }
	}

      lr.Create(content, len, numvar, serietitles);
      mn.Run();
    }
  else
    cerr << "Couldn't understand the file " << argv[1] << endl;

  return 0;
}
