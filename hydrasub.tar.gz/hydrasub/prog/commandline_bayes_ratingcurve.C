#include <stdio.h>
#include <hydrasub/hydrabase/bayes_generate_ratingcurve.H>
#include <hydrasub/hydrabase/stagedischarge.H>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <cmath>

void usage(void)
{
  printf("  Usage: commandline_bayes_ratingcurve [options] <measurement file>\n");
  printf("This command line program performs a one segment Bayesian rating\n");
  printf("curve fit for the given measurement file. The rating curve has the\n");
  printf("form Q=C(h-h0)^b (times lognormal noise). (The re-parametrization\n");
  printf("a=log(C) and c=-h0 is used internally.)\n");
  printf("  The output will be a text containing the fitted parameters, the variance\n");
  printf("and credibility intervals for these parameters, a stage-discharge table "
	 "going from\n");
  printf("the lowest stage measurement plus 10 meters or to\n");
  printf("a limit provided by the user, and a residual table. The output will\n");
  printf("default be shown in the command window, but can be redirected to a file\n");
  printf("using the '-o' option or the redirection sign '>' at the end of the\n");
  printf("command. If nothing else is given, the program will use priors found\n");
  printf("from Norwegian rivers, with non-informative prior for the parameter "
	 "'c=-h0'\n\n");
  printf("The measurement file should be a text file containing one measurements "
	 "per line,\n");
  printf("either in the form of \"time stage discharge\" or on the form \"stage "
	 "discharge\"\n");
  printf("The time can either be years, or a date on the form \"DD/MM/YYYY\" or\n");
  printf("a data time in the form \"DD/MM/YYY hh:mm\". For instance, \"21/07/2006 "
	 "14:27\"\n");
  printf("will be the twenty-first of July, at 2:27 PM.\n\n");
  printf("Options:\n");
  printf("  -o <output file>: Redirects the output to a given file.\n");
  printf("  -N <number of samples>: Sets the number of samples for the MCMC run\n");
  printf("                          Default: 10000. It can be advantageous to increase"
	 " it to 100000\n");
  printf("  -h <lower cred> <upper cred>: Gives a normally distributed prior for\n");
  printf("                                h0=-c. Default: non-informativ prior.\n");
  printf("                                (The normal distribution is set so that\n");
  printf("                                the limits set by the user is contains the\n");
  printf("                                95%% credibility for this parameter.)\n");
  printf("  -b <lower cred> <upper cred>: Sets the prior for the exponent, b.\n");
  printf("                                Default: 0.68 - 4.32.\n");
  printf("  -C <lower cred> <upper cred>: Sets the prior for the constant,"
	 "C=exp(a).\n");
  printf("                                Default: 1.20 - 160.8.\n");
  printf("  -a <lower cred> <upper cred>: Sets the prior for the log-constant,"
	 "a=log(C).\n");
  printf("                                Default: 0.18 - 5.1.\n");
  printf("  -r <a-b correlation>: Sets the prior correlation between 'a' and 'b'.\n");
  printf("                        Default: -0.276.\n");
  printf("  -S <lower cred> <upper cred>: Sets the prior for the proportional noise\n");
  printf("                                term, sigma. Default: 0.02 -  0.15\n");
  printf("  -n: Triggers non-informative prior for the noise term sigma.\n");
  printf("  -e <end stage>: Sets the ending stage of the stage-discharge table.\n");
  printf("                  Default: h0-estimate + 10.0m.\n");
  printf("  -s <stage step rate>: Sets the step rate for the stage-discharge table.");
  printf("                        Default: 1cm.\n");
  printf("  -c: Triggers only showing the parameter estimates.\n");
  printf("  -R: Triggers showing the residuals.\n");
  exit(0);
}

int main(int argc, char **argv)
{
  // Priors and program settings:
  double min_c=MISSING_VALUE, max_c=MISSING_VALUE;
  double min_a=0.18, max_a=5.08;
  double min_b=0.68, max_b=4.32;
  double min_s=0.02, max_s=0.15;
  boolean do_file_output=b_false, noninfo_h0=b_true, 
    noninfo_sigma=b_false, auto_end=b_true, show_table=b_true, show_res=b_false;
  char output_file[1000];
  double steprate=0.01, endstage=MISSING_VALUE;
  double corr=-0.276; // correlation between 'a' and 'b'
  int numsamples=10000;

  // Mean and standard deviation of the curve parameters:
  double m1,s1,m2,s2,c_m=MISSING_VALUE, c_s=MISSING_VALUE;
  double alpha,beta; // sigma^2 ~ IG(alpha,beta)

  // Measurements:
  StageDischarge *sd; // single structure
  int sdlen;
  // Separate arrays:
  DateTime *dt;
  double *Q, *h, zeropoint;
  int i;

  if(argc<2)
    usage();

  randify();

  // Fetch all options:
  while(argc>=2 && argv[1][0]=='-')
    {
      switch(argv[1][1])
	{
	case 'c':
	  show_table=b_false;
	  break;
	case 'R':
	  show_res=b_true;
	  break;
	case 'o':
	  do_file_output=b_true;
	  
	  if(argc<3)
	    usage();
	  else
	    strcpy(output_file,argv[2]);
	  argc--;
	  argv++;
	  break;
	case 'h':
	  noninfo_h0=b_false;
	  
	  if(argc<4)
	    usage();
	  max_c=-atof(argv[2]);
	  min_c=-atof(argv[3]);
	  argc-=2;
	  argv+=2;
	  break;
	case 'b':
	  if(argc<4)
	    usage();
	  min_b=atof(argv[2]);
	  max_b=atof(argv[3]);
	  argc-=2;
	  argv+=2;
	  break;
	case 'a':
	  if(argc<4)
	    usage();
	  min_a=atof(argv[2]);
	  max_a=atof(argv[3]);
	  argc-=2;
	  argv+=2;
	  break;
	case 'C':
	  if(argc<4)
	    usage();
	  min_a=log(atof(argv[2]));
	  max_a=log(atof(argv[3]));
	  argc-=2;
	  argv+=2;
	  break;
	case 'S':
	  if(argc<4)
	    usage();
	  min_s=atof(argv[2]);
	  max_s=atof(argv[3]);
	  argc-=2;
	  argv+=2;
	  break;
	case 'n':
	  noninfo_sigma=b_true;
	  break;
	case 'N':
	  if(argc<3)
	    usage();
	  else
	    numsamples=atoi(argv[2]);
	  argc--;
	  argv++;
	  break;
	case 's':
	  if(argc<3)
	    usage();
	  else
	    steprate=atof(argv[2]);
	  argc--;
	  argv++;
	  break;
	case 'e':
	  auto_end=b_false;
	  if(argc<3)
	    usage();
	  else
	    endstage=atof(argv[2]);
	  argc--;
	  argv++;
	  break;
	case 'r':
	  if(argc<3)
	    usage();
	  else
	    corr=atof(argv[2]);
	  argc--;
	  argv++;
	  break;
	default:
	  printf("Unknown option!\n");
	  usage();
	  break;
	}

      argc--;
      argv++;
    }

  // check if the input file has been given:
  if(argc<2)
    {
      printf("Input measurement file has not been given!\n");
      usage();
    }
  
  // Read the measurements:
  char errmsg[1000];
  sd=get_sd_file(argv[1], &sdlen, errmsg, &zeropoint);  
  if(!sd || sdlen<=0)
    {
      printf("%s\n", errmsg);
      exit(0);
    }

  // Split the data into separate arrays:
  Q=new double[sdlen]; 
  h=new double[sdlen];
  dt=new DateTime[sdlen];
  for(i=0;i<sdlen;i++)
    {
      dt[i]=sd[i].dt;
      Q[i]=sd[i].q;
      h[i]=sd[i].h;
    }

  if(auto_end)
    endstage=find_statistics(h,sdlen,MIN)+10.0;

  // Check if a prior for h0 ought to be set:
  if(zeropoint!=MISSING_VALUE && noninfo_h0)
    {
      noninfo_h0=b_false;
	
      min_c=-zeropoint-0.1;
      max_c=-zeropoint+0.1;
    }
	
  // Set the prior for c=-h0:
  BAYES_RATINGCURVE_C_PRIOR c_priortype=noninfo_h0 ? BAYES_RATINGCURVE_C_NONINFO :
    BAYES_RATINGCURVE_C_NORMAL;
  if(!noninfo_h0 && min_c!=MISSING_VALUE && max_c!=MISSING_VALUE)
    {
      c_m=(min_c+max_c)/2.0;
      c_s=(max_c-min_c)/2.0/1.96;
    }

  // Set the prior for sigma^2 ~ IG(alpha, beta):
  if(noninfo_sigma)
    alpha=beta=0.0;
  else
    find_invgamma_distribution(min_s*min_s, max_s*max_s, 95.0, &alpha, &beta);
  
  // Set the prior for a and b:
  m1=(min_b+max_b)/2.0;
  s1=(max_b-min_b)/2.0/1.96;
  m2=(min_a+max_a)/2.0;
  s2=(max_a-min_a)/2.0/1.96;
  
  bayes_mcmc_ratingcurve mcmccurve;

  mcmccurve.draw_parameters(h,Q,sdlen,numsamples, m1, s1, m2, s2, corr, alpha, beta, 
			    c_priortype, c_m, c_s);
  
  FILE *f;
  if(do_file_output)
    f=fopen(output_file,"w");
  else
    f=stdout;

  // Fetch the main results:
  double med_C=exp(mcmccurve.get_median_a());
  double med_b=mcmccurve.get_median_b();
  double med_h0=-mcmccurve.get_median_c();
  double med_s=sqrt(mcmccurve.get_median_s2());
  double lower_C=exp(mcmccurve.get_a_percentile(0.025));
  double lower_b=mcmccurve.get_b_percentile(0.025);
  double lower_h0=-mcmccurve.get_c_percentile(0.025);
  double lower_s=sqrt(mcmccurve.get_s2_percentile(0.025));
  double upper_C=exp(mcmccurve.get_a_percentile(0.975));
  double upper_b=mcmccurve.get_b_percentile(0.975);
  double upper_h0=-mcmccurve.get_c_percentile(0.975);
  double upper_s=sqrt(mcmccurve.get_s2_percentile(0.975));

  // Show the rating curve parameters:
  fprintf(f, "Parameters for Q=C(h-h0)^b*noise (a=log(C), h0=-c):\n");
  fprintf(f, "Best curve estimate: Q=%7.3f(h-%6.2f)^%5.3f\n\n", med_C, med_h0,med_b);
  fprintf(f, "Parameter  Median   Lower 95%% cred   Upper 95%% cred\n");
  fprintf(f, "        C %7.3f          %7.3f          %7.3f\n", med_C, lower_C, upper_C);
  fprintf(f, "        b   %5.3f            %5.3f            %5.3f\n", 
	  med_b, lower_b, upper_b);
  fprintf(f, "       h0  %6.2f           %6.2f           %6.2f\n", 
	  med_h0, lower_h0, upper_h0);
  fprintf(f, "    sigma   %5.3f            %5.3f            %5.3f\n", 
	  med_s, lower_s, upper_s);
  
  if(show_table)
    {
      double stage, startstage=steprate*floor(lower_h0/steprate);
     
      while(mcmccurve.get_discharge_percentile(startstage,0.975)>=0.001)
	startstage-=steprate;

      fprintf(f, "\n");
      fprintf(f, "Stage-discharge table:\n");
      fprintf(f, "   Stage   Discharge  Lower 95%% cred  Upper 95%% cred\n");
      for(stage=startstage;stage<=endstage;stage+=steprate)
	fprintf(f, "%8.3f    %8.3f        %8.3f        %8.3f\n", stage,
		mcmccurve.get_median_coefficient_discharge(stage),
		mcmccurve.get_discharge_percentile(stage,0.025),
		mcmccurve.get_discharge_percentile(stage,0.975));
    }

  if(show_res)
    {
      
      fprintf(f, "\n");
      fprintf(f, "Residuals (in the logarithmic space):\n");

      if(dt[0]!=NoDateTime)
	fprintf(f,"            Time    Stage Residual\n");
      else
	fprintf(f,"Stage  Residual\n");

      for(i=0;i<sdlen;i++)
	{
	  if(dt[0]!=NoDateTime)
	    fprintf(f, "%s %8.3f %8.3f\n", dt[i].syCh(1), h[i], log(Q[i])-
		    log(mcmccurve.get_median_coefficient_discharge(h[i])));
	  else
	    fprintf(f, "%8.3f %8.3f\n", h[i], log(Q[i])-
		    log(mcmccurve.get_median_coefficient_discharge(h[i])));
	}
    }
}

