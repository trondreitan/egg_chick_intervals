#include <math.h>
#include <stream.h>
#include <stdlib.h>


enum statistics {BOLTZMANN=1, BOSE_EINSTEIN=2, FERMI_DIRAC=3};

void dice(int depth, int numsides, int prevdice, statistics stati, 
	  long int sum_so_far, long int *result, long int &totnum)
{
  int i, num=0;
  int start=1;
  if(stati==BOSE_EINSTEIN)
    start=prevdice>0 ? prevdice : 1;
  else if(stati==FERMI_DIRAC)
    start=prevdice+1;

  if(depth>1)
    {
      for(i=start;i<=numsides;i++)
	dice(depth-1, numsides, i, stati, sum_so_far+i, result, totnum);
    } 
  else
    {
      for(i=start;i<=numsides;i++)
	{
	  result[sum_so_far+i]++;
	  totnum++;
	}
    }
}


void usage(void)
{
  cout << "Usage: dice3 [-s] [-n] <number of dice>" << endl;
  cout << "Returns a stream of all possible sum of outcomes." << endl;
  cout << "Options: -s : toggles extra normal distribution" << endl;
  cout << "         -n : toggles number of outcomes rather than prob." << endl;
  cout << "         -B : Bose-Einstein statistics (default: Boltzmann)" << endl;
  cout << "         -F : Fermi-Dirac   statistics (default: Boltzmann)" << endl;
  cout << "         -S <sides> : Set the number of sides on the " << endl;
  cout << "                      dice (default 6)" << endl;
  cout << "         -c : Compare between statistics" << endl;
  cout << " Bexause of the statistics options, this is not a very" << endl;
  cout << " efficient program. A moderate number of dice (15) will make" << endl;
  cout << " the program go really slow." << endl;
  exit(0);
}


int main(int argc, char **argv)
{
  int showgauss=0, shownum=0; // output indicators
  statistics stat=BOLTZMANN;
  int numsides=6;
  int docompare=0;

  // Handle input arguments;
  while(argc>1 && argv[1][0]=='-')
    {
      switch(argv[1][1])
	{
	case 'c':
	  docompare=1;
	  break;
	case 'B':
	  stat=BOSE_EINSTEIN;
	  break;
	case 'F':
	  stat=FERMI_DIRAC;
	  break;
	case 's':
	  showgauss=1;
	  break;
	case 'S':
	  numsides=atoi(argv[2]);
	  argc--;
	  argv++;
	  break;
	case 'n':
	  shownum=1;
	  break;
	case 'h':
	case 'H':
	default:
	  usage();
	  break;
	}
      argc--;
      argv++;
    }

  if(argc!=2) // We need the number of dices
    usage();
  
  int numdice=atoi(argv[1]); // number of dices

  if(docompare)
    {
      // The number of different outcomes and different statistics;
      long int *number1=new long int[numdice*numsides+2], totnumber1=0L;
      long int *number2=new long int[numdice*numsides+2], totnumber2=0L;
      long int *number3=new long int[numdice*numsides+2], totnumber3=0L;
      int i; // count variable
      double mf=((double) numdice)*(double(numsides+1)/2.0) ,
	vf=double(numdice*numsides*(numsides-1))/12.0;
      
      // initialize the number of outcomes;
      for(i=0;i<numdice*numsides+2;i++)
	number1[i]=number2[i]=number3[i]=0L;
      
      // Do the caluclation of number of outcomes;
      dice(numdice, numsides, 0, BOLTZMANN,     0L, number1, totnumber1);
      dice(numdice, numsides, 0, BOSE_EINSTEIN, 0L, number2, totnumber2);
      dice(numdice, numsides, 0, FERMI_DIRAC,   0L, number3, totnumber3);
      
      // Caluclate the probabilities from the number of outcomes;
      long double *prob1=new long double[numdice*numsides+2];
      long double *prob2=new long double[numdice*numsides+2];
      long double *prob3=new long double[numdice*numsides+2];
      for(i=0;i<numdice*numsides+2;i++)
	{
	  prob1[i]=((long double) number1[i])/((long double) totnumber1);
	  prob2[i]=((long double) number2[i])/((long double) totnumber2);
	  prob3[i]=((long double) number3[i])/((long double) totnumber3);
	}
      
      // Output:
      char line[200];  
      sprintf(line,"# Column 1: sum(%ld terninger) - Boltzmann "
	      ,numdice);
      cout << line << endl;
      cout << "# Column 1 - type: filled bars" << endl;
      sprintf(line,"# Column 2: sum(%ld terninger) - Bose-Einstein "
	      ,numdice);
      cout << line << endl;
      cout << "# Column 2 - type: bars" << endl;
      sprintf(line,"# Column 3: sum(%ld terninger) - Fermi-Dirac "
	      ,numdice);
      cout << line << endl;
      cout << "# Column 3 - type: bars" << endl;
      if(showgauss)
	{
	  sprintf(line,"# Column 4: Normalfordeling, N(%lf, %lf)",
		  mf,vf);
	  cout << line << endl;
	}
      cout << "#################" << endl;
      for(i=0;i<numdice*numsides+2;i++)
	{
	  cout << i << " " << (shownum==0 ? prob1[i] : number1[i]) <<
	    " " << (shownum==0 ? prob2[i] : number2[i]) << " " <<
	    (shownum==0 ? prob3[i] : number3[i]);
	  if(showgauss)
	    cout << " -10000000";
	  cout << endl;
	}
      
      // extra output:
      if(showgauss)
	for(double x=0;x<=double(numsides*numdice)+2.0;x+=0.1)
	  cout << x << " -10000000 -10000000 -10000000 " << 
	    (shownum==0 ? 1.0 : totnumber1) *
	    exp(-(x-mf)*(x-mf)/2.0/vf-0.5*log(2.0*M_PI)-0.5*log(vf)) << endl;
    }
  else
    {
      // The number of different outcomes;
      long int *number=new long int[numdice*numsides+2], totnumber=0L;
      int i; // count variable
      double mf=((double) numdice)*(double(numsides+1)/2.0) ,
	vf=double(numdice*numsides*(numsides-1))/12.0;
      
      // initialize the number of outcomes;
      for(i=0;i<numdice*numsides+2;i++)
	number[i]=0L;
      
      // Do the caluclation of number of outcomes;
      dice(numdice, numsides, 0, stat, 0L, number, totnumber);
      
      // Caluclate the probabilities from the number of outcomes;
      long double *prob=new long double[numdice*numsides+2];
      for(i=0;i<numdice*numsides+2;i++)
	prob[i]=((long double) number[i])/((long double) totnumber);
      
      // Output:
      char line[200];  
      sprintf(line,"# Column 1: sum(%ld terninger) - totalt antall=%d "
	      ,numdice,totnumber);
      cout << line << endl;
      cout << "# Column 1 - type: bars" << endl;
      if(showgauss)
	{
	  sprintf(line,"# Column 2: Normalfordeling, N(%lf, %lf)",
		  mf,vf);
	  cout << line << endl;
	}
      cout << "#################" << endl;
      for(i=0;i<numdice*numsides+2;i++)
	{
	  cout << i << " " << (shownum==0 ? prob[i] : number[i]);
	  if(showgauss)
	    cout << " -10000000";
	  cout << endl;
	}
      
      // extra output:
      if(showgauss)
	for(double x=0;x<=double(numsides*numdice)+2.0;x+=0.1)
	  cout << x << " -10000000 " << (shownum==0 ? 1.0 : totnumber) *
	    exp(-(x-mf)*(x-mf)/2.0/vf-0.5*log(2.0*M_PI)-0.5*log(vf)) << endl;
      
    }

  return 0;
}
