#include <cmath>
#include <stdio.h>
#include <hydrasub/hydrabase/divfunc.H>

void usage(void)
{
  printf("Usage: make_stagedischarge <output fil> <num meas> <start stage> "
	 "<end stage>\n");
  printf("                           <measurement noise> "
	 "<number of segments>\n");
  printf("                           <a1> <b1> <h01> [<hs1> <b2> <h02> "
	 "[...]]\n");
  exit(0);
}

int main(int argc, char **argv)
{
  if(argc<10)
    usage();
  
  randify();

  double s=atof(argv[5]), hstart=atof(argv[3]), hend=atof(argv[4]);
  int i,j,numseg=atoi(argv[6]), len=atoi(argv[2]);
  if(argc!=7+3*numseg)
    usage();

  double *a=new double[numseg], *b=new double[numseg], *h0=new double[numseg],
    *hs=new double[numseg];

  
  a[0]=atof(argv[7]);
  b[0]=atof(argv[8]);
  h0[0]=atof(argv[9]);
  hs[0]=MISSING_VALUE;

  for(i=1;i<numseg;i++)
    {
      hs[i]=atof(argv[7+3*i]);
      b[i]=atof(argv[7+3*i+1]);
      h0[i]=atof(argv[7+3*i+2]);
      a[i]=a[i-1]+b[i-1]*log(hs[i]-h0[i-1])-b[i]*log(hs[i]-h0[i]);
    }
  
  FILE *f=fopen(argv[1], "w");
  for(i=0;i<len;i++)
    {
      double h=hstart+double(i)*(hend-hstart)/double(len-1);

      for(j=1;j<numseg;j++)
	if(h<hs[j])
	  break;
      j--;
      
      if(h>h0[j])
	fprintf(f,"%7.5f %7.5f\n", h, exp(a[j]+b[j]*log(h-h0[j])+s*gauss()));
      else
	fprintf(f,"%7.5f 0\n", h);
    }
  fclose(f);
}
