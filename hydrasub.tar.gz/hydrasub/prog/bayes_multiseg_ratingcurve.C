#include "bayes_multiseg_ratingcurve.H"
#include <cmath>

void bmr_show_stagedischarge::load_file(char *filename, int type)
{
  ssp.reset_standards();
  show_stagedischarge::load_file(filename, type);
  
  ssp.create(*this, get_stage(), get_discharge(), num_data());
  pt->set_infile_name(filename);
}

void bmr_show_stagedischarge::
create_and_connect(widget parent, bayes_multiseg_ratingcurve *ipt)
{
  pt=ipt;

  int i, numatt=3;
  char **attrib=new char*[3], **altnames=new char*[3];
  TABLE_CONTENT *content=new TABLE_CONTENT[3];
  
  for(i=0;i<numatt;i++)
    {
      attrib[i]=new char[100];
      altnames[i]=new char[100];
    }
  
  strcpy(attrib[0], "time");
  strcpy(altnames[0], WHAT((char *) "     Tid        ", 
			   (char *) "     Time       "));
  content[0]=TABLE_DATETIME;

  
  strcpy(attrib[1], "stage");
  strcpy(altnames[1], WHAT((char *) "Vannstand ", 
			   (char *) " Stage    "));
  content[1]=TABLE_DOUBLE;

  strcpy(attrib[2], "discharge");
  strcpy(altnames[2], WHAT((char *) "Vannf�ring", 
			   (char *) "Discharge "));
  content[2]=TABLE_DOUBLE;


  create(parent, NULL, NULL, NULL, NULL,
	 attrib, content, numatt, altnames);
}


void bayes_multiseg_ratingcurve_button::Create(widget parent, char *txt,   
                                         bayes_multiseg_ratingcurve *ipt,
                                         BAYES_MULTISEG_PROG_ACTION action_type)
{
  build(parent, txt);
  pt=ipt;
  type=action_type;
}

void bayes_multiseg_ratingcurve_button::pushed(void)
{
  pt->take_action(type);
}

void bayes_multiseg_stagedischarge_toggle::Create(widget parent, char *txt, 
						  bayes_multiseg_ratingcurve *ipt)
{
  pt=NULL;
  build(parent,txt);
  pt=ipt;
}

void bayes_multiseg_stagedischarge_toggle::pushed(Boolean state)
{
  if(pt)
    pt->stage_discharge_change(state);
}


bayes_interactive_multiseg_showcurve::
bayes_interactive_multiseg_showcurve(bayes_multiseg_ratingcurve *ipt) : 
bayes_multiseg_showcurve()
{
  pt=ipt;
}

void bayes_interactive_multiseg_showcurve::cancel(void)
{
  pt->showcurve_cancelled();
}

void bayes_interactive_multiseg_showcurve::
preview_done(int recommended_spacing, int workload_,
	     double analysistime, double showcurvetime,
	     boolean recommend_increased_burnin_and_tempering)
{
  pt->preview_done(recommended_spacing, workload_, 
		   analysistime, showcurvetime,
		   recommend_increased_burnin_and_tempering);
}
  
void bayes_interactive_multiseg_showcurve::
accept( // analysis results:
       segmented_curve *ret_curve,
       double ret_curve_prob,
       segmented_curve_analysis *ret_analysis,
       
       // prior:
       segmented_priors *ret_prior,
       
       // background data:
       tablelist *ret_measurements,
       double *ret_q, double *ret_h, 
       DateTime *ret_dt, int ret_num_meas,
       
       // quality judgement:
       int ret_total_quality, char *ret_comment, 
       int ret_trend_quality, int ret_trend_importance,
       int ret_trend_visual_importance,
       int ret_uncert_quality, int ret_uncert_importance,
       int ret_uncert_visual_importance,
       int ret_outlier_quality, int ret_outlier_importance,
       int ret_outlier_visual_importance,
       int ret_fit_quality, int ret_fit_importance,
       
       // quality measures:
       char *ret_description,
       double ret_p_outlier, double ret_p_trend_time, 
       double ret_p_abstrend_time, double ret_p_trend_stage, 
       double ret_p_abstrend_stage, double ret_max_rel_uncert, 
       double ret_min_rel_uncert, double ret_norm_rel_uncert,
       double ret_h0_uncert, double ret_b_uncert, 
       double ret_sigma_median)
{
  pt->curve_accepted(ret_curve, ret_curve_prob, ret_analysis,
		     ret_prior, ret_measurements, ret_q, ret_h, 
		     ret_dt, ret_num_meas,
		     ret_total_quality, ret_comment, 
		     ret_trend_quality, ret_trend_importance,
		     ret_uncert_quality, ret_uncert_importance,
		     ret_outlier_quality, ret_outlier_importance,
		     ret_fit_quality, ret_fit_importance,
		     ret_description, ret_p_outlier, ret_p_trend_time, 
		     ret_p_abstrend_time, ret_p_trend_stage, 
		     ret_p_abstrend_stage, ret_max_rel_uncert, 
		     ret_min_rel_uncert, ret_norm_rel_uncert,
		     ret_h0_uncert, ret_b_uncert, 
		     ret_sigma_median);
}


void bayes_multiseg_savesel::Create(bayes_multiseg_ratingcurve *ipt)
{
  pt=ipt;
  sh.build(mainwin::toplevel, WHAT((char * ) "Velg lagringsfil", 
				   (char *) "Choose file for saving"));
  v1.build(sh);
  build(v1);
  sh.Map();
}

void bayes_multiseg_savesel::ok(char *filename)
{
  if(pt)
    pt->save_on_file(filename);
  sh.Unmap();
}

void bayes_multiseg_savesel::cancel(void)
{
  sh.Unmap();
}

void bayes_multiseg_printershell::create(bayes_multiseg_ratingcurve *ipt)
{
  pt=ipt;
  Create();
}

void bayes_multiseg_printershell::ok_pushed(char *newprinter)
{
  if(pt)
    pt->printer_changed(newprinter);
}

bayes_multiseg_ratingcurve::bayes_multiseg_ratingcurve(int argc, 
						       char **argv) : 
  mainwin("bayes_multiseg_ratingcurve5", argc, argv)
{
  randify();
  
  v1.build(*this);
  h2.build(v1);
  st.create_and_connect(h2, this);
  v2.build(h2);
  sdtog.Create(v2, WHAT((char *) "Vannstand langs x-aksen", 
			(char *) "Stage along the x axis"), this);
  sp.Create(v1, 850,300, &st);
  st.connect_to_plot(&sp);

  h1.build(v1);
  exitb.Create(h1, WHAT((char *) "Avslutt", (char *) "Exit"),
	       this, BAYES_MULTISEG_PROG_EXIT);
  exitb.Background("red");
  exitb.Foreground("white");
  spacelab.build(h1, "         ");
  previewb.Create(h1, WHAT((char *) "Kvikk f�ranalyse",
			   (char *) "Preview"), this,
		  BAYES_MULTISEG_PROG_PREVIEW);
  previewb.Background("yellow");
  previewb.Foreground("black");
  generateb.Create(h1, WHAT((char *) "Generer vannf�ringskurve",
			    (char *) "Generate ratingcurve"), 
		   this,BAYES_MULTISEG_PROG_GENERATE);
  generateb.Background("green");
  generateb.Foreground("black");
  generateb.InSensitive();
  showpriorsb.Create(h1, WHAT((char *) "Vis/rediger f�rkunnskap", 
			      (char *) "Show/edit priors"), 
		     this, BAYES_MULTISEG_PROG_SHOWPRIORS);
  options_startb.Create(h1, WHAT((char *) "Opsjoner", 
				 (char *) "Options"), 
			this, BAYES_MULTISEG_PROG_OPTIONS_START);
  options_startb.InSensitive();

  burnin=10000;
  num_temp=1;
  spacing=10; /* spacing=100; */
  num_preview=1000;
  num_generate=2000;
  
  optwin.build(*this, WHAT((char *) "Opsjoner", (char *) "Options"));
  optv1.build(optwin);
  generatenumf.build(optv1, 7, 
		     WHAT((char *) "Antall trekninger i generering av kurve:",
                       (char *) "Number of samples when generating curve:"));
  previewnumf.build(optv1, 6, WHAT((char *) "Antall trekninger i f�ranalyse:", 
				   (char *) "Number of samples in preview:")); 
  burninf.build(optv1, 6, WHAT((char *) "Antall trekninger i 'burnin':", 
			       (char *) "Number of samples during 'burnin':"));
  spacingf.build(optv1, 4, WHAT((char *) "Antatt avstand mellom "
				"uavhengige trekninger:", 
				(char *) "Assumed distance between independent"
				" samples:"));
  numtempf.build(optv1, 2, WHAT((char *) "Antall temperaturer i "
				"tempering-algoritme:", 
				(char *) "Number of temperatures in "
				"tempering algorithm:"));
  opth1.build(optv1);
  optokb.Create(opth1, WHAT((char *) "OK", (char *) "OK"), this,
		BAYES_MULTISEG_PROG_OPTIONS_OK);
  optokb.Background("green");
  optokb.Foreground("black");
  optcancelb.Create(opth1, WHAT((char *) "Avbryt", (char *) "Cancel"), this,
		    BAYES_MULTISEG_PROG_OPTIONS_CANCEL);
  optcancelb.Background("red");
  optcancelb.Foreground("white");

  curve=NULL;
}

void bayes_multiseg_ratingcurve::take_action(BAYES_MULTISEG_PROG_ACTION action)
{
  switch(action)
    {
    case BAYES_MULTISEG_ChANGEPRINTER:
      changeprinter();
      break;
    case BAYES_MULTISEG_PRINTRES:
      do_print();
      break;
    case BAYES_MULTISEG_SAVERES:
      startsave();
      break;
    case BAYES_MULTISEG_CLOSERES:
      reswin.Unmap();
      break;
    case BAYES_MULTISEG_PROG_GENERATE:
      doanalysis(False);
      break;
    case BAYES_MULTISEG_PROG_SHOWPRIORS:
      show_priors();
      break;
    case BAYES_MULTISEG_PROG_OPTIONS_START:
      show_options();
      break;
    case BAYES_MULTISEG_PROG_OPTIONS_OK:
      options_ok();
      break;
    case BAYES_MULTISEG_PROG_OPTIONS_CANCEL:
      options_cancel();
      break;
    case BAYES_MULTISEG_PROG_PREVIEW:
      doanalysis(True);
      break;
    case BAYES_MULTISEG_PROG_EXIT:
      do_exit();
      break;
    }
}

void bayes_multiseg_ratingcurve::showcurve_cancelled(void)
{
  // NOP
}

void bayes_multiseg_ratingcurve::preview_done(int recommended_spacing, 
					      int workload,
					      double analysistime, 
					      double showcurvetime,
	     boolean recommend_increased_burnin_and_tempering)
{
  spacing=recommended_spacing;
  spacingf.SetDigit(recommended_spacing);
  preview_workload=workload;
  preview_analysistime=analysistime;
  preview_showcurvetime=showcurvetime;

  generateb.Sensitive();
  options_startb.Sensitive();

  if(recommend_increased_burnin_and_tempering)
    {
      burnin*=2;

      if(num_temp>=3)
	{
	  mess3.build(mainwin::toplevel, WHAT((char *) "Melding", 
					      (char *) "Message"),
		      WHAT((char *) "Problematisk f�ranalyse, men automatisk "
			   "oppgradering av kj�re-ressursene kan ikke lenger\n "
			   "foretas. Kj�r med r�dende ressurser eller sett de opp "
			   "maunelt med 'opsjoner'.",
			   (char *) "Problematic pre-analysis, but automatic "
			   "upgrading of resources can no longer be performed.\n"
			   "Try running with current resources or set the resources "
			   "manually with 'options'."));
	  return;
	}
      else
	{
	  mess3.build(mainwin::toplevel, WHAT((char *) "Melding", 
					      (char *) "Message"),
		      WHAT((char *) "Problematisk f�ranalyse gj�r at kj�re-ressursene "
			   "er blitt automatisk oppgradert. En ny f�ranalyse er � "
			   "anbefale.", 
			   (char *) "A problematic pre-analysis has made the program "
			   "upgrade the resources (and the run time) automatically.\n"
			   "It is recommended that a new pre-analysis be performed."));
	  num_temp++;
	}
    }
}

void bayes_multiseg_ratingcurve::
curve_accepted( // analysis results:
	       segmented_curve *ret_curve, double ret_curve_prob,
	       segmented_curve_analysis *ret_analysis,
	       
	       // prior:
	       segmented_priors *ret_prior,
		      
	       // background data:
	       tablelist *ret_measurements,
	       double *ret_q, double *ret_h, 
	       DateTime *ret_dt, int ret_num_meas,
		      
	       // quality judgement:
	       int ret_total_quality, char *ret_comment, 
	       int ret_trend_quality, int ret_trend_importance,
	       int ret_uncert_quality, int ret_uncert_importance,
	       int ret_outlier_quality, int ret_outlier_importance,
	       int ret_fit_quality, int ret_fit_importance,
	       
	       // quality measures:
	       char *ret_description,
	       double ret_p_outlier, double ret_p_trend_time, 
	       double ret_p_abstrend_time, double ret_p_trend_stage, 
	       double ret_p_abstrend_stage, double ret_max_rel_uncert, 
	       double ret_min_rel_uncert, double ret_norm_rel_uncert,
	       double ret_h0_uncert, double ret_b_uncert, 
	       double ret_sigma_median)
{
  reswin.build(mainwin::toplevel, WHAT((char *) "Result-vindu", 
				       (char *) "Result window"));
  resv1.build(reswin);
  restext.build(resv1, 100, 35);
  resh1.build(resv1);
  rescloseb.Create(resh1, WHAT((char *) "Lukk vindu", (char *) "Close window"),
		   this, BAYES_MULTISEG_CLOSERES);
  rescloseb.Background("red");
  rescloseb.Foreground("white");
  printb.Create(resh1, WHAT((char *) "Skriv ut", (char *) "Print"), this, 
		BAYES_MULTISEG_PRINTRES);
  printb.Background("blue");
  printb.Foreground("black");
  printlab.build(resh1, WHAT((char *) "Skriver: %s", (char *) "Printer: %s"), 
		 getenv("PRINTER"));
  printlab.Background("white");
  printlab.Foreground("black");
  changeprinterb.Create(resh1, WHAT((char *) "Forandre skriver", 
				    (char *) "Change printer"),
			this, BAYES_MULTISEG_ChANGEPRINTER);
  saveb.Create(resh1, WHAT((char *) "Lagre p� fil", 
			   (char *) "Save results on file"),
	       this, BAYES_MULTISEG_SAVERES);
  saveb.Background("green");
  saveb.Foreground("black");

  reswin.Map();

  char line[10000];

  sprintf(line, WHAT((char *) "Analyse av datasett hentet fra filen '%s'\n\n",
		     (char *) "Analysis of a dataset from the file '%s'\n\n"),
	  infile_name);
  strcpy(line+strlen(line), WHAT((char *) "Estimert vannf�ringskurve: Q(h)=\n", 
		    (char *) "Estimated stage-discharge rating curve: Q(h)=\n"));
  int numseg=ret_curve->get_numseg();
  for(int i=1;i<=numseg;i++)
    {
      if(ret_curve->get_h0(i)>0.0)
	sprintf(line+strlen(line), "%7.4f (h-%5.3f)^%-6.4f",
		exp(ret_curve->get_a(i)), ret_curve->get_h0(i),
		ret_curve->get_b(i));
      else
	sprintf(line+strlen(line), "%7.4f (h+%5.3f)^%-6.4f",
		exp(ret_curve->get_a(i)), -ret_curve->get_h0(i),
		ret_curve->get_b(i));
      if(i<numseg)
	sprintf(line+strlen(line), "   for h<%5.3f", ret_curve->get_hs(i));
      strcpy(line+strlen(line), "\n");
    }

  strcpy(line+strlen(line), "\n");
  sprintf(line+strlen(line), WHAT((char *) "Estimert m�lest�y: %5.2f%%\n\n", 
				  (char *) "Estimated measurement noise level: "
				  "%5.2f%%\n\n"),
	  ret_curve->get_sigma()*100.0);
  
  strcpy(line+strlen(line), "**********************************************\n\n");
  strcpy(line+strlen(line), ret_description);
  strcpy(line+strlen(line), "\n\n**********************************************\n\n");

  char *qualnames[]={WHAT((char *) "Bra", (char *) "Good"),
		     WHAT((char *) "Medium", (char *) "Medium"), 
		     WHAT((char *) "D�rlig", (char *) "Bad"), 
		     WHAT((char *) "Ubrukelig", (char *) "Unusable") };
  sprintf(line+strlen(line), WHAT((char *) "Total kvalitet: %d (%s)\n\n",
				  (char *) "Total quality: %d (%s)\n\n"),
	  ret_total_quality, qualnames[4-ret_total_quality]);
  sprintf(line+strlen(line), WHAT((char*) "Kommentar: %s\n\n", 
				  (char *) "Comment: %s\n\n"), ret_comment);
  strcpy(line+strlen(line), "**********************************************\n\n");

  restext+=line;
}

void bayes_multiseg_ratingcurve::stage_discharge_change(Boolean stage_argument)
{
  sp.set_stage_as_argument(stage_argument);
}

void bayes_multiseg_ratingcurve::show_options(void)
{
  generatenumf.SetDigit(num_generate);
  previewnumf.SetDigit(num_preview);
  burninf.SetDigit(burnin);
  spacingf.SetDigit(spacing);
  numtempf.SetDigit(num_temp);
  optwin.Map();
}

void bayes_multiseg_ratingcurve::options_ok(void)
{
  num_generate=generatenumf.getdigit();
  num_preview=previewnumf.getdigit();
  burnin=burninf.getdigit();
  spacing=spacingf.getdigit();
  num_temp=numtempf.getdigit();
  optwin.Unmap();
}

void bayes_multiseg_ratingcurve::options_cancel(void)
{
  optwin.Unmap();
}

void bayes_multiseg_ratingcurve::show_priors(void)
{
  ssp.show_again();
}

void bayes_multiseg_ratingcurve::startsave(void)
{
  savesel.Create(this);
}

void bayes_multiseg_ratingcurve::do_print(void)
{
  FILE *p=popen("lpr","w");
  fprintf(p, "%s", restext.GetText());
  fclose(p);
}

void bayes_multiseg_ratingcurve::changeprinter(void)
{
  prsh.create(this);
}

void bayes_multiseg_ratingcurve::set_infile_name(char *filename)
{
  strcpy(infile_name, filename);
}

void bayes_multiseg_ratingcurve::save_on_file(char *filename)
{
  FILE *f=fopen(filename,"w");

  if(!f)
    {
      err.build(mainwin::toplevel, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kunne ikke skrive til fil!",
		     (char *) "Could not write to file!"));
      return;
    }

  fprintf(f, "%s", restext.GetText());
  fclose(f);
}

void bayes_multiseg_ratingcurve::printer_changed(char *newprinter)
{
  printlab.labelString(WHAT((char *) "Skriver: %s", (char *) "Printer: %s"), newprinter);
}

void bayes_multiseg_ratingcurve::do_exit(void)
{
  mess.build(*this, WHAT((char *) "Sp�rsm�l", (char *) "Question"),
	     WHAT((char *) "�nsker du � avslutte?",
		  (char *) "Do you wish to exit?"));
  if(mess.ok_or_cancel(WHAT((char *) "Ja", (char *) "Yes"),
		       WHAT((char *) "Nei", (char *) "No")))
    exit(0);
}

void bayes_multiseg_ratingcurve::doanalysis(Boolean is_preview)
{
  int altlen;
  char **altnames=st.get_altname(&altlen);

  if(!is_preview)
    {
      int new_workload=burnin*num_temp+spacing*num_generate*num_temp+
	20*num_generate;
      double projected_time=double(new_workload)/double(preview_workload)*
	preview_analysistime+
	preview_showcurvetime*double(num_generate)/double(num_preview);
      int proj_time=(int) ceil(projected_time);
      int proj_min=proj_time/60;
      int proj_sec=proj_time%60;
      char message[1000];
      sprintf(message, WHAT((char *) "Antatt tid: %d min., %d sek.", 
			    (char *) "Projected time: %d min., %d sec."), 
	      proj_min, proj_sec);

      if(projected_time>60.0*10.0)
	{
	  sprintf(message+strlen(message), WHAT((char *) " Fortsett?",
						(char *) " Continue?"));
	  mess.build(mainwin::toplevel, WHAT((char *) "Sp�rsm�l", 
					     (char *) "Question"),
		     message);
	  if(!mess.ok_or_cancel(WHAT((char *) "Ja", (char *) "Yes"),
				WHAT((char *) "Nei", (char *) "No")))
	    {
	      mess2.build(mainwin::toplevel, WHAT((char *) "Melding",
						  (char *) "Message"),
			  WHAT((char *) "Opsjoner kan settes slik at "
			       "mindre tid blir brukt.",
			       (char *) "Options can be set to reduce the "
			       "time spent on the analysis."));
	      return;
	    }
	}
      else
	{
	  mess.build(mainwin::toplevel,  WHAT((char *) "Melding",
					      (char *) "Message"),
		     message);
	  Set(1000);
	  return;
	}
    }

  AddWorkCursor(*this);
  if(curve)
    delete curve;
  curve=new bayes_interactive_multiseg_showcurve(this);
  curve->create(st.get_selected(), &ssp,
		altnames, altlen, is_preview, 
		is_preview ? num_preview : num_generate, 
		is_preview ? 10 : spacing, 
		is_preview ? 1000 : burnin, num_temp, sdtog(),
		infile_name);
  RmWorkCursor(*this);
}

void bayes_multiseg_ratingcurve::wakeup(void) // used for not previewing
{
  int is_preview=0;
  int altlen;
  char **altnames=st.get_altname(&altlen);

  AddWorkCursor(*this);
  if(curve)
    delete curve;
  curve=new bayes_interactive_multiseg_showcurve(this);
  curve->create(st.get_selected(), &ssp,
		altnames, altlen, is_preview, 
		is_preview ? num_preview : num_generate, 
		is_preview ? 10 : spacing, 
		is_preview ? 1000 : burnin, num_temp, sdtog(), infile_name);
  mess.Unmap();
  RmWorkCursor(*this);
}

int main(int argc, char **argv)
{
  bayes_multiseg_ratingcurve tt(argc,argv);
  tt.Run();

  return 0;
}
