// $Id: nmod.C 997 2006-11-29 09:37:46Z bjg $
// $URL: svn://overfloden/hydra/trunk/source/prog/2SEG/nmod.C $
#include <hydrasub/hydrabase/divfunc.H>
#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/stagedischarge.H>
#include <hydrasub/hydrabase/regression.H>
#include <hydrasub/hydrabase/linalg.H>
#include <gsl/gsl_randist.h>
#include <cmath>
 


double Bj(double h_curr, double *h0, double *hs, int seg, int numseg)
{
  if(seg<0 || seg>=numseg)
    return MISSING_VALUE;

  double ret;

  if(seg>=1 && h_curr<hs[seg-1])
    ret=0.0;
  else if(h_curr<h0[seg])
    return MISSING_VALUE;
  else
    {
      if(seg==0 && (numseg==1 || h_curr<hs[seg]))
	ret=log(h_curr-h0[seg]);
      else if(seg==(numseg-1) || h_curr<hs[seg])
	ret=log(h_curr-h0[seg])-log(hs[seg-1]-h0[seg]);
      else // h_curr>=hs[seg]
	{
	  if(seg==0)
	    ret=log(hs[seg]-h0[seg]);
	  else
	    ret=log(hs[seg]-h0[seg])-log(hs[seg-1]-h0[seg]);
	}
    }

  return ret;
}

double find_SS(double *h, double *q, int len, double a1, double *b, 
	       double *h0,double *hs, int numseg)
{
  double SS=0.0, res;
  int i,j;

  for(i=0;i<len;i++)
    {
      for(j=0;j<numseg;j++)	
	if(b[j]==MISSING_VALUE)
	  return 1e+216;
      
      res=q[i]-a1;
      for(j=0;j<numseg;j++)
	{
	  double bj=Bj(h[i],h0,hs,j,numseg);
	  if(bj==MISSING_VALUE)
	    return MISSING_VALUE;

	  if(!(bj>-1e+100 && bj<1e+100))
	    {
	      cout << " noe er galt!" << endl;
	      bj=Bj(h[i],h0,hs,j,numseg);
	      return MISSING_VALUE;
	    }

	  res-=b[j]*bj;
	}
      
      SS+=res*res;
    }
  
  return SS;
}

double logprob(double *q, double *h, int len, double hmin, 
	       double hmax, double a1, double *b, double *hs, double *h0, 
	       double s2, double **var, double *m,
	       double mu_q, double sigma2_q, double sigma_a, double sigma_b, 
	       double mu_h02, double sd_h02, double T, int numseg,
	       double h01_m=MISSING_VALUE, double h01_s2=MISSING_VALUE, 
	       double h02_m=MISSING_VALUE, double h02_s2=MISSING_VALUE,
	       double hs_m=MISSING_VALUE, double hs_s2=MISSING_VALUE)
{
  int i, j;
  double n=(double) len;
  
  function_timer::start_timer(4);
  
  if(hmin<h0[0])
    return -1e+216;

  for(i=0;i<(numseg-1);i++)
    if(h0[i+1]>hs[i] || h0[i]>hs[i] || hs[i]<hmin || hs[i]>hmax)
      return -1e+216;

  for(i=0;i<(numseg-2);i++)
    if(hs[i]>=hs[i+1])
      return -1e+216;

  if(s2<0.0)
    return -1e+216;

  // contrubtion from (beta-m)V^(-1)(beta-m);
  int dim=numseg+1;
  double *beta=new double[dim];
  beta[0]=a1;
  for(j=0;j<numseg;j++)
    beta[j+1]=b[j];

  double *a=new double[numseg];
  a[0]=a1;
  for(j=1;j<numseg;j++)
    a[j]=a[j-1]+b[j-1]*log(hs[j-1]-h0[j-1])-b[j]*log(hs[j-1]-h0[j]);

  double contrib_pri_beta = multinormal_pdf(beta,m,var,numseg+1,b_true);
  double contrib_h01=0.0;
  double contrib_hs=0.0;
  for(j=0;j<(numseg-1);j++)
    contrib_hs+=log(ABSVAL(b[j]))-0.5*log(2.0*M_PI*sigma2_q)-
      0.5*(a[j]+b[j]*log(hs[j]-h0[j])-mu_q)*(a[j]+b[j]*log(hs[j]-h0[j])-mu_q)/
      sigma2_q;
  double contrib_h02=0.0; 
  //-0.5*(h02-h01-mu_h02)*(h02-h01-mu_h02)/sd_h02/sd_h02;
  for(j=0;j<(numseg-1);j++)
    contrib_h02+=log(sqrt(2.0)/sd_h02)-ABSVAL((h0[j+1]-h0[j]-mu_h02))*
      sqrt(2.0)/sd_h02;

  if(h01_m!=MISSING_VALUE && h01_s2!=MISSING_VALUE)
    contrib_h01=-0.5*(h0[0]-h01_m)*(h0[0]-h01_m)/h01_s2;
  if(numseg>1 && h02_m!=MISSING_VALUE && h02_s2!=MISSING_VALUE)
    {
      contrib_h02=0.0;
      for(j=1;j<numseg;j++)
	contrib_h02-=0.5*(h0[j]-h02_m)*(h0[j]-h02_m)/h02_s2;
    }
  if(hs_m!=MISSING_VALUE && hs_s2!=MISSING_VALUE)
    for(j=0;j<(numseg-1);j++)
      contrib_hs-=0.5*(hs[j]-hs_m)*(hs[j]-hs_m)/hs_s2;

  // contribution from (sigma�)^-(a+2+n/2)*exp(-b/sigma�)
  double contrib_s2 = - (sigma_a+1.0)*log(s2) - sigma_b/s2;
  
  double SS=find_SS(h, q,len,a1,b,h0,hs,numseg);

  if(SS==MISSING_VALUE)
    return -1e+216;

  // contribution from the exponensial data part of the likelihood function;
  double contrib_lik=-0.5*n*log(s2)-SS/2.0/s2;
  //cout << "logprob :" << contrib_lik << " " << SS << 
  // " " << n << " " << s2 << " " <<
  // -0.5*n*log(s2)-SS/2.0/s2 << endl;

  double ret = contrib_pri_beta +contrib_s2 +
    contrib_h01+contrib_h02 +contrib_hs +contrib_lik;

  delete [] beta;
  delete [] a;

  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;

  function_timer::stop_timer(4);

  return ret/T;
}

double gibbs_sigma2(double *h, double *q, int len, 
		    double sigma_a, double sigma_b, 
		    double a1, double *b, double *hs,
		    double *h0, double T, gsl_rng *rptr,
		    int num_seg)
{
  function_timer::start_timer(5);

  double n=(double) len;
  double sigma_a_star=sigma_a+n/2.0;
  double sigma_b_star=sigma_b;

  sigma_b_star+=find_SS(h, q,len,a1,b,h0,hs,num_seg)/2.0;
  
  if(T!=1.0)
    {
      sigma_a_star=(sigma_a_star+1.0-T)/T;
      sigma_b_star/=T;
    }

  double s2=1.0/gsl_ran_gamma(rptr, sigma_a_star, 1.0/sigma_b_star);

  function_timer::stop_timer(5);

  return s2;
}

void get_linear_proposal_hyperparameters(double *h, double *q, int len,
					 double *m, double **V,
					 double *hs, double *h0,
					 double s2, double T, int numseg,
					 double **m_star_, double ***V_star_)
{
  function_timer::start_timer(1);
  
  int dim=numseg+1;
  double **XtX=new double*[dim], **V_star, 
    **inv_V_star=new double*[dim], **inv_V;
  int i,j,k;
  double **X=new double*[len];
  
  function_timer::start_timer(0);
  inv_V=inverse_matrix(V,dim);
  function_timer::stop_timer(0);
  
  function_timer::start_timer(2);
  for(j=0;j<dim;j++)
    {
      XtX[j]=new double[dim];
      for(k=0;k<dim;k++)
	XtX[j][k]=0.0;
    }
  for(j=0;j<dim;j++)
    inv_V_star[j]=new double[dim];

  function_timer::start_timer(3);
  for(i=0;i<len;i++)
    {
      X[i]=new double[dim];
      X[i][0]=1.0;
      for(j=0;j<numseg;j++)
	X[i][j+1]=Bj(h[i],h0,hs,j,numseg);
	  
      for(j=0;j<dim;j++)
	for(k=j;k<dim;k++)
	  XtX[j][k] += X[i][j]*X[i][k];
    }
  for(j=0;j<dim;j++)
    for(k=0;k<j;k++)
      XtX[j][k]=XtX[k][j];
  function_timer::stop_timer(3);
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      inv_V_star[j][k]=inv_V[j][k]+XtX[j][k]/s2;
  function_timer::stop_timer(2);

  function_timer::start_timer(0);
  V_star=inverse_matrix(inv_V_star,dim);
  function_timer::stop_timer(0);
  
  double *m_star_raw=new double[dim], *m_star=new double[dim];
  
  function_timer::start_timer(2);
  for(j=0;j<dim;j++)
    m_star_raw[j]=m_star[j]=0.0;
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      m_star_raw[j]+=inv_V[j][k]*m[k];
  for(i=0;i<len;i++)
    for(j=0;j<dim;j++)
      m_star_raw[j]+=q[i]*X[i][j]/s2;
  
  for(j=0;j<dim;j++)
    for(k=0;k<dim;k++)
      m_star[j]+=V_star[j][k]*m_star_raw[k];

  doubledelete(X,len);
  doubledelete(XtX,dim);
  doubledelete(inv_V_star,dim);
  doubledelete(inv_V,dim);
  delete [] m_star_raw;

  if(T!=1.0)
    for(j=0;j<dim;j++)
      for(k=0;k<dim;k++)
	V_star[j][k]*=T;
  function_timer::stop_timer(2);

  *m_star_=m_star;
  *V_star_=V_star;

  function_timer::stop_timer(1);
}

double gibbs_linear(double *h, double *q, int len,
		    double *m, double **V,
		    double *hs, double *h0, 
		    double s2, double T, int numseg,
		    double *new_a1, double **new_b, 
		    gsl_rng *rptr)
{
  double *m_star, **V_star, ret;
  int j,dim=numseg+1;

  get_linear_proposal_hyperparameters(h, q, len, m, V, hs, h0, s2, T, numseg,
				      &m_star, &V_star);

  function_timer::start_timer(6);
  double **samples=sample_from_multinormal(1,m_star,V_star,dim,rptr);
  
  double *b=new double[numseg];

  *new_a1=samples[0][0];
  for(j=0;j<numseg;j++)
    b[j]=samples[0][j+1];
  *new_b=b;

  ret=multinormal_pdf(samples[0],m_star,V_star,dim,b_true);
  function_timer::stop_timer(6);
  
  delete [] m_star;
  doubledelete(V_star,dim);
  doubledelete(samples,1);
  
  return ret;
}

double get_proposal_logdensity(double *h, double *q, int len,
			       double *m, double **V, double s2, double *hs,
			       double prop_a1, double *prop_b,
			       double *prop_h0, double T, int numseg)
{
  int j, dim=numseg+1;
  double *m_star, **V_star;
  double ret, *beta=new double[dim];
  
  beta[0]=prop_a1;
  for(j=0;j<numseg;j++)
    beta[j+1]=prop_b[j];
  
  get_linear_proposal_hyperparameters(h, q, len, m, V, hs, 
				      prop_h0, s2, T, numseg,
				      &m_star, &V_star);
  
  ret=multinormal_pdf(beta,m_star,V_star,dim,b_true);

  delete [] m_star;
  doubledelete(V_star,dim);
  delete [] beta;

  return ret;
}

// Performs one sampling from the posterior. returns an indiactor
// of wether the bulk of the parameters were accepted or not.
int draw_from_model(int num_seg, int /* max_seg */,
		    int num_temp, double *T, gsl_rng *rptr, 
		    double *q, double *h, int len, 
		    double minh,double maxh, 
		    double *prev_a1, double **prev_b, double **prev_h0,
		    double **prev_hs, double *prev_s2, double *prev_logprob,
		    double *m, double **var, 
		    double mu_q, double sd_q,
		    double sigma_a, double sigma_b,
		    double mu_h02, double sd_h02,
		    double *rw_hs, double *rw_h0, 
		    int h0_update /* =-1 means all h0's are updated */,
		    int hs_update /* =-1 means all h0's are updated. If not
				     accpetance for this is reported */)
{
  int t,l,l2, acc=0;
  double new_logprob;

  for(t=0;t<num_temp;t++)
    {
      double steptype=sqrt(T[t]);
      double r=drand48();
      if(r<0.1)
	steptype/=10.0;
      else if(r<0.2)
	steptype/=300.0;
      else if(r<0.3)
	steptype/=10000.0;
      else if(r<0.4)
	steptype*=10.0;
      else if(r<0.5)
	steptype*=100.0;
      
      // Update s^2
      prev_s2[t]=gibbs_sigma2(h, q, len, sigma_a, sigma_b, 
			      prev_a1[t], prev_b[t], 
			      prev_hs[t], prev_h0[t], 
			      T[t], rptr, num_seg);
      
      // Update hs:
      /*for(l=0;l<(num_seg-1);l++)
	if(hs_update<0 || hs_update==l)
	  {
	    double *new_hs=new double[num_seg-1];
	    for(l2=0;l2<(num_seg-1);l2++)
	      new_hs[l2]=prev_hs[t][l2];
	    new_hs[l]=prev_hs[t][l]+gsl_ran_gaussian(rptr,steptype*rw_hs[l]);

	    new_logprob=logprob(q,h,len,minh,maxh,prev_a1[t],
				prev_b[t], new_hs, prev_h0[t], prev_s2[t],
				var,m, mu_q,sd_q*sd_q,sigma_a,sigma_b,
				mu_h02,sd_h02,T[t], num_seg);
	    
	    if(log(drand48())<new_logprob-prev_logprob[t])
	      {
		prev_hs[t][l]=new_hs[l];
		prev_logprob[t]=new_logprob;

		if(hs_update>=0)
		  acc=1;
	      }
	    
	    delete [] new_hs;
	  }
      */

      // Update h01, h02, a1, b1, b2:
      double new_a1, *new_h0=new double[num_seg];
      for(l=0;l<num_seg;l++)
	new_h0[l]=prev_h0[t][l]+
	  gsl_ran_gaussian(rptr, steptype*rw_h0[l]);

      double *new_hs=new double[num_seg];
      for(l=0;l<(num_seg-1);l++)
	if(hs_update<0 || hs_update==l)
	  {
	    for(l2=0;l2<(num_seg-1);l2++)
	      new_hs[l2]=prev_hs[t][l2];
	    new_hs[l]=prev_hs[t][l]+gsl_ran_gaussian(rptr,steptype*rw_hs[l]);
	  }

      int is_h0_ok=1;
      if(new_h0[0]>=minh)
	is_h0_ok=0;
      for(l=0;l<(num_seg-1);l++)
	if(new_h0[l]>=new_hs[l] || new_h0[l+1]>=new_hs[l])
	  is_h0_ok=0;

      if(is_h0_ok)
	{
	  if(h0_update>=0 && h0_update<num_seg)
	    for(l=0;l<num_seg;l++)
	      if(l!=h0_update)
		new_h0[l]=prev_h0[t][l];
	  
	  double *new_b;
	  double new_proposal=
	    gibbs_linear(h, q, len, m, var, new_hs, new_h0,
			 prev_s2[t], T[t], num_seg, &new_a1, 
			 &new_b, rptr);
	  
	  new_logprob=logprob(q,h,len,minh,
			      maxh,new_a1, new_b, new_hs, 
			      new_h0, prev_s2[t],
			      var,m, mu_q, sd_q*sd_q, 
			      sigma_a,sigma_b,mu_h02,sd_h02,T[t],num_seg);
	  double prev_proposal=
	    get_proposal_logdensity(h,q,len,m,var,prev_s2[t], 
				    prev_hs[t], prev_a1[t], 
				    prev_b[t], prev_h0[t], 
				    T[t], num_seg);
	  
	  if(log(drand48())<((new_logprob-prev_logprob[t])-
			     (new_proposal-prev_proposal)))
	    {
	      for(l=0;l<num_seg;l++)
		prev_h0[t][l]=new_h0[l];
	      for(l=0;l<(num_seg-1);l++)
		prev_hs[t][l]=new_hs[l];
	      prev_a1[t]=new_a1;
	      for(l=0;l<num_seg;l++)
		prev_b[t][l]=new_b[l];
	      prev_logprob[t]=new_logprob;
	
	      if(t==0 && hs_update<0)
		acc=1;
	    }

	  delete [] new_b;
	}

      delete [] new_h0;
      delete [] new_hs;
    }

  return acc;
}

void make_lin_prior(double est_logconst, double est_exp, double sdev_logconst, 
		    double sdev_exp, double corr, int max_seg, double **m_, 
		    double ***var_)
{
  int l,l2;

  // Make the prior expectancy vector:
  double *m=new double[max_seg+1];
  m[0]=est_logconst;
  for(l=0;l<max_seg;l++)
    m[l+1]=est_exp;
  
  // Make the prior covariance matrix:
  double **var=new double*[max_seg+1];
  for(l=0;l<max_seg+1;l++)
    var[l]=new double[max_seg+1];
  var[0][0]=sdev_logconst*sdev_logconst;
  for(l=0;l<max_seg;l++)
    {
      var[0][l+1]=var[l+1][0]=corr*sdev_logconst*sdev_exp;
      var[l+1][l+1]=sdev_exp*sdev_exp;
    }
  for(l=0;l<max_seg;l++)
    for(l2=l+1;l2<max_seg;l2++)
      var[l+1][l2+1]=var[l2+1][l+1]=corr*corr*sdev_exp*sdev_exp;

  *m_=m;
  *var_=var;
}

void switch_temp(double new_logprob1, double new_logprob2, 
		 double *prev_a1, double **prev_b, double **prev_h0, 
		 double **prev_hs, double *prev_s2, double *prev_logprob,
		 int num_seg, int t)
{
  int l;
  double *b_buff=new double[num_seg], 
    *h0_buff=new double[num_seg], 
    *hs_buff=new double[num_seg];
  double a1_buff=prev_a1[t],
    s2_buff=prev_s2[t]; 

  
  for(l=0;l<num_seg;l++)
    {
      b_buff[l]=prev_b[t][l];
      h0_buff[l]=prev_h0[t][l];
      if(l<(num_seg-1))
	hs_buff[l]=prev_hs[t][l];
    }
  
  prev_a1[t]=prev_a1[t+1];
  for(l=0;l<num_seg;l++)
    {
      prev_b[t][l]=prev_b[t+1][l];
      prev_h0[t][l]=prev_h0[t+1][l];
      if(l<(num_seg-1))
	prev_hs[t][l]=prev_hs[t+1][l];
    }
  prev_s2[t]=prev_s2[t+1];
  prev_logprob[t]=new_logprob1;
  
  prev_a1[t+1]=a1_buff;
  for(l=0;l<num_seg;l++)
    {
      prev_b[t+1][l]=b_buff[l];
      prev_h0[t+1][l]=h0_buff[l];
      if(l<(num_seg-1))
	prev_hs[t+1][l]=hs_buff[l];
    }
  prev_s2[t+1]=s2_buff;
  prev_logprob[t+1]=new_logprob2;

  delete [] b_buff;
  delete [] h0_buff;
  delete [] hs_buff;
}
	  

void draw_parameters(double *stage, double *discharge, 
		     int number_of_measurements, 
		     // measurements
		     
		     // output:
		     double **sampled_a1,
		     double ***sampled_b,
		     double ***sampled_hs,
		     double ***sampled_h0,
		     double **sampled_s2,
		     double **sampled_psi,
		     int **sampled_num_seg,
		     
		     // Optional input::
		     
		     int num_sim, 
		     // number of drawings
		     
		     // prior knowledge:
		     double est_exp, 
		     double sdev_exp, 
		     double est_logconst, 
		     double sdev_logconst,
		     double corr,
		     double sigma_a, 
		     double sigma_b, 
		     //double h01_mean, double h01_sdev,
		     //double h02_mean, double h02_sdev,
		     //double hs_mean, double hs_sdev,
		     double mu_q, double sd_q,
		     double mu_h02, double sd_h02,
		     
		     int indep, 
		     /* spacing between drawings */
		     
		     int burnin, 
		     /* burn-in length */
		     int num_temp,

		     int max_seg,
		     int min_seg=1
		     )
{
  int i;
  
  // Store the measurements:
  int l, l2;
  int num_meas=number_of_measurements, len=number_of_measurements;
  double *q=new double[num_meas];
  double *h=new double[num_meas];
  for(i=0;i<num_meas;i++)
    {
      q[i]=log(discharge[i]);
      h[i]=stage[i];
    }    
  
  double minh=find_statistics(h,num_meas,MIN);
  double maxh=find_statistics(h,num_meas,MAX);
  double *T=new double[num_temp];
  
  int num_mod=(max_seg-min_seg+1);
  double *pi_model=new double[max_seg];
  double **T_model=new double*[max_seg];
  for(l=(min_seg-1);l<max_seg;l++)
    {
      pi_model[l]=1.0/double(num_mod);
      T_model[l]=new double[max_seg];
      for(l2=0;l2<max_seg;l2++)
	T_model[l][l2]=0.0;
      if(num_mod>=2)
	{
	  if(l==(min_seg-1))
	    T_model[l][l+1]=1.0;
	  else if(l==(max_seg-1))
	    T_model[l][l-1]=1.0;
	  else
	    T_model[l][l-1]=T_model[l][l+1]=0.5;
	}
    }

  // Initialize GSL random generator:
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  
  double *m, **var;
  make_lin_prior(est_logconst, est_exp, sdev_logconst, sdev_exp, corr, 
		 max_seg, &m, &var);
  
  // Make the return arrays:
  double *a1=new double[num_sim];
  double **b_=new double*[num_sim];
  double **hs_=new double*[num_sim];
  double **h0_=new double*[num_sim];
  double *s2=new double[num_sim];
  double *psi=new double[num_sim];
  int *num_seg=new int[num_sim];
  for(l=0;l<num_sim;l++)
    {
      b_[l]=new double[max_seg];
      hs_[l]=new double[max_seg];
      h0_[l]=new double[max_seg];
    }

  // Make the vectors holding previous simulation values:
  int prev_nseg=max_seg>min_seg ? min_seg+1 : min_seg;
  double **prev_a1=new double*[max_seg], ***prev_b=new double**[max_seg],
    ***prev_h0=new double**[max_seg], ***prev_hs=new double**[max_seg],
    **prev_s2=new double*[max_seg], **prev_logprob=new double*[max_seg];

  for(l=0;l<max_seg;l++)
    {
      prev_a1[l]=new double[num_temp];
      prev_b[l]=new double*[num_temp]; 
      prev_h0[l]=new double*[num_temp];
      prev_hs[l]=new double*[num_temp]; 
      prev_s2[l]=new double[num_temp];
      prev_logprob[l]=new double[num_temp];

      for(i=0;i<num_temp;i++)
	{
	  prev_b[l][i]=new double[max_seg];
	  prev_h0[l][i]=new double[max_seg];
	  prev_hs[l][i]=new double[max_seg];
	}
    }

  int t;
  int *numswaps=NULL;

  if(num_temp>1)
    numswaps=new int[num_temp-1];
  
  // First sample for all models;
  for(l=(min_seg-1);l<max_seg;l++)
    {
      for(t=0;t<num_temp;t++)
	{
	  if(t==0)
	    T[t]=1.0;
	  else
	    T[t]=2.0*T[t-1];
	  if(num_temp>1 && t<num_temp-1)
	    numswaps[t]=0; 
	  
	  prev_a1[l][t]=m[0]+gsl_ran_gaussian(rptr, sdev_logconst);
	  
	  for(l2=0;l2<=l;l2++)
	    {
	      prev_b[l][t][l2]=m[l2+1];//+gsl_ran_gaussian(rptr, sdev_exp);
	      prev_h0[l][t][l2]=minh-drand48();
	      if(l2<l)
		prev_hs[l][t][l2]=minh+drand48()*(maxh-minh);
	    }
	  if(l>1)
	    qsort(prev_hs[l][t],l, sizeof(double), compare_double); 
	  
	  prev_s2[l][t]=sigma_a>0.0 ? 
	    1.0/gsl_ran_gamma(rptr,sigma_a,1.0/sigma_b) : 1.0e+5*drand48();
	  
	  prev_logprob[l][t]=logprob(q,h,num_meas,minh,maxh,
				     prev_a1[l][t], prev_b[l][t], 
				     prev_hs[l][t], prev_h0[l][t], 
				     prev_s2[l][t],
				     var,m, mu_q,sd_q*sd_q,
				     sigma_a,sigma_b,mu_h02,sd_h02,
				     T[t], l+1);
	}
    }
  
  // burnin non-adaptive samples for each model;
  double **rw_hs=new double*[max_seg], **rw_h0=new double*[max_seg];
  for(l=(min_seg-1);l<max_seg;l++)
    {
      rw_hs[l]=new double[max_seg];
      rw_h0[l]=new double[max_seg];
      for(l2=0;l2<=l;l2++)
	{
	  rw_h0[l][l2]=0.1;
	  if(l2<l)
	    rw_hs[l][l2]=0.1;
	}

      for(i=0;i<burnin;i++)
	draw_from_model(l+1, max_seg, (l==0 ? 1 : num_temp), T, rptr, 
			q,h,len,minh,maxh, 
			prev_a1[l], prev_b[l], prev_h0[l], prev_hs[l], 
			prev_s2[l], prev_logprob[l],
			m,var,mu_q,sd_q,sigma_a,sigma_b,mu_h02,sd_h02, 
			rw_hs[l], rw_h0[l],-1, -1);
    }

  // adaptive samples for each model:
  for(l=(min_seg-1);l<max_seg;l++)
    {
      for(i=0;i<burnin;i+=100)
	{
	  for(l2=0;l2<=l;l2++) // adapt rw_h0
	    {
	      int acc=0;
	      for(int j=0;j<100;j++)
		acc+=draw_from_model(l+1, max_seg, (l==0 ? 1 : num_temp), 
				     T, rptr, q,h,len,minh,maxh, 
				     prev_a1[l], prev_b[l], 
				     prev_h0[l], prev_hs[l], 
				     prev_s2[l], prev_logprob[l],
				     m,var,mu_q,sd_q,sigma_a,sigma_b,
				     mu_h02,sd_h02, 
				     rw_hs[l], rw_h0[l], l2, -1);
	      double accrate=double(acc)/double(100);
	      
	      rw_h0[l][l2]*=exp((accrate-0.33)*2.0);
	    }
	  
	  for(l2=0;l2<l;l2++) // adapt rw_hs
	    {
	      int acc=0;
	      for(int j=0;j<100;j++)
		acc+=draw_from_model(l+1, max_seg, (l==0 ? 1 : num_temp), 
			 	     T, rptr, q,h,len,minh,maxh,
				     prev_a1[l], prev_b[l], 
				     prev_h0[l], prev_hs[l],
				     prev_s2[l], prev_logprob[l],
				     m,var,mu_q,sd_q,sigma_a,sigma_b,
				     mu_h02,sd_h02,
				     rw_hs[l], rw_h0[l], -1, l2);
	      double accrate=double(acc)/double(100);
	      
	      rw_hs[l][l2]*=exp((accrate-0.33)*2.0);
	    }
	}
    }     


  // Global variables inside the simulation:
  int prev_method=0;
  double *numseg=new double[burnin+num_sim*indep];
  
  for(i=1;i<=num_sim*indep+burnin;i++)
    {
      if(prev_nseg>=2 && drand48()<0.1 && num_temp>1) 
	// try tempering algorithm?
	{
	  int t=(int) floor(drand48()*double(num_temp-1));

	  double new_logprob1=
	    logprob(q,h,num_meas,minh,maxh,prev_a1[prev_nseg-1][t+1], 
		    prev_b[prev_nseg-1][t+1], 
		    prev_hs[prev_nseg-1][t+1], prev_h0[prev_nseg-1][t+1], 
		    prev_s2[prev_nseg-1][t+1],
		    var,m, mu_q,sd_q*sd_q,sigma_a,sigma_b,
		    mu_h02,sd_h02,T[t], 2);
	  
	  double new_logprob2=
	    logprob(q,h,num_meas,minh,maxh,
		    prev_a1[prev_nseg-1][t], prev_b[prev_nseg-1][t], 
		    prev_hs[prev_nseg-1][t], prev_h0[prev_nseg-1][t], 
		    prev_s2[prev_nseg-1][t],
		    var,m,mu_q,sd_q*sd_q,sigma_a,sigma_b,
		    mu_h02,sd_h02,T[t+1], 2);

	  // swap parameters between distribution t and distribution t+1
	  if(log(drand48())< new_logprob1+new_logprob2-
	     prev_logprob[prev_nseg-1][t]-prev_logprob[prev_nseg-1][t+1])
	    {
	      switch_temp(new_logprob1, new_logprob2,
			  prev_a1[prev_nseg-1], prev_b[prev_nseg-1],
			  prev_h0[prev_nseg-1], prev_hs[prev_nseg-1],
			  prev_s2[prev_nseg-1], prev_logprob[prev_nseg-1],
			  prev_nseg, t);
	      numswaps[t]++;
	    }
	      
	  prev_method=1;
	}
      else // no tempering proposal
	{


	  // reversible jump:
	  if(num_mod>=2 && i>burnin/2 && drand48()<0.2) // propose model jump?
	    {
	      // Draw a new model:
	      double r=drand48(), T_cumul=0.0;
	      int next_nseg=-1;
	      
	      for(l=(min_seg-1);l<max_seg && next_nseg<0;l++)
		{
		  T_cumul+=T_model[prev_nseg-1][l];
		  if(r<=T_cumul)
		    next_nseg=l+1;
		}
	      
	      // Draw from that model:
	      draw_from_model(next_nseg, max_seg, 
			      (next_nseg==1 ? 1 : num_temp), 
			      T, rptr, q,h,len,minh,maxh,
			      prev_a1[next_nseg-1], prev_b[next_nseg-1], 
			      prev_h0[next_nseg-1], prev_hs[next_nseg-1],
			      prev_s2[next_nseg-1], prev_logprob[next_nseg-1],
			      m,var,mu_q,sd_q,sigma_a,sigma_b,
			      mu_h02,sd_h02,
			      rw_hs[next_nseg-1], rw_h0[next_nseg-1], -1, -1);
	      
	      // Accept/reject model proposal:
	      if(log(drand48())<
		 (prev_logprob[next_nseg-1][0]-prev_logprob[prev_nseg-1][0])+
		 (log(pi_model[next_nseg-1])-log(pi_model[prev_nseg-1]))-
		 (log(T_model[prev_nseg-1][next_nseg-1])-
		  log(T_model[next_nseg-1][prev_nseg-1])))
		prev_nseg=next_nseg;
	    }
	  else // internal model run
	    {
	      draw_from_model(prev_nseg, max_seg, prev_nseg==1 ? 1 : num_temp, 
			      T, rptr, q,h,len,minh,maxh, 
			      prev_a1[prev_nseg-1], prev_b[prev_nseg-1], 
			      prev_h0[prev_nseg-1], prev_hs[prev_nseg-1], 
			      prev_s2[prev_nseg-1], prev_logprob[prev_nseg-1],
			      m,var,mu_q,sd_q,sigma_a,sigma_b,mu_h02,sd_h02, 
			      rw_hs[prev_nseg-1], rw_h0[prev_nseg-1],-1, -1);
	      
	      prev_method=4;
	    }
	}
      
      if(!(prev_logprob[prev_nseg-1][0]>-1e+100 && 
	   prev_logprob[prev_nseg-1][0]<1e+100))
	{
	  cout << "Logprob out of range: " << 
	    prev_logprob[prev_nseg-1][0] << endl;
	  cout << "Method:" << prev_method << endl;
	  cout << i << " " << prev_a1[prev_nseg-1][0] << " " << 
	    prev_b[prev_nseg-1][0][0] << " " << 
	    prev_b[prev_nseg-1][0][1] << " " << 
	    prev_hs[prev_nseg-1][0][0] << 
	    " "  << prev_h0[prev_nseg-1][0][0] << " " << 
	    prev_h0[prev_nseg-1][0][1] << " " << 
	    prev_s2[prev_nseg-1][0] << " " << 
	    prev_logprob[prev_nseg-1][0] << " " << 
	    prev_nseg << endl;
	}
      
      if(i%1000==0)
	{
	  cout << i << " " << prev_a1[prev_nseg-1][0] << " " << 
	    prev_b[prev_nseg-1][0][0] << " " << 
	    prev_b[prev_nseg-1][0][1] << " " << 
	    prev_hs[prev_nseg-1][0][0] << 
	    " "  << prev_h0[prev_nseg-1][0][0] << " " << 
	    prev_h0[prev_nseg-1][0][1] << " " << 
	    prev_s2[prev_nseg-1][0] << " " << 
	    prev_logprob[prev_nseg-1][0] << " " << 
	    prev_nseg << endl;
	}
      //cout << prev_method << endl;
      numseg[i]=prev_nseg;
      
      if(i>burnin && (i-burnin)%indep==0)
	{
	  a1[(i-burnin)/indep-1]=prev_a1[prev_nseg-1][0];
	  for(l=0;l<max_seg;l++)
	    {
	      b_[(i-burnin)/indep-1][l]=prev_b[prev_nseg-1][0][l];
	      h0_[(i-burnin)/indep-1][l]=prev_h0[prev_nseg-1][0][l];
	      if(l<(max_seg-1))
		hs_[(i-burnin)/indep-1][l]=prev_hs[prev_nseg-1][0][l];
	    }
	  s2[(i-burnin)/indep-1]=prev_s2[prev_nseg-1][0];
	  psi[(i-burnin)/indep-1]=prev_logprob[prev_nseg-1][0];
	  num_seg[(i-burnin)/indep-1]=prev_nseg;
	}
    }
  
  int num_1=0, num_2=0;
  for(i=burnin;i<burnin+indep*num_sim;i++)
    if(numseg[i]==1)
      num_1++;
    else
      num_2++;
  
  //cout << "rw_h0:" << rw_h0[0][0] << " rw_h01:" << rw_h0[1][0] << 
  //" rw_h02:" << rw_h0[1][1] << " rw_hs:" << rw_hs[1][0] << endl;

  for(t=0;t<num_temp-1;t++)
    cout << "Number of swaps from " << t+1 << " to " << 
      t+2 << " : " << numswaps[t] << endl;

  *sampled_a1=a1;
  *sampled_b=b_;
  *sampled_hs=hs_;
  *sampled_h0=h0_;
  *sampled_s2=s2;
  *sampled_psi=psi;
  *sampled_num_seg=num_seg;

  delete [] m;
  doubledelete(var,3);
}

double get_Q(double h, double a1, double *b, double *hs, 
	     double *h0, int num_seg)
{
  double Q=0.0;

  if(h>h0[0])
    {
      double a=a1;
      int seg=0;

      for(seg=0;seg<(num_seg-1);seg++)
	{
	  if(h<=hs[seg])
	    break;
	  else
	    a+=b[seg]*log(hs[seg]-h0[seg])-b[seg+1]*log(hs[seg]-h0[seg+1]);
	}
      
      Q=exp(a+b[seg]*log(h-h0[seg]));
    }

  return Q;
}

void show_parameter(double *par, int N, char *parname, char *filename) 
{
  char cmd[1000];
  FILE *p;
  int i, len=N;
  double rho=get_auto_correlation(par, len);
  double spacing=2.0*(0.5+rho/(1.0-rho));
  cout << parname << " - spacing between independent samples:" << 
    spacing << endl;

  sprintf(cmd, "vvgraph -x %s", parname);
  p=popen(cmd,"w");
  fprintf(p,"# Column 1: %s, %s\n", filename, parname);
  fprintf(p,"###################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%d %f\n", i+1, par[i]);
  pclose(p);

  sprintf(cmd, "histogramme -x \"%s\" -t \"%s, %s\"", 
	  parname, filename, parname); 
  p=popen(cmd, "w");
  for(i=0;i<len;i++)
    fprintf(p,"%f\n", par[i]);
  pclose(p);
}

void show_scatter(double *par1, double *par2, int N, 
		  char *parname1, char *parname2, char *filename)
{
  FILE *p;
  char cmd[1000];
  int i, len=N;

  sprintf(cmd, "vvgraph -x %s -y %s", parname1, parname2);
  p=popen(cmd,"w");
  fprintf(p, "# Column 1: %s vs %s for dataset %s\n", parname1, parname2, 
	  filename);
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%f %f\n", par1[i], par2[i]);
  pclose(p);
}

void usage(void)
{
  cout << "Usage: nmod <input file> <number of simulations> <burnin> <indep> "
    "<max_seg> [<min_seg> [<num temp>]]]" << endl;
  exit(0);
}

int main(int argc, char **argv)
{
  if(argc<6 || argc>8)
    usage();
 
  randify();

  // Fetch the data file;
  int i,j,l,len, N=atoi(argv[2]);
  char errmsg[1000];
  StageDischarge *data=get_sd_file(argv[1], &len, errmsg);
  /*double sd_a=atof(argv[3]);
  double sd_b=atof(argv[4]);
  double sd_h=atof(argv[5]);
  double sd_s2=atof(argv[6]);*/
  int burnin=atoi(argv[3]);
  int indep=atoi(argv[4]);
  int numtemp=1;
  int max_seg=atoi(argv[5]);
  int min_seg=1;

  if(argc>6)
    min_seg=atoi(argv[6]);
  if(argc>7)
    numtemp=atoi(argv[7]);

  if(len<=0 || !data) // test if there's an error reading data
    {
      cout << errmsg << endl;
      exit(0);
    }
   
  double *q=new double[len], *h=new double[len];
  for(i=0;i<len;i++)
    {
      q[i]=data[i].q;
      h[i]=data[i].h;
      // cout << h[i] << " " << q[i] << endl;
    }

  double maxT=pow(2.0, double(numtemp-1));
  if(double(len)/2.0+1.0-maxT<0.0)
    {
      cout << "Too many temperatures!" << endl;
      cout << "Max possible number of temperatures for this dataset:";
      cout << 1+int(floor(log(double(len)/2.0+1.0)/log(2.0))) << endl;
      exit(0);
    }

  double *a1,**b,**hs,**h0,*s2,*psi;
  int *numseg;
  function_timer::start_total_timer(7);
  draw_parameters(h,q,len,&a1,&b,&hs,&h0,&s2,&psi,&numseg, N,
		  2.46,0.92, 2.84,1.38, -0.42, 1.356, 0.00176, 
		  1.8, 2.35, 0.264, 0.683, // default
		  //2.46,0.92, 2.84,1.38, -0.42, 0.0, 0.0, 
		  //1.8, 2.35, 0.0, 2.0, // wide hs
		  //2.46,2.0, 2.84,3.0, -0.42, 0.0,0.0,
		  //1.8, 3.0, 0.0, 2.0, // wide hs,h02
		  //2.46,0.92, 2.84, 1.38, -0.42, 0.0, 0.0, 
		  //10.0, 0.4, 0.0, 10.0, // corrientes
		  indep, burnin, numtemp, max_seg, min_seg); 
  function_timer::stop_total_timer();
  double t0=function_timer::get_total_timer(), 
    t1=function_timer::get_timer(0),
    t2=function_timer::get_timer(1),
    t3=function_timer::get_timer(2),
    t4=function_timer::get_timer(3),
    t5=function_timer::get_timer(4),
    t6=function_timer::get_timer(5),
    t7=function_timer::get_timer(6);
  cout << "Total tid:" << t0 << "s." << endl;
  cout << "Brukt tid p� � kvadratiske "
    "beregninger:" << t2 << "s. Forhold:" << t2/t0*100.0 << "%" << endl;
  cout << "Brukt tid p� invertering i kvad:" << t1 << 
    "s. Forhold:" << t1/t2*100.0 << "%" << endl;
  cout << "Brukt tid p� � l�kker i kvad:" << t3 << 
    "s. Forhold:" << t3/t2*100.0 << "%" << endl;
  cout << "Brukt tid p� XtX i l�kkene:" << t4 << 
    "s. Forhold:" << t4/t3*100.0 << "%" << endl;
  cout << "Brukt tid p� logprob:" << t5 << 
    "s. Forhold:" << t5/t0*100.0 << "%" << endl;
  cout << "Brukt tid p� gibbs_sigma2:" << t6 << 
    "s. Forhold:" << t6/t0*100.0 << "%" << endl;
  cout << "Brukt tid p� multinormale beregninger:" << t7 << 
    "s. Forhold:" << t7/t0*100.0 << "%" << endl;

  int *num_mod=new int[max_seg];
  for(i=0;i<max_seg;i++)
    num_mod[i]=0;
  for(i=0;i<N;i++)
    num_mod[numseg[i]-1]++;

  double *p_mod=new double[max_seg], p_mod_max=0.0;
  int max_mod=0;
  for(i=0;i<max_seg;i++)
    {
      p_mod[i]=double(num_mod[i])/double(N);
      if(p_mod[i]>p_mod_max)
	{
	  p_mod_max=p_mod[i];
	  max_mod=i+1;
	}

      cout << "Antall trekninger fra modell " << i+1 << ": " << num_mod[i] << 
	" / " << N << " = " << p_mod[i]*100.0 << "%" << endl;
    }


  int max_mod_len=num_mod[max_mod-1];
  double **par=new double*[1+3*max_mod];
  char **parname=new char*[1+3*max_mod];
  double med_a1, med_s, *med_b=new double[max_mod],
    *med_h0=new double[max_mod], *med_hs=new double[max_mod];

  for(i=0;i<1+3*max_mod;i++)
    {
      par[i]=new double[max_mod_len];
      parname[i]=new char[100];
    }
  
  strcpy(parname[0], "a1");
  for(l=0;l<max_mod;l++)
    sprintf(parname[1+l], "b%d", l+1);
  for(l=0;l<max_mod;l++)
    sprintf(parname[1+l+max_mod], "h0%d", l+1);
  for(l=0;l<(max_mod-1);l++)
    sprintf(parname[1+l+2*max_mod], "hs%d", l+1);
  strcpy(parname[3*max_mod], "sigma");
  
  j=0;
  for(i=0;i<N;i++)
    if(numseg[i]==max_mod)
      {
	par[0][j]=a1[i];
	for(l=0;l<max_mod;l++)
	  {
	    par[1+l][j]=b[i][l];
	    par[1+l+max_mod][j]=h0[i][l];
	    if(l<(max_mod-1))
	      par[1+l+2*max_mod][j]=hs[i][l];
	  }
	par[3*max_mod][j]=sqrt(s2[i]);

	j++;
      }

  med_a1=find_statistics(par[0], max_mod_len,MEDIAN);
  for(l=0;l<max_mod;l++)
    {
      med_b[l]=find_statistics(par[1+l], max_mod_len,MEDIAN);
      med_h0[l]=find_statistics(par[1+l+max_mod], max_mod_len,MEDIAN);
      if(l<(max_mod-1))
	med_hs[l]=find_statistics(par[1+l+2*max_mod], max_mod_len,MEDIAN);
    }
  med_s=find_statistics(par[3*max_mod], max_mod_len, MEDIAN);

  double *s=new double[N];
  for(i=0;i<N;i++)
    s[i]=sqrt(s2[i]);
  
  FILE *p;

  double min_h=find_statistics(h,len,MIN), max_h=find_statistics(h,len,MAX);

  p=popen("vvgraph -x m -y \"m^3/s\"","w");
  fprintf(p,"# Column 1: median(Q(h))\n");
  fprintf(p,"# Column 2: num_seg=%d, median parameters\n", max_mod);
  fprintf(p,"# Column 3: lower limit for 95%% credibility\n");
  fprintf(p,"# Column 4: upper limit for 95%% credibility\n");
  fprintf(p,"# Column 5: measurements from %s\n", argv[1]);
  fprintf(p,"# Column 5 - type: dot\n");
  fprintf(p,"###################\n");
  double *Q=new double[N],x;
  for(x=min_h-1.0;x<max_h+1.0;x+=0.005)
    {
      for(i=0;i<N;i++)
	Q[i]=get_Q(x, a1[i], b[i], hs[i], h0[i], numseg[i]);
      
      double Q_med=find_statistics(Q,N,MEDIAN);
      double Q_med_par=get_Q(x, med_a1, med_b, med_hs, med_h0, max_mod);
      double lower=find_statistics(Q,N,PERCENTILE_2_5);
      double upper=find_statistics(Q,N,PERCENTILE_97_5);

      fprintf(p, "%f %f %f %f %f -10000000\n", x, Q_med, Q_med_par, 
	      lower, upper);
    }
  delete [] Q;
  for(j=0;j<len;j++)
    fprintf(p, "%f -10000000 -10000000 -10000000 -10000000 %f\n", 
	    h[j], q[j]);
  pclose(p);

  show_parameter(a1, N, "a1_total", argv[1]); 
  show_parameter(s, N, "sigma_total", argv[1]); 

  for(i=0;i<1+3*max_mod;i++)
    show_parameter(par[i], max_mod_len, parname[i], argv[1]);

  for(i=0;i<1+3*max_mod;i++)
    for(j=i+1;j<1+3*max_mod;j++)
      show_scatter(par[i],  par[j],  max_mod_len, 
		   parname[i],  parname[j],  argv[1]);
}





