#include <stdio.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_odeiv.h>
#include <math.h>
#include <hydrasub/hydragui/mainwin.H>
#include <hydrasub/hydragui/pushb.H>
#include <hydrasub/hydragui/draw.H>
#include <hydrasub/hydragui/timer.H>

int
func (double t, const double y[], double f[],
      void *params)
{
  // Fetch the parameters:
  double m1 = *(((double *) params));
  double L1 = *(((double *) params)+1);
  double m2 = *(((double *) params)+2);
  double L2 = *(((double *) params)+3);
  double g = *(((double *) params)+4);

  // Fetch the state:
  double t1=y[0], p1=y[1], t2=y[2], p2=y[3];  

  // derived parameters:
  double a=(m1/6.0+m2/2.0)*L1*L1, b=1.0/6.0*m2*L2*L2;
  double c=0.5*m2*L1*L2*cos(t1-t2);
  double cder=-0.5*m2*L1*L2*sin(t1-t2);
  double det=4.0*a*b-c*c;
  double dder=g*(m1/2.0+m2)*L1*sin(t1);
  double eder=g*m2/2.0*L2*sin(t2);
  double parant=(4.0*a*b*b-b*c*c)*p1*p1 + (4.0*a*a*b-a*c*c)*p2*p2 +
    (c*c*c-4.0*a*b*c)*p1*p2;

  // Calculate the time derivative of the state using
  // Hamilton's equations:
  f[0]=((8.0*a*b*b-2.0*b*c*c)*p1+(c*c*c-4.0*a*b*c)*p2)/det/det;
  f[1]=-4.0*cder*c/det/det/det*parant+
    cder/det/det*(2.0*b*c*p1*p1+2.0*a*c*p2*p2+4.0*a*b*p1*p2-3.0*c*c*p1*p2)-dder;
  f[2]=((8.0*a*a*b-2.0*a*c*c)*p2+(c*c*c-4.0*a*b*c)*p1)/det/det;
  f[3]=+4.0*cder*c/det/det/det*parant-
    cder/det/det*(2.0*b*c*p1*p1+2.0*a*c*p2*p2+4.0*a*b*p1*p2-3.0*c*c*p1*p2)-eder;
  
  return GSL_SUCCESS;
}

// A drawing class for the swinging rod program:
class swinging_rod_draw : public draw
{
public:
  swinging_rod_draw();
  void expose(void); // Called each time the drawing area is shown
  boolean exposed;
};

swinging_rod_draw::swinging_rod_draw() : draw()
{
  exposed=b_false; // indicator , no picture exposed yet
}

void swinging_rod_draw::expose(void)
{
  exposed=b_true; // indicator, picture exposed
}

// SWINGING_ROD
// The main class of the program:
class swinging_rod : public mainwin, public timer
{
private:
  swinging_rod_draw dr; // drawing area
  vrow v1;              // container
  hrow h1;
  exitbutton eb;        // exit button

  // GSL variables for solving the differential equations:
  const gsl_odeiv_step_type * T; 
  gsl_odeiv_step * s;
  gsl_odeiv_control * c;
  gsl_odeiv_evolve * e;
  gsl_odeiv_system sys;

  // Physical parameters:
  double m1, m2, L1, L2,g;
  double params[5]; 
  double y[4]; // state
  double t,tbuf,ti,dt; // time variables
  int showiter, maxiter;

  boolean exposed; // drawing area indicator

public:

  // Constructor:
  swinging_rod(int argc, char **argv);

  // destructor:
  ~swinging_rod();

  // Called each time iteration:
  void wakeup(void);
};


// Constructor.
// Stores the user defined physical parameters
// and the initial state, as well as make the
// main GUI window.
swinging_rod::swinging_rod(int argc, char **argv) :
  mainwin("swinging rod", argc, argv)
{
  // make the GUI:
  v1.build(*this);
  dr.build(v1, 800, 800);
  h1.build(v1);
  eb.Create(h1, "Quit");
  
  // Make the GSL variables:
  T=gsl_odeiv_step_rk8pd;
  s=gsl_odeiv_step_alloc (T, 4);
  c=gsl_odeiv_control_y_new (1e-6, 0.0);
  e=gsl_odeiv_evolve_alloc (4);

  // Store the physical parameters:
  if(argc<3)
    {
      m1 = 1.0;
      m2 = 2.0;
    }
  else
    {
      m1=atof(argv[1]);
      m2=atof(argv[2]);
    }

  L1=0.1;
  L2=0.1;
  g = 9.81;
  params[0]=m1;
  params[1]=L1;
  params[2]=m2;
  params[3]=L2;
  params[4]=g;

  // Store the initial state:
  if(argc<=3)
    {
      y[0]=M_PI/2.0;
      y[2]=M_PI/2.0;
    }
  else
    {
      double angle=atof(argv[3]);
      y[0]=atof(argv[3])*2.0*M_PI/360.0;
      if(y[0]>=M_PI/2.0 && y[0]<=3.0*M_PI/2.0)
	y[2]=M_PI-y[0];
      else
	y[2]=y[0];
    }
  y[1]=0.0;
  y[3]=0.0;

  // Number of iterations (if defined):
  if(argc>4)
    showiter=atoi(argv[4]);
  else
    showiter=0;

  if(argc>5)
    maxiter=atoi(argv[5]);
  else
    maxiter=0;

  // set GSL variables:
  sys.function=func;
  sys.jacobian=NULL;
  sys.dimension=4;
  sys.params=params;

  // Set time variables:
  t=0;
  dt=0.004;

  // Start the interations:
  Set(10);
}

void swinging_rod::wakeup(void)
{
  if(!dr.exposed) // if nothing has yet been exposed, 
    // wait a little more
    {
      Set(10);
      return;
    }

  double tbuf=0.0;
  double ti = dt;
  int status=GSL_SUCCESS;
  double h = 1e-6;
  double prevangle1=y[0], prevangle2=y[2];

  // Update the state using numerical resepies in the GSL 
  // library and the Hamiltonian equations of motion:
  while (tbuf < ti && status==GSL_SUCCESS)
    {
      status=gsl_odeiv_evolve_apply (e, c, s, 
				     &sys, 
				     &tbuf, ti, &h,
				     y);
    }

  t+=tbuf;

  // fetch the new physical state and transform it into
  // graphical variables:
  double angle1=y[0], angle2=y[2];
  int x1p=int(180.0*sin(prevangle1));
  int y1p=int(180.0*cos(prevangle1));
  int x2p=x1p+int(180.0*sin(prevangle2));
  int y2p=y1p+int(180.0*cos(prevangle2));
  int x1=int(180.0*sin(angle1));
  int y1=int(180.0*cos(angle1));
  int x2=x1+int(180.0*sin(angle2));
  int y2=y1+int(180.0*cos(angle2));

  // Show the new graphics:
  dr.Set_No_Dashes(10);
  dr.SetFg("black");
  dr.Line(400,400, 400+x1p, 400+y1p);
  dr.Line(400+x1p, 400+y1p, 400+x2p, 400+y2p);
	  
  dr.SetFg("white");
  dr.Line(400,400, 400+x1, 400+y1);
  dr.Line(400+x1, 400+y1, 400+x2, 400+y2);

  
  static int count=0;

  // IF iterations has been given, output the state to
  // the standard output stream:
  if(showiter && count%showiter==0)
    cout << t << " " << 180.0*angle1/M_PI << endl;
  count++;

  if(maxiter && count>maxiter)
    exit(0);

  if(maxiter)
    {
      image img(800,600);
      rgb white(255,255,255);
      
      image_line(&img, 400 ,200, 400+x1p, 200+y1p, 10, white);
      image_line(&img, 400+x1p, 200+y1p, 400+x2p, 200+y2p, 10, white);
      
      char filename[100];
      sprintf(filename, "swing%05d.jpg", count);
      write_image(&img, filename);
    }

  // Wait for a new iteration:
  Set(10);
}

// Destructor:
swinging_rod::~swinging_rod()
{
  // Frre the GSL variables:
  gsl_odeiv_evolve_free(e);
  gsl_odeiv_control_free(c);
  gsl_odeiv_step_free(s);
}

// Show usage and quit:
void usage(void)
{
  cout << "Usage: swinging_rod3 [<mass 1> <mass 2> [<starting angle> "
    "[<output frequency> [<max iter>]]]]" << endl;
  cout << "The <mass1> and <mass2> determines the mass of the two "
    "swinging rods." << endl;
  cout << "PS: Only the relation between them determines the dynamics." << 
    endl;
  cout << "The <starting angle> in degrees determines the initial conditions."
       << endl;
  cout << "PS: The rods will be at rest then." << endl;
  cout << "The <output frequency> determines how often the time and angle" <<
    endl;
  cout << "of the first rod is shown. This can be piped to a plotting program"
       << endl;
  cout << "such as 'vvgraph'. Default is 0, which means no output." << endl;
  cout << "Max iter(ations) toggles a stop in the simulation. This is used" << endl;
  cout << "for making output to graphical files possible, and for making" << endl;
  cout << "an animation at the end of the simulation." << endl;
  exit(0);
}


// MAIN - main loop
int main (int argc, char **argv)
{
  // Check if the usage is ok. If not, show usage
  // to the user and quit:
  if(argc>1 && !isdigit(argv[1][0]))
    usage();

  // Start the simulation:
  swinging_rod sr(argc, argv);

  sr.Run(); // run the GUI components
  return 0; // quit
}
