#include <stdio.h>
#include "showfunc2d.H"

char showfunc2d_filename[200];

void showfunc_2d_plot::plot_ended(void)
{
  unlink(showfunc2d_filename);
  exit(0);
}

void usage(void)
{
  cout << "usage: showfunc2d [-a] <start-x> <end-x> <start-y> <end-y> <function>"
       << endl;
  cout << " -a toggles on showing a grid." << endl;
  cout << " <start-x>, <end-x>, <start-y>, <end-y> defines the argument "
    "of the graph" << endl;
  cout << " <function> should be of the form \"1.3*sin(x*y)-0.2\", that" << endl;
  cout << "            is, a c-style function description using <x> " << endl;
  cout << "            and <y> as the argument." << endl; 
  cout << "            Remember always to place semi-colon (\") around "
    "each function. For instance;" << endl << endl;
  cout << "   showfunc2d -5 5 -5 5 \"sin(x*y)\"" << endl;
  exit(0);
}

int main(int argc, char **argv)
{
  Boolean gridon=False, sepax=False;
  mainwin mn("showfunc 2D 1.0", argc, argv);
  showfunc_2d_plot showplot;
  vrow v1;
  double startx, endx, starty, endy;

  argv++;
  argc--;

  while(argc>=1 && argv[0][0]=='-')
    {
      if(strlen(argv[0])<2)
	usage();

      if(isdigit(argv[0][1]))
	break;

      switch(argv[0][1])
	{
	case 'a':
	  gridon=True;
	  break;
	default:
	  usage();
	  break;
	}

      argv++;
      argc--;
    }

  if(argc!=5)
    usage();

  if(!sscanf(argv[0], "%lf", &startx))
    {
      cout << "Error reading start" << endl;
      usage();
    }

  argv++;
  argc--;

  if(!sscanf(argv[0], "%lf", &endx))
    {
      cout << "Error reading end" << endl;
      usage();
    }

  argv++;
  argc--;

  if(!sscanf(argv[0], "%lf", &starty))
    {
      cout << "Error reading start" << endl;
      usage();
    }

  argv++;
  argc--;

  if(!sscanf(argv[0], "%lf", &endy))
    {
      cout << "Error reading end" << endl;
      usage();
    }

  argv++;
  argc--;

  int i;

  if(gridon)
    showplot.set_grid(gridon);

  v1.build(mn);
  showplot.put_in_widget(v1, 300, 300,
			 //v1.screenwidth()*9/10, v1.screenheight()*9/10, 
			 PLOT_IN_WIDGET_SHOWMAINMENU);

  makefunc(*argv);

  showplot.Create(valfunc, startx, starty, endx, endy, "x", "y"); 

  mn.Run();
}

void makefunc(char *function_description)
{
  int i=0;
  ofstream tempc;
  DateTime now;
  char cmd[300], cfile[100], exefile[100], *ptr;

  now.now();
  ptr=now.syCh(2);
  sprintf(cfile, "/tmp/showfunc2d_cfile%s.c", ptr);
  sprintf(exefile, "/tmp/showfunc2d_exefile%s", ptr);
  delete [] ptr;

  strcpy(showfunc2d_filename, exefile);

  tempc.open(cfile, ios::out);
  if(tempc.fail())
    {
      cerr << "Couldn't open the temp file " << cfile << "!" << endl;
      exit(1);
    }

  tempc << "#include <math.h>" << endl;
#ifdef GSL
  tempc << "#include <gsl/gsl_randist.h>" << endl;
  tempc << "#include <gsl/gsl_cdf.h>" << endl;
#endif
  tempc << "#include <stdio.h>" << endl;
  tempc << endl;
  tempc << "int main(int argc, char **argv)" << endl;
  tempc << "  {" << endl;
  tempc << "    double x,y,f;" << endl;
  tempc << endl;
  tempc << "    if(argc!=3)" << endl;
  tempc << "      exit(1);" << endl;
  tempc << endl;
  tempc << "    if(!sscanf(argv[1],\"%lf\", &x))" << endl;
  tempc << "      exit(2);" << endl;
  tempc << endl;
  tempc << "    if(!sscanf(argv[2],\"%lf\", &y))" << endl;
  tempc << "      exit(3);" << endl;
  tempc << endl;
  tempc << "    f=" << function_description << ";" << endl;
  tempc << "    printf(\"%lf\\n\", f);" << endl;
  tempc << endl;
  tempc << "    return 0;" << endl;
  tempc << "  }" << endl;
  tempc.close();

#ifdef GSL
  sprintf(cmd, "cc -I/usr/local/include -L/usr/local/lib -o %s %s "
	  "-lgsl -lgslcblas -lm 2> /dev/null", exefile, cfile);
#else
  sprintf(cmd, "cc -I/usr/local/include -L/usr/local/lib -o %s %s "
	  "-lm 2> /dev/null", exefile, cfile);
#endif


  if(system(cmd))
    {
      unlink(cfile);
       
      cerr << "Error in function definition; " << function_description << endl;
      exit(2);
    }

  unlink(cfile);
}

double valfunc(double x, double y)
{
  double funcval=0;
  char *buff=new char[100], cmd[300];
  size_t len=99;

  sprintf(cmd,"%s %lf %lf", showfunc2d_filename, x, y);

  FILE *p = popen(cmd, "r");
  if(!p)
    {
      cerr << "Error executing \"" << cmd << "\" !" << endl;
      unlink(showfunc2d_filename);
      exit(3);
    }

   int fno=fileno(p);
   size_t len2;

   getline(&buff, &len, p);
   if(!sscanf(buff,"%lf", &funcval))
     {
       cerr << "No function value returned from compiled program!" << endl;
       unlink(showfunc2d_filename);
       exit(4);
     }

   delete [] buff;
   pclose(p);

   return funcval;
}
