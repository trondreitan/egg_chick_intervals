#include "bayes_mcmc.H"
#include <math.h>
#include <hydrabase/newton.H>

void bayes_mcmc_old_button::Create(widget parent, char *txt, 
			       BAYES_MCMC_OLD_ACTION button_type,
			       bayes_mcmc_old *ipt)
{
  type=button_type;
  pt=ipt;
  build(parent,txt);
}

void bayes_mcmc_old_button::pushed(void)
{
  pt->take_action(type);
}

void bayes_mcmc_old_plot::plot_ended(void)
{
  pt->take_action(BAYES_MCMC_OLD_CLOSE);
}
void bayes_mcmc_old_plot::show_prediction(double *q, double *h, int num_meas,
				      int num_sim, double *lC, 
				      double *b, double *c, bayes_mcmc_old *ipt)
{
  double **arg=new double*[4], **val=new double*[4];
  int *len=new int[4], *axis=new int[4];
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[4];
  char **axistitles=new char*[2];
  char **linetitles=new char*[4];
  double minh=find_statistics(h, num_meas, MIN);
  double maxh=find_statistics(h, num_meas, MAX);
  double x1=minh-20.0, x2=maxh+1.0;
  int i,j,num=1000;
  double *pred=new double[num_sim];

  axistitles[0]=new char[10];
  axistitles[1]=new char[10];

  strcpy(axistitles[0], "h");
  strcpy(axistitles[1], "q");

  for(i=0;i<4;i++)
    {
      linetitles[i]=new char[100];
      if(i<3)
	{
	  type[i]=PLOTLINE_LINE;
	  len[i]=num;
	}
      else
	{
	  type[i]=PLOTLINE_DOT;
	  len[i]=num_meas;
	}
      arg[i]=new double[len[i]];
      val[i]=new double[len[i]];
      axis[i]=1;
    }
  
  strcpy(linetitles[0], "Beste estimat ubetinget parameterene");
  strcpy(linetitles[1], "�vre 2.5% troverdighet");
  strcpy(linetitles[2], "Nedre 2.5% troverdighet");
  strcpy(linetitles[3], "M�linger");
  
  for(i=0;i<num_meas;i++)
    {
      arg[3][i]=h[i];
      val[3][i]=q[i];
    }
  
  for(i=0;i<num;i++)
    {
      double x=x1+(x2-x1)*double(i)/double(num-1);

      for(j=0;j<num_sim;j++)
	pred[j]= x > -c[j] ? exp(lC[j])*pow(x+c[j], b[j]) : 0.0;
      
      qsort(pred, num_sim, sizeof(double), compare_double);

      arg[0][i]=arg[1][i]=arg[2][i]=x;
      val[0][i]=find_statistics(pred, num_sim, MEAN);
      val[1][i]=pred[num_sim*25/1000];
      val[2][i]=pred[num_sim*975/1000];
    }

  Create(arg,val,len, axis,linetitles, 4, axistitles, 2, NULL, type);
  
  pt=ipt;  
}

void bayes_mcmc_old::take_action(BAYES_MCMC_OLD_ACTION action)
{
  switch(action)
    {
    case BAYES_MCMC_OLD_CLOSE:
      Unmap();
      break;
    case BAYES_MCMC_OLD_A_HIST:
      hist_a();
      break;
    case BAYES_MCMC_OLD_B_HIST:
      hist_b();
      break;
    case BAYES_MCMC_OLD_C_HIST:
      hist_c();
      break;
    case BAYES_MCMC_OLD_S_HIST:
      hist_s();
      break;
    case BAYES_MCMC_OLD_A_PLOT:
      plot_a();
      break;
    case BAYES_MCMC_OLD_B_PLOT:
      plot_b();
      break;
    case BAYES_MCMC_OLD_C_PLOT:
      plot_c();
      break;
    case BAYES_MCMC_OLD_S_PLOT:
      plot_s();
      break;
    }
}


void bayes_mcmc_old::plot_a(void)
{
  FILE *p=popen("vvgraph -x iterasjoner -y a=\"log[C]\"", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%d %lf\n", i, a_sim[i]);
  pclose(p);
}

void bayes_mcmc_old::plot_b(void)
{
  FILE *p=popen("vvgraph -x iterasjoner -y b", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%d %lf\n", i, b_sim[i]);
  pclose(p);
}

void bayes_mcmc_old::plot_c(void)
{
  FILE *p=popen("vvgraph -x iterasjoner -y c", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%d %lf\n", i, c_sim[i]);
  pclose(p);
}


void bayes_mcmc_old::plot_s(void)
{
  FILE *p=popen("vvgraph -x iterasjoner -y s�", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%d %lf\n", i, s_sim[i]);
  pclose(p);
}

void bayes_mcmc_old::hist_a(void)
{
  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%lf\n", a_sim[i]);
  pclose(p);
}

void bayes_mcmc_old::hist_b(void)
{
  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%lf\n", b_sim[i]);
  pclose(p);
}

void bayes_mcmc_old::hist_c(void)
{
  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%lf\n", c_sim[i]);
  pclose(p);
}

void bayes_mcmc_old::hist_s(void)
{
  FILE *p=popen("histogramme", "w");
  for(int i=0;i<num_iter;i++)
    fprintf(p, "%lf\n", s_sim[i]);
  pclose(p);
}

void bayes_mcmc_old::create(double est_exp_, double sdev_exp_, // prior exp
			// prior log constant;
			double est_logconst_, double sdev_logconst_, 
			// prior of sigma�~neggamma(a,b);
			double sigma_a_, double sigma_b_,
			sd_list *new_measurements)
{
  build(mainwin::toplevel, "MCMC-h�ndtering");
  v1.build(*this);
  plot.put_in_widget(v1, 900,700, PLOT_IN_WIDGET_SHOWMAINMENU);
  h1.build(v1);
  closeb.Create(h1, "Avslutt", BAYES_MCMC_OLD_CLOSE, this);
  closeb.Background("red");
  closeb.Foreground("white");
  hist_a_button.Create(h1, "log(C)-hist", BAYES_MCMC_OLD_A_HIST, this);
  hist_b_button.Create(h1, "b-hist", BAYES_MCMC_OLD_B_HIST, this);
  hist_c_button.Create(h1, "c-hist", BAYES_MCMC_OLD_C_HIST, this);
  hist_s_button.Create(h1, "sigma�-hist", BAYES_MCMC_OLD_S_HIST, this);
  plot_a_button.Create(h1, "Plott log(C)", BAYES_MCMC_OLD_A_PLOT, this);
  plot_b_button.Create(h1, "Plott b", BAYES_MCMC_OLD_B_PLOT, this);
  plot_c_button.Create(h1, "Plott c", BAYES_MCMC_OLD_C_PLOT, this);
  plot_s_button.Create(h1, "Plott sigma�", BAYES_MCMC_OLD_S_PLOT, this);


  double *lC, *b, *c, *sigma2;
  int num_sim=1000;
  int num_meas;

  double *q=new_measurements->get_q(num_meas);
  double *h=new_measurements->get_h(num_meas);

  get_mcmc(est_exp_, sdev_exp_, est_logconst_, 
	   sdev_logconst_, sigma_a_, sigma_b_,
	   num_sim, q,h,  num_meas, &lC, &b, &c, &sigma2);

  a_sim=lC;
  b_sim=b;
  c_sim=c;
  s_sim=sigma2;
  num_iter=num_sim;

  plot.show_prediction(q, h, num_meas, num_sim, lC, b, c, this);

  Map();
}

void bayes_mcmc_old::create(double est_exp_, double sdev_exp_, // prior exp
			// prior log constant;
			double est_logconst_, double sdev_logconst_, 
			// prior of sigma�~neggamma(a,b);
			double sigma_a_, double sigma_b_,
			StageDischarge *sd, int len)
{
  build(mainwin::toplevel, "MCMC-h�ndtering");
  v1.build(*this);
  plot.put_in_widget(v1, 900,700, PLOT_IN_WIDGET_SHOWMAINMENU);
  h1.build(v1);
  closeb.Create(h1, "Avslutt", BAYES_MCMC_OLD_CLOSE, this);
  closeb.Background("red");
  closeb.Foreground("white");
  hist_a_button.Create(h1, "log(C)-hist", BAYES_MCMC_OLD_A_HIST, this);
  hist_b_button.Create(h1, "b-hist", BAYES_MCMC_OLD_B_HIST, this);
  hist_c_button.Create(h1, "c-hist", BAYES_MCMC_OLD_C_HIST, this);
  hist_s_button.Create(h1, "sigma�-hist", BAYES_MCMC_OLD_S_HIST, this);
  plot_a_button.Create(h1, "Plott log(C)", BAYES_MCMC_OLD_A_PLOT, this);
  plot_b_button.Create(h1, "Plott b", BAYES_MCMC_OLD_B_PLOT, this);
  plot_c_button.Create(h1, "Plott c", BAYES_MCMC_OLD_C_PLOT, this);
  plot_s_button.Create(h1, "Plott sigma�", BAYES_MCMC_OLD_S_PLOT, this);


  double *lC, *b, *c, *sigma2;
  int num_sim=1000;
  int num_meas=len;

  double *q=new double[len], *h=new double[len];
  for(int i=0;i<len;i++)
    {
      q[i]=sd[i].q;
      h[i]=sd[i].h;
    }
  
  get_mcmc(est_exp_, sdev_exp_, est_logconst_, 
	   sdev_logconst_, sigma_a_, sigma_b_,
	   num_sim, q,h,  num_meas, &lC, &b, &c, &sigma2);

  a_sim=lC;
  b_sim=b;
  c_sim=c;
  s_sim=sigma2;
  num_iter=num_sim;

  plot.show_prediction(q, h, num_meas, num_sim, lC, b, c, this);

  Map();
}

double logprob(double a, double b, double c, double s, 
	       double *q, double *h, int num_meas, 
	       double **inv_var, double *m, 
	       double sigma_a, double sigma_b)
{
  if(s<0.0)
    return -1e+216;

  double ret=-log(s)-(a*a*inv_var[0][0]+a*b*(inv_var[0][1]+inv_var[1][0])+
		      b*b*inv_var[1][1])/2.0/s;

  ret-=(sigma_a+1.0)*log(s)-sigma_b/s;
  ret-=double(num_meas)/2.0*log(s);
  
  for(int i=0;i<num_meas;i++)
    if(h[i]+c<0.0)
      return -1e+216;
    else
      ret-=(log(q[i])-a-b*log(h[i]+c))*
	(log(q[i])-a-b*log(h[i]+c))/2.0/s;

  return ret;
}

void bayes_mcmc_old::get_mcmc(double est_exp_, double sdev_exp_, // prior exp
			  // prior log constant;
			  double est_logconst_, double sdev_logconst_, 
			  // prior of sigma�~neggamma(a,b);
			  double sigma_a_, double sigma_b_,
			  int num_sim, double *q, double *h, int num_meas,
			  double **lC, double **b_, double **c_, 
			  double **sigma2)
{
  double *a=new double[num_sim*100+1000];
  double *b=new double[num_sim*100+1000];
  double *c=new double[num_sim*100+1000];
  double *s=new double[num_sim*100+1000];
  double *m=new double[2];
  double **var=new double*[2];
  double **inv_var;
  int i,j;
  double minh=find_statistics(h,num_meas,MIN);

  var[0]=new double[2];
  var[1]=new double[2];
  m[0]=est_logconst_;
  m[1]=est_exp_;
  var[0][0]=sdev_logconst_*sdev_logconst_*(2.0*sigma_a_-2.0); ///sigma_b;
  var[1][1]=sdev_exp_*sdev_exp_*(2.0*sigma_a_-2.0); ///sigma_b;
  var[0][1]=var[1][0]=-0.2*sqrt(var[0][0]*var[1][1]);

  inv_var=inverse_matrix(var,2);

  a[0]=est_logconst_;
  b[0]=est_exp_;
  c[0]=-find_statistics(h,num_meas,MIN)+1.0;
  s[0]=0.1;
  
  for(i=1;i<num_sim*100+1000;i++)
    {
      double new_a=a[i-1]+0.1*gauss();
      if(log(drand48())<
	 logprob(new_a,b[i-1], c[i-1], s[i-1],
		 q,h,num_meas,inv_var,m,sigma_a_,sigma_b_)-
	 logprob(a[i-1],b[i-1],c[i-1],s[i-1],
		 q,h,num_meas,inv_var,m,sigma_a_,sigma_b_))
	a[i]=new_a;
      else
	a[i]=a[i-1];

      double new_b=b[i-1]+0.1*gauss();
      if(log(drand48())<
	 logprob(a[i],new_b, c[i-1], s[i-1],
		 q,h,num_meas,inv_var,m,sigma_a_,sigma_b_)-
	 logprob(a[i],b[i-1],c[i-1],s[i-1],
		 q,h,num_meas,inv_var,m,sigma_a_,sigma_b_))
	b[i]=new_b;
      else
	b[i]=b[i-1];

      double new_c=c[i-1]+0.1*gauss();
      if(log(drand48())<
	 logprob(a[i],b[i], new_c, s[i-1],
		 q,h,num_meas,inv_var,m,sigma_a_,sigma_b_)-
	 logprob(a[i],b[i],c[i-1],s[i-1],
		 q,h,num_meas,inv_var,m,sigma_a_,sigma_b_) && minh+new_c>0.0)
	c[i]=new_c;
      else
	c[i]=c[i-1];

      double new_s=s[i-1]+0.01*gauss();
      double r=log(drand48());

      if(r<logprob(a[i],b[i], c[i], new_s,
		   q,h,num_meas,inv_var,m,sigma_a_,sigma_b_)-
	 logprob(a[i],b[i],c[i],s[i-1],
		 q,h,num_meas,inv_var,m,sigma_a_,sigma_b_)  && new_s>0.0)
	s[i]=new_s;
      else
	s[i]=s[i-1];

      if(i%100==0)
	cout << a[i] << " " << b[i] << " " << c[i] << " " << s[i] << endl;
    }

  *lC=new double[num_sim];
  *b_=new double[num_sim];
  *c_=new double[num_sim];
  *sigma2=new double[num_sim];
  
  for(i=0;i<num_sim;i++)
    {
      lC[0][i]=a[i*100+1000];
      b_[0][i]=b[i*100+1000];
      c_[0][i]=c[i*100+1000];
      sigma2[0][i]=s[i*100+1000];
    }

  delete [] a;
  delete [] b;
  delete [] c;
  delete [] s;
  doubledelete(inv_var,2);
  doubledelete(var,2);
  delete [] m;
}
