#include <hydrasub/hydrabase/divfunc.H>
#include <hydrasub/hydrabase/newton.H>
#include <hydrasub/hydrabase/stagedischarge.H>
#include <hydrasub/hydrabase/regression.H>
#include <hydrasub/hydrabase/linalg.H>
#include <gsl/gsl_randist.h>
#include <cmath>
 

double B0(double h, double h01)
{
  if(h>h01)
    return log(h-h01);
  else
    return MISSING_VALUE;
}

double B1(double h, double hs, double h01)
{
  if(h<hs && h>h01)
    return log(h-h01);
  else if(h>=hs && hs>h01)
    return log(hs-h01);
  else
    return MISSING_VALUE;
}

double B2(double h, double hs, double h02)
{
  if(h<hs)
    return 0.0;
  else if(h>hs && hs>h02)
    return log(h-h02)-log(hs-h02);
  else
    return MISSING_VALUE;
}

double find_SS2(double *h, double *q, int len, double a1, double b1, double b2,
		double hs,double h01, double h02)
{
  double SS=0.0, xb1,xb2,res;


  for(int i=0;i<len;i++)
    {
      xb1=B1(h[i],hs,h01);
      xb2=B2(h[i],hs,h02);
      if(b1==MISSING_VALUE || b2==MISSING_VALUE)
	return -1e+216;
      else
	{
	  res=q[i]-a1-b1*xb1-b2*xb2;
	  SS+=res*res;
	}
    }
  
  return SS;
}

double find_SS1(double *h, double *q, int len, double a1, double b1,double h01)
{
  double SS=0.0, xb,res;

  for(int i=0;i<len;i++)
    {
      xb=B0(h[i],h01);
      if(b1==MISSING_VALUE)
	return -1e+216;
      else
	{
	  res=q[i]-a1-b1*xb;
	  SS+=res*res;
	}
    }
  
  return SS;
}

double logprob2(double *q, double *h, int len, double hmin, 
		double hmax, double a1, double b1, double b2, 
		double hs, double h01, double h02, 
		double s2, double **var,
		double a1_m, double b1_m, double b2_m, 
		double mu_q, double sigma2_q,
		double sigma_a, double sigma_b, double mu_h02, double sd_h02,
		double T,
		double h01_m=MISSING_VALUE, double h01_s2=MISSING_VALUE, 
		double h02_m=MISSING_VALUE, double h02_s2=MISSING_VALUE,
		double hs_m=MISSING_VALUE, double hs_s2=MISSING_VALUE)
{

  double n=(double) len;


  function_timer::start_timer(4);

  if(s2<0.0 || h01>hs || h02>hs || hmin<h01 || hs<hmin || hs>hmax)
    return -1e+216;

  // contrubtion from (beta-m)V^(-1)(beta-m);
  double m[3], beta[3];
  m[0]=a1_m;
  m[1]=b1_m;
  m[2]=b2_m;
  beta[0]=a1;
  beta[1]=b1;
  beta[2]=b2;

  double contrib_pri_beta = multinormal_pdf(beta,m,var,3,b_true);
  double contrib_h01=0.0;
  double contrib_hs=log(ABSVAL(b1))-0.5*log(2.0*M_PI*sigma2_q)-
    0.5*(a1+b1*log(hs-h01)-mu_q)*(a1+b1*log(hs-h01)-mu_q)/sigma2_q;
  double contrib_h02=//-0.5*(h02-h01-mu_h02)*(h02-h01-mu_h02)/sd_h02/sd_h02;
    +log(sqrt(2.0)/sd_h02)-ABSVAL((h02-h01-mu_h02))*sqrt(2.0)/sd_h02;

  if(h01_m!=MISSING_VALUE && h01_s2!=MISSING_VALUE)
    contrib_h01=-0.5*(h01-h01_m)*(h01-h01_m)/h01_s2;
  if(h02_m!=MISSING_VALUE && h02_s2!=MISSING_VALUE)
    contrib_h02=-0.5*(h02-h02_m)*(h02-h02_m)/h02_s2;
  if(hs_m!=MISSING_VALUE && hs_s2!=MISSING_VALUE)
    contrib_hs=-0.5*(hs-hs_m)*(hs-hs_m)/hs_s2;

  // contribution from (sigma�)^-(a+2+n/2)*exp(-b/sigma�)
  double contrib_s2 = - (sigma_a+1.0)*log(s2) - sigma_b/s2;
  
  double SS=find_SS2(h, q,len,a1,b1,b2,hs,h01,h02);
  // contribution from the exponensial data part of the likelihood function;
  double contrib_lik=-0.5*n*log(s2)-SS/2.0/s2;

  double ret = contrib_pri_beta +contrib_s2 +
    contrib_h01+contrib_h02 +contrib_hs +contrib_lik;

  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;

  function_timer::stop_timer(4);

  return ret/T;
}

double logprob1(double *q, double *h, int len, double hmin, 
		double /* hmax */, double a1, double b1, double h01, 
		double s2, double **var,
		double a1_m, double b1_m, 
		double sigma_a, double sigma_b,
		double h01_m=MISSING_VALUE, double h01_s2=MISSING_VALUE)
{

  double n=(double) len;

  function_timer::start_timer(4);

  if(s2<0.0 || hmin<h01)
    return -1e+216;

  // contrubtion from (beta-m)V^(-1)(beta-m);
  double m[2], beta[2];
  m[0]=a1_m;
  m[1]=b1_m;
  beta[0]=a1;
  beta[1]=b1;

  double contrib_pri_beta = multinormal_pdf(beta,m,var,2,b_true);
  
  double contrib_h01=0.0;

  if(h01_m!=MISSING_VALUE && h01_s2!=MISSING_VALUE)
    contrib_h01=-0.5*(h01-h01_m)*(h01-h01_m)/h01_s2;

  // contribution from (sigma�)^-(a+2+n/2)*exp(-b/sigma�)
  double contrib_s2 = - (sigma_a+1.0)*log(s2) - sigma_b/s2;
  
  double SS=find_SS1(h, q,len,a1,b1,h01);
  // contribution from the exponensial data part of the likelihood function;
  double contrib_lik=-0.5*n*log(s2)-SS/2.0/s2;

  double ret = contrib_pri_beta +contrib_s2 +
    contrib_h01 + contrib_lik;
  
  if(!(ret>=-1e+200 && ret<=1e+200))
    return -1e+216;

  function_timer::stop_timer(4);

  return ret;
}

double gibbs_sigma2(double *h, double *q, int len, 
		    double sigma_a, double sigma_b, 
		    double a1, double b1, double b2, double hs,
		    double h01, double h02, double T, gsl_rng *rptr,
		    int num_seg)
{
  function_timer::start_timer(5);

  double n=(double) len;
  double sigma_a_star=sigma_a+n/2.0;
  double sigma_b_star=sigma_b;

  if(num_seg==2)
    sigma_b_star+=find_SS2(h, q,len,a1,b1,b2,hs,h01,h02)/2.0;
  else
    sigma_b_star+=find_SS1(h, q,len,a1,b1,h01)/2.0;

  if(T!=1.0)
    {
      sigma_a_star=(sigma_a_star+1.0-T)/T;
      sigma_b_star/=T;
    }

  double s2=1.0/gsl_ran_gamma(rptr, sigma_a_star, 1.0/sigma_b_star);

  function_timer::stop_timer(5);

  return s2;
}

void get_linear_proposal_hyperparameters2(double *h, double *q, int len,
					  double *m, double **V,
					  double hs, double h01, double h02,
					  double s2, double T,
					  double **m_star_, double ***V_star_)
{
  function_timer::start_timer(1);

  double **XtX=new double*[3], **V_star, **inv_V_star=new double*[3], 
    **inv_V;
  int i,j;
  double *b1=new double[len],*b2=new double[len];

  function_timer::start_timer(0);
  inv_V=inverse_matrix(V,3);
  function_timer::stop_timer(0);
  
  function_timer::start_timer(2);
  for(i=0;i<3;i++)
    {
      XtX[i]=new double[3];
      for(j=0;j<3;j++)
	XtX[i][j]=0.0;
    }
  for(i=0;i<3;i++)
    inv_V_star[i]=new double[3];

  function_timer::start_timer(3);
  for(i=0;i<len;i++)
    {
      b1[i]=B1(h[i],hs,h01);
      b2[i]=B2(h[i],hs,h02);

      XtX[0][0]++;
      XtX[0][1]+=b1[i];
      XtX[1][1]+=b1[i]*b1[i];
      XtX[0][2]+=b2[i];
      XtX[1][2]+=b1[i]*b2[i];
      XtX[2][2]+=b2[i]*b2[i];
    }
  XtX[1][0]=XtX[0][1];
  XtX[2][0]=XtX[0][2];
  XtX[2][1]=XtX[1][2];
  function_timer::stop_timer(3);
  
  for(i=0;i<3;i++)
    for(j=0;j<3;j++)
      inv_V_star[i][j]=inv_V[i][j]+XtX[i][j]/s2;
  function_timer::stop_timer(2);

  function_timer::start_timer(0);
  V_star=inverse_matrix(inv_V_star,3);
  function_timer::stop_timer(0);
  
  double m_star_raw[3], *m_star=new double[3];
  
  function_timer::start_timer(2);
  for(i=0;i<3;i++)
    m_star_raw[i]=m_star[i]=0.0;
  
  for(i=0;i<3;i++)
    for(j=0;j<3;j++)
      m_star_raw[i]+=inv_V[i][j]*m[j];
  for(i=0;i<len;i++)
    {
      m_star_raw[0]+=q[i]/s2;
      m_star_raw[1]+=q[i]*b1[i]/s2;
      m_star_raw[2]+=q[i]*b2[i]/s2;
    }
  
  for(i=0;i<3;i++)
    for(j=0;j<3;j++)
      m_star[i]+=V_star[i][j]*m_star_raw[j];

  delete [] b1;
  delete [] b2;
  doubledelete(XtX,3);
  doubledelete(inv_V_star,3);
  doubledelete(inv_V,3);

  if(T!=1.0)
    for(i=0;i<3;i++)
      for(j=0;j<3;j++)
	V_star[i][j]*=T;
  function_timer::stop_timer(2);

  *m_star_=m_star;
  *V_star_=V_star;

  function_timer::stop_timer(1);
}

void get_linear_proposal_hyperparameters1(double *h, double *q, int len,
					  double *m, double **V,
					  double h01, double s2, 
					  double **m_star_, double ***V_star_)
{
  function_timer::start_timer(1);

  double **XtX=new double*[2], **V_star, **inv_V_star=new double*[2], 
    **inv_V;
  int i,j;
  double *b1=new double[len];

  function_timer::start_timer(0);
  inv_V=inverse_matrix(V,2);
  function_timer::stop_timer(0);
  
  function_timer::start_timer(2);
  for(i=0;i<2;i++)
    {
      XtX[i]=new double[2];
      for(j=0;j<2;j++)
	XtX[i][j]=0.0;
    }
  for(i=0;i<2;i++)
    inv_V_star[i]=new double[2];

  function_timer::start_timer(3);
  for(i=0;i<len;i++)
    {
      b1[i]=B0(h[i],h01);

      XtX[0][0]++;
      XtX[0][1]+=b1[i];
      XtX[1][1]+=b1[i]*b1[i];
    }
  XtX[1][0]=XtX[0][1];
  function_timer::stop_timer(3);
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      inv_V_star[i][j]=inv_V[i][j]+XtX[i][j]/s2;
  function_timer::stop_timer(2);

  function_timer::start_timer(0);
  V_star=inverse_matrix(inv_V_star,2);
  function_timer::stop_timer(0);
  
  double m_star_raw[2], *m_star=new double[2];
  
  function_timer::start_timer(2);
  for(i=0;i<2;i++)
    m_star_raw[i]=m_star[i]=0.0;
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      m_star_raw[i]+=inv_V[i][j]*m[j];
  for(i=0;i<len;i++)
    {
      m_star_raw[0]+=q[i]/s2;
      m_star_raw[1]+=q[i]*b1[i]/s2;
    }
  
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      m_star[i]+=V_star[i][j]*m_star_raw[j];

  delete [] b1;
  doubledelete(XtX,2);
  doubledelete(inv_V_star,2);
  doubledelete(inv_V,2);

  function_timer::stop_timer(2);

  *m_star_=m_star;
  *V_star_=V_star;

  function_timer::stop_timer(1);
}

double gibbs_linear2(double *h, double *q, int len,
		     double *m, double **V,
		     double hs, double h01, double h02,
		     double s2, double T, double *new_a1, double *new_b1, 
		     double *new_b2, gsl_rng *rptr)
{
  double *m_star, **V_star, ret;

  get_linear_proposal_hyperparameters2(h, q, len, m, V, hs, h01, h02, s2, T,
				       &m_star, &V_star);

  function_timer::start_timer(6);
  double **samples=sample_from_multinormal(1,m_star,V_star,3,rptr);
  
  *new_a1=samples[0][0];
  *new_b1=samples[0][1];
  *new_b2=samples[0][2];

  ret=multinormal_pdf(samples[0],m_star,V_star,3,b_true);
  function_timer::stop_timer(6);

  delete [] m_star;
  doubledelete(V_star,3);
  doubledelete(samples,1);
  
  return ret;
}

double gibbs_linear1(double *h, double *q, int len,
		     double *m, double **V,
		     double h01, double s2, double *new_a1, double *new_b1, 
		     gsl_rng *rptr)
{
  double *m_star, **V_star, ret;

  get_linear_proposal_hyperparameters1(h, q, len, m, V, h01, s2, 
				       &m_star, &V_star);
  
  function_timer::start_timer(6);
  double **samples=sample_from_multinormal(1,m_star,V_star,2,rptr);
  
  *new_a1=samples[0][0];
  *new_b1=samples[0][1];

  ret=multinormal_pdf(samples[0],m_star,V_star,2,b_true);
  function_timer::stop_timer(6);

  delete [] m_star;
  doubledelete(V_star,2);
  doubledelete(samples,1);
  
  return ret;
}

double get_proposal_logdensity2(double *h, double *q, int len,
			       double *m, double **V, double s2, double hs,
			       double prop_a1, double prop_b1, double prop_b2,
			       double prop_h01,double prop_h02, double T)
{
  double *m_star, **V_star;
  double ret, *beta=new double[3];
  
  beta[0]=prop_a1;
  beta[1]=prop_b1;
  beta[2]=prop_b2;

  get_linear_proposal_hyperparameters2(h, q, len, m, V, hs, 
				       prop_h01, prop_h02, s2, T,
				       &m_star, &V_star);
  
  ret=multinormal_pdf(beta,m_star,V_star,3,b_true);

  delete [] m_star;
  doubledelete(V_star,3);
  delete [] beta;

  return ret;
}

double get_proposal_logdensity1(double *h, double *q, int len,
			       double *m, double **V, double s2, 
			       double prop_a1, double prop_b1, 
			       double prop_h01)
{
  double *m_star, **V_star;
  double ret, *beta=new double[2];
  
  beta[0]=prop_a1;
  beta[1]=prop_b1;

  get_linear_proposal_hyperparameters1(h, q, len, m, V, prop_h01, s2,
				       &m_star, &V_star);
  
  ret=multinormal_pdf(beta,m_star,V_star,2,b_true);

  delete [] m_star;
  doubledelete(V_star,2);
  delete [] beta;

  return ret;
}

void draw_parameters(double *stage, double *discharge, 
		     int number_of_measurements, 
		     // measurements
		     
		     // output:
		     double **sampled_a1,
		     double **sampled_b1,
		     double **sampled_b2,
		     double **sampled_hs,
		     double **sampled_h01,
		     double **sampled_h02,
		     double **sampled_s2,
		     double **sampled_psi,
		     int **sampled_num_seg,

		     // Optional input::
		     
		     int num_sim, 
		     // number of drawings
		     
		     // prior knowledge:
		     double est_exp, 
		     double sdev_exp, 
		     double est_logconst, 
		     double sdev_logconst,
		     double corr,
		     double sigma_a, 
		     double sigma_b, 
		     //double h01_mean, double h01_sdev,
		     //double h02_mean, double h02_sdev,
		     //double hs_mean, double hs_sdev,
		     double mu_q, double sd_q,
		     double mu_h02, double sd_h02,
		     
		     int indep, 
		     /* spacing between drawings */
		     
		     int burnin, 
		     /* burn-in length */
		     int num_temp
		     )
{
  int i;

  // Store the measurements:
  int num_meas=number_of_measurements, len=number_of_measurements;
  double *q=new double[num_meas];
  double *h=new double[num_meas];
  for(i=0;i<num_meas;i++)
    {
      q[i]=log(discharge[i]);
      h[i]=stage[i];
    }    
  
  double *m=new double[3];
  double minh=find_statistics(h,num_meas,MIN);
  double maxh=find_statistics(h,num_meas,MAX);
  double *T=new double[num_temp];
  double *prev_logprob=new double[num_temp];

  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand()); 
  
  double **var=new double*[3];
  var[0]=new double[3];
  var[1]=new double[3];
  var[2]=new double[3];
  m[0]=est_logconst;
  m[1]=est_exp;
  m[2]=est_exp;
  var[0][0]=sdev_logconst*sdev_logconst;
  var[1][1]=var[2][2]=sdev_exp*sdev_exp;
  var[0][1]=corr*sdev_logconst*sdev_exp;
  var[0][2]=corr*sdev_logconst*sdev_exp;
  var[1][0]=corr*sdev_logconst*sdev_exp;
  var[2][0]=corr*sdev_logconst*sdev_exp;
  var[2][1]=corr*corr*sdev_exp*sdev_exp;
  var[1][2]=corr*corr*sdev_exp*sdev_exp;


  double *a1=new double[num_sim];
  double *b1=new double[num_sim];
  double *b2=new double[num_sim];
  double *hs=new double[num_sim];
  double *h01=new double[num_sim];
  double *h02=new double[num_sim];
  double *s2=new double[num_sim];
  double *psi=new double[num_sim];
  int *num_seg=new int[num_sim];
  
  double *prev_a1=new double[num_temp], *prev_b1=new double[num_temp], 
    *prev_b2=new double[num_temp], *prev_h01=new double[num_temp], 
    *prev_h02=new double[num_temp], *prev_hs=new double[num_temp],
    *prev_s2=new double[num_temp];
  int prev_num_seg=2;
  
  int t;
  int *numswaps=new int[num_temp-1];
  // First sample;
  for(t=0;t<num_temp;t++)
    {
      if(t==0)
	T[t]=1.0;
      else
	T[t]=2.0*T[t-1];
      if(t<num_temp-1)
	numswaps[t]=0; 

      prev_a1[t]=est_logconst+gsl_ran_gaussian(rptr, sdev_logconst);
      prev_b1[t]=est_exp;//+gsl_ran_gaussian(rptr, sdev_exp);
      prev_b2[t]=est_exp;//+gsl_ran_gaussian(rptr, sdev_exp);
      prev_h01[t]=minh-drand48();
      prev_h02[t]=minh-drand48();
      prev_hs[t]=minh+drand48()*(maxh-minh);
      prev_s2[t]=sigma_a>0.0 ? 1.0/gsl_ran_gamma(rptr,sigma_a,1.0/sigma_b) :
	1.0e+5*drand48();
      
      prev_logprob[t]=logprob2(q,h,num_meas,minh,maxh,
			       prev_a1[t],prev_b1[t],prev_b2[t],prev_hs[t],
			       prev_h01[t],prev_h02[t],prev_s2[t],
			       var,est_logconst,est_exp,est_exp,
			       mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,
			       T[t]);
    }

  double acc_h01=0.0, acc_h02=0.0, acc_hs=0.0, total=0.0;
  int do_h01=1;
  double rw_h01=0.01, rw_h02=0.01, rw_hs=0.01;
  double m_hs=0.0, s_hs=0.0, m_b2=0.0, s_b2=0.0, m_h02=0.0, s_h02=0.0;
  int m_len=0;

  for(i=1;i<=num_sim*indep+burnin;i++)
    {
      if(prev_num_seg==2 && drand48()<0.1 && num_temp>1)
	{
	  int t=(int) floor(drand48()*double(num_temp-1));

	  double new_logprob1=
	    logprob2(q,h,num_meas,minh,maxh,prev_a1[t+1],
		     prev_b1[t+1],prev_b2[t+1],
		     prev_hs[t+1],prev_h01[t+1], prev_h02[t+1],prev_s2[t+1],
		     var,est_logconst,est_exp,est_exp,
		     mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
	  double new_logprob2=
	    logprob2(q,h,num_meas,minh,maxh,prev_a1[t],
		     prev_b1[t],prev_b2[t],
		     prev_hs[t],prev_h01[t], prev_h02[t],prev_s2[t],
		     var,est_logconst,est_exp,est_exp,
		     mu_q,sd_q*sd_q,sigma_a,sigma_b,mu_h02,sd_h02,T[t+1]);

	  // swap parameters between distribution t and distribution t+1
	  if(log(drand48())< new_logprob1+new_logprob2-
	     prev_logprob[t]-prev_logprob[t+1])
	    {
	      //cout << "Swap: " << t+1 << " vs " << t+2 << endl; 
	      numswaps[t]++;

	      double a1_buff=prev_a1[t],b1_buff=prev_b1[t],b2_buff=prev_b2[t],
		hs_buff=prev_hs[t],h01_buff=prev_h01[t],h02_buff=prev_h02[t],
		s2_buff=prev_s2[t];

	      prev_a1[t]=prev_a1[t+1];
	      prev_b1[t]=prev_b1[t+1];
	      prev_b2[t]=prev_b2[t+1];
	      prev_hs[t]=prev_hs[t+1];
	      prev_h01[t]=prev_h01[t+1];
	      prev_h02[t]=prev_h02[t+1];
	      prev_s2[t]=prev_s2[t+1];
	      prev_logprob[t]=new_logprob1;

	      prev_a1[t+1]=a1_buff;
	      prev_b1[t+1]=b1_buff;
	      prev_b2[t+1]=b2_buff;
	      prev_hs[t+1]=hs_buff;
	      prev_h01[t+1]=h01_buff;
	      prev_h02[t+1]=h02_buff;
	      prev_s2[t+1]=s2_buff;
	      prev_logprob[t+1]=new_logprob2;
	    }
	}
      else // parallell MCMC
	{
	  double new_logprob;

	  if(i>burnin*3/4 && drand48()<0.1) // propose jump?
	    {
	      double new_a1=prev_a1[0]+gsl_ran_gaussian(rptr, 0.01);
	      double new_b1=prev_b1[0]+gsl_ran_gaussian(rptr, 0.01);
	      double new_b2=m_b2+gsl_ran_gaussian(rptr, s_b2);
	      double new_hs=m_hs+gsl_ran_gaussian(rptr, s_hs);
	      double new_h01=prev_h01[0]+gsl_ran_gaussian(rptr, 0.01);
	      double new_h02=m_h02+gsl_ran_gaussian(rptr, s_h02);
	      double new_s2=prev_s2[0]+gsl_ran_gaussian(rptr, 0.0001);

	      if(prev_num_seg==1) // expansion
		{
		  double q1=logprob2(q,h,num_meas,minh,maxh,
				     new_a1, new_b1, new_b2, new_hs,
				     new_h01, new_h02, new_s2,
				     var, est_logconst, est_exp, est_exp,
				     mu_q,sd_q*sd_q,sigma_a,sigma_b,
				     mu_h02,sd_h02, T[0]);
		  double q0=logprob1(q,h,num_meas,minh,maxh,prev_a1[0],
				     prev_b1[0], prev_h01[0], prev_s2[0],
				     var,est_logconst,est_exp,
				     sigma_a,sigma_b);
		  double g=log(gsl_ran_gaussian_pdf(new_b2-m_b2, s_b2))+
		    log(gsl_ran_gaussian_pdf(new_h02-m_h02, s_h02))+
		    log(gsl_ran_gaussian_pdf(new_hs-m_hs, s_hs));
		  // T2(y',y)=T1(y,y')

		  if(log(drand48())<q1-q0-g)
		    {
		      prev_a1[0]=new_a1;
		      prev_b1[0]=new_b1;
		      prev_b2[0]=new_b2;
		      prev_hs[0]=new_hs;
		      prev_h01[0]=new_h01;
		      prev_h02[0]=new_h02;
		      prev_s2[0]=new_s2;
		      prev_num_seg=2;
		    }
		}
	      else // contraction
		{
		  double q1=logprob2(q,h,num_meas,minh,maxh,
				     prev_a1[0], prev_b1[0], prev_b2[0], 
				     prev_hs[0], prev_h01[0], prev_h02[0], 
				     prev_s2[0],
				     var, est_logconst, est_exp, est_exp,
				     mu_q,sd_q*sd_q,sigma_a,sigma_b,
				     mu_h02,sd_h02, T[0]);
		  double q0=logprob1(q,h,num_meas,minh,maxh,new_a1,
				     new_b1, new_h01, new_s2,
				     var,est_logconst,est_exp,
				     sigma_a,sigma_b);

		  double g=log(gsl_ran_gaussian_pdf(prev_b2[0]-m_b2, s_b2))+
		    log(gsl_ran_gaussian_pdf(prev_h02[0]-m_h02, s_h02))+
		    log(gsl_ran_gaussian_pdf(prev_hs[0]-m_hs, s_hs));
		  // T2(y,y')=T1(y',y)

		  /*
		  cout << q1 << " " << q0 << " " << g << " " << q0-q1+g << 
		    " " << logprob1(q,h,num_meas,minh,maxh,prev_a1[0],
				    prev_b1[0], prev_h01[0], prev_s2[0],
				    var,est_logconst,est_exp,
				    sigma_a,sigma_b) << endl;
		  */

		  if(log(drand48())<q0-q1+g)
		    {
		      prev_a1[0]=new_a1;
		      prev_b1[0]=new_b1;
		      prev_b2[0]=new_b2;
		      prev_hs[0]=new_hs;
		      prev_h01[0]=new_h01;
		      prev_h02[0]=new_h02;
		      prev_s2[0]=new_s2;
		      prev_num_seg=1;
		    }
		}
	    }
	  else if(prev_num_seg==1)
	    {
	      double steptype=1.0;
	      double r=drand48();
	      if(r<0.1)
		steptype/=10.0;
	      else if(r<0.2)
		steptype/=300.0;
	      else if(r<0.3)
		steptype/=10000.0;
	      else if(r<0.4)
		steptype*=10.0;
	      else if(r<0.5)
		steptype*=100.0;
	      
	      // Update s^2
	      prev_s2[0]=gibbs_sigma2(h, q, len, sigma_a, sigma_b, 
				      prev_a1[0], prev_b1[0], 
				      prev_b2[0], prev_hs[0],
				      prev_h01[0], prev_h02[0], 
				      T[0], rptr, 1);
		  
	      // Update h01, a1, b1:
	      double new_a1, new_b1;
	      double new_h01=prev_h01[0]+gsl_ran_gaussian(rptr,
							  steptype*rw_h01);
		  
	      double new_proposal=
		gibbs_linear1(h, q, len, m, var,  
			      new_h01, prev_s2[0], &new_a1, 
			      &new_b1, rptr);
	      
	      new_logprob=logprob1(q,h,num_meas,minh,maxh,new_a1,new_b1,
				   new_h01, prev_s2[0],
				   var,est_logconst,est_exp,
				   sigma_a,sigma_b);
	      
	      
	      double prev_proposal=
		get_proposal_logdensity1(h,q,len,m,var,prev_s2[0], 
					 prev_a1[0], prev_b1[0], prev_h01[0]);
	      
	      if(log(drand48())<((new_logprob-prev_logprob[0])-
				 (new_proposal-prev_proposal)))
		{
		  prev_h01[0]=new_h01;
		  prev_a1[0]=new_a1;
		  prev_b1[0]=new_b1;
		  prev_logprob[0]=new_logprob;
		}

	      prev_num_seg=1;
	    }
	  else // 2 segments
	    {
	      for(t=0;t<num_temp;t++)
		{
		  double steptype=sqrt(T[t]);
		  double r=drand48();
		  if(r<0.1)
		    steptype/=10.0;
		  else if(r<0.2)
		    steptype/=300.0;
		  else if(r<0.3)
		    steptype/=10000.0;
		  else if(r<0.4)
		    steptype*=10.0;
		  else if(r<0.5)
		    steptype*=100.0;
		  
		  if(t==0 && i>burnin/4 && i<=burnin/2 && i%1000==0)
		    {
		      acc_h01/=total;
		      acc_h02/=total;
		      acc_hs/=total;
		      
		      rw_hs*=exp((acc_hs-0.33)*2.0);
		      if(do_h01)
			rw_h01*=exp((acc_h01-0.33)*2.0);
		      else
			rw_h02*=exp((acc_h02-0.33)*2.0);
		      do_h01=!do_h01;
		      
		      acc_h01=acc_hs=total=0.0;
		    }
		  
		  if(i==burnin/4)
		    total=acc_h01=acc_h02=acc_hs=0.0;

		  if(t==0)
		    total++;

		  // Update s^2
		  prev_s2[t]=gibbs_sigma2(h, q, len, sigma_a, sigma_b, 
					  prev_a1[t], prev_b1[t], 
					  prev_b2[t], prev_hs[t],
					  prev_h01[t], prev_h02[t], 
					  T[t], rptr, 2);
		  
		  // Update hs:
		  double new_hs=prev_hs[t]+gsl_ran_gaussian(rptr,
							    steptype*rw_hs);
		  new_logprob=logprob2(q,h,num_meas,minh,maxh,prev_a1[t],
				       prev_b1[t],prev_b2[t],
				       new_hs,prev_h01[t],
				       prev_h02[t],prev_s2[t],
				       var,est_logconst,est_exp,est_exp,
				       mu_q,sd_q*sd_q,sigma_a,sigma_b,
				       mu_h02,sd_h02,T[t]);
		  if(log(drand48())<new_logprob-prev_logprob[t])
		    {
		      prev_hs[t]=new_hs;
		      prev_logprob[t]=new_logprob;
		      if(t==0)
			acc_hs++;
		    }
		  
		  // Update h01, h02, a1, b1, b2:
		  double new_a1, new_b1, new_b2;
		  double new_h01=prev_h01[t]+gsl_ran_gaussian(rptr,
							      steptype*rw_h01);
		  double new_h02=prev_h02[t]+gsl_ran_gaussian(rptr,
							      steptype*rw_h02);
		  
		  if(t==0 && i>burnin/4 && i<burnin/2)
		    {
		      if(do_h01)
			new_h02=prev_h02[t];
		      else
			new_h01=prev_h01[t];
		    }
		  
		  double new_proposal=
		    gibbs_linear2(h, q, len, m, var, prev_hs[t], 
				  new_h01, new_h02,
				  prev_s2[t], T[t], &new_a1, 
				  &new_b1, &new_b2, rptr);
		  
		  new_logprob=logprob2(q,h,num_meas,minh,maxh,new_a1,new_b1,
				       new_b2, prev_hs[t], new_h01, 
				       new_h02, prev_s2[t],
				       var,est_logconst,est_exp,est_exp,
				       mu_q, sd_q*sd_q, 
				       sigma_a,sigma_b,mu_h02,sd_h02,T[t]);
		  
		  
		  double prev_proposal=
		    get_proposal_logdensity2(h,q,len,m,var,prev_s2[t], 
					     prev_hs[t], prev_a1[t], 
					     prev_b1[t], prev_b2[t],
					     prev_h01[t], prev_h02[t], T[t]);
		  
		  if(log(drand48())<((new_logprob-prev_logprob[t])-
				     (new_proposal-prev_proposal)))
		    {
		      prev_h01[t]=new_h01;
		      prev_h02[t]=new_h02;
		      prev_a1[t]=new_a1;
		      prev_b1[t]=new_b1;
		      prev_b2[t]=new_b2;
		      prev_logprob[t]=new_logprob;
		      if(t==0)
			{
			  acc_h01++;
			  acc_h02++;
			}
		    }
		}

	      if(i>burnin/2 && i<=burnin*3/4)
		{
		  m_h02 += prev_h02[0];
		  s_h02 += prev_h02[0]*prev_h02[0];
		  m_hs += prev_hs[0];
		  s_hs += prev_hs[0]*prev_hs[0];
		  m_b2 += prev_b2[0];
		  s_b2 += prev_b2[0]*prev_b2[0];
		  m_len++;
		}
	      if(i==burnin*3/4)
		{
		  m_h02/=double(m_len);
		  m_hs/=double(m_len);
		  m_b2/=double(m_len);
		  s_h02/=double(m_len);
		  s_hs/=double(m_len);
		  s_b2/=double(m_len);
		  s_h02-=m_h02*m_h02;
		  s_hs-=m_hs*m_hs;
		  s_b2-=m_b2*m_b2;
		  s_h02=sqrt(s_h02);
		  s_hs=sqrt(s_hs);
		  s_b2=sqrt(s_b2);
		  
		  cout << m_h02 << " " << s_h02 << " " << m_hs << " " << 
		    s_hs << " " << m_b2 << " " << s_b2 << endl;
		}

	      prev_num_seg=2;
	    }
	}
      

      if(i%1000==0)
	{
	  cout << i << " " << prev_a1[0] << " " << 
	    prev_b1[0] << " " << prev_b2[0] << " " << prev_hs[0] << 
	    " "  << prev_h01[0] << " " << prev_h02[0] << " " << 
	    prev_s2[0] << " " << prev_logprob[0] << " " << prev_num_seg << 
	    endl;
	}
      
      if(i>burnin && (i-burnin)%indep==0)
	{
	  a1[(i-burnin)/indep-1]=prev_a1[0];
	  b1[(i-burnin)/indep-1]=prev_b1[0];
	  b2[(i-burnin)/indep-1]=prev_b2[0];
	  hs[(i-burnin)/indep-1]=prev_hs[0];
	  h01[(i-burnin)/indep-1]=prev_h01[0];
	  h02[(i-burnin)/indep-1]=prev_h02[0];
	  s2[(i-burnin)/indep-1]=prev_s2[0];
	  psi[(i-burnin)/indep-1]=prev_logprob[0];
	  num_seg[(i-burnin)/indep-1]=prev_num_seg;
	}
    }

  cout << "Linear+h01+h02 acceptance rate:" << acc_h01/total*100.0 << 
    "%" << endl;
  cout << "Hs acceptance rate:" << acc_hs/total*100.0 << "%" << endl;
  cout << "rw_h01:" << rw_h01 << " rw_h02:" << rw_h02 << " rw_hs:" << 
    rw_hs << endl;

  for(t=0;t<num_temp-1;t++)
    cout << "Number of swaps from " << t+1 << " to " << 
      t+2 << " : " << numswaps[t] << endl;

  *sampled_a1=a1;
  *sampled_b1=b1;
  *sampled_b2=b2;
  *sampled_hs=hs;
  *sampled_h01=h01;
  *sampled_h02=h02;
  *sampled_s2=s2;
  *sampled_psi=psi;
  *sampled_num_seg=num_seg;

  delete [] m;
  doubledelete(var,3);
}

void usage(void)
{
  cout << "Usage: 2mod <input file> <number of simulations> <burnin> <indep> "
    "<num temp>" << endl;
  exit(0);
}

double get_Q(double h, double a1, double b1, double b2, double hs, 
	     double h01, double h02, int num_seg)
{
  double Q=0.0;
  
  if(a1==MISSING_VALUE || b1==MISSING_VALUE || h01==MISSING_VALUE)
    return MISSING_VALUE;
  
  if((num_seg==1 && h>h01) || (num_seg==2 && h<hs && h>h01))
    Q=exp(a1)*pow(h-h01, b1);
  else if(num_seg==2 && h>hs && h>h02)
    {
      double a2=a1+b1*log(hs-h01)-b2*log(hs-h02);
      Q=exp(a2)*pow(h-h02, b2);
    }

  return Q;
}

void show_parameter(double *par, int N, char *parname, char *filename,
		    int *num_seg=NULL) 
{
  char cmd[1000];
  FILE *p;
  int i, len=N;

  double *par_buff=new double[N];
  if(num_seg)
    {
      int j=0;
      for(i=0;i<N;i++)
	if(num_seg[i]==2)
	  par_buff[j++]=par[i];
      len=j;
    }
  else
    for(i=0;i<N;i++)
      par_buff[i]=par[i];

  double rho=get_auto_correlation(par_buff, len);
  double spacing=2.0*(0.5+rho/(1.0-rho));
  cout << parname << " - spacing between independent samples:" << 
    spacing << endl;

  sprintf(cmd, "vvgraph -x %s", parname);
  p=popen(cmd,"w");
  fprintf(p,"# Column 1: %s, %s\n", filename, parname);
  fprintf(p,"###################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%d %f\n", i+1, par_buff[i]);
  pclose(p);

  sprintf(cmd, "histogramme -x \"%s\" -t \"%s, %s\"", 
	  parname, filename, parname); 
  p=popen(cmd, "w");
  for(i=0;i<len;i++)
    fprintf(p,"%f\n", par_buff[i]);
  pclose(p);

  delete [] par_buff;
}

void show_scatter(double *par1, double *par2, int N, 
		  char *parname1, char *parname2, char *filename,
		  int *num_seg=NULL)
{
  FILE *p;
  char cmd[1000];
  int i, len=N;

  double *par1_buff=new double[N], *par2_buff=new double[N];
  if(num_seg)
    {
      int j=0;
      for(i=0;i<N;i++)
	if(num_seg[i]==2)
	  {
	    par1_buff[j]=par1[i];
	    par2_buff[j]=par2[i];
	    j++;
	  }
      len=j;
    }
  else
    for(i=0;i<N;i++)
      {
	par1_buff[i]=par1[i];
	par2_buff[i]=par2[i];
      }

  sprintf(cmd, "vvgraph -x %s -y %s", parname1, parname2);
  p=popen(cmd,"w");
  fprintf(p, "# Column 1: %s vs %s for dataset %s\n", parname1, parname2, 
	  filename);
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%f %f\n", par1_buff[i], par2_buff[i]);
  pclose(p);
}

int main(int argc, char **argv)
{
  if(argc!=6)
    usage();
 
  randify();

  // Fetch the data file;
  int i,j,len, N=atoi(argv[2]);
  char errmsg[1000];
  StageDischarge *data=get_sd_file(argv[1], &len, errmsg);
  /*double sd_a=atof(argv[3]);
  double sd_b=atof(argv[4]);
  double sd_h=atof(argv[5]);
  double sd_s2=atof(argv[6]);*/
  int burnin=atoi(argv[3]);
  int indep=atoi(argv[4]);
  int numtemp=atoi(argv[5]);

  if(len<=0 || !data) // test if there's an error reading data
    {
      cout << errmsg << endl;
      exit(0);
    }
   
  double *q=new double[len], *h=new double[len];
  for(i=0;i<len;i++)
    {
      q[i]=data[i].q;
      h[i]=data[i].h;
      // cout << h[i] << " " << q[i] << endl;
    }

  double maxT=pow(2.0, double(numtemp-1));
  if(double(len)/2.0+1.0-maxT<0.0)
    {
      cout << "Too many temperatures!" << endl;
      cout << "Max possible number of temperatures for this dataset:";
      cout << 1+int(floor(log(double(len)/2.0+1.0)/log(2.0))) << endl;
      exit(0);
    }

  double *a1,*b1,*b2,*hs,*h01,*h02,*s2,*psi;
  int *numseg;
  function_timer::start_total_timer(7);
  draw_parameters(h,q,len,&a1,&b1,&b2,&hs,&h01,&h02,&s2,&psi,&numseg, N,
		  2.46,0.92, 2.84,1.38, -0.42, 1.356, 0.00176, 
		  1.8, 2.35, 0.264, 0.683, // default
		  //2.46,0.92, 2.84,1.38, -0.42, 0.0, 0.0, 
		  //1.8, 2.35, 0.0, 2.0, // wide hs
		  //2.46,2.0, 2.84,3.0, -0.42, 0.0,0.0,
		  //1.8, 3.0, 0.0, 2.0, // wide hs,h02
		  //2.46,0.92, 2.84, 1.38, -0.42, 0.0, 0.0, 
		  //10.0, 0.4, 0.0, 10.0, // corrientes
		  indep, burnin, numtemp); 
  function_timer::stop_total_timer();
  double t0=function_timer::get_total_timer(), 
    t1=function_timer::get_timer(0),
    t2=function_timer::get_timer(1),
    t3=function_timer::get_timer(2),
    t4=function_timer::get_timer(3),
    t5=function_timer::get_timer(4),
    t6=function_timer::get_timer(5),
    t7=function_timer::get_timer(6);
  cout << "Total tid:" << t0 << "s." << endl;
  cout << "Brukt tid p� � kvadratiske "
    "beregninger:" << t2 << "s. Forhold:" << t2/t0*100.0 << "%" << endl;
  cout << "Brukt tid p� invertering i kvad:" << t1 << 
    "s. Forhold:" << t1/t2*100.0 << "%" << endl;
  cout << "Brukt tid p� � l�kker i kvad:" << t3 << 
    "s. Forhold:" << t3/t2*100.0 << "%" << endl;
  cout << "Brukt tid p� XtX i l�kkene:" << t4 << 
    "s. Forhold:" << t4/t3*100.0 << "%" << endl;
  cout << "Brukt tid p� logprob:" << t5 << 
    "s. Forhold:" << t5/t0*100.0 << "%" << endl;
  cout << "Brukt tid p� gibbs_sigma2:" << t6 << 
    "s. Forhold:" << t6/t0*100.0 << "%" << endl;
  cout << "Brukt tid p� multinormale beregninger:" << t7 << 
    "s. Forhold:" << t7/t0*100.0 << "%" << endl;

  int num1=0;
  for(i=0;i<N;i++)
    if(numseg[i]==1)
      num1++;

  cout << "Antall trekninger fra modell 1: " << num1 << " / " << N << " = " <<
    double(num1)/double(N)*100.0 << "%" << endl;

  FILE *p;

  int l1=0, l2=0;
  double *a=new double[N], *b=new double[N], *h0=new double[N];
  double *a21=new double[N], *b21=new double[N], *b22=new double[N], 
    *h2s=new double[N], *h201=new double[N], *h202=new double[N];

  for(i=0;i<N;i++)
    if(numseg[i]==1)
      {
	a[l1]=a1[i];
	b[l1]=b1[i];
	h0[l1]=h01[i];
	l1++;
      }
    else
      {
	a21[l2]=a1[i];
	b21[l2]=b1[i];
	b22[l2]=b2[i];
	h2s[l2]=hs[i];
	h201[l2]=h01[i];
	h202[l2]=h02[i];
	l2++;
      }
  
  double med_a=l1>0 ? find_statistics(a, l1, MEDIAN) : MISSING_VALUE;
  double med_b=l1>0 ? find_statistics(b, l1, MEDIAN) : MISSING_VALUE;
  double med_h0=l1>0 ? find_statistics(h0, l1, MEDIAN) : MISSING_VALUE;

  double med_a1=l2>0 ? find_statistics(a21, l2, MEDIAN) : MISSING_VALUE;
  double med_b1=l2>0 ? find_statistics(b21, l2, MEDIAN) : MISSING_VALUE;
  double med_b2=l2>0 ? find_statistics(b22, l2, MEDIAN) : MISSING_VALUE;
  double med_hs=l2>0 ? find_statistics(h2s, l2, MEDIAN) : MISSING_VALUE;
  double med_h01=l2>0 ? find_statistics(h201, l2, MEDIAN) : MISSING_VALUE;
  double med_h02=l2>0 ? find_statistics(h202, l2, MEDIAN) : MISSING_VALUE;
  double min_h=find_statistics(h01, N, MIN);
  double max_h=find_statistics(h, len, MAX);

  p=popen("vvgraph -x m -y \"m^3/s\"","w");
  fprintf(p,"# Column 1: median(Q(h))\n");
  fprintf(p,"# Column 2: median par. 1-seg: a=%7.3f b=%7.3f h0=%7.3f\n",
	  med_a, med_b, med_h0);
  fprintf(p,"# Column 3: median par. 2-seg: a1=%7.3f b1=%7.3f b2=%7.3f "
	  "hs=%7.3f h01=%7.3f h02=%7.3f\n", med_a1, med_b1, med_b2, med_hs,
	  med_h01, med_h02);
  fprintf(p,"# Column 4: lower limit for 95%% credibility\n");
  fprintf(p,"# Column 5: upper limit for 95%% credibility\n");
  fprintf(p,"# Column 6: measurements from %s\n", argv[1]);
  fprintf(p,"# Column 6 - type: dot\n");
  fprintf(p,"###################\n");
  double *Q=new double[N],x;
  for(x=min_h;x<max_h+1.0;x+=0.005)
    {
      for(i=0;i<N;i++)
	Q[i]=get_Q(x,a1[i],b1[i],b2[i],hs[i],h01[i],h02[i], numseg[i]);
      
      double Q_med=find_statistics(Q,N,MEDIAN);
      double Q1=get_Q(x, med_a, med_b, 0, 0, med_h0, 0, 1);
      double Q2=get_Q(x, med_a1, med_b1, med_b2, med_hs, med_h01, med_h02, 2);
      double lower=find_statistics(Q,N,PERCENTILE_2_5);
      double upper=find_statistics(Q,N,PERCENTILE_97_5);

      if(!((Q1>=0.0 && Q1<1e+10) || Q1==MISSING_VALUE))
	{
	  cout << "Noe er galt!" << endl;
	  Q1=get_Q(x, med_a, med_b, 0, 0, med_h0, 0, 1);
	}

      fprintf(p, "%f %f %f %f %f %f -10000000\n", x, Q_med, Q1, Q2,
	      lower, upper);
    }
  delete [] Q;
  for(j=0;j<len;j++)
    fprintf(p, "%f -10000000 -10000000 -10000000 -10000000 -10000000 %f\n", 
	    h[j], q[j]);
  pclose(p);

  double *s=new double[N];
  for(i=0;i<N;i++)
    s[i]=sqrt(s2[i]);

  show_parameter(a1, N, "a1", argv[1]); 
  show_parameter(b1, N, "b1", argv[1]); 
  show_parameter(b2, N, "b2", argv[1], numseg); 
  show_parameter(hs, N, "hs", argv[1], numseg); 
  show_parameter(h01, N, "h01", argv[1]); 
  show_parameter(h02, N, "h02", argv[1], numseg); 
  show_parameter(s, N, "s", argv[1]);

  show_scatter(a1,  b1,  N, "a1",  "b1",  argv[1]);
  show_scatter(a1,  b2,  N, "a1",  "b2",  argv[1], numseg);
  show_scatter(a1,  hs,  N, "a1",  "hs",  argv[1], numseg);
  show_scatter(a1,  h01, N, "a1",  "h01", argv[1]);
  show_scatter(a1,  h02, N, "a1",  "h02", argv[1], numseg);
  show_scatter(a1,  s,   N, "a1",  "s",   argv[1]);
  show_scatter(b1,  b2,  N, "b1",  "b2",  argv[1], numseg);
  show_scatter(b1,  hs,  N, "b1",  "hs",  argv[1], numseg);
  show_scatter(b1,  h01, N, "b1",  "h01", argv[1]);
  show_scatter(b1,  h02, N, "b1",  "h02", argv[1], numseg);
  show_scatter(b1,  s,   N, "b1",  "s",   argv[1]);
  show_scatter(b2,  hs,  N, "b2",  "hs",  argv[1], numseg);
  show_scatter(b2,  h01, N, "b2",  "h01", argv[1], numseg);
  show_scatter(b2,  h02, N, "b2",  "h02", argv[1], numseg);
  show_scatter(b2,  s,   N, "b2",  "s",   argv[1], numseg);
  show_scatter(hs,  h01, N, "hs",  "h01", argv[1], numseg);
  show_scatter(hs,  h02, N, "hs",  "h02", argv[1], numseg);
  show_scatter(hs,  s,   N, "hs",  "s",   argv[1], numseg);
  show_scatter(h01, h02, N, "h01", "h02", argv[1], numseg);
  show_scatter(h01, s,   N, "h01", "s",   argv[1]);
  show_scatter(h02, s,   N, "h02", "s",   argv[1], numseg);

}





