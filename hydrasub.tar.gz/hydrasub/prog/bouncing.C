#include "bouncing.H"

char *colors[]={"white", "red", "blue", "cyan", "yellow", "green"};
int numcolors=6;
int numballs=300;
int size=800, ballsize=9;
double g=0,walldissipation=1.0, balldissipation=1.0;

void bouncing_exit::pushed(void)
{
  exit(0);
}


bouncing_draw::bouncing_draw() : draw()
{
  x=new double[numballs];
  y=new double[numballs];
  dx=new double[numballs];
  dy=new double[numballs];

  // initialize positions and velocities;
  for(int i=0; i<numballs;i++)
    {
      x[i] = (size-50.0)*drand48()/2.0+25.0;
      y[i] = (size-50.0)*drand48()+25.0;
      dx[i] = 3.0*drand48() - 1.5;
      dy[i] = 3.0*drand48() - 1.5;
    }
}

void bouncing_draw::expose(void)
{  
  Set(2);

  int i,j;

  // check for collisions;
  for(i=0; i<numballs; i++)
    for(j=0; j<i; j++)
      {
	double x1=x[i]+dx[i], y1=y[i]+dy[i];
	double x2=x[j]+dx[j], y2=y[j]+dy[j];
	double ex,ey,er,e0,k0,prevenergy;

	// collision detection;
	if((((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) < 8.0*8.0)) 
	  // collision  
	  // ((dx[i]-dx[j])*(dx[i]-dx[j]) + (dy[i]-dy[j])*(dy[i]-dy[j]))>0.0)
	  /* moving towards? */ 
	  {
	    // make a unit vector between the balls;
	    ex=x1-x2;
	    ey=y1-y2;
	    er=sqrt(ex*ex+ey*ey);
	    ex=ex/er;
	    ey=ey/er;
	    e0=balldissipation;
	    prevenergy = dx[i]*dx[i] + dy[i]*dy[i] + dx[j]*dx[j] + dy[j]+dy[j];

	    // collision strength;
	    k0 = e0*((dx[i]-dx[j]) * ex + (dy[i]-dy[j]) * ey);

	    if(k0<0.0)
	      {
		//cout << "k0 f�r:" << k0;
		//k0 = 0.5*k0 - 0.5*sqrt(k0*k0+4.0*(1.0-e0*e0)*prevenergy);
		//cout << "   og k0 etter:" << k0 << endl;

		// new velocity after collision;
		dx[i] = dx[i] - k0 * ex;
		dy[i] = dy[i] - k0 * ey;
		
		dx[j] = dx[j] + k0 * ex;
		dy[j] = dy[j] + k0 * ey;
	      }
	  }
      }

  for(i=0; i<numballs; i++)
    {
      dy[i] += g*0.015/9.8;
      
      // remove the previous ball drawing;
      SetFg("black");
      drawball((int) x[i], (int) y[i]);
      
      // edge handling;

      if((x[i]+dx[i])>=(size-ballsize) || (x[i]+dx[i])<0.0)
	{
	  if((x[i]+dx[i])>=(size-ballsize))
	    x[i] = 2.0 * (size-ballsize) - x[i];
	  else
	    x[i]=-x[i];
	  dx[i]=-dx[i]*walldissipation;
	  dy[i]=dy[i]*walldissipation;
	}
      
      if((y[i]+dy[i])>=(size-ballsize) || (y[i]+dy[i])<0.0)
	{
	  if((y[i]+dy[i])>=(size-ballsize))
	    y[i] = 2.0 * (size-ballsize) - y[i];
	  else
	    y[i]=-y[i];
	  dy[i]=-dy[i]*walldissipation;
	  dx[i]=dx[i]*walldissipation;
	}

      // calculate new positions;

      x[i]+=dx[i];
      y[i]+=dy[i];
  
      SetFg(colors[i%numcolors]);

      // draw a new ball;
      drawball((int) x[i], (int) y[i]);
    }
}

void bouncing_draw::drawball(int xx, int yy)
{
  char *ball[]={"  xxxxx  ",
		" xxxxxxx ",
		"xxxxxxxxx",
		"xxxxxxxxx",
		"xxxxxxxxx",
		"xxxxxxxxx",
		"xxxxxxxxx",
		" xxxxxxx ",
		"  xxxxx  "};

  int i,j,leny=sizeof(ball) / sizeof(char *);

  for(i=0;i<leny;i++)
    for(j=0; j<strlen(ball[i]);j++)
      if(ball[i][j]=='x')
	Point(xx+j, yy+i);
}

void bouncing_draw::wakeup(void)
{
  expose();
}

bouncing::bouncing(int argc, char **argv) : mainwin("Pong5 1.0", argc, argv)
{
  v1.build(*this);
  dr.build(v1, size, size);
  exitb.build(v1, "Avslutt");
  exitb.Background("red");
  exitb.Foreground("white");
}

int main(int argc, char **argv)
{
  if(argc>=2 && (argv[1][0]=='-' || argv[1][0]=='h' || argv[1][0]=='?'))
    {
      cout << "Usage: bouncing [<number of balls> [<wall dissipation> "
	"[<ball dissipation> [<window size> [<g>]]]]]" << endl;
      cout << "Number of balls: Default 300" << endl;
      cout << "Wall dissipation: The relative energy after bouncing" << endl;
      cout << "  on a wall. Default 1 (no dissipation)" << endl;
      cout << "Ball dissipation: The relative energy after bouncing" << endl;
      cout << "  on a another ball. Default 1 (no dissipation)" << endl;
      cout << "Window size: Default 800 pixels in width and height." << endl;
      cout << "g: Gravity. Default 0 (none)." << endl;      return 0;
    }

  if(argc>=2)
    sscanf(argv[1], "%d", &numballs);

  if(argc>=3)
    sscanf(argv[2], "%lf", &walldissipation);

  if(argc>=4)
    sscanf(argv[3], "%lf", &balldissipation);

   if(argc>=5)
    sscanf(argv[4], "%d", &size);

   if(argc>=6)
    sscanf(argv[5], "%lf", &g);

  bouncing png(argc, argv);

  time_t tm;

  time(&tm);
  long int t=(long int) tm;

  srand48(t);

  png.Run();

  return 0;
}


