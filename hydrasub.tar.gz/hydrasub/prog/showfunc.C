#include "showfunc.H"
#include <stdio.h>
#include <cmath>

void showfuncplot::plot_ended(void)
{
  exit(0);
}

void usage(void)
{
  cout << "usage: showfunc [-a] [-s] [-p <period length>] "
    "<start> <end> <step> <function> "
    "[<function> [<function> ...]]" << endl;
  cout << " -b toggles big ticks." << endl;
  cout << " -a toggles on showing a grid." << endl;
  cout << " -s toggles on showing each function along a "
    "separate axisis" << endl;
  cout << " -p toggles polar plotting with the given period length" << endl;
  cout << " <start>, <end>, and <step> defines the argument "
    "of the graph" << endl;
  cout << " <function> should be of the form \"1.3*sin(x)-0.2\", that" << endl;
  cout << "            is, a c-style function description using <x> " << endl;
  cout << "            as the argument." << endl; 
  cout << "            Remember always to place semi-colon (\") around "
    "each function. For instance;" << endl << endl;
  cout << "   showfunc -5 5 0.1 \"sin(x)\" \"sin(x)*sin(x)\"" << endl;
  exit(0);
}

int main(int argc, char **argv)
{
  Boolean gridon=False, sepax=False;
  mainwin mn("showfunc 1.0", argc, argv);
  showfuncplot showplot;
  vrow v1;
  double start, end, step;
  double period=MISSING_VALUE;
  int bigticks=0;

  argv++;
  argc--;

  while(argc>=1 && argv[0][0]=='-')
    {
      if(strlen(argv[0])<2)
	usage();

      if(isdigit(argv[0][1]))
	break;

      switch(argv[0][1])
	{
	case 'b':
	  bigticks=1;
	  break;
	case 's':
	  sepax=True;
	  break;
	case 'a':
	  gridon=True;
	  break;
	case 'p':
	  argv++;
	  argc--;
	  if(argc<1)
	    usage();
	  if(!sscanf(argv[0], "%lf", &period))
	    usage();
	  break;
	default:
	  usage();
	  break;
	}

      argv++;
      argc--;
    }

  if(argc<4)
    usage();

  if(!sscanf(argv[0], "%lf", &start))
    {
      cout << "Error reading start" << endl;
      usage();
    }

  argv++;
  argc--;

  if(!sscanf(argv[0], "%lf", &end))
    {
      cout << "Error reading end" << endl;
      usage();
    }

  argv++;
  argc--;

  if(!sscanf(argv[0], "%lf", &step))
    {
      cout << "Error reading step" << endl;
      usage();
    }

  argv++;
  argc--;

  int i, numseries=argc;
  char **linetitles=argv;
  int numax = sepax ? numseries+1 : 2;
  char **axistitles = new char*[numax];
  int *len=new int[numseries],*axis=new int[numseries];
  double **val=new double*[numseries];
  double **arg=new double*[numseries];

  axistitles[0]=new char[100];
  strcpy(axistitles[0], "x");
  if(!sepax)
    {
      axistitles[1]=new char[100];
      strcpy(axistitles[1], "f(x)");
    }
    
  for(i=0;i<numseries;i++)
    {
      if(sepax)
	{
	  axistitles[i+1]=new char[100];
	  sprintf(axistitles[i+1], "f%d(x)", i+1);
	  axis[i]=i+1;
	}
      else
	axis[i]=1;

      fetchfunc(start, end, step, argv[i], arg+i, val+i, len+i);
      if(strlen(linetitles[i])>30)
	linetitles[30]='\0';
    }

  if(gridon)
    showplot.set_grid(gridon);

  if(bigticks)
    showplot.set_big();

  v1.build(mn);
  if(period!=MISSING_VALUE)
    showplot.set_radial(period);
  showplot.put_in_widget(v1, v1.screenwidth()*9/10, v1.screenheight()*9/10, 
			 PLOT_IN_WIDGET_SHOWMAINMENU);

  showplot.Create(arg, val, len, axis, linetitles, numseries, 
		  axistitles, numax);
  mn.Run();
}

void fetchfunc(double start, double end, double step, 
	       char *func, double **arg, double **val, int *len)
{
  double lenbuff=(end-start)/step+1.0;
  int i=0,length=(int) lenbuff + 1;
  ofstream tempc;
  DateTime now;
  char cmd[1000], cfile[100], exefile[100], *ptr, *buff=new char[1000];
  FILE *p;
  
  now.now();
  ptr=now.syCh(2);
  sprintf(cfile, "/tmp/showfunc_cfile%s.c", ptr);
  sprintf(exefile, "/tmp/showfunc_exefile%s", ptr);
  delete [] ptr;

  *val=new double[length];
  *arg=new double[length];

  tempc.open(cfile, ios::out);
  if(tempc.fail())
    {
      cerr << "Couldn't open the temp file " << cfile << "!" << endl;
      exit(1);
    }

  tempc << "#include <cmath>" << endl;
#ifdef GSL
  tempc << "#include <gsl/gsl_randist.h>" << endl;
  tempc << "#include <gsl/gsl_cdf.h>" << endl;
  tempc << "#include <gsl/gsl_sf.h>" << endl;
#endif
  tempc << "#include <stdio.h>" << endl;
  tempc << endl;
  tempc << "int main(int argc, char **argv)" << endl;
  tempc << "  {" << endl;
  tempc << "    double start,end,step,x,f;" << endl;
  tempc << endl;
  tempc << "    if(argc!=4)" << endl;
  tempc << "      exit(1);" << endl;
  tempc << endl;
  tempc << "    if(!sscanf(argv[1],\"%lf\", &start))" << endl;
  tempc << "      exit(2);" << endl;
  tempc << endl;
  tempc << "    if(!sscanf(argv[2],\"%lf\", &end))" << endl;
  tempc << "      exit(3);" << endl;
  tempc << endl;
  tempc << "    if(!sscanf(argv[3],\"%lf\", &step))" << endl;
  tempc << "      exit(4);" << endl;
  tempc << endl;
  tempc << "    for(x=start;x<=end;x+=step)" << endl;
  tempc << "      {" << endl;
  tempc << "        f=" << func << ";" << endl;
  tempc << "        printf(\"%g : %g\\n\", x, f);" << endl;
  tempc << "      }" << endl;
  tempc << endl;
  tempc << "    return 0;" << endl;
  tempc << "  }" << endl;
  tempc.close();

#ifdef GSL
  sprintf(cmd, "g++ -I/site/avdc/include -L/site/avdc/lib -o %s %s -lgsl -lgslcblas -lm 2> /dev/null", exefile, cfile);
#else
  sprintf(cmd, "g++ -o %s %s -lm 2> /dev/null", exefile, cfile);
#endif

  //cout << cmd << endl;
  //exit(0);

  if(system(cmd))
    {
      sprintf(cmd, "rm -f %s", cfile);
      system(cmd);
       
      cerr << "Error in function definition; " << func << endl;
      exit(2);
    }

   sprintf(cmd,"%s %lf %lf %lf", exefile, start, end, step);
   p = popen(cmd, "r");
   if(!p)
     {
       cerr << "Error executing \"" << cmd << "\" !" << endl;
       sprintf(cmd, "rm -f %s %s", exefile, cfile);
       system(cmd);
       exit(3);
     }
   
   int fno=fileno(p);
   unsigned int len2;
   
   while(p && !feof(p) && i<length)
     {
       double argbuff, valbuff;
       
       if(fscanf(p,"%lf : %lf", &argbuff, &valbuff)==2)
	 {
	   (*arg)[i]=argbuff;
	   (*val)[i]=valbuff;
	   i++;
	 }
     }

   *len=i;

   pclose(p);

   sprintf(cmd, "rm -f %s %s", exefile, cfile);
   system(cmd);
}
      
