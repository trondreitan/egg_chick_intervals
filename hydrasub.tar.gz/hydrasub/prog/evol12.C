
#include <signal.h>
#include "evol12.H"
#include <fstream>

// **************************************
//
//       GLOBAL VARIABLES
//
// **************************************

int numanimals=150; // number of animals at the start
double size=500.0 /* draw size */, zoomfactor=1.0, 
  critsize=1.0; // inital creature size
int plantspace=5, // space between plants
  plantgrowth=50, // 1.0/probability of growing a new plant
  plantstat=500;  // time for taking a new statistics

Boolean noevol=False;

double best_energy=2.5;
double best_growing=1.0;
double metabol_pow=1.0;

double prob[]={0.87, 0.91, 0.97};
// cumulative inital probability of walking, 
// turning left, turning right and eating (100%)

Boolean doload=False, // load from file?
  docompute=True,    // should the simulation continue?
  background_mode=False, // background mode
  do_file_output=False;
long int runlen=0; // the simulation run length
Boolean keepdead=True;

evol12_draw *drawpt=NULL; // the main drawing area
FILE *numfile=NULL;
FILE *p_feel_file=NULL, *p_feel_hist_file=NULL;
FILE *growing_file=NULL, *growing_hist_file=NULL;
FILE *grown_file=NULL, *grown_hist_file=NULL;
FILE *p_eat_grown_file=NULL, *p_eat_grown_hist_file=NULL;
FILE *p_eat_growing_file=NULL, *p_eat_growing_hist_file=NULL;
FILE *velocity_file=NULL, *velocity_hist_file=NULL;
FILE *mutation_file=NULL, *mutation_hist_file=NULL;

// **************************************
//
//           ROUTINES / FUNCTIONS
//
// **************************************

#define sgn(x) ( x < 0 ? -1 : +1)

//           GET_RAND
// Fetch a random number lying between 'high' and 'low' and
// centered about 'oldval'. 'severity' denotes how severe a change should be.
double get_rand(double low, double high, double oldval, double severity)
{
  double newval;

  if(drand48()<0.5)
    newval=oldval-drand48()*(oldval-low)*severity;
  else
    newval=oldval+drand48()*(high-oldval)*severity;

  return newval;
}

// **************************************
//
//               EVOL12_CREATURE
//
// Generic creature (animal or plant).
//
// ***************************************

evol12_creature::evol12_creature(evol12_creature *prev,
                                 evol12_creature *next) :
  double_linked_list((double_linked_list *) prev, (double_linked_list *) next)
{
  x=y=dx=dy=olddx=olddy=0.0;
  creaturesize=critsize;

  generation = 1;
  children=0;
  age=0;
  birthtime=runlen;
  mutating_rate=0.2;

  parent=NULL;
}

void evol12_creature::do_step(evol12_draw *, int)
{
  check_coord();
}

void evol12_creature::check_coord(void)
{
  x = x+dx;
  y = y+dy;

  if(x > size/2.0)
    x -= size;
  else if(x < -size/2.0)
    x += size;

  if(y > size/2.0)
    y -= size;
  else if(y < -size/2.0)
    y += size;
}

evol12_creature *evol12_creature::suc_(void)
{
  return (evol12_creature *) getnext();
}

evol12_creature *evol12_creature::pred_(void)
{
  return (evol12_creature *) getprev();
}

void evol12_creature::set(double start_x, double start_y,
                          double start_dx, double start_dy)
{
  x  = start_x;
  y  = start_y;
  dx = start_dx;
  dy = start_dy;
}

double evol12_creature::get_size(void)
{
  return creaturesize;
}

int evol12_creature::get_red(void)
{
  return red;
}

int evol12_creature::get_green(void)
{
  return green;
}

int evol12_creature::get_blue(void)
{
  return blue;
}

double evol12_creature::get_rel_x(evol12_creature *item)
{
  double x1 = x - item->x;

  if(x1 >= size/2.0)
    x1 -= size;
  else if(x1 < -size/2.0)
    x1 += size;

  return x1;
}

double evol12_creature::get_rel_y(evol12_creature *item)
{
  double y1 = y - item->y;

  if(y1 >= size/2.0)
    y1 -= size;
  else if(y1 < -size/2.0)
    y1 += size;

  return y1;
}

double evol12_creature::get_next_rel_x(evol12_creature *item)
{
  double x1 = x +dx - item->x - item->dx;

  if(x1 >= size/2.0)
    x1 -= size;
  else if(x1 < -size/2.0)
    x1 += size;

  return x1;
}

double evol12_creature::get_next_rel_y(evol12_creature *item)
{
  double y1 = y + dy - item->y - item->dy;

  if(y1 >= size/2.0)
    y1 -= size;
  else if(y1 < -size/2.0)
    y1 += size;

  return y1;
}

int evol12_creature::get_children(void)
{
  return children;
}

long int evol12_creature::get_birthtime(void)
{
  return birthtime;
}

int evol12_creature::get_age(void)
{
  return age;
}

double evol12_creature::get_mutating_rate(void)
{
  return mutating_rate;
}

double evol12_creature::get_x(void)
{
  return x;
}

double evol12_creature::get_y(void)
{
  return y;
}

double evol12_creature::get_dx(void)
{
  return dx;
}

double evol12_creature::get_dy(void)
{
  return dy;
}

char *evol12_creature::get_color(void)
{
  char *color=new char[100];

  sprintf(color, "#%02x%02x%02x", red ,green, blue);

  return color;
}

int evol12_creature::get_generation(void)
{
  return generation;
}

Boolean evol12_creature::is_collision(evol12_creature *item, Boolean donext)
{
  double x1 = 0.0, y1 = 0.0;
  double x2, y2;

  if(donext)
    {
      x2 = item->get_next_rel_x(this);
      y2 = item->get_next_rel_y(this);
    }
  else
    {
      x2 = item->get_rel_x(this);
      y2 = item->get_rel_y(this);
    }

  // collision detection;
  if(((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) <
      ((creaturesize+item->creaturesize)*
       (creaturesize+item->creaturesize)/4.0))
    return True;

  return False;
}

Boolean evol12_creature::is_predator(void)
{
  return False;
}

void evol12_creature::mutate(double rate)
{
}

// ***************************************
//
//             EVOL!=_ANIMAL
//
// A class representing an "animal"
//
// ***************************************

evol12_animal::evol12_animal(evol12_animal *prev, evol12_animal *next,
                             double start_x, double start_y,
                             double start_dx, double start_dy) :
  evol12_creature(prev, next)
{
  x = start_x;
  y = start_y;
  dx=olddx=start_dx;
  dy=olddy=start_dy;

  do
    {
      red=(int) (drand48() * 256.0);
      green=(int) (drand48() * 256.0);
      blue==(int) (drand48() * 256.0);
    } while(red<200 && blue<200);

  dofeel=0.2;
  doremember=0.5;

  mouth = 0;
  predstate = PREDATOR_WALK;
  eaten = 50.0*creaturesize*creaturesize;

  eatinggrowing=0.25;
  eatinggrown=0.25+0.25;
  doeatgrowing=0.5;
  doeatgrown=0.5;

  /*
  if(drand48()<0.5)
    {
      eatinggrowing=0.9999;
      eatinggrown=0.99995;
      doeatgrowing=1.0;
      doeatgrown=0.0;
    }
  else
    {
      eatinggrowing=0.00005;
      eatinggrown=0.99995;
      doeatgrowing=0.0;
      doeatgrown=1.0;
    }
  */

  probability[0]=prob[0];
  probability[1]=prob[1];
  probability[2]=prob[2];
  reproducelimit=200*creaturesize*creaturesize;
  velocity=0.125;
  ch_angle = 30.0;

  if(dx!=0.0 || dy!=0.0)
    {
      olddx=2.0*velocity*drand48()-velocity;
      olddy=2.0*velocity*drand48()-velocity;

      dx = olddx * velocity/sqrt(olddx*olddx+olddy*olddy);
      dy = olddy * velocity/sqrt(olddx*olddx+olddy*olddy);
      
      olddx=dx;
      olddy=dy;
    }
}

evol12_animal::evol12_animal(evol12_animal *prev, evol12_animal *next,
                             evol12_animal *parent_, Boolean domutate) :
  evol12_creature(prev, next)
{
  if(domutate)
    {
      x = parent_->x + 1.0;
      y = parent_->y + 1.0;

      if(x > size/2.0)
        x -= size;
      else if(x < -size/2.0)
        x += size;

      if(y > size/2.0)
        y -= size;
      else if(y < -size/2.0)
        y += size;

      dx = - parent_->dx;
      dy = - parent_->dy;
    }
  else
    {
      x=parent_->x;
      y=parent_->y;
      dx=parent_->dx;
      dy=parent_->dy;
    }

  red = parent_->red;
  green = parent_->green;
  blue = parent_->blue;
  mouth = 0;
  predstate = PREDATOR_EAT;
  creaturesize=parent_->creaturesize;

  eatinggrowing=parent_->eatinggrowing;
  eatinggrown=parent_->eatinggrown;
  doeatgrowing=parent_->doeatgrowing;
  doeatgrown=parent_->doeatgrown;

  probability[0]=parent_->probability[0];
  probability[1]=parent_->probability[1];
  probability[2]=parent_->probability[2];
  reproducelimit=parent_->reproducelimit;
  velocity=parent_->velocity;
  ch_angle=parent_->ch_angle;
  mutating_rate=parent_->mutating_rate;

  dofeel=parent_->dofeel;
  doremember=parent_->doremember;

  if(domutate)
    {
      eaten = (parent_->eaten-70.0*creaturesize*creaturesize)/2.0;
      children=0;
      age=0;
      generation = parent_->generation +1;
      parent_->eaten = eaten;
      parent_->children++;
      parent=parent_;
      birthtime=runlen;
    }
  else
    {
      age=parent_->age;
      eaten=parent_->eaten;
      children = parent_->children;
      generation = parent_->generation;
      parent = parent_->parent;
      birthtime=parent_->birthtime;
    }

  if(domutate && !noevol)
    {
      for(int i=0;i<=mutating_rate*10; i++)
        mutate(0.1);
      while(drand48() < mutating_rate)
        mutate(0.2);
      while(10.0*drand48() < mutating_rate)
        mutate(0.3);
      while(100.0*drand48() < mutating_rate)
        mutate(0.4);
      while(1000.0*drand48() < mutating_rate)
        mutate(0.5);
    }

  olddx=dx;
  olddy=dy;
}

evol12_animal *evol12_animal::suc(void)
{
  return (evol12_animal *) suc_();
}

evol12_animal *evol12_animal::pred(void)
{
  return (evol12_animal *) pred_();
}

void evol12_animal::mutate(double rate)
{
  double severity=pow(drand48(), sqrt(1.0/mutating_rate));
  int type = (int) (17.0*drand48());
  
  switch(type)
    {
    case 0: // change 'walk' and 'turn left' probability;
      probability[0]=get_rand(0.0, probability[1], probability[0],
                              rate*severity);
      break;
    case 1: // change 'turn left' and 'turn right' probability;
      probability[1]=get_rand(probability[0], probability[2],
                              probability[1], rate*severity);
      break;
    case 2: // change 'turn right' and 'eat' probability;
      probability[2]=get_rand(probability[1], 1.0, probability[2],
                              rate*severity);
      break;
    case 3: // change starting velocity;
      velocity=get_rand(0.5*velocity, 2.0*velocity, velocity, rate*severity);
      break;
    case 4: // change turning angle
      ch_angle=get_rand(0.0, 180.0, ch_angle, rate*severity);
      break;
    case 5: // change the reproducing limit
      reproducelimit=get_rand(0.5*reproducelimit, 2.0*reproducelimit,
                              reproducelimit, rate*severity);
      break;
    case 6: // change the mutating rate
      mutating_rate=get_rand(0.0, 1.0, mutating_rate, rate*severity);
      break;
    case 7:
      {
        double sizechange = get_rand(0.5, 2.0, 1.0, rate*severity);
        creaturesize *= sizechange;
        reproducelimit *= sizechange;
        velocity *= sizechange;
        break;
      }
    case 8:
      doremember = get_rand(0.0, 1.0, doremember, rate*severity);
      break;
    case 9:
      dofeel = get_rand(0.0, 1.0, dofeel, rate*severity);
      break;
    case 10:
      eatinggrowing = get_rand(0.0, eatinggrown ,
                               eatinggrowing, rate*severity);
      eatinggrown = get_rand(eatinggrowing, 1.0, eatinggrown, rate*severity);
      break;
    case 11:
      eatinggrown = get_rand(eatinggrowing, 1.0, eatinggrown, rate*severity);
      eatinggrowing = get_rand(0.0, eatinggrown ,
                               eatinggrowing, rate*severity);
      break;
    case 12:
      red = (int) get_rand( blue>150 ? 0.0 : 150.0,
                            255.0, (double) red, rate*severity);
      break;
    case 13:
      green = (int) get_rand( 0.0, 255.0, (double) green, rate*severity);
      break;
    case 14:
      blue = (int) get_rand( red>150 ? 0.0 : 150.0,
                            255.0, (double) blue, rate*severity);
      break;
    case 15:
      doeatgrowing = get_rand(0.0, 1.0, doeatgrowing, rate*severity);
      break;
    case 16:
      doeatgrown = get_rand(0.0, 1.0, doeatgrown, rate*severity);
      break;
    }
}

PREDATOR_STATE evol12_animal::get_predator_state(void)
{
  return predstate;
}

double evol12_animal::do_remember(void)
{
  return doremember;
}

double evol12_animal::do_eatinggrowing(void)
{
  return eatinggrowing;
}

double evol12_animal::do_eatinggrown(void)
{
  return eatinggrown;
}

double evol12_animal::do_doeatgrowing(void)
{
  return doeatgrowing;
}

double evol12_animal::do_doeatgrown(void)
{
  return doeatgrown;
}

double evol12_animal::do_feel(void)
{
  return dofeel;
}

double evol12_animal::get_eaten(void)
{
  return eaten;
}

double evol12_animal::get_prob(int i)
{
  return probability[i];
}

double evol12_animal::get_ch_angle(void)
{
  return ch_angle;
}

double evol12_animal::get_reproducelimit(void)
{
  return reproducelimit;
}

double evol12_animal::get_velocity(void)
{
  return velocity;
}

int evol12_animal::get_mouth(void)
{
  return mouth;
}

void evol12_animal::do_collision(double impactx, double impacty)
{
  dx += impactx;
  dy += impacty;
}

void evol12_animal::do_step(evol12_draw *pt, int doshow)
{
  int k=0;
  double rr=drand48();
  PLANT_STATE pl=pt->have_plant(this);

  if(doshow)
    {
      age++;
      pt->drawball(this, 0);
    }

  if(pl!=prevplantstate)
    {
      if(drand48()<=dofeel)
	{
	  if((pl==PLANT_OK && doeatgrown>=drand48()) ||
	     (pl==PLANT_GROWING && doeatgrowing>=drand48()))
	    rr=1.0;
	  else
	    rr *= probability[2];
	}
    }
  prevplantstate=pl;

  if(rr<probability[2] && (dx*dx+dy*dy < 0.00001))
    {
      double vv;

      if(drand48()<=doremember)
        {
          dx=olddx;
          dy=olddy;
        }

      if(dx==0.0 && dy==0.0)
        {
          dx=drand48()-0.5;
          dy=drand48()-0.5;
        }

      vv=sqrt(dx*dx+dy*dy);

      dx=dx*velocity/vv;
      dy=dy*velocity/vv;

      eaten -= creaturesize*creaturesize*2.0*(dx*dx+dy*dy);
      predstate=PREDATOR_WALK;
    }

  if(doremember>0.0 && rr>=probability[2] && predstate!=PREDATOR_EAT &&
     (dx*dx+dy*dy < 0.00001))
    {
      olddx=dx;
      olddy=dy;
    }

  if(rr<probability[0])
    {
      predstate=PREDATOR_WALK;
    }
  else if(rr<probability[1])
    {
      double dx1, dy1;
      double angle = 2.0 * 3.1415926 * ch_angle / 360.0;

      dx1=dx*cos(angle) + dy*sin(angle);
      dy1=-dx*sin(angle) + dy*cos(angle);

      dx=dx1;
      dy=dy1;
      
      predstate=PREDATOR_LEFT;
    }
  else if(rr<probability[2])
    {
      double dx1, dy1;
      double angle = - 2.0 * 3.1415926 * ch_angle / 360.0;

      dx1=dx*cos(angle) + dy*sin(angle);
      dy1=-dx*sin(angle) + dy*cos(angle);

      dx=dx1;
      dy=dy1;

      predstate=PREDATOR_RIGHT;
    }
  else // eat
    {
      PLANT_STATE ps=pt->do_eat(this);
      double portion = MINIM(creaturesize*creaturesize, critsize*critsize);
      double xx=eatinggrown - eatinggrowing, Dok=xx;
      double yy=eatinggrowing, Dg=yy;
      double b=metabol_pow;
      double a=(1.0-1.0/8.0)/(1.0-pow(0.5,b));
      double c=1.0-a;
      double d=pow(0.1,b);

      /*
      if(ps==PLANT_OK)
        eaten += 1.51 * (xx*(xx+1)/1.5 - 0.35)*
          plantspace*plantspace*portion;
      else if(ps==PLANT_GROWING)
        eaten += 1.6 * (yy*(yy+1)/1.5 - 0.35)*
          plantspace*plantspace*portion;
      */

      /*
      if(ps==PLANT_OK)
	{
	  eaten += best_energy*eatinggrown*
	    (a*pow(1.0-yy,b)+c)*
	    plantspace*plantspace*portion;
	}
      else if(ps==PLANT_GROWING)
	{
	  eaten += best_energy*best_growing*eatinggrown*
	    (a*pow(yy,b)+c)*
	    plantspace*plantspace*portion;
	}
      */

      if(ps==PLANT_OK)
	{
	  eaten += best_energy*(pow(Dok,b)-d)/
	    (1.0-d)*plantspace*plantspace*portion;
	}
      else if(ps==PLANT_GROWING)
	{
	  eaten += best_energy*best_growing*(pow(Dg,b)-d)/
	    (1.0-d)*plantspace*plantspace*portion;
	}

      dx = 0.0;
      dy = 0.0;
      predstate=PREDATOR_EAT;
    }
  
  eaten -= 0.3*creaturesize*creaturesize*(dx*dx + dy*dy + 0.01);
  
  if(eaten > creaturesize*creaturesize*450)
    eaten = creaturesize*creaturesize*450;
  
  mouth++;
  mouth=mouth%4;
  
  check_coord();
  
  if(doshow)
    pt->drawball(this, 1);
}

void evol12_animal::collision_detect(evol12_animal *head)
{
  evol12_animal *ptr;

  for(ptr=head; ptr && ptr!=this; ptr=ptr->suc())
    {
      double x1 = 0.0, y1 = 0.0;
      double x2 = ptr->get_next_rel_x(this), y2 = ptr->get_next_rel_y(this);
      double ex,ey,er,k0;

      // collision detection;
      if(is_collision(ptr, True))
        // collision
        /* moving towards? */
        {
          // make a unit vector between the animals;
          ex=x1-x2;
          ey=y1-y2;
          er=sqrt(ex*ex+ey*ey);
          ex=ex/er;
          ey=ey/er;

          // collision strength;
          k0 = -((ptr->dx - dx) * ex + (ptr->dy - dy) * ey);

          if(k0<0.0)
            {
              // new velocity after collision;
              do_collision(-k0*ex, -k0*ey);
              ptr->do_collision(k0*ex, k0*ey);
            }
        }
    }
}

Boolean evol12_animal::is_predator(void)
{
  return True;
}

// ************************************************
//         EVOL!0_PLANT
//
// A class represnenting a "plant"
//
// ************************************************

evol12_plant::evol12_plant(evol12_plant *prev, evol12_plant *next,
                           double start_x, double start_y) :
  evol12_creature(prev, next)
{
  x=start_x;
  y=start_y;

  red=0;
  green=255;
  blue=0;

  plantstate=PLANT_OK;
}

PLANT_STATE evol12_plant::get_plant_state(void)
{
  return plantstate;;
}

void evol12_plant::set_plant_state(PLANT_STATE state)
{
  plantstate=state;
  if(state==PLANT_EATEN || state==PLANT_GROWING)
    age=0;

  if(state==PLANT_GROWING)
    green = 128;
  else
    green = 255;
}

Boolean evol12_plant::is_predator(void)
{
  return False;
}

evol12_plant *evol12_plant::suc(void)
{
  return (evol12_plant *) suc_();
}

evol12_plant *evol12_plant::pred(void)
{
  return (evol12_plant *) pred_();
}

void evol12_plant::mutate(double rate)
{
}

void evol12_plant::do_step(evol12_draw *pt, int doshow)
{
  if(doshow && plantstate!=PLANT_EATEN)
    {
      age++;
      pt->drawball(this, 0);
    }


  if(plantstate==PLANT_EATEN || plantstate==PLANT_GROWING)
    {
      if(plantstate==PLANT_EATEN && drand48()<(1.0/plantgrowth)
         && pt->do_grow(this))
        {
          pt->grown++;
          set_plant_state(PLANT_GROWING);
        }
      else if(plantstate==PLANT_GROWING && drand48()<(1.0/plantgrowth))
        set_plant_state(PLANT_OK);
    }

  check_coord();

  if(doshow && plantstate!=PLANT_EATEN)
    pt->drawball(this, 1);
}

// *****************************************************
//
// Routines for sorting arrays of
// evol12_creature pointers;
//
// *****************************************************

int compar_walkprob(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->get_prob(0);
  double prob2=ptr2->get_prob(0);

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_leftprob(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->get_prob(1) - ptr1->get_prob(0);
  double prob2=ptr2->get_prob(1) - ptr2->get_prob(0);

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_rightprob(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->get_prob(2) - ptr1->get_prob(1);
  double prob2=ptr2->get_prob(2) - ptr2->get_prob(1);

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_eatprob(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=1.0 - ptr1->get_prob(2);
  double prob2=1.0 - ptr2->get_prob(2);

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_mutaterate(const void *item1, const void *item2)
{
  evol12_creature *ptr1 = *(evol12_creature **) item1;
  evol12_creature *ptr2 = *(evol12_creature **) item2;
  double prob1=ptr1->get_mutating_rate();
  double prob2=ptr2->get_mutating_rate();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_velocity(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->get_velocity();
  double prob2=ptr2->get_velocity();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_reproducelimit(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->get_reproducelimit();
  double prob2=ptr2->get_reproducelimit();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_changle(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->get_ch_angle();
  double prob2=ptr2->get_ch_angle();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_generation(const void *item1, const void *item2)
{
  evol12_creature *ptr1 = *(evol12_creature **) item1;
  evol12_creature *ptr2 = *(evol12_creature **) item2;
  int prob1=ptr1->get_generation();
  int prob2=ptr2->get_generation();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_children(const void *item1, const void *item2)
{
  evol12_creature *ptr1 = *(evol12_creature **) item1;
  evol12_creature *ptr2 = *(evol12_creature **) item2;
  int prob1=ptr1->get_children();
  int prob2=ptr2->get_children();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_age(const void *item1, const void *item2)
{
  evol12_creature *ptr1 = *(evol12_creature **) item1;
  evol12_creature *ptr2 = *(evol12_creature **) item2;
  int prob1=ptr1->get_age();
  int prob2=ptr2->get_age();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_eaten(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->get_eaten();
  double prob2=ptr2->get_eaten();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_size(const void *item1, const void *item2)
{
  evol12_creature *ptr1 = *(evol12_creature **) item1;
  evol12_creature *ptr2 = *(evol12_creature **) item2;
  double prob1=ptr1->get_size();
  double prob2=ptr2->get_size();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_feel(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->do_feel();
  double prob2=ptr2->do_feel();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_rem(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->do_remember();
  double prob2=ptr2->do_remember();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_eatinggrowing(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->do_eatinggrowing();
  double prob2=ptr2->do_eatinggrowing();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_eatinggrown(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->do_eatinggrown()-ptr1->do_eatinggrowing();
  double prob2=ptr2->do_eatinggrown()-ptr2->do_eatinggrowing();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_doeatgrowing(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->do_doeatgrowing();
  double prob2=ptr2->do_doeatgrowing();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_doeatgrown(const void *item1, const void *item2)
{
  evol12_animal *ptr1 = *(evol12_animal **) item1;
  evol12_animal *ptr2 = *(evol12_animal **) item2;
  double prob1=ptr1->do_doeatgrown();
  double prob2=ptr2->do_doeatgrown();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

int compar_birthtime(const void *item1, const void *item2)
{
  evol12_creature *ptr1 = *(evol12_creature **) item1;
  evol12_creature *ptr2 = *(evol12_creature **) item2;
  double prob1=ptr1->get_birthtime();
  double prob2=ptr2->get_birthtime();

  if(prob1<prob2)
    return -1;
  else if(prob2<prob1)
    return 1;
  else
    return 0;
}

void evol12_showall_button::Create(widget parent, char *txt,
                                  evol12_showall *ipt,
                                  EVOL12_SHOWALL_TYPE type)
{
  pt=ipt;
  typ=type;
  build(parent, txt);
}

void evol12_showall_button::pushed(void)
{
  if(typ==EVOL12_SHOWALL_EXIT)
    {
      pt->do_restart();
      pt->Unmap();
      delete pt;
    }
  else
    pt->buttonpushed(typ);
}

void evol12_showall::do_restart(void)
{
  pt->restart();
}

void evol12_showall::zoom(void)
{
  int sel=lst.Selected();

  if(sel==-1)
    {
      err.build(*this, "Feil", "Inget vesen valgt!");
      return;
    }

  pt->zoom(array[sel]);

  exitb.pushed();
}

void evol12_showall::details(void)
{
  int sel=lst.Selected();

  if(sel==-1)
    {
      err.build(*this, "Feil", "Inget vesen valgt!");
      return;
    }

  evol12_show *ptr=new evol12_show();
  ptr->Create(detailsb, array[sel]);
}

void evol12_showall::buttonpushed(EVOL12_SHOWALL_TYPE type)
{
  switch(type)
    {
    case EVOL12_SHOWALL_WALK:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_walkprob);
      break;
    case EVOL12_SHOWALL_LEFT:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_leftprob);
      break;
    case EVOL12_SHOWALL_RIGHT:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_rightprob);
      break;
    case EVOL12_SHOWALL_EAT:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_eatprob);
      break;
    case EVOL12_SHOWALL_MUTATERATE:
      qsort(array, size_t(len), sizeof(evol12_creature *), compar_mutaterate);
      break;
    case EVOL12_SHOWALL_VELOCITY:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_velocity);
      break;
    case EVOL12_SHOWALL_REPRODUCELIMIT:
      qsort(array, size_t(len), sizeof(evol12_animal *),
            compar_reproducelimit);
      break;
    case EVOL12_SHOWALL_CHANGLE:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_changle);
      break;
    case EVOL12_SHOWALL_GENERATION:
      qsort(array, size_t(len), sizeof(evol12_creature *), compar_generation);
      break;
    case EVOL12_SHOWALL_CHILDREN:
      qsort(array, size_t(len), sizeof(evol12_creature *), compar_children);
      break;
    case EVOL12_SHOWALL_AGE:
      qsort(array, size_t(len), sizeof(evol12_creature *), compar_age);
      break;
    case EVOL12_SHOWALL_EATEN:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_eaten);
      break;
    case EVOL12_SHOWALL_SIZE:
      qsort(array, size_t(len), sizeof(evol12_creature *), compar_size);
      break;
    case EVOL12_SHOWALL_FEEL:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_feel);
      break;
    case EVOL12_SHOWALL_REM:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_rem);
      break;
    case EVOL12_SHOWALL_EATINGGROWING:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_eatinggrowing);
      break;
    case EVOL12_SHOWALL_EATINGGROWN:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_eatinggrown);
      break;
    case EVOL12_SHOWALL_DOEATGROWING:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_doeatgrowing);
      break;
    case EVOL12_SHOWALL_DOEATGROWN:
      qsort(array, size_t(len), sizeof(evol12_animal *), compar_doeatgrown);
      break;
    case EVOL12_SHOWALL_BIRTHTIME:
      qsort(array, size_t(len), sizeof(evol12_creature *), compar_birthtime);
      break;
    case EVOL12_SHOWALL_ZOOM:
      zoom();
      return;
    case EVOL12_SHOWALL_DETAILS:
      details();
      return;
    }

  lst.Clear();
  for(int i=0; i<len;i++)
    {
      char str[300];
      sprintf(str,"%3d %5.2lf%% %5.2lf%% %5.2lf%% %5.2lf%%  "
              "mr=%5.2lf%% fart=%5.3lf gr=%7.1lf(%3.0lf%%) vi=%6.1lf "
              " %3d barn a=%-6d e=%-6.1lf siz=%-9.6lf "
              "%5.3lf %5.3lf %5.3lf %5.3lf %5.3lf %5.3lf %-9ld",
              array[i]->get_generation(),
              100.0*array[i]->get_prob(0),
              100.0*(array[i]->get_prob(1)-
                     array[i]->get_prob(0)),
              100.0*(array[i]->get_prob(2)-
                     array[i]->get_prob(1)),
              100.0*(1.0-array[i]->get_prob(2)),
              100.0*array[i]->get_mutating_rate(),
              array[i]->get_velocity(),
              array[i]->get_reproducelimit(),
              (100.0*array[i]->get_reproducelimit()/
               (450.0*array[i]->get_size()*array[i]->get_size())),
              array[i]->get_ch_angle(),
              array[i]->get_children(),
              array[i]->get_age(),
              array[i]->get_eaten(),
              array[i]->get_size(),
              array[i]->do_feel(),
              array[i]->do_remember(),
              array[i]->do_eatinggrowing(),
              array[i]->do_eatinggrown()-array[i]->do_eatinggrowing(),
              array[i]->do_doeatgrowing(),
              array[i]->do_doeatgrown(),
              array[i]->get_birthtime()
              );
      lst.Insert(str);
    }
}

evol12_showall::evol12_showall()
{
  array=NULL;
}

evol12_showall::~evol12_showall()
{
  if(array)
    delete [] array;
}

void evol12_showall::Create(evol12_animal *population, evol12_draw *ipt)
{
  evol12_animal *ptr=population;

  pt=ipt;

  len=population->number_of_elements();
  array=new evol12_animal*[len];

  build(mainwin::toplevel, "Populasjonsoversikt:");
  v1.build(*this);
  h1.build(v1);

  generationb.Create(h1, "Gen. #", this, EVOL12_SHOWALL_GENERATION);
  walkb.Create(h1, "G� %", this, EVOL12_SHOWALL_WALK);
  leftb.Create(h1, "Venstre %", this, EVOL12_SHOWALL_LEFT);
  rightb.Create(h1, "H�yre %", this, EVOL12_SHOWALL_RIGHT);
  eatb.Create(h1, "Spis %", this, EVOL12_SHOWALL_EAT);
  mutaterateb.Create(h1, "Mutasjons-rate", this, EVOL12_SHOWALL_MUTATERATE);
  velocityb.Create(h1, "Fart", this, EVOL12_SHOWALL_VELOCITY);
  reproducelimitb.Create(h1, "Repr. gr.", this, EVOL12_SHOWALL_REPRODUCELIMIT);
  changleb.Create(h1, "Vinkel-endring", this, EVOL12_SHOWALL_CHANGLE);
  childrenb.Create(h1, "# Barn", this,  EVOL12_SHOWALL_CHILDREN);
  ageb.Create(h1, "Alder", this,  EVOL12_SHOWALL_AGE);
  eatenb.Create(h1, "Energi", this, EVOL12_SHOWALL_EATEN);
  sizeb.Create(h1, "St�rrelse", this, EVOL12_SHOWALL_SIZE);
  feelb.Create(h1, "f�le", this, EVOL12_SHOWALL_FEEL);
  remb.Create(h1, "husk", this, EVOL12_SHOWALL_REM);
  eatinggrowingb.Create(h1, " . ", this, EVOL12_SHOWALL_EATINGGROWING);
  eatinggrownb.Create(h1, " O ", this, EVOL12_SHOWALL_EATINGGROWN);
  doeatgrowingb.Create(h1, " p. ", this, EVOL12_SHOWALL_DOEATGROWING);
  doeatgrownb.Create(h1, " pO ", this, EVOL12_SHOWALL_DOEATGROWN);
  birthtimeb.Create(h1, "F�dt", this, EVOL12_SHOWALL_BIRTHTIME);

  lst.build(v1, 30, 1);

  for(int i=0; i<len;i++)
    {
      array[i]=new evol12_animal(NULL, NULL, ptr, False);
      ptr=ptr->suc();
    }

  h2.build(v1);
  exitb.Create(h2, "Avslutt", this, EVOL12_SHOWALL_EXIT);
  exitb.Background("red");
  exitb.Foreground("white");

  zoomb.Create(h2, "Zoom inn p� vesen", this, EVOL12_SHOWALL_ZOOM);
  zoomb.Background("yellow");
  zoomb.Foreground("black");

  detailsb.Create(h2, "Detaljer", this, EVOL12_SHOWALL_DETAILS);
  detailsb.Background("yellow");
  detailsb.Foreground("black");

  Map();

  buttonpushed(EVOL12_SHOWALL_GENERATION);
}

void evol12_draw::write_text_file(char *outfile)
{
  FILE *f=fopen(outfile,"w");
  evol12_animal *ptr;

  for(ptr=animals; ptr ; ptr=ptr->suc())
    fprintf(f,"%ld %d 0\n", ptr->get_birthtime(),
	  ptr->get_age());
  for(ptr=deadbeings; ptr ; ptr=ptr->suc())
    fprintf(f,"%ld %d 1\n", ptr->get_birthtime(),
	  ptr->get_age());
  
  fclose(f);
}

void evol12_draw::to_stream(FILE *file)
{
  cout << "starting" << endl;

  char str[10];
  int i, numplants = ((int)size)/plantspace;
  evol12_animal *ptr;
  long int liveanimals = animals ? (long int) animals->number_of_elements() :
    (int) 0;
  long int deadanimals = deadbeings ?
    (int) deadbeings->number_of_elements() : (long int) 0;

  fwrite(&size,         sizeof(double), 1, file);
  fwrite(&liveanimals,  sizeof(long int), 1, file);
  fwrite(&critsize,     sizeof(double), 1, file);
  fwrite(&runlen,       sizeof(long int), 1, file);
  fwrite(&deadanimals,  sizeof(long int), 1, file);
  fwrite(&plantspace,   sizeof(int), 1, file);
  fwrite(&plantgrowth,  sizeof(int), 1, file);
  fwrite(&plantstat,    sizeof(int), 1, file);
  fwrite(&best_energy,  sizeof(double), 1, file);
  fwrite(&best_growing, sizeof(double), 1, file);
  fwrite(&metabol_pow,  sizeof(double), 1, file);
  
  cout << size << " " << liveanimals << " " << critsize << " " << runlen << " " <<
    deadanimals << " " << plantspace << " " << plantgrowth << " " << plantstat << 
    " " << best_energy << " " << best_growing << " " << metabol_pow << endl;

  cout << "Writing plants..." << endl;

  for(i=0; i<numplants; i++)
    for(int j=0; j<numplants; j++)
      {
        PLANT_STATE pl=plants[i][j]->get_plant_state();
        fwrite(&pl, sizeof(PLANT_STATE), 1, file);
      }

  cout << "Setting code for live animals" << endl;

  i=0;
  for(ptr=animals; ptr ; ptr=ptr->suc())
    {
      sprintf(str, "l%-8d", i);
      ptr->set_code(str);
      i++;
    }

  cout << "Setting code for dead animals" << endl;

  i=0;
  for(ptr=deadbeings; ptr ; ptr=ptr->suc())
    {
      sprintf(str, "d%-8d", i);
      ptr->set_code(str);
      i++;
    }

  cout << "Writing live animals..." << endl;

  for(ptr=animals; ptr; ptr=ptr->suc())
    {
      fwrite(ptr, sizeof(evol12_animal), 1, file);
      fwrite(ptr->get_parent() ? ptr->get_parent()->get_code() : "none", 
	     sizeof(char), 10, file);
    }

   cout << "Writing dead animals..." << endl;

  for(ptr=deadbeings; ptr; ptr=ptr->suc())
    {
      fwrite(ptr, sizeof(evol12_animal), 1, file);
      fwrite(ptr->get_parent() ? ptr->get_parent()->get_code() : "none", 
	     sizeof(char), 10, file);
    }
}

void evol12_draw::from_stream(FILE *file)
{
  char line[1000], code[11];
  int  i, j, numplants;
  long int numdead;
  evol12_animal *ptr, *btail=NULL, *bhead=NULL, *dtail=NULL, *dhead=NULL;
  double livebuff, runbuff, deadbuff;

  cleanup();

  fread(&size,         sizeof(double), 1, file);
  fread(&numanimals,   sizeof(long int), 1, file);
  fread(&critsize,     sizeof(double), 1, file);
  fread(&runlen,       sizeof(long int), 1, file);
  fread(&numdead,      sizeof(long int), 1, file);
  fread(&plantspace,   sizeof(int), 1, file);
  fread(&plantgrowth,  sizeof(int), 1, file);
  fread(&plantstat,    sizeof(int), 1, file);
  fread(&best_energy,  sizeof(double), 1, file);
  fread(&best_growing, sizeof(double), 1, file);
  fread(&metabol_pow,  sizeof(double), 1, file);

  cout << size << " " << numanimals << " " << critsize << " " << runlen << " " <<
    numdead << " " << plantspace << " " << plantgrowth << " " << plantstat << 
    " " << best_energy << " " << best_growing << " " << metabol_pow << endl;

  numplants = ((int)size)/plantspace;

  plants = new evol12_plant**[numplants];

  for(i=0; i<numplants;i++)
    {
      plants[i]=new evol12_plant*[numplants];

      for(j=0; j<numplants;j++)
        {
          PLANT_STATE pl;

          fread(&pl, sizeof(PLANT_STATE), 1, file);
          plants[i][j]=new evol12_plant(NULL, NULL,
                                        (double) i*plantspace+plantspace/2.0-
                                        size/2.0,
                                        (double) j*plantspace+plantspace/2.0-
                                        size/2.0);
          plants[i][j]->set_plant_state(pl);
        }
    }


  cout << "Reading live beings..." << endl;

  for(i=0; i<numanimals;i++)
    {
      evol12_animal *oldtail=btail;

      btail=new evol12_animal(btail, NULL, 0, 0, 0, 0);
      if(!bhead)
        bhead=btail;
      fread(btail, sizeof(evol12_animal), 1, file);
      fread(code, sizeof(char), 10, file);
      btail->set_code(code);
      btail->setprev(oldtail);
      btail->setnext(NULL);
    }

  animals=bhead;

  cout << "Reading dead beings..." << endl;

  for(i=0; i<numdead;i++)
    {
      evol12_animal *oldtail=dtail;

      if(i>0 && i%10000==0)
        cout << "Dead being number " << i << " (" <<
          ((double) i * 100.0)/((double) numdead) << "%) read." << endl;

      dtail=new evol12_animal(dtail, NULL, 0, 0, 0, 0);
      if(!dhead)
        dhead=dtail;
      fread(dtail, sizeof(evol12_animal), 1, file);
      fread(code, sizeof(char), 10, file);
      dtail->set_code(code);
      dtail->setprev(oldtail);
      dtail->setnext(NULL);
    }

  deadbeings=dhead;

  cout << "Making array of live beings" << endl;

  i=0;
  evol12_animal **orderalive=NULL;
  if(animals->number_of_elements()>0)
    orderalive=new evol12_animal*[animals->number_of_elements()];
  for(ptr=animals; ptr ; ptr=ptr->suc())
    orderalive[i++]=ptr;

  cout << "Making array of dead beings" << endl;

  i=0;
  evol12_animal **orderdead=NULL;
  if(deadbeings->number_of_elements()>0)
    orderdead=new evol12_animal*[deadbeings->number_of_elements()];
  for(ptr=deadbeings; ptr ; ptr=ptr->suc())
    orderdead[i++]=ptr;

  cout << "Finding parents of the live beings." << endl;
  for(ptr=animals; ptr ; ptr=ptr->suc())
    {
      if(strcmp(ptr->get_code(), "none"))
	{
	  char *code=ptr->get_code();
	  long int num;
	  
	  sscanf(code+1, "%ld", &num);
	  if(code[0]=='l')
	    ptr->set_parent(orderalive[num]);
	  else
	    ptr->set_parent(orderdead[num]);
	}
    }

  cout << "Finding parents of the dead beings." << endl;

  i=0;
  for(ptr=deadbeings; ptr ; ptr=ptr->suc())
    {
      if(strcmp(ptr->get_code(), "none"))
	{
	  char *code=ptr->get_code();
	  long int num;
	  
	  if(i>0 && i%10000==0)
	    cout << "Parent of dead being number " << i << " (" <<
	      ((double) i * 100.0)/((double) numdead) << "%) found." << endl;
	  i++;
	  
	  sscanf(code+1, "%ld", &num);
	  if(code[0]=='l')
	    ptr->set_parent((evol12_animal *) orderalive[num]);
	  else
	    ptr->set_parent((evol12_animal *) orderdead[num]);
	}
    }

  modus=EVOL12_NORMAL;
  reference = new evol12_creature(NULL, NULL);
}

evol12_draw::evol12_draw(FILE *file) : draw()
{
  animals=NULL;
  plants=NULL;
  eaten=0;
  grown=0;
  step=0;
  dohalt = background_mode;
  runlen=0;
  modus=EVOL12_NORMAL;
  deadbeings=NULL;
  showtree=NULL;

  from_stream(file);
}

evol12_draw::evol12_draw() : draw()
{
  int i,j;

  animals=NULL;
  deadbeings=NULL;
  plants=new evol12_plant**[((int)size)/plantspace];
  eaten=0;
  grown=0;
  step=0;
  dohalt=background_mode;
  runlen=0;

  for(i=0; i<((int)size)/plantspace; i++)
    {
      plants[i]=new evol12_plant*[((int)size)/plantspace];
      for(j=0;j<((int)size)/plantspace; j++)
	{
	  double rr=drand48();
	  plants[i][j]=new evol12_plant(NULL, NULL,
					(double) i*plantspace+plantspace/2.0-
					size/2.0,
					(double) j*plantspace+plantspace/2.0-
					size/2.0);
	  if(rr<0.20)
	    plants[i][j]->set_plant_state(PLANT_GROWING);
	  else if(rr>0.45)
	    plants[i][j]->set_plant_state(PLANT_EATEN);
	}
    }

  for(i=0; i<numanimals;i++)
    {
      animals=new evol12_animal(NULL, animals,
                                (size-50.0)*drand48()-(size-50.0)/2.0,
                                (size-50.0)*drand48()-(size-50.0)/2.0,
                                0.3*drand48()-0.15,
                                0.3*drand48()-0.15);
    }

  modus=EVOL12_NORMAL;
  reference = new evol12_creature(NULL, NULL);
}

evol12_draw::~evol12_draw()
{
  cleanup();
}

void evol12_draw::cleanup(void)
{
  int i,j;
  int numplants = ((int)size)/plantspace;

  if(plants)
    {
      for(i=0;i<numplants;i++)
        if(plants[i])
          {
            for(j=0; j<numplants; j++)
              if(plants[i][j])
                delete plants[i][j];
            delete [] plants[i];
          }
      delete [] plants;
    }
  plants=NULL;

  if(animals)
    delete animals;
  animals=NULL;

  if(reference)
    delete reference;
  reference=NULL;
}

void evol12_draw::expose(void)
{
  evol12_animal *ptr, *ptr2;
  int i,j;

  if(!docompute)
    return;

  if(!background_mode && !dohalt)
    Set(2);

  //if(step%10==0)
  //cout << *this << endl;

  runlen++;

  if(step%25==0 && pt)
    pt->doupdatescale(step);

  step++;
  if(step>=plantstat)
    {    
      int numgrown=0, numgrowing=0;
      
      int i, numplants = ((int)size)/plantspace;

      for(i=0; i<numplants; i++)
	for(int j=0; j<numplants; j++)
	  {
	    PLANT_STATE pl=plants[i][j]->get_plant_state();
	    if(pl==PLANT_OK)
	      numgrown++;
	    else if(pl==PLANT_GROWING)
	      numgrowing++;
	  }

      if(pt)
        pt->showstat(eaten, grown, died, born,
                     animals ? animals->number_of_elements() : 0,
		     numgrown, numgrowing, numplants*numplants);
      eaten=0;
      grown=0;
      died=0;
      born=0;
      step=0;
    }

  //for(ptr=animals; ptr; ptr=ptr->suc())
  //ptr->collision_detect(animals);

  if(step%25==0)
    for(i=0; i<((int)size)/plantspace; i++)
      for(j=0;j<((int)size)/plantspace; j++)
        plants[i][j]->do_step(this);

  for(ptr=animals; ptr; ptr=ptr->suc())
    ptr->do_step(this);
  
  ptr=animals;
  while(ptr)
    {
      ptr2=ptr;
      ptr=ptr->suc();

      if(ptr2->get_eaten() <= 0.0)
        {
          if(animals == ptr2 && ptr == NULL && background_mode)
	    {
	      cout << "Last animal died!" << endl;
	      signal_handler(1);
	    }

          drawball(ptr2, 0);
          if(animals == ptr2)
            animals=ptr2->suc();
          ptr2->removefromlist();
	  
	  if(keepdead)
	    into_the_start((double_linked_list *) ptr2,
			   (double_linked_list **) &deadbeings);
	  else
	    delete ptr2;
          died++;
        }
      else if(ptr2->get_eaten() > ptr2->get_reproducelimit())
        {
          animals = new evol12_animal(NULL, animals, ptr2, True);
          born++;
        }
    }
  
  if(numfile==NULL && do_file_output)
    {
      if(doload)
	numfile=fopen("evol12_num.txt","a");
      else
	numfile=fopen("evol12_num.txt","w");
      fprintf(numfile,"# Column 1:  number of animals\n");
      fprintf(numfile,"# Column 2:  number of grown plants\n");
      fprintf(numfile,"# Column 3:  number of growing plants\n");
      fprintf(numfile,"###############################\n");

      if(doload)
	p_feel_file=fopen("evol12_p_feel_mean.txt", "a");
      else
	p_feel_file=fopen("evol12_p_feel_mean.txt", "w");
      fprintf(p_feel_file, "# Column 1: mean p_feel\n");
      fprintf(p_feel_file,"###############################\n");
      
      if(doload)
	growing_file=fopen("evol12_growing_mean.txt", "a");
      else
	growing_file=fopen("evol12_growing_mean.txt", "w");
      fprintf(growing_file, "# Column 1: mean growing\n");
      fprintf(growing_file,"###############################\n");
      
      if(doload)
	grown_file=fopen("evol12_grown_mean.txt", "a");
      else
	grown_file=fopen("evol12_grown_mean.txt", "w");
      fprintf(grown_file, "# Column 1: mean grown\n");
      fprintf(grown_file,"###############################\n");
      
      if(doload)
	p_eat_grown_file=fopen("evol12_p_eat_grown_mean.txt", "a");
      else
	p_eat_grown_file=fopen("evol12_p_eat_grown_mean.txt", "w");
      fprintf(p_eat_grown_file, "# Column 1: mean p_eat_grown\n");
      fprintf(p_eat_grown_file,"###############################\n");

      if(doload)
	p_eat_growing_file=fopen("evol12_p_eat_growing_mean.txt", "a");
      else
	p_eat_growing_file=fopen("evol12_p_eat_growing_mean.txt", "w");
      fprintf(p_eat_growing_file, "# Column 1: mean p_eat_growing\n");
      fprintf(p_eat_growing_file,"###############################\n");

      if(doload)
	velocity_file=fopen("evol12_velocity_mean.txt", "a");
      else
	velocity_file=fopen("evol12_velocity_mean.txt", "w");
      fprintf(velocity_file, "# Column 1: mean velocity\n");
      fprintf(velocity_file,"###############################\n");
      
      if(doload)
	mutation_file=fopen("evol12_mutation_mean.txt", "a");
      else
	mutation_file=fopen("evol12_mutation_mean.txt", "w");
      fprintf(mutation_file, "# Column 1: mean mutation\n");
      fprintf(mutation_file,"###############################\n");
    }
  
  if(runlen%500==0 && do_file_output)
    { 
      int numgrown=0, numgrowing=0;
      
      int i, numplants = ((int)size)/plantspace;

      for(i=0; i<numplants; i++)
	for(int j=0; j<numplants; j++)
	  {
	    PLANT_STATE pl=plants[i][j]->get_plant_state();
	    if(pl==PLANT_OK)
	      numgrown++;
	    else if(pl==PLANT_GROWING)
	      numgrowing++;
	  }

      int numanimals=animals ? animals->number_of_elements() : 0;

      fprintf(numfile,"%d %d %d %d\n", runlen, numanimals, numgrown, numgrowing);
      fflush(numfile);

      p_feel_hist_file=fopen("evol12_p_feel_curr_hist.txt", "w");
      growing_hist_file=fopen("evol12_growing_curr_hist.txt", "w");
      grown_hist_file=fopen("evol12_grown_curr_hist.txt", "w");
      p_eat_grown_hist_file=fopen("evol12_p_eat_grown_curr_hist.txt", "w");
      p_eat_growing_hist_file=fopen("evol12_p_eat_growing_curr_hist.txt", "w");
      velocity_hist_file=fopen("evol12_velocity_curr_hist.txt", "w");
      mutation_hist_file=fopen("evol12_mutation_curr_hist.txt", "w");

      double mean_p_feel=0.0, mean_growing=0.0, mean_grown=0.0, 
	mean_p_eat_grown=0.0, mean_p_eat_growing=0.0;
      double mean_velocity=0.0, mean_mutation=0.0;
      ptr=animals;
      while(ptr)
	{
	  fprintf(p_feel_hist_file, "%f\n", ptr->do_feel());
	  fprintf(growing_hist_file, "%f\n", ptr->do_eatinggrowing());
	  fprintf(p_eat_growing_hist_file, "%f\n", ptr->do_doeatgrowing());
	  fprintf(grown_hist_file, "%f\n", 
		  ptr->do_eatinggrown()-ptr->do_eatinggrowing());
	  fprintf(p_eat_grown_hist_file, "%f\n", ptr->do_doeatgrown());
	  fprintf(velocity_hist_file, "%f\n", ptr->get_velocity());
	  fprintf(mutation_hist_file, "%f\n", ptr->get_mutating_rate());

	  mean_p_feel += ptr->do_feel()/double(numanimals);
	  mean_growing += ptr->do_eatinggrowing()/double(numanimals);
	  mean_grown += (ptr->do_eatinggrown()-ptr->do_eatinggrowing())/
	    double(numanimals);
	  mean_p_eat_grown += ptr->do_doeatgrown()/double(numanimals);
	  mean_p_eat_growing += ptr->do_doeatgrowing()/double(numanimals);
	  mean_velocity += ptr->get_velocity()/double(numanimals);
	  mean_mutation += ptr->get_mutating_rate()/double(numanimals);

	  ptr=ptr->suc();
	}
      fclose(p_feel_hist_file);
      fclose(growing_hist_file);
      fclose(grown_hist_file);
      fclose(p_eat_grown_hist_file);
      fclose(p_eat_growing_hist_file);
      fclose(velocity_hist_file);
      fclose(mutation_hist_file);

      fprintf(p_feel_file, "%d %f\n", runlen, mean_p_feel);
      fflush(p_feel_file);
      fprintf(growing_file, "%d %f\n", runlen, mean_growing);
      fflush(growing_file);
      fprintf(grown_file, "%d %f\n", runlen, mean_grown);
      fflush(grown_file);
      fprintf(p_eat_grown_file, "%d %f\n", runlen, mean_p_eat_grown); 
      fflush(p_eat_grown_file);
      fprintf(p_eat_growing_file, "%d %f\n", runlen, mean_p_eat_growing); 
      fflush(p_eat_growing_file);
      fprintf(velocity_file, "%d %f\n", runlen, mean_velocity); 
      fflush(velocity_file);
      fprintf(mutation_file, "%d %f\n", runlen, mean_mutation); 
      fflush(mutation_file);
    }
}

void evol12_draw::zoom(evol12_creature *item)
{
  reference->set(item->get_x(), item->get_y());
  modus = EVOL12_MORE_ZOOMED;

  Clear("black");
  dohalt=False;
  Set(2);
}

PLANT_STATE evol12_draw::have_plant(evol12_animal *item)
{
  int plantnum=((int) size) / plantspace;
  int i=((int)(item->get_x()+size/2.0) / plantspace) % plantnum;
  int j=((int)(item->get_y()+size/2.0) / plantspace) % plantnum;

  if(item->is_collision(plants[i][j], False))
    {
      PLANT_STATE plstate=plants[i][j]->get_plant_state();
      return plstate;
    }
  else
    return PLANT_EATEN;
}

PLANT_STATE evol12_draw::do_eat(evol12_animal *item)
{
  int plantnum=((int) size) / plantspace;
  int i=((int)(item->get_x()+size/2.0) / plantspace) % plantnum;
  int j=((int)(item->get_y()+size/2.0) / plantspace) % plantnum;
  PLANT_STATE pl=have_plant(item);

  if(pl!=PLANT_EATEN)
    {
      plants[i][j]->set_plant_state(PLANT_EATEN);
      drawball(plants[i][j], 0);

      eaten++;
    }

  return pl;
}

Boolean evol12_draw::do_grow(evol12_plant *item)
{
  int plantnum=((int) size) / plantspace;
  int i=(int)(item->get_x()+size/2.0) / plantspace;
  int j=(int)(item->get_y()+size/2.0) / plantspace;
  int i0=i-1, i2=i+1, j0=j-1, j2=j+1;

  if(i0<0)
    i0+=plantnum;
  else if(i2>=plantnum)
    i2-=plantnum;

  if(j0<0)
    j0+=plantnum;
  else if(j2>=plantnum)
    j2-=plantnum;

  if(plants[i0][j0]->get_plant_state() == PLANT_OK ||
     plants[i0][j]->get_plant_state() == PLANT_OK ||
     plants[i0][j2]->get_plant_state() == PLANT_OK ||
     plants[i][j0]->get_plant_state() == PLANT_OK ||
     plants[i][j2]->get_plant_state() == PLANT_OK ||
     plants[i2][j0]->get_plant_state() == PLANT_OK ||
     plants[i2][j]->get_plant_state() == PLANT_OK ||
     plants[i2][j2]->get_plant_state() == PLANT_OK)
    return True;

  return False;
}

void evol12_draw::clear(void)
{
  SetFg("black");
  for(int i=0; i<(int) (zoomfactor*size);i++)
    for(int j=0; j<(int) (zoomfactor*size);j++)
      Point(i,j);
}

void evol12_draw::drawball(evol12_creature *pt, int filled)
{
  if(background_mode)
    return;

  int i,j;
  double ball_size=zoomfactor*pt->get_size()*(double) modus, 
    winsize = zoomfactor*size/(double) modus;
  double x0 = zoomfactor*pt->get_rel_x(reference) * (double) modus;
  double y0 = zoomfactor*pt->get_rel_y(reference) * (double) modus;

  if(filled)
    {
      char *col=pt->get_color();
      SetFg(col);
      delete [] col;
    }
  else
    SetFg("black");

  if(!(x0 > -zoomfactor*size/2.0 && x0 < zoomfactor*size/2.0 &&
       y0 > -zoomfactor*size/2.0 && y0 < zoomfactor*size/2.0))
    return;

  if(ball_size<=1.1)
    Point((int) (x0 + zoomfactor*size/2.0), (int) (y0 + zoomfactor*size/2.0));
  else
    for(i=0;i<(int) ball_size;i++)
      for(j=0;j<(int) ball_size;j++)
        {
          double x = (double) i - ball_size/2.0;
          double y = (double) j - ball_size/2.0;
          double inner = x * pt->get_dx() + y * pt->get_dy();
          int mouth=0;

          if(pt->is_predator())
            {
              evol12_animal *animal=(evol12_animal *) pt;
              mouth = animal->get_mouth();
            }

          if(mouth==0 || inner <=0.0 || (inner>0.0 &&
             inner*inner < mouth_state[mouth] * (x*x+y*y) *
                                         (pt->get_dx() * pt->get_dx() +
                                          pt->get_dy() * pt->get_dy())))
            if((x*x+y*y)<ball_size*ball_size/4.0)
              Point((int)(x0+x+zoomfactor*size/2.0), (int)(y0+y+zoomfactor*size/2.0));
        }
}

void evol12_draw::wakeup(void)
{
  expose();
}

void evol12_draw::DoButton1(int x , int y )
{
  double xx=reference->get_x(), yy=reference->get_y();
  double resize=1.0;

  switch(modus)
    {
    case EVOL12_NORMAL:
      Clear("black");

      modus=EVOL12_ZOOMED;
      reference->set(x/zoomfactor-size/2.0, y/zoomfactor-size/2.0);
      break;
    case EVOL12_ZOOMED:
      Clear("black");

      modus=EVOL12_MORE_ZOOMED;
      resize = (double) EVOL12_ZOOMED / (double) EVOL12_NORMAL;
      reference->set(xx+(x/zoomfactor-size/2.0)/resize, 
		     yy+(y/zoomfactor-size/2.0)/resize);
      reference->do_step(this, 0);
      break;
    case EVOL12_MORE_ZOOMED:
      Clear("black");

      modus=EVOL12_EVENMORE_ZOOMED;
      resize = (double) EVOL12_EVENMORE_ZOOMED / (double) EVOL12_NORMAL;
      reference->set(xx+(x/zoomfactor-size/2.0)/resize, 
		     yy+(y/zoomfactor-size/2.0)/resize);
      reference->do_step(this, 0);

      break;
    case EVOL12_EVENMORE_ZOOMED:
      Beep(1);
      break;
    }
}

void evol12_draw::DoButton2(int x , int y )
{
  double xx=reference->get_x(), yy=reference->get_y();
  double resize=1.0;

  switch(modus)
    {
    case EVOL12_NORMAL:
      Beep(1);
      break;
    case EVOL12_ZOOMED:
      Clear();
      modus=EVOL12_NORMAL;
      reference->set(0.0, 0.0);
      break;
    case EVOL12_MORE_ZOOMED:
      Clear();
      modus=EVOL12_ZOOMED;
      resize = (double) EVOL12_NORMAL / (double) EVOL12_MORE_ZOOMED;
      reference->set(xx+(x/zoomfactor-size/2.0)*resize, 
		     yy+(y/zoomfactor-size/2.0)*resize);
      reference->do_step(this, 0);
      break;
    case EVOL12_EVENMORE_ZOOMED:
      Clear();
      modus=EVOL12_MORE_ZOOMED;
      resize = (double) EVOL12_NORMAL / (double) EVOL12_EVENMORE_ZOOMED;
      reference->set(xx+(x/zoomfactor-size/2.0)*resize, 
		     yy+(y/zoomfactor-size/2.0)*resize);
      reference->do_step(this, 0);
      break;
    }
}

void evol12_draw::DoButton3(int x , int y )
{
  double xx=reference->get_x(), yy=reference->get_y();
  double resize = (double) modus / (double) EVOL12_NORMAL;
  double x0,y0;
  evol12_animal *ptr;
  evol12_creature *ptr2;

  x0 = xx + (((double) x)/zoomfactor - size/2.0) / resize;
  y0 = yy + (((double) y)/zoomfactor - size/2.0) / resize;

  ptr2=new evol12_creature(NULL, NULL);
  ptr2->set(x0,y0);

  for(ptr=animals; ptr; ptr=ptr->suc())
    if(ptr->is_collision(ptr2))
      {
        evol12_show *newshow = new evol12_show();

        newshow->Create(pt->showb, ptr);

        break;
      }

  delete ptr2;
}

void evol12_draw::DoUp()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case EVOL12_NORMAL:
      Beep(1);
      break;
    case EVOL12_ZOOMED:
      Clear();
      reference->set(xx, yy - 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case EVOL12_MORE_ZOOMED:
      Clear();
      reference->set(xx, yy - 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case EVOL12_EVENMORE_ZOOMED:
      Clear();
      reference->set(xx, yy - 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    }
}

void evol12_draw::DoDown()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case EVOL12_NORMAL:
      Beep(1);
      break;
    case EVOL12_ZOOMED:
      Clear();
      reference->set(xx, yy + 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case EVOL12_MORE_ZOOMED:
      Clear();
      reference->set(xx, yy + 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case EVOL12_EVENMORE_ZOOMED:
      Clear();
      reference->set(xx, yy + 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    }
}

void evol12_draw::DoLeft()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case EVOL12_NORMAL:
      Beep(1);
      break;
    case EVOL12_ZOOMED:
      Clear();
      reference->set(xx - 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case EVOL12_MORE_ZOOMED:
      Clear();
      reference->set(xx - 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case EVOL12_EVENMORE_ZOOMED:
      Clear();
      reference->set(xx - 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    }
}

void evol12_draw::DoRight()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case EVOL12_NORMAL:
      Beep(1);
      break;
    case EVOL12_ZOOMED:
      Clear();
      reference->set(xx + 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case EVOL12_MORE_ZOOMED:
      Clear();
      reference->set(xx + 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case EVOL12_EVENMORE_ZOOMED:
      Clear();
      reference->set(xx + 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    }
}

void evol12_draw::show_all(void)
{
  evol12_showall *pt=new evol12_showall();

  pt->Create(animals, this);
  if(!background_mode)
    {
      dohalt=True;
      Set(2);
    }
}

evol12_animal *nextbeing(evol12_animal *ptr, evol12_animal *deadbeings,
			 Boolean &traverseddead)
{
  evol12_animal *ptr2;

  if(!ptr->suc() && !traverseddead)
    {
      ptr2=deadbeings;
      traverseddead=True;
    }
  else
    ptr2=ptr->suc();
     
  return ptr2;
}

void evol12_draw::show_tree(void)
{
  char str[10];
  register int i,j;
  evol12_animal *ptr;
  int numalive= animals ? animals->number_of_elements() : 0;
  int numdead=deadbeings ? deadbeings->number_of_elements() : 0;
  lineage_entity *aliveptr=NULL, *deadptr=NULL;

  if(showtree)
    delete showtree;

  if(animals)
    aliveptr=new lineage_entity[numalive+numdead];

  if(deadbeings)
    deadptr=new lineage_entity[numdead+numalive];

  showtree=new evol12_lineage();
  showtree->pt=this;

  i=0;
  for(ptr=animals; ptr ; ptr=ptr->suc())
    {
      sprintf(str, "l%-8d", i);
      ptr->set_code(str);
      i++;
    }

  i=0;
  for(ptr=deadbeings; ptr ; ptr=ptr->suc())
    {
      sprintf(str, "d%-8d", i);
      ptr->set_code(str);
      i++;
    }
  
  i=0;
  j=0;
  Boolean traverseddead=False;
  for(ptr=animals; ptr ; ptr = nextbeing(ptr, deadbeings, traverseddead))
    {
      lineage_entity *parent=NULL;
      double val[22];

      val[0]=ptr->get_prob(0);
      val[1]=ptr->get_prob(1) - ptr->get_prob(0);
      val[2]=ptr->get_prob(2) - ptr->get_prob(1);
      val[3]=1.0 - ptr->get_prob(2);
      val[4]=ptr->get_mutating_rate();
      val[5]=ptr->get_velocity();
      val[6]=ptr->get_reproducelimit();
      val[7]=ptr->get_ch_angle();
      val[8]=(double) ptr->get_generation();
      val[9]=ptr->get_size();
      val[10]=ptr->do_feel();
      val[11]=ptr->do_remember();
      val[12]=ptr->do_eatinggrowing();
      val[13]=ptr->do_eatinggrown() - ptr->do_eatinggrowing();
      val[14]=1.0 - ptr->do_eatinggrown();
      val[15]=ptr->do_doeatgrowing();
      val[16]=ptr->do_doeatgrown();
      val[17]=ptr->get_age();
      val[18]=ptr->get_children();
      val[19]=ptr->get_red();
      val[20]=ptr->get_green();
      val[21]=ptr->get_blue();

      if(ptr->get_parent())
	{
	  int num;

	  sscanf(ptr->get_parent()->get_code()+1, "%d", &num);
	  if(ptr->get_parent()->get_code()[0]=='l')
	    parent=aliveptr+num;
	  else
	    parent=deadptr+num;
	}

      if(traverseddead)
	deadptr[j++].Create(22, val, ptr->get_birthtime(),
				   ptr->get_age(), parent);
      else
	aliveptr[i++].Create(22, val, ptr->get_birthtime(),
			     ptr->get_age(), parent);
    }

  numalive=i;
  numdead=j;

  char *prop[]={"p(walk)","p(left)","p(right)","p(eat)","m.rate",
		"speed","Rep.limit","angle","gener.","size",
		"p(feel)","p(rem)","dig. growing","dig. grown",
		"Unused dig.", "p(growing)","p(grown)", "Age", 
		"#children","red","green","blue"};
  showtree->Create(aliveptr, numalive, deadptr, numdead, 22, prop, runlen);

  dohalt=True;
}


void evol12_draw::restart(void)
{
  if(showtree)
    delete showtree;
  showtree=NULL;

  if(!docompute)
    return;

  dohalt=False;
  Set(2);
}

void evol12_showdraw::Create(widget parent, evol12_animal *new_item)
{
  build(parent, 100, 100);
  item=new_item;
}

void evol12_showdraw::expose(void)
{
  int i,j;
  double ball_size=90.0;
  double x0 = item->get_x();
  double y0 = item->get_y();
  double dx=1.0, dy=0.0;
  char *col=item->get_color();

  SetFg(col);
  delete [] col;

  for(i=0;i<(int)ball_size;i++)
    for(j=0;j<(int)ball_size;j++)
      {
        double x = (double) i - ball_size/2.0;
        double y = (double) j - ball_size/2.0;
        double inner = x * dx + y * dy;

        if(inner <=0.0 || (inner>0.0 &&
                           inner*inner < 0.5 * (x*x+y*y) *
                           (dx*dx+dy*dy)))
          if((x*x+y*y)<ball_size*ball_size/4.0)
            Point((int)(x+ball_size/2.0+5.0), (int)(y+ball_size/2.0+5.0));
      }
}

void evol12_show::Create(widget parent, evol12_animal *item)
{
  build(parent, "Individ-info");
  v1.build(*this);
  lab1.build(v1, "Vesenet er av %d generasjon og er %d sykler gammel. "
             "Energistatus:%lf",
             item->get_generation(), item->get_age(), item->get_eaten());
  lab2.build(v1, "Det %-9.6lf store vesenet har %d barn og "
             "har en mutasjonsrate p� %lf", item->get_size(),
             item->get_children(), item->get_mutating_rate());
  lab3.build(v1, "Strategi: g�=%4.2lf%%, venstre=%4.2lf%%, "
             "h�yre=%4.2lf%%, spise=%4.2lf%%", 100.0*item->get_prob(0),
             100.0*(item->get_prob(1)-item->get_prob(0)),
             100.0*(item->get_prob(2)-item->get_prob(1)),
             100.0*(1.0-item->get_prob(2)));
  lab4.build(v1, "Gj. start-hastighet: %lf , reproduksjonsgrense: "
             "%lf(%3.0lf%%))  ,  sving-vinkel:%lf",
             item->get_velocity(), item->get_reproducelimit(),
             100.0*item->get_reproducelimit()/(450.0*item->get_size()*
                                               item->get_size()),
             item->get_ch_angle());
  lab5.build(v1, "Vesenet kan %sdetektere planter og husker %shastighet "
             "f�r spising", item->do_feel() ? "" : "ikke ",
             item->do_remember() ? "" : "ikke ");
  lab6.build(v1, "Det spiser %sutvokste planter %s %svoksende planter %s",
             item->do_doeatgrown() ? "" : "ikke ",
             (item->do_doeatgrowing()!=item->do_doeatgrown()) ? "men" : "og",
             item->do_doeatgrowing() ? "" : "ikke ",
             (!item->do_doeatgrowing() &&
              !item->do_doeatgrown()) ? "(stakkar!)" :
             "");
  switch(item->get_predator_state())
    {
    case PREDATOR_WALK:
      lab7.build(v1,"Akkurat n� g�r den.");
      break;
    case PREDATOR_LEFT:
      lab7.build(v1,"Akkurat n� svinger den til venstre.");
      break;
    case PREDATOR_RIGHT:
      lab7.build(v1,"Akkurat n� svinger den til h�yre.");
      break;
    case PREDATOR_EAT:
      lab7.build(v1,"Akkurat n� spiser den.");
      break;
    }
  lab8.build(v1, "Hastighet n�: %lf (%lf, %lf)",
             sqrt(item->get_dx()*item->get_dx() +
                  item->get_dy()*item->get_dy()),
             item->get_dx(), item->get_dy());

  h1.build(v1);
  dr.Create(h1, item);
  exitb.Create(v1, this);
  Map();
}

void evol12_showbutton::Create(widget parent, evol12_show *ipt)
{
  pt=ipt;
  build(parent, "Avslutt");
  Background("red");
  Foreground("white");
}

void evol12_showbutton::pushed(void)
{
  pt->Unmap();
  delete pt;
}



void evol12_lineage::ended(void)
{
  pt->restart();
}


void evol12_button::Create(widget parent, char *txt,
                          evol12 *ipt, EVOL12_BUTTON_TYPE type)
{
  pt=ipt;
  typ=type;
  build(parent, txt);
}

void evol12_button::pushed(void)
{
  pt->button_pushed(typ);
}

void evol12::button_pushed(EVOL12_BUTTON_TYPE type)
{
  switch(type)
    {
    case EVOL12_SHOW:
      drawpt->show_all();
      break;
    case EVOL12_TREE:
      drawpt->show_tree();
      break;
    case EVOL12_EXIT:
      if(docompute)
        signal_handler(0); // store the results
      exit(0);
    }
}

void evol12::showstat(int eaten, int grown, int died, int born, int total,
		      int numgrown, int numgrowing, int numslots)
{
  char str[100];

  eatenf.SetDigit(eaten);
  grownf.SetDigit(grown);
  diedf.SetDigit(died);
  bornf.SetDigit(born);
  totalf.SetDigit(total);

  sprintf(str, "%d (%lf%%)", numgrown, 
	  100.0 * (double) numgrown / (double) numslots);
  numgrownf.SetText(str);
  sprintf(str, "%d (%lf%%)", numgrowing, 
	  100.0 * (double) numgrowing / (double) numslots);
  numgrowingf.SetText(str);
}

void evol12::doupdatescale(int count)
{
  updatescale.SetValue(count);
}

evol12::evol12(int argc, char **argv) : mainwin("Evol12 1.1", argc, argv)
{
  if(doload)
    {
      FILE *file=fopen("evol12.sav", "r");

      if(!file)
        {
          cout << "File 'evol12.sav' not found!" << endl;
          exit(0);
        }
      
      drawpt=new evol12_draw(file);
      fclose(file);
    }
  else
    drawpt=new evol12_draw();
  drawpt->pt=this;

  v1.build(*this);

  if(docompute)
    {
      h5.build(v1);
      
      v3.build(h5);
      drawpt->build(v3, (int) (size*zoomfactor), (int) (size*zoomfactor));
      
      v2.build(h5);
      h1.build(v2);
      eatenf.build(h1, 5, "Eaten:");
      eatenf.EditAble(False);
      grownf.build(h1, 5, "Grown:");
      grownf.EditAble(False);
      numgrownf.build(v2, 15, "# grown plants:");
      numgrowingf.build(v2, 15, "# growing plants:");
      
      h2.build(v2);
      diedf.build(h2, 5, "Died: ");
      diedf.EditAble(False);
      bornf.build(h2, 5, "Born: ");
      bornf.EditAble(False);
      h3.build(v2);
      totalf.build(h3, 5, "Population:");
      totalf.EditAble(False);

      
      updatescale.build(v1, "", 0, plantstat, 0);
    }

  h4.build(v1);
  exitb.Create(h4, "Avslutt",this, EVOL12_EXIT);
  exitb.Background("red");
  exitb.Foreground("white");
  showb.Create(h4, "Vis vesener", this, EVOL12_SHOW);
  showb.Background("yellow");
  showb.Foreground("black");
  treeb.Create(h4, "Vis slektstre", this, EVOL12_TREE);
  treeb.Background("yellow");
  treeb.Foreground("black");

  
}

void usage(void)
{
  cout << "Usage: evol12 [-l] [-b] [-E] [-F] [-z <zoom factor>] [-m metabolizsm power] "
    "[-G <best growing>]" << endl << " [-e <best energy>] [<#creatres> "
    "[<size> [<critsize> [<plantspace> [<plantgrowth>]]]]]" << endl;
  cout << "  or   evol12 -s (Loads a previous run withouth continuing the "
    "computations." << endl;
  cout << "                  Used for showing the results of an earlier run.)" << endl;
  cout << " -l loads the parameters from a file specifying a previous run." <<
    endl;
  cout << " -b should run the program without graphics." << endl;
  cout << " -n do *not* keep dead in the memory." << endl;
  
  cout << " -E switches off evolution by switch off mutation." << endl;
  cout << " -f <file> sends birth time, age and censoring indicator to a file" << endl;
  cout << " -F : toggles file output for central characters." << endl;
  exit(0);
}

int main(int argc, char **argv)
{
  char *outfile=NULL;
  int numopt=0;
  while((numopt+1)<argc && argv[numopt+1][0]=='-')
    {
      switch(argv[numopt+1][1])
        {
	case 'F':
	  do_file_output=True;
	  break;
	case 'f':
	  outfile=argv[numopt+2];
	  numopt++;
          docompute=False;
          doload=True;
          background_mode=True;
	  break;
	case 'E':
	  noevol=True;
	  break;
	case 'm':
	  metabol_pow=atof(argv[numopt+2]);
	  numopt++;
	  break;
	case 'G':
	  best_growing=atof(argv[numopt+2]);
	  numopt++;
	  break;
	case 'e':
	  best_energy=atof(argv[numopt+2]);
	  numopt++;
	  break;
	case 'n':
	  keepdead=False;
	  break;
        case 's':
          docompute=False;
          doload=True;
          background_mode=False;
        case 'l':
          doload=True;
          break;
        case 'b':
          background_mode=True;
          break;
	case 'z':
	  sscanf(argv[numopt+2], "%lf", &zoomfactor);
	  numopt++;
	  break;
        case 'h':
        case 'H':
        case '?':
        default:
          usage();
          break;
        }

      numopt++;
    }

  if(argc>=2+numopt)
    sscanf(argv[1+numopt], "%d", &numanimals);

  if(argc>=3+numopt)
    sscanf(argv[2+numopt], "%lf", &size);

  if(argc>=4+numopt)
    sscanf(argv[3+numopt], "%lf", &critsize);

  if(argc>=5+numopt)
    sscanf(argv[4+numopt], "%d", &plantspace);
  plantspace *= (int) critsize;

  if(argc>=6+numopt)
    sscanf(argv[5+numopt], "%d", &plantgrowth);

  time_t tm;

  time(&tm);
  long int t=(int) tm;

  srand48(t);

  if(docompute)
    activate_signal();

  if(background_mode)
    {
      if(doload)
        {
          FILE *file=fopen("evol12.sav", "r");

          if(!file)
            {
              cout << "File 'evol12.sav' not found!" << endl;
              exit(0);
            }

          drawpt=new evol12_draw(file);
          fclose(file);
        }
      else
        drawpt=new evol12_draw();

      drawpt->pt=NULL;

      if(!outfile)
	while(1)
	  drawpt->expose();
      else
	drawpt->write_text_file(outfile);
    }
  else
    {
      evol12 png(argc, argv);

      png.Run();
    }

  return 0;
}

void activate_signal(void)
{
  signal(SIGTERM, signal_handler);
  signal(SIGILL, signal_handler);
  signal(SIGQUIT, signal_handler);
  signal(SIGINT, signal_handler);
  signal(SIGHUP, signal_handler);
}

void signal_handler(int signal_nr)
{
  ofstream out;
  FILE *file;

  cout << "Please wait while we're saving data..." << endl;

  file=fopen("evol12.sav", "w");
  if(!file)
    {
      cout << "Couldn't write to file \"evol12.sav\"!" << endl;
      exit(0);
    }

  drawpt->to_stream(file);
  fclose(file);
  
  cout << "Done!" << endl;

  if(do_file_output)
    {
      fclose(numfile);
      fclose(p_feel_file);
      fclose(growing_file);
      fclose(grown_file);
      fclose(p_eat_grown_file);
      fclose(p_eat_growing_file);
      fclose(velocity_file);
      fclose(mutation_file);
    }

  exit(0);
}
