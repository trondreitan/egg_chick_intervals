#include "vvgraph.H"
#include <hydrasub/hydrabase/divfunc.H>


// ************************************************** //
//                                                    //
//                VVGRAPH                             //
//                                                    //
// This is a program for showing one or several       //
// value-value files as a plot.                       //
//                                                    //
//                Trond Reitan                        //
//                  1/10-2000                         //
//                                                    //
// ************************************************** //


// **************************************************
//              VV_ELEM
// This is an element of a linked list, containing
// info about a specified value-value element
// **************************************************

// CONSTRUCTOR
// Makes the elemtn at puts it in the tail of a given list.
vv_elem::vv_elem(vv_elem *prev, double argument, double value) :
  double_linked_list((double_linked_list *) prev, NULL)
{
  arg=argument;
  val=value;
}

// DESTRUCTOR 
// Destroys all elements in a list
vv_elem::~vv_elem()
{
  vv_elem *next = (vv_elem *) getnext();

  removefromlist();
  if(next)
    delete next;
}

// GET_TIME
// Fetches the element's time
double vv_elem::get_argument(void)
{
  return arg;
}

// GET_VALUE
// Fetches the element's value
double vv_elem::get_value(void)
{
  return val;
}



// **************************************************
//         VVEXITB
// Exit button class;
// **************************************************

void vvexitb::Create(widget parent, char *txt, vvgraph *ipt)
{
  pt=ipt;
  build(parent, txt);
}

//        PUSHED
// called when the user pushes the button. Exits the program
void vvexitb::pushed(void)
{
  pt->exit_pushed();
}


char *checkline(char *line, char *strptr, char *filename, int num, 
		int numchannels, bool lessthan)
{
  char *strptr2;

  if((!lessthan && num!=numchannels) || (lessthan && num>numchannels)) 
    // wrong channel number?
    {
      std::cerr << "Error in file " << filename << std::endl;
      std::cerr << "Column number out of range: " << line << std::endl;
      exit(0);
    }
  
  // fetch the line title
  strptr2=strstr(strptr, ":");
  
  if(!strptr2)
    {
      std::cerr << "Error in file " << filename << std::endl;
      std::cerr << "Couldn't find the ':' sign: " << line << std::endl;
      exit(0);
    }

  strptr2++;
  return strptr2;
}

// **************************************************
//         VVGRAPH
// The main class of this application.
// Holds the plotting area and the exit button
// Has a method for fetching timerie info from a
// file format beloning to the application
// **************************************************

//           GETFILE
// Fetches info from a given file and returns the contens as a structure
vv_file &vvgraph::getfile(std::istream &in, char *filename, int numseries_so_far, 
			  int linesep)
{
  vv_file *filestruct=new vv_file();
  vv_elem **vvhead=NULL, **vvtail=NULL;
  char line[1000], channelnames[50][1000], colorname[50][100];
  PLOTLINE_TYPE type[50];
  PLOTLINE_STYLE style[50];
  int width[50];
  char *color[]={"#000000",  "#aa0000", "#005500", "#0000aa", 
		 "#880088", "#007788", "#777700", "#aa4400"};
  PLOTLINE_STYLE style_choices[]={PLOTLINE_SOLID, PLOTLINE_DOTS, 
				  PLOTLINE_LARGE_DASH, 
				  PLOTLINE_DASH_DOT, PLOTLINE_SLDASH, 
				  PLOTLINE_DASH_DOT_DOT,
				  PLOTLINE_SMALL_DASH, PLOTLINE_HUGE_DASH, 
				  PLOTLINE_DASH_DASH_DOT};

  int i,j, numchannels=0;
  double **val;
  double **arg;
  int *len, numseries;
  char **names;
  PLOTLINE_TYPE *types;
  PLOTLINE_STYLE *styles;
  int *widths;
  char **colors;

  for(i=0;i<50;i++)
    {
      strcpy(channelnames[i], "");
      type[i]=PLOTLINE_LINE;
      strcpy(colorname[i], color[(i+numseries_so_far)%8]);
      style[i]=style_choices[(i+numseries_so_far)%9];
      width[i]=2;
    }

  // get the first line
  in.getline(line, 999);

  // fetch header info, if there is any...
  while(!in.fail() && !in.eof() && *line=='#' && strncmp(line, "#####", 5))
    {
      char *strptr, *strptr2, *strptr3, *strptr4;
      // if the comment indicates a graph title... 
      if((strptr=strstr(line, "Column"))!=NULL || 
	 (strptr=strstr(line, "column"))!=NULL || 
	 (strptr=strstr(line, "COLUMN"))!=NULL)
	{
	  int num;

	  sscanf(strptr+6, "%d", &num); // fetch the channel number

	  if(strptr2=strstr(strptr+6, "type"))
	    {
	      strptr3=checkline(line, strptr2, filename, num, numchannels, 
				true);
	      
	      if((strstr(strptr3, "line") || strstr(strptr3, "graph")) &&
		 (strstr(strptr3, "dot") || strstr(strptr3, "marker")))
		type[num-1]=PLOTLINE_LINEDOT;
	      else if(strstr(strptr3, "line") || strstr(strptr3, "graph"))
		type[num-1]=PLOTLINE_LINE;
	      else if(strstr(strptr3, "dot") || strstr(strptr3, "marker"))
		type[num-1]=PLOTLINE_DOT;
	      else if(strstr(strptr3, "filled"))
		type[num-1]=PLOTLINE_FILLEDBARS;
	      else if(strstr(strptr3, "bar"))
		type[num-1]=PLOTLINE_BARS;
	      else
		std::cout << "\"" <<  line << "\" - unknown graph type" << std::endl;
	    }
	  else if(strptr2=strstr(strptr+6, "width"))
	    {
	      strptr3=checkline(line, strptr2, filename, num, numchannels, 
				true);

	      if(!sscanf(strptr3, "%d", width+num-1))
		{
		  std::cout << "\"" <<  line << "\" - couldn't read width" << std::endl;
		  width[num-1]=2;
		}
	    }
	  else if(strptr2=strstr(strptr+6, "style"))
	    {
	      strptr3=checkline(line, strptr2, filename, num, numchannels, 
				true);

	      if(strstr(strptr3, "solid") || ((strstr(strptr3, "circle") ||
		 strstr(strptr3, " o") ||  strstr(strptr3, " O") ||
		 strstr(strptr3, " 0")) && !strstr(strptr3, "cross")))
		style[num-1]=PLOTLINE_SOLID;
	      else if(strstr(strptr3, "...") || 
		      (strstr(strptr3, "small") &&
		      strstr(strptr3, "dot")) ||
		      strstr(strptr3, "triangle"))
		style[num-1]=PLOTLINE_DOTS;
	      else if((strstr(strptr3, "large") && strstr(strptr3, "dash") &&
		       !strstr(strptr3, "small")) ||
		      strstr(strptr3, "___ ___ ") ||
		      strstr(strptr3, "--- --- ") ||
		      (strstr(strptr3, "cross") && 
		       !strstr(strptr3, "circle") &&
		       !strstr(strptr3, " o") &&
		       !strstr(strptr3, " O") &&
		       !strstr(strptr3, " 0")))
		style[num-1]=PLOTLINE_LARGE_DASH;
	      else if((strstr(strptr3, "dash") && 
		       (strptr4=strstr(strptr3, "dot")) && 
		       !strstr(strptr4+1, "dot")) ||
		      strstr(strptr3, "_ . _ .") ||
		      strstr(strptr3, "- . - .") ||
		      ((strstr(strptr3, "X") || strstr(strptr3, "x")) &&
		       !strstr(strptr3, "square") && 
		       !strstr(strptr3, "rectangle")))
		style[num-1]=PLOTLINE_DASH_DOT;
	      else if((strstr(strptr3, "large") && strstr(strptr3, "dash") &&
		       strstr(strptr3, "small")) ||
		      strstr(strptr3, "___ _ ___ _") ||
		      strstr(strptr3, "--- - --- -") ||
		      ((strstr(strptr3, "square") ||
			strstr(strptr3, "rectangle")) && 
		       !strstr(strptr3, "x") && !strstr(strptr3, "X")))
		style[num-1]=PLOTLINE_SLDASH;
	      else if((strstr(strptr3, "dash") && 
		       (strptr4=strstr(strptr3, "dot")) && 
		       strstr(strptr4+1, "dot")) ||
		      strstr(strptr3, "_ .. _ ..") || 
		      strstr(strptr3, "_ . . _ . .") ||
		      strstr(strptr3, "- .. - ..") || 
		      strstr(strptr3, "- . . - . .") ||
		      strstr(strptr3, "club") ||
		      strstr(strptr3, "tilted square") ||
		      strstr(strptr3, "tilted rectangle"))
		style[num-1]=PLOTLINE_DASH_DOT_DOT;
	      else if((!strstr(strptr3, "large") && strstr(strptr3, "dash") &&
		       strstr(strptr3, "small")) ||
		      strstr(strptr3, "_ _ _ _") || 
		      strstr(strptr3, "- - - -") ||
		      strstr(strptr3, "*") || strstr(strptr3, "star"))
		style[num-1]=PLOTLINE_SMALL_DASH;
	      else if((strstr(strptr3, "huge") && strstr(strptr3, "dash")) ||
		      strstr(strptr3, "_____ _____ ") || 
		      strstr(strptr3, "----- ----- ") ||
		      ((strstr(strptr3, "circle") || strstr(strptr3, " o") ||
			strstr(strptr3, " O") || strstr(strptr3, " 0")) && 
		       strstr(strptr3, "cross")))
		style[num-1]=PLOTLINE_HUGE_DASH;
	      else if(((strptr4=strstr(strptr3, "dash")) && 
		       strstr(strptr4+1, "dash") &&
		       strstr(strptr3, "dot")) ||
		      strstr(strptr3, "-- -- . -- -- .") || 
		      strstr(strptr3, "__ __ . __ __ .") || 
		      strstr(strptr3, "_ _ . _ _ .") || 
		      strstr(strptr3, "- - . - - .") ||
		      ((strstr(strptr3, "square") || 
			strstr(strptr3, "rectangle")) && 
		       (strstr(strptr3, "x") || strstr(strptr3, "X"))))
		style[num-1]=PLOTLINE_DASH_DOT_DOT;
	      else
		std::cout << "\"" <<  line << "\" - unknown graph style" << std::endl;
	    }
	  else if(strptr2=strstr(strptr+6, "color"))
	    {
	      strptr3=checkline(line, strptr, filename, num, numchannels, 
				true);
	     
	      strptr4=strstr(strptr3, "#");
	      if(!strptr4 || 
		 (!isdigit(strptr4[1]) && !(strptr4[1]>='a' &&
					    strptr4[1]<='f') ) || 
		 (!isdigit(strptr4[2]) && !(strptr4[2]>='a' &&
					    strptr4[2]<='f') ) || 
		 (!isdigit(strptr4[3]) && !(strptr4[3]>='a' &&
					    strptr4[3]<='f') ) || 
		 (!isdigit(strptr4[4]) && !(strptr4[4]>='a' && 
					    strptr4[4]<='f') ) || 
		 (!isdigit(strptr4[5]) && !(strptr4[5]>='a' &&
					    strptr4[5]<='f') ) || 
		 (!isdigit(strptr4[6]) && !(strptr4[6]>='a' &&
					    strptr4[6]<='f') ))
		std::cout << "\"" << line << "\" - unknown color format. " << std::endl 
		     << "Legal: # followed by six-digit hex code (red,"
		  "green,blue)" << std::endl;
	      else
		{
		  strncpy(colorname[num-1], strptr4, 7); 
		  colorname[num-1][7]='\0';
		}
	    }
	  else
	    {
	      numchannels++; // number of channels has to be increased

	      strptr3=checkline(line, strptr, filename, num, numchannels, 
				false);
	      if(strptr3[0]==' ')
		strptr3++;
	      strcpy(channelnames[num-1], strptr3);
	      if(channelnames[num-1][strlen(channelnames[num-1])-1]=='\r')
		channelnames[num-1][strlen(channelnames[num-1])-1]='\0';
	    }
	}

      // fetch the next line in the file
      in.getline(line, 999);
    }

  if(numchannels==0)
    numchannels=1;

  // make the vv lists
  vvhead=new vv_elem*[numchannels];
  vvtail=new vv_elem*[numchannels];
  for(i=0;i<numchannels;i++)
    vvhead[i]=vvtail[i]=NULL;

  int linenr=0;
  // traverse the rest of the file
  while(!in.fail() && !in.eof())
    {
      double valbuffer, argbuffer;

      if(*line!='\0' && *line!='#' && linenr%linesep==0) 
	// if the line isn't empty of contents...
	{
	  char *strptr=line;
	  
	  if((strptr=getnextdouble(strptr, &argbuffer))==NULL)
	    {
	      std::cout << "Illegal argument string in file \"" << filename << 
		"\": " << line << std::endl;
	      exit(0);
	    }
	  
	  for(i=0;i<numchannels;i++)
	    {
	      if((strptr=getnextdouble(strptr, &valbuffer))==NULL)
		{
		  std::cout << "Illegal value string in file \"" << filename << 
		    "\": " << line << std::endl;
		  exit(0);
		}
	      
	      if(valbuffer == -9999)
		valbuffer=MISSING_VALUE;

	      // insert the value into a vv list;
	      vvtail[i]=new vv_elem(vvtail[i], argbuffer, valbuffer);
	      if(!vvhead[i]) 
		vvhead[i]=vvtail[i];
	    }
	}

      linenr++;
      // fetch the next line in the file;
      in.getline(line, 999);
    }

  if(!vvhead || !*vvhead) // no data?
    {
      std::cout << "No data found in file \"" << filename << "\"!" << std::endl;
      exit(0);
    }

  // make the structure necessary to represent the contents of the file;
  numseries=numchannels;
  names=new char*[numchannels];
  arg=new double*[numchannels];
  val=new double*[numchannels];
  len=new int[numchannels];
  widths=new int[numchannels];
  colors=new char*[numchannels];
  styles=new PLOTLINE_STYLE[numchannels];
  types=new PLOTLINE_TYPE[numchannels];

  // set info belonging to each vv channel;
  for(i=0;i<numchannels;i++)
    {
      // fetch the length;
      len[i] = vvhead[i]->number_of_elements();

      // make the necessary arrays;
      arg[i] = new double[len[i]];
      val[i] = new double[len[i]];
      names[i] = new char[300];
      colors[i] = new char[100];

      widths[i]=width[i];
      strcpy(colors[i], colorname[i]);
      styles[i]=style[i];
      types[i]=type[i];

      // pointer used to traverse the contents of this channel;
      vv_elem *vvptr=vvhead[i];

      // traverse the contents of this channel;
      for(j=0; j<len[i]; j++)
	{
	  // put the vv element into the 'arg' and 'val' arrays;
	  arg[i][j]=vvptr->get_argument();
	  val[i][j]=vvptr->get_value();
	  
	  // fetch the next vv element;
	  vvptr = (vv_elem *) vvptr->getnext();
	}

      // set the line/channel name;
      if(channelnames[i][0]=='\0') // no channel name given in the file?
	{
	  if(numchannels==1) 
	    strcpy(names[i], filename);
	  else
	    sprintf(names[i], "%s - %d", filename, i+1);
	}
      else // channel name given in the file
	strcpy(names[i], channelnames[i]);
    }

  // put the contents of the file into the structure representing the file;
  filestruct->arg=arg;
  filestruct->val=val;
  filestruct->len=len;
  filestruct->numseries=numseries;
  filestruct->names=names;
  filestruct->type=types;
  filestruct->style=styles;
  filestruct->color=colors;
  filestruct->width=widths;

  // cleanup;
  for(i=0;i<numchannels;i++)
    delete vvhead[i];
  delete [] vvhead;

  return *filestruct; // return the contents of the file
}


//           CONSTRUCTOR
// makes the main window, reads from the file using 'getfile'
// and sends the contents to the plotting module;
vvgraph::vvgraph(int argc, char **argv) : 
  mainwin("VVGRAPH", argc, argv)
{
  char **axistitles=new char*[20], outfile[200]="";
  bool grid=false, bigticks=false;
  int height=800, width=1000, sep=0, linesep=1;
  int pyear=int(MISSING_VALUE), pmin=int(MISSING_VALUE);
  Boolean logx=false, logy=False;
  Boolean *usecolumn=new Boolean[argc*50-1];
  register int i, j, k=0;
  char *ptr;
  char *title=NULL;
  double minval=MISSING_VALUE, maxval=MISSING_VALUE;
  int vs=0;

  for(i=0;i<argc*50-1;i++)
    usecolumn[i]=True;

  // make the axis names;
  axistitles[0]=new char[100];
  sprintf(axistitles[0], "Time");
  
  axistitles[1]=new char[100];
  sprintf(axistitles[1], "Value");
  
  // traverse the option arguments;
  argc--;
  argv++;
  while(argc>0 && argv[0][0]=='-') // while more options are found...
    {
      switch(argv[0][1]) 
	{
	case 'v':
	  argc--;
	  argv++;
	  vs=atoi(*argv);
	  break;
	case 'b':
	  bigticks=true;
	  break;
	case 'S':
	  argc--;
	  argv++;
	  linesep=atoi(*argv);
	  break;
	case 'l':
	case 'L': 
	  // toggle grid lines;
	  grid=true;
	  break;
	case 'c':
	case 'C':
	  for(i=0;i<argc*50-1;i++)
	    usecolumn[i]=False;
	  argc--;
	  argv++;

	  ptr=*argv;
	  do
	    {
	      int column;

	      ptr=getnextint(ptr, &column);
	      if(ptr)
		{
		  if(column<1 || column>(argc-1)*50)
		    {
		      std::cerr << "Column number out of range!" << std::endl;
		      exit(0);
		    }
		  usecolumn[column-1]=True;
		} 
	    } while(ptr && *ptr);
	  break;
	case 't':
	case 'T':
	  // use title:
	  argc--;
	  argv++;
	  title=new char[100];
	  strcpy(title, *argv);
	  break;
	case 'm':
	case 'M':
	  // toggle periodicity in minutes
	  argc--;
	  argv++;
	  sscanf(*argv, "%d", &pmin);
	  break;
	case '1':
	  logx=True;
	  break;
	case '2':
	  logy=True;
	  break;
	case 'p':
	case 'P':
	  // toggle periodicity in minutes
	  argc--;
	  argv++;
	  sscanf(*argv, "%d", &pyear);
	  break;
	case 'x':
	case 'X':
	  // fetch title of the x-axis
	  argc--;
	  argv++;
	  strcpy(axistitles[0], *argv);
	  break;
	case 'y':
	  // fetch the title of the y-axis
	  argc--;
	  argv++;
	  strcpy(axistitles[1], *argv);
	  break;
	case 'F':
	  fileusage();
	  break;
	case 'H':
	  // fetch the height;
	  argc--;
	  argv++;
	  sscanf(*argv, "%d", &height);
	  break;
	case 'W':
	  // fetch the width;
	  argc--;
	  argv++;
	  sscanf(*argv, "%d", &width);
	  break;
	case 'a':
	  // fetch the max y value;
	  argc--;
	  argv++;
	  maxval=atoi(*argv);
	  break;
	case 'i':
	  // fetch the min y value;
	  argc--;
	  argv++;
	  minval=atoi(*argv);
	  break;
	case 'f':
	  // fetch the output file name;
	  argc--;
	  argv++;
	  strcpy(outfile, *argv);
	  break;
	case 's':
	  sep=1;
	  break;
	default:
	  // unknown option;
	  std::cerr << "Unknow option '" << argv[0][1] << "'!" << std::endl;
	  usage();
	  break;
	}

      // fetch the next argument
      argc--;
      argv++;
    }

  
  int numfiles=MAXIM(argc,1), numseries=0;
  vv_file *files=new vv_file[numfiles+1];

  if(vs)
    usecolumn[vs-1]=False;

  if(argc==0) // no files given?
    {
      files[0]=getfile(std::cin, "Standard in", numseries, linesep);
      
      int num=files[0].numseries, tempnum=numseries;
    
      for(j=numseries;j<numseries+num;j++)
	if(usecolumn[j])
	  tempnum++;
      
      numseries=tempnum; // increments the number of series
    }
  else
    for(i=0; i<numfiles; i++) // traverse the input files
      {
	std::ifstream in;
	
	// open the specified file
	in.open(argv[i]);
	if(in.fail())
	  {
	    std::cout << "Couldn't find file \"" << argv[i] << "\"!" << std::endl;
	    exit(0);
	  }
	
	files[i]=getfile(in, argv[i], numseries, linesep); // fetch another input file
	in.close();

	int num=files[i].numseries, tempnum=numseries;
	
	for(j=numseries;j<numseries+num;j++)
	  if(usecolumn[j])
	    tempnum++;
	
	numseries=tempnum; // increments the number of series
      }
  
  // make the arrays need for for plotting;
  double **arg=new double*[numseries]; 
  double **val=new double*[numseries];
  int *len=new int[numseries], *axis=new int[numseries];
  char **linetitles=new char*[numseries];
  char tempfile[1000], command[1000];
  AXIS_SCALING *logaxis=new AXIS_SCALING[numseries+1];
  int num=0;

  logaxis[0]=logx ? AXIS_LOGARITHMIC : AXIS_LINEAR;
  for(i=1;i<=numseries;i++)
    logaxis[i]=logy ? AXIS_LOGARITHMIC : AXIS_LINEAR;

  // optional elements;
  PLOTLINE_TYPE *type = new PLOTLINE_TYPE[numseries];
  PLOTLINE_STYLE *style = new PLOTLINE_STYLE[numseries];
  int *widths=new int[numseries];
  char **color=new char*[numseries];

  if(vs)
    axistitles[0]=files[0].names[vs-1];

  // traverse the files;
  for(i=0;i<numfiles;i++)
    {
      // traverse the series in the examined file;
      for(j=0;j<files[i].numseries;j++) 
	{
	  if(usecolumn[num])
	    {
	      // put the contents of this serie into the plotting arrays;
	      if(!vs)
		arg[k]=files[i].arg[j];
	      else
		arg[k]=files[i].val[vs-1];
	      val[k]=files[i].val[j];
	      len[k]=files[i].len[j];
	      linetitles[k]=files[i].names[j];
	      if(!sep)
		axis[k]=1; // just one y-axis
	      else
		axis[k]=k+1;
	      type[k]=files[i].type[j];
	      style[k]=files[i].style[j];
	      color[k]=files[i].color[j];
	      widths[k]=files[i].width[j];

	      k++;
	    }

	  num++;
	}
    }

  if(pmin!=MISSING_VALUE || pyear!=MISSING_VALUE)
    pl.set_radial(pmin, pyear, True);

  if(maxval!=MISSING_VALUE)
    pl.set_max(maxval);
  if(minval!=MISSING_VALUE)
    pl.set_min(minval);

  if(!*outfile) // no output file given
    {
      show=true; // screen output set
      v1.build(*this); // make the main container
      
      // Tell the plotting module that it's to be displayed 
      // in the main container
      pl.put_in_widget(v1, width, height, PLOT_IN_WIDGET_SHOWMAINMENU);
      
      // Make the exit button;
      exitb.Create(v1, "Quit", this);
      exitb.Background("red");
      exitb.Foreground("white");
    }
  else // output file given
    {
      DateTime now; now.now(); // fetch time now
      char *ptr=now.syCh(2);   // make it into a string

      // make a name for a temporal file;
      sprintf(tempfile, "/tmp/vvgraph%s", ptr);
      delete [] ptr;

      show=false; // no screen output set
      
      // tell the plotting module that the output is to go to a temporal file
      pl.set_background(tempfile, width, height);
    }

  if(bigticks)
    pl.set_big();

  if(grid) // if grids are wanted by the user...
    pl.set_grid(True); // tell the plotting module that grids are wanted

  if(sep)
    {
      for(i=1;i<=numseries;i++)
	{
	  axistitles[i]=new char[10];
	  sprintf(axistitles[i], "graph %d", i);
	}
    }

  // make the plot;
  pl.Create(arg, val, len, axis, linetitles, numseries, axistitles, 
	    2+sep*(numseries-1), title, type, NULL, style, color, 
	    widths, logaxis);
  
  if(!show) // output to file?
    {
      int stlen=strlen(outfile);
      // postscript file?
      if(((outfile[stlen-3]=='.' &&
	   (outfile[stlen-2]=='p' || outfile[stlen-2]=='P') &&
	   (outfile[stlen-1]=='s' || outfile[stlen-1]=='S'))) ||
	 ((outfile[stlen-4]=='.' &&
	   (outfile[stlen-3]=='e' || outfile[stlen-3]=='E') &&
	   (outfile[stlen-2]=='p' || outfile[stlen-2]=='P') &&
	   (outfile[stlen-1]=='s' || outfile[stlen-1]=='S'))))
	{
	  // move the file to the given file name

	  sprintf(command, "mv %s.eps %s", tempfile, outfile);
	  system(command);
	}
      else
	{
	  // convert the file to the correct format using
	  // ImageMagic's 'convert' command. (Must be in the path!);
	  sprintf(command, "convert %s.eps %s", tempfile, outfile);
	  system(command);
	  
	  // Remove the temporal file;
	  sprintf(command, "rm -f %s.eps", tempfile);
	  system(command);
	}
    }

  delete [] usecolumn;
}

void vvgraph::exit_pushed(void)
{
  pl.Cleanup();
  exit(0);
}


//            DOSHOW
// Returns if the application is to be run on the screen
bool vvgraph::doshow(void)
{
  return show;
}

// GLOBAL FUNCTIONS;

void fileusage(void)
{
  std::cout << "For a file having the advanced layout, there are options that "
    "can be given to" << std::endl;
  std::cout << "the plot. The advanced layout looks like this;" << std::endl << std::endl;

  std::cout << "# Column 1: <line title of first line>." << std::endl;
  std::cout << "# Column 2: <line title of second line>." << std::endl;
  std::cout << "..." << std::endl;
  std::cout << "############################" << std::endl;
  std::cout << "argument value1 value 2 ..." << std::endl;
  std::cout << "argument value1 value 2 ..." << std::endl;
  std::cout << "..." << std::endl << std::endl;

  std::cout << "After each column name specification in the header ('# Column n: "
    "<line title n>)" << std::endl;
  std::cout << "one can put in the follow optional lines;"  << std::endl;
  std::cout << "# Column n - type: <plotting type of graph n>" << std::endl;
  std::cout << "# Column n - style: <plotting style of graph n>" << std::endl;
  std::cout << "# Column n - color: <plotting color of graph n>" << std::endl;
  std::cout << "# Column n - width: <plotting width of graph n>" << std::endl << std::endl;
  
  std::cout << "Plotting type: the plotting type determines wether a single "
    "graphs should" << std::endl;
  std::cout << "be plotted using lines, dots, dots+lines, bars or filled bars" 
       << std::endl;
  std::cout << "One gets a line graph by putting; '# Column n - type: line' " 
       << std::endl;
  std::cout << "(this is the default!)" << std::endl; 
  std::cout << "One gets dot representation by specifying 'dot' after '# Column n "
    "- type:'" << std::endl;
  std::cout << "One gets dots and line by specifying 'dot+line'" << std::endl;
  std::cout << "One gets bars (column diagram) by specifying 'bars'" << std::endl;
  std::cout << "One gets filled bars by specifying 'filled bars'" << std::endl << std::endl;

  std::cout << "Plotting style: the plotting style determines what combination "
       << std::endl;
  std::cout << "of dashes and dots are to be used in a line graph and what symbols"
       << std::endl;
  std::cout << "are to be used in a dot representation of a graph." << std::endl;
  std::cout << "For line graphs the following styles are available;" << std::endl;
  std::cout << "   \"solid\", \"small dot\", \"large dash\", \"dash+dot\"," << std::endl;
  std::cout << "   \"small and large dash\", \"dash+dot+dot\", \"small dash\", "
       << std::endl;
  std::cout << "   \"huge dash\" and \"dash+dash+dot\"" << std::endl;
  std::cout << " They can also be specified as; " << std::endl;
  std::cout << "   \"solid\", \"___ ___ ___\", \"_ . _ . _ .\", \"_ ___ _ ___ _\","
       << std::endl;
  std::cout << "   \"___ . . ___ . .\", \"- - - - - -\", \"_____ _____\" and "
    "\"__ __ . __ __ .\"" << std::endl;
  std::cout << "For dot graphs the following styles are available;" << std::endl;
  std::cout << "   \"circle\", \"triangle\", \"cross\", \"X\", \"square\" "
    "(or \"rectangle\"), " << std::endl;
  std::cout << "   \"club\" (or \"titled square\"), \"circle+cross\" and "
    "\"square+X\"" << std::endl;
  std::cout << "(Note that dot styles can be used for the corresponding line style"
    " and vice" << std::endl;
  std::cout << " versa, in case you shift graph type but forget to switch style "
    "label.)" << std::endl << std::endl;

  std::cout << "The color of graphs are specified using \"# Column n - color: " 
       << std::endl; 
  std::cout << "  #<six digit hex code of the color>" << std::endl;
  std::cout << "The color code uses two digits for each color in the "
    "red,green,blue scheme" << std::endl;
  std::cout << "Example: \"#000000\"=black, \"#ffffff\"=white, \"00ffff\"=cyan, "
    "\"800000\"=dark red" << std::endl << std::endl;
  
  std::cout << "The width of the graph lines are specified using \"# Column n - "
    "width: <integer>" << std::endl;
  std::cout << "The default is width=2" << std::endl << std::endl;

  std::cout << "A small example using all options:" << std::endl;
  std::cout << "# Column 1: Testgraf A" << std::endl;
  std::cout << "# Column 1 - color: #00ffff" << std::endl;
  std::cout << "# Column 1 - type: dot" << std::endl;
  std::cout << "# Column 2: Testgraf B" << std::endl;
  std::cout << "# Column 2 - style: solid" << std::endl;
  std::cout << "# Column 2 - width: 5" << std::endl;
  std::cout << "##################################" << std::endl;
  std::cout << "0.0  0.0  -1.0" << std::endl;
  std::cout << "0.1  0.1  -0.8" << std::endl;
  std::cout << "0.2  0.3  -0.5" << std::endl;
  std::cout << "0.3  0.6  0.0" << std::endl;
  std::cout << "0.4  1.0  0.7" << std::endl;
  std::cout << "0.5  1.5  1.5" << std::endl << std::endl;

  std::cout << "This file will be graphed using dots for the first data " << std::endl;
  std::cout << " ((0.0, 0.0), (0.1, 0.1), (0.1, 0.3), (0.4, 0.6), (0.4, 1.0), "
    "(0.5, 1.5))" << std::endl;
  std::cout << "while the second column will be drawn using lines (which is " 
       << std::endl;
  std::cout << "the default and which thus isn't neccesary to specify)." << std::endl;
  std::cout << "The color of the first graph is set to cyan, while the " << std::endl;
  std::cout << "application determines the color of the second graph itself." 
       << std::endl;
  std::cout << "The line style of the second graph is set to 'solid' in stead " 
       << std::endl;
  std::cout << "of letting the program determine the line style." << std::endl << std::endl;
  std::cout << "-Trond Reitan (trr@nve.no), 1/10-2001" << std::endl;
  exit(0);
}

//                USAGE
// Sends a manual to standard out and exits;
void usage(void)
{
  std::cout << "Usage: vvgraph [-l] [-x <x-axis title>] [-y <y-axis title>] " << 
    std::endl;
  std::cout << "       [-1] [-2] [-p <year periodicity>] "
    "[-m <minute periodicity>]" << std::endl;
  std::cout << "       [-c column_number1,column_number2,..." << std::endl;
  std::cout << "       [-T <plot title>] [-f <filename>] [-s]" << std::endl;
  std::cout << "       [-W <file image width in pixels>]" << std::endl;
  std::cout << "       [-H <file image height in pixels>]" << std::endl;
  std::cout << "       [-S <line separation>] [-b]" << std::endl;
  std::cout << "       [-a <max y value>] [-i <min y value>]" << std::endl;
  std::cout << "       <vv file 1 > [<vv file 2> ...]" << std::endl << 
    std::endl;
  std::cout << "Format of file(s):" << std::endl;
  std::cout << "argument value" << std::endl;
  std::cout << "argument value" << std::endl;
  std::cout << "..." << std::endl << std::endl;
  std::cout << "If more than one channel or the lien label is to be specified" <<
    std::endl;
  std::cout << "Use the header:" << std::endl << std::endl;
  std::cout << "# Column 1: <line title of first line>." << std::endl;
  std::cout << "# Column 2: <line title of second line>." << std::endl;
  std::cout << "..." << std::endl;
  std::cout << "############################" << std::endl;
  std::cout << "argument value1 value 2 ..." << std::endl;
  std::cout << "argument value1 value 2 ..." << std::endl;
  std::cout << "..." << std::endl << std::endl;
  std::cout << "The option '-l' toggle grid on." << std::endl;
  std::cout << "The option '-1' toggle logarithmic x-axis." << std::endl;
  std::cout << "The option '-2' toggle logarithmic y-axis." << std::endl;
  std::cout << "The option -p toggle polar plot with the given periodicity "
    "in years." << std::endl;
  std::cout << "The option -m toggle polar plot with the given periodicity "
    "in minutes." << std::endl;
  std::cout << "The option -c toggle wether to use only the specified " << std::endl;
  std::cout << "  columns (default is to use all). No spaces between the numbers!" 
       << std::endl;
  std::cout << "The option -T gives the plot a header title at the top of the plot."
       << std::endl;
  std::cout << "The option '-x' sets the label of the x-axis." << std::endl;
  std::cout << "The option '-y' sets the label of the y-axis." << std::endl;
  std::cout << "The option '-f' sends the plot to a file on gif or eps format" <<
    std::endl;
  std::cout << "The option '-s' toggle separate y-axis for each column" << std::endl;
  std::cout << "     rather than the screen (other formats supported by "
    "ImageMagics 'convert' can also be used.)" << std::endl;
  std::cout << "The option '-b' toggles big ticks." << std::endl;
  std::cout << "The option '-W' sets the file image's width in pixels." << std::endl;
  std::cout << std::endl;
  std::cout << "The option '-H' sets the file image's width in pixels." << std::endl;
  std::cout << std::endl;
  std::cout << "The option '-S' specifies the number of lines between each " << std::endl;
  std::cout << "     included line in the plot." << std::endl;
  std::cout << "The option '-v' <column> specifies that the remaining columns are "
    "to be plotted agains the specified one\n" << std::endl;
  std::cout << "For more details about the input files (options), "
    "type 'vvgraph -F'" << std::endl;
  exit(0);
}


//                    MAIN
// Starts the main window
int main(int argc, char **argv)
{
  language=English; // language is english 

  vvgraph vg(argc, argv); // make the plot

  if(vg.doshow()) // if the output mode is visual
    vg.Run(); // run the main window

  return 1;
}
