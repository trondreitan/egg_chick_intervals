#include "bmsrc.H"

int main(int argc, char **argv)
{
  show_stagedischarge st;
  show_stagedischarge_plot sp;
  vrow v1;
  exitbutton exitb;

  mainwin mn("bmsrc",argc,argv);
  v1.build(mn);
  st.create(v1);
  sp.Create(v1, 600,300, &st);
  st.connect_to_plot(&sp);
  exitb.Create(v1, "Exit");

  mn.Run();

  return 0;
}
