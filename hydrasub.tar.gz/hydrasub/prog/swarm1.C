#include "swarm1.H"
#include <fstream.h>

int numhunters=5, numhares=2000;
double size_x=480.0, size_y=320.0, huntersize=6.0, haresize=1.0;
double hunterangle=1.0, hareangle=5.0;
double haresin1, haresin2;
double harecos1, harecos2;
double huntersin1, huntersin2;
double huntercos1, huntercos2;
double lookback=-1.0, sigthlen;
double relvel=1, absvel=2.0;

swarm1_draw *drawpt;

#define sgn(x) ( x < 0 ? -1 : +1)

swarm1_item::swarm1_item(swarm1_item *prev, swarm1_item *next,
			 double start_x, double start_y, double v,
			 Boolean is_hare) :
  double_linked_list((double_linked_list *) prev, (double_linked_list *) next)
{
  x = start_x;
  y = start_y;
  dx=drand48()-0.5;
  dy=drand48()-0.5;

  ishare=is_hare;

  if(!ishare)
    {
      do
	{
	  red=(int) (drand48() * 256.0);
	  green=(int) (drand48() * 256.0);
	  blue==(int) (drand48() * 256.0);
	} while(red<240 && green<240 && blue<240);
    }
  else
    {
      red=green=blue=255;
    }

  if(is_hare)
    itemsize=haresize;
  else
    itemsize=huntersize;

  velocity=v; // *plantspace/5.0;

  double vv=sqrt(dx*dx+dy*dy);

  dx *= v/vv;
  dy *= v/vv;
}

double get_rand(double low, double high, double oldval, double severity)
{
  double newval;

  if(drand48()<0.5)
    newval=oldval-drand48()*(oldval-low)*severity;
  else
    newval=oldval+drand48()*(high-oldval)*severity;

  return newval;
}


void swarm1_item::do_collision(double impactx, double impacty)
{
  dx += impactx;
  dy += impacty;
}

swarm1_item *swarm1_item::suc(void)
{
  return (swarm1_item *) getnext();
}

swarm1_item *swarm1_item::pred(void)
{
  return (swarm1_item *) getprev();
}

void swarm1_item::set(double start_x, double start_y,
                     double start_dx, double start_dy)
{
  x  = start_x;
  y  = start_y;
  dx = start_dx;
  dy = start_dy;
}

double swarm1_item::get_size(void)
{
  return itemsize;
}

double swarm1_item::get_rel_x(swarm1_item *item)
{
  double x1 = x - item->x;

  if(x1 >= size_x/2.0)
    x1 -= size_x;
  else if(x1 < -size_x/2.0)
    x1 += size_x;

  return x1;
}

double swarm1_item::get_rel_y(swarm1_item *item)
{
  double y1 = y - item->y;

  if(y1 >= size_y/2.0)
    y1 -= size_y;
  else if(y1 < -size_y/2.0)
    y1 += size_y;

  return y1;
}

double swarm1_item::get_next_rel_x(swarm1_item *item)
{
  double x1 = x +dx - item->x - item->dx;

  if(x1 >= size_x/2.0)
    x1 -= size_x;
  else if(x1 < -size_x/2.0)
    x1 += size_x;

  return x1;
}

double swarm1_item::get_next_rel_y(swarm1_item *item)
{
  double y1 = y + dy - item->y - item->dy;

  if(y1 >= size_y/2.0)
    y1 -= size_y;
  else if(y1 < -size_y/2.0)
    y1 += size_y;

  return y1;
}




double swarm1_item::get_velocity(void)
{
  return sqrt(2.0)*velocity/3.0;
}

double swarm1_item::get_x(void)
{
  return x;
}

double swarm1_item::get_y(void)
{
  return y;
}

double swarm1_item::get_dx(void)
{
  return dx;
}

double swarm1_item::get_dy(void)
{
  return dy;
}

char *swarm1_item::get_color(void)
{
  char *color=new char[100];

  sprintf(color, "#%02x%02x%02x", red ,green, blue);

  return color;
}

void swarm1_item::do_step(swarm1_draw *pt, int doshow, 
			  swarm1_item *targethead, image *img)
{
  swarm1_item *ptr, *target=NULL;
  double x0,y0,ddx=0.0, ddy=0.0;
  double r_nearest2=(double) size_x*size_y;

  if(doshow)
    pt->drawball(this, 0);

  for(ptr=targethead; ptr; ptr=ptr->suc())
    {
      double x1 = 0.0, y1 = 0.0;
      double x2, y2;
      
      x2 = ptr->get_rel_x(this);
      y2 = ptr->get_rel_y(this);

      // collision detection;
      double r2=(x1-x2)*(x1-x2) + (y1-y2)*(y1-y2);
      if(r2 < r_nearest2 && 
	 sgn(x2*dx+y2*dy)*(x2*dx+y2*dy)*(x2*dx+y2*dy) >= 
	 sgn(lookback)*lookback*lookback*(dx*dx+dy*dy)*r2 &&
	 r2 <= sigthlen*sigthlen)
	{
	  r_nearest2=(x1-x2)*(x1-x2) + (y1-y2)*(y1-y2);
	  target=ptr;
	  x0=x2;
	  y0=y2;
	}
    }

  if(target)
    {
      if(ishare)
	{
	  if((x0*dy-y0*dx) < 0.0)
	    {
	      ddx=dx*harecos1+dy*haresin1;
	      ddy=-dx*haresin1+dy*harecos1;
	    }
	  else
	    {
	      ddx=dx*harecos2+dy*haresin2;
	      ddy=-dx*haresin2+dy*harecos2;
	    }
	}
      else
	{
	  if((x0*dy-y0*dx) >= 0.0)
	    {
	      ddx=dx*huntercos1+dy*huntersin1;
	      ddy=-dx*huntersin1+dy*huntercos1;
	    }
	  else
	    {
	      ddx=dx*huntercos2+dy*huntersin2;
	      ddy=-dx*huntersin2+dy*huntercos2;
	    }
	}

      dx=ddx;
      dy=ddy;
    }

  x = x+dx;
  y = y+dy;

  if(x > size_x/2.0)
    x -= size_x;
  else if(x < -size_x/2.0)
    x += size_x;

  if(y > size_y/2.0)
    y -= size_y;
  else if(y < -size_y/2.0)
    y += size_y;

  if(doshow)
    pt->drawball(this, 1, img);
}

Boolean swarm1_item::is_collision(swarm1_item *item, Boolean donext)
{
  double x1 = 0.0, y1 = 0.0;
  double x2, y2;

  if(donext)
    {
      x2 = item->get_next_rel_x(this);
      y2 = item->get_next_rel_y(this);
    }
  else
    {
      x2 = item->get_rel_x(this);
      y2 = item->get_rel_y(this);
    }

  // collision detection;
  if(((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) <
      ((itemsize+item->itemsize)*(itemsize+item->itemsize)/4.0))
    return True;

  return False;
}

void swarm1_item::collision_detect(swarm1_item *head)
{
  swarm1_item *ptr;

  for(ptr=head; ptr && ptr!=this; ptr=ptr->suc())
    {
      double x1 = 0.0, y1 = 0.0;
      double x2 = ptr->get_next_rel_x(this), y2 = ptr->get_next_rel_y(this);
      double ex,ey,er,k0;

      // collision detection;
      if(is_collision(ptr, True))
        // collision
        /* moving towards? */
        {
          // make a unit vector between the balls;
          ex=x1-x2;
          ey=y1-y2;
          er=sqrt(ex*ex+ey*ey);
          ex=ex/er;
          ey=ey/er;

          // collision strength;
          k0 = -((ptr->dx - dx) * ex + (ptr->dy - dy) * ey);

          if(k0<0.0)
            {
              // new velocity after collision;
              do_collision(-k0*ex, -k0*ey);
              ptr->do_collision(k0*ex, k0*ey);
            }
        }
    }
}

int swarm1_item::get_red(void)
{
  return red;
}

int swarm1_item::get_green(void)
{
  return green;
}

int swarm1_item::get_blue(void)
{
  return blue;
}



swarm1_draw::swarm1_draw(int postscript_) : draw()
{
  int i,j;

  postscript=postscript_;

  balls=NULL;
  hare=NULL;

  for(i=0; i<numhunters;i++)
    balls=new swarm1_item(NULL, balls,
			  (size_x-50.0)*drand48()-(size_x-50.0)/2.0,
			  (size_y-50.0)*drand48()-(size_y-50.0)/2.0, 
			  (0.7+0.3*drand48())*relvel*absvel, False);
  
  for(i=0; i<numhares;i++)  
    hare=new swarm1_item(NULL, hare,
			 (size_x-50.0)*drand48()-(size_x-50.0)/2.0,
			 (size_y-50.0)*drand48()-(size_y-50.0)/2.0, 
			 (0.7+0.3*drand48())*absvel, True);

  modus=SWARM1_NORMAL;
  reference = new swarm1_item(NULL, NULL, 0.0, 0.0, 0.0, False);
}

swarm1_draw::~swarm1_draw()
{
  cleanup();
}

void swarm1_draw::cleanup(void)
{
  int i,j;

  if(balls)
    delete balls;
  balls=NULL;

  if(reference)
    delete reference;
  reference=NULL;

  if(hare)
    delete hare;
  hare=NULL;
}

void swarm1_draw::expose(void)
{
  swarm1_item *ptr, *ptr2;
  int i,j;
  static int count=1;
  char filename[1000];
  image *img=NULL;

  Set(2);

  if(postscript)
    {
      /*
      sprintf(filename, "swarm1_%06d.eps", count);
      invert_black_and_white=False;
      initialize_postscript(filename, (int) size_x, (int) size_y);*/

      img=new image((int) size_x, (int) size_y);
    }
  
  for(ptr=balls; ptr; ptr=ptr->suc())
    ptr->do_step(this,1,hare,img);
  
  for(ptr=hare; ptr; ptr=ptr->suc())
    ptr->do_step(this,1,balls,img);
  
  if(postscript)
    {
      /*
	char cmd[1000];
      endpostscript();
      sprintf(cmd, "ps2png swarm1_%06d.eps swarm1_%06d.png", count, count);
      system(cmd);
      unlink(filename);
      */

      char filename[100];
      sprintf(filename, "swarm1_%06d.png", count);
      write_image(img, filename);

      delete img;
      count++;
    }
}



void swarm1_draw::clear(void)
{
  SetFg("black");
  for(int i=0; i<(int)size_x;i++)
    for(int j=0; j<(int)size_y;j++)
      Point(i,j);
}

void swarm1_draw::drawball(swarm1_item *pt, int filled, image *img)
{
  int i,j;
  double ball_size=pt->get_size()*(double) modus;
  double x0 = pt->get_rel_x(reference) * (double) modus;
  double y0 = pt->get_rel_y(reference) * (double) modus;
  rgb currcol;

  if(filled)
    {
      char *col=pt->get_color();
      SetFg(col);
      delete [] col;
      
      currcol.red=(unsigned char) pt->get_red();
      currcol.green=(unsigned char) pt->get_green();
      currcol.blue=(unsigned char) pt->get_blue();
    }
  else
    {
      SetFg("black");
      rgb black(0,0,0);
      currcol=black;
    }

  if(!(x0 > -size_x/2.0 && x0 < size_x/2.0 &&
       y0 > -size_y/2.0 && y0 < size_y/2.0))
    return;

  if(ball_size<=1.1)
    {
      int xx=(int) (x0 + size_x/2.0), yy=(int) (y0 + size_y/2.0);
      Point(xx, yy);
      if(img && xx>=0 && xx<int(size_x) && yy>=0 && yy<int(size_y)) 
	img->values[yy][xx]=currcol;
    }
  else
    for(i=0;i<(int)ball_size;i++)
      for(j=0;j<(int)ball_size;j++)
        {
          double x = (double) i - ball_size/2.0;
          double y = (double) j - ball_size/2.0;
	  double norm = sqrt(x*x+y*y); 

          double innerprod = (x * pt->get_dx() + y *
			  pt->get_dy())/pt->get_velocity()/norm; 
	  // should yield a number between -1.0 and 1.0
	  
          if(norm<(ball_size/2.0) && (innerprod >=2.1 || innerprod<=-2.1))
	    {
	      int xx=(int) (x0 + x+ size_x/2.0), yy=(int) (y0 + y + size_y/2.0);

	      Point(xx, yy);
	      if(img && xx>=0 && xx<int(size_x) && yy>=0 && yy<int(size_y))
		img->values[yy][xx]=currcol;
	    }
	}
}

void swarm1_draw::wakeup(void)
{
  expose();
}

void swarm1_draw::DoButton1(int x , int y )
{
  double xx=reference->get_x(), yy=reference->get_y();
  double resize=1.0;

  switch(modus)
    {
    case SWARM1_NORMAL:
      clear();

      modus=SWARM1_ZOOMED;
      reference->set(x-size_x/2.0, y-size_y/2.0);
      break;
    case SWARM1_ZOOMED:
      clear();

      modus=SWARM1_MORE_ZOOMED;
      resize = (double) SWARM1_ZOOMED / (double) SWARM1_NORMAL;
      reference->set(xx+(x-size_x/2.0)/resize, yy+(y-size_y/2.0)/resize);
      reference->do_step(this, 0);
      break;
    case SWARM1_MORE_ZOOMED:
      clear();

      modus=SWARM1_EVENMORE_ZOOMED;
      resize = (double) SWARM1_EVENMORE_ZOOMED / (double) SWARM1_NORMAL;
      reference->set(xx+(x-size_x/2.0)/resize, yy+(y-size_y/2.0)/resize);
      reference->do_step(this, 0);

      break;
    case SWARM1_EVENMORE_ZOOMED:
      Beep(1);
      break;
    }
}

void swarm1_draw::DoButton2(int x , int y )
{
  double xx=reference->get_x(), yy=reference->get_y();
  double resize=1.0;

  switch(modus)
    {
    case SWARM1_NORMAL:
      Beep(1);
      break;
    case SWARM1_ZOOMED:
      clear();
      modus=SWARM1_NORMAL;
      reference->set(0.0, 0.0);
      break;
    case SWARM1_MORE_ZOOMED:
      clear();
      modus=SWARM1_ZOOMED;
      resize = (double) SWARM1_NORMAL / (double) SWARM1_MORE_ZOOMED;
      reference->set(xx+(x-size_x/2.0)*resize, yy+(y-size_y/2.0)*resize);
      reference->do_step(this, 0);
      break;
    case SWARM1_EVENMORE_ZOOMED:
      clear();
      modus=SWARM1_MORE_ZOOMED;
      resize = (double) SWARM1_NORMAL / (double) SWARM1_EVENMORE_ZOOMED;
      reference->set(xx+(x-size_x/2.0)*resize, yy+(y-size_y/2.0)*resize);
      reference->do_step(this, 0);
      break;
    }
}

void swarm1_draw::DoUp()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case SWARM1_NORMAL:
      Beep(1);
      break;
    case SWARM1_ZOOMED:
      clear();
      reference->set(xx, yy - 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case SWARM1_MORE_ZOOMED:
      clear();
      reference->set(xx, yy - 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case SWARM1_EVENMORE_ZOOMED:
      clear();
      reference->set(xx, yy - 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    }
}

void swarm1_draw::DoDown()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case SWARM1_NORMAL:
      Beep(1);
      break;
    case SWARM1_ZOOMED:
      clear();
      reference->set(xx, yy + 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case SWARM1_MORE_ZOOMED:
      clear();
      reference->set(xx, yy + 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    case SWARM1_EVENMORE_ZOOMED:
      clear();
      reference->set(xx, yy + 100.0 / (double) modus);
      reference->do_step(this, 0);
      break;
    }
}

void swarm1_draw::DoLeft()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case SWARM1_NORMAL:
      Beep(1);
      break;
    case SWARM1_ZOOMED:
      clear();
      reference->set(xx - 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case SWARM1_MORE_ZOOMED:
      clear();
      reference->set(xx - 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case SWARM1_EVENMORE_ZOOMED:
      clear();
      reference->set(xx - 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    }
}

void swarm1_draw::DoRight()
{
  double xx=reference->get_x(), yy=reference->get_y();

  switch(modus)
    {
    case SWARM1_NORMAL:
      Beep(1);
      break;
    case SWARM1_ZOOMED:
      clear();
      reference->set(xx + 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case SWARM1_MORE_ZOOMED:
      clear();
      reference->set(xx + 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    case SWARM1_EVENMORE_ZOOMED:
      clear();
      reference->set(xx + 100.0 / (double) modus, yy);
      reference->do_step(this, 0);
      break;
    }
}



void swarm1_button::Create(widget parent, char *txt,
                          swarm1 *ipt, SWARM1_BUTTON_TYPE type)
{
  pt=ipt;
  typ=type;
  build(parent, txt);
}

void swarm1_button::pushed(void)
{
  pt->button_pushed(typ);
}

void swarm1::button_pushed(SWARM1_BUTTON_TYPE type)
{
  switch(type)
    {
    case SWARM1_EXIT:
      exit(0);
    }
}


swarm1::swarm1(int argc, char **argv, int postscript_) : 
  mainwin("Swarm1 1.0", argc, argv)
{
  postscript=postscript_;

  drawpt=new swarm1_draw(postscript);
  drawpt->pt=this;

  v1.build(*this);
  h5.build(v1);
  v3.build(h5);
  drawpt->build(v3, (int) size_x, (int) size_y);

  h4.build(v1);
  exitb.Create(h4, "Avslutt",this, SWARM1_EXIT);
  exitb.Background("red");
  exitb.Foreground("white");
}

void usage(void)
{
  cout << "Usage: swarm1 [<#hunters> [<#hares> [<canvas size� "
    "[�hunter size>" << endl;
  cout << "              [<hare size> [<lookback> " << endl;
  cout << "              [<hunter angle> [<hare angle> [<rel. velocity> " <<
    endl;
  cout << "              [<abs. velocity> [<sigthlen>]]]]]]]]]]]" << endl << 
    endl;
 
  cout << " Here <lookback> is  value from -1.0 (360 deg.) to 1.0 (0 deg.)."<<
    endl << endl;
  cout << " Default: <#hunters>=5 <#hares>=2000 <canvas width>=800 " << endl;
  cout << "          <canvas height>" << endl;
  cout << "          �hunter size>=6 <hare size>=1 <lookback>=-1 " << endl;
  cout << "          <hunter angle>=1.0 <hare angle>=5.0 " << endl;
  cout << "          <rel. velocity>=1 <abs. velocity>=2.0 "
    "<sigthlen>=size/2" << endl;
  cout << endl;
  cout << "Options:" << endl;
  cout << "         -p : toggle pictures" << endl;

  exit(0);
}

int main(int argc, char **argv)
{
  int numopt=0, postscript=0;
  while((numopt+1)<argc && argv[numopt+1][0]=='-')
    {
      switch(argv[numopt+1][1])
        {
	case 'p':
	  postscript=1;
	  break;
        case 'h':
        case 'H':
        case '?':
        default:
          usage();
          break;
        }

      numopt++;
    }

  if(argc>=2+numopt)
    sscanf(argv[1+numopt], "%d", &numhunters);

  if(argc>=3+numopt)
    sscanf(argv[2+numopt], "%d", &numhares);

  if(argc>=4+numopt)
    sscanf(argv[3+numopt], "%lf", &size_x);
  sigthlen=size_x/2.0;

  if(argc>=5+numopt)
    sscanf(argv[4+numopt], "%lf", &size_y);

  if(argc>=6+numopt)
    sscanf(argv[5+numopt], "%lf", &huntersize);

  if(argc>=7+numopt)
    sscanf(argv[6+numopt], "%lf", &haresize);

  if(argc>=8+numopt)
    sscanf(argv[7+numopt], "%lf", &lookback);

  if(argc>=9+numopt)
    sscanf(argv[8+numopt], "%lf", &hunterangle);

  if(argc>=10+numopt)
    sscanf(argv[9+numopt], "%lf", &hareangle);

  if(argc>=11+numopt)
    sscanf(argv[10+numopt], "%lf", &relvel);

  if(argc>=12+numopt)
    sscanf(argv[11+numopt], "%lf", &absvel);

  if(argc>=13+numopt)
    sscanf(argv[12+numopt], "%lf", &sigthlen);

  haresin1=sin(2*3.14159*hareangle/360.0); haresin2=-haresin1;
  harecos1=cos(2*3.14159*hareangle/360.0); harecos2=harecos1;

  huntersin1=sin(2*3.14159*hunterangle/360.0); huntersin2=-huntersin1;
  huntercos1=cos(2*3.14159*hunterangle/360.0); huntercos2=huntercos1;

  time_t tm;

  time(&tm);
  long int t=(long int) tm;

  srand48(t);

  swarm1 png(argc, argv, postscript);

  png.Run();

  return 0;
}
