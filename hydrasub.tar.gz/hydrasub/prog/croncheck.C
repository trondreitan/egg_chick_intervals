#include <stdio.h>
#include <hydrabase/divfunc.H>
#include <iostream>
#include <stream.h>

void usage(void)
{
  cout << "Usage: croncheck <cron-updated file> <list of email addresses>" << 
    endl;
  exit(0);
}

void showerr(char *errmsg, char **recipients, int numrec, char *filename)
{
  register int i;

  for(i=0;i<numrec;i++)
    {
      char cmd[1000];
      FILE *p;

      sprintf(cmd, "Mail -s \"%s\" \"%s\"", errmsg, recipients[i]);
      p=popen(cmd, "w");
      
      if(!p)
	{
	  cerr << "Couldn't open mail pipe!" << endl;
	  exit(0);
	}

      fprintf(p,"%s\n",errmsg);
      fprintf(p, "Run 'cron -j 50' and then 'croncheck \"%s\"", filename);
      for(int ii=0;ii<numrec;ii++)
	fprintf(p, " \"%s\"", recipients[ii]);
      fprintf(p, "' again.\n");;

      pclose(p);
    }

  exit(0);
}

int main(int argc, char **argv)
{
  if(argc<3)
    usage();

  FILE *p=popen("ps -ef | grep croncheck | grep -v grep | grep -v emacs", "r");
  if(!p)
    {
      cout << "Couldn't check if croncheck was alive... Exiting!" << endl;
      exit(0);
    }

  ifstream is(fileno(p));
  if(is.fail())
    {
      cout << "Couldn't check if croncheck was alive(2)... Exiting!" << endl;
      exit(0);
    }

  int num=0;
  char buff[1000];

  is.getline(buff,999);
  while(!is.fail() && !is.eof())
    {
      num++;
      is.getline(buff,999);
    }

  if(num>1)
    exit(0);
    
  while(1)
    {
      DateTime *dt=getfiletime(argv[1]), now;

      now.now();

      if(!dt || *dt==NoDateTime)
	showerr("Cron fil not found!", argv+2, argc-2, argv[1]);

      if(now-*dt > 120)
	{
	  FILE *p;
	  
	  p=popen("ps -ef | grep cron | grep root | grep -v croncheck | "
		  "grep -v grep", "r");
	  if(p)
	    {
	      ifstream is(fileno(p));

	      if(!is.fail())
		{
		  int lines=0;
		  char line[100];
		  
		  is.getline(line, 99);
		  while(!is.fail())
		    {
		      lines++;
		      is.getline(line, 99);
		    }

		  if(lines>0)
		    showerr("Cron daemon has been jammed!", argv+2, argc-2, 
			    argv[1]);
		  else
		    showerr("Cron daemon has stopped!", argv+2, argc-2, 
			    argv[1]);
		}
	      else
		showerr("Cron daemon has stopped!", argv+2, argc-2, argv[1]);

	      pclose(p);
	      is.close();
	    }
	  else
	    showerr("Cron daemon has stopped!", argv+2, argc-2, argv[1]);
	}

      sleep(60);
    }
}
