#include <hydrasub/hydragui/histogram.H>
#include <hydrasub/hydrabase/lists.H>

// Fetch stream content and put into an array;
double *fetchstreamcontent(std::istream &in, int &len)
{
  char line[1000]; // line content buffer

  // list head and tail for the content as a linked list;
  valuelist *head=NULL, *tail=NULL;

  // fetch the first line;
  in.getline(line,999);
  while(!in.fail()) // traverse the stream
    {
      double newval; // value content buffer

      // try to fetch the content of the line;
      if(sscanf(line, "%lf", &newval)) 
	{
	  // Insert the new element into the end of the list;
	  tail=new valuelist(tail, NULL, newval);
	  if(!head) // check if the list has been started
	    head=tail; // start the list if not
	}

      // fetch the next line;
      in.getline(line,999);
    }

  if(head) // content has been found
    {
      // fetch the content as an array from the list
      double *valarr=head->getarray(len);
      delete head; // cleanup
      return valarr; // return the array
    }
  else // no content in stream
    {
      // indicate that by the return values;
      len=0;
      return NULL;
    }
}

void usage(void)
{
  std::cout << "Usage: histogramme [options] <input file name>" << std::endl;
  std::cout << "Or   : program | histogramme [options]" << std::endl;
  std::cout << "Gives a histogramme of the input values in a file or from" << 
    std::endl;
  std::cout << "the standard input stream." << std::endl;
  std::cout << "Options:" << std::endl;
  std::cout << "-x <x label>" << std::endl;
  std::cout << "-t <title>" << std::endl;
  exit(0);
}

// Main loop. fetches stream content and show a histogramme
int main(int argc, char **argv)
{
  char xlab[100]="values";
  char title[100]="";

  // check input form:
  while(argc>2 && argv[1][0]=='-')
    {
      switch(argv[1][1])
	{
	case 'x':
	  if(argc<3)
	    usage();
	  strcpy(xlab, argv[2]);
	  argc--;
	  argv++;
	  break;
	case 't':
	  if(argc<3)
	    usage();
 	  strcpy(title, argv[2]);
	  argc--;
	  argv++;
	  break;
	case 'h':
	case '?':
	default:
	  usage();
	  break;
	}

      argc--;
      argv++;
    }
  
  if(argc>2)
    usage();

  int len=0; // length of data array
  double *valarr=NULL; // array containing input value 

  if(argc==2) // fetch from file?
    {
      std::ifstream in;

      // Attempt to open the file
      in.open(argv[1]);
      if(in.fail())
	{
	  std::cout << "Couldn't open file " << argv[1] << std::endl;
	  return 2;
	}

      // fetch file content;
      valarr=fetchstreamcontent(in, len);
      in.close(); // close the file
    }
  else // input froms standard in
    valarr=fetchstreamcontent(std::cin, len); // fetch content from standard in

  // check if any content was fetched;
  if(!valarr || len<=0)
    {
      std::cout << "No values found in the file!" << std::endl;
      return 3;
    }

  // Create a histogram object;
  histogram hs;
  
  char *linestr=new char[1000];

  if(argc==2)
    sprintf(linestr, "file=\"%s\" ", argv[1]);
  else
    strcpy(linestr,"");

  if(*title)
    sprintf(linestr+strlen(linestr), "%s ", title);

  sprintf(linestr+strlen(linestr), "  mean=%f sdev=%f", 
	  find_statistics(valarr,len,MEAN), 
	  find_statistics(valarr,len,STANDARD_DEVIATION)), 
    
  // Create the histogram for the given input values;
  hs.create(&valarr, &len, 1, &linestr, (char *) xlab, (char *) "p", 
	    false, MISSING_VALUE, argc, argv);

  return 0;
}
