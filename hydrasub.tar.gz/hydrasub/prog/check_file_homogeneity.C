#include "check_file_homogeneity.H"
#include <math.h>
#include <hydrabase/divfunc.H>

void ch_button::Create(widget parent, char *txt, check_file_homogeneity *ipt, 
		       CH_ACTION action)
{
  pt=ipt;
  type=action;
  build(parent, txt);
}

void ch_button::pushed(void)
{
  pt->take_action(type);
}


void ch_getfilewindow::Create(check_file_homogeneity *ipt)
{
  pt=ipt;
  sh.build(*ipt, WHAT((char *) "Innhenting av tidsseriefil",
		      (char *) "Choose input time serie file"));
  v1.build(sh);
  build(v1);
  
  sh.Map();
}

void ch_getfilewindow::ok(char *filename)
{
  ifstream in;
  char line[200], linenum=1;

  in.open(filename, ios::in);
  if(in.fail())
    {
      err.build(*pt, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Klarte ikke � �pne fila!", 
		     (char *) "Couldn't open the file!"));
      return;
    }

  timeserielist *head=NULL, *tail=NULL;

  in.getline(line,199);
  while(!in.fail())
    {
      char line2[200], *ptr1=line, *ptr2=line2;
      int firstspc=1;

      for(ptr1=line;*ptr1;ptr1++)
	{
	  if(*ptr1!=':' && *ptr1!='/' && *ptr1!=',' &&
	     (!firstspc || *ptr1!=' ') && (!firstspc || *ptr1!='\t'))
	    {
	      *ptr2=*ptr1;
	      ptr2++;
	    }
	  if(*ptr1!=' ' && *ptr1!='\t')
	    firstspc=0;
	}
      *ptr2='\0';

      if(*line2!='#')
	{
	  int numdigits=0;
	  for(ptr2=line2;*ptr2!='\0' && *ptr2!=' ' && *ptr2!='\r';ptr2++)
	    {
	      if(!isdigit(*ptr2))
		{
		  char errstr[100];
		  sprintf(errstr, 
			  WHAT((char *) "Feil i linje %d - ukjent tegn!",
			       (char *) "Error in line %d - unknown sign!"),
			  linenum);
		  err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
			    errstr);
		  return;
		 }
	      numdigits++;
	    }

	  DateTime dt;
	  if(numdigits<=4)
	    {
	      int year;

	      if(!sscanf(line2,"%d",&year))
		{
		  char errstr[100];
		  sprintf(errstr, 
			  WHAT((char *) "Feil i linje %d - "
			       "klarte ikke � lese �r!",
			       (char *) "Error in line %d - "
			       "couldn't read year!"),
			  linenum);
		  err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
			    errstr);
		  return;
		}

	      if(year<1800)
		year+=2000; // hack

	      DateTime dt2(year,1,1);
	      dt=dt2;
	    }
	  else if(numdigits==6)
	    {
	      int yearmonth;
	      if(!sscanf(line2,"%d",&yearmonth))
		{
		  char errstr[100];
		  sprintf(errstr, 
			  WHAT((char *) "Feil i linje %d - "
			       "klarte ikke � lese �r/m�ned!",
			       (char *) "Error in line %d - "
			       "couldn't read year/month!"),
			  linenum);
		  err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
			    errstr);
		  return;
		}
	      DateTime dt2(yearmonth/100,yearmonth%100,1);
	      dt=dt2;
	    }
	  else if(numdigits==8)
	    {
	      char dtstr2[100];
	      strncpy(dtstr2, line2, 8);
	      strcpy(dtstr2+8, "1200");
	      DateTime dt2(dtstr2);

	      if(!dt2.legal())
		{
		  char errstr[100];
		  sprintf(errstr, 
			  WHAT((char *) "Feil i linje %d - "
			       "ugyldig dato!",
			       (char *) "Error in line %d - "
			       "illegal date!"),
			  linenum);
		  err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
			    errstr);
		  return;
		}

	      dt=dt2;
	    }
	  else if(numdigits==12)
	    {
	      char dtstr2[100];
	      strncpy(dtstr2, line2, 12);
	      strcpy(dtstr2+12, "");
	      DateTime dt2(dtstr2);

	      if(!dt2.legal())
		{
		  char errstr[100];
		  sprintf(errstr, 
			  WHAT((char *) "Feil i linje %d - "
			       "ugyldig dato/tid!",
			       (char *) "Error in line %d - "
			       "illegal date/time!"),
			  linenum);
		  err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
			    errstr);
		  return;
		}

	      dt=dt2;
	    }
	  else
	    {
	      char errstr[100];
	      sprintf(errstr, 
		      WHAT((char *) "Feil i linje %d - "
			   "ugyldig date/tidsformat!",
			   (char *) "Error in line %d - "
			   "unbnown date/time format!"),
		      linenum);
	      err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
			errstr);
	      return;
	    }
	  
	  double value;
	  if(!sscanf(line2+numdigits+1, "%lf", &value))
	    {
	      char errstr[100];
	      sprintf(errstr, 
		      WHAT((char *) "Feil i linje %d - "
			   "fant ingen verdi!",
			   (char *) "Error in line %d - "
			   "no value found!"),
		      linenum);
	      err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
			errstr);
	      return;
	    }
	  
	  tail=new timeserielist(tail, NULL, dt, value);
	  if(!head)
	    head=tail;
	} // if(*line2!='#')

      in.getline(line,199);
      linenum++;
    }

  if(!head)
    {
      err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Ingen tid/verdi-linjer funnet!",
			   (char *) "No time/value lines found!"));
      return;
    }
  
  int i, len;
  double *values=head->getvaluearray(len);
  DateTime *timearray=head->gettimearray(len);

  for(i=1;i<len;i++)
    {
      if(timearray[i-1]>timearray[i])
	{
	  err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Ukronologiske data!",
			   (char *) "Non-chronological data!"));
	  return;
	}
      else if(timearray[i-1]==timearray[i])
	{
	  cout << timearray[i-1].getYear() << endl;
	  err.build(*pt, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Samme tidspunkt funnet to ganger!",
			   (char *) "Same time found to places!"));
	  return;
	}
    }

  pt->set_new_serie(timearray, values, len);

  sh.Unmap();
}

void ch_getfilewindow::cancel(void)
{
  sh.Unmap();
}


void check_file_homogeneity::init(void)
{
  plot=plot2=plot3=NULL;
  origtimes=NULL;
  origvalues=NULL;
  origlen=0;
  startyear=endyear=(int)MISSING_VALUE;
  numyears=0;
  years=NULL;
  yearvalues=NULL;
  met=UNKNOWN_METHOD;
}

void check_file_homogeneity::cleanup(void)
{
  if(origtimes)
    delete [] origtimes;
  if(origvalues)
    delete [] origvalues;
  if(years)
    delete [] years;
  if(yearvalues)
    delete [] yearvalues;
  if(plot)
    delete plot;
  if(plot2)
    delete plot2;
  if(plot3)
    delete plot3;

  init();
}


void check_file_homogeneity::startfetch(void)
{
  infilewin.Create(this);
}

Boolean check_file_homogeneity::aggregate_data(void)
{
  int i;

  // Check if any data has been fetched;
  if(origlen==0 || !origvalues)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Ingen serie innhentet!", 
		     (char *) "No serie fetched!"));
      return False;
    }

  // fetch the statistical method;
  met=selmet.getmethodkey();

  // Fetch the number of years;
  numyears=endyear-startyear+1;
  
  // Make the yearly arrays;
  if(years)
    delete [] years;
  years=new double[numyears];
  if(yearvalues)
    delete [] yearvalues;
  yearvalues=new double[numyears];
  double *yearvaluebuffer=new double[origlen];
  int bufferlen=0;

  // initialize the yearly arrays;
  for(i=0;i<numyears;i++)
    {
      years[i]=(double) (startyear+i);
      yearvalues[i]=MISSING_VALUE;
    }
  
  // yearly aggregation;
  for(i=0;i<origlen;i++)
    {
      int curryear=origtimes[i].getYear();
      
      yearvaluebuffer[bufferlen]=origvalues[i];
      bufferlen++;
	
      if(i==origlen-1 || origtimes[i+1].getYear()!=curryear)
	{
	  int index=curryear-startyear;
	  yearvalues[index]=find_statistics(yearvaluebuffer, bufferlen, 
					    met, 80.0);
	  bufferlen=0;
	}
    }
  
  baymod.set_data(years, yearvalues, numyears);

  return True;
}



void check_file_homogeneity::run_analysis(void)
{
  int i,j;

  if(!aggregate_data())
    return;

  double prior_twostep=prior_twostepf.getdouble()/100.0;
  if(prior_twostep<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Tostegs apriorsannsynlighet kan ikke "
		     "v�re mindre eller lik null!",
		     (char *) "Two step prior probability can not "
		     "be less than or equal to zero!"));
      return;
    }
  if(prior_twostep>=1)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Tostegs apriorsannsynlighet kan ikke "
		     "v�re st�rre eller lik hundre prosent!",
		     (char *) "Two step prior probability can not "
		     "be more than or equal to one hundred percent!"));
      return;
    }

  double prior_homogeneity=priorf.getdouble()/100.0;
  if(prior_homogeneity<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Homogen apriorsannsynlighet kan ikke "
		     "v�re mindre eller lik null!",
		     (char *) "Homogen prior probability can not "
		     "be less than or equal to zero!"));
      return;
    }
  if(prior_homogeneity>=1)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Homogen apriorsannsynlighet kan ikke "
		     "v�re st�rre eller lik hundre prosent!",
		     (char *) "Homogen prior probability can not "
		     "be more than or equal to one hundred percent!"));
      return;
    }

  double prior_linear=prior_linf.getdouble()/100.0;
  if(prior_linear<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"), 
		WHAT((char *) "Line�r apriorsannsynlighet kan ikke v�re mindre "
		     "eller lik null!",
		     (char *) "Linear prior probability can not "
		     "be less than or equal to zero!"));
      return;
    }
  if(prior_linear>=1)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Line�r apriorsannsynlighet kan ikke v�re st�rre "
		     "eller lik hundre prosent!",
		     (char *) "Linear prior probability can not "
		     "be more than or equal to one hundred percent!"));
      return;
    }

  double prior_quadratic=prior_quadf.getdouble()/100.0;
  if(prior_quadratic<=0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kvadratisk apriorsannsynlighet kan ikke "
		     "v�re mindre eller lik null!",
		     (char *) "Quadratic prior probability can not "
		     "be less than or equal to zero!"));
      return;
    }
  if(prior_quadratic>=1)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Kvadratisk apriorsannsynlighet kan "
		     "ikke v�re st�rre eller lik hundre prosent!",
		     (char *) "Quadratic prior probability can not "
		     "be more than or equal to one hundred percent!"));
      return;
    }

  if(prior_homogeneity+prior_linear+prior_quadratic+prior_twostep>=1.0)
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Homogen+line�r+kvadratisk+tostegs "
		     "apriorsannsynlighet kan ikke v�re st�rre eller "
		     "lik hundre prosent!\n(Husk � reservere litt sannsynlighet"
		     "til ett-stegs-hypotesen.)",
		     (char *) "Homogen+linear+quadratic+two step "
		     "prior probability can no be greater than or equal to "
		     "one hundred percent!\n(Remember to reserve some "
		     "probability to the one step models.)"));
      return;
    }

  baymod.calculate_aposteriori(prior_homogeneity,prior_linear, 
					 prior_quadratic,prior_twostep);
  
  double total_onestep=baymod.full_step_model_probability();
  double total_twostep=baymod.full_twostep_probability();
  double meanyear=baymod.get_mean_year();

  result.Clear();
  char strbuffer[1000];
  sprintf(strbuffer,
	  WHAT((char *) "Sannsynlighet for homogenitet: %9.5g %%\n", 
	       (char *) "Probability for homogeneity: %9.5g %%\n"),
	  baymod.homogeneity_probability()*100.0);
  result+=strbuffer;
  sprintf(strbuffer,
	  WHAT((char *) "Homogen verdi: %7.3lf, kredibilitetsintervall: "
	       "%7.3lf - %7.3lf",
	       (char *) "Homogen value: %7.3lf, credibility interval: "
	       "%7.3lf - %7.3lf"),
	       baymod.homogeneity_mean(),
	       baymod.homogeneity_lower(0.95), 
	       baymod.homogeneity_upper(0.95));
  result+=strbuffer;
  sprintf(strbuffer,WHAT((char *) " st�y:  %7.3lf\n\n", 
			 (char *) " noise: %7.3lf\n\n"), 
			 baymod.homogeneity_sdev());
  result+=strbuffer;
  


  sprintf(strbuffer, WHAT((char *) "Sannsynlighet for sprang: %9.5g %%\n", 
			  (char *) "Probability for one step: %9.5g %%\n"), 
	  baymod.full_step_model_probability()*100.0);
  result+=strbuffer;
  sprintf(strbuffer,WHAT((char *) "Gitt sprang, mest sannsynlige sprang ved "
			 "overgangen %d til %d (%9.5g%%)\n",
			 (char *) "Given one step, most probable transition by "
			 "%d to %d (%9.5g%%)\n"), 
		 baymod.year_maxprob_before_step(),
		 baymod.year_maxprob_after_step(),
		 baymod.maxprob_step_probability()*100.0/
		 baymod.full_step_model_probability());
  result+=strbuffer;
  sprintf(strbuffer,
	  WHAT((char *) "%d-%d: %7.3lf (%7.3lf-%7.3lf)\n"
		 "%d-%d: %7.3lf (%7.3lf-%7.3lf) st�y:%7.3lf\n",
	       (char *) "%d-%d: %7.3lf (%7.3lf-%7.3lf)\n"
		 "%d-%d: %7.3lf (%7.3lf-%7.3lf) noise:%7.3lf\n"),
		 baymod.get_start_year(),
		 baymod.year_maxprob_before_step(),
		 baymod.maxprob_step_mean_before(),
		 baymod.maxprob_step_lower_before(0.95),
		 baymod.maxprob_step_upper_before(0.95),
		 baymod.year_maxprob_after_step(),
		 baymod.get_end_year(),
		 baymod.maxprob_step_mean_after(),
		 baymod.maxprob_step_lower_after(0.95),
		 baymod.maxprob_step_upper_after(0.95),
		 baymod.maxprob_step_sdev());
  result+=strbuffer;

  result+="\n";
  sprintf(strbuffer,
	  WHAT((char *) "Sannsynlighet for line�r trend: %9.5g %%\n"
	       "  (Q=exp(%7.3lf + %7.5lf(t-%7.3lf)), st�y:%7.3lf\n",
	       (char *) "Probability for linear trend: %9.5g %%\n"
	       "  (Q=exp(%7.3lf + %7.5lf(t-%7.3lf)), noise:%7.3lf\n"),  
		 baymod.linear_probability()*100.0,
		 baymod.linear_mean_intercept(), baymod.linear_mean_slope(),
		 meanyear, baymod.linear_sdev());
  result+=strbuffer;

  sprintf(strbuffer,
	  WHAT((char *) "Sannsynlighet for kvadratisk trend: %9.5g %%\n"
	       " (Q=exp(%7.3lf + %7.5lf(t-%7.3lf) + %7.5lf(t-%7.3lf)�), "
	       "st�y:%7.3lf\n\n", 
	       (char *) "Probability for quadratic trend: %9.5g %%\n"
	       " (Q=exp(%7.3lf + %7.5lf(t-%7.3lf) + %7.5lf(t-%7.3lf)�), "
	       "noise:%7.3lf\n\n"), 
		 baymod.quadratic_probability()*100.0,		 
		 baymod.quadratic_mean_intercept(), 
		 baymod.quadratic_mean_slope(), meanyear,
		 baymod.quadratic_mean_curvature(), meanyear,
		 baymod.linear_sdev());
  result+=strbuffer;
  
  sprintf(strbuffer,
	  WHAT((char *) "Sannsynlighet for to-stegs-sprang: %9.5g %%\n",
	       (char *) "Probability for two-step model: %9.5g %%\n"),
		 baymod.full_twostep_probability()*100.0);
  result+=strbuffer;
  sprintf(strbuffer,
	  WHAT((char *) "Gitt to sprang, mest sannsynlige sprang ved "
		 "overgangen %d/%d og %d/%d (%9.5g%%)\n", 
	       (char *) "Given two speps, most probable transitions by "
		 "%d/%d and %d/%d (%9.5g%%)\n"), 
		 baymod.year_maxprob_twostep_before_step1(),
		 baymod.year_maxprob_twostep_after_step1(),
		 baymod.year_maxprob_twostep_before_step2(),
		 baymod.year_maxprob_twostep_after_step2(),
		 baymod.maxprob_twostep_probability()*100.0/
		 baymod.full_twostep_probability());
  result+=strbuffer;
  sprintf(strbuffer,
	  WHAT((char *) "%d-%d: %7.3lf (%7.3lf-%7.3lf)\n"
		 "%d-%d: %7.3lf (%7.3lf-%7.3lf)\n"
		 "%d-%d: %7.3lf (%7.3lf-%7.3lf) st�y:%7.3lf\n",
	       (char *) "%d-%d: %7.3lf (%7.3lf-%7.3lf)\n"
		 "%d-%d: %7.3lf (%7.3lf-%7.3lf)\n"
		 "%d-%d: %7.3lf (%7.3lf-%7.3lf) noise:%7.3lf\n"),
		 baymod.get_start_year(),
		 baymod.year_maxprob_twostep_before_step1(),
		 baymod.maxprob_twostep_mean_before1(),
		 baymod.maxprob_twostep_lower_before1(0.95),
		 baymod.maxprob_twostep_upper_before1(0.95),
		 baymod.year_maxprob_twostep_after_step1(),
		 baymod.year_maxprob_twostep_before_step2(),
		 baymod.maxprob_twostep_mean_after1(),
		 baymod.maxprob_twostep_lower_after1(0.95),
		 baymod.maxprob_twostep_upper_after1(0.95),
		 baymod.year_maxprob_twostep_after_step2(),
		 baymod.get_end_year(),
		 baymod.maxprob_twostep_mean_after2(),
		 baymod.maxprob_twostep_lower_after2(0.95),
		 baymod.maxprob_twostep_upper_after2(0.95),
		 baymod.maxprob_twostep_sdev());
  result+=strbuffer;
  result+="\n";

  boolean done_homogen=b_false, done_step=b_false, done_maxprob_step=b_false,
    done_lin=b_false, done_quad=b_false, done_twostep=b_false, 
    done_maxprob_twostep=b_false;
  
  char line[100];
  resultlist.Clear();
  while(!done_homogen || !done_step || !done_maxprob_step || 
	!done_lin || !done_quad || !done_twostep || !done_maxprob_twostep)
    {
      if(!done_homogen &&
	 (done_step || baymod.homogeneity_probability()>total_onestep) &&
	 (done_twostep || baymod.homogeneity_probability()>total_twostep) &&
	 (done_maxprob_step || 
	  baymod.homogeneity_probability()>baymod.maxprob_step_probability()) &&
	 (done_maxprob_twostep || 
	  baymod.homogeneity_probability()>
	  baymod.maxprob_twostep_probability()) &&
	 (done_lin || 
	  baymod.homogeneity_probability()>baymod.linear_probability()) &&
	 (done_quad || 
	  baymod.homogeneity_probability()>baymod.quadratic_probability()))
	{
	  sprintf(line, WHAT((char *) "Homogen: %7.3lf%%",  
			     (char *) "Homogeneity: %7.3lf%%"),  
		  baymod.homogeneity_probability()*100.0);
	  resultlist.Insert(line);
	  done_homogen=b_true;
	}

      if(!done_step &&
	 (done_homogen || total_onestep>baymod.homogeneity_probability()) &&
	 (done_twostep || total_onestep>total_twostep) &&
	 (done_maxprob_step || 
	  total_onestep>=baymod.maxprob_step_probability()) &&
	 (done_maxprob_twostep || 
	  total_onestep>baymod.maxprob_twostep_probability()) &&
	 (done_lin || total_onestep>baymod.linear_probability()) &&
	 (done_quad || total_onestep>baymod.quadratic_probability()))
	{
	  sprintf(line, WHAT((char *) "Sprang: %7.3lf%%", 
			     (char *) "One step: %7.3lf%%"), 
		  total_onestep*100.0);
	  resultlist.Insert(line);
	  done_step=b_true;
	}

      if(!done_maxprob_step &&
	 (done_homogen || 
	  baymod.maxprob_step_probability()>baymod.homogeneity_probability()) &&
	 (done_step || baymod.maxprob_step_probability()>total_onestep) &&
	 (done_twostep || baymod.maxprob_step_probability()>total_twostep) &&
	 (done_maxprob_twostep || 
	  baymod.maxprob_step_probability()>
	  baymod.maxprob_twostep_probability()) &&
	 (done_lin || 
	  baymod.maxprob_step_probability()>baymod.linear_probability()) &&
	 (done_quad || 
	  baymod.maxprob_step_probability()>baymod.quadratic_probability()))
	{
	  sprintf(line, 
		  WHAT((char *) "Maks sprang: %7.3lf%% (%d-%d)", 
		       (char *) "Max one step: %7.3lf%%(%d-%d)"),
		  baymod.maxprob_step_probability()*100.0,
		  baymod.year_maxprob_before_step(),
		  baymod.year_maxprob_after_step());
	  resultlist.Insert(line);
	  done_maxprob_step=b_true;
	}

      if(!done_twostep &&
	 (done_homogen || total_twostep>baymod.homogeneity_probability()) &&
	 (done_step || total_twostep>total_onestep) &&
	 (done_maxprob_step || 
	  total_twostep>baymod.maxprob_step_probability()) &&
	 (done_maxprob_twostep || 
	  total_twostep>=baymod.maxprob_twostep_probability()) &&
	 (done_lin || total_twostep>baymod.linear_probability()) &&
	 (done_quad || total_twostep>baymod.quadratic_probability()))
	{
	  sprintf(line, WHAT((char *) "2sprang: %7.3lf%%",
			     (char *) "2 step : %7.3lf%%"), 
		  total_twostep*100.0);
	  resultlist.Insert(line);
	  done_twostep=b_true;
	}

      if(!done_maxprob_twostep &&
	 (done_homogen || 
	  baymod.maxprob_twostep_probability()>
	  baymod.homogeneity_probability()) &&
	 (done_step || baymod.maxprob_twostep_probability()>total_onestep) &&
	 (done_twostep || 
	  baymod.maxprob_twostep_probability()>total_twostep) &&
	 (done_maxprob_step || 
	  baymod.maxprob_twostep_probability()>
	  baymod.maxprob_step_probability()) &&
	 (done_lin || 
	  baymod.maxprob_twostep_probability()>baymod.linear_probability()) &&
	 (done_quad || 
	  baymod.maxprob_twostep_probability()>baymod.quadratic_probability()))
	{
	  sprintf(line, WHAT((char *) "M2sprang: %7.3lf%% (%d,%d)", 
			     (char *) "Max 2step: %7.3lf%%(%d,%d)"), 
		  baymod.maxprob_twostep_probability()*100.0,
		  baymod.year_maxprob_twostep_before_step1(),
		  baymod.year_maxprob_twostep_after_step2());
	  resultlist.Insert(line);
	  done_maxprob_twostep=b_true;
	}

      if(!done_lin &&
	 (done_homogen || 
	  baymod.linear_probability()>baymod.homogeneity_probability()) &&
	 (done_step || baymod.linear_probability()>total_onestep) &&
	 (done_twostep || baymod.linear_probability()>total_twostep) &&
	 (done_maxprob_step || 
	  baymod.linear_probability()>baymod.maxprob_step_probability()) &&
	 (done_maxprob_twostep || 
	  baymod.linear_probability()>baymod.maxprob_twostep_probability()) &&
	 (done_quad || 
	  baymod.linear_probability()>baymod.quadratic_probability()))
	{
	  sprintf(line, WHAT((char *) "Line�r: %7.3lf%%", 
			     (char *) "Linear: %7.3lf%%"), 
		  baymod.linear_probability()*100.0);
	  resultlist.Insert(line);
	  done_lin=b_true;
	}

      if(!done_quad &&
	 (done_homogen || 
	  baymod.quadratic_probability()>baymod.homogeneity_probability()) &&
	 (done_step || baymod.quadratic_probability()>total_onestep) &&
	 (done_twostep || baymod.quadratic_probability()>total_twostep) &&
	 (done_maxprob_step || 
	  baymod.quadratic_probability()>baymod.maxprob_step_probability()) &&
	 (done_maxprob_twostep || 
	  baymod.quadratic_probability()>
	  baymod.maxprob_twostep_probability()) &&
	 (done_lin || 
	  baymod.quadratic_probability()>baymod.linear_probability()))
	{
	  sprintf(line, WHAT((char *) "Kvadratisk: %7.3lf%%", 
			     (char *) "Quadratic : %7.3lf%%"), 
		  baymod.quadratic_probability()*100.0);
	  resultlist.Insert(line);
	  done_quad=b_true;
	}
    }

  resultlist.Mark(1);
}


void check_file_homogeneity::do_plot_timeserie(void)
{
  if(!baymod.has_been_calculated())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Analysen har ikke blitt kj�rt!",
		     (char *) "The analysis has not been done yet!"));
      return;
    }

  double *post=baymod.fetch_aposteriori_model_probabilities();
  double total_onestep=baymod.full_step_model_probability();
  double total_twostep=baymod.full_twostep_probability();
  double maxprob=baymod.maxprob_step_probability();
  double *years=baymod.getyears();
  int maxindex=baymod.get_maxprob_onestep_index();
  int maxindex1=baymod.get_maxprob_twostep_index_1();
  int maxindex2=baymod.get_maxprob_twostep_index_2();
  int start=baymod.get_start_year();
  int end=baymod.get_end_year();
  int numyears=baymod.get_num_years();
  bayesian_regression **regresult=baymod.get_regressions();
  bayesian_regression ***twostep_regresult=
    baymod.get_twostep_regressions();
  double **twostep_post=baymod.get_two_step_probabilities();
  
  char **listitems;
  int *pos, numseries, numlist;
  Boolean showcred=show_credibility();
  int multinum = showcred ? 3 : 1;
  int numsel=resultlist.Selected(&pos);
  
  numlist=resultlist.Get(&listitems);
  numseries=1+multinum*numsel;
  
  int i,j,k;
  double **arg=new double*[numseries], **val=new double*[numseries];
  char **linetitles=new char*[numseries], **axistitles=new char*[2];
  int *axis=new int[numseries], *len=new int[numseries];
  PLOTLINE_TYPE *type=new PLOTLINE_TYPE[numseries];
  char *lines[8]={"", WHAT((char *) "Homogen modell", (char *) "Homogeneity"),
		  WHAT((char *) "Mest sannsynlige modell med sprang",
		       (char *) "Most probable model with one step"),
		  WHAT((char *) "Sum prediksjon for modeller med sprang",
		       (char *) "Sum prediction for models with one step"),
		  WHAT((char *) "Line�r modell", (char *) "Linear model"), 
		  WHAT((char *) "Kvadratisk modell",(char *) "Quadratic model"),
		  WHAT((char *) "Mest sanns. modell med to sprang",
		       (char *) "Most prob. model with two steps"),
		  WHAT((char *) "Sum prediksjon for modeller med to sprang",
		       (char *) "Sum prediction for models with two steps")};
  double *yearvalues=baymod.get_year_values();
  double meanyear=baymod.get_mean_year();

  axistitles[0]=new char[100];
  axistitles[1]=new char[100];
  strcpy(axistitles[0], WHAT((char *) "Tid", (char *) "Time"));
  strcpy(axistitles[1], WHAT((char *) "Verdi", (char *) "Value"));
  
  for(i=0;i<numseries;i++)
    {
      linetitles[i]=new char[200];
      strcpy(linetitles[i], lines[i]);
      type[i]=PLOTLINE_LINE;
      axis[i]=1;
      len[i]=numyears;
      arg[i]=years;
      val[i]=new double[numyears];
    }
  
  sprintf(linetitles[0], WHAT((char *) "%s (�rlig)","%s (yearly)"),
	  Get_method_name(met));
  type[0]=PLOTLINE_DOT;
  
  for(k=1;k<numsel+1;k++)
    {
      char buffer[100];

      if(!strncmp(listitems[pos[k-1]-1], WHAT((char *) "Homogen",
					      (char *) "Homogeneity"),
		  WHAT(7,10)))
	strcpy(buffer, lines[1]);
      else if(!strncmp(listitems[pos[k-1]-1], WHAT((char *) "Sprang",
						   (char *) "One step"), 
		       WHAT(6, 8)))
	strcpy(buffer, lines[3]);
      else if(!strncmp(listitems[pos[k-1]-1], WHAT((char *) "Maks sprang",
						   (char *) "Max one step"),
		       WHAT(11,12)))
	strcpy(buffer, lines[2]);
      else if(!strncmp(listitems[pos[k-1]-1], WHAT((char *) "Line�r", 
						   (char *) "Linear"), 
		       WHAT(6,6)))
	strcpy(buffer, lines[4]);
      else if(!strncmp(listitems[pos[k-1]-1], WHAT((char *) "Kvadratisk",
						   (char *) "Quadratic"),
		       WHAT(10,9)))
	strcpy(buffer, lines[5]);
      else if(!strncmp(listitems[pos[k-1]-1], WHAT((char *) "2sprang",
						   (char *) "2 step"),
		       WHAT(7,6)))
	strcpy(buffer, lines[7]);
      else if(!strncmp(listitems[pos[k-1]-1], WHAT((char *) "M2sprang",
						   (char *) "Max 2step"),
		       WHAT(8,9)))
	strcpy(buffer, lines[6]);
      else
	{
	  cout << (WHAT((char *) "Ukjent menyvalg:",
			(char *) "Unknwon menu item:")) << 
	    listitems[pos[k-1]-1] << endl;
	  exit(0);
	}

      if(!showcred)
	strcpy(linetitles[k], buffer);
      else
	{
	  strcpy(linetitles[3*k-2], buffer);
	  sprintf(linetitles[3*k-1], 
		  WHAT((char *) "%s Nedre 95%% troverdighetsgrense", 
		       (char *) "%s Lower 95%% credibility limit"), 
		  buffer);
	  sprintf(linetitles[3*k], 
		  WHAT((char *) "%s �vre 95%% troverdighetsgrense", 
		       (char *) "%s Upper 95%% credibility limit"), 
		  buffer);
	}
    }

  for(i=0;i<numyears;i++)
    {
      val[0][i]=yearvalues[i];

      for(k=1;k<numsel+1;k++)
	{
	  if(!strncmp(listitems[pos[k-1]-1], 
		      WHAT((char *) "Homogen",
			   (char *) "Homogeneity"),
		      WHAT(7,10)))
	    {
	      if(!showcred)
		val[k][i]=exp(regresult[0]->get_mean_coefficient(0));
	      else
		{
		  val[3*k-2][i]=exp(regresult[0]->get_mean_coefficient(0));
		  val[3*k-1][i]=exp(regresult[0]->
				    lower_coefficient_credibility(0,0.95));
		  val[3*k][i]=exp(regresult[0]->		  
				  upper_coefficient_credibility(0,0.95));
		}
	    }
	  else if(!strncmp(listitems[pos[k-1]-1], 
			   WHAT((char *) "Sprang", 
				(char *) "One step"), 
			   WHAT(6,8)))
	    {
	      double buffer=0.0, upper=0.0, lower=0.0;

	      for(j=1;j<numyears;j++)
		{
		  buffer += post[j]/total_onestep *
		  (i<j ? 
		   exp(regresult[j]->get_mean_coefficient(0)) :
		   exp(regresult[j]->get_mean_coefficient(1)));

		  if(showcred)
		    {
		      lower += post[j]/total_onestep* 
			(i<j ? 
			 exp(regresult[j]->
			     lower_coefficient_credibility(0,.95)) :
			 exp(regresult[j]->
			     lower_coefficient_credibility(1,.95)));
		      
		      upper += post[j]/total_onestep* 
			(i<j ? 
			 exp(regresult[j]->
			     upper_coefficient_credibility(0,.95)) :
			 exp(regresult[j]->
			     upper_coefficient_credibility(1,.95)));
		    }
		}

	      if(!showcred)
		val[k][i]=buffer;
	      else
		{
		  val[3*k-2][i]=buffer;
		  val[3*k-1][i]=lower;
		  val[3*k][i]=upper;
		}
	    }
	  else if(!strncmp(listitems[pos[k-1]-1], 
			   WHAT((char *) "Maks sprang",
				(char *) "Max one step"),
			   WHAT(11,12)))
	    {
	      if(!showcred)
		val[k][i] = i<maxindex ? 
		  exp(regresult[maxindex]->get_mean_coefficient(0)) :
		exp(regresult[maxindex]->get_mean_coefficient(1));
	      else
		{
		  val[3*k-2][i] = i<maxindex ? 
		    exp(regresult[maxindex]->get_mean_coefficient(0)) :
		    exp(regresult[maxindex]->get_mean_coefficient(1));

		  val[3*k-1][i] = i<maxindex ? 
		    exp(regresult[maxindex]->
			lower_coefficient_credibility(0, 0.95)) :
		    exp(regresult[maxindex]->
			lower_coefficient_credibility(1, 0.95));

		  val[3*k][i] = i<maxindex ? 
		    exp(regresult[maxindex]->
			upper_coefficient_credibility(0, 0.95)) :
		    exp(regresult[maxindex]->
			upper_coefficient_credibility(1, 0.95));
		}
	    }
	  else if(!strncmp(listitems[pos[k-1]-1], 
			   WHAT((char *) "2sprang", 
				(char *) "2 step"),
			   WHAT(7,6)))
	    {
	      double buffer=0.0, lower=0.0, upper=0.0;

	      for(int l=1;l<numyears-1;l++)
		for(j=l+1;j<numyears;j++)
		  {
		    if(i<l)
		      {
			buffer += twostep_post[l-1][j-l-1]/total_twostep*
			  exp(twostep_regresult[l-1][j-l-1]->
			      get_mean_coefficient(0));
			if(showcred)
			  {
			    lower += twostep_post[l-1][j-l-1]/total_twostep* 
			      exp(twostep_regresult[l-1][j-l-1]->
				  lower_coefficient_credibility(0, 0.95));
			    upper += twostep_post[l-1][j-l-1]/total_twostep* 
			      exp(twostep_regresult[l-1][j-l-1]->
				  upper_coefficient_credibility(0, 0.95));
			  }
		      }
		    else if(i<j)
		      {
			buffer += twostep_post[l-1][j-l-1]/total_twostep* 
			  exp(twostep_regresult[l-1][j-l-1]->
			      get_mean_coefficient(1));
			if(showcred)
			  {
			    lower += twostep_post[l-1][j-l-1]/total_twostep* 
			      exp(twostep_regresult[l-1][j-l-1]->
				  lower_coefficient_credibility(1, 0.95));
			    upper += twostep_post[l-1][j-l-1]/total_twostep* 
			      exp(twostep_regresult[l-1][j-l-1]->
				  upper_coefficient_credibility(1, 0.95));
			  }
		      }
		    else
		      {
			buffer += twostep_post[l-1][j-l-1]/total_twostep* 
			  exp(twostep_regresult[l-1][j-l-1]->
			      get_mean_coefficient(2));
			if(showcred)
			  {
			    lower += twostep_post[l-1][j-l-1]/total_twostep* 
			      exp(twostep_regresult[l-1][j-l-1]->
				  lower_coefficient_credibility(2, 0.95));
			    upper += twostep_post[l-1][j-l-1]/total_twostep* 
			      exp(twostep_regresult[l-1][j-l-1]->
				  upper_coefficient_credibility(2, 0.95));
			  }
		      }
		  }

	      if(!showcred)
		val[k][i] = buffer;
	      else
		{
		  val[3*k-2][i]=buffer;
		  val[3*k-1][i]=lower;
		  val[3*k][i]=upper;
		}
	    }
	  else if(!strncmp(listitems[pos[k-1]-1], 
			   WHAT((char *) "M2sprang",
				(char *) "Max 2step"),
				WHAT(8,9)))
	    {
	      int l=maxindex1-1;
	      j=maxindex2-maxindex1-1;

	      double upper,lower;
	      double buffer = i<maxindex1 ? 
		exp(twostep_regresult[l][j]->get_mean_coefficient(0)) :
		(i<maxindex2 ? 
		 exp(twostep_regresult[l][j]->get_mean_coefficient(1)) :
		 exp(twostep_regresult[l][j]->get_mean_coefficient(2)));

	      if(showcred)
		{
		  lower = i<maxindex1 ? 
		    exp(twostep_regresult[l][j]->
			lower_coefficient_credibility(0, 0.95)) :
		    (i<maxindex2 ? 
		     exp(twostep_regresult[l][j]->
			 lower_coefficient_credibility(1, 0.95)) :
		     exp(twostep_regresult[l][j]->
			 lower_coefficient_credibility(2, 0.95)));
		  
		  upper = i<maxindex1 ? 
		    exp(twostep_regresult[l][j]->
			upper_coefficient_credibility(0, 0.95)) :
		    (i<maxindex2 ? 
		     exp(twostep_regresult[l][j]->
			 upper_coefficient_credibility(1, 0.95)) :
		     exp(twostep_regresult[l][j]->
			 upper_coefficient_credibility(2, 0.95)));
		}

	      if(!showcred)
		val[k][i] = buffer;
	      else
		{
		  val[3*k-2][i]=buffer;
		  val[3*k-1][i]=lower;
		  val[3*k][i]=upper;
		}
	    }
	  else if(!strncmp(listitems[pos[k-1]-1], 
			   WHAT((char *) "Line�r",
				(char *) "Linear"),
			   WHAT(6,6)))
	    {
	      double pred[]={1,1};
	      pred[1]=years[i]-meanyear;

	      double upper,lower;
	      double buffer=exp(regresult[numyears]->predict(pred));

	      if(showcred)
		{
		  lower=exp(regresult[numyears]->
			    lower_estimate_credibility(pred, 0.95));
		  upper=exp(regresult[numyears]->
			    upper_estimate_credibility(pred, 0.95));
		}

	      if(!showcred)
		val[k][i] = buffer;
	      else
		{
		  val[3*k-2][i]=buffer;
		  val[3*k-1][i]=lower;
		  val[3*k][i]=upper;
		}
	    }
	  else if(!strncmp(listitems[pos[k-1]-1], 
			   WHAT((char *) "Kvadratisk",
				(char *) "Quadratic"),
			   WHAT(10,9)))
	    {
	      double pred[]={1,1,1};
	      pred[1]=years[i]-meanyear;
	      pred[2]=(years[i]-meanyear)*(years[i]-meanyear);

	      double upper,lower;
	      double buffer=exp(regresult[numyears+1]->get_mean_coefficient(0)+
				regresult[numyears+1]->get_mean_coefficient(1)*
				(years[i]-meanyear));
	      buffer=exp(regresult[numyears+1]->predict(pred));

	      if(showcred)
		{
		  lower=exp(regresult[numyears+1]->
			    lower_estimate_credibility(pred, 0.95));
		  upper=exp(regresult[numyears+1]->
			    upper_estimate_credibility(pred, 0.95));
		}

	      if(!showcred)
		val[k][i] = buffer;
	      else
		{
		  val[3*k-2][i]=buffer;
		  val[3*k-1][i]=lower;
		  val[3*k][i]=upper;
		}
	    }
	  else
	    {
	      cout << (WHAT((char *) "Ukjent menyvalg:",
			    (char *) "Unknwon menu item:")) << 
		listitems[pos[k-1]-1] << endl;
	      exit(0);
	    }

/*
  val[k][i]=exp(regresult[numyears]->get_mean_coefficient(0)+
  regresult[numyears]->get_mean_coefficient(1)*
  (years[i]-meanyear));
  val[k][i]=exp(regresult[numyears+1]->get_mean_coefficient(0)+
  regresult[numyears+1]->get_mean_coefficient(1)*
  (years[i]-meanyear)+
  regresult[numyears+1]->get_mean_coefficient(2)*
  (years[i]-meanyear)*(years[i]-meanyear));
*/
	}
    }

  if(plot)
    delete plot;
  plot=new plot_module();
  plot->Create(arg,val,len,axis,linetitles,numseries,axistitles,2,NULL,type);
}


void check_file_homogeneity::do_plot_aposteriori(void)
{
  if(!baymod.has_been_calculated())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Analysen har ikke blitt kj�rt!",
		     (char *) "The analysis has not been done yet!"));
      return;
    }

  double *post=baymod.fetch_aposteriori_model_probabilities();
  double total_onestep=baymod.full_step_model_probability();
  double total_twostep=baymod.full_twostep_probability();
  double maxprob=baymod.maxprob_step_probability();
  double *years=baymod.getyears();
  int maxindex=baymod.get_maxprob_onestep_index();
  int start=baymod.get_start_year();
  int end=baymod.get_end_year();
  int numyears=baymod.get_num_years();
  bayesian_regression **regresult=baymod.get_regressions();

  int len=numyears-1;
  double *arg=years+1, *val=new double[len];
  int axis=1;
  PLOTLINE_TYPE type=PLOTLINE_FILLEDBARS;
  char *linetitle=new char[100], **axistitle=new char*[2];

  for(int i=1;i<numyears;i++)
    val[i-1]=post[i]*100.0/total_onestep;

  axistitle[0]=new char[100];
  strcpy(axistitle[0], WHAT((char *) "�r", (char *) "year"));
  axistitle[1]=new char[100];
  strcpy(axistitle[1], WHAT((char *) "% sanns. for sprang",
			    (char *) "% prob. for one step"));

  sprintf(linetitle, 
	  WHAT((char *) "Sannsynlighet (%%) for sprang p� spesifikt �r (gitt "
	       "at det er sprang) i %d-%d",
	       (char *) "Probability (%%) for one step on spesific year (given "
	       "that there is a step in %d-%d"), start, end);

  if(plot2)
    delete plot2;
  plot2=new plot_module();
  plot2->set_grid(True);
  plot2->Create(&arg, &val, &len, &axis, &linetitle, 1,
	       axistitle, 2, NULL, &type);

  delete [] val;
  doubledelete(axistitle,2);
  delete [] linetitle;
}

static boolean twostep_log;
static int twostep_startyear,twostep_endyear, twostep_num_years;
static double **twostep_posterior;
double find_twostep_posterior(double year1, double year2)
{
  int yr1=(int) year1, yr2=(int) year2;

  if(yr1>=yr2)
    return MISSING_VALUE;
  
  int index1=yr1-twostep_startyear, index2=yr2-twostep_startyear, i,j;

  i=index1-1;
  j=index2-index1-1;

  if(i<0 || i>twostep_num_years-2)
    return MISSING_VALUE;
  if(j<0 || j>twostep_num_years-i-2)
    return MISSING_VALUE;

  if(twostep_log)
    {
      if(twostep_posterior[i][j]>0)
	return log(twostep_posterior[i][j]);
      else
	return MISSING_VALUE;
    }
  else
    return twostep_posterior[i][j];
}

void check_file_homogeneity::do_plot_twostep_aposteriori(void)
{
  if(!baymod.has_been_calculated())
    {
      err.build(*this, WHAT((char *) "Feil", (char *) "Error"),
		WHAT((char *) "Analysen har ikke blitt kj�rt!",
		     (char *) "The analysis has not been done yet!"));
      return;
    }

  int start=baymod.get_start_year();
  int end=baymod.get_end_year();
  int numyears=baymod.get_num_years();
  double **twostep_post=baymod.get_two_step_probabilities();

  char xaxis[100];
  sprintf(xaxis, WHAT((char *) "Steg 1", (char *) "Step 1"));

  mess.build(*this, WHAT((char *) "Sp�rsm�l:",
			 (char *) "Question:"), 
	     WHAT((char *) "Logaritmisk sannsynlighet?",
		  (char *) "Logarithmic probability?"));
  if(mess.ok_or_cancel(WHAT((char *) "Ja", (char *) "Yes"),
		       WHAT((char *) "Nei", (char *) "No")))
    twostep_log=b_true;
  else
    twostep_log=b_false;

  twostep_startyear=start;
  twostep_endyear=end;
  twostep_posterior=twostep_post;
  twostep_num_years=numyears;

  if(plot3)
    delete plot3;
  plot3=new plot_module();
  plot3->Create(find_twostep_posterior, start, start, end, end, 
	       xaxis, WHAT((char *) "Steg 2", (char *) "Step 2"));
}


void check_file_homogeneity::take_action(CH_ACTION action)
{
  switch(action)
    {
    case CH_STARTFETCH:
      startfetch();
      break;
    case CH_RUN:
      run_analysis();
      break;
    case CH_EXIT:
      exit(0);
      break;
    case CH_PLOT_POSTERIORI:
      do_plot_aposteriori();
      break;
    case CH_PLOT_TWOSTEP_POSTERIORI:
      do_plot_twostep_aposteriori();
      break;
    case CH_PLOT_TIMESERIE:
      do_plot_timeserie();
      break;
    }
}

void check_file_homogeneity::set_new_serie(DateTime *timearray, 
				     double *values, int len)
{
  origlen=len;
  if(origtimes)
    delete [] origtimes;
  origtimes=new DateTime[origlen];
  if(origvalues)
    delete [] origvalues;
  origvalues=new double[origlen];

  for(int i=0;i<len;i++)
    {
      origvalues[i]=values[i];
      origtimes[i]=timearray[i];
    }

  startyear=origtimes[0].getYear();
  endyear=origtimes[origlen-1].getYear();
  
  serielab.labelString("%d-%d", startyear, endyear);
}

check_file_homogeneity::check_file_homogeneity(int argc, char **argv) :
  mainwin("check_file_homogeneity", argc, argv)
{
  init();

  v1.build(*this);
  h4.build(v1);
  startfetchb.Create(h4, WHAT((char *) "    Hent tidsserie      ", 
			      (char *) "    Fetch time serie    "), 
		     this, CH_STARTFETCH);
  serielab.build(h4, 
		 WHAT((char *) ".............................. "
		      "ingen serie innhentet"
		      " .......................................",
		      (char *) ".............................. "
		      "  no serie fetched   "
		      " ......................................."));
		      
  METHOD mets[]={MEAN,MIN,MAX,SUM,STANDARD_DEVIATION,VARIATION,SKEW,CURTOSIS,
		 PERCENTILE_2_5,PERCENTILE_5,PERCENTILE_10,PERCENTILE_20,
		 PERCENTILE_25,PERCENTILE_30,PERCENTILE_40,MEDIAN,
		 PERCENTILE_60,PERCENTILE_70,PERCENTILE_75,PERCENTILE_80,
		 PERCENTILE_90,PERCENTILE_95,PERCENTILE_97_5,
		 DERIVATIVE};
  selmet.create(h4, mets, 23);
  selmet.setfocus(MEDIAN);

  priorf.build(v1, 4, WHAT((char *) "A priori sannsynlighet for "
			   "homogenitet (prosent):",
			   (char *) "Prior probability for "
			   "homogeneity (percent):"));
  priorf.SetDouble(50.0, 4);
  h5.build(v1);
  prior_linf.build(h5, 4, WHAT((char *) "A priori sannsynlighet for "
		   "line�r trend (prosent):",
			       (char *) "Prior probability for "
		   "linear trend (percent):"));
  prior_linf.SetDouble(10.0, 4);
  prior_quadf.build(h5, 4, WHAT((char *) "A priori sannsynlighet for kvadratisk "
				"trend (prosent):",
				(char *) "Prior probability for quadratic "
				"trend (percent):"));
  prior_quadf.SetDouble(4.0, 4);
  prior_twostepf.build(v1, 4, 
		       WHAT((char *) "A priori sanns. for to-sprang-modell "
			    "(prosent):",
			    (char *) "Prior prob. for two-step model "
			    "(percent):"));
  prior_twostepf.SetDouble(10.0, 4);
  lab1.build(v1, WHAT((char *) "(Merk at disse sannsynligheten m� summeres til "
		      "mindre enn 100%% for � holde mulighet for "
		      "ett-stegs-modell �pen.)",
		      (char *) "(Note that these probabilities should in sum "
		      "be less than 100%% in order to make the one step "
		      "model possible.)"));
  h1.build(v1);
  runb.Create(h1, WHAT((char *) "Kj�r analyse", (char *) "Run analysis"), 
	      this, CH_RUN);
  runb.Background("green");
  runb.Foreground("black");
  
  h6.build(v1);
  v2.build(h6);
  resultlistlab.build(v2,WHAT((char *) 
			      "Modeller sortert p� sannsynlighet          ",
			      (char *) 
			      "Models sorted on probability               "));
  resultlist.build(v2,5);
  result.build(h6, 90, 10);

  h7.build(v1);
  show_credibility.build(h7, WHAT((char *) "Vis 95% troverdighetsintervall",
				  (char *) "Show 95% credibility interval"));
  plot_timeserieb.Create(h7, WHAT((char *) "Plott tidsserie",
				  (char *) "Plot time serie"), 
			 this, CH_PLOT_TIMESERIE);
  plot_postb.Create(h7, WHAT((char *) "Plott sprang-sanns.", 
			     (char *) "Plot one step prob."), 
		    this, CH_PLOT_POSTERIORI);
  plot_post2b.Create(h7, WHAT((char *) "Plott tostegs sprang-sanns.", 
			      (char *) "Plot two step prob."), 
		     this, CH_PLOT_TWOSTEP_POSTERIORI);

  h2.build(v1);
  exitb.Create(h2, WHAT((char *) "Avslutt", (char *) "Quit"), this, CH_EXIT);
  exitb.Background("red");
  exitb.Foreground("white");
  result.build_printb(h2, WHAT((char *) "Skriv ut", (char *) "Print"));
  result.build_chprintb(h2, WHAT((char *) "Forandre skriver",
				 (char *) "Change printer"));
  result.build_printlab(h2);
  result.build_emailb(h2, WHAT((char *) "Send som epost",
			       (char *) "Send as email"));
  result.build_saveb(h2, WHAT((char *) "Lagre p� fil", (char *) "Save as file"));

  spc.Unmap();
  Set(2);
}

void check_file_homogeneity::wakeup(void)
{
  h8.Unmap();
  spc.Map();
}

check_file_homogeneity::~check_file_homogeneity()
{
  cleanup();
}

int main(int argc, char **argv)
{
  check_file_homogeneity ch(argc, argv);
  ch.Run();

  return 0;
}
