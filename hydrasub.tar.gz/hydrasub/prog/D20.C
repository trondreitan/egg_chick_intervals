#include <cmath>
#include <stdlib.h>
#include <iostream>

// The 'motor' of the application;
// recursively traverse all ordered combination 
// of dice events and increments the number of 
// unordered ways to get a outcome. 
long double *dice(int depth, long double *prevnumber, long double *totnumber, 
	     unsigned long int *numit, int numdice)
{
  int i,j,minindex=20*numdice,maxindex=0, is_zero=1;
  long double *thisnumber=new long double[numdice*20+2];
  for(i=0;i<20*numdice+2;i++)
    thisnumber[i]=0.0;

  for(j=0;j<20*numdice+2;j++)
    {
      if(prevnumber[j]>0 && j<minindex)
	minindex=j;
      if(prevnumber[j]>0 && j>maxindex)
	maxindex=j;
      if(prevnumber[j]>0)
	is_zero=0;
    }

  if(is_zero)
    {
      minindex=0;
      maxindex=0;
    }

  for(i=1;i<=20;i++)
    for(j=minindex;j<=maxindex;j++)
      {
	thisnumber[j+i]+= (is_zero ? 1.0 : prevnumber[j]);
	if(depth==1)
	  *totnumber+=(is_zero ? 1 : prevnumber[j]);
	*numit++;
      }

  if(depth==1)
    return thisnumber;
  else
    {
      long double *number=dice(depth-1, thisnumber, totnumber, numit, numdice);
      delete [] thisnumber;
      return number;
    }
}


void usage(void)
{
  std::cout << "Usage: dice3 [-s] [-n] <number of dice>" << std::endl;
  std::cout << "Returns a stream of all possible sum of outcomes." << std::endl;
  std::cout << "Options: -s : toggles extra normal distribution" << std::endl;
  std::cout << "         -n : toggles number of outcomes rather than prob." << std::endl;
  exit(0);
}


int main(int argc, char **argv)
{
  int showgauss=0, shownum=0; // output indicators
  
  // Handle input arguments;
  while(argc>1 && argv[1][0]=='-')
    {
      switch(argv[1][1])
	{
	case 's':
	  showgauss=1;
	  break;
	case 'n':
	  shownum=1;
	  break;
	case 'h':
	case 'H':
	default:
	  usage();
	  break;
	}
      argc--;
      argv++;
    }


  if(argc!=2) // We need the number of dices
    usage(); 


  
  unsigned long int numit=0; // number of total calculations
  int numdice=atoi(argv[1]); // number of dices
  // The number of different outcomes;
  long double *number=new long double[numdice*20+2], 
    *in_number=new long double[20*numdice+2], totnumber=0.0;
  int i; // countint variable
  double mf=((double) numdice)*(20.0+1.0)/2.0, 
    vf=((double) numdice)*
    ((20.0+1.0)*(2.0*20.0+1.0)/6.0-(20.0+1.0)*(20.0+1.0)/4.0);
  
  // initialize the number of outcomes;
  for(i=0;i<numdice*20+2;i++)
    in_number[i]=0;
  
  // Do the caluclation of number of outcomes;
  number=dice(numdice, in_number, &totnumber, &numit, numdice);

  // Caluclate the probabilities from the number of outcomes;
  long double *prob=new long double[numdice*20+2];
  for(i=0;i<numdice*20+2;i++)
    prob[i]=number[i]/totnumber;


  // Output:
  char line[200];  
  sprintf(line,"# Column 1: sum(%ld terninger) - totalt antall=%12.6g "
	  ,numdice,totnumber);
  std::cout << line << std::endl;
  std::cout << "# Column 1 - type: bars" << std::endl;
  if(showgauss)
    {
      sprintf(line,"# Column 2: Normalfordeling, N(%lf, %lf)",
	      mf,vf);
      std::cout << line << std::endl;
    }
  std::cout << "#################" << std::endl;
  for(i=0;i<numdice*20+2;i++)
    {
      std::cout << i << " " << (shownum==0 ? prob[i] : number[i]);
      if(showgauss)
	std::cout << " -10000000";
      std::cout << std::endl;
    }

  // extra output:
  if(showgauss)
    for(double x=0;x<=20.0*((double) numdice)+2.0;x+=0.1)
      std::cout << x << " -10000000 " << (shownum==0 ? 1.0 : totnumber) *
	exp(-(x-mf)*(x-mf)/2.0/vf-0.5*log(2.0*M_PI)-0.5*log(vf)) << std::endl;

  //std::cerr << numit << std::endl;

  return 0;
}
