#include <stdio.h>
#include <stream.h>
#include <unistd.h>
#include <gsl/gsl_randist.h>
#include <cmath>
#include <hydrasub/hydrabase/divfunc.H>
#include <hydrasub/hydrabase/regression.H>


double predict_q(double x, double y, double a, double b, 
		 double c, double x0, double y0)
{
  double q=a+b*log(x-x0);
  if(y>y0)
    q+=c*log((x-y)/(x-y0));

  return q;
}


double logprob(// data:
	       double *q, double *x, double *y, int n,
	       
	       // prior hyper-parameters:
	       double a0, double a_s2, double b0, double b_s2,
	       double c0, double c_s2, double x00, double x0_s2, 
	       double y0_s2, double s2_alpha, double s2_beta,
	       double corr,

	       // current parameter state:
	       double a, double b, double c, 
	       double x0, double y0, double s2)
{
  int i;
  
  if(s2<=0.0)
    return -1e+200;
  for(i=0;i<n;i++)
    if(x[i]<x0 || (y[i]>y0 && x[i]<y0))
      return -1e+200;

  //double prior_a=-0.5*log(2.0*M_PI)-0.5*log(a_s2)-0.5*(a-a0)*(a-a0)/a_s2;
  //double prior_b=-0.5*log(2.0*M_PI)-0.5*log(b_s2)-0.5*(b-b0)*(b-b0)/b_s2;
  double prior_ab=-log(2.0*M_PI)-0.5*log(a_s2)-0.5*log(b_s2)-
    0.5*log(1.0-corr*corr) - 0.5/(1.0-corr*corr)*
    ((a-a0)*(a-a0)/a_s2+(b-b0)*(b-b0)/b_s2-2.0*corr*(a-a0)*(b-b0)/sqrt(a_s2*b_s2));
  double prior_c=-0.5*log(2.0*M_PI)-0.5*log(c_s2)-0.5*(c-c0)*(c-c0)/c_s2;
  double prior_x0=-0.5*log(2.0*M_PI)-0.5*log(x0_s2)-0.5*(x0-x00)*(x0-x00)/x0_s2;
  double prior_y0=-0.5*log(2.0*M_PI)-0.5*log(y0_s2)-0.5*(y0-x0)*(y0-x0)/y0_s2;
  double prior_s2=s2_alpha*log(s2_beta)-gamma(s2_alpha)-(s2_alpha-1.0)*log(s2)-
    s2_beta/s2;
  
  double loglik=0.0;

  for(i=0;i<n;i++)
    {
      double res=q[i]-predict_q(x[i],y[i], a, b, c, x0, y0);
      loglik += -0.5*log(2.0*M_PI)-0.5*log(s2)-0.5*res*res/s2;
    }


  double logp=prior_ab+prior_c+prior_x0+prior_y0+prior_s2+loglik;

  return logp;
}

void get_new_sample(// data:
		    double *q, double *x, double *y, int n,

		    // prior hyper-parameters:
		    double a0, double a_s2, double b0, double b_s2,
		    double c0, double c_s2, double x00, double x0_s2, 
		    double y0_s2, double s2_alpha, double s2_beta,
		    double corr,

		    // current parameter state:
		    double &a, double &b, double &c, 
		    double &x0, double &y0, double &s2,

		    // random walk Metropolis parameters:
		    double rw_a, double rw_b, double rw_c,
		    double rw_x0, double rw_y0, double rw_s2,

		    // for counting acceptance: 
		    int *acc,

		    // structure for sampling from various dist:
		    gsl_rng *rptr)
{
  double new_logprob, prev_logprob=
    logprob(q, x, y, n, a0, a_s2, b0, b_s2, c0, c_s2, x00, x0_s2, y0_s2,
	    s2_alpha, s2_beta, corr, a,b,c,x0,y0,s2);
  
  double new_a=a+rw_a*gsl_ran_ugaussian(rptr);
  new_logprob=logprob(q, x, y, n, a0, a_s2, b0, b_s2, c0, c_s2, x00, x0_s2, y0_s2,
	    s2_alpha, s2_beta, corr, new_a,b,c,x0,y0,s2);
  if(log(drand48())< new_logprob-prev_logprob)
    {
      a=new_a;
      prev_logprob=new_logprob;
      acc[0]++;
    }
  
  double new_b=b+rw_b*gsl_ran_ugaussian(rptr);
  new_logprob=logprob(q, x, y, n, a0, a_s2, b0, b_s2, c0, c_s2, x00, x0_s2, y0_s2,
	    s2_alpha, s2_beta, corr, a,new_b,c,x0,y0,s2);
  if(log(drand48())< new_logprob-prev_logprob)
    {
      b=new_b;
      prev_logprob=new_logprob;
      acc[1]++;
    }
  
  double new_c=c+rw_c*gsl_ran_ugaussian(rptr);
  new_logprob=logprob(q, x, y, n, a0, a_s2, b0, b_s2, c0, c_s2, x00, x0_s2, y0_s2,
	    s2_alpha, s2_beta, corr, a,b,new_c,x0,y0,s2);
  if(log(drand48())< new_logprob-prev_logprob)
    {
      c=new_c;
      prev_logprob=new_logprob;
      acc[2]++;
    }
  
  double new_x0=x0+rw_x0*gsl_ran_ugaussian(rptr);
  new_logprob=logprob(q, x, y, n, a0, a_s2, b0, b_s2, c0, c_s2, x00, x0_s2, y0_s2,
	    s2_alpha, s2_beta, corr, a,b,c,new_x0,y0,s2);
  if(log(drand48())< new_logprob-prev_logprob)
    {
      x0=new_x0;
      prev_logprob=new_logprob;
      acc[3]++;
    }  

  double new_y0=y0+rw_y0*gsl_ran_ugaussian(rptr);
  new_logprob=logprob(q, x, y, n, a0, a_s2, b0, b_s2, c0, c_s2, x00, x0_s2, y0_s2,
		      s2_alpha, s2_beta, corr, a,b,c,x0,new_y0,s2);
  if(log(drand48())< new_logprob-prev_logprob)
    {
      y0=new_y0;
      prev_logprob=new_logprob;
      acc[4]++;
    }

  double new_s2=s2+rw_s2*gsl_ran_ugaussian(rptr);
  new_logprob=logprob(q, x, y, n, a0, a_s2, b0, b_s2, c0, c_s2, x00, x0_s2, y0_s2,
	    s2_alpha, s2_beta, corr, a,b,c,x0,y0,new_s2);
  if(log(drand48())< new_logprob-prev_logprob)
    {
      s2=new_s2;
      prev_logprob=new_logprob;
      acc[5]++;
    }
}

void sample_params(int N /* number of samples */, int burnin, int indep,

		   // data:
		   double *q, double *x, double *y, int n,
		   
		   // prior hyper-parameters:
		   double a0, double a_s2, double b0, double b_s2,
		   double c0, double c_s2, double x00, double x0_s2, 
		   double y0_s2, double s2_alpha, double s2_beta, 
		   double corr,
		   
		   double **sim_a, double **sim_b, 
		   double **sim_c, double **sim_x0, 
		   double **sim_y0, double **sim_sigma) 
{
  randify();
  gsl_rng *rptr=gsl_rng_alloc(gsl_rng_rand48);
  gsl_rng_set(rptr, rand());
  
  int i,j;

  // Storage for the samples:
  double *a=new double[N], *b=new double[N], *c=new double[N], 
    *x0=new double[N], *y0=new double[N], *sigma=new double[N];

  // Draw first parameter set from the prior:
  double prev_a=a0+sqrt(a_s2)*gsl_ran_ugaussian(rptr);
  double prev_b=b0+sqrt(b_s2)*gsl_ran_ugaussian(rptr);
  double prev_c=c0+sqrt(c_s2)*gsl_ran_ugaussian(rptr);
  double prev_x0, prev_y0;
  int legal;
  do
    {
      legal=1;
      prev_x0=x00+sqrt(x0_s2)*gsl_ran_ugaussian(rptr);
      prev_y0=prev_x0+sqrt(y0_s2)*gsl_ran_ugaussian(rptr);
      for(i=0;i<n && legal;i++)
	if(x[i]<prev_x0 || x[i]<prev_y0)
	  legal=0;
    } while(!legal);
  double prev_s2=1.0/gsl_ran_gamma(rptr, s2_alpha, 1.0/s2_beta);
  
  // Random walk metropolis parameters:
  double rw_a=0.5;
  double rw_b=0.5;
  double rw_c=0.5;
  double rw_x0=10.0;
  double rw_y0=0.5;
  double rw_s2=0.1;

  // Storage for acceptance rates:
  int *acc=new int[6];
  for(i=0;i<6;i++)
    acc[i]=0;

  // first burnin:
  for(i=0;i<burnin/2;i++)
    get_new_sample(q,x,y,n, a0, a_s2, b0, b_s2, c0, c_s2,
		   x00, x0_s2, y0_s2, s2_alpha, s2_beta, corr, 
		   prev_a, prev_b, prev_c, prev_x0, prev_y0,
		   prev_s2, rw_a, rw_b, rw_c, rw_x0, rw_y0, rw_s2,
		   acc, rptr);

  // adaptive burnin based on acceptance rates:
  for(i=0;i<burnin/2/100;i++)
    {
      for(j=0;j<6;j++)
	acc[j]=0;
      
      for(j=0;j<100;j++)
	get_new_sample(q,x,y,n, a0, a_s2, b0, b_s2, c0, c_s2,
		       x00, x0_s2, y0_s2, s2_alpha, s2_beta, corr, 
		       prev_a, prev_b, prev_c, prev_x0, prev_y0,
		       prev_s2, rw_a, rw_b, rw_c, rw_x0, rw_y0, rw_s2,
		       acc, rptr);

      // Adjust rates to be as near 1/3 as possible:
      rw_a  *= exp((double(acc[0])/100.0-0.33)*2.0);
      rw_b  *= exp((double(acc[1])/100.0-0.33)*2.0);
      rw_c  *= exp((double(acc[2])/100.0-0.33)*2.0);
      rw_x0 *= exp((double(acc[3])/100.0-0.33)*2.0);
      rw_y0 *= exp((double(acc[4])/100.0-0.33)*2.0);
      rw_s2 *= exp((double(acc[4])/100.0-0.33)*2.0);
      
      // Show the current state:
      printf("%f %f %f %f %f %f\n", rw_a, rw_b, rw_c, rw_x0, rw_y0, rw_s2);
    }
  
  for(i=0;i<N;i++)
    {
      for(j=0;j<indep;j++)
	get_new_sample(q,x,y,n, a0, a_s2, b0, b_s2, c0, c_s2,
		       x00, x0_s2, y0_s2, s2_alpha, s2_beta, corr, 
		       prev_a, prev_b, prev_c, prev_x0, prev_y0,
		       prev_s2, rw_a, rw_b, rw_c, rw_x0, rw_y0, rw_s2,
		       acc, rptr);

      a[i]=prev_a;
      b[i]=prev_b;
      c[i]=prev_c;
      x0[i]=prev_x0;
      y0[i]=prev_y0;
      sigma[i]=sqrt(prev_s2);
      
      if(i>0 && i%100==0)
	printf("%d of %d\n", i*indep, indep*N);
    }

  delete [] acc;

  *sim_a=a;
  *sim_b=b;
  *sim_c=c;
  *sim_x0=x0;
  *sim_y0=y0;
  *sim_sigma=sigma;
}

void show_parameter(double *par, int N, char *parname) 
{
  char cmd[1000];
  FILE *p;
  int i, len=N;
  double rho=get_auto_correlation(par, len);
  //double n_indep=len/2.0/(0.5+rho/(1.0-rho));
  double spacing=2.0*(0.5+rho/(1.0-rho));
  printf("%s - spacing between independent samples: %f\n", parname, spacing);

  sprintf(cmd, "vvgraph -x %s", parname);
  p=popen(cmd,"w");
  fprintf(p,"# Column 1: %s\n",  parname);
  fprintf(p,"###################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%d %f\n", i+1, par[i]);
  pclose(p);

  sprintf(cmd, "histogramme -x \"%s\" -t \"%s\"", 
	  parname,  parname); 
  p=popen(cmd, "w");
  for(i=0;i<len;i++)
    fprintf(p,"%f\n", par[i]);
  pclose(p);
}

void show_scatter(double *par1, double *par2, int N, 
		  char *parname1, char *parname2)
{
  FILE *p;
  char cmd[1000];
  int i, len=N;

  sprintf(cmd, "vvgraph -x %s -y %s", parname1, parname2);
  p=popen(cmd,"w");
  fprintf(p, "# Column 1: %s vs %s\n", parname1, parname2);
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "#####################\n");
  for(i=0;i<len;i++)
    fprintf(p,"%f %f\n", par1[i], par2[i]);
  pclose(p);
}


void usage(int N, int indep, int burnin, double a0, double a_s, 
	   double b0, double b_s, double c0, double c_s, 
	   double x00, double x0_s, double y0_s, double s1, double s2)
{
  printf("Usage: backwater [options] <file> "
	 "[<N> <indep> <burnin> [<a_lower> <a_upper>\n");
  printf(" <b_lower> <b_upper> <c_lower> <c_upper> <x0_lower> <x0_upper>\n");
  printf(" <y0_sigma> <sigma_lower> <sigma_upper>]]\n\n");
  printf("Default: N=%d, indep=%d, burnin=%d\n", N, indep, burnin);
  printf("         a_lower=%f a_upper=%f\n", a0-1.96*a_s, a0+1.96*a_s);
  printf("         b_lower=%f b_upper=%f\n", b0-1.96*b_s, b0+1.96*b_s);
  printf("         c_lower=%f c_upper=%f\n", c0-1.96*c_s, c0+1.96*c_s);
  printf("         x0_lower=%f x0_upper=%f\n", x00-1.96*x0_s, x00+1.96*x0_s);
  printf("         y0_sigma=%f\n", y0_s);
  printf("         sigma_lower=%f sigma_upper=%f\n\n", s1, s2);
  printf("Options:\n");
  printf(" -s : surpress parameter plots\n"); 
  printf(" -c <correlation> : specify correlation between parameter a and b\n"); 
  printf(" -t <x timeserie file> <y timeserie file> <output file>: \n"
	 "    makes a discharge timeseries based on the two stage series.\n"); 
  printf(" -u <x timeserie file> <y timeserie file> <output file>: \n"
	 "    same as '-t', except shows upper and lower 95%% cred. interval "
	 "    also.\n"); 
  printf(" -p <parameter sample file> : Lists the samples in a given file\n");
  exit(0);
}


int main(int argc, char **argv)
{
  double *q,*x, *y; 
  int surpress=0,i,len=0, ts=0, us=0, pf=0;
  char in_x[100], in_y[100], q_out[100], pfile[1000];
  double corr=0;
  
  // Prior hyper-parameters:
  double a0=1.15, a_s=2.3;
  double b0=2.0,  b_s=1.0;
  double c0=0.5,  c_s=0.5;
  double x00=0.0, x0_s=100.0, y0_s=1.0;
  double alpha, beta;
  double s1=0.02, s2=0.15;
  int N=1000,burnin=100000,indep=200; 
  

  while(argc>1 && argv[1][0]=='-')
    {
      switch(argv[1][1])
	{
	case 'c':
	  if(argc<3)
	    usage(N,indep,burnin,a0,a_s,b0,b_s,c0,c_s,x00,x0_s,y0_s,s1,s2);
	  corr=atof(argv[2]);
	  argc--;
	  argv++;
	  break;
	case 'p':
	  if(argc<3)
	    usage(N,indep,burnin,a0,a_s,b0,b_s,c0,c_s,x00,x0_s,y0_s,s1,s2);
	  pf=1;
	  strcpy(pfile, argv[2]);
	  argc--;
	  argv++;
	  break;
	case 's':
	  surpress=1;
	  break;
	case 't':
	  ts=1;
	  if(argc<5)
	    usage(N,indep,burnin,a0,a_s,b0,b_s,c0,c_s,x00,x0_s,y0_s,s1,s2);
	  strcpy(in_x, argv[2]);
	  strcpy(in_y, argv[3]);
	  strcpy(q_out, argv[4]);
	  argc-=3;
	  argv+=3;
	  break;
	case 'u':
	  us=1;
	  if(argc<5)
	    usage(N,indep,burnin,a0,a_s,b0,b_s,c0,c_s,x00,x0_s,y0_s,s1,s2);
	  strcpy(in_x, argv[2]);
	  strcpy(in_y, argv[3]);
	  strcpy(q_out, argv[4]);
	  argc-=3;
	  argv+=3;
	  break;
	default:
	  usage(N,indep,burnin,a0,a_s,b0,b_s,c0,c_s,x00,x0_s,y0_s,s1,s2);
	  break;
	}

      argc--;
      argv++;
    }

  if(argc<2)
    usage(N,indep,burnin,a0,a_s,b0,b_s,c0,c_s,x00,x0_s,y0_s,s1,s2);

  double *ts_x=NULL, *ts_y=NULL;
  DateTime *ts_t=NULL;
  int ts_len;
  if(ts || us)
    {
      timeserielist *tsx=get_timeserie_file(in_x);
      timeserielist *tsy=get_timeserie_file(in_y);

      ts_x=tsx->getvaluearray(ts_len);
      ts_y=tsy->getvaluearray(ts_len);
      ts_t=tsy->gettimearray(ts_len);
    }
  
  double_3d *d3_array=get_3d_data_file(argv[1], &len);
  if(len==0)
    {
      printf("Could not read file %s!\n", argv[1]);
      return 1;
    }

  q=new double[len];
  x=new double[len];
  y=new double[len];
  for(i=0;i<len;i++)
    {
      x[i]=d3_array[i].x;
      y[i]=d3_array[i].y;
      q[i]=log(d3_array[i].z);
    }

  // Prior hyper-parameters:
  find_invgamma_distribution(s1*s1, s2*s2, 95.0, &alpha, &beta);
  printf("sigma�~IG(%f,%f)\n", alpha, beta);

  if(argc>2)
    N=atoi(argv[2]);
  if(argc>3)
    indep=atoi(argv[3]);
  if(argc>4)
    burnin=atoi(argv[4]);
  if(argc>6)
    {
      double a_l=atof(argv[5]), a_u=atof(argv[6]);
      a0=(a_l+a_u)/2.0;
      a_s=(a_u-a_l)/2.0/1.96;
    }
  if(argc>8)
    {
      double b_l=atof(argv[7]), b_u=atof(argv[8]);
      b0=(b_l+b_u)/2.0;
      b_s=(b_u-b_l)/2.0/1.96;
    }
  if(argc>10)
    {
      double c_l=atof(argv[9]), c_u=atof(argv[10]);
      c0=(c_l+c_u)/2.0;
      c_s=(c_u-c_l)/2.0/1.96;
    }
  if(argc>12)
    {
      double x0_l=atof(argv[11]), x0_u=atof(argv[12]);
      x00=(x0_l+x0_u)/2.0;
      x0_s=(x0_u-x0_l)/2.0/1.96;
    }
  if(argc>13)
    y0_s=atof(argv[13]);
  if(argc>15)
    {
      s1=atof(argv[14]);
      s2=atof(argv[15]);
    }

  double *sim_a, *sim_b, *sim_c, *sim_x0, *sim_y0, *sim_sigma;

  function_timer::start_total_timer(10);
  sample_params(N, burnin, indep, q, x, y, len,
		a0, a_s*a_s, b0, b_s*b_s, c0, c_s*c_s,
		x00, x0_s*x0_s, y0_s*y0_s, alpha, beta, corr, 
		&sim_a, &sim_b, &sim_c, &sim_x0, 
		&sim_y0, &sim_sigma);
  function_timer::stop_total_timer();
  printf("Tid: %f\n", function_timer::get_total_timer());
  
  FILE *p,*f;

  if(pf)
    {
      f=fopen(pfile, "w");
      fprintf(f, "%6s %8s %8s %8s %8s %8s %8s\n", "Iter.", 
	      "a", "b", "c", "x0", "y0", "sigma");
      for(i=0;i<N;i++)
	fprintf(f, "%6d %8.3f %8.3f %8.3f %8.3f %8.3f %8.3f\n",
		i+1, sim_a[i], sim_b[i], sim_c[i], sim_x0[i], sim_y0[i], sim_sigma[i]);
      fclose(f);
    }

  if(ts)
    {
      p=fopen(q_out, "w");
      for(i=0;i<ts_len;i++)
	{
	  double *qi=new double[N];
	  for(int j=0;j<N;j++)
	    qi[j]=predict_q(ts_x[i], ts_y[i], sim_a[j], sim_b[j], sim_c[j], 
			    sim_x0[j], sim_y0[j]);
	  double q=find_statistics(qi, N, MEDIAN);
	  double Q=exp(q);
	  
	  fprintf(p, "%04d%02d%02d/%02d%02d %8.4f\n", 
		  ts_t[i].getYear(), ts_t[i].getMonth(),
		  ts_t[i].getDay(), ts_t[i].getHour(),
		  ts_t[i].getMinute(), Q);
	  
	  delete [] qi;
	}
      pclose(p);
    }
  else if(us)
    {
      p=fopen(q_out, "w");
      fprintf(p, "# Column 1: median Q\n");
      fprintf(p, "# Column 2: lower 95%% cred.\n");
      fprintf(p, "# Column 3: uppser 95%% cred.\n");
      fprintf(p, "##########################\n");
      for(i=0;i<ts_len;i++)
	{
	  double *qi=new double[N];
	  for(int j=0;j<N;j++)
	    qi[j]=predict_q(ts_x[i], ts_y[i], sim_a[j], sim_b[j], sim_c[j], 
			    sim_x0[j], sim_y0[j]);
	  double q1=find_statistics(qi, N, MEDIAN);
	  double q2=find_statistics(qi, N, PERCENTILE_2_5);
	  double q3=find_statistics(qi, N, PERCENTILE_97_5);
	  double Q1=exp(q1),Q2=exp(q2),Q3=exp(q3);
	  
	  fprintf(p, "%04d%02d%02d/%02d%02d %8.4f %8.4f %8.4f\n", 
		  ts_t[i].getYear(), ts_t[i].getMonth(),
		  ts_t[i].getDay(), ts_t[i].getHour(),
		  ts_t[i].getMinute(), Q1, Q2, Q3);
	  
	  delete [] qi;
	}
      pclose(p);
    }

  if(!surpress)
    {
      show_parameter(sim_a,  N, "a");
      show_parameter(sim_b,  N, "b");
      show_parameter(sim_c,  N, "c");
      show_parameter(sim_x0, N, "x0");
      show_parameter(sim_y0, N, "y0");
      show_parameter(sim_sigma, N, "sigma");
      
      show_scatter(sim_a, sim_b, N, "a", "b");
      show_scatter(sim_a, sim_c, N, "a", "c");
      show_scatter(sim_a, sim_x0, N, "a", "x0");
      show_scatter(sim_a, sim_y0, N, "a", "y0");
      show_scatter(sim_a, sim_sigma, N, "a", "sigma");
      show_scatter(sim_b, sim_c, N, "b", "c");
      show_scatter(sim_b, sim_x0, N, "b", "x0");
      show_scatter(sim_b, sim_y0, N, "b", "y0");
      show_scatter(sim_b, sim_sigma, N, "b", "sigma");
      show_scatter(sim_c, sim_x0, N, "c", "x0");
      show_scatter(sim_c, sim_y0, N, "c", "y0");
      show_scatter(sim_c, sim_sigma, N, "c", "sigma");
      show_scatter(sim_x0, sim_y0, N, "x0", "y0");
      show_scatter(sim_x0, sim_sigma, N, "x0", "sigma");
      show_scatter(sim_y0, sim_sigma, N, "y0", "sigma");
    }

  double *q_med=new double[len];
  for(i=0;i<len;i++)
    {
      double *qi=new double[N];
      for(int j=0;j<N;j++)
	qi[j]=predict_q(x[i], y[i], sim_a[j], sim_b[j], sim_c[j], 
		     sim_x0[j], sim_y0[j]);
      q_med[i]=find_statistics(qi, N, MEDIAN);
      delete [] qi;
    }

  p=popen("vvgraph -x x -y res", "w");
  fprintf(p, "# Column 1: Residuals of q vs x\n");
  fprintf(p, "# Column 1 - type: dot");
  fprintf(p, "###############\n");
  for(i=0;i<len;i++)
    fprintf(p, "%f %f\n", x[i], q_med[i]-q[i]);
  pclose(p);

  p=popen("vvgraph -x y -y res", "w"); 
  fprintf(p, "# Column 1: Residuals of q vs y\n");
  fprintf(p, "# Column 1 - type: dot");
  fprintf(p, "###############\n");
  for(i=0;i<len;i++)
    fprintf(p, "%f %f\n", y[i], q_med[i]-q[i]);
  pclose(p);

  p=popen("vvgraph -x x -y Q", "w");
  fprintf(p, "# Column 1: Measured Q\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "# Column 2: Median predicted Q\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "###############\n");
  for(i=0;i<len;i++)
    fprintf(p, "%f %f %f\n", x[i], exp(q[i]), exp(q_med[i]));
  pclose(p);
  
  p=popen("vvgraph -x y -y Q", "w");
  fprintf(p, "# Column 1: Measured Q\n");
  fprintf(p, "# Column 1 - type: dot\n");
  fprintf(p, "# Column 2: Median Q_pred\n");
  fprintf(p, "# Column 2 - type: dot\n");
  fprintf(p, "###############\n");
  for(i=0;i<len;i++)
    fprintf(p, "%f %f %f\n", y[i], exp(q[i]), exp(q_med[i]));
  pclose(p);
  
  printf("\n");
  printf("%7s %7s %7s\n", "x", "y", "res"); 
  for(i=0;i<len;i++)
    printf("%7.3f %7.3f %7.3f\n", x[i], y[i], q[i]-q_med[i]);

  printf("\n");
  printf("%7s %7s %7s %7s\n", "x", "y", "Q_meas", "med(Q_pred)"); 
  for(i=0;i<len;i++)
    printf("%7.3f %7.3f %7.3f %7.3f\n", x[i], y[i], exp(q[i]), exp(q_med[i]));
}
